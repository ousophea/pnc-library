<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-10 18:29:28 --> Config Class Initialized
INFO - 2016-07-10 18:29:28 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:28 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:28 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:28 --> URI Class Initialized
DEBUG - 2016-07-10 18:29:28 --> No URI present. Default controller set.
INFO - 2016-07-10 18:29:28 --> Router Class Initialized
INFO - 2016-07-10 18:29:28 --> Output Class Initialized
INFO - 2016-07-10 18:29:28 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:28 --> Input Class Initialized
INFO - 2016-07-10 18:29:28 --> Language Class Initialized
INFO - 2016-07-10 18:29:28 --> Loader Class Initialized
INFO - 2016-07-10 18:29:28 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:28 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:28 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:28 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:28 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:28 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:28 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:28 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:28 --> Email Class Initialized
INFO - 2016-07-10 18:29:28 --> Controller Class Initialized
INFO - 2016-07-10 18:29:28 --> Config Class Initialized
INFO - 2016-07-10 18:29:28 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:28 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:28 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:28 --> URI Class Initialized
INFO - 2016-07-10 18:29:28 --> Router Class Initialized
INFO - 2016-07-10 18:29:28 --> Output Class Initialized
INFO - 2016-07-10 18:29:29 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:29 --> Input Class Initialized
INFO - 2016-07-10 18:29:29 --> Language Class Initialized
INFO - 2016-07-10 18:29:29 --> Loader Class Initialized
INFO - 2016-07-10 18:29:29 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:29 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:29 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:29 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:29 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:29 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:29 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:29 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:29 --> Email Class Initialized
INFO - 2016-07-10 18:29:29 --> Controller Class Initialized
INFO - 2016-07-10 18:29:29 --> Model Class Initialized
DEBUG - 2016-07-10 18:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-10 18:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-10 18:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:29:29 --> Final output sent to browser
DEBUG - 2016-07-10 18:29:29 --> Total execution time: 0.4093
INFO - 2016-07-10 18:29:35 --> Config Class Initialized
INFO - 2016-07-10 18:29:35 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:35 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:35 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:35 --> URI Class Initialized
INFO - 2016-07-10 18:29:35 --> Router Class Initialized
INFO - 2016-07-10 18:29:35 --> Output Class Initialized
INFO - 2016-07-10 18:29:35 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:35 --> Input Class Initialized
INFO - 2016-07-10 18:29:35 --> Language Class Initialized
INFO - 2016-07-10 18:29:35 --> Loader Class Initialized
INFO - 2016-07-10 18:29:35 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:35 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:35 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:35 --> Email Class Initialized
INFO - 2016-07-10 18:29:35 --> Controller Class Initialized
INFO - 2016-07-10 18:29:35 --> Model Class Initialized
DEBUG - 2016-07-10 18:29:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:29:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-10 18:29:35 --> Config Class Initialized
INFO - 2016-07-10 18:29:35 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:35 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:35 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:35 --> URI Class Initialized
DEBUG - 2016-07-10 18:29:35 --> No URI present. Default controller set.
INFO - 2016-07-10 18:29:35 --> Router Class Initialized
INFO - 2016-07-10 18:29:35 --> Output Class Initialized
INFO - 2016-07-10 18:29:35 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:35 --> Input Class Initialized
INFO - 2016-07-10 18:29:35 --> Language Class Initialized
INFO - 2016-07-10 18:29:35 --> Loader Class Initialized
INFO - 2016-07-10 18:29:35 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:35 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:35 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:35 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:35 --> Email Class Initialized
INFO - 2016-07-10 18:29:35 --> Controller Class Initialized
INFO - 2016-07-10 18:29:35 --> Model Class Initialized
INFO - 2016-07-10 18:29:35 --> Model Class Initialized
INFO - 2016-07-10 18:29:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:29:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:29:35 --> File loaded: D:\wamp\www\pnc-library\application\views\account/index.php
INFO - 2016-07-10 18:29:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:29:35 --> Final output sent to browser
DEBUG - 2016-07-10 18:29:35 --> Total execution time: 0.2583
INFO - 2016-07-10 18:29:40 --> Config Class Initialized
INFO - 2016-07-10 18:29:40 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:40 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:40 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:40 --> URI Class Initialized
INFO - 2016-07-10 18:29:40 --> Router Class Initialized
INFO - 2016-07-10 18:29:40 --> Output Class Initialized
INFO - 2016-07-10 18:29:40 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:40 --> Input Class Initialized
INFO - 2016-07-10 18:29:40 --> Language Class Initialized
INFO - 2016-07-10 18:29:40 --> Loader Class Initialized
INFO - 2016-07-10 18:29:40 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:40 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:40 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:40 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:40 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:40 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:40 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:41 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:41 --> Email Class Initialized
INFO - 2016-07-10 18:29:41 --> Controller Class Initialized
DEBUG - 2016-07-10 18:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:29:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:29:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:29:41 --> Model Class Initialized
INFO - 2016-07-10 18:29:41 --> Model Class Initialized
INFO - 2016-07-10 18:29:41 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-10 18:29:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:29:41 --> Final output sent to browser
DEBUG - 2016-07-10 18:29:41 --> Total execution time: 0.3571
INFO - 2016-07-10 18:29:42 --> Config Class Initialized
INFO - 2016-07-10 18:29:42 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:42 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:42 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:42 --> URI Class Initialized
INFO - 2016-07-10 18:29:42 --> Router Class Initialized
INFO - 2016-07-10 18:29:42 --> Output Class Initialized
INFO - 2016-07-10 18:29:42 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:42 --> Input Class Initialized
INFO - 2016-07-10 18:29:42 --> Language Class Initialized
INFO - 2016-07-10 18:29:42 --> Loader Class Initialized
INFO - 2016-07-10 18:29:42 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:42 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:42 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:42 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:42 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:42 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:42 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:42 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:42 --> Email Class Initialized
INFO - 2016-07-10 18:29:42 --> Controller Class Initialized
DEBUG - 2016-07-10 18:29:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:29:42 --> Model Class Initialized
INFO - 2016-07-10 18:29:42 --> Model Class Initialized
INFO - 2016-07-10 18:29:42 --> Model Class Initialized
INFO - 2016-07-10 18:29:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:29:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:29:42 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-10 18:29:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:29:42 --> Final output sent to browser
DEBUG - 2016-07-10 18:29:42 --> Total execution time: 0.2115
INFO - 2016-07-10 18:29:47 --> Config Class Initialized
INFO - 2016-07-10 18:29:47 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:47 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:47 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:47 --> URI Class Initialized
INFO - 2016-07-10 18:29:47 --> Router Class Initialized
INFO - 2016-07-10 18:29:47 --> Output Class Initialized
INFO - 2016-07-10 18:29:47 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:47 --> Input Class Initialized
INFO - 2016-07-10 18:29:47 --> Language Class Initialized
INFO - 2016-07-10 18:29:47 --> Loader Class Initialized
INFO - 2016-07-10 18:29:47 --> Helper loaded: url_helper
INFO - 2016-07-10 18:29:47 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:29:47 --> Helper loaded: html_helper
INFO - 2016-07-10 18:29:47 --> Helper loaded: form_helper
INFO - 2016-07-10 18:29:47 --> Helper loaded: file_helper
INFO - 2016-07-10 18:29:47 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:29:47 --> Database Driver Class Initialized
INFO - 2016-07-10 18:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:29:47 --> Form Validation Class Initialized
INFO - 2016-07-10 18:29:47 --> Email Class Initialized
INFO - 2016-07-10 18:29:47 --> Controller Class Initialized
DEBUG - 2016-07-10 18:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:29:47 --> Helper loaded: download_helper
INFO - 2016-07-10 18:29:47 --> Config Class Initialized
INFO - 2016-07-10 18:29:47 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:29:47 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:29:47 --> Utf8 Class Initialized
INFO - 2016-07-10 18:29:47 --> URI Class Initialized
INFO - 2016-07-10 18:29:47 --> Router Class Initialized
INFO - 2016-07-10 18:29:47 --> Output Class Initialized
INFO - 2016-07-10 18:29:47 --> Security Class Initialized
DEBUG - 2016-07-10 18:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:29:47 --> Input Class Initialized
INFO - 2016-07-10 18:29:47 --> Language Class Initialized
ERROR - 2016-07-10 18:29:48 --> 404 Page Not Found: Books/Book1.xlsx
ERROR - 2016-07-10 18:29:48 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xlsx): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\pnc-library\application\controllers\Books.php 321
INFO - 2016-07-10 18:30:53 --> Config Class Initialized
INFO - 2016-07-10 18:30:53 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:30:53 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:30:53 --> Utf8 Class Initialized
INFO - 2016-07-10 18:30:53 --> URI Class Initialized
INFO - 2016-07-10 18:30:53 --> Router Class Initialized
INFO - 2016-07-10 18:30:53 --> Output Class Initialized
INFO - 2016-07-10 18:30:53 --> Security Class Initialized
DEBUG - 2016-07-10 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:30:53 --> Input Class Initialized
INFO - 2016-07-10 18:30:53 --> Language Class Initialized
INFO - 2016-07-10 18:30:53 --> Loader Class Initialized
INFO - 2016-07-10 18:30:53 --> Helper loaded: url_helper
INFO - 2016-07-10 18:30:53 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:30:53 --> Helper loaded: html_helper
INFO - 2016-07-10 18:30:53 --> Helper loaded: form_helper
INFO - 2016-07-10 18:30:53 --> Helper loaded: file_helper
INFO - 2016-07-10 18:30:53 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:30:53 --> Database Driver Class Initialized
INFO - 2016-07-10 18:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:30:53 --> Form Validation Class Initialized
INFO - 2016-07-10 18:30:53 --> Email Class Initialized
INFO - 2016-07-10 18:30:53 --> Controller Class Initialized
DEBUG - 2016-07-10 18:30:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:30:53 --> Helper loaded: download_helper
INFO - 2016-07-10 18:30:53 --> Config Class Initialized
INFO - 2016-07-10 18:30:53 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:30:53 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:30:53 --> Utf8 Class Initialized
INFO - 2016-07-10 18:30:53 --> URI Class Initialized
INFO - 2016-07-10 18:30:53 --> Router Class Initialized
INFO - 2016-07-10 18:30:53 --> Output Class Initialized
INFO - 2016-07-10 18:30:53 --> Security Class Initialized
DEBUG - 2016-07-10 18:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:30:53 --> Input Class Initialized
INFO - 2016-07-10 18:30:53 --> Language Class Initialized
ERROR - 2016-07-10 18:30:53 --> 404 Page Not Found: Books/Book1.xlsx
ERROR - 2016-07-10 18:30:53 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xlsx): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\pnc-library\application\controllers\Books.php 321
INFO - 2016-07-10 18:36:48 --> Config Class Initialized
INFO - 2016-07-10 18:36:48 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:36:48 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:36:48 --> Utf8 Class Initialized
INFO - 2016-07-10 18:36:48 --> URI Class Initialized
INFO - 2016-07-10 18:36:48 --> Router Class Initialized
INFO - 2016-07-10 18:36:48 --> Output Class Initialized
INFO - 2016-07-10 18:36:48 --> Security Class Initialized
DEBUG - 2016-07-10 18:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:36:48 --> Input Class Initialized
INFO - 2016-07-10 18:36:48 --> Language Class Initialized
INFO - 2016-07-10 18:36:48 --> Loader Class Initialized
INFO - 2016-07-10 18:36:48 --> Helper loaded: url_helper
INFO - 2016-07-10 18:36:48 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:36:48 --> Helper loaded: html_helper
INFO - 2016-07-10 18:36:48 --> Helper loaded: form_helper
INFO - 2016-07-10 18:36:48 --> Helper loaded: file_helper
INFO - 2016-07-10 18:36:48 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:36:48 --> Database Driver Class Initialized
INFO - 2016-07-10 18:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:36:48 --> Form Validation Class Initialized
INFO - 2016-07-10 18:36:48 --> Email Class Initialized
INFO - 2016-07-10 18:36:48 --> Controller Class Initialized
DEBUG - 2016-07-10 18:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:36:48 --> Model Class Initialized
INFO - 2016-07-10 18:36:48 --> Model Class Initialized
INFO - 2016-07-10 18:36:48 --> Model Class Initialized
INFO - 2016-07-10 18:36:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:36:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:36:48 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-10 18:36:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:36:48 --> Final output sent to browser
DEBUG - 2016-07-10 18:36:48 --> Total execution time: 0.2323
INFO - 2016-07-10 18:36:53 --> Config Class Initialized
INFO - 2016-07-10 18:36:53 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:36:53 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:36:53 --> Utf8 Class Initialized
INFO - 2016-07-10 18:36:53 --> URI Class Initialized
INFO - 2016-07-10 18:36:53 --> Router Class Initialized
INFO - 2016-07-10 18:36:53 --> Output Class Initialized
INFO - 2016-07-10 18:36:53 --> Security Class Initialized
DEBUG - 2016-07-10 18:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:36:53 --> Input Class Initialized
INFO - 2016-07-10 18:36:53 --> Language Class Initialized
INFO - 2016-07-10 18:36:53 --> Loader Class Initialized
INFO - 2016-07-10 18:36:53 --> Helper loaded: url_helper
INFO - 2016-07-10 18:36:53 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:36:53 --> Helper loaded: html_helper
INFO - 2016-07-10 18:36:53 --> Helper loaded: form_helper
INFO - 2016-07-10 18:36:53 --> Helper loaded: file_helper
INFO - 2016-07-10 18:36:53 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:36:53 --> Database Driver Class Initialized
INFO - 2016-07-10 18:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:36:53 --> Form Validation Class Initialized
INFO - 2016-07-10 18:36:53 --> Email Class Initialized
INFO - 2016-07-10 18:36:53 --> Controller Class Initialized
DEBUG - 2016-07-10 18:36:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:36:53 --> Helper loaded: download_helper
INFO - 2016-07-10 18:36:53 --> Config Class Initialized
INFO - 2016-07-10 18:36:53 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:36:53 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:36:53 --> Utf8 Class Initialized
INFO - 2016-07-10 18:36:53 --> URI Class Initialized
INFO - 2016-07-10 18:36:53 --> Router Class Initialized
INFO - 2016-07-10 18:36:53 --> Output Class Initialized
INFO - 2016-07-10 18:36:53 --> Security Class Initialized
DEBUG - 2016-07-10 18:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:36:53 --> Input Class Initialized
INFO - 2016-07-10 18:36:53 --> Language Class Initialized
ERROR - 2016-07-10 18:36:53 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-10 18:36:53 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\pnc-library\application\controllers\Books.php 321
INFO - 2016-07-10 18:37:08 --> Config Class Initialized
INFO - 2016-07-10 18:37:08 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:37:08 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:37:08 --> Utf8 Class Initialized
INFO - 2016-07-10 18:37:08 --> URI Class Initialized
INFO - 2016-07-10 18:37:08 --> Router Class Initialized
INFO - 2016-07-10 18:37:08 --> Output Class Initialized
INFO - 2016-07-10 18:37:08 --> Security Class Initialized
DEBUG - 2016-07-10 18:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:37:08 --> Input Class Initialized
INFO - 2016-07-10 18:37:08 --> Language Class Initialized
INFO - 2016-07-10 18:37:08 --> Loader Class Initialized
INFO - 2016-07-10 18:37:08 --> Helper loaded: url_helper
INFO - 2016-07-10 18:37:08 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:37:08 --> Helper loaded: html_helper
INFO - 2016-07-10 18:37:08 --> Helper loaded: form_helper
INFO - 2016-07-10 18:37:08 --> Helper loaded: file_helper
INFO - 2016-07-10 18:37:08 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:37:08 --> Database Driver Class Initialized
INFO - 2016-07-10 18:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:37:08 --> Form Validation Class Initialized
INFO - 2016-07-10 18:37:08 --> Email Class Initialized
INFO - 2016-07-10 18:37:08 --> Controller Class Initialized
DEBUG - 2016-07-10 18:37:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:37:08 --> Helper loaded: download_helper
INFO - 2016-07-10 18:37:08 --> Config Class Initialized
INFO - 2016-07-10 18:37:08 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:37:08 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:37:08 --> Utf8 Class Initialized
INFO - 2016-07-10 18:37:08 --> URI Class Initialized
INFO - 2016-07-10 18:37:08 --> Router Class Initialized
INFO - 2016-07-10 18:37:08 --> Output Class Initialized
INFO - 2016-07-10 18:37:08 --> Security Class Initialized
DEBUG - 2016-07-10 18:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:37:08 --> Input Class Initialized
INFO - 2016-07-10 18:37:08 --> Language Class Initialized
ERROR - 2016-07-10 18:37:08 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-10 18:37:08 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\pnc-library\application\controllers\Books.php 321
INFO - 2016-07-10 18:38:29 --> Config Class Initialized
INFO - 2016-07-10 18:38:29 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:38:29 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:38:29 --> Utf8 Class Initialized
INFO - 2016-07-10 18:38:29 --> URI Class Initialized
INFO - 2016-07-10 18:38:29 --> Router Class Initialized
INFO - 2016-07-10 18:38:29 --> Output Class Initialized
INFO - 2016-07-10 18:38:29 --> Security Class Initialized
DEBUG - 2016-07-10 18:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:38:29 --> Input Class Initialized
INFO - 2016-07-10 18:38:29 --> Language Class Initialized
INFO - 2016-07-10 18:38:29 --> Loader Class Initialized
INFO - 2016-07-10 18:38:29 --> Helper loaded: url_helper
INFO - 2016-07-10 18:38:29 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:38:29 --> Helper loaded: html_helper
INFO - 2016-07-10 18:38:29 --> Helper loaded: form_helper
INFO - 2016-07-10 18:38:29 --> Helper loaded: file_helper
INFO - 2016-07-10 18:38:29 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:38:29 --> Database Driver Class Initialized
INFO - 2016-07-10 18:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:38:29 --> Form Validation Class Initialized
INFO - 2016-07-10 18:38:29 --> Email Class Initialized
INFO - 2016-07-10 18:38:29 --> Controller Class Initialized
INFO - 2016-07-10 18:38:29 --> Model Class Initialized
INFO - 2016-07-10 18:38:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:38:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:38:29 --> File loaded: D:\wamp\www\pnc-library\application\views\users/users_state.php
INFO - 2016-07-10 18:38:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:38:29 --> Final output sent to browser
DEBUG - 2016-07-10 18:38:29 --> Total execution time: 0.3480
INFO - 2016-07-10 18:38:30 --> Config Class Initialized
INFO - 2016-07-10 18:38:30 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:38:30 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:38:30 --> Utf8 Class Initialized
INFO - 2016-07-10 18:38:30 --> URI Class Initialized
INFO - 2016-07-10 18:38:30 --> Router Class Initialized
INFO - 2016-07-10 18:38:30 --> Output Class Initialized
INFO - 2016-07-10 18:38:30 --> Security Class Initialized
DEBUG - 2016-07-10 18:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:38:30 --> Input Class Initialized
INFO - 2016-07-10 18:38:30 --> Language Class Initialized
INFO - 2016-07-10 18:38:30 --> Loader Class Initialized
INFO - 2016-07-10 18:38:30 --> Helper loaded: url_helper
INFO - 2016-07-10 18:38:30 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:38:30 --> Helper loaded: html_helper
INFO - 2016-07-10 18:38:30 --> Helper loaded: form_helper
INFO - 2016-07-10 18:38:30 --> Helper loaded: file_helper
INFO - 2016-07-10 18:38:30 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:38:30 --> Database Driver Class Initialized
INFO - 2016-07-10 18:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:38:30 --> Form Validation Class Initialized
INFO - 2016-07-10 18:38:30 --> Email Class Initialized
INFO - 2016-07-10 18:38:30 --> Controller Class Initialized
INFO - 2016-07-10 18:38:30 --> Model Class Initialized
INFO - 2016-07-10 18:38:30 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:38:30 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:38:30 --> File loaded: D:\wamp\www\pnc-library\application\views\users/index.php
INFO - 2016-07-10 18:38:30 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:38:30 --> Final output sent to browser
DEBUG - 2016-07-10 18:38:30 --> Total execution time: 0.2215
INFO - 2016-07-10 18:38:33 --> Config Class Initialized
INFO - 2016-07-10 18:38:33 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:38:33 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:38:33 --> Utf8 Class Initialized
INFO - 2016-07-10 18:38:33 --> URI Class Initialized
INFO - 2016-07-10 18:38:33 --> Router Class Initialized
INFO - 2016-07-10 18:38:33 --> Output Class Initialized
INFO - 2016-07-10 18:38:33 --> Security Class Initialized
DEBUG - 2016-07-10 18:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:38:33 --> Input Class Initialized
INFO - 2016-07-10 18:38:33 --> Language Class Initialized
INFO - 2016-07-10 18:38:33 --> Loader Class Initialized
INFO - 2016-07-10 18:38:33 --> Helper loaded: url_helper
INFO - 2016-07-10 18:38:33 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:38:33 --> Helper loaded: html_helper
INFO - 2016-07-10 18:38:33 --> Helper loaded: form_helper
INFO - 2016-07-10 18:38:33 --> Helper loaded: file_helper
INFO - 2016-07-10 18:38:33 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:38:33 --> Database Driver Class Initialized
INFO - 2016-07-10 18:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:38:33 --> Form Validation Class Initialized
INFO - 2016-07-10 18:38:33 --> Email Class Initialized
INFO - 2016-07-10 18:38:33 --> Controller Class Initialized
INFO - 2016-07-10 18:38:33 --> Model Class Initialized
DEBUG - 2016-07-10 18:38:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:38:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:38:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-10 18:38:33 --> File loaded: D:\wamp\www\pnc-library\application\views\users/edit.php
INFO - 2016-07-10 18:38:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:38:33 --> Final output sent to browser
DEBUG - 2016-07-10 18:38:33 --> Total execution time: 0.2439
INFO - 2016-07-10 18:38:42 --> Config Class Initialized
INFO - 2016-07-10 18:38:42 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:38:42 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:38:42 --> Utf8 Class Initialized
INFO - 2016-07-10 18:38:42 --> URI Class Initialized
INFO - 2016-07-10 18:38:42 --> Router Class Initialized
INFO - 2016-07-10 18:38:42 --> Output Class Initialized
INFO - 2016-07-10 18:38:42 --> Security Class Initialized
DEBUG - 2016-07-10 18:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:38:42 --> Input Class Initialized
INFO - 2016-07-10 18:38:42 --> Language Class Initialized
INFO - 2016-07-10 18:38:42 --> Loader Class Initialized
INFO - 2016-07-10 18:38:42 --> Helper loaded: url_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: html_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: form_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: file_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:38:42 --> Database Driver Class Initialized
INFO - 2016-07-10 18:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:38:42 --> Form Validation Class Initialized
INFO - 2016-07-10 18:38:42 --> Email Class Initialized
INFO - 2016-07-10 18:38:42 --> Controller Class Initialized
INFO - 2016-07-10 18:38:42 --> Model Class Initialized
INFO - 2016-07-10 18:38:42 --> Config Class Initialized
INFO - 2016-07-10 18:38:42 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:38:42 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:38:42 --> Utf8 Class Initialized
INFO - 2016-07-10 18:38:42 --> URI Class Initialized
INFO - 2016-07-10 18:38:42 --> Router Class Initialized
INFO - 2016-07-10 18:38:42 --> Output Class Initialized
INFO - 2016-07-10 18:38:42 --> Security Class Initialized
DEBUG - 2016-07-10 18:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:38:42 --> Input Class Initialized
INFO - 2016-07-10 18:38:42 --> Language Class Initialized
INFO - 2016-07-10 18:38:42 --> Loader Class Initialized
INFO - 2016-07-10 18:38:42 --> Helper loaded: url_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: html_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: form_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: file_helper
INFO - 2016-07-10 18:38:42 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:38:43 --> Database Driver Class Initialized
INFO - 2016-07-10 18:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:38:43 --> Form Validation Class Initialized
INFO - 2016-07-10 18:38:43 --> Email Class Initialized
INFO - 2016-07-10 18:38:43 --> Controller Class Initialized
INFO - 2016-07-10 18:38:43 --> Model Class Initialized
DEBUG - 2016-07-10 18:38:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:38:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-10 18:38:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:38:43 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-10 18:38:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:38:43 --> Final output sent to browser
DEBUG - 2016-07-10 18:38:43 --> Total execution time: 0.2474
INFO - 2016-07-10 18:41:01 --> Config Class Initialized
INFO - 2016-07-10 18:41:01 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:41:01 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:41:01 --> Utf8 Class Initialized
INFO - 2016-07-10 18:41:01 --> URI Class Initialized
INFO - 2016-07-10 18:41:01 --> Router Class Initialized
INFO - 2016-07-10 18:41:01 --> Output Class Initialized
INFO - 2016-07-10 18:41:01 --> Security Class Initialized
DEBUG - 2016-07-10 18:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:41:01 --> Input Class Initialized
INFO - 2016-07-10 18:41:01 --> Language Class Initialized
INFO - 2016-07-10 18:41:01 --> Loader Class Initialized
INFO - 2016-07-10 18:41:01 --> Helper loaded: url_helper
INFO - 2016-07-10 18:41:01 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:41:01 --> Helper loaded: html_helper
INFO - 2016-07-10 18:41:01 --> Helper loaded: form_helper
INFO - 2016-07-10 18:41:01 --> Helper loaded: file_helper
INFO - 2016-07-10 18:41:01 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:41:01 --> Database Driver Class Initialized
INFO - 2016-07-10 18:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:41:01 --> Form Validation Class Initialized
INFO - 2016-07-10 18:41:01 --> Email Class Initialized
INFO - 2016-07-10 18:41:01 --> Controller Class Initialized
INFO - 2016-07-10 18:41:01 --> Model Class Initialized
INFO - 2016-07-10 18:46:46 --> Config Class Initialized
INFO - 2016-07-10 18:46:46 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:46:46 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:46:46 --> Utf8 Class Initialized
INFO - 2016-07-10 18:46:46 --> URI Class Initialized
INFO - 2016-07-10 18:46:46 --> Router Class Initialized
INFO - 2016-07-10 18:46:46 --> Output Class Initialized
INFO - 2016-07-10 18:46:46 --> Security Class Initialized
DEBUG - 2016-07-10 18:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:46:46 --> Input Class Initialized
INFO - 2016-07-10 18:46:46 --> Language Class Initialized
INFO - 2016-07-10 18:46:46 --> Loader Class Initialized
INFO - 2016-07-10 18:46:47 --> Helper loaded: url_helper
INFO - 2016-07-10 18:46:47 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:46:47 --> Helper loaded: html_helper
INFO - 2016-07-10 18:46:47 --> Helper loaded: form_helper
INFO - 2016-07-10 18:46:47 --> Helper loaded: file_helper
INFO - 2016-07-10 18:46:47 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:46:47 --> Database Driver Class Initialized
INFO - 2016-07-10 18:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:46:47 --> Form Validation Class Initialized
INFO - 2016-07-10 18:46:47 --> Email Class Initialized
INFO - 2016-07-10 18:46:47 --> Controller Class Initialized
INFO - 2016-07-10 18:46:47 --> Model Class Initialized
DEBUG - 2016-07-10 18:46:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:46:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-10 18:46:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:46:47 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-10 18:46:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:46:47 --> Final output sent to browser
DEBUG - 2016-07-10 18:46:47 --> Total execution time: 0.2497
INFO - 2016-07-10 18:48:46 --> Config Class Initialized
INFO - 2016-07-10 18:48:46 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:48:46 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:48:46 --> Utf8 Class Initialized
INFO - 2016-07-10 18:48:46 --> URI Class Initialized
INFO - 2016-07-10 18:48:46 --> Router Class Initialized
INFO - 2016-07-10 18:48:46 --> Output Class Initialized
INFO - 2016-07-10 18:48:46 --> Security Class Initialized
DEBUG - 2016-07-10 18:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:48:46 --> Input Class Initialized
INFO - 2016-07-10 18:48:46 --> Language Class Initialized
INFO - 2016-07-10 18:48:46 --> Loader Class Initialized
INFO - 2016-07-10 18:48:46 --> Helper loaded: url_helper
INFO - 2016-07-10 18:48:46 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:48:46 --> Helper loaded: html_helper
INFO - 2016-07-10 18:48:46 --> Helper loaded: form_helper
INFO - 2016-07-10 18:48:46 --> Helper loaded: file_helper
INFO - 2016-07-10 18:48:46 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:48:46 --> Database Driver Class Initialized
INFO - 2016-07-10 18:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:48:46 --> Form Validation Class Initialized
INFO - 2016-07-10 18:48:46 --> Email Class Initialized
INFO - 2016-07-10 18:48:46 --> Controller Class Initialized
INFO - 2016-07-10 18:48:46 --> Model Class Initialized
INFO - 2016-07-10 18:48:46 --> Register method called
DEBUG - 2016-07-10 18:48:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:48:46 --> Form not validated
INFO - 2016-07-10 18:48:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:48:46 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/register.php
INFO - 2016-07-10 18:48:46 --> Final output sent to browser
DEBUG - 2016-07-10 18:48:46 --> Total execution time: 0.2227
INFO - 2016-07-10 18:48:51 --> Config Class Initialized
INFO - 2016-07-10 18:48:51 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:48:51 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:48:51 --> Utf8 Class Initialized
INFO - 2016-07-10 18:48:51 --> URI Class Initialized
DEBUG - 2016-07-10 18:48:51 --> No URI present. Default controller set.
INFO - 2016-07-10 18:48:51 --> Router Class Initialized
INFO - 2016-07-10 18:48:51 --> Output Class Initialized
INFO - 2016-07-10 18:48:51 --> Security Class Initialized
DEBUG - 2016-07-10 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:48:51 --> Input Class Initialized
INFO - 2016-07-10 18:48:51 --> Language Class Initialized
INFO - 2016-07-10 18:48:51 --> Loader Class Initialized
INFO - 2016-07-10 18:48:51 --> Helper loaded: url_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: html_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: form_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: file_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:48:51 --> Database Driver Class Initialized
INFO - 2016-07-10 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:48:51 --> Form Validation Class Initialized
INFO - 2016-07-10 18:48:51 --> Email Class Initialized
INFO - 2016-07-10 18:48:51 --> Controller Class Initialized
INFO - 2016-07-10 18:48:51 --> Config Class Initialized
INFO - 2016-07-10 18:48:51 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:48:51 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:48:51 --> Utf8 Class Initialized
INFO - 2016-07-10 18:48:51 --> URI Class Initialized
INFO - 2016-07-10 18:48:51 --> Router Class Initialized
INFO - 2016-07-10 18:48:51 --> Output Class Initialized
INFO - 2016-07-10 18:48:51 --> Security Class Initialized
DEBUG - 2016-07-10 18:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:48:51 --> Input Class Initialized
INFO - 2016-07-10 18:48:51 --> Language Class Initialized
INFO - 2016-07-10 18:48:51 --> Loader Class Initialized
INFO - 2016-07-10 18:48:51 --> Helper loaded: url_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: html_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: form_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: file_helper
INFO - 2016-07-10 18:48:51 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:48:51 --> Database Driver Class Initialized
INFO - 2016-07-10 18:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:48:51 --> Form Validation Class Initialized
INFO - 2016-07-10 18:48:51 --> Email Class Initialized
INFO - 2016-07-10 18:48:51 --> Controller Class Initialized
INFO - 2016-07-10 18:48:51 --> Model Class Initialized
DEBUG - 2016-07-10 18:48:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:48:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-10 18:48:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:48:51 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-10 18:48:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:48:51 --> Final output sent to browser
DEBUG - 2016-07-10 18:48:51 --> Total execution time: 0.2317
INFO - 2016-07-10 18:49:59 --> Config Class Initialized
INFO - 2016-07-10 18:49:59 --> Hooks Class Initialized
DEBUG - 2016-07-10 18:49:59 --> UTF-8 Support Enabled
INFO - 2016-07-10 18:49:59 --> Utf8 Class Initialized
INFO - 2016-07-10 18:49:59 --> URI Class Initialized
INFO - 2016-07-10 18:49:59 --> Router Class Initialized
INFO - 2016-07-10 18:49:59 --> Output Class Initialized
INFO - 2016-07-10 18:49:59 --> Security Class Initialized
DEBUG - 2016-07-10 18:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 18:49:59 --> Input Class Initialized
INFO - 2016-07-10 18:49:59 --> Language Class Initialized
INFO - 2016-07-10 18:49:59 --> Loader Class Initialized
INFO - 2016-07-10 18:49:59 --> Helper loaded: url_helper
INFO - 2016-07-10 18:49:59 --> Helper loaded: utils_helper
INFO - 2016-07-10 18:49:59 --> Helper loaded: html_helper
INFO - 2016-07-10 18:49:59 --> Helper loaded: form_helper
INFO - 2016-07-10 18:49:59 --> Helper loaded: file_helper
INFO - 2016-07-10 18:49:59 --> Helper loaded: myemail_helper
INFO - 2016-07-10 18:49:59 --> Database Driver Class Initialized
INFO - 2016-07-10 18:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 18:49:59 --> Form Validation Class Initialized
INFO - 2016-07-10 18:49:59 --> Email Class Initialized
INFO - 2016-07-10 18:49:59 --> Controller Class Initialized
INFO - 2016-07-10 18:49:59 --> Model Class Initialized
DEBUG - 2016-07-10 18:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 18:49:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-10 18:49:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-10 18:49:59 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-10 18:49:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-10 18:49:59 --> Final output sent to browser
DEBUG - 2016-07-10 18:49:59 --> Total execution time: 0.2935
INFO - 2016-07-10 19:33:16 --> Config Class Initialized
INFO - 2016-07-10 19:33:16 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:33:16 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:33:16 --> Utf8 Class Initialized
INFO - 2016-07-10 19:33:16 --> URI Class Initialized
INFO - 2016-07-10 19:33:16 --> Router Class Initialized
INFO - 2016-07-10 19:33:16 --> Output Class Initialized
INFO - 2016-07-10 19:33:16 --> Security Class Initialized
DEBUG - 2016-07-10 19:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:33:16 --> Input Class Initialized
INFO - 2016-07-10 19:33:16 --> Language Class Initialized
INFO - 2016-07-10 19:33:16 --> Loader Class Initialized
INFO - 2016-07-10 19:33:16 --> Helper loaded: url_helper
INFO - 2016-07-10 19:33:16 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:33:16 --> Helper loaded: html_helper
INFO - 2016-07-10 19:33:16 --> Helper loaded: form_helper
INFO - 2016-07-10 19:33:16 --> Helper loaded: file_helper
INFO - 2016-07-10 19:33:16 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:33:16 --> Database Driver Class Initialized
INFO - 2016-07-10 19:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:33:16 --> Form Validation Class Initialized
INFO - 2016-07-10 19:33:16 --> Email Class Initialized
INFO - 2016-07-10 19:33:16 --> Controller Class Initialized
INFO - 2016-07-10 19:33:16 --> Model Class Initialized
INFO - 2016-07-10 19:40:09 --> Config Class Initialized
INFO - 2016-07-10 19:40:09 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:09 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:09 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:09 --> URI Class Initialized
INFO - 2016-07-10 19:40:09 --> Router Class Initialized
INFO - 2016-07-10 19:40:09 --> Output Class Initialized
INFO - 2016-07-10 19:40:09 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:09 --> Input Class Initialized
INFO - 2016-07-10 19:40:09 --> Language Class Initialized
INFO - 2016-07-10 19:40:09 --> Loader Class Initialized
INFO - 2016-07-10 19:40:09 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:09 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:09 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:09 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:09 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:09 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:09 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:09 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:09 --> Email Class Initialized
INFO - 2016-07-10 19:40:09 --> Controller Class Initialized
INFO - 2016-07-10 19:40:09 --> Model Class Initialized
DEBUG - 2016-07-10 19:40:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:40:09 --> Final output sent to browser
DEBUG - 2016-07-10 19:40:09 --> Total execution time: 0.2959
INFO - 2016-07-10 19:40:11 --> Config Class Initialized
INFO - 2016-07-10 19:40:11 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:11 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:11 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:11 --> URI Class Initialized
INFO - 2016-07-10 19:40:11 --> Router Class Initialized
INFO - 2016-07-10 19:40:11 --> Output Class Initialized
INFO - 2016-07-10 19:40:11 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:11 --> Input Class Initialized
INFO - 2016-07-10 19:40:11 --> Language Class Initialized
INFO - 2016-07-10 19:40:11 --> Loader Class Initialized
INFO - 2016-07-10 19:40:11 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:11 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:11 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:11 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:11 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:11 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:11 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:11 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:11 --> Email Class Initialized
INFO - 2016-07-10 19:40:11 --> Controller Class Initialized
INFO - 2016-07-10 19:40:11 --> Model Class Initialized
INFO - 2016-07-10 19:40:22 --> Config Class Initialized
INFO - 2016-07-10 19:40:22 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:22 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:22 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:22 --> URI Class Initialized
INFO - 2016-07-10 19:40:22 --> Router Class Initialized
INFO - 2016-07-10 19:40:22 --> Output Class Initialized
INFO - 2016-07-10 19:40:22 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:22 --> Input Class Initialized
INFO - 2016-07-10 19:40:22 --> Language Class Initialized
INFO - 2016-07-10 19:40:22 --> Loader Class Initialized
INFO - 2016-07-10 19:40:22 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:22 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:22 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:22 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:22 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:22 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:22 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:22 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:22 --> Email Class Initialized
INFO - 2016-07-10 19:40:22 --> Controller Class Initialized
INFO - 2016-07-10 19:40:22 --> Model Class Initialized
DEBUG - 2016-07-10 19:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:40:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:40:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:40:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:40:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:40:22 --> Final output sent to browser
DEBUG - 2016-07-10 19:40:22 --> Total execution time: 0.2354
INFO - 2016-07-10 19:40:25 --> Config Class Initialized
INFO - 2016-07-10 19:40:25 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:25 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:25 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:25 --> URI Class Initialized
INFO - 2016-07-10 19:40:25 --> Router Class Initialized
INFO - 2016-07-10 19:40:25 --> Output Class Initialized
INFO - 2016-07-10 19:40:25 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:25 --> Input Class Initialized
INFO - 2016-07-10 19:40:25 --> Language Class Initialized
INFO - 2016-07-10 19:40:25 --> Loader Class Initialized
INFO - 2016-07-10 19:40:25 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:25 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:25 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:25 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:25 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:25 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:25 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:25 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:25 --> Email Class Initialized
INFO - 2016-07-10 19:40:25 --> Controller Class Initialized
INFO - 2016-07-10 19:40:25 --> Model Class Initialized
DEBUG - 2016-07-10 19:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:40:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:40:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:40:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:40:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:40:25 --> Final output sent to browser
DEBUG - 2016-07-10 19:40:25 --> Total execution time: 0.2452
INFO - 2016-07-10 19:40:28 --> Config Class Initialized
INFO - 2016-07-10 19:40:28 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:28 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:28 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:28 --> URI Class Initialized
INFO - 2016-07-10 19:40:28 --> Router Class Initialized
INFO - 2016-07-10 19:40:28 --> Output Class Initialized
INFO - 2016-07-10 19:40:28 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:28 --> Input Class Initialized
INFO - 2016-07-10 19:40:28 --> Language Class Initialized
INFO - 2016-07-10 19:40:28 --> Loader Class Initialized
INFO - 2016-07-10 19:40:28 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:28 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:28 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:28 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:28 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:28 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:28 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:28 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:28 --> Email Class Initialized
INFO - 2016-07-10 19:40:28 --> Controller Class Initialized
INFO - 2016-07-10 19:40:28 --> Model Class Initialized
DEBUG - 2016-07-10 19:40:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:40:28 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-10 19:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:40:28 --> Final output sent to browser
DEBUG - 2016-07-10 19:40:28 --> Total execution time: 0.2496
INFO - 2016-07-10 19:40:30 --> Config Class Initialized
INFO - 2016-07-10 19:40:30 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:40:30 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:40:30 --> Utf8 Class Initialized
INFO - 2016-07-10 19:40:30 --> URI Class Initialized
INFO - 2016-07-10 19:40:30 --> Router Class Initialized
INFO - 2016-07-10 19:40:30 --> Output Class Initialized
INFO - 2016-07-10 19:40:30 --> Security Class Initialized
DEBUG - 2016-07-10 19:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:40:30 --> Input Class Initialized
INFO - 2016-07-10 19:40:30 --> Language Class Initialized
INFO - 2016-07-10 19:40:30 --> Loader Class Initialized
INFO - 2016-07-10 19:40:30 --> Helper loaded: url_helper
INFO - 2016-07-10 19:40:30 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:40:30 --> Helper loaded: html_helper
INFO - 2016-07-10 19:40:30 --> Helper loaded: form_helper
INFO - 2016-07-10 19:40:30 --> Helper loaded: file_helper
INFO - 2016-07-10 19:40:30 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:40:30 --> Database Driver Class Initialized
INFO - 2016-07-10 19:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:40:30 --> Form Validation Class Initialized
INFO - 2016-07-10 19:40:30 --> Email Class Initialized
INFO - 2016-07-10 19:40:30 --> Controller Class Initialized
INFO - 2016-07-10 19:40:30 --> Model Class Initialized
INFO - 2016-07-10 19:46:04 --> Config Class Initialized
INFO - 2016-07-10 19:46:04 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:46:04 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:46:04 --> Utf8 Class Initialized
INFO - 2016-07-10 19:46:04 --> URI Class Initialized
DEBUG - 2016-07-10 19:46:04 --> No URI present. Default controller set.
INFO - 2016-07-10 19:46:04 --> Router Class Initialized
INFO - 2016-07-10 19:46:04 --> Output Class Initialized
INFO - 2016-07-10 19:46:04 --> Security Class Initialized
DEBUG - 2016-07-10 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:46:04 --> Input Class Initialized
INFO - 2016-07-10 19:46:04 --> Language Class Initialized
INFO - 2016-07-10 19:46:04 --> Loader Class Initialized
INFO - 2016-07-10 19:46:04 --> Helper loaded: url_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: html_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: form_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: file_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:46:04 --> Database Driver Class Initialized
INFO - 2016-07-10 19:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:46:04 --> Form Validation Class Initialized
INFO - 2016-07-10 19:46:04 --> Email Class Initialized
INFO - 2016-07-10 19:46:04 --> Controller Class Initialized
INFO - 2016-07-10 19:46:04 --> Config Class Initialized
INFO - 2016-07-10 19:46:04 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:46:04 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:46:04 --> Utf8 Class Initialized
INFO - 2016-07-10 19:46:04 --> URI Class Initialized
INFO - 2016-07-10 19:46:04 --> Router Class Initialized
INFO - 2016-07-10 19:46:04 --> Output Class Initialized
INFO - 2016-07-10 19:46:04 --> Security Class Initialized
DEBUG - 2016-07-10 19:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:46:04 --> Input Class Initialized
INFO - 2016-07-10 19:46:04 --> Language Class Initialized
INFO - 2016-07-10 19:46:04 --> Loader Class Initialized
INFO - 2016-07-10 19:46:04 --> Helper loaded: url_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: html_helper
INFO - 2016-07-10 19:46:04 --> Helper loaded: form_helper
INFO - 2016-07-10 19:46:05 --> Helper loaded: file_helper
INFO - 2016-07-10 19:46:05 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:46:05 --> Database Driver Class Initialized
INFO - 2016-07-10 19:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:46:05 --> Form Validation Class Initialized
INFO - 2016-07-10 19:46:05 --> Email Class Initialized
INFO - 2016-07-10 19:46:05 --> Controller Class Initialized
INFO - 2016-07-10 19:46:05 --> Model Class Initialized
DEBUG - 2016-07-10 19:46:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:46:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:46:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:46:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:46:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:46:05 --> Final output sent to browser
DEBUG - 2016-07-10 19:46:05 --> Total execution time: 0.2860
INFO - 2016-07-10 19:46:08 --> Config Class Initialized
INFO - 2016-07-10 19:46:08 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:46:08 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:46:08 --> Utf8 Class Initialized
INFO - 2016-07-10 19:46:08 --> URI Class Initialized
INFO - 2016-07-10 19:46:08 --> Router Class Initialized
INFO - 2016-07-10 19:46:08 --> Output Class Initialized
INFO - 2016-07-10 19:46:08 --> Security Class Initialized
DEBUG - 2016-07-10 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:46:08 --> Input Class Initialized
INFO - 2016-07-10 19:46:08 --> Language Class Initialized
INFO - 2016-07-10 19:46:08 --> Loader Class Initialized
INFO - 2016-07-10 19:46:08 --> Helper loaded: url_helper
INFO - 2016-07-10 19:46:08 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:46:08 --> Helper loaded: html_helper
INFO - 2016-07-10 19:46:08 --> Helper loaded: form_helper
INFO - 2016-07-10 19:46:08 --> Helper loaded: file_helper
INFO - 2016-07-10 19:46:08 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:46:08 --> Database Driver Class Initialized
INFO - 2016-07-10 19:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:46:08 --> Form Validation Class Initialized
INFO - 2016-07-10 19:46:08 --> Email Class Initialized
INFO - 2016-07-10 19:46:08 --> Controller Class Initialized
INFO - 2016-07-10 19:46:08 --> Model Class Initialized
INFO - 2016-07-10 19:46:59 --> Config Class Initialized
INFO - 2016-07-10 19:46:59 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:46:59 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:46:59 --> Utf8 Class Initialized
INFO - 2016-07-10 19:46:59 --> URI Class Initialized
INFO - 2016-07-10 19:46:59 --> Router Class Initialized
INFO - 2016-07-10 19:46:59 --> Output Class Initialized
INFO - 2016-07-10 19:46:59 --> Security Class Initialized
DEBUG - 2016-07-10 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:46:59 --> Input Class Initialized
INFO - 2016-07-10 19:46:59 --> Language Class Initialized
INFO - 2016-07-10 19:46:59 --> Loader Class Initialized
INFO - 2016-07-10 19:46:59 --> Helper loaded: url_helper
INFO - 2016-07-10 19:46:59 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:46:59 --> Helper loaded: html_helper
INFO - 2016-07-10 19:46:59 --> Helper loaded: form_helper
INFO - 2016-07-10 19:46:59 --> Helper loaded: file_helper
INFO - 2016-07-10 19:46:59 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:46:59 --> Database Driver Class Initialized
INFO - 2016-07-10 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:46:59 --> Form Validation Class Initialized
INFO - 2016-07-10 19:46:59 --> Email Class Initialized
INFO - 2016-07-10 19:46:59 --> Controller Class Initialized
INFO - 2016-07-10 19:46:59 --> Model Class Initialized
DEBUG - 2016-07-10 19:46:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:46:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:46:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:46:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:46:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:46:59 --> Final output sent to browser
DEBUG - 2016-07-10 19:46:59 --> Total execution time: 0.3045
INFO - 2016-07-10 19:47:01 --> Config Class Initialized
INFO - 2016-07-10 19:47:01 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:47:01 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:47:01 --> Utf8 Class Initialized
INFO - 2016-07-10 19:47:01 --> URI Class Initialized
INFO - 2016-07-10 19:47:01 --> Router Class Initialized
INFO - 2016-07-10 19:47:01 --> Output Class Initialized
INFO - 2016-07-10 19:47:01 --> Security Class Initialized
DEBUG - 2016-07-10 19:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:47:01 --> Input Class Initialized
INFO - 2016-07-10 19:47:01 --> Language Class Initialized
INFO - 2016-07-10 19:47:01 --> Loader Class Initialized
INFO - 2016-07-10 19:47:01 --> Helper loaded: url_helper
INFO - 2016-07-10 19:47:01 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:47:01 --> Helper loaded: html_helper
INFO - 2016-07-10 19:47:01 --> Helper loaded: form_helper
INFO - 2016-07-10 19:47:01 --> Helper loaded: file_helper
INFO - 2016-07-10 19:47:01 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:47:01 --> Database Driver Class Initialized
INFO - 2016-07-10 19:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:47:01 --> Form Validation Class Initialized
INFO - 2016-07-10 19:47:01 --> Email Class Initialized
INFO - 2016-07-10 19:47:01 --> Controller Class Initialized
INFO - 2016-07-10 19:47:01 --> Model Class Initialized
DEBUG - 2016-07-10 19:47:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:47:01 --> Final output sent to browser
DEBUG - 2016-07-10 19:47:01 --> Total execution time: 0.2535
INFO - 2016-07-10 19:47:02 --> Config Class Initialized
INFO - 2016-07-10 19:47:02 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:47:03 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:47:03 --> Utf8 Class Initialized
INFO - 2016-07-10 19:47:03 --> URI Class Initialized
INFO - 2016-07-10 19:47:03 --> Router Class Initialized
INFO - 2016-07-10 19:47:03 --> Output Class Initialized
INFO - 2016-07-10 19:47:03 --> Security Class Initialized
DEBUG - 2016-07-10 19:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:47:03 --> Input Class Initialized
INFO - 2016-07-10 19:47:03 --> Language Class Initialized
INFO - 2016-07-10 19:47:03 --> Loader Class Initialized
INFO - 2016-07-10 19:47:03 --> Helper loaded: url_helper
INFO - 2016-07-10 19:47:03 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:47:03 --> Helper loaded: html_helper
INFO - 2016-07-10 19:47:03 --> Helper loaded: form_helper
INFO - 2016-07-10 19:47:03 --> Helper loaded: file_helper
INFO - 2016-07-10 19:47:03 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:47:03 --> Database Driver Class Initialized
INFO - 2016-07-10 19:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:47:03 --> Form Validation Class Initialized
INFO - 2016-07-10 19:47:03 --> Email Class Initialized
INFO - 2016-07-10 19:47:03 --> Controller Class Initialized
INFO - 2016-07-10 19:47:03 --> Model Class Initialized
INFO - 2016-07-10 19:51:45 --> Config Class Initialized
INFO - 2016-07-10 19:51:45 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:51:45 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:51:45 --> Utf8 Class Initialized
INFO - 2016-07-10 19:51:45 --> URI Class Initialized
INFO - 2016-07-10 19:51:45 --> Router Class Initialized
INFO - 2016-07-10 19:51:45 --> Output Class Initialized
INFO - 2016-07-10 19:51:45 --> Security Class Initialized
DEBUG - 2016-07-10 19:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:51:45 --> Input Class Initialized
INFO - 2016-07-10 19:51:45 --> Language Class Initialized
INFO - 2016-07-10 19:51:45 --> Loader Class Initialized
INFO - 2016-07-10 19:51:45 --> Helper loaded: url_helper
INFO - 2016-07-10 19:51:45 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:51:45 --> Helper loaded: html_helper
INFO - 2016-07-10 19:51:45 --> Helper loaded: form_helper
INFO - 2016-07-10 19:51:45 --> Helper loaded: file_helper
INFO - 2016-07-10 19:51:45 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:51:45 --> Database Driver Class Initialized
INFO - 2016-07-10 19:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:51:45 --> Form Validation Class Initialized
INFO - 2016-07-10 19:51:45 --> Email Class Initialized
INFO - 2016-07-10 19:51:45 --> Controller Class Initialized
INFO - 2016-07-10 19:51:45 --> Model Class Initialized
DEBUG - 2016-07-10 19:51:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:51:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:51:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:51:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:51:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:51:45 --> Final output sent to browser
DEBUG - 2016-07-10 19:51:45 --> Total execution time: 0.2635
INFO - 2016-07-10 19:51:47 --> Config Class Initialized
INFO - 2016-07-10 19:51:47 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:51:47 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:51:47 --> Utf8 Class Initialized
INFO - 2016-07-10 19:51:47 --> URI Class Initialized
INFO - 2016-07-10 19:51:47 --> Router Class Initialized
INFO - 2016-07-10 19:51:47 --> Output Class Initialized
INFO - 2016-07-10 19:51:47 --> Security Class Initialized
DEBUG - 2016-07-10 19:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:51:47 --> Input Class Initialized
INFO - 2016-07-10 19:51:47 --> Language Class Initialized
INFO - 2016-07-10 19:51:47 --> Loader Class Initialized
INFO - 2016-07-10 19:51:47 --> Helper loaded: url_helper
INFO - 2016-07-10 19:51:47 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:51:47 --> Helper loaded: html_helper
INFO - 2016-07-10 19:51:47 --> Helper loaded: form_helper
INFO - 2016-07-10 19:51:47 --> Helper loaded: file_helper
INFO - 2016-07-10 19:51:47 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:51:47 --> Database Driver Class Initialized
INFO - 2016-07-10 19:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:51:47 --> Form Validation Class Initialized
INFO - 2016-07-10 19:51:47 --> Email Class Initialized
INFO - 2016-07-10 19:51:47 --> Controller Class Initialized
INFO - 2016-07-10 19:51:47 --> Model Class Initialized
DEBUG - 2016-07-10 19:51:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:51:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:51:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:51:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:51:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:51:47 --> Final output sent to browser
DEBUG - 2016-07-10 19:51:47 --> Total execution time: 0.2714
INFO - 2016-07-10 19:51:51 --> Config Class Initialized
INFO - 2016-07-10 19:51:51 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:51:51 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:51:51 --> Utf8 Class Initialized
INFO - 2016-07-10 19:51:51 --> URI Class Initialized
INFO - 2016-07-10 19:51:51 --> Router Class Initialized
INFO - 2016-07-10 19:51:51 --> Output Class Initialized
INFO - 2016-07-10 19:51:51 --> Security Class Initialized
DEBUG - 2016-07-10 19:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:51:51 --> Input Class Initialized
INFO - 2016-07-10 19:51:51 --> Language Class Initialized
INFO - 2016-07-10 19:51:51 --> Loader Class Initialized
INFO - 2016-07-10 19:51:51 --> Helper loaded: url_helper
INFO - 2016-07-10 19:51:51 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:51:51 --> Helper loaded: html_helper
INFO - 2016-07-10 19:51:51 --> Helper loaded: form_helper
INFO - 2016-07-10 19:51:51 --> Helper loaded: file_helper
INFO - 2016-07-10 19:51:51 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:51:51 --> Database Driver Class Initialized
INFO - 2016-07-10 19:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:51:51 --> Form Validation Class Initialized
INFO - 2016-07-10 19:51:51 --> Email Class Initialized
INFO - 2016-07-10 19:51:51 --> Controller Class Initialized
INFO - 2016-07-10 19:51:51 --> Model Class Initialized
DEBUG - 2016-07-10 19:51:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:51:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-10 19:51:51 --> Config Class Initialized
INFO - 2016-07-10 19:51:51 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:51:51 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:51:51 --> Utf8 Class Initialized
INFO - 2016-07-10 19:51:51 --> URI Class Initialized
DEBUG - 2016-07-10 19:51:52 --> No URI present. Default controller set.
INFO - 2016-07-10 19:51:52 --> Router Class Initialized
INFO - 2016-07-10 19:51:52 --> Output Class Initialized
INFO - 2016-07-10 19:51:52 --> Security Class Initialized
DEBUG - 2016-07-10 19:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:51:52 --> Input Class Initialized
INFO - 2016-07-10 19:51:52 --> Language Class Initialized
INFO - 2016-07-10 19:51:52 --> Loader Class Initialized
INFO - 2016-07-10 19:51:52 --> Helper loaded: url_helper
INFO - 2016-07-10 19:51:52 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:51:52 --> Helper loaded: html_helper
INFO - 2016-07-10 19:51:52 --> Helper loaded: form_helper
INFO - 2016-07-10 19:51:52 --> Helper loaded: file_helper
INFO - 2016-07-10 19:51:52 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:51:52 --> Database Driver Class Initialized
INFO - 2016-07-10 19:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:51:52 --> Form Validation Class Initialized
INFO - 2016-07-10 19:51:52 --> Email Class Initialized
INFO - 2016-07-10 19:51:52 --> Controller Class Initialized
INFO - 2016-07-10 19:51:52 --> Model Class Initialized
INFO - 2016-07-10 19:51:52 --> Model Class Initialized
INFO - 2016-07-10 19:51:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:51:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-10 19:51:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-10 19:51:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:51:52 --> Final output sent to browser
DEBUG - 2016-07-10 19:51:52 --> Total execution time: 0.2672
INFO - 2016-07-10 19:52:02 --> Config Class Initialized
INFO - 2016-07-10 19:52:02 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:52:02 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:52:02 --> Utf8 Class Initialized
INFO - 2016-07-10 19:52:02 --> URI Class Initialized
INFO - 2016-07-10 19:52:02 --> Router Class Initialized
INFO - 2016-07-10 19:52:02 --> Output Class Initialized
INFO - 2016-07-10 19:52:02 --> Security Class Initialized
DEBUG - 2016-07-10 19:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:52:02 --> Input Class Initialized
INFO - 2016-07-10 19:52:02 --> Language Class Initialized
INFO - 2016-07-10 19:52:02 --> Loader Class Initialized
INFO - 2016-07-10 19:52:02 --> Helper loaded: url_helper
INFO - 2016-07-10 19:52:02 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:52:02 --> Helper loaded: html_helper
INFO - 2016-07-10 19:52:02 --> Helper loaded: form_helper
INFO - 2016-07-10 19:52:02 --> Helper loaded: file_helper
INFO - 2016-07-10 19:52:02 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:52:02 --> Database Driver Class Initialized
INFO - 2016-07-10 19:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:52:03 --> Form Validation Class Initialized
INFO - 2016-07-10 19:52:03 --> Email Class Initialized
INFO - 2016-07-10 19:52:03 --> Controller Class Initialized
INFO - 2016-07-10 19:52:03 --> Model Class Initialized
INFO - 2016-07-10 19:52:03 --> Config Class Initialized
INFO - 2016-07-10 19:52:03 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:52:03 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:52:03 --> Utf8 Class Initialized
INFO - 2016-07-10 19:52:03 --> URI Class Initialized
INFO - 2016-07-10 19:52:03 --> Router Class Initialized
INFO - 2016-07-10 19:52:03 --> Output Class Initialized
INFO - 2016-07-10 19:52:03 --> Security Class Initialized
DEBUG - 2016-07-10 19:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:52:03 --> Input Class Initialized
INFO - 2016-07-10 19:52:03 --> Language Class Initialized
INFO - 2016-07-10 19:52:03 --> Loader Class Initialized
INFO - 2016-07-10 19:52:03 --> Helper loaded: url_helper
INFO - 2016-07-10 19:52:03 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:52:03 --> Helper loaded: html_helper
INFO - 2016-07-10 19:52:03 --> Helper loaded: form_helper
INFO - 2016-07-10 19:52:03 --> Helper loaded: file_helper
INFO - 2016-07-10 19:52:03 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:52:03 --> Database Driver Class Initialized
INFO - 2016-07-10 19:52:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:52:03 --> Form Validation Class Initialized
INFO - 2016-07-10 19:52:03 --> Email Class Initialized
INFO - 2016-07-10 19:52:03 --> Controller Class Initialized
INFO - 2016-07-10 19:52:03 --> Model Class Initialized
DEBUG - 2016-07-10 19:52:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:52:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:52:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:52:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:52:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:52:03 --> Final output sent to browser
DEBUG - 2016-07-10 19:52:03 --> Total execution time: 0.2592
INFO - 2016-07-10 19:52:04 --> Config Class Initialized
INFO - 2016-07-10 19:52:04 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:52:04 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:52:04 --> Utf8 Class Initialized
INFO - 2016-07-10 19:52:04 --> URI Class Initialized
INFO - 2016-07-10 19:52:04 --> Router Class Initialized
INFO - 2016-07-10 19:52:04 --> Output Class Initialized
INFO - 2016-07-10 19:52:04 --> Security Class Initialized
DEBUG - 2016-07-10 19:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:52:04 --> Input Class Initialized
INFO - 2016-07-10 19:52:04 --> Language Class Initialized
INFO - 2016-07-10 19:52:04 --> Loader Class Initialized
INFO - 2016-07-10 19:52:04 --> Helper loaded: url_helper
INFO - 2016-07-10 19:52:04 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:52:04 --> Helper loaded: html_helper
INFO - 2016-07-10 19:52:04 --> Helper loaded: form_helper
INFO - 2016-07-10 19:52:04 --> Helper loaded: file_helper
INFO - 2016-07-10 19:52:04 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:52:04 --> Database Driver Class Initialized
INFO - 2016-07-10 19:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:52:04 --> Form Validation Class Initialized
INFO - 2016-07-10 19:52:04 --> Email Class Initialized
INFO - 2016-07-10 19:52:04 --> Controller Class Initialized
INFO - 2016-07-10 19:52:04 --> Model Class Initialized
INFO - 2016-07-10 19:52:29 --> Config Class Initialized
INFO - 2016-07-10 19:52:29 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:52:29 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:52:29 --> Utf8 Class Initialized
INFO - 2016-07-10 19:52:29 --> URI Class Initialized
INFO - 2016-07-10 19:52:29 --> Router Class Initialized
INFO - 2016-07-10 19:52:29 --> Output Class Initialized
INFO - 2016-07-10 19:52:29 --> Security Class Initialized
DEBUG - 2016-07-10 19:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:52:29 --> Input Class Initialized
INFO - 2016-07-10 19:52:29 --> Language Class Initialized
INFO - 2016-07-10 19:52:29 --> Loader Class Initialized
INFO - 2016-07-10 19:52:29 --> Helper loaded: url_helper
INFO - 2016-07-10 19:52:29 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:52:29 --> Helper loaded: html_helper
INFO - 2016-07-10 19:52:29 --> Helper loaded: form_helper
INFO - 2016-07-10 19:52:29 --> Helper loaded: file_helper
INFO - 2016-07-10 19:52:29 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:52:29 --> Database Driver Class Initialized
INFO - 2016-07-10 19:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:52:29 --> Form Validation Class Initialized
INFO - 2016-07-10 19:52:29 --> Email Class Initialized
INFO - 2016-07-10 19:52:29 --> Controller Class Initialized
INFO - 2016-07-10 19:52:29 --> Model Class Initialized
DEBUG - 2016-07-10 19:52:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 19:52:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 19:52:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 19:52:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 19:52:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 19:52:29 --> Final output sent to browser
DEBUG - 2016-07-10 19:52:29 --> Total execution time: 0.2757
INFO - 2016-07-10 19:52:31 --> Config Class Initialized
INFO - 2016-07-10 19:52:31 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:52:31 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:52:31 --> Utf8 Class Initialized
INFO - 2016-07-10 19:52:31 --> URI Class Initialized
INFO - 2016-07-10 19:52:31 --> Router Class Initialized
INFO - 2016-07-10 19:52:31 --> Output Class Initialized
INFO - 2016-07-10 19:52:31 --> Security Class Initialized
DEBUG - 2016-07-10 19:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:52:31 --> Input Class Initialized
INFO - 2016-07-10 19:52:31 --> Language Class Initialized
INFO - 2016-07-10 19:52:31 --> Loader Class Initialized
INFO - 2016-07-10 19:52:31 --> Helper loaded: url_helper
INFO - 2016-07-10 19:52:31 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:52:31 --> Helper loaded: html_helper
INFO - 2016-07-10 19:52:31 --> Helper loaded: form_helper
INFO - 2016-07-10 19:52:31 --> Helper loaded: file_helper
INFO - 2016-07-10 19:52:31 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:52:31 --> Database Driver Class Initialized
INFO - 2016-07-10 19:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:52:31 --> Form Validation Class Initialized
INFO - 2016-07-10 19:52:31 --> Email Class Initialized
INFO - 2016-07-10 19:52:31 --> Controller Class Initialized
INFO - 2016-07-10 19:52:31 --> Model Class Initialized
INFO - 2016-07-10 19:53:46 --> Config Class Initialized
INFO - 2016-07-10 19:53:46 --> Hooks Class Initialized
DEBUG - 2016-07-10 19:53:46 --> UTF-8 Support Enabled
INFO - 2016-07-10 19:53:46 --> Utf8 Class Initialized
INFO - 2016-07-10 19:53:46 --> URI Class Initialized
INFO - 2016-07-10 19:53:46 --> Router Class Initialized
INFO - 2016-07-10 19:53:46 --> Output Class Initialized
INFO - 2016-07-10 19:53:46 --> Security Class Initialized
DEBUG - 2016-07-10 19:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 19:53:46 --> Input Class Initialized
INFO - 2016-07-10 19:53:46 --> Language Class Initialized
INFO - 2016-07-10 19:53:46 --> Loader Class Initialized
INFO - 2016-07-10 19:53:46 --> Helper loaded: url_helper
INFO - 2016-07-10 19:53:46 --> Helper loaded: utils_helper
INFO - 2016-07-10 19:53:46 --> Helper loaded: html_helper
INFO - 2016-07-10 19:53:46 --> Helper loaded: form_helper
INFO - 2016-07-10 19:53:46 --> Helper loaded: file_helper
INFO - 2016-07-10 19:53:46 --> Helper loaded: myemail_helper
INFO - 2016-07-10 19:53:46 --> Database Driver Class Initialized
INFO - 2016-07-10 19:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 19:53:46 --> Form Validation Class Initialized
INFO - 2016-07-10 19:53:46 --> Email Class Initialized
INFO - 2016-07-10 19:53:46 --> Controller Class Initialized
INFO - 2016-07-10 19:53:46 --> Model Class Initialized
INFO - 2016-07-10 20:01:29 --> Config Class Initialized
INFO - 2016-07-10 20:01:29 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:01:29 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:01:29 --> Utf8 Class Initialized
INFO - 2016-07-10 20:01:29 --> URI Class Initialized
INFO - 2016-07-10 20:01:29 --> Router Class Initialized
INFO - 2016-07-10 20:01:29 --> Output Class Initialized
INFO - 2016-07-10 20:01:29 --> Security Class Initialized
DEBUG - 2016-07-10 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:01:29 --> Input Class Initialized
INFO - 2016-07-10 20:01:29 --> Language Class Initialized
INFO - 2016-07-10 20:01:29 --> Loader Class Initialized
INFO - 2016-07-10 20:01:29 --> Helper loaded: url_helper
INFO - 2016-07-10 20:01:29 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:01:29 --> Helper loaded: html_helper
INFO - 2016-07-10 20:01:29 --> Helper loaded: form_helper
INFO - 2016-07-10 20:01:29 --> Helper loaded: file_helper
INFO - 2016-07-10 20:01:29 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:01:29 --> Database Driver Class Initialized
INFO - 2016-07-10 20:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:01:29 --> Form Validation Class Initialized
INFO - 2016-07-10 20:01:29 --> Email Class Initialized
INFO - 2016-07-10 20:01:29 --> Controller Class Initialized
INFO - 2016-07-10 20:01:29 --> Model Class Initialized
DEBUG - 2016-07-10 20:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 20:01:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 20:01:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 20:01:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 20:01:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 20:01:29 --> Final output sent to browser
DEBUG - 2016-07-10 20:01:29 --> Total execution time: 0.2721
INFO - 2016-07-10 20:01:31 --> Config Class Initialized
INFO - 2016-07-10 20:01:31 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:01:31 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:01:31 --> Utf8 Class Initialized
INFO - 2016-07-10 20:01:31 --> URI Class Initialized
INFO - 2016-07-10 20:01:31 --> Router Class Initialized
INFO - 2016-07-10 20:01:31 --> Output Class Initialized
INFO - 2016-07-10 20:01:31 --> Security Class Initialized
DEBUG - 2016-07-10 20:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:01:31 --> Input Class Initialized
INFO - 2016-07-10 20:01:31 --> Language Class Initialized
INFO - 2016-07-10 20:01:31 --> Loader Class Initialized
INFO - 2016-07-10 20:01:31 --> Helper loaded: url_helper
INFO - 2016-07-10 20:01:31 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:01:31 --> Helper loaded: html_helper
INFO - 2016-07-10 20:01:31 --> Helper loaded: form_helper
INFO - 2016-07-10 20:01:31 --> Helper loaded: file_helper
INFO - 2016-07-10 20:01:31 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:01:31 --> Database Driver Class Initialized
INFO - 2016-07-10 20:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:01:31 --> Form Validation Class Initialized
INFO - 2016-07-10 20:01:31 --> Email Class Initialized
INFO - 2016-07-10 20:01:31 --> Controller Class Initialized
INFO - 2016-07-10 20:01:31 --> Model Class Initialized
INFO - 2016-07-10 20:02:06 --> Config Class Initialized
INFO - 2016-07-10 20:02:06 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:02:06 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:02:06 --> Utf8 Class Initialized
INFO - 2016-07-10 20:02:06 --> URI Class Initialized
INFO - 2016-07-10 20:02:06 --> Router Class Initialized
INFO - 2016-07-10 20:02:06 --> Output Class Initialized
INFO - 2016-07-10 20:02:06 --> Security Class Initialized
DEBUG - 2016-07-10 20:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:02:06 --> Input Class Initialized
INFO - 2016-07-10 20:02:06 --> Language Class Initialized
INFO - 2016-07-10 20:02:06 --> Loader Class Initialized
INFO - 2016-07-10 20:02:06 --> Helper loaded: url_helper
INFO - 2016-07-10 20:02:06 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:02:06 --> Helper loaded: html_helper
INFO - 2016-07-10 20:02:06 --> Helper loaded: form_helper
INFO - 2016-07-10 20:02:06 --> Helper loaded: file_helper
INFO - 2016-07-10 20:02:06 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:02:06 --> Database Driver Class Initialized
INFO - 2016-07-10 20:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:02:06 --> Form Validation Class Initialized
INFO - 2016-07-10 20:02:06 --> Email Class Initialized
INFO - 2016-07-10 20:02:06 --> Controller Class Initialized
INFO - 2016-07-10 20:02:06 --> Model Class Initialized
DEBUG - 2016-07-10 20:02:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 20:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 20:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 20:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 20:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 20:02:06 --> Final output sent to browser
DEBUG - 2016-07-10 20:02:06 --> Total execution time: 0.2916
INFO - 2016-07-10 20:02:08 --> Config Class Initialized
INFO - 2016-07-10 20:02:08 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:02:08 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:02:08 --> Utf8 Class Initialized
INFO - 2016-07-10 20:02:08 --> URI Class Initialized
INFO - 2016-07-10 20:02:08 --> Router Class Initialized
INFO - 2016-07-10 20:02:08 --> Output Class Initialized
INFO - 2016-07-10 20:02:08 --> Security Class Initialized
DEBUG - 2016-07-10 20:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:02:08 --> Input Class Initialized
INFO - 2016-07-10 20:02:08 --> Language Class Initialized
INFO - 2016-07-10 20:02:08 --> Loader Class Initialized
INFO - 2016-07-10 20:02:08 --> Helper loaded: url_helper
INFO - 2016-07-10 20:02:08 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:02:08 --> Helper loaded: html_helper
INFO - 2016-07-10 20:02:08 --> Helper loaded: form_helper
INFO - 2016-07-10 20:02:08 --> Helper loaded: file_helper
INFO - 2016-07-10 20:02:08 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:02:08 --> Database Driver Class Initialized
INFO - 2016-07-10 20:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:02:08 --> Form Validation Class Initialized
INFO - 2016-07-10 20:02:08 --> Email Class Initialized
INFO - 2016-07-10 20:02:08 --> Controller Class Initialized
INFO - 2016-07-10 20:02:08 --> Model Class Initialized
INFO - 2016-07-10 20:02:55 --> Config Class Initialized
INFO - 2016-07-10 20:02:55 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:02:55 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:02:55 --> Utf8 Class Initialized
INFO - 2016-07-10 20:02:55 --> URI Class Initialized
INFO - 2016-07-10 20:02:55 --> Router Class Initialized
INFO - 2016-07-10 20:02:55 --> Output Class Initialized
INFO - 2016-07-10 20:02:55 --> Security Class Initialized
DEBUG - 2016-07-10 20:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:02:55 --> Input Class Initialized
INFO - 2016-07-10 20:02:55 --> Language Class Initialized
INFO - 2016-07-10 20:02:55 --> Loader Class Initialized
INFO - 2016-07-10 20:02:55 --> Helper loaded: url_helper
INFO - 2016-07-10 20:02:55 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:02:56 --> Helper loaded: html_helper
INFO - 2016-07-10 20:02:56 --> Helper loaded: form_helper
INFO - 2016-07-10 20:02:56 --> Helper loaded: file_helper
INFO - 2016-07-10 20:02:56 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:02:56 --> Database Driver Class Initialized
INFO - 2016-07-10 20:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:02:56 --> Form Validation Class Initialized
INFO - 2016-07-10 20:02:56 --> Email Class Initialized
INFO - 2016-07-10 20:02:56 --> Controller Class Initialized
INFO - 2016-07-10 20:02:56 --> Model Class Initialized
DEBUG - 2016-07-10 20:02:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-10 20:02:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-10 20:02:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-10 20:02:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-10 20:02:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-10 20:02:56 --> Final output sent to browser
DEBUG - 2016-07-10 20:02:56 --> Total execution time: 0.2774
INFO - 2016-07-10 20:02:57 --> Config Class Initialized
INFO - 2016-07-10 20:02:57 --> Hooks Class Initialized
DEBUG - 2016-07-10 20:02:57 --> UTF-8 Support Enabled
INFO - 2016-07-10 20:02:57 --> Utf8 Class Initialized
INFO - 2016-07-10 20:02:57 --> URI Class Initialized
INFO - 2016-07-10 20:02:57 --> Router Class Initialized
INFO - 2016-07-10 20:02:57 --> Output Class Initialized
INFO - 2016-07-10 20:02:57 --> Security Class Initialized
DEBUG - 2016-07-10 20:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-10 20:02:57 --> Input Class Initialized
INFO - 2016-07-10 20:02:57 --> Language Class Initialized
INFO - 2016-07-10 20:02:58 --> Loader Class Initialized
INFO - 2016-07-10 20:02:58 --> Helper loaded: url_helper
INFO - 2016-07-10 20:02:58 --> Helper loaded: utils_helper
INFO - 2016-07-10 20:02:58 --> Helper loaded: html_helper
INFO - 2016-07-10 20:02:58 --> Helper loaded: form_helper
INFO - 2016-07-10 20:02:58 --> Helper loaded: file_helper
INFO - 2016-07-10 20:02:58 --> Helper loaded: myemail_helper
INFO - 2016-07-10 20:02:58 --> Database Driver Class Initialized
INFO - 2016-07-10 20:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-10 20:02:58 --> Form Validation Class Initialized
INFO - 2016-07-10 20:02:58 --> Email Class Initialized
INFO - 2016-07-10 20:02:58 --> Controller Class Initialized
INFO - 2016-07-10 20:02:58 --> Model Class Initialized
