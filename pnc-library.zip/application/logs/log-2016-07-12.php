<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-12 04:00:56 --> Config Class Initialized
INFO - 2016-07-12 04:00:56 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:00:56 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:00:56 --> Utf8 Class Initialized
INFO - 2016-07-12 04:00:56 --> URI Class Initialized
INFO - 2016-07-12 04:00:56 --> Router Class Initialized
INFO - 2016-07-12 04:00:56 --> Output Class Initialized
INFO - 2016-07-12 04:00:56 --> Security Class Initialized
DEBUG - 2016-07-12 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:00:56 --> Input Class Initialized
INFO - 2016-07-12 04:00:56 --> Language Class Initialized
INFO - 2016-07-12 04:00:56 --> Loader Class Initialized
INFO - 2016-07-12 04:00:56 --> Helper loaded: url_helper
INFO - 2016-07-12 04:00:56 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:00:56 --> Helper loaded: html_helper
INFO - 2016-07-12 04:00:56 --> Helper loaded: form_helper
INFO - 2016-07-12 04:00:56 --> Helper loaded: file_helper
INFO - 2016-07-12 04:00:56 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:00:56 --> Database Driver Class Initialized
INFO - 2016-07-12 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:00:56 --> Form Validation Class Initialized
INFO - 2016-07-12 04:00:57 --> Email Class Initialized
INFO - 2016-07-12 04:00:57 --> Controller Class Initialized
INFO - 2016-07-12 04:00:57 --> Model Class Initialized
DEBUG - 2016-07-12 04:00:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:00:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-12 04:00:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:00:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-12 04:00:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:00:57 --> Final output sent to browser
DEBUG - 2016-07-12 04:00:57 --> Total execution time: 0.6787
INFO - 2016-07-12 04:10:46 --> Config Class Initialized
INFO - 2016-07-12 04:10:46 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:10:46 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:10:46 --> Utf8 Class Initialized
INFO - 2016-07-12 04:10:46 --> URI Class Initialized
INFO - 2016-07-12 04:10:46 --> Router Class Initialized
INFO - 2016-07-12 04:10:46 --> Output Class Initialized
INFO - 2016-07-12 04:10:46 --> Security Class Initialized
DEBUG - 2016-07-12 04:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:10:46 --> Input Class Initialized
INFO - 2016-07-12 04:10:46 --> Language Class Initialized
ERROR - 2016-07-12 04:10:46 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-07-12 04:10:48 --> Config Class Initialized
INFO - 2016-07-12 04:10:48 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:10:48 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:10:48 --> Utf8 Class Initialized
INFO - 2016-07-12 04:10:48 --> URI Class Initialized
INFO - 2016-07-12 04:10:48 --> Router Class Initialized
INFO - 2016-07-12 04:10:48 --> Output Class Initialized
INFO - 2016-07-12 04:10:48 --> Security Class Initialized
DEBUG - 2016-07-12 04:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:10:48 --> Input Class Initialized
INFO - 2016-07-12 04:10:48 --> Language Class Initialized
INFO - 2016-07-12 04:10:48 --> Loader Class Initialized
INFO - 2016-07-12 04:10:48 --> Helper loaded: url_helper
INFO - 2016-07-12 04:10:48 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:10:48 --> Helper loaded: html_helper
INFO - 2016-07-12 04:10:48 --> Helper loaded: form_helper
INFO - 2016-07-12 04:10:48 --> Helper loaded: file_helper
INFO - 2016-07-12 04:10:48 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:10:49 --> Database Driver Class Initialized
INFO - 2016-07-12 04:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:10:49 --> Form Validation Class Initialized
INFO - 2016-07-12 04:10:49 --> Email Class Initialized
INFO - 2016-07-12 04:10:49 --> Controller Class Initialized
INFO - 2016-07-12 04:10:49 --> Model Class Initialized
DEBUG - 2016-07-12 04:10:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:10:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-12 04:10:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:10:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-12 04:10:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:10:49 --> Final output sent to browser
DEBUG - 2016-07-12 04:10:49 --> Total execution time: 0.2498
INFO - 2016-07-12 04:10:51 --> Config Class Initialized
INFO - 2016-07-12 04:10:51 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:10:51 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:10:51 --> Utf8 Class Initialized
INFO - 2016-07-12 04:10:51 --> URI Class Initialized
INFO - 2016-07-12 04:10:51 --> Router Class Initialized
INFO - 2016-07-12 04:10:51 --> Output Class Initialized
INFO - 2016-07-12 04:10:51 --> Security Class Initialized
DEBUG - 2016-07-12 04:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:10:51 --> Input Class Initialized
INFO - 2016-07-12 04:10:51 --> Language Class Initialized
ERROR - 2016-07-12 04:10:51 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-07-12 04:10:53 --> Config Class Initialized
INFO - 2016-07-12 04:10:53 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:10:53 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:10:53 --> Utf8 Class Initialized
INFO - 2016-07-12 04:10:53 --> URI Class Initialized
INFO - 2016-07-12 04:10:53 --> Router Class Initialized
INFO - 2016-07-12 04:10:53 --> Output Class Initialized
INFO - 2016-07-12 04:10:53 --> Security Class Initialized
DEBUG - 2016-07-12 04:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:10:53 --> Input Class Initialized
INFO - 2016-07-12 04:10:53 --> Language Class Initialized
INFO - 2016-07-12 04:10:53 --> Loader Class Initialized
INFO - 2016-07-12 04:10:53 --> Helper loaded: url_helper
INFO - 2016-07-12 04:10:53 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:10:53 --> Helper loaded: html_helper
INFO - 2016-07-12 04:10:53 --> Helper loaded: form_helper
INFO - 2016-07-12 04:10:53 --> Helper loaded: file_helper
INFO - 2016-07-12 04:10:53 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:10:53 --> Database Driver Class Initialized
INFO - 2016-07-12 04:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:10:53 --> Form Validation Class Initialized
INFO - 2016-07-12 04:10:53 --> Email Class Initialized
INFO - 2016-07-12 04:10:53 --> Controller Class Initialized
INFO - 2016-07-12 04:10:53 --> Model Class Initialized
DEBUG - 2016-07-12 04:10:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:10:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-12 04:10:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:10:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-12 04:10:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:10:53 --> Final output sent to browser
DEBUG - 2016-07-12 04:10:53 --> Total execution time: 0.2258
INFO - 2016-07-12 04:12:16 --> Config Class Initialized
INFO - 2016-07-12 04:12:16 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:12:16 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:12:16 --> Utf8 Class Initialized
INFO - 2016-07-12 04:12:16 --> URI Class Initialized
INFO - 2016-07-12 04:12:16 --> Router Class Initialized
INFO - 2016-07-12 04:12:16 --> Output Class Initialized
INFO - 2016-07-12 04:12:16 --> Security Class Initialized
DEBUG - 2016-07-12 04:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:12:16 --> Input Class Initialized
INFO - 2016-07-12 04:12:16 --> Language Class Initialized
INFO - 2016-07-12 04:12:16 --> Loader Class Initialized
INFO - 2016-07-12 04:12:16 --> Helper loaded: url_helper
INFO - 2016-07-12 04:12:16 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:12:16 --> Helper loaded: html_helper
INFO - 2016-07-12 04:12:16 --> Helper loaded: form_helper
INFO - 2016-07-12 04:12:16 --> Helper loaded: file_helper
INFO - 2016-07-12 04:12:16 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:12:16 --> Database Driver Class Initialized
INFO - 2016-07-12 04:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:12:16 --> Form Validation Class Initialized
INFO - 2016-07-12 04:12:16 --> Email Class Initialized
INFO - 2016-07-12 04:12:16 --> Controller Class Initialized
INFO - 2016-07-12 04:12:16 --> Model Class Initialized
DEBUG - 2016-07-12 04:12:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:12:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-12 04:12:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:12:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-12 04:12:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:12:16 --> Final output sent to browser
DEBUG - 2016-07-12 04:12:16 --> Total execution time: 0.3689
INFO - 2016-07-12 04:36:46 --> Config Class Initialized
INFO - 2016-07-12 04:36:46 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:36:46 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:36:46 --> Utf8 Class Initialized
INFO - 2016-07-12 04:36:46 --> URI Class Initialized
INFO - 2016-07-12 04:36:46 --> Router Class Initialized
INFO - 2016-07-12 04:36:46 --> Output Class Initialized
INFO - 2016-07-12 04:36:46 --> Security Class Initialized
DEBUG - 2016-07-12 04:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:36:46 --> Input Class Initialized
INFO - 2016-07-12 04:36:46 --> Language Class Initialized
INFO - 2016-07-12 04:36:46 --> Loader Class Initialized
INFO - 2016-07-12 04:36:46 --> Helper loaded: url_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: html_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: form_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: file_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:36:46 --> Database Driver Class Initialized
INFO - 2016-07-12 04:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:36:46 --> Form Validation Class Initialized
INFO - 2016-07-12 04:36:46 --> Email Class Initialized
INFO - 2016-07-12 04:36:46 --> Controller Class Initialized
INFO - 2016-07-12 04:36:46 --> Model Class Initialized
DEBUG - 2016-07-12 04:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:36:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-12 04:36:46 --> Config Class Initialized
INFO - 2016-07-12 04:36:46 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:36:46 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:36:46 --> Utf8 Class Initialized
INFO - 2016-07-12 04:36:46 --> URI Class Initialized
INFO - 2016-07-12 04:36:46 --> Router Class Initialized
INFO - 2016-07-12 04:36:46 --> Output Class Initialized
INFO - 2016-07-12 04:36:46 --> Security Class Initialized
DEBUG - 2016-07-12 04:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:36:46 --> Input Class Initialized
INFO - 2016-07-12 04:36:46 --> Language Class Initialized
INFO - 2016-07-12 04:36:46 --> Loader Class Initialized
INFO - 2016-07-12 04:36:46 --> Helper loaded: url_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: html_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: form_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: file_helper
INFO - 2016-07-12 04:36:46 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:36:46 --> Database Driver Class Initialized
INFO - 2016-07-12 04:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:36:46 --> Form Validation Class Initialized
INFO - 2016-07-12 04:36:46 --> Email Class Initialized
INFO - 2016-07-12 04:36:46 --> Controller Class Initialized
DEBUG - 2016-07-12 04:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-12 04:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:36:46 --> Model Class Initialized
INFO - 2016-07-12 04:36:46 --> Model Class Initialized
INFO - 2016-07-12 04:36:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:36:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-12 04:36:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-12 04:36:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:36:46 --> Final output sent to browser
DEBUG - 2016-07-12 04:36:46 --> Total execution time: 0.3729
INFO - 2016-07-12 04:36:56 --> Config Class Initialized
INFO - 2016-07-12 04:36:56 --> Hooks Class Initialized
DEBUG - 2016-07-12 04:36:56 --> UTF-8 Support Enabled
INFO - 2016-07-12 04:36:56 --> Utf8 Class Initialized
INFO - 2016-07-12 04:36:56 --> URI Class Initialized
INFO - 2016-07-12 04:36:56 --> Router Class Initialized
INFO - 2016-07-12 04:36:56 --> Output Class Initialized
INFO - 2016-07-12 04:36:56 --> Security Class Initialized
DEBUG - 2016-07-12 04:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 04:36:56 --> Input Class Initialized
INFO - 2016-07-12 04:36:56 --> Language Class Initialized
INFO - 2016-07-12 04:36:56 --> Loader Class Initialized
INFO - 2016-07-12 04:36:56 --> Helper loaded: url_helper
INFO - 2016-07-12 04:36:56 --> Helper loaded: utils_helper
INFO - 2016-07-12 04:36:56 --> Helper loaded: html_helper
INFO - 2016-07-12 04:36:56 --> Helper loaded: form_helper
INFO - 2016-07-12 04:36:56 --> Helper loaded: file_helper
INFO - 2016-07-12 04:36:56 --> Helper loaded: myemail_helper
INFO - 2016-07-12 04:36:56 --> Database Driver Class Initialized
INFO - 2016-07-12 04:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 04:36:56 --> Form Validation Class Initialized
INFO - 2016-07-12 04:36:56 --> Email Class Initialized
INFO - 2016-07-12 04:36:56 --> Controller Class Initialized
DEBUG - 2016-07-12 04:36:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-12 04:36:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 04:36:56 --> Model Class Initialized
INFO - 2016-07-12 04:36:56 --> Model Class Initialized
INFO - 2016-07-12 04:36:56 --> Model Class Initialized
INFO - 2016-07-12 04:36:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 04:36:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-12 04:36:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/all_books.php
INFO - 2016-07-12 04:36:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 04:36:56 --> Final output sent to browser
DEBUG - 2016-07-12 04:36:56 --> Total execution time: 0.2941
INFO - 2016-07-12 10:28:20 --> Config Class Initialized
INFO - 2016-07-12 10:28:20 --> Hooks Class Initialized
DEBUG - 2016-07-12 10:28:20 --> UTF-8 Support Enabled
INFO - 2016-07-12 10:28:20 --> Utf8 Class Initialized
INFO - 2016-07-12 10:28:20 --> URI Class Initialized
INFO - 2016-07-12 10:28:20 --> Router Class Initialized
INFO - 2016-07-12 10:28:20 --> Output Class Initialized
INFO - 2016-07-12 10:28:20 --> Security Class Initialized
DEBUG - 2016-07-12 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 10:28:20 --> Input Class Initialized
INFO - 2016-07-12 10:28:20 --> Language Class Initialized
INFO - 2016-07-12 10:28:20 --> Loader Class Initialized
INFO - 2016-07-12 10:28:20 --> Helper loaded: url_helper
INFO - 2016-07-12 10:28:20 --> Helper loaded: utils_helper
INFO - 2016-07-12 10:28:20 --> Helper loaded: html_helper
INFO - 2016-07-12 10:28:20 --> Helper loaded: form_helper
INFO - 2016-07-12 10:28:20 --> Helper loaded: file_helper
INFO - 2016-07-12 10:28:20 --> Helper loaded: myemail_helper
INFO - 2016-07-12 10:28:20 --> Database Driver Class Initialized
INFO - 2016-07-12 10:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 10:28:20 --> Form Validation Class Initialized
INFO - 2016-07-12 10:28:20 --> Email Class Initialized
INFO - 2016-07-12 10:28:20 --> Controller Class Initialized
INFO - 2016-07-12 10:28:20 --> Config Class Initialized
INFO - 2016-07-12 10:28:20 --> Hooks Class Initialized
DEBUG - 2016-07-12 10:28:20 --> UTF-8 Support Enabled
INFO - 2016-07-12 10:28:20 --> Utf8 Class Initialized
INFO - 2016-07-12 10:28:20 --> URI Class Initialized
INFO - 2016-07-12 10:28:20 --> Router Class Initialized
INFO - 2016-07-12 10:28:20 --> Output Class Initialized
INFO - 2016-07-12 10:28:20 --> Security Class Initialized
DEBUG - 2016-07-12 10:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-12 10:28:20 --> Input Class Initialized
INFO - 2016-07-12 10:28:20 --> Language Class Initialized
INFO - 2016-07-12 10:28:20 --> Loader Class Initialized
INFO - 2016-07-12 10:28:20 --> Helper loaded: url_helper
INFO - 2016-07-12 10:28:21 --> Helper loaded: utils_helper
INFO - 2016-07-12 10:28:21 --> Helper loaded: html_helper
INFO - 2016-07-12 10:28:21 --> Helper loaded: form_helper
INFO - 2016-07-12 10:28:21 --> Helper loaded: file_helper
INFO - 2016-07-12 10:28:21 --> Helper loaded: myemail_helper
INFO - 2016-07-12 10:28:21 --> Database Driver Class Initialized
INFO - 2016-07-12 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-12 10:28:21 --> Form Validation Class Initialized
INFO - 2016-07-12 10:28:21 --> Email Class Initialized
INFO - 2016-07-12 10:28:21 --> Controller Class Initialized
INFO - 2016-07-12 10:28:21 --> Model Class Initialized
DEBUG - 2016-07-12 10:28:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-12 10:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-12 10:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-12 10:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-12 10:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-12 10:28:21 --> Final output sent to browser
DEBUG - 2016-07-12 10:28:21 --> Total execution time: 0.3859
