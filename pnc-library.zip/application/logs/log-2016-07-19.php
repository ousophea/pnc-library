<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-19 15:26:38 --> Config Class Initialized
INFO - 2016-07-19 15:26:38 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:26:38 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:26:38 --> Utf8 Class Initialized
INFO - 2016-07-19 15:26:38 --> URI Class Initialized
INFO - 2016-07-19 15:26:39 --> Router Class Initialized
INFO - 2016-07-19 15:26:39 --> Output Class Initialized
INFO - 2016-07-19 15:26:39 --> Security Class Initialized
DEBUG - 2016-07-19 15:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:26:39 --> Input Class Initialized
INFO - 2016-07-19 15:26:39 --> Language Class Initialized
ERROR - 2016-07-19 15:26:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-19 15:26:41 --> Config Class Initialized
INFO - 2016-07-19 15:26:41 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:26:41 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:26:41 --> Utf8 Class Initialized
INFO - 2016-07-19 15:26:41 --> URI Class Initialized
INFO - 2016-07-19 15:26:41 --> Router Class Initialized
INFO - 2016-07-19 15:26:41 --> Output Class Initialized
INFO - 2016-07-19 15:26:41 --> Security Class Initialized
DEBUG - 2016-07-19 15:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:26:41 --> Input Class Initialized
INFO - 2016-07-19 15:26:41 --> Language Class Initialized
ERROR - 2016-07-19 15:26:41 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-19 15:26:57 --> Config Class Initialized
INFO - 2016-07-19 15:26:57 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:26:57 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:26:57 --> Utf8 Class Initialized
INFO - 2016-07-19 15:26:57 --> URI Class Initialized
INFO - 2016-07-19 15:26:57 --> Router Class Initialized
INFO - 2016-07-19 15:26:57 --> Output Class Initialized
INFO - 2016-07-19 15:26:57 --> Security Class Initialized
DEBUG - 2016-07-19 15:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:26:57 --> Input Class Initialized
INFO - 2016-07-19 15:26:57 --> Language Class Initialized
INFO - 2016-07-19 15:26:57 --> Loader Class Initialized
INFO - 2016-07-19 15:26:57 --> Helper loaded: url_helper
INFO - 2016-07-19 15:26:57 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:26:57 --> Helper loaded: html_helper
INFO - 2016-07-19 15:26:57 --> Helper loaded: form_helper
INFO - 2016-07-19 15:26:57 --> Helper loaded: file_helper
INFO - 2016-07-19 15:26:57 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:26:57 --> Database Driver Class Initialized
INFO - 2016-07-19 15:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:26:57 --> Form Validation Class Initialized
INFO - 2016-07-19 15:26:58 --> Email Class Initialized
INFO - 2016-07-19 15:26:58 --> Controller Class Initialized
INFO - 2016-07-19 15:26:58 --> Config Class Initialized
INFO - 2016-07-19 15:26:58 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:26:58 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:26:58 --> Utf8 Class Initialized
INFO - 2016-07-19 15:26:58 --> URI Class Initialized
INFO - 2016-07-19 15:26:58 --> Router Class Initialized
INFO - 2016-07-19 15:26:58 --> Output Class Initialized
INFO - 2016-07-19 15:26:58 --> Security Class Initialized
DEBUG - 2016-07-19 15:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:26:58 --> Input Class Initialized
INFO - 2016-07-19 15:26:58 --> Language Class Initialized
INFO - 2016-07-19 15:26:58 --> Loader Class Initialized
INFO - 2016-07-19 15:26:58 --> Helper loaded: url_helper
INFO - 2016-07-19 15:26:58 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:26:58 --> Helper loaded: html_helper
INFO - 2016-07-19 15:26:58 --> Helper loaded: form_helper
INFO - 2016-07-19 15:26:58 --> Helper loaded: file_helper
INFO - 2016-07-19 15:26:58 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:26:58 --> Database Driver Class Initialized
INFO - 2016-07-19 15:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:26:58 --> Form Validation Class Initialized
INFO - 2016-07-19 15:26:58 --> Email Class Initialized
INFO - 2016-07-19 15:26:58 --> Controller Class Initialized
INFO - 2016-07-19 15:26:58 --> Model Class Initialized
DEBUG - 2016-07-19 15:26:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 15:26:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-19 15:26:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 15:26:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-19 15:26:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 15:26:58 --> Final output sent to browser
DEBUG - 2016-07-19 15:26:58 --> Total execution time: 0.4893
INFO - 2016-07-19 15:57:24 --> Config Class Initialized
INFO - 2016-07-19 15:57:24 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:57:24 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:57:24 --> Utf8 Class Initialized
INFO - 2016-07-19 15:57:24 --> URI Class Initialized
DEBUG - 2016-07-19 15:57:24 --> No URI present. Default controller set.
INFO - 2016-07-19 15:57:24 --> Router Class Initialized
INFO - 2016-07-19 15:57:24 --> Output Class Initialized
INFO - 2016-07-19 15:57:24 --> Security Class Initialized
DEBUG - 2016-07-19 15:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:57:24 --> Input Class Initialized
INFO - 2016-07-19 15:57:24 --> Language Class Initialized
INFO - 2016-07-19 15:57:24 --> Loader Class Initialized
INFO - 2016-07-19 15:57:24 --> Helper loaded: url_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: html_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: form_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: file_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:57:24 --> Database Driver Class Initialized
INFO - 2016-07-19 15:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:57:24 --> Form Validation Class Initialized
INFO - 2016-07-19 15:57:24 --> Email Class Initialized
INFO - 2016-07-19 15:57:24 --> Controller Class Initialized
INFO - 2016-07-19 15:57:24 --> Config Class Initialized
INFO - 2016-07-19 15:57:24 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:57:24 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:57:24 --> Utf8 Class Initialized
INFO - 2016-07-19 15:57:24 --> URI Class Initialized
INFO - 2016-07-19 15:57:24 --> Router Class Initialized
INFO - 2016-07-19 15:57:24 --> Output Class Initialized
INFO - 2016-07-19 15:57:24 --> Security Class Initialized
DEBUG - 2016-07-19 15:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:57:24 --> Input Class Initialized
INFO - 2016-07-19 15:57:24 --> Language Class Initialized
INFO - 2016-07-19 15:57:24 --> Loader Class Initialized
INFO - 2016-07-19 15:57:24 --> Helper loaded: url_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: html_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: form_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: file_helper
INFO - 2016-07-19 15:57:24 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:57:24 --> Database Driver Class Initialized
INFO - 2016-07-19 15:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:57:24 --> Form Validation Class Initialized
INFO - 2016-07-19 15:57:24 --> Email Class Initialized
INFO - 2016-07-19 15:57:24 --> Controller Class Initialized
INFO - 2016-07-19 15:57:24 --> Model Class Initialized
DEBUG - 2016-07-19 15:57:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 15:57:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-19 15:57:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 15:57:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-19 15:57:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 15:57:24 --> Final output sent to browser
DEBUG - 2016-07-19 15:57:24 --> Total execution time: 0.2054
INFO - 2016-07-19 15:57:33 --> Config Class Initialized
INFO - 2016-07-19 15:57:33 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:57:33 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:57:33 --> Utf8 Class Initialized
INFO - 2016-07-19 15:57:33 --> URI Class Initialized
INFO - 2016-07-19 15:57:33 --> Router Class Initialized
INFO - 2016-07-19 15:57:33 --> Output Class Initialized
INFO - 2016-07-19 15:57:33 --> Security Class Initialized
DEBUG - 2016-07-19 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:57:33 --> Input Class Initialized
INFO - 2016-07-19 15:57:33 --> Language Class Initialized
INFO - 2016-07-19 15:57:33 --> Loader Class Initialized
INFO - 2016-07-19 15:57:33 --> Helper loaded: url_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: html_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: form_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: file_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:57:33 --> Database Driver Class Initialized
INFO - 2016-07-19 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:57:33 --> Form Validation Class Initialized
INFO - 2016-07-19 15:57:33 --> Email Class Initialized
INFO - 2016-07-19 15:57:33 --> Controller Class Initialized
INFO - 2016-07-19 15:57:33 --> Model Class Initialized
DEBUG - 2016-07-19 15:57:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 15:57:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-19 15:57:33 --> Config Class Initialized
INFO - 2016-07-19 15:57:33 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:57:33 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:57:33 --> Utf8 Class Initialized
INFO - 2016-07-19 15:57:33 --> URI Class Initialized
DEBUG - 2016-07-19 15:57:33 --> No URI present. Default controller set.
INFO - 2016-07-19 15:57:33 --> Router Class Initialized
INFO - 2016-07-19 15:57:33 --> Output Class Initialized
INFO - 2016-07-19 15:57:33 --> Security Class Initialized
DEBUG - 2016-07-19 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:57:33 --> Input Class Initialized
INFO - 2016-07-19 15:57:33 --> Language Class Initialized
INFO - 2016-07-19 15:57:33 --> Loader Class Initialized
INFO - 2016-07-19 15:57:33 --> Helper loaded: url_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: html_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: form_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: file_helper
INFO - 2016-07-19 15:57:33 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:57:33 --> Database Driver Class Initialized
INFO - 2016-07-19 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:57:33 --> Form Validation Class Initialized
INFO - 2016-07-19 15:57:33 --> Email Class Initialized
INFO - 2016-07-19 15:57:33 --> Controller Class Initialized
INFO - 2016-07-19 15:57:33 --> Model Class Initialized
INFO - 2016-07-19 15:57:33 --> Model Class Initialized
INFO - 2016-07-19 15:57:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 15:57:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 15:57:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-19 15:57:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 15:57:33 --> Final output sent to browser
DEBUG - 2016-07-19 15:57:33 --> Total execution time: 0.2007
INFO - 2016-07-19 15:57:39 --> Config Class Initialized
INFO - 2016-07-19 15:57:39 --> Hooks Class Initialized
DEBUG - 2016-07-19 15:57:39 --> UTF-8 Support Enabled
INFO - 2016-07-19 15:57:39 --> Utf8 Class Initialized
INFO - 2016-07-19 15:57:39 --> URI Class Initialized
INFO - 2016-07-19 15:57:39 --> Router Class Initialized
INFO - 2016-07-19 15:57:39 --> Output Class Initialized
INFO - 2016-07-19 15:57:39 --> Security Class Initialized
DEBUG - 2016-07-19 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 15:57:39 --> Input Class Initialized
INFO - 2016-07-19 15:57:39 --> Language Class Initialized
INFO - 2016-07-19 15:57:39 --> Loader Class Initialized
INFO - 2016-07-19 15:57:39 --> Helper loaded: url_helper
INFO - 2016-07-19 15:57:39 --> Helper loaded: utils_helper
INFO - 2016-07-19 15:57:39 --> Helper loaded: html_helper
INFO - 2016-07-19 15:57:39 --> Helper loaded: form_helper
INFO - 2016-07-19 15:57:39 --> Helper loaded: file_helper
INFO - 2016-07-19 15:57:39 --> Helper loaded: myemail_helper
INFO - 2016-07-19 15:57:39 --> Database Driver Class Initialized
INFO - 2016-07-19 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 15:57:39 --> Form Validation Class Initialized
INFO - 2016-07-19 15:57:39 --> Email Class Initialized
INFO - 2016-07-19 15:57:39 --> Controller Class Initialized
DEBUG - 2016-07-19 15:57:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-19 15:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 15:57:39 --> Model Class Initialized
INFO - 2016-07-19 15:57:39 --> Model Class Initialized
INFO - 2016-07-19 15:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 15:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 15:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-19 15:57:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 15:57:40 --> Final output sent to browser
DEBUG - 2016-07-19 15:57:40 --> Total execution time: 0.5013
INFO - 2016-07-19 16:05:02 --> Config Class Initialized
INFO - 2016-07-19 16:05:02 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:05:02 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:05:02 --> Utf8 Class Initialized
INFO - 2016-07-19 16:05:02 --> URI Class Initialized
INFO - 2016-07-19 16:05:02 --> Router Class Initialized
INFO - 2016-07-19 16:05:02 --> Output Class Initialized
INFO - 2016-07-19 16:05:02 --> Security Class Initialized
DEBUG - 2016-07-19 16:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:05:02 --> Input Class Initialized
INFO - 2016-07-19 16:05:02 --> Language Class Initialized
INFO - 2016-07-19 16:05:02 --> Loader Class Initialized
INFO - 2016-07-19 16:05:02 --> Helper loaded: url_helper
INFO - 2016-07-19 16:05:02 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:05:02 --> Helper loaded: html_helper
INFO - 2016-07-19 16:05:02 --> Helper loaded: form_helper
INFO - 2016-07-19 16:05:02 --> Helper loaded: file_helper
INFO - 2016-07-19 16:05:02 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:05:02 --> Database Driver Class Initialized
INFO - 2016-07-19 16:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:05:02 --> Form Validation Class Initialized
INFO - 2016-07-19 16:05:02 --> Email Class Initialized
INFO - 2016-07-19 16:05:02 --> Controller Class Initialized
DEBUG - 2016-07-19 16:05:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-19 16:05:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:05:02 --> Model Class Initialized
INFO - 2016-07-19 16:05:02 --> Model Class Initialized
INFO - 2016-07-19 16:05:02 --> Model Class Initialized
INFO - 2016-07-19 16:05:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:05:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:05:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/all_books.php
INFO - 2016-07-19 16:05:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:05:02 --> Final output sent to browser
DEBUG - 2016-07-19 16:05:02 --> Total execution time: 0.2327
INFO - 2016-07-19 16:05:06 --> Config Class Initialized
INFO - 2016-07-19 16:05:06 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:05:06 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:05:06 --> Utf8 Class Initialized
INFO - 2016-07-19 16:05:06 --> URI Class Initialized
INFO - 2016-07-19 16:05:06 --> Router Class Initialized
INFO - 2016-07-19 16:05:06 --> Output Class Initialized
INFO - 2016-07-19 16:05:06 --> Security Class Initialized
DEBUG - 2016-07-19 16:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:05:06 --> Input Class Initialized
INFO - 2016-07-19 16:05:06 --> Language Class Initialized
INFO - 2016-07-19 16:05:06 --> Loader Class Initialized
INFO - 2016-07-19 16:05:06 --> Helper loaded: url_helper
INFO - 2016-07-19 16:05:06 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:05:06 --> Helper loaded: html_helper
INFO - 2016-07-19 16:05:06 --> Helper loaded: form_helper
INFO - 2016-07-19 16:05:06 --> Helper loaded: file_helper
INFO - 2016-07-19 16:05:06 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:05:06 --> Database Driver Class Initialized
INFO - 2016-07-19 16:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:05:06 --> Form Validation Class Initialized
INFO - 2016-07-19 16:05:06 --> Email Class Initialized
INFO - 2016-07-19 16:05:06 --> Controller Class Initialized
DEBUG - 2016-07-19 16:05:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:05:06 --> Model Class Initialized
INFO - 2016-07-19 16:05:06 --> Model Class Initialized
INFO - 2016-07-19 16:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-19 16:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:05:06 --> Final output sent to browser
DEBUG - 2016-07-19 16:05:06 --> Total execution time: 0.2114
INFO - 2016-07-19 16:05:08 --> Config Class Initialized
INFO - 2016-07-19 16:05:08 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:05:08 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:05:08 --> Utf8 Class Initialized
INFO - 2016-07-19 16:05:08 --> URI Class Initialized
INFO - 2016-07-19 16:05:08 --> Router Class Initialized
INFO - 2016-07-19 16:05:08 --> Output Class Initialized
INFO - 2016-07-19 16:05:08 --> Security Class Initialized
DEBUG - 2016-07-19 16:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:05:08 --> Input Class Initialized
INFO - 2016-07-19 16:05:08 --> Language Class Initialized
INFO - 2016-07-19 16:05:08 --> Loader Class Initialized
INFO - 2016-07-19 16:05:08 --> Helper loaded: url_helper
INFO - 2016-07-19 16:05:08 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:05:08 --> Helper loaded: html_helper
INFO - 2016-07-19 16:05:08 --> Helper loaded: form_helper
INFO - 2016-07-19 16:05:08 --> Helper loaded: file_helper
INFO - 2016-07-19 16:05:08 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:05:08 --> Database Driver Class Initialized
INFO - 2016-07-19 16:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:05:08 --> Form Validation Class Initialized
INFO - 2016-07-19 16:05:08 --> Email Class Initialized
INFO - 2016-07-19 16:05:08 --> Controller Class Initialized
DEBUG - 2016-07-19 16:05:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:05:08 --> Model Class Initialized
INFO - 2016-07-19 16:05:08 --> Model Class Initialized
INFO - 2016-07-19 16:05:08 --> Model Class Initialized
INFO - 2016-07-19 16:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-19 16:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:05:08 --> Final output sent to browser
DEBUG - 2016-07-19 16:05:08 --> Total execution time: 0.2221
INFO - 2016-07-19 16:05:25 --> Config Class Initialized
INFO - 2016-07-19 16:05:25 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:05:25 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:05:25 --> Utf8 Class Initialized
INFO - 2016-07-19 16:05:25 --> URI Class Initialized
INFO - 2016-07-19 16:05:25 --> Router Class Initialized
INFO - 2016-07-19 16:05:25 --> Output Class Initialized
INFO - 2016-07-19 16:05:25 --> Security Class Initialized
DEBUG - 2016-07-19 16:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:05:25 --> Input Class Initialized
INFO - 2016-07-19 16:05:25 --> Language Class Initialized
INFO - 2016-07-19 16:05:25 --> Loader Class Initialized
INFO - 2016-07-19 16:05:25 --> Helper loaded: url_helper
INFO - 2016-07-19 16:05:25 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:05:25 --> Helper loaded: html_helper
INFO - 2016-07-19 16:05:25 --> Helper loaded: form_helper
INFO - 2016-07-19 16:05:25 --> Helper loaded: file_helper
INFO - 2016-07-19 16:05:25 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:05:25 --> Database Driver Class Initialized
INFO - 2016-07-19 16:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:05:25 --> Form Validation Class Initialized
INFO - 2016-07-19 16:05:25 --> Email Class Initialized
INFO - 2016-07-19 16:05:25 --> Controller Class Initialized
DEBUG - 2016-07-19 16:05:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:05:25 --> Helper loaded: download_helper
INFO - 2016-07-19 16:05:25 --> Config Class Initialized
INFO - 2016-07-19 16:05:25 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:05:25 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:05:25 --> Utf8 Class Initialized
INFO - 2016-07-19 16:05:25 --> URI Class Initialized
INFO - 2016-07-19 16:05:25 --> Router Class Initialized
INFO - 2016-07-19 16:05:25 --> Output Class Initialized
INFO - 2016-07-19 16:05:25 --> Security Class Initialized
DEBUG - 2016-07-19 16:05:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:05:25 --> Input Class Initialized
INFO - 2016-07-19 16:05:25 --> Language Class Initialized
ERROR - 2016-07-19 16:05:25 --> 404 Page Not Found: Books/example.csv
ERROR - 2016-07-19 16:05:25 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/example.csv): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 321
INFO - 2016-07-19 16:16:10 --> Config Class Initialized
INFO - 2016-07-19 16:16:10 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:16:10 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:16:10 --> Utf8 Class Initialized
INFO - 2016-07-19 16:16:10 --> URI Class Initialized
INFO - 2016-07-19 16:16:10 --> Router Class Initialized
INFO - 2016-07-19 16:16:10 --> Output Class Initialized
INFO - 2016-07-19 16:16:10 --> Security Class Initialized
DEBUG - 2016-07-19 16:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:16:10 --> Input Class Initialized
INFO - 2016-07-19 16:16:10 --> Language Class Initialized
INFO - 2016-07-19 16:16:10 --> Loader Class Initialized
INFO - 2016-07-19 16:16:10 --> Helper loaded: url_helper
INFO - 2016-07-19 16:16:10 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:16:10 --> Helper loaded: html_helper
INFO - 2016-07-19 16:16:10 --> Helper loaded: form_helper
INFO - 2016-07-19 16:16:10 --> Helper loaded: file_helper
INFO - 2016-07-19 16:16:10 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:16:10 --> Database Driver Class Initialized
INFO - 2016-07-19 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:16:10 --> Form Validation Class Initialized
INFO - 2016-07-19 16:16:10 --> Email Class Initialized
INFO - 2016-07-19 16:16:10 --> Controller Class Initialized
DEBUG - 2016-07-19 16:16:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:16:10 --> Model Class Initialized
INFO - 2016-07-19 16:16:10 --> Model Class Initialized
INFO - 2016-07-19 16:16:10 --> Model Class Initialized
INFO - 2016-07-19 16:16:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:16:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:16:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-19 16:16:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:16:10 --> Final output sent to browser
DEBUG - 2016-07-19 16:16:10 --> Total execution time: 0.2612
INFO - 2016-07-19 16:16:12 --> Config Class Initialized
INFO - 2016-07-19 16:16:12 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:16:12 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:16:12 --> Utf8 Class Initialized
INFO - 2016-07-19 16:16:12 --> URI Class Initialized
INFO - 2016-07-19 16:16:12 --> Router Class Initialized
INFO - 2016-07-19 16:16:12 --> Output Class Initialized
INFO - 2016-07-19 16:16:12 --> Security Class Initialized
DEBUG - 2016-07-19 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:16:12 --> Input Class Initialized
INFO - 2016-07-19 16:16:12 --> Language Class Initialized
INFO - 2016-07-19 16:16:12 --> Loader Class Initialized
INFO - 2016-07-19 16:16:12 --> Helper loaded: url_helper
INFO - 2016-07-19 16:16:12 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:16:12 --> Helper loaded: html_helper
INFO - 2016-07-19 16:16:12 --> Helper loaded: form_helper
INFO - 2016-07-19 16:16:12 --> Helper loaded: file_helper
INFO - 2016-07-19 16:16:12 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:16:12 --> Database Driver Class Initialized
INFO - 2016-07-19 16:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:16:12 --> Form Validation Class Initialized
INFO - 2016-07-19 16:16:12 --> Email Class Initialized
INFO - 2016-07-19 16:16:12 --> Controller Class Initialized
DEBUG - 2016-07-19 16:16:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:16:12 --> Helper loaded: download_helper
INFO - 2016-07-19 16:16:12 --> Config Class Initialized
INFO - 2016-07-19 16:16:12 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:16:12 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:16:12 --> Utf8 Class Initialized
INFO - 2016-07-19 16:16:12 --> URI Class Initialized
INFO - 2016-07-19 16:16:12 --> Router Class Initialized
INFO - 2016-07-19 16:16:12 --> Output Class Initialized
INFO - 2016-07-19 16:16:12 --> Security Class Initialized
DEBUG - 2016-07-19 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:16:12 --> Input Class Initialized
INFO - 2016-07-19 16:16:12 --> Language Class Initialized
ERROR - 2016-07-19 16:16:12 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-19 16:16:12 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 321
INFO - 2016-07-19 16:17:36 --> Config Class Initialized
INFO - 2016-07-19 16:17:36 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:17:36 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:17:36 --> Utf8 Class Initialized
INFO - 2016-07-19 16:17:36 --> URI Class Initialized
INFO - 2016-07-19 16:17:36 --> Router Class Initialized
INFO - 2016-07-19 16:17:36 --> Output Class Initialized
INFO - 2016-07-19 16:17:36 --> Security Class Initialized
DEBUG - 2016-07-19 16:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:17:36 --> Input Class Initialized
INFO - 2016-07-19 16:17:36 --> Language Class Initialized
INFO - 2016-07-19 16:17:36 --> Loader Class Initialized
INFO - 2016-07-19 16:17:36 --> Helper loaded: url_helper
INFO - 2016-07-19 16:17:36 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:17:36 --> Helper loaded: html_helper
INFO - 2016-07-19 16:17:36 --> Helper loaded: form_helper
INFO - 2016-07-19 16:17:36 --> Helper loaded: file_helper
INFO - 2016-07-19 16:17:36 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:17:36 --> Database Driver Class Initialized
INFO - 2016-07-19 16:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:17:36 --> Form Validation Class Initialized
INFO - 2016-07-19 16:17:36 --> Email Class Initialized
INFO - 2016-07-19 16:17:36 --> Controller Class Initialized
DEBUG - 2016-07-19 16:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:17:36 --> Model Class Initialized
INFO - 2016-07-19 16:17:36 --> Model Class Initialized
INFO - 2016-07-19 16:17:36 --> Model Class Initialized
INFO - 2016-07-19 16:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-19 16:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:17:36 --> Final output sent to browser
DEBUG - 2016-07-19 16:17:36 --> Total execution time: 0.2425
INFO - 2016-07-19 16:17:39 --> Config Class Initialized
INFO - 2016-07-19 16:17:39 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:17:39 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:17:39 --> Utf8 Class Initialized
INFO - 2016-07-19 16:17:40 --> URI Class Initialized
INFO - 2016-07-19 16:17:40 --> Router Class Initialized
INFO - 2016-07-19 16:17:40 --> Output Class Initialized
INFO - 2016-07-19 16:17:40 --> Security Class Initialized
DEBUG - 2016-07-19 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:17:40 --> Input Class Initialized
INFO - 2016-07-19 16:17:40 --> Language Class Initialized
INFO - 2016-07-19 16:17:40 --> Loader Class Initialized
INFO - 2016-07-19 16:17:40 --> Helper loaded: url_helper
INFO - 2016-07-19 16:17:40 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:17:40 --> Helper loaded: html_helper
INFO - 2016-07-19 16:17:40 --> Helper loaded: form_helper
INFO - 2016-07-19 16:17:40 --> Helper loaded: file_helper
INFO - 2016-07-19 16:17:40 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:17:40 --> Database Driver Class Initialized
INFO - 2016-07-19 16:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:17:40 --> Form Validation Class Initialized
INFO - 2016-07-19 16:17:40 --> Email Class Initialized
INFO - 2016-07-19 16:17:40 --> Controller Class Initialized
DEBUG - 2016-07-19 16:17:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:17:40 --> Helper loaded: download_helper
INFO - 2016-07-19 16:17:40 --> Config Class Initialized
INFO - 2016-07-19 16:17:40 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:17:40 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:17:40 --> Utf8 Class Initialized
INFO - 2016-07-19 16:17:40 --> URI Class Initialized
INFO - 2016-07-19 16:17:40 --> Router Class Initialized
INFO - 2016-07-19 16:17:40 --> Output Class Initialized
INFO - 2016-07-19 16:17:40 --> Security Class Initialized
DEBUG - 2016-07-19 16:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:17:40 --> Input Class Initialized
INFO - 2016-07-19 16:17:40 --> Language Class Initialized
ERROR - 2016-07-19 16:17:40 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-19 16:17:40 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 321
INFO - 2016-07-19 16:21:22 --> Config Class Initialized
INFO - 2016-07-19 16:21:22 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:21:22 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:21:22 --> Utf8 Class Initialized
INFO - 2016-07-19 16:21:22 --> URI Class Initialized
INFO - 2016-07-19 16:21:22 --> Router Class Initialized
INFO - 2016-07-19 16:21:22 --> Output Class Initialized
INFO - 2016-07-19 16:21:22 --> Security Class Initialized
DEBUG - 2016-07-19 16:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:21:22 --> Input Class Initialized
INFO - 2016-07-19 16:21:22 --> Language Class Initialized
INFO - 2016-07-19 16:21:22 --> Loader Class Initialized
INFO - 2016-07-19 16:21:22 --> Helper loaded: url_helper
INFO - 2016-07-19 16:21:22 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:21:23 --> Helper loaded: html_helper
INFO - 2016-07-19 16:21:23 --> Helper loaded: form_helper
INFO - 2016-07-19 16:21:23 --> Helper loaded: file_helper
INFO - 2016-07-19 16:21:23 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:21:23 --> Database Driver Class Initialized
INFO - 2016-07-19 16:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:21:23 --> Form Validation Class Initialized
INFO - 2016-07-19 16:21:23 --> Email Class Initialized
INFO - 2016-07-19 16:21:23 --> Controller Class Initialized
DEBUG - 2016-07-19 16:21:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:21:23 --> Model Class Initialized
INFO - 2016-07-19 16:21:23 --> Model Class Initialized
INFO - 2016-07-19 16:21:23 --> Model Class Initialized
INFO - 2016-07-19 16:21:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:21:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:21:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-19 16:21:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:21:23 --> Final output sent to browser
DEBUG - 2016-07-19 16:21:23 --> Total execution time: 0.2831
INFO - 2016-07-19 16:27:40 --> Config Class Initialized
INFO - 2016-07-19 16:27:40 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:27:40 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:27:40 --> Utf8 Class Initialized
INFO - 2016-07-19 16:27:40 --> URI Class Initialized
INFO - 2016-07-19 16:27:40 --> Router Class Initialized
INFO - 2016-07-19 16:27:40 --> Output Class Initialized
INFO - 2016-07-19 16:27:40 --> Security Class Initialized
DEBUG - 2016-07-19 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:27:40 --> Input Class Initialized
INFO - 2016-07-19 16:27:40 --> Language Class Initialized
INFO - 2016-07-19 16:27:40 --> Loader Class Initialized
INFO - 2016-07-19 16:27:40 --> Helper loaded: url_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: html_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: form_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: file_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:27:40 --> Database Driver Class Initialized
INFO - 2016-07-19 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:27:40 --> Form Validation Class Initialized
INFO - 2016-07-19 16:27:40 --> Email Class Initialized
INFO - 2016-07-19 16:27:40 --> Controller Class Initialized
INFO - 2016-07-19 16:27:40 --> Config Class Initialized
INFO - 2016-07-19 16:27:40 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:27:40 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:27:40 --> Utf8 Class Initialized
INFO - 2016-07-19 16:27:40 --> URI Class Initialized
INFO - 2016-07-19 16:27:40 --> Router Class Initialized
INFO - 2016-07-19 16:27:40 --> Output Class Initialized
INFO - 2016-07-19 16:27:40 --> Security Class Initialized
DEBUG - 2016-07-19 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:27:40 --> Input Class Initialized
INFO - 2016-07-19 16:27:40 --> Language Class Initialized
INFO - 2016-07-19 16:27:40 --> Loader Class Initialized
INFO - 2016-07-19 16:27:40 --> Helper loaded: url_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: html_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: form_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: file_helper
INFO - 2016-07-19 16:27:40 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:27:40 --> Database Driver Class Initialized
INFO - 2016-07-19 16:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:27:40 --> Form Validation Class Initialized
INFO - 2016-07-19 16:27:40 --> Email Class Initialized
INFO - 2016-07-19 16:27:40 --> Controller Class Initialized
INFO - 2016-07-19 16:27:40 --> Model Class Initialized
DEBUG - 2016-07-19 16:27:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:27:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-19 16:27:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:27:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-19 16:27:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:27:40 --> Final output sent to browser
DEBUG - 2016-07-19 16:27:40 --> Total execution time: 0.2474
INFO - 2016-07-19 16:27:45 --> Config Class Initialized
INFO - 2016-07-19 16:27:45 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:27:45 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:27:45 --> Utf8 Class Initialized
INFO - 2016-07-19 16:27:45 --> URI Class Initialized
INFO - 2016-07-19 16:27:45 --> Router Class Initialized
INFO - 2016-07-19 16:27:45 --> Output Class Initialized
INFO - 2016-07-19 16:27:45 --> Security Class Initialized
DEBUG - 2016-07-19 16:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:27:45 --> Input Class Initialized
INFO - 2016-07-19 16:27:45 --> Language Class Initialized
ERROR - 2016-07-19 16:27:45 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-19 16:27:56 --> Config Class Initialized
INFO - 2016-07-19 16:27:56 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:27:56 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:27:56 --> Utf8 Class Initialized
INFO - 2016-07-19 16:27:56 --> URI Class Initialized
INFO - 2016-07-19 16:27:56 --> Router Class Initialized
INFO - 2016-07-19 16:27:56 --> Output Class Initialized
INFO - 2016-07-19 16:27:56 --> Security Class Initialized
DEBUG - 2016-07-19 16:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:27:56 --> Input Class Initialized
INFO - 2016-07-19 16:27:56 --> Language Class Initialized
INFO - 2016-07-19 16:27:56 --> Loader Class Initialized
INFO - 2016-07-19 16:27:56 --> Helper loaded: url_helper
INFO - 2016-07-19 16:27:56 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:27:56 --> Helper loaded: html_helper
INFO - 2016-07-19 16:27:56 --> Helper loaded: form_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: file_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:27:57 --> Database Driver Class Initialized
INFO - 2016-07-19 16:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:27:57 --> Form Validation Class Initialized
INFO - 2016-07-19 16:27:57 --> Email Class Initialized
INFO - 2016-07-19 16:27:57 --> Controller Class Initialized
INFO - 2016-07-19 16:27:57 --> Model Class Initialized
DEBUG - 2016-07-19 16:27:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:27:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-19 16:27:57 --> Config Class Initialized
INFO - 2016-07-19 16:27:57 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:27:57 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:27:57 --> Utf8 Class Initialized
INFO - 2016-07-19 16:27:57 --> URI Class Initialized
INFO - 2016-07-19 16:27:57 --> Router Class Initialized
INFO - 2016-07-19 16:27:57 --> Output Class Initialized
INFO - 2016-07-19 16:27:57 --> Security Class Initialized
DEBUG - 2016-07-19 16:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:27:57 --> Input Class Initialized
INFO - 2016-07-19 16:27:57 --> Language Class Initialized
INFO - 2016-07-19 16:27:57 --> Loader Class Initialized
INFO - 2016-07-19 16:27:57 --> Helper loaded: url_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: html_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: form_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: file_helper
INFO - 2016-07-19 16:27:57 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:27:57 --> Database Driver Class Initialized
INFO - 2016-07-19 16:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:27:57 --> Form Validation Class Initialized
INFO - 2016-07-19 16:27:57 --> Email Class Initialized
INFO - 2016-07-19 16:27:57 --> Controller Class Initialized
DEBUG - 2016-07-19 16:27:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:27:57 --> Model Class Initialized
INFO - 2016-07-19 16:27:57 --> Model Class Initialized
INFO - 2016-07-19 16:27:57 --> Model Class Initialized
INFO - 2016-07-19 16:27:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 16:27:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 16:27:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-19 16:27:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 16:27:57 --> Final output sent to browser
DEBUG - 2016-07-19 16:27:57 --> Total execution time: 0.2272
INFO - 2016-07-19 16:28:18 --> Config Class Initialized
INFO - 2016-07-19 16:28:18 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:28:18 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:28:18 --> Utf8 Class Initialized
INFO - 2016-07-19 16:28:18 --> URI Class Initialized
INFO - 2016-07-19 16:28:18 --> Router Class Initialized
INFO - 2016-07-19 16:28:18 --> Output Class Initialized
INFO - 2016-07-19 16:28:18 --> Security Class Initialized
DEBUG - 2016-07-19 16:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:28:18 --> Input Class Initialized
INFO - 2016-07-19 16:28:18 --> Language Class Initialized
INFO - 2016-07-19 16:28:18 --> Loader Class Initialized
INFO - 2016-07-19 16:28:18 --> Helper loaded: url_helper
INFO - 2016-07-19 16:28:18 --> Helper loaded: utils_helper
INFO - 2016-07-19 16:28:18 --> Helper loaded: html_helper
INFO - 2016-07-19 16:28:18 --> Helper loaded: form_helper
INFO - 2016-07-19 16:28:18 --> Helper loaded: file_helper
INFO - 2016-07-19 16:28:18 --> Helper loaded: myemail_helper
INFO - 2016-07-19 16:28:18 --> Database Driver Class Initialized
INFO - 2016-07-19 16:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 16:28:18 --> Form Validation Class Initialized
INFO - 2016-07-19 16:28:18 --> Email Class Initialized
INFO - 2016-07-19 16:28:18 --> Controller Class Initialized
DEBUG - 2016-07-19 16:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 16:28:18 --> Helper loaded: download_helper
INFO - 2016-07-19 16:28:18 --> Config Class Initialized
INFO - 2016-07-19 16:28:18 --> Hooks Class Initialized
DEBUG - 2016-07-19 16:28:18 --> UTF-8 Support Enabled
INFO - 2016-07-19 16:28:18 --> Utf8 Class Initialized
INFO - 2016-07-19 16:28:18 --> URI Class Initialized
INFO - 2016-07-19 16:28:18 --> Router Class Initialized
INFO - 2016-07-19 16:28:18 --> Output Class Initialized
INFO - 2016-07-19 16:28:18 --> Security Class Initialized
DEBUG - 2016-07-19 16:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 16:28:18 --> Input Class Initialized
INFO - 2016-07-19 16:28:18 --> Language Class Initialized
ERROR - 2016-07-19 16:28:18 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-19 16:28:18 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 321
INFO - 2016-07-19 17:39:54 --> Config Class Initialized
INFO - 2016-07-19 17:39:54 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:39:54 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:39:54 --> Utf8 Class Initialized
INFO - 2016-07-19 17:39:54 --> URI Class Initialized
INFO - 2016-07-19 17:39:54 --> Router Class Initialized
INFO - 2016-07-19 17:39:54 --> Output Class Initialized
INFO - 2016-07-19 17:39:54 --> Security Class Initialized
DEBUG - 2016-07-19 17:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:39:54 --> Input Class Initialized
INFO - 2016-07-19 17:39:54 --> Language Class Initialized
INFO - 2016-07-19 17:39:54 --> Loader Class Initialized
INFO - 2016-07-19 17:39:54 --> Helper loaded: url_helper
INFO - 2016-07-19 17:39:54 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:39:54 --> Helper loaded: html_helper
INFO - 2016-07-19 17:39:54 --> Helper loaded: form_helper
INFO - 2016-07-19 17:39:54 --> Helper loaded: file_helper
INFO - 2016-07-19 17:39:54 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:39:54 --> Database Driver Class Initialized
INFO - 2016-07-19 17:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:39:54 --> Form Validation Class Initialized
INFO - 2016-07-19 17:39:54 --> Email Class Initialized
INFO - 2016-07-19 17:39:54 --> Controller Class Initialized
DEBUG - 2016-07-19 17:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 17:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-19 17:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-19 17:39:54 --> Model Class Initialized
INFO - 2016-07-19 17:39:54 --> Model Class Initialized
INFO - 2016-07-19 17:39:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-19 17:39:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-19 17:39:55 --> Final output sent to browser
DEBUG - 2016-07-19 17:39:55 --> Total execution time: 0.4297
INFO - 2016-07-19 17:39:59 --> Config Class Initialized
INFO - 2016-07-19 17:39:59 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:39:59 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:39:59 --> Utf8 Class Initialized
INFO - 2016-07-19 17:39:59 --> URI Class Initialized
INFO - 2016-07-19 17:39:59 --> Router Class Initialized
INFO - 2016-07-19 17:39:59 --> Output Class Initialized
INFO - 2016-07-19 17:39:59 --> Security Class Initialized
DEBUG - 2016-07-19 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:39:59 --> Input Class Initialized
INFO - 2016-07-19 17:39:59 --> Language Class Initialized
INFO - 2016-07-19 17:39:59 --> Loader Class Initialized
INFO - 2016-07-19 17:39:59 --> Helper loaded: url_helper
INFO - 2016-07-19 17:39:59 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:39:59 --> Helper loaded: html_helper
INFO - 2016-07-19 17:39:59 --> Helper loaded: form_helper
INFO - 2016-07-19 17:39:59 --> Helper loaded: file_helper
INFO - 2016-07-19 17:39:59 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:39:59 --> Database Driver Class Initialized
INFO - 2016-07-19 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:39:59 --> Form Validation Class Initialized
INFO - 2016-07-19 17:39:59 --> Email Class Initialized
INFO - 2016-07-19 17:39:59 --> Controller Class Initialized
DEBUG - 2016-07-19 17:39:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-07-19 17:40:00 --> Severity: Notice --> Undefined property: Books::$excel D:\wamp\www\library.pnc.lan\application\controllers\Books.php 301
ERROR - 2016-07-19 17:40:00 --> Severity: Error --> Call to a member function setActiveSheetIndex() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 301
INFO - 2016-07-19 17:44:54 --> Config Class Initialized
INFO - 2016-07-19 17:44:54 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:44:54 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:44:54 --> Utf8 Class Initialized
INFO - 2016-07-19 17:44:54 --> URI Class Initialized
INFO - 2016-07-19 17:44:54 --> Router Class Initialized
INFO - 2016-07-19 17:44:54 --> Output Class Initialized
INFO - 2016-07-19 17:44:54 --> Security Class Initialized
DEBUG - 2016-07-19 17:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:44:54 --> Input Class Initialized
INFO - 2016-07-19 17:44:54 --> Language Class Initialized
INFO - 2016-07-19 17:44:54 --> Loader Class Initialized
INFO - 2016-07-19 17:44:54 --> Helper loaded: url_helper
INFO - 2016-07-19 17:44:54 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:44:54 --> Helper loaded: html_helper
INFO - 2016-07-19 17:44:54 --> Helper loaded: form_helper
INFO - 2016-07-19 17:44:54 --> Helper loaded: file_helper
INFO - 2016-07-19 17:44:54 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:44:54 --> Database Driver Class Initialized
INFO - 2016-07-19 17:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:44:54 --> Form Validation Class Initialized
INFO - 2016-07-19 17:44:54 --> Email Class Initialized
INFO - 2016-07-19 17:44:54 --> Controller Class Initialized
DEBUG - 2016-07-19 17:44:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-07-19 17:44:54 --> Severity: Notice --> Undefined property: Books::$books_model D:\wamp\www\library.pnc.lan\application\controllers\Books.php 312
ERROR - 2016-07-19 17:44:54 --> Severity: Error --> Call to a member function getBooks() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 312
INFO - 2016-07-19 17:48:00 --> Config Class Initialized
INFO - 2016-07-19 17:48:00 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:48:00 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:48:00 --> Utf8 Class Initialized
INFO - 2016-07-19 17:48:00 --> URI Class Initialized
INFO - 2016-07-19 17:48:00 --> Router Class Initialized
INFO - 2016-07-19 17:48:00 --> Output Class Initialized
INFO - 2016-07-19 17:48:00 --> Security Class Initialized
DEBUG - 2016-07-19 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:48:00 --> Input Class Initialized
INFO - 2016-07-19 17:48:00 --> Language Class Initialized
INFO - 2016-07-19 17:48:00 --> Loader Class Initialized
INFO - 2016-07-19 17:48:00 --> Helper loaded: url_helper
INFO - 2016-07-19 17:48:00 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:48:00 --> Helper loaded: html_helper
INFO - 2016-07-19 17:48:00 --> Helper loaded: form_helper
INFO - 2016-07-19 17:48:00 --> Helper loaded: file_helper
INFO - 2016-07-19 17:48:00 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:48:00 --> Database Driver Class Initialized
INFO - 2016-07-19 17:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:48:00 --> Form Validation Class Initialized
INFO - 2016-07-19 17:48:00 --> Email Class Initialized
INFO - 2016-07-19 17:48:00 --> Controller Class Initialized
DEBUG - 2016-07-19 17:48:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 17:48:00 --> Model Class Initialized
INFO - 2016-07-19 17:48:00 --> Model Class Initialized
ERROR - 2016-07-19 17:48:00 --> Severity: Error --> Cannot use object of type stdClass as array D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
INFO - 2016-07-19 17:58:37 --> Config Class Initialized
INFO - 2016-07-19 17:58:37 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:58:37 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:58:37 --> Utf8 Class Initialized
INFO - 2016-07-19 17:58:37 --> URI Class Initialized
INFO - 2016-07-19 17:58:37 --> Router Class Initialized
INFO - 2016-07-19 17:58:37 --> Output Class Initialized
INFO - 2016-07-19 17:58:37 --> Security Class Initialized
DEBUG - 2016-07-19 17:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:58:37 --> Input Class Initialized
INFO - 2016-07-19 17:58:38 --> Language Class Initialized
INFO - 2016-07-19 17:58:38 --> Loader Class Initialized
INFO - 2016-07-19 17:58:38 --> Helper loaded: url_helper
INFO - 2016-07-19 17:58:38 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:58:38 --> Helper loaded: html_helper
INFO - 2016-07-19 17:58:38 --> Helper loaded: form_helper
INFO - 2016-07-19 17:58:38 --> Helper loaded: file_helper
INFO - 2016-07-19 17:58:38 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:58:38 --> Database Driver Class Initialized
INFO - 2016-07-19 17:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:58:38 --> Form Validation Class Initialized
INFO - 2016-07-19 17:58:38 --> Email Class Initialized
INFO - 2016-07-19 17:58:38 --> Controller Class Initialized
DEBUG - 2016-07-19 17:58:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 17:58:38 --> Model Class Initialized
INFO - 2016-07-19 17:58:38 --> Model Class Initialized
ERROR - 2016-07-19 17:58:38 --> Severity: Error --> Cannot use object of type stdClass as array D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
INFO - 2016-07-19 17:59:47 --> Config Class Initialized
INFO - 2016-07-19 17:59:47 --> Hooks Class Initialized
DEBUG - 2016-07-19 17:59:47 --> UTF-8 Support Enabled
INFO - 2016-07-19 17:59:47 --> Utf8 Class Initialized
INFO - 2016-07-19 17:59:47 --> URI Class Initialized
INFO - 2016-07-19 17:59:47 --> Router Class Initialized
INFO - 2016-07-19 17:59:47 --> Output Class Initialized
INFO - 2016-07-19 17:59:47 --> Security Class Initialized
DEBUG - 2016-07-19 17:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 17:59:47 --> Input Class Initialized
INFO - 2016-07-19 17:59:47 --> Language Class Initialized
INFO - 2016-07-19 17:59:47 --> Loader Class Initialized
INFO - 2016-07-19 17:59:47 --> Helper loaded: url_helper
INFO - 2016-07-19 17:59:47 --> Helper loaded: utils_helper
INFO - 2016-07-19 17:59:47 --> Helper loaded: html_helper
INFO - 2016-07-19 17:59:47 --> Helper loaded: form_helper
INFO - 2016-07-19 17:59:47 --> Helper loaded: file_helper
INFO - 2016-07-19 17:59:47 --> Helper loaded: myemail_helper
INFO - 2016-07-19 17:59:47 --> Database Driver Class Initialized
INFO - 2016-07-19 17:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 17:59:47 --> Form Validation Class Initialized
INFO - 2016-07-19 17:59:47 --> Email Class Initialized
INFO - 2016-07-19 17:59:47 --> Controller Class Initialized
DEBUG - 2016-07-19 17:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 17:59:47 --> Model Class Initialized
INFO - 2016-07-19 17:59:47 --> Model Class Initialized
ERROR - 2016-07-19 17:59:47 --> Severity: Error --> Call to a member function result_array() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 316
INFO - 2016-07-19 18:03:56 --> Config Class Initialized
INFO - 2016-07-19 18:03:56 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:03:56 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:03:56 --> Utf8 Class Initialized
INFO - 2016-07-19 18:03:56 --> URI Class Initialized
INFO - 2016-07-19 18:03:56 --> Router Class Initialized
INFO - 2016-07-19 18:03:56 --> Output Class Initialized
INFO - 2016-07-19 18:03:56 --> Security Class Initialized
DEBUG - 2016-07-19 18:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:03:56 --> Input Class Initialized
INFO - 2016-07-19 18:03:56 --> Language Class Initialized
INFO - 2016-07-19 18:03:56 --> Loader Class Initialized
INFO - 2016-07-19 18:03:56 --> Helper loaded: url_helper
INFO - 2016-07-19 18:03:56 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:03:56 --> Helper loaded: html_helper
INFO - 2016-07-19 18:03:56 --> Helper loaded: form_helper
INFO - 2016-07-19 18:03:56 --> Helper loaded: file_helper
INFO - 2016-07-19 18:03:56 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:03:56 --> Database Driver Class Initialized
INFO - 2016-07-19 18:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:03:56 --> Form Validation Class Initialized
INFO - 2016-07-19 18:03:56 --> Email Class Initialized
INFO - 2016-07-19 18:03:56 --> Controller Class Initialized
DEBUG - 2016-07-19 18:03:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:03:56 --> Model Class Initialized
INFO - 2016-07-19 18:03:56 --> Model Class Initialized
ERROR - 2016-07-19 18:03:56 --> Severity: Error --> Call to a member function result_array() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 316
INFO - 2016-07-19 18:06:44 --> Config Class Initialized
INFO - 2016-07-19 18:06:44 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:06:44 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:06:44 --> Utf8 Class Initialized
INFO - 2016-07-19 18:06:44 --> URI Class Initialized
INFO - 2016-07-19 18:06:44 --> Router Class Initialized
INFO - 2016-07-19 18:06:44 --> Output Class Initialized
INFO - 2016-07-19 18:06:44 --> Security Class Initialized
DEBUG - 2016-07-19 18:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:06:44 --> Input Class Initialized
INFO - 2016-07-19 18:06:44 --> Language Class Initialized
INFO - 2016-07-19 18:06:44 --> Loader Class Initialized
INFO - 2016-07-19 18:06:44 --> Helper loaded: url_helper
INFO - 2016-07-19 18:06:44 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:06:44 --> Helper loaded: html_helper
INFO - 2016-07-19 18:06:44 --> Helper loaded: form_helper
INFO - 2016-07-19 18:06:44 --> Helper loaded: file_helper
INFO - 2016-07-19 18:06:44 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:06:44 --> Database Driver Class Initialized
INFO - 2016-07-19 18:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:06:44 --> Form Validation Class Initialized
INFO - 2016-07-19 18:06:44 --> Email Class Initialized
INFO - 2016-07-19 18:06:44 --> Controller Class Initialized
DEBUG - 2016-07-19 18:06:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:06:44 --> Model Class Initialized
INFO - 2016-07-19 18:06:44 --> Model Class Initialized
ERROR - 2016-07-19 18:06:44 --> Query error: Unknown column 'b_ide' in 'order clause' - Invalid query: SELECT *
FROM `books`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
ORDER BY `b_ide` DESC
INFO - 2016-07-19 18:06:44 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-19 18:07:47 --> Config Class Initialized
INFO - 2016-07-19 18:07:47 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:07:47 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:07:47 --> Utf8 Class Initialized
INFO - 2016-07-19 18:07:47 --> URI Class Initialized
INFO - 2016-07-19 18:07:47 --> Router Class Initialized
INFO - 2016-07-19 18:07:47 --> Output Class Initialized
INFO - 2016-07-19 18:07:47 --> Security Class Initialized
DEBUG - 2016-07-19 18:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:07:47 --> Input Class Initialized
INFO - 2016-07-19 18:07:47 --> Language Class Initialized
INFO - 2016-07-19 18:07:47 --> Loader Class Initialized
INFO - 2016-07-19 18:07:47 --> Helper loaded: url_helper
INFO - 2016-07-19 18:07:47 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:07:47 --> Helper loaded: html_helper
INFO - 2016-07-19 18:07:47 --> Helper loaded: form_helper
INFO - 2016-07-19 18:07:47 --> Helper loaded: file_helper
INFO - 2016-07-19 18:07:47 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:07:48 --> Database Driver Class Initialized
INFO - 2016-07-19 18:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:07:48 --> Form Validation Class Initialized
INFO - 2016-07-19 18:07:48 --> Email Class Initialized
INFO - 2016-07-19 18:07:48 --> Controller Class Initialized
DEBUG - 2016-07-19 18:07:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:07:48 --> Model Class Initialized
INFO - 2016-07-19 18:07:48 --> Model Class Initialized
ERROR - 2016-07-19 18:07:48 --> Severity: Error --> Call to a member function result_array() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 316
INFO - 2016-07-19 18:09:40 --> Config Class Initialized
INFO - 2016-07-19 18:09:40 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:09:40 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:09:40 --> Utf8 Class Initialized
INFO - 2016-07-19 18:09:40 --> URI Class Initialized
INFO - 2016-07-19 18:09:40 --> Router Class Initialized
INFO - 2016-07-19 18:09:40 --> Output Class Initialized
INFO - 2016-07-19 18:09:40 --> Security Class Initialized
DEBUG - 2016-07-19 18:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:09:40 --> Input Class Initialized
INFO - 2016-07-19 18:09:40 --> Language Class Initialized
INFO - 2016-07-19 18:09:40 --> Loader Class Initialized
INFO - 2016-07-19 18:09:40 --> Helper loaded: url_helper
INFO - 2016-07-19 18:09:40 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:09:40 --> Helper loaded: html_helper
INFO - 2016-07-19 18:09:40 --> Helper loaded: form_helper
INFO - 2016-07-19 18:09:40 --> Helper loaded: file_helper
INFO - 2016-07-19 18:09:40 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:09:40 --> Database Driver Class Initialized
INFO - 2016-07-19 18:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:09:40 --> Form Validation Class Initialized
INFO - 2016-07-19 18:09:40 --> Email Class Initialized
INFO - 2016-07-19 18:09:40 --> Controller Class Initialized
DEBUG - 2016-07-19 18:09:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:09:40 --> Model Class Initialized
INFO - 2016-07-19 18:09:40 --> Model Class Initialized
ERROR - 2016-07-19 18:09:40 --> Severity: Error --> Call to a member function result_array() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 314
INFO - 2016-07-19 18:14:45 --> Config Class Initialized
INFO - 2016-07-19 18:14:45 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:14:45 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:14:45 --> Utf8 Class Initialized
INFO - 2016-07-19 18:14:45 --> URI Class Initialized
INFO - 2016-07-19 18:14:45 --> Router Class Initialized
INFO - 2016-07-19 18:14:45 --> Output Class Initialized
INFO - 2016-07-19 18:14:45 --> Security Class Initialized
DEBUG - 2016-07-19 18:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:14:45 --> Input Class Initialized
INFO - 2016-07-19 18:14:45 --> Language Class Initialized
INFO - 2016-07-19 18:14:45 --> Loader Class Initialized
INFO - 2016-07-19 18:14:45 --> Helper loaded: url_helper
INFO - 2016-07-19 18:14:45 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:14:45 --> Helper loaded: html_helper
INFO - 2016-07-19 18:14:45 --> Helper loaded: form_helper
INFO - 2016-07-19 18:14:45 --> Helper loaded: file_helper
INFO - 2016-07-19 18:14:45 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:14:45 --> Database Driver Class Initialized
INFO - 2016-07-19 18:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:14:45 --> Form Validation Class Initialized
INFO - 2016-07-19 18:14:45 --> Email Class Initialized
INFO - 2016-07-19 18:14:45 --> Controller Class Initialized
DEBUG - 2016-07-19 18:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:14:45 --> Model Class Initialized
INFO - 2016-07-19 18:14:45 --> Model Class Initialized
ERROR - 2016-07-19 18:14:45 --> Severity: Error --> Function name must be a string D:\wamp\www\library.pnc.lan\application\controllers\Books.php 316
INFO - 2016-07-19 18:15:09 --> Config Class Initialized
INFO - 2016-07-19 18:15:09 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:15:09 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:15:09 --> Utf8 Class Initialized
INFO - 2016-07-19 18:15:09 --> URI Class Initialized
INFO - 2016-07-19 18:15:09 --> Router Class Initialized
INFO - 2016-07-19 18:15:09 --> Output Class Initialized
INFO - 2016-07-19 18:15:09 --> Security Class Initialized
DEBUG - 2016-07-19 18:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:15:09 --> Input Class Initialized
INFO - 2016-07-19 18:15:09 --> Language Class Initialized
INFO - 2016-07-19 18:15:09 --> Loader Class Initialized
INFO - 2016-07-19 18:15:09 --> Helper loaded: url_helper
INFO - 2016-07-19 18:15:09 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:15:09 --> Helper loaded: html_helper
INFO - 2016-07-19 18:15:09 --> Helper loaded: form_helper
INFO - 2016-07-19 18:15:09 --> Helper loaded: file_helper
INFO - 2016-07-19 18:15:09 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:15:09 --> Database Driver Class Initialized
INFO - 2016-07-19 18:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:15:09 --> Form Validation Class Initialized
INFO - 2016-07-19 18:15:09 --> Email Class Initialized
INFO - 2016-07-19 18:15:09 --> Controller Class Initialized
DEBUG - 2016-07-19 18:15:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:15:09 --> Model Class Initialized
INFO - 2016-07-19 18:15:09 --> Model Class Initialized
ERROR - 2016-07-19 18:15:09 --> Severity: Notice --> Array to string conversion D:\wamp\www\library.pnc.lan\application\controllers\Books.php 316
INFO - 2016-07-19 18:37:39 --> Config Class Initialized
INFO - 2016-07-19 18:37:39 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:37:39 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:37:39 --> Utf8 Class Initialized
INFO - 2016-07-19 18:37:39 --> URI Class Initialized
INFO - 2016-07-19 18:37:39 --> Router Class Initialized
INFO - 2016-07-19 18:37:39 --> Output Class Initialized
INFO - 2016-07-19 18:37:39 --> Security Class Initialized
DEBUG - 2016-07-19 18:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:37:39 --> Input Class Initialized
INFO - 2016-07-19 18:37:39 --> Language Class Initialized
INFO - 2016-07-19 18:37:39 --> Loader Class Initialized
INFO - 2016-07-19 18:37:39 --> Helper loaded: url_helper
INFO - 2016-07-19 18:37:39 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:37:39 --> Helper loaded: html_helper
INFO - 2016-07-19 18:37:39 --> Helper loaded: form_helper
INFO - 2016-07-19 18:37:39 --> Helper loaded: file_helper
INFO - 2016-07-19 18:37:39 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:37:39 --> Database Driver Class Initialized
INFO - 2016-07-19 18:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:37:39 --> Form Validation Class Initialized
INFO - 2016-07-19 18:37:39 --> Email Class Initialized
INFO - 2016-07-19 18:37:39 --> Controller Class Initialized
DEBUG - 2016-07-19 18:37:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:37:39 --> Model Class Initialized
INFO - 2016-07-19 18:37:39 --> Model Class Initialized
ERROR - 2016-07-19 18:37:39 --> Severity: Notice --> Undefined property: Books::$excel D:\wamp\www\library.pnc.lan\application\controllers\Books.php 323
ERROR - 2016-07-19 18:37:39 --> Severity: Error --> Call to a member function getActiveSheet() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 323
INFO - 2016-07-19 18:38:09 --> Config Class Initialized
INFO - 2016-07-19 18:38:09 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:38:09 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:38:09 --> Utf8 Class Initialized
INFO - 2016-07-19 18:38:09 --> URI Class Initialized
INFO - 2016-07-19 18:38:09 --> Router Class Initialized
INFO - 2016-07-19 18:38:09 --> Output Class Initialized
INFO - 2016-07-19 18:38:09 --> Security Class Initialized
DEBUG - 2016-07-19 18:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:38:09 --> Input Class Initialized
INFO - 2016-07-19 18:38:09 --> Language Class Initialized
INFO - 2016-07-19 18:38:09 --> Loader Class Initialized
INFO - 2016-07-19 18:38:09 --> Helper loaded: url_helper
INFO - 2016-07-19 18:38:09 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:38:09 --> Helper loaded: html_helper
INFO - 2016-07-19 18:38:09 --> Helper loaded: form_helper
INFO - 2016-07-19 18:38:09 --> Helper loaded: file_helper
INFO - 2016-07-19 18:38:09 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:38:09 --> Database Driver Class Initialized
INFO - 2016-07-19 18:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:38:09 --> Form Validation Class Initialized
INFO - 2016-07-19 18:38:09 --> Email Class Initialized
INFO - 2016-07-19 18:38:09 --> Controller Class Initialized
DEBUG - 2016-07-19 18:38:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:38:09 --> Model Class Initialized
INFO - 2016-07-19 18:38:10 --> Model Class Initialized
INFO - 2016-07-19 18:38:11 --> Final output sent to browser
DEBUG - 2016-07-19 18:38:11 --> Total execution time: 1.3044
INFO - 2016-07-19 18:52:49 --> Config Class Initialized
INFO - 2016-07-19 18:52:50 --> Hooks Class Initialized
DEBUG - 2016-07-19 18:52:50 --> UTF-8 Support Enabled
INFO - 2016-07-19 18:52:50 --> Utf8 Class Initialized
INFO - 2016-07-19 18:52:50 --> URI Class Initialized
INFO - 2016-07-19 18:52:50 --> Router Class Initialized
INFO - 2016-07-19 18:52:50 --> Output Class Initialized
INFO - 2016-07-19 18:52:50 --> Security Class Initialized
DEBUG - 2016-07-19 18:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 18:52:50 --> Input Class Initialized
INFO - 2016-07-19 18:52:50 --> Language Class Initialized
INFO - 2016-07-19 18:52:50 --> Loader Class Initialized
INFO - 2016-07-19 18:52:50 --> Helper loaded: url_helper
INFO - 2016-07-19 18:52:50 --> Helper loaded: utils_helper
INFO - 2016-07-19 18:52:50 --> Helper loaded: html_helper
INFO - 2016-07-19 18:52:50 --> Helper loaded: form_helper
INFO - 2016-07-19 18:52:50 --> Helper loaded: file_helper
INFO - 2016-07-19 18:52:50 --> Helper loaded: myemail_helper
INFO - 2016-07-19 18:52:50 --> Database Driver Class Initialized
INFO - 2016-07-19 18:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 18:52:50 --> Form Validation Class Initialized
INFO - 2016-07-19 18:52:50 --> Email Class Initialized
INFO - 2016-07-19 18:52:50 --> Controller Class Initialized
DEBUG - 2016-07-19 18:52:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 18:52:50 --> Model Class Initialized
INFO - 2016-07-19 18:52:50 --> Model Class Initialized
ERROR - 2016-07-19 18:52:50 --> Severity: Error --> Call to a member function list_fields() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 319
INFO - 2016-07-19 19:01:03 --> Config Class Initialized
INFO - 2016-07-19 19:01:03 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:01:03 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:01:03 --> Utf8 Class Initialized
INFO - 2016-07-19 19:01:03 --> URI Class Initialized
INFO - 2016-07-19 19:01:03 --> Router Class Initialized
INFO - 2016-07-19 19:01:03 --> Output Class Initialized
INFO - 2016-07-19 19:01:03 --> Security Class Initialized
DEBUG - 2016-07-19 19:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:01:03 --> Input Class Initialized
INFO - 2016-07-19 19:01:03 --> Language Class Initialized
INFO - 2016-07-19 19:01:03 --> Loader Class Initialized
INFO - 2016-07-19 19:01:03 --> Helper loaded: url_helper
INFO - 2016-07-19 19:01:03 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:01:03 --> Helper loaded: html_helper
INFO - 2016-07-19 19:01:03 --> Helper loaded: form_helper
INFO - 2016-07-19 19:01:03 --> Helper loaded: file_helper
INFO - 2016-07-19 19:01:03 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:01:03 --> Database Driver Class Initialized
INFO - 2016-07-19 19:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:01:03 --> Form Validation Class Initialized
INFO - 2016-07-19 19:01:03 --> Email Class Initialized
INFO - 2016-07-19 19:01:03 --> Controller Class Initialized
DEBUG - 2016-07-19 19:01:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:01:03 --> Model Class Initialized
INFO - 2016-07-19 19:01:03 --> Model Class Initialized
INFO - 2016-07-19 19:01:03 --> Final output sent to browser
DEBUG - 2016-07-19 19:01:03 --> Total execution time: 0.4933
INFO - 2016-07-19 19:03:57 --> Config Class Initialized
INFO - 2016-07-19 19:03:57 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:03:57 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:03:57 --> Utf8 Class Initialized
INFO - 2016-07-19 19:03:57 --> URI Class Initialized
INFO - 2016-07-19 19:03:57 --> Router Class Initialized
INFO - 2016-07-19 19:03:57 --> Output Class Initialized
INFO - 2016-07-19 19:03:57 --> Security Class Initialized
DEBUG - 2016-07-19 19:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:03:57 --> Input Class Initialized
INFO - 2016-07-19 19:03:57 --> Language Class Initialized
INFO - 2016-07-19 19:03:57 --> Loader Class Initialized
INFO - 2016-07-19 19:03:57 --> Helper loaded: url_helper
INFO - 2016-07-19 19:03:57 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:03:57 --> Helper loaded: html_helper
INFO - 2016-07-19 19:03:57 --> Helper loaded: form_helper
INFO - 2016-07-19 19:03:57 --> Helper loaded: file_helper
INFO - 2016-07-19 19:03:57 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:03:57 --> Database Driver Class Initialized
INFO - 2016-07-19 19:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:03:57 --> Form Validation Class Initialized
INFO - 2016-07-19 19:03:57 --> Email Class Initialized
INFO - 2016-07-19 19:03:57 --> Controller Class Initialized
DEBUG - 2016-07-19 19:03:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:03:57 --> Model Class Initialized
INFO - 2016-07-19 19:03:57 --> Model Class Initialized
INFO - 2016-07-19 19:03:57 --> Final output sent to browser
DEBUG - 2016-07-19 19:03:57 --> Total execution time: 0.4704
INFO - 2016-07-19 19:04:22 --> Config Class Initialized
INFO - 2016-07-19 19:04:22 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:04:22 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:04:22 --> Utf8 Class Initialized
INFO - 2016-07-19 19:04:22 --> URI Class Initialized
INFO - 2016-07-19 19:04:22 --> Router Class Initialized
INFO - 2016-07-19 19:04:23 --> Output Class Initialized
INFO - 2016-07-19 19:04:23 --> Security Class Initialized
DEBUG - 2016-07-19 19:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:04:23 --> Input Class Initialized
INFO - 2016-07-19 19:04:23 --> Language Class Initialized
INFO - 2016-07-19 19:04:23 --> Loader Class Initialized
INFO - 2016-07-19 19:04:23 --> Helper loaded: url_helper
INFO - 2016-07-19 19:04:23 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:04:23 --> Helper loaded: html_helper
INFO - 2016-07-19 19:04:23 --> Helper loaded: form_helper
INFO - 2016-07-19 19:04:23 --> Helper loaded: file_helper
INFO - 2016-07-19 19:04:23 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:04:23 --> Database Driver Class Initialized
INFO - 2016-07-19 19:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:04:23 --> Form Validation Class Initialized
INFO - 2016-07-19 19:04:23 --> Email Class Initialized
INFO - 2016-07-19 19:04:23 --> Controller Class Initialized
DEBUG - 2016-07-19 19:04:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:04:23 --> Model Class Initialized
INFO - 2016-07-19 19:04:23 --> Model Class Initialized
INFO - 2016-07-19 19:04:23 --> Final output sent to browser
DEBUG - 2016-07-19 19:04:23 --> Total execution time: 0.4660
INFO - 2016-07-19 19:18:54 --> Config Class Initialized
INFO - 2016-07-19 19:18:54 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:18:54 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:18:54 --> Utf8 Class Initialized
INFO - 2016-07-19 19:18:54 --> URI Class Initialized
INFO - 2016-07-19 19:18:54 --> Router Class Initialized
INFO - 2016-07-19 19:18:54 --> Output Class Initialized
INFO - 2016-07-19 19:18:54 --> Security Class Initialized
DEBUG - 2016-07-19 19:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:18:54 --> Input Class Initialized
INFO - 2016-07-19 19:18:54 --> Language Class Initialized
INFO - 2016-07-19 19:18:54 --> Loader Class Initialized
INFO - 2016-07-19 19:18:54 --> Helper loaded: url_helper
INFO - 2016-07-19 19:18:54 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:18:54 --> Helper loaded: html_helper
INFO - 2016-07-19 19:18:54 --> Helper loaded: form_helper
INFO - 2016-07-19 19:18:54 --> Helper loaded: file_helper
INFO - 2016-07-19 19:18:54 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:18:54 --> Database Driver Class Initialized
INFO - 2016-07-19 19:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:18:54 --> Form Validation Class Initialized
INFO - 2016-07-19 19:18:54 --> Email Class Initialized
INFO - 2016-07-19 19:18:54 --> Controller Class Initialized
DEBUG - 2016-07-19 19:18:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:18:54 --> Model Class Initialized
INFO - 2016-07-19 19:18:54 --> Model Class Initialized
ERROR - 2016-07-19 19:18:54 --> Severity: Error --> Call to a member function list_fields() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 319
INFO - 2016-07-19 19:20:16 --> Config Class Initialized
INFO - 2016-07-19 19:20:16 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:20:16 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:20:16 --> Utf8 Class Initialized
INFO - 2016-07-19 19:20:16 --> URI Class Initialized
INFO - 2016-07-19 19:20:16 --> Router Class Initialized
INFO - 2016-07-19 19:20:16 --> Output Class Initialized
INFO - 2016-07-19 19:20:16 --> Security Class Initialized
DEBUG - 2016-07-19 19:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:20:16 --> Input Class Initialized
INFO - 2016-07-19 19:20:16 --> Language Class Initialized
INFO - 2016-07-19 19:20:16 --> Loader Class Initialized
INFO - 2016-07-19 19:20:16 --> Helper loaded: url_helper
INFO - 2016-07-19 19:20:16 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:20:16 --> Helper loaded: html_helper
INFO - 2016-07-19 19:20:16 --> Helper loaded: form_helper
INFO - 2016-07-19 19:20:16 --> Helper loaded: file_helper
INFO - 2016-07-19 19:20:16 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:20:16 --> Database Driver Class Initialized
INFO - 2016-07-19 19:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:20:16 --> Form Validation Class Initialized
INFO - 2016-07-19 19:20:16 --> Email Class Initialized
INFO - 2016-07-19 19:20:16 --> Controller Class Initialized
DEBUG - 2016-07-19 19:20:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:20:16 --> Model Class Initialized
INFO - 2016-07-19 19:20:16 --> Model Class Initialized
ERROR - 2016-07-19 19:20:16 --> Severity: Error --> Cannot use object of type stdClass as array D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
INFO - 2016-07-19 19:27:28 --> Config Class Initialized
INFO - 2016-07-19 19:27:28 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:27:28 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:27:28 --> Utf8 Class Initialized
INFO - 2016-07-19 19:27:28 --> URI Class Initialized
INFO - 2016-07-19 19:27:28 --> Router Class Initialized
INFO - 2016-07-19 19:27:28 --> Output Class Initialized
INFO - 2016-07-19 19:27:28 --> Security Class Initialized
DEBUG - 2016-07-19 19:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:27:28 --> Input Class Initialized
INFO - 2016-07-19 19:27:28 --> Language Class Initialized
INFO - 2016-07-19 19:27:28 --> Loader Class Initialized
INFO - 2016-07-19 19:27:28 --> Helper loaded: url_helper
INFO - 2016-07-19 19:27:28 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:27:28 --> Helper loaded: html_helper
INFO - 2016-07-19 19:27:28 --> Helper loaded: form_helper
INFO - 2016-07-19 19:27:28 --> Helper loaded: file_helper
INFO - 2016-07-19 19:27:28 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:27:28 --> Database Driver Class Initialized
INFO - 2016-07-19 19:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:27:28 --> Form Validation Class Initialized
INFO - 2016-07-19 19:27:28 --> Email Class Initialized
INFO - 2016-07-19 19:27:28 --> Controller Class Initialized
DEBUG - 2016-07-19 19:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:27:28 --> Model Class Initialized
INFO - 2016-07-19 19:27:28 --> Model Class Initialized
ERROR - 2016-07-19 19:27:28 --> Severity: Error --> Call to a member function list_fields() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 319
INFO - 2016-07-19 19:27:30 --> Config Class Initialized
INFO - 2016-07-19 19:27:30 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:27:30 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:27:30 --> Utf8 Class Initialized
INFO - 2016-07-19 19:27:30 --> URI Class Initialized
INFO - 2016-07-19 19:27:30 --> Router Class Initialized
INFO - 2016-07-19 19:27:30 --> Output Class Initialized
INFO - 2016-07-19 19:27:30 --> Security Class Initialized
DEBUG - 2016-07-19 19:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:27:30 --> Input Class Initialized
INFO - 2016-07-19 19:27:30 --> Language Class Initialized
INFO - 2016-07-19 19:27:30 --> Loader Class Initialized
INFO - 2016-07-19 19:27:30 --> Helper loaded: url_helper
INFO - 2016-07-19 19:27:30 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:27:30 --> Helper loaded: html_helper
INFO - 2016-07-19 19:27:30 --> Helper loaded: form_helper
INFO - 2016-07-19 19:27:30 --> Helper loaded: file_helper
INFO - 2016-07-19 19:27:30 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:27:30 --> Database Driver Class Initialized
INFO - 2016-07-19 19:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:27:30 --> Form Validation Class Initialized
INFO - 2016-07-19 19:27:30 --> Email Class Initialized
INFO - 2016-07-19 19:27:30 --> Controller Class Initialized
DEBUG - 2016-07-19 19:27:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:27:30 --> Model Class Initialized
INFO - 2016-07-19 19:27:30 --> Model Class Initialized
ERROR - 2016-07-19 19:27:30 --> Severity: Error --> Call to a member function list_fields() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 319
INFO - 2016-07-19 19:28:32 --> Config Class Initialized
INFO - 2016-07-19 19:28:32 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:28:32 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:28:32 --> Utf8 Class Initialized
INFO - 2016-07-19 19:28:32 --> URI Class Initialized
INFO - 2016-07-19 19:28:32 --> Router Class Initialized
INFO - 2016-07-19 19:28:32 --> Output Class Initialized
INFO - 2016-07-19 19:28:32 --> Security Class Initialized
DEBUG - 2016-07-19 19:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:28:32 --> Input Class Initialized
INFO - 2016-07-19 19:28:32 --> Language Class Initialized
INFO - 2016-07-19 19:28:32 --> Loader Class Initialized
INFO - 2016-07-19 19:28:32 --> Helper loaded: url_helper
INFO - 2016-07-19 19:28:32 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:28:32 --> Helper loaded: html_helper
INFO - 2016-07-19 19:28:32 --> Helper loaded: form_helper
INFO - 2016-07-19 19:28:32 --> Helper loaded: file_helper
INFO - 2016-07-19 19:28:32 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:28:32 --> Database Driver Class Initialized
INFO - 2016-07-19 19:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:28:32 --> Form Validation Class Initialized
INFO - 2016-07-19 19:28:32 --> Email Class Initialized
INFO - 2016-07-19 19:28:32 --> Controller Class Initialized
DEBUG - 2016-07-19 19:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:28:32 --> Model Class Initialized
INFO - 2016-07-19 19:28:32 --> Model Class Initialized
ERROR - 2016-07-19 19:28:32 --> Severity: Error --> Cannot use object of type mysqli as array D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
INFO - 2016-07-19 19:29:16 --> Config Class Initialized
INFO - 2016-07-19 19:29:16 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:29:16 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:29:16 --> Utf8 Class Initialized
INFO - 2016-07-19 19:29:16 --> URI Class Initialized
INFO - 2016-07-19 19:29:16 --> Router Class Initialized
INFO - 2016-07-19 19:29:16 --> Output Class Initialized
INFO - 2016-07-19 19:29:16 --> Security Class Initialized
DEBUG - 2016-07-19 19:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:29:16 --> Input Class Initialized
INFO - 2016-07-19 19:29:16 --> Language Class Initialized
INFO - 2016-07-19 19:29:16 --> Loader Class Initialized
INFO - 2016-07-19 19:29:16 --> Helper loaded: url_helper
INFO - 2016-07-19 19:29:16 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:29:16 --> Helper loaded: html_helper
INFO - 2016-07-19 19:29:16 --> Helper loaded: form_helper
INFO - 2016-07-19 19:29:16 --> Helper loaded: file_helper
INFO - 2016-07-19 19:29:16 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:29:16 --> Database Driver Class Initialized
INFO - 2016-07-19 19:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:29:16 --> Form Validation Class Initialized
INFO - 2016-07-19 19:29:16 --> Email Class Initialized
INFO - 2016-07-19 19:29:16 --> Controller Class Initialized
DEBUG - 2016-07-19 19:29:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:29:16 --> Model Class Initialized
INFO - 2016-07-19 19:29:16 --> Model Class Initialized
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:16 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:16 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
ERROR - 2016-07-19 19:29:17 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
INFO - 2016-07-19 19:29:17 --> Final output sent to browser
DEBUG - 2016-07-19 19:29:17 --> Total execution time: 1.0848
INFO - 2016-07-19 19:30:12 --> Config Class Initialized
INFO - 2016-07-19 19:30:12 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:30:12 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:30:12 --> Utf8 Class Initialized
INFO - 2016-07-19 19:30:12 --> URI Class Initialized
INFO - 2016-07-19 19:30:12 --> Router Class Initialized
INFO - 2016-07-19 19:30:12 --> Output Class Initialized
INFO - 2016-07-19 19:30:12 --> Security Class Initialized
DEBUG - 2016-07-19 19:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:30:12 --> Input Class Initialized
INFO - 2016-07-19 19:30:12 --> Language Class Initialized
INFO - 2016-07-19 19:30:12 --> Loader Class Initialized
INFO - 2016-07-19 19:30:12 --> Helper loaded: url_helper
INFO - 2016-07-19 19:30:12 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:30:12 --> Helper loaded: html_helper
INFO - 2016-07-19 19:30:12 --> Helper loaded: form_helper
INFO - 2016-07-19 19:30:12 --> Helper loaded: file_helper
INFO - 2016-07-19 19:30:12 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:30:12 --> Database Driver Class Initialized
INFO - 2016-07-19 19:30:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:30:12 --> Form Validation Class Initialized
INFO - 2016-07-19 19:30:12 --> Email Class Initialized
INFO - 2016-07-19 19:30:12 --> Controller Class Initialized
DEBUG - 2016-07-19 19:30:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:30:12 --> Model Class Initialized
INFO - 2016-07-19 19:30:12 --> Model Class Initialized
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Notice --> Undefined offset: 0 D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 86
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Cell\DefaultValueBinder.php 95
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given D:\wamp\www\library.pnc.lan\application\third_party\PHPExcel\Shared\String.php 575
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
ERROR - 2016-07-19 19:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\controllers\Books.php 329
INFO - 2016-07-19 19:30:13 --> Final output sent to browser
DEBUG - 2016-07-19 19:30:13 --> Total execution time: 0.8572
INFO - 2016-07-19 19:42:50 --> Config Class Initialized
INFO - 2016-07-19 19:42:50 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:42:50 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:42:50 --> Utf8 Class Initialized
INFO - 2016-07-19 19:42:50 --> URI Class Initialized
INFO - 2016-07-19 19:42:50 --> Router Class Initialized
INFO - 2016-07-19 19:42:50 --> Output Class Initialized
INFO - 2016-07-19 19:42:50 --> Security Class Initialized
DEBUG - 2016-07-19 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:42:50 --> Input Class Initialized
INFO - 2016-07-19 19:42:50 --> Language Class Initialized
INFO - 2016-07-19 19:42:50 --> Loader Class Initialized
INFO - 2016-07-19 19:42:50 --> Helper loaded: url_helper
INFO - 2016-07-19 19:42:50 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:42:50 --> Helper loaded: html_helper
INFO - 2016-07-19 19:42:50 --> Helper loaded: form_helper
INFO - 2016-07-19 19:42:50 --> Helper loaded: file_helper
INFO - 2016-07-19 19:42:50 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:42:50 --> Database Driver Class Initialized
INFO - 2016-07-19 19:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:42:50 --> Form Validation Class Initialized
INFO - 2016-07-19 19:42:50 --> Email Class Initialized
INFO - 2016-07-19 19:42:50 --> Controller Class Initialized
DEBUG - 2016-07-19 19:42:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:42:50 --> Model Class Initialized
INFO - 2016-07-19 19:42:50 --> Model Class Initialized
ERROR - 2016-07-19 19:42:51 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 19:43:07 --> Config Class Initialized
INFO - 2016-07-19 19:43:07 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:43:07 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:43:07 --> Utf8 Class Initialized
INFO - 2016-07-19 19:43:07 --> URI Class Initialized
INFO - 2016-07-19 19:43:07 --> Router Class Initialized
INFO - 2016-07-19 19:43:07 --> Output Class Initialized
INFO - 2016-07-19 19:43:07 --> Security Class Initialized
DEBUG - 2016-07-19 19:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:43:07 --> Input Class Initialized
INFO - 2016-07-19 19:43:07 --> Language Class Initialized
INFO - 2016-07-19 19:43:07 --> Loader Class Initialized
INFO - 2016-07-19 19:43:07 --> Helper loaded: url_helper
INFO - 2016-07-19 19:43:07 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:43:07 --> Helper loaded: html_helper
INFO - 2016-07-19 19:43:07 --> Helper loaded: form_helper
INFO - 2016-07-19 19:43:07 --> Helper loaded: file_helper
INFO - 2016-07-19 19:43:07 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:43:07 --> Database Driver Class Initialized
INFO - 2016-07-19 19:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:43:07 --> Form Validation Class Initialized
INFO - 2016-07-19 19:43:07 --> Email Class Initialized
INFO - 2016-07-19 19:43:07 --> Controller Class Initialized
DEBUG - 2016-07-19 19:43:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:43:07 --> Model Class Initialized
INFO - 2016-07-19 19:43:07 --> Model Class Initialized
ERROR - 2016-07-19 19:43:07 --> Severity: Notice --> Undefined variable: query D:\wamp\www\library.pnc.lan\application\controllers\Books.php 308
ERROR - 2016-07-19 19:43:07 --> Severity: Error --> Call to a member function list_fields() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Books.php 308
INFO - 2016-07-19 19:43:55 --> Config Class Initialized
INFO - 2016-07-19 19:43:55 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:43:55 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:43:55 --> Utf8 Class Initialized
INFO - 2016-07-19 19:43:55 --> URI Class Initialized
INFO - 2016-07-19 19:43:55 --> Router Class Initialized
INFO - 2016-07-19 19:43:55 --> Output Class Initialized
INFO - 2016-07-19 19:43:55 --> Security Class Initialized
DEBUG - 2016-07-19 19:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:43:55 --> Input Class Initialized
INFO - 2016-07-19 19:43:55 --> Language Class Initialized
INFO - 2016-07-19 19:43:55 --> Loader Class Initialized
INFO - 2016-07-19 19:43:55 --> Helper loaded: url_helper
INFO - 2016-07-19 19:43:55 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:43:55 --> Helper loaded: html_helper
INFO - 2016-07-19 19:43:55 --> Helper loaded: form_helper
INFO - 2016-07-19 19:43:55 --> Helper loaded: file_helper
INFO - 2016-07-19 19:43:55 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:43:55 --> Database Driver Class Initialized
INFO - 2016-07-19 19:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:43:55 --> Form Validation Class Initialized
INFO - 2016-07-19 19:43:55 --> Email Class Initialized
INFO - 2016-07-19 19:43:55 --> Controller Class Initialized
DEBUG - 2016-07-19 19:43:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:43:55 --> Model Class Initialized
INFO - 2016-07-19 19:43:55 --> Model Class Initialized
ERROR - 2016-07-19 19:43:55 --> Severity: Error --> Class 'IOFactory' not found D:\wamp\www\library.pnc.lan\application\controllers\Books.php 330
INFO - 2016-07-19 19:54:26 --> Config Class Initialized
INFO - 2016-07-19 19:54:26 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:54:26 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:54:26 --> Utf8 Class Initialized
INFO - 2016-07-19 19:54:26 --> URI Class Initialized
INFO - 2016-07-19 19:54:26 --> Router Class Initialized
INFO - 2016-07-19 19:54:26 --> Output Class Initialized
INFO - 2016-07-19 19:54:26 --> Security Class Initialized
DEBUG - 2016-07-19 19:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:54:26 --> Input Class Initialized
INFO - 2016-07-19 19:54:26 --> Language Class Initialized
INFO - 2016-07-19 19:54:26 --> Loader Class Initialized
INFO - 2016-07-19 19:54:26 --> Helper loaded: url_helper
INFO - 2016-07-19 19:54:26 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:54:26 --> Helper loaded: html_helper
INFO - 2016-07-19 19:54:26 --> Helper loaded: form_helper
INFO - 2016-07-19 19:54:26 --> Helper loaded: file_helper
INFO - 2016-07-19 19:54:26 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:54:26 --> Database Driver Class Initialized
INFO - 2016-07-19 19:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:54:26 --> Form Validation Class Initialized
INFO - 2016-07-19 19:54:26 --> Email Class Initialized
INFO - 2016-07-19 19:54:26 --> Controller Class Initialized
DEBUG - 2016-07-19 19:54:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:54:26 --> Model Class Initialized
INFO - 2016-07-19 19:54:26 --> Model Class Initialized
ERROR - 2016-07-19 19:54:26 --> Severity: Warning --> require(D:\wamp\www\library.pnc.lan\application\third_party/../PHPExcel/Autoloader.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\third_party\IOFactory.php 35
ERROR - 2016-07-19 19:54:26 --> Severity: Compile Error --> require(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/../PHPExcel/Autoloader.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\third_party\IOFactory.php 35
INFO - 2016-07-19 19:56:42 --> Config Class Initialized
INFO - 2016-07-19 19:56:42 --> Hooks Class Initialized
DEBUG - 2016-07-19 19:56:42 --> UTF-8 Support Enabled
INFO - 2016-07-19 19:56:42 --> Utf8 Class Initialized
INFO - 2016-07-19 19:56:42 --> URI Class Initialized
INFO - 2016-07-19 19:56:42 --> Router Class Initialized
INFO - 2016-07-19 19:56:42 --> Output Class Initialized
INFO - 2016-07-19 19:56:42 --> Security Class Initialized
DEBUG - 2016-07-19 19:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 19:56:42 --> Input Class Initialized
INFO - 2016-07-19 19:56:42 --> Language Class Initialized
INFO - 2016-07-19 19:56:42 --> Loader Class Initialized
INFO - 2016-07-19 19:56:42 --> Helper loaded: url_helper
INFO - 2016-07-19 19:56:42 --> Helper loaded: utils_helper
INFO - 2016-07-19 19:56:42 --> Helper loaded: html_helper
INFO - 2016-07-19 19:56:42 --> Helper loaded: form_helper
INFO - 2016-07-19 19:56:42 --> Helper loaded: file_helper
INFO - 2016-07-19 19:56:42 --> Helper loaded: myemail_helper
INFO - 2016-07-19 19:56:42 --> Database Driver Class Initialized
INFO - 2016-07-19 19:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 19:56:42 --> Form Validation Class Initialized
INFO - 2016-07-19 19:56:42 --> Email Class Initialized
INFO - 2016-07-19 19:56:42 --> Controller Class Initialized
DEBUG - 2016-07-19 19:56:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 19:56:42 --> Model Class Initialized
INFO - 2016-07-19 19:56:42 --> Model Class Initialized
ERROR - 2016-07-19 19:56:42 --> Severity: Warning --> require(D:\wamp\www\library.pnc.lan\application\third_party/../PHPExcel/Autoloader.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\third_party\IOFactory.php 35
ERROR - 2016-07-19 19:56:42 --> Severity: Compile Error --> require(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/../PHPExcel/Autoloader.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\third_party\IOFactory.php 35
INFO - 2016-07-19 20:10:48 --> Config Class Initialized
INFO - 2016-07-19 20:10:48 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:10:48 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:10:48 --> Utf8 Class Initialized
INFO - 2016-07-19 20:10:48 --> URI Class Initialized
INFO - 2016-07-19 20:10:48 --> Router Class Initialized
INFO - 2016-07-19 20:10:48 --> Output Class Initialized
INFO - 2016-07-19 20:10:48 --> Security Class Initialized
DEBUG - 2016-07-19 20:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:10:48 --> Input Class Initialized
INFO - 2016-07-19 20:10:48 --> Language Class Initialized
INFO - 2016-07-19 20:10:48 --> Loader Class Initialized
INFO - 2016-07-19 20:10:48 --> Helper loaded: url_helper
INFO - 2016-07-19 20:10:48 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:10:48 --> Helper loaded: html_helper
INFO - 2016-07-19 20:10:48 --> Helper loaded: form_helper
INFO - 2016-07-19 20:10:48 --> Helper loaded: file_helper
INFO - 2016-07-19 20:10:48 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:10:48 --> Database Driver Class Initialized
INFO - 2016-07-19 20:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:10:48 --> Form Validation Class Initialized
INFO - 2016-07-19 20:10:48 --> Email Class Initialized
INFO - 2016-07-19 20:10:48 --> Controller Class Initialized
DEBUG - 2016-07-19 20:10:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:10:48 --> Model Class Initialized
INFO - 2016-07-19 20:10:48 --> Model Class Initialized
ERROR - 2016-07-19 20:10:48 --> Severity: Error --> Class 'IOFactory' not found D:\wamp\www\library.pnc.lan\application\libraries\IOFactory.php 5
INFO - 2016-07-19 20:12:36 --> Config Class Initialized
INFO - 2016-07-19 20:12:36 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:12:36 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:12:36 --> Utf8 Class Initialized
INFO - 2016-07-19 20:12:36 --> URI Class Initialized
INFO - 2016-07-19 20:12:36 --> Router Class Initialized
INFO - 2016-07-19 20:12:36 --> Output Class Initialized
INFO - 2016-07-19 20:12:36 --> Security Class Initialized
DEBUG - 2016-07-19 20:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:12:36 --> Input Class Initialized
INFO - 2016-07-19 20:12:36 --> Language Class Initialized
INFO - 2016-07-19 20:12:36 --> Loader Class Initialized
INFO - 2016-07-19 20:12:36 --> Helper loaded: url_helper
INFO - 2016-07-19 20:12:36 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:12:36 --> Helper loaded: html_helper
INFO - 2016-07-19 20:12:36 --> Helper loaded: form_helper
INFO - 2016-07-19 20:12:36 --> Helper loaded: file_helper
INFO - 2016-07-19 20:12:36 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:12:36 --> Database Driver Class Initialized
INFO - 2016-07-19 20:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:12:36 --> Form Validation Class Initialized
INFO - 2016-07-19 20:12:36 --> Email Class Initialized
INFO - 2016-07-19 20:12:36 --> Controller Class Initialized
DEBUG - 2016-07-19 20:12:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:12:36 --> Model Class Initialized
INFO - 2016-07-19 20:12:36 --> Model Class Initialized
ERROR - 2016-07-19 20:12:36 --> Non-existent class: IOFactory
INFO - 2016-07-19 20:15:38 --> Config Class Initialized
INFO - 2016-07-19 20:15:38 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:15:38 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:15:38 --> Utf8 Class Initialized
INFO - 2016-07-19 20:15:38 --> URI Class Initialized
INFO - 2016-07-19 20:15:38 --> Router Class Initialized
INFO - 2016-07-19 20:15:38 --> Output Class Initialized
INFO - 2016-07-19 20:15:38 --> Security Class Initialized
DEBUG - 2016-07-19 20:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:15:38 --> Input Class Initialized
INFO - 2016-07-19 20:15:38 --> Language Class Initialized
INFO - 2016-07-19 20:15:38 --> Loader Class Initialized
INFO - 2016-07-19 20:15:38 --> Helper loaded: url_helper
INFO - 2016-07-19 20:15:38 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:15:38 --> Helper loaded: html_helper
INFO - 2016-07-19 20:15:38 --> Helper loaded: form_helper
INFO - 2016-07-19 20:15:38 --> Helper loaded: file_helper
INFO - 2016-07-19 20:15:38 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:15:38 --> Database Driver Class Initialized
INFO - 2016-07-19 20:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:15:38 --> Form Validation Class Initialized
INFO - 2016-07-19 20:15:38 --> Email Class Initialized
INFO - 2016-07-19 20:15:38 --> Controller Class Initialized
DEBUG - 2016-07-19 20:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:15:38 --> Model Class Initialized
INFO - 2016-07-19 20:15:38 --> Model Class Initialized
ERROR - 2016-07-19 20:15:38 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:18:30 --> Config Class Initialized
INFO - 2016-07-19 20:18:30 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:18:30 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:18:30 --> Utf8 Class Initialized
INFO - 2016-07-19 20:18:30 --> URI Class Initialized
INFO - 2016-07-19 20:18:30 --> Router Class Initialized
INFO - 2016-07-19 20:18:30 --> Output Class Initialized
INFO - 2016-07-19 20:18:30 --> Security Class Initialized
DEBUG - 2016-07-19 20:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:18:30 --> Input Class Initialized
INFO - 2016-07-19 20:18:30 --> Language Class Initialized
INFO - 2016-07-19 20:18:30 --> Loader Class Initialized
INFO - 2016-07-19 20:18:30 --> Helper loaded: url_helper
INFO - 2016-07-19 20:18:30 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:18:30 --> Helper loaded: html_helper
INFO - 2016-07-19 20:18:30 --> Helper loaded: form_helper
INFO - 2016-07-19 20:18:30 --> Helper loaded: file_helper
INFO - 2016-07-19 20:18:30 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:18:30 --> Database Driver Class Initialized
INFO - 2016-07-19 20:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:18:30 --> Form Validation Class Initialized
INFO - 2016-07-19 20:18:30 --> Email Class Initialized
INFO - 2016-07-19 20:18:30 --> Controller Class Initialized
DEBUG - 2016-07-19 20:18:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:18:30 --> Model Class Initialized
INFO - 2016-07-19 20:18:30 --> Model Class Initialized
ERROR - 2016-07-19 20:18:30 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:18:34 --> Config Class Initialized
INFO - 2016-07-19 20:18:34 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:18:34 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:18:34 --> Utf8 Class Initialized
INFO - 2016-07-19 20:18:34 --> URI Class Initialized
INFO - 2016-07-19 20:18:35 --> Router Class Initialized
INFO - 2016-07-19 20:18:35 --> Output Class Initialized
INFO - 2016-07-19 20:18:35 --> Security Class Initialized
DEBUG - 2016-07-19 20:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:18:35 --> Input Class Initialized
INFO - 2016-07-19 20:18:35 --> Language Class Initialized
INFO - 2016-07-19 20:18:35 --> Loader Class Initialized
INFO - 2016-07-19 20:18:35 --> Helper loaded: url_helper
INFO - 2016-07-19 20:18:35 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:18:35 --> Helper loaded: html_helper
INFO - 2016-07-19 20:18:35 --> Helper loaded: form_helper
INFO - 2016-07-19 20:18:35 --> Helper loaded: file_helper
INFO - 2016-07-19 20:18:35 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:18:35 --> Database Driver Class Initialized
INFO - 2016-07-19 20:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:18:35 --> Form Validation Class Initialized
INFO - 2016-07-19 20:18:35 --> Email Class Initialized
INFO - 2016-07-19 20:18:35 --> Controller Class Initialized
DEBUG - 2016-07-19 20:18:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:18:35 --> Model Class Initialized
INFO - 2016-07-19 20:18:35 --> Model Class Initialized
ERROR - 2016-07-19 20:18:35 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:25:27 --> Config Class Initialized
INFO - 2016-07-19 20:25:27 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:25:27 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:25:27 --> Utf8 Class Initialized
INFO - 2016-07-19 20:25:27 --> URI Class Initialized
INFO - 2016-07-19 20:25:27 --> Router Class Initialized
INFO - 2016-07-19 20:25:27 --> Output Class Initialized
INFO - 2016-07-19 20:25:27 --> Security Class Initialized
DEBUG - 2016-07-19 20:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:25:27 --> Input Class Initialized
INFO - 2016-07-19 20:25:27 --> Language Class Initialized
INFO - 2016-07-19 20:25:27 --> Loader Class Initialized
INFO - 2016-07-19 20:25:27 --> Helper loaded: url_helper
INFO - 2016-07-19 20:25:27 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:25:27 --> Helper loaded: html_helper
INFO - 2016-07-19 20:25:27 --> Helper loaded: form_helper
INFO - 2016-07-19 20:25:27 --> Helper loaded: file_helper
INFO - 2016-07-19 20:25:27 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:25:27 --> Database Driver Class Initialized
INFO - 2016-07-19 20:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:25:27 --> Form Validation Class Initialized
INFO - 2016-07-19 20:25:27 --> Email Class Initialized
INFO - 2016-07-19 20:25:27 --> Controller Class Initialized
DEBUG - 2016-07-19 20:25:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:25:27 --> Model Class Initialized
INFO - 2016-07-19 20:25:27 --> Model Class Initialized
ERROR - 2016-07-19 20:25:27 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:31:39 --> Config Class Initialized
INFO - 2016-07-19 20:31:39 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:31:39 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:31:39 --> Utf8 Class Initialized
INFO - 2016-07-19 20:31:39 --> URI Class Initialized
INFO - 2016-07-19 20:31:39 --> Router Class Initialized
INFO - 2016-07-19 20:31:39 --> Output Class Initialized
INFO - 2016-07-19 20:31:39 --> Security Class Initialized
DEBUG - 2016-07-19 20:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:31:39 --> Input Class Initialized
INFO - 2016-07-19 20:31:39 --> Language Class Initialized
INFO - 2016-07-19 20:31:39 --> Loader Class Initialized
INFO - 2016-07-19 20:31:39 --> Helper loaded: url_helper
INFO - 2016-07-19 20:31:39 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:31:39 --> Helper loaded: html_helper
INFO - 2016-07-19 20:31:39 --> Helper loaded: form_helper
INFO - 2016-07-19 20:31:39 --> Helper loaded: file_helper
INFO - 2016-07-19 20:31:39 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:31:39 --> Database Driver Class Initialized
INFO - 2016-07-19 20:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:31:39 --> Form Validation Class Initialized
INFO - 2016-07-19 20:31:39 --> Email Class Initialized
INFO - 2016-07-19 20:31:39 --> Controller Class Initialized
DEBUG - 2016-07-19 20:31:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:31:39 --> Model Class Initialized
INFO - 2016-07-19 20:31:39 --> Model Class Initialized
ERROR - 2016-07-19 20:31:39 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:31:42 --> Config Class Initialized
INFO - 2016-07-19 20:31:42 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:31:42 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:31:42 --> Utf8 Class Initialized
INFO - 2016-07-19 20:31:42 --> URI Class Initialized
INFO - 2016-07-19 20:31:42 --> Router Class Initialized
INFO - 2016-07-19 20:31:42 --> Output Class Initialized
INFO - 2016-07-19 20:31:42 --> Security Class Initialized
DEBUG - 2016-07-19 20:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:31:42 --> Input Class Initialized
INFO - 2016-07-19 20:31:42 --> Language Class Initialized
INFO - 2016-07-19 20:31:42 --> Loader Class Initialized
INFO - 2016-07-19 20:31:42 --> Helper loaded: url_helper
INFO - 2016-07-19 20:31:42 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:31:43 --> Helper loaded: html_helper
INFO - 2016-07-19 20:31:43 --> Helper loaded: form_helper
INFO - 2016-07-19 20:31:43 --> Helper loaded: file_helper
INFO - 2016-07-19 20:31:43 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:31:43 --> Database Driver Class Initialized
INFO - 2016-07-19 20:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:31:43 --> Form Validation Class Initialized
INFO - 2016-07-19 20:31:43 --> Email Class Initialized
INFO - 2016-07-19 20:31:43 --> Controller Class Initialized
DEBUG - 2016-07-19 20:31:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:31:43 --> Model Class Initialized
INFO - 2016-07-19 20:31:43 --> Model Class Initialized
ERROR - 2016-07-19 20:31:43 --> Unable to load the requested class: IOFactory
INFO - 2016-07-19 20:42:09 --> Config Class Initialized
INFO - 2016-07-19 20:42:09 --> Hooks Class Initialized
DEBUG - 2016-07-19 20:42:09 --> UTF-8 Support Enabled
INFO - 2016-07-19 20:42:09 --> Utf8 Class Initialized
INFO - 2016-07-19 20:42:09 --> URI Class Initialized
INFO - 2016-07-19 20:42:09 --> Router Class Initialized
INFO - 2016-07-19 20:42:09 --> Output Class Initialized
INFO - 2016-07-19 20:42:09 --> Security Class Initialized
DEBUG - 2016-07-19 20:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-19 20:42:09 --> Input Class Initialized
INFO - 2016-07-19 20:42:09 --> Language Class Initialized
INFO - 2016-07-19 20:42:09 --> Loader Class Initialized
INFO - 2016-07-19 20:42:09 --> Helper loaded: url_helper
INFO - 2016-07-19 20:42:09 --> Helper loaded: utils_helper
INFO - 2016-07-19 20:42:09 --> Helper loaded: html_helper
INFO - 2016-07-19 20:42:09 --> Helper loaded: form_helper
INFO - 2016-07-19 20:42:09 --> Helper loaded: file_helper
INFO - 2016-07-19 20:42:09 --> Helper loaded: myemail_helper
INFO - 2016-07-19 20:42:09 --> Database Driver Class Initialized
INFO - 2016-07-19 20:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-19 20:42:09 --> Form Validation Class Initialized
INFO - 2016-07-19 20:42:09 --> Email Class Initialized
INFO - 2016-07-19 20:42:09 --> Controller Class Initialized
DEBUG - 2016-07-19 20:42:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-19 20:42:09 --> Model Class Initialized
INFO - 2016-07-19 20:42:09 --> Model Class Initialized
ERROR - 2016-07-19 20:42:09 --> Severity: Error --> Cannot call private PHPExcel_IOFactory::__construct() D:\wamp\www\library.pnc.lan\application\libraries\iof_actory.php 7
