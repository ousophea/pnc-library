<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-16 04:45:44 --> Config Class Initialized
INFO - 2016-08-16 04:45:44 --> Hooks Class Initialized
DEBUG - 2016-08-16 04:45:44 --> UTF-8 Support Enabled
INFO - 2016-08-16 04:45:44 --> Utf8 Class Initialized
INFO - 2016-08-16 04:45:44 --> URI Class Initialized
INFO - 2016-08-16 04:45:44 --> Router Class Initialized
INFO - 2016-08-16 04:45:44 --> Output Class Initialized
INFO - 2016-08-16 04:45:44 --> Security Class Initialized
DEBUG - 2016-08-16 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-16 04:45:44 --> Input Class Initialized
INFO - 2016-08-16 04:45:44 --> Language Class Initialized
INFO - 2016-08-16 04:45:44 --> Loader Class Initialized
INFO - 2016-08-16 04:45:44 --> Helper loaded: url_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: utils_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: html_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: form_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: file_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: myemail_helper
INFO - 2016-08-16 04:45:45 --> Database Driver Class Initialized
INFO - 2016-08-16 04:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-16 04:45:45 --> Form Validation Class Initialized
INFO - 2016-08-16 04:45:45 --> Email Class Initialized
INFO - 2016-08-16 04:45:45 --> Controller Class Initialized
INFO - 2016-08-16 04:45:45 --> Config Class Initialized
INFO - 2016-08-16 04:45:45 --> Hooks Class Initialized
DEBUG - 2016-08-16 04:45:45 --> UTF-8 Support Enabled
INFO - 2016-08-16 04:45:45 --> Utf8 Class Initialized
INFO - 2016-08-16 04:45:45 --> URI Class Initialized
INFO - 2016-08-16 04:45:45 --> Router Class Initialized
INFO - 2016-08-16 04:45:45 --> Output Class Initialized
INFO - 2016-08-16 04:45:45 --> Security Class Initialized
DEBUG - 2016-08-16 04:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-16 04:45:45 --> Input Class Initialized
INFO - 2016-08-16 04:45:45 --> Language Class Initialized
INFO - 2016-08-16 04:45:45 --> Loader Class Initialized
INFO - 2016-08-16 04:45:45 --> Helper loaded: url_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: utils_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: html_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: form_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: file_helper
INFO - 2016-08-16 04:45:45 --> Helper loaded: myemail_helper
INFO - 2016-08-16 04:45:45 --> Database Driver Class Initialized
INFO - 2016-08-16 04:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-16 04:45:45 --> Form Validation Class Initialized
INFO - 2016-08-16 04:45:45 --> Email Class Initialized
INFO - 2016-08-16 04:45:45 --> Controller Class Initialized
INFO - 2016-08-16 04:45:45 --> Model Class Initialized
DEBUG - 2016-08-16 04:45:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-16 04:45:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-16 04:45:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-16 04:45:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-16 04:45:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-16 04:45:45 --> Final output sent to browser
DEBUG - 2016-08-16 04:45:45 --> Total execution time: 0.3795
INFO - 2016-08-16 04:45:47 --> Config Class Initialized
INFO - 2016-08-16 04:45:47 --> Hooks Class Initialized
DEBUG - 2016-08-16 04:45:47 --> UTF-8 Support Enabled
INFO - 2016-08-16 04:45:47 --> Utf8 Class Initialized
INFO - 2016-08-16 04:45:47 --> URI Class Initialized
INFO - 2016-08-16 04:45:47 --> Router Class Initialized
INFO - 2016-08-16 04:45:47 --> Output Class Initialized
INFO - 2016-08-16 04:45:47 --> Security Class Initialized
DEBUG - 2016-08-16 04:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-16 04:45:47 --> Input Class Initialized
INFO - 2016-08-16 04:45:47 --> Language Class Initialized
ERROR - 2016-08-16 04:45:47 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-16 04:45:47 --> Config Class Initialized
INFO - 2016-08-16 04:45:47 --> Hooks Class Initialized
DEBUG - 2016-08-16 04:45:47 --> UTF-8 Support Enabled
INFO - 2016-08-16 04:45:47 --> Utf8 Class Initialized
INFO - 2016-08-16 04:45:47 --> URI Class Initialized
INFO - 2016-08-16 04:45:47 --> Router Class Initialized
INFO - 2016-08-16 04:45:47 --> Output Class Initialized
INFO - 2016-08-16 04:45:47 --> Security Class Initialized
DEBUG - 2016-08-16 04:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-16 04:45:47 --> Input Class Initialized
INFO - 2016-08-16 04:45:47 --> Language Class Initialized
ERROR - 2016-08-16 04:45:47 --> 404 Page Not Found: Faviconico/index
