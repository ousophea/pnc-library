<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-12 17:30:29 --> Config Class Initialized
INFO - 2016-08-12 17:30:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:29 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:29 --> URI Class Initialized
DEBUG - 2016-08-12 17:30:29 --> No URI present. Default controller set.
INFO - 2016-08-12 17:30:29 --> Router Class Initialized
INFO - 2016-08-12 17:30:29 --> Output Class Initialized
INFO - 2016-08-12 17:30:29 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:29 --> Input Class Initialized
INFO - 2016-08-12 17:30:29 --> Language Class Initialized
INFO - 2016-08-12 17:30:29 --> Loader Class Initialized
INFO - 2016-08-12 17:30:29 --> Helper loaded: url_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: html_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: form_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: file_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:30:29 --> Database Driver Class Initialized
INFO - 2016-08-12 17:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:30:29 --> Form Validation Class Initialized
INFO - 2016-08-12 17:30:29 --> Email Class Initialized
INFO - 2016-08-12 17:30:29 --> Controller Class Initialized
INFO - 2016-08-12 17:30:29 --> Config Class Initialized
INFO - 2016-08-12 17:30:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:29 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:29 --> URI Class Initialized
INFO - 2016-08-12 17:30:29 --> Router Class Initialized
INFO - 2016-08-12 17:30:29 --> Output Class Initialized
INFO - 2016-08-12 17:30:29 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:29 --> Input Class Initialized
INFO - 2016-08-12 17:30:29 --> Language Class Initialized
INFO - 2016-08-12 17:30:29 --> Loader Class Initialized
INFO - 2016-08-12 17:30:29 --> Helper loaded: url_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:30:29 --> Helper loaded: html_helper
INFO - 2016-08-12 17:30:30 --> Helper loaded: form_helper
INFO - 2016-08-12 17:30:30 --> Helper loaded: file_helper
INFO - 2016-08-12 17:30:30 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:30:30 --> Database Driver Class Initialized
INFO - 2016-08-12 17:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:30:30 --> Form Validation Class Initialized
INFO - 2016-08-12 17:30:30 --> Email Class Initialized
INFO - 2016-08-12 17:30:30 --> Controller Class Initialized
INFO - 2016-08-12 17:30:30 --> Model Class Initialized
DEBUG - 2016-08-12 17:30:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:30:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-12 17:30:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:30:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-12 17:30:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:30:30 --> Final output sent to browser
DEBUG - 2016-08-12 17:30:30 --> Total execution time: 0.4332
INFO - 2016-08-12 17:30:31 --> Config Class Initialized
INFO - 2016-08-12 17:30:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:31 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:31 --> URI Class Initialized
INFO - 2016-08-12 17:30:31 --> Router Class Initialized
INFO - 2016-08-12 17:30:31 --> Output Class Initialized
INFO - 2016-08-12 17:30:31 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:31 --> Input Class Initialized
INFO - 2016-08-12 17:30:31 --> Language Class Initialized
ERROR - 2016-08-12 17:30:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-12 17:30:31 --> Config Class Initialized
INFO - 2016-08-12 17:30:31 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:31 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:31 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:31 --> URI Class Initialized
INFO - 2016-08-12 17:30:31 --> Router Class Initialized
INFO - 2016-08-12 17:30:31 --> Output Class Initialized
INFO - 2016-08-12 17:30:31 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:31 --> Input Class Initialized
INFO - 2016-08-12 17:30:31 --> Language Class Initialized
ERROR - 2016-08-12 17:30:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-12 17:30:34 --> Config Class Initialized
INFO - 2016-08-12 17:30:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:34 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:34 --> URI Class Initialized
INFO - 2016-08-12 17:30:34 --> Router Class Initialized
INFO - 2016-08-12 17:30:34 --> Output Class Initialized
INFO - 2016-08-12 17:30:34 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:34 --> Input Class Initialized
INFO - 2016-08-12 17:30:34 --> Language Class Initialized
INFO - 2016-08-12 17:30:34 --> Loader Class Initialized
INFO - 2016-08-12 17:30:34 --> Helper loaded: url_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: html_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: form_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: file_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:30:34 --> Database Driver Class Initialized
INFO - 2016-08-12 17:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:30:34 --> Form Validation Class Initialized
INFO - 2016-08-12 17:30:34 --> Email Class Initialized
INFO - 2016-08-12 17:30:34 --> Controller Class Initialized
INFO - 2016-08-12 17:30:34 --> Model Class Initialized
DEBUG - 2016-08-12 17:30:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:30:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 17:30:34 --> Config Class Initialized
INFO - 2016-08-12 17:30:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:34 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:34 --> URI Class Initialized
DEBUG - 2016-08-12 17:30:34 --> No URI present. Default controller set.
INFO - 2016-08-12 17:30:34 --> Router Class Initialized
INFO - 2016-08-12 17:30:34 --> Output Class Initialized
INFO - 2016-08-12 17:30:34 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:34 --> Input Class Initialized
INFO - 2016-08-12 17:30:34 --> Language Class Initialized
INFO - 2016-08-12 17:30:34 --> Loader Class Initialized
INFO - 2016-08-12 17:30:34 --> Helper loaded: url_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: html_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: form_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: file_helper
INFO - 2016-08-12 17:30:34 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:30:34 --> Database Driver Class Initialized
INFO - 2016-08-12 17:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:30:34 --> Form Validation Class Initialized
INFO - 2016-08-12 17:30:34 --> Email Class Initialized
INFO - 2016-08-12 17:30:34 --> Controller Class Initialized
INFO - 2016-08-12 17:30:34 --> Model Class Initialized
INFO - 2016-08-12 17:30:34 --> Model Class Initialized
INFO - 2016-08-12 17:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 17:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:30:34 --> Final output sent to browser
DEBUG - 2016-08-12 17:30:34 --> Total execution time: 0.2201
INFO - 2016-08-12 17:30:39 --> Config Class Initialized
INFO - 2016-08-12 17:30:39 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:30:39 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:30:39 --> Utf8 Class Initialized
INFO - 2016-08-12 17:30:39 --> URI Class Initialized
INFO - 2016-08-12 17:30:39 --> Router Class Initialized
INFO - 2016-08-12 17:30:39 --> Output Class Initialized
INFO - 2016-08-12 17:30:39 --> Security Class Initialized
DEBUG - 2016-08-12 17:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:30:39 --> Input Class Initialized
INFO - 2016-08-12 17:30:39 --> Language Class Initialized
INFO - 2016-08-12 17:30:39 --> Loader Class Initialized
INFO - 2016-08-12 17:30:39 --> Helper loaded: url_helper
INFO - 2016-08-12 17:30:39 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:30:39 --> Helper loaded: html_helper
INFO - 2016-08-12 17:30:39 --> Helper loaded: form_helper
INFO - 2016-08-12 17:30:39 --> Helper loaded: file_helper
INFO - 2016-08-12 17:30:39 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:30:39 --> Database Driver Class Initialized
INFO - 2016-08-12 17:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:30:40 --> Form Validation Class Initialized
INFO - 2016-08-12 17:30:40 --> Email Class Initialized
INFO - 2016-08-12 17:30:40 --> Controller Class Initialized
DEBUG - 2016-08-12 17:30:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:30:40 --> Model Class Initialized
INFO - 2016-08-12 17:30:40 --> Model Class Initialized
ERROR - 2016-08-12 17:30:40 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 23
INFO - 2016-08-12 17:30:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:30:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:30:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 17:30:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:30:40 --> Final output sent to browser
DEBUG - 2016-08-12 17:30:40 --> Total execution time: 0.3799
INFO - 2016-08-12 17:32:22 --> Config Class Initialized
INFO - 2016-08-12 17:32:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:32:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:32:22 --> Utf8 Class Initialized
INFO - 2016-08-12 17:32:22 --> URI Class Initialized
INFO - 2016-08-12 17:32:22 --> Router Class Initialized
INFO - 2016-08-12 17:32:22 --> Output Class Initialized
INFO - 2016-08-12 17:32:22 --> Security Class Initialized
DEBUG - 2016-08-12 17:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:32:22 --> Input Class Initialized
INFO - 2016-08-12 17:32:22 --> Language Class Initialized
INFO - 2016-08-12 17:32:22 --> Loader Class Initialized
INFO - 2016-08-12 17:32:22 --> Helper loaded: url_helper
INFO - 2016-08-12 17:32:22 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:32:22 --> Helper loaded: html_helper
INFO - 2016-08-12 17:32:22 --> Helper loaded: form_helper
INFO - 2016-08-12 17:32:22 --> Helper loaded: file_helper
INFO - 2016-08-12 17:32:22 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:32:22 --> Database Driver Class Initialized
INFO - 2016-08-12 17:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:32:22 --> Form Validation Class Initialized
INFO - 2016-08-12 17:32:22 --> Email Class Initialized
INFO - 2016-08-12 17:32:22 --> Controller Class Initialized
DEBUG - 2016-08-12 17:32:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:32:22 --> Model Class Initialized
INFO - 2016-08-12 17:32:22 --> Model Class Initialized
INFO - 2016-08-12 17:32:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:32:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:39:08 --> Config Class Initialized
INFO - 2016-08-12 17:39:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:39:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:39:08 --> Utf8 Class Initialized
INFO - 2016-08-12 17:39:08 --> URI Class Initialized
INFO - 2016-08-12 17:39:08 --> Router Class Initialized
INFO - 2016-08-12 17:39:08 --> Output Class Initialized
INFO - 2016-08-12 17:39:08 --> Security Class Initialized
DEBUG - 2016-08-12 17:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:39:08 --> Input Class Initialized
INFO - 2016-08-12 17:39:08 --> Language Class Initialized
INFO - 2016-08-12 17:39:08 --> Loader Class Initialized
INFO - 2016-08-12 17:39:08 --> Helper loaded: url_helper
INFO - 2016-08-12 17:39:08 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:39:08 --> Helper loaded: html_helper
INFO - 2016-08-12 17:39:08 --> Helper loaded: form_helper
INFO - 2016-08-12 17:39:08 --> Helper loaded: file_helper
INFO - 2016-08-12 17:39:08 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:39:08 --> Database Driver Class Initialized
INFO - 2016-08-12 17:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:39:08 --> Form Validation Class Initialized
INFO - 2016-08-12 17:39:08 --> Email Class Initialized
INFO - 2016-08-12 17:39:08 --> Controller Class Initialized
DEBUG - 2016-08-12 17:39:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:39:08 --> Model Class Initialized
INFO - 2016-08-12 17:39:08 --> Model Class Initialized
INFO - 2016-08-12 17:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 17:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:39:08 --> Final output sent to browser
DEBUG - 2016-08-12 17:39:08 --> Total execution time: 0.2893
INFO - 2016-08-12 17:39:19 --> Config Class Initialized
INFO - 2016-08-12 17:39:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:39:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:39:19 --> Utf8 Class Initialized
INFO - 2016-08-12 17:39:19 --> URI Class Initialized
INFO - 2016-08-12 17:39:19 --> Router Class Initialized
INFO - 2016-08-12 17:39:19 --> Output Class Initialized
INFO - 2016-08-12 17:39:19 --> Security Class Initialized
DEBUG - 2016-08-12 17:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:39:19 --> Input Class Initialized
INFO - 2016-08-12 17:39:19 --> Language Class Initialized
INFO - 2016-08-12 17:39:19 --> Loader Class Initialized
INFO - 2016-08-12 17:39:19 --> Helper loaded: url_helper
INFO - 2016-08-12 17:39:19 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:39:19 --> Helper loaded: html_helper
INFO - 2016-08-12 17:39:19 --> Helper loaded: form_helper
INFO - 2016-08-12 17:39:19 --> Helper loaded: file_helper
INFO - 2016-08-12 17:39:19 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:39:19 --> Database Driver Class Initialized
INFO - 2016-08-12 17:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:39:19 --> Form Validation Class Initialized
INFO - 2016-08-12 17:39:19 --> Email Class Initialized
INFO - 2016-08-12 17:39:19 --> Controller Class Initialized
DEBUG - 2016-08-12 17:39:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:39:19 --> Model Class Initialized
INFO - 2016-08-12 17:39:19 --> Model Class Initialized
INFO - 2016-08-12 17:39:19 --> Model Class Initialized
INFO - 2016-08-12 17:39:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:39:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:39:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-12 17:39:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:39:19 --> Final output sent to browser
DEBUG - 2016-08-12 17:39:19 --> Total execution time: 0.2377
INFO - 2016-08-12 17:40:28 --> Config Class Initialized
INFO - 2016-08-12 17:40:28 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:40:28 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:40:28 --> Utf8 Class Initialized
INFO - 2016-08-12 17:40:28 --> URI Class Initialized
INFO - 2016-08-12 17:40:28 --> Router Class Initialized
INFO - 2016-08-12 17:40:28 --> Output Class Initialized
INFO - 2016-08-12 17:40:28 --> Security Class Initialized
DEBUG - 2016-08-12 17:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:40:28 --> Input Class Initialized
INFO - 2016-08-12 17:40:28 --> Language Class Initialized
INFO - 2016-08-12 17:40:28 --> Loader Class Initialized
INFO - 2016-08-12 17:40:28 --> Helper loaded: url_helper
INFO - 2016-08-12 17:40:28 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:40:28 --> Helper loaded: html_helper
INFO - 2016-08-12 17:40:28 --> Helper loaded: form_helper
INFO - 2016-08-12 17:40:28 --> Helper loaded: file_helper
INFO - 2016-08-12 17:40:28 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:40:28 --> Database Driver Class Initialized
INFO - 2016-08-12 17:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:40:28 --> Form Validation Class Initialized
INFO - 2016-08-12 17:40:28 --> Email Class Initialized
INFO - 2016-08-12 17:40:28 --> Controller Class Initialized
DEBUG - 2016-08-12 17:40:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:40:28 --> Model Class Initialized
INFO - 2016-08-12 17:40:28 --> Model Class Initialized
INFO - 2016-08-12 17:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 17:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:40:28 --> Final output sent to browser
DEBUG - 2016-08-12 17:40:28 --> Total execution time: 0.2746
INFO - 2016-08-12 17:59:50 --> Config Class Initialized
INFO - 2016-08-12 17:59:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:59:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:59:50 --> Utf8 Class Initialized
INFO - 2016-08-12 17:59:50 --> URI Class Initialized
INFO - 2016-08-12 17:59:50 --> Router Class Initialized
INFO - 2016-08-12 17:59:50 --> Output Class Initialized
INFO - 2016-08-12 17:59:50 --> Security Class Initialized
DEBUG - 2016-08-12 17:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:59:50 --> Input Class Initialized
INFO - 2016-08-12 17:59:50 --> Language Class Initialized
INFO - 2016-08-12 17:59:50 --> Loader Class Initialized
INFO - 2016-08-12 17:59:50 --> Helper loaded: url_helper
INFO - 2016-08-12 17:59:50 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:59:50 --> Helper loaded: html_helper
INFO - 2016-08-12 17:59:50 --> Helper loaded: form_helper
INFO - 2016-08-12 17:59:50 --> Helper loaded: file_helper
INFO - 2016-08-12 17:59:50 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:59:50 --> Database Driver Class Initialized
INFO - 2016-08-12 17:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:59:50 --> Form Validation Class Initialized
INFO - 2016-08-12 17:59:50 --> Email Class Initialized
INFO - 2016-08-12 17:59:50 --> Controller Class Initialized
DEBUG - 2016-08-12 17:59:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:59:50 --> Model Class Initialized
INFO - 2016-08-12 17:59:50 --> Model Class Initialized
INFO - 2016-08-12 17:59:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:59:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 17:59:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 17:59:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:59:50 --> Final output sent to browser
DEBUG - 2016-08-12 17:59:50 --> Total execution time: 0.2452
INFO - 2016-08-12 17:59:58 --> Config Class Initialized
INFO - 2016-08-12 17:59:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:59:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:59:59 --> Utf8 Class Initialized
INFO - 2016-08-12 17:59:59 --> URI Class Initialized
INFO - 2016-08-12 17:59:59 --> Router Class Initialized
INFO - 2016-08-12 17:59:59 --> Output Class Initialized
INFO - 2016-08-12 17:59:59 --> Security Class Initialized
DEBUG - 2016-08-12 17:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:59:59 --> Input Class Initialized
INFO - 2016-08-12 17:59:59 --> Language Class Initialized
INFO - 2016-08-12 17:59:59 --> Loader Class Initialized
INFO - 2016-08-12 17:59:59 --> Helper loaded: url_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: html_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: form_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: file_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:59:59 --> Database Driver Class Initialized
INFO - 2016-08-12 17:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:59:59 --> Form Validation Class Initialized
INFO - 2016-08-12 17:59:59 --> Email Class Initialized
INFO - 2016-08-12 17:59:59 --> Controller Class Initialized
INFO - 2016-08-12 17:59:59 --> Model Class Initialized
INFO - 2016-08-12 17:59:59 --> Config Class Initialized
INFO - 2016-08-12 17:59:59 --> Hooks Class Initialized
DEBUG - 2016-08-12 17:59:59 --> UTF-8 Support Enabled
INFO - 2016-08-12 17:59:59 --> Utf8 Class Initialized
INFO - 2016-08-12 17:59:59 --> URI Class Initialized
INFO - 2016-08-12 17:59:59 --> Router Class Initialized
INFO - 2016-08-12 17:59:59 --> Output Class Initialized
INFO - 2016-08-12 17:59:59 --> Security Class Initialized
DEBUG - 2016-08-12 17:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 17:59:59 --> Input Class Initialized
INFO - 2016-08-12 17:59:59 --> Language Class Initialized
INFO - 2016-08-12 17:59:59 --> Loader Class Initialized
INFO - 2016-08-12 17:59:59 --> Helper loaded: url_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: utils_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: html_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: form_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: file_helper
INFO - 2016-08-12 17:59:59 --> Helper loaded: myemail_helper
INFO - 2016-08-12 17:59:59 --> Database Driver Class Initialized
INFO - 2016-08-12 17:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 17:59:59 --> Form Validation Class Initialized
INFO - 2016-08-12 17:59:59 --> Email Class Initialized
INFO - 2016-08-12 17:59:59 --> Controller Class Initialized
INFO - 2016-08-12 17:59:59 --> Model Class Initialized
DEBUG - 2016-08-12 17:59:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 17:59:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-12 17:59:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 17:59:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-12 17:59:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 17:59:59 --> Final output sent to browser
DEBUG - 2016-08-12 17:59:59 --> Total execution time: 0.2297
INFO - 2016-08-12 18:00:03 --> Config Class Initialized
INFO - 2016-08-12 18:00:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:00:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:00:03 --> Utf8 Class Initialized
INFO - 2016-08-12 18:00:03 --> URI Class Initialized
INFO - 2016-08-12 18:00:04 --> Router Class Initialized
INFO - 2016-08-12 18:00:04 --> Output Class Initialized
INFO - 2016-08-12 18:00:04 --> Security Class Initialized
DEBUG - 2016-08-12 18:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:00:04 --> Input Class Initialized
INFO - 2016-08-12 18:00:04 --> Language Class Initialized
INFO - 2016-08-12 18:00:04 --> Loader Class Initialized
INFO - 2016-08-12 18:00:04 --> Helper loaded: url_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: html_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: form_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: file_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:00:04 --> Database Driver Class Initialized
INFO - 2016-08-12 18:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:00:04 --> Form Validation Class Initialized
INFO - 2016-08-12 18:00:04 --> Email Class Initialized
INFO - 2016-08-12 18:00:04 --> Controller Class Initialized
INFO - 2016-08-12 18:00:04 --> Model Class Initialized
DEBUG - 2016-08-12 18:00:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:00:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 18:00:04 --> Config Class Initialized
INFO - 2016-08-12 18:00:04 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:00:04 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:00:04 --> Utf8 Class Initialized
INFO - 2016-08-12 18:00:04 --> URI Class Initialized
INFO - 2016-08-12 18:00:04 --> Router Class Initialized
INFO - 2016-08-12 18:00:04 --> Output Class Initialized
INFO - 2016-08-12 18:00:04 --> Security Class Initialized
DEBUG - 2016-08-12 18:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:00:04 --> Input Class Initialized
INFO - 2016-08-12 18:00:04 --> Language Class Initialized
INFO - 2016-08-12 18:00:04 --> Loader Class Initialized
INFO - 2016-08-12 18:00:04 --> Helper loaded: url_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: html_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: form_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: file_helper
INFO - 2016-08-12 18:00:04 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:00:04 --> Database Driver Class Initialized
INFO - 2016-08-12 18:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:00:04 --> Form Validation Class Initialized
INFO - 2016-08-12 18:00:04 --> Email Class Initialized
INFO - 2016-08-12 18:00:04 --> Controller Class Initialized
INFO - 2016-08-12 18:00:04 --> Model Class Initialized
INFO - 2016-08-12 18:00:04 --> Model Class Initialized
INFO - 2016-08-12 18:00:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:00:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:00:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:00:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:00:04 --> Final output sent to browser
DEBUG - 2016-08-12 18:00:04 --> Total execution time: 0.3635
INFO - 2016-08-12 18:00:09 --> Config Class Initialized
INFO - 2016-08-12 18:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:00:09 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:00:09 --> Utf8 Class Initialized
INFO - 2016-08-12 18:00:09 --> URI Class Initialized
INFO - 2016-08-12 18:00:09 --> Router Class Initialized
INFO - 2016-08-12 18:00:09 --> Output Class Initialized
INFO - 2016-08-12 18:00:09 --> Security Class Initialized
DEBUG - 2016-08-12 18:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:00:09 --> Input Class Initialized
INFO - 2016-08-12 18:00:09 --> Language Class Initialized
INFO - 2016-08-12 18:00:09 --> Loader Class Initialized
INFO - 2016-08-12 18:00:09 --> Helper loaded: url_helper
INFO - 2016-08-12 18:00:09 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:00:09 --> Helper loaded: html_helper
INFO - 2016-08-12 18:00:10 --> Helper loaded: form_helper
INFO - 2016-08-12 18:00:10 --> Helper loaded: file_helper
INFO - 2016-08-12 18:00:10 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:00:10 --> Database Driver Class Initialized
INFO - 2016-08-12 18:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:00:10 --> Form Validation Class Initialized
INFO - 2016-08-12 18:00:10 --> Email Class Initialized
INFO - 2016-08-12 18:00:10 --> Controller Class Initialized
DEBUG - 2016-08-12 18:00:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:00:10 --> Model Class Initialized
INFO - 2016-08-12 18:00:10 --> Model Class Initialized
INFO - 2016-08-12 18:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 18:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:00:10 --> Final output sent to browser
DEBUG - 2016-08-12 18:00:10 --> Total execution time: 0.2679
INFO - 2016-08-12 18:00:45 --> Config Class Initialized
INFO - 2016-08-12 18:00:45 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:00:45 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:00:45 --> Utf8 Class Initialized
INFO - 2016-08-12 18:00:45 --> URI Class Initialized
INFO - 2016-08-12 18:00:45 --> Router Class Initialized
INFO - 2016-08-12 18:00:45 --> Output Class Initialized
INFO - 2016-08-12 18:00:45 --> Security Class Initialized
DEBUG - 2016-08-12 18:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:00:45 --> Input Class Initialized
INFO - 2016-08-12 18:00:45 --> Language Class Initialized
INFO - 2016-08-12 18:00:45 --> Loader Class Initialized
INFO - 2016-08-12 18:00:45 --> Helper loaded: url_helper
INFO - 2016-08-12 18:00:45 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:00:45 --> Helper loaded: html_helper
INFO - 2016-08-12 18:00:45 --> Helper loaded: form_helper
INFO - 2016-08-12 18:00:45 --> Helper loaded: file_helper
INFO - 2016-08-12 18:00:45 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:00:45 --> Database Driver Class Initialized
INFO - 2016-08-12 18:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:00:45 --> Form Validation Class Initialized
INFO - 2016-08-12 18:00:45 --> Email Class Initialized
INFO - 2016-08-12 18:00:45 --> Controller Class Initialized
DEBUG - 2016-08-12 18:00:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:00:45 --> Model Class Initialized
INFO - 2016-08-12 18:00:45 --> Model Class Initialized
INFO - 2016-08-12 18:01:02 --> Config Class Initialized
INFO - 2016-08-12 18:01:02 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:02 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:02 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:02 --> URI Class Initialized
INFO - 2016-08-12 18:01:02 --> Router Class Initialized
INFO - 2016-08-12 18:01:02 --> Output Class Initialized
INFO - 2016-08-12 18:01:02 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:02 --> Input Class Initialized
INFO - 2016-08-12 18:01:02 --> Language Class Initialized
INFO - 2016-08-12 18:01:02 --> Loader Class Initialized
INFO - 2016-08-12 18:01:02 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:02 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:02 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:02 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:02 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:02 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:02 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:02 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:02 --> Email Class Initialized
INFO - 2016-08-12 18:01:02 --> Controller Class Initialized
INFO - 2016-08-12 18:01:02 --> Model Class Initialized
INFO - 2016-08-12 18:01:02 --> Model Class Initialized
INFO - 2016-08-12 18:01:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:01:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:01:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:01:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:01:02 --> Final output sent to browser
DEBUG - 2016-08-12 18:01:02 --> Total execution time: 0.2933
INFO - 2016-08-12 18:01:06 --> Config Class Initialized
INFO - 2016-08-12 18:01:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:06 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:06 --> URI Class Initialized
INFO - 2016-08-12 18:01:06 --> Router Class Initialized
INFO - 2016-08-12 18:01:06 --> Output Class Initialized
INFO - 2016-08-12 18:01:06 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:06 --> Input Class Initialized
INFO - 2016-08-12 18:01:06 --> Language Class Initialized
INFO - 2016-08-12 18:01:06 --> Loader Class Initialized
INFO - 2016-08-12 18:01:06 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:06 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:06 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:06 --> Email Class Initialized
INFO - 2016-08-12 18:01:06 --> Controller Class Initialized
INFO - 2016-08-12 18:01:06 --> Model Class Initialized
INFO - 2016-08-12 18:01:06 --> Config Class Initialized
INFO - 2016-08-12 18:01:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:06 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:06 --> URI Class Initialized
INFO - 2016-08-12 18:01:06 --> Router Class Initialized
INFO - 2016-08-12 18:01:06 --> Output Class Initialized
INFO - 2016-08-12 18:01:06 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:06 --> Input Class Initialized
INFO - 2016-08-12 18:01:06 --> Language Class Initialized
INFO - 2016-08-12 18:01:06 --> Loader Class Initialized
INFO - 2016-08-12 18:01:06 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:06 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:06 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:06 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:06 --> Email Class Initialized
INFO - 2016-08-12 18:01:06 --> Controller Class Initialized
INFO - 2016-08-12 18:01:06 --> Model Class Initialized
DEBUG - 2016-08-12 18:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:01:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-12 18:01:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:01:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-12 18:01:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:01:07 --> Final output sent to browser
DEBUG - 2016-08-12 18:01:07 --> Total execution time: 0.3545
INFO - 2016-08-12 18:01:10 --> Config Class Initialized
INFO - 2016-08-12 18:01:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:10 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:10 --> URI Class Initialized
INFO - 2016-08-12 18:01:10 --> Router Class Initialized
INFO - 2016-08-12 18:01:10 --> Output Class Initialized
INFO - 2016-08-12 18:01:10 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:10 --> Input Class Initialized
INFO - 2016-08-12 18:01:10 --> Language Class Initialized
INFO - 2016-08-12 18:01:10 --> Loader Class Initialized
INFO - 2016-08-12 18:01:10 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:10 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:10 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:10 --> Email Class Initialized
INFO - 2016-08-12 18:01:10 --> Controller Class Initialized
INFO - 2016-08-12 18:01:10 --> Model Class Initialized
DEBUG - 2016-08-12 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:01:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 18:01:10 --> Config Class Initialized
INFO - 2016-08-12 18:01:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:10 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:10 --> URI Class Initialized
INFO - 2016-08-12 18:01:10 --> Router Class Initialized
INFO - 2016-08-12 18:01:10 --> Output Class Initialized
INFO - 2016-08-12 18:01:10 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:10 --> Input Class Initialized
INFO - 2016-08-12 18:01:10 --> Language Class Initialized
INFO - 2016-08-12 18:01:10 --> Loader Class Initialized
INFO - 2016-08-12 18:01:10 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:10 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:10 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:10 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:10 --> Email Class Initialized
INFO - 2016-08-12 18:01:10 --> Controller Class Initialized
DEBUG - 2016-08-12 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-12 18:01:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:01:10 --> Model Class Initialized
INFO - 2016-08-12 18:01:10 --> Model Class Initialized
INFO - 2016-08-12 18:01:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:01:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:01:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-12 18:01:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:01:10 --> Final output sent to browser
DEBUG - 2016-08-12 18:01:10 --> Total execution time: 0.4927
INFO - 2016-08-12 18:01:16 --> Config Class Initialized
INFO - 2016-08-12 18:01:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:01:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:01:16 --> Utf8 Class Initialized
INFO - 2016-08-12 18:01:16 --> URI Class Initialized
INFO - 2016-08-12 18:01:16 --> Router Class Initialized
INFO - 2016-08-12 18:01:16 --> Output Class Initialized
INFO - 2016-08-12 18:01:16 --> Security Class Initialized
DEBUG - 2016-08-12 18:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:01:16 --> Input Class Initialized
INFO - 2016-08-12 18:01:16 --> Language Class Initialized
INFO - 2016-08-12 18:01:16 --> Loader Class Initialized
INFO - 2016-08-12 18:01:16 --> Helper loaded: url_helper
INFO - 2016-08-12 18:01:16 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:01:16 --> Helper loaded: html_helper
INFO - 2016-08-12 18:01:16 --> Helper loaded: form_helper
INFO - 2016-08-12 18:01:16 --> Helper loaded: file_helper
INFO - 2016-08-12 18:01:16 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:01:16 --> Database Driver Class Initialized
INFO - 2016-08-12 18:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:01:16 --> Form Validation Class Initialized
INFO - 2016-08-12 18:01:16 --> Email Class Initialized
INFO - 2016-08-12 18:01:16 --> Controller Class Initialized
DEBUG - 2016-08-12 18:01:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:01:16 --> Model Class Initialized
INFO - 2016-08-12 18:01:16 --> Model Class Initialized
INFO - 2016-08-12 18:02:01 --> Config Class Initialized
INFO - 2016-08-12 18:02:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:01 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:01 --> URI Class Initialized
INFO - 2016-08-12 18:02:01 --> Router Class Initialized
INFO - 2016-08-12 18:02:01 --> Output Class Initialized
INFO - 2016-08-12 18:02:01 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:01 --> Input Class Initialized
INFO - 2016-08-12 18:02:01 --> Language Class Initialized
INFO - 2016-08-12 18:02:01 --> Loader Class Initialized
INFO - 2016-08-12 18:02:01 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:01 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:01 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:01 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:01 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:01 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:01 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:01 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:01 --> Email Class Initialized
INFO - 2016-08-12 18:02:01 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-12 18:02:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:01 --> Model Class Initialized
INFO - 2016-08-12 18:02:01 --> Model Class Initialized
INFO - 2016-08-12 18:02:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-12 18:02:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:01 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:01 --> Total execution time: 0.3612
INFO - 2016-08-12 18:02:06 --> Config Class Initialized
INFO - 2016-08-12 18:02:06 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:06 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:06 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:06 --> URI Class Initialized
INFO - 2016-08-12 18:02:06 --> Router Class Initialized
INFO - 2016-08-12 18:02:06 --> Output Class Initialized
INFO - 2016-08-12 18:02:06 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:06 --> Input Class Initialized
INFO - 2016-08-12 18:02:06 --> Language Class Initialized
INFO - 2016-08-12 18:02:06 --> Loader Class Initialized
INFO - 2016-08-12 18:02:06 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:06 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:06 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:06 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:06 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:06 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:06 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:06 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:06 --> Email Class Initialized
INFO - 2016-08-12 18:02:06 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:06 --> Model Class Initialized
INFO - 2016-08-12 18:02:06 --> Model Class Initialized
INFO - 2016-08-12 18:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-12 18:02:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:06 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:06 --> Total execution time: 0.2781
INFO - 2016-08-12 18:02:27 --> Config Class Initialized
INFO - 2016-08-12 18:02:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:27 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:27 --> URI Class Initialized
DEBUG - 2016-08-12 18:02:27 --> No URI present. Default controller set.
INFO - 2016-08-12 18:02:27 --> Router Class Initialized
INFO - 2016-08-12 18:02:27 --> Output Class Initialized
INFO - 2016-08-12 18:02:27 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:27 --> Input Class Initialized
INFO - 2016-08-12 18:02:27 --> Language Class Initialized
INFO - 2016-08-12 18:02:27 --> Loader Class Initialized
INFO - 2016-08-12 18:02:27 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:27 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:27 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:27 --> Email Class Initialized
INFO - 2016-08-12 18:02:27 --> Controller Class Initialized
INFO - 2016-08-12 18:02:27 --> Config Class Initialized
INFO - 2016-08-12 18:02:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:27 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:27 --> URI Class Initialized
INFO - 2016-08-12 18:02:27 --> Router Class Initialized
INFO - 2016-08-12 18:02:27 --> Output Class Initialized
INFO - 2016-08-12 18:02:27 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:27 --> Input Class Initialized
INFO - 2016-08-12 18:02:27 --> Language Class Initialized
INFO - 2016-08-12 18:02:27 --> Loader Class Initialized
INFO - 2016-08-12 18:02:27 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:27 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:27 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:27 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:27 --> Email Class Initialized
INFO - 2016-08-12 18:02:27 --> Controller Class Initialized
INFO - 2016-08-12 18:02:27 --> Model Class Initialized
DEBUG - 2016-08-12 18:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-12 18:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-12 18:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:27 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:27 --> Total execution time: 0.2731
INFO - 2016-08-12 18:02:34 --> Config Class Initialized
INFO - 2016-08-12 18:02:34 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:34 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:34 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:34 --> URI Class Initialized
INFO - 2016-08-12 18:02:34 --> Router Class Initialized
INFO - 2016-08-12 18:02:34 --> Output Class Initialized
INFO - 2016-08-12 18:02:34 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:34 --> Input Class Initialized
INFO - 2016-08-12 18:02:34 --> Language Class Initialized
ERROR - 2016-08-12 18:02:34 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-12 18:02:40 --> Config Class Initialized
INFO - 2016-08-12 18:02:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:40 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:40 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:40 --> URI Class Initialized
INFO - 2016-08-12 18:02:40 --> Router Class Initialized
INFO - 2016-08-12 18:02:40 --> Output Class Initialized
INFO - 2016-08-12 18:02:40 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:40 --> Input Class Initialized
INFO - 2016-08-12 18:02:40 --> Language Class Initialized
INFO - 2016-08-12 18:02:40 --> Loader Class Initialized
INFO - 2016-08-12 18:02:40 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:40 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:40 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:40 --> Email Class Initialized
INFO - 2016-08-12 18:02:40 --> Controller Class Initialized
INFO - 2016-08-12 18:02:40 --> Model Class Initialized
DEBUG - 2016-08-12 18:02:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 18:02:40 --> Config Class Initialized
INFO - 2016-08-12 18:02:40 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:40 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:40 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:40 --> URI Class Initialized
DEBUG - 2016-08-12 18:02:40 --> No URI present. Default controller set.
INFO - 2016-08-12 18:02:40 --> Router Class Initialized
INFO - 2016-08-12 18:02:40 --> Output Class Initialized
INFO - 2016-08-12 18:02:40 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:40 --> Input Class Initialized
INFO - 2016-08-12 18:02:40 --> Language Class Initialized
INFO - 2016-08-12 18:02:40 --> Loader Class Initialized
INFO - 2016-08-12 18:02:40 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:40 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:40 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:40 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:40 --> Email Class Initialized
INFO - 2016-08-12 18:02:40 --> Controller Class Initialized
INFO - 2016-08-12 18:02:40 --> Model Class Initialized
INFO - 2016-08-12 18:02:40 --> Model Class Initialized
INFO - 2016-08-12 18:02:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:02:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:40 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:40 --> Total execution time: 0.2846
INFO - 2016-08-12 18:02:46 --> Config Class Initialized
INFO - 2016-08-12 18:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:46 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:46 --> URI Class Initialized
INFO - 2016-08-12 18:02:46 --> Router Class Initialized
INFO - 2016-08-12 18:02:46 --> Output Class Initialized
INFO - 2016-08-12 18:02:46 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:46 --> Input Class Initialized
INFO - 2016-08-12 18:02:46 --> Language Class Initialized
INFO - 2016-08-12 18:02:46 --> Loader Class Initialized
INFO - 2016-08-12 18:02:46 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:46 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:46 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:46 --> Email Class Initialized
INFO - 2016-08-12 18:02:46 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:46 --> Model Class Initialized
INFO - 2016-08-12 18:02:46 --> Model Class Initialized
INFO - 2016-08-12 18:02:46 --> Config Class Initialized
INFO - 2016-08-12 18:02:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:46 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:46 --> URI Class Initialized
INFO - 2016-08-12 18:02:46 --> Router Class Initialized
INFO - 2016-08-12 18:02:46 --> Output Class Initialized
INFO - 2016-08-12 18:02:46 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:46 --> Input Class Initialized
INFO - 2016-08-12 18:02:46 --> Language Class Initialized
INFO - 2016-08-12 18:02:46 --> Loader Class Initialized
INFO - 2016-08-12 18:02:46 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:46 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:46 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:46 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:46 --> Email Class Initialized
INFO - 2016-08-12 18:02:46 --> Controller Class Initialized
INFO - 2016-08-12 18:02:46 --> Model Class Initialized
INFO - 2016-08-12 18:02:46 --> Model Class Initialized
INFO - 2016-08-12 18:02:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:02:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:47 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:47 --> Total execution time: 0.3224
INFO - 2016-08-12 18:02:52 --> Config Class Initialized
INFO - 2016-08-12 18:02:52 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:52 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:52 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:52 --> URI Class Initialized
INFO - 2016-08-12 18:02:52 --> Router Class Initialized
INFO - 2016-08-12 18:02:52 --> Output Class Initialized
INFO - 2016-08-12 18:02:52 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:52 --> Input Class Initialized
INFO - 2016-08-12 18:02:52 --> Language Class Initialized
INFO - 2016-08-12 18:02:52 --> Loader Class Initialized
INFO - 2016-08-12 18:02:52 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:52 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:52 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:52 --> Email Class Initialized
INFO - 2016-08-12 18:02:52 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:52 --> Model Class Initialized
INFO - 2016-08-12 18:02:52 --> Model Class Initialized
INFO - 2016-08-12 18:02:52 --> Config Class Initialized
INFO - 2016-08-12 18:02:52 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:52 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:52 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:52 --> URI Class Initialized
INFO - 2016-08-12 18:02:52 --> Router Class Initialized
INFO - 2016-08-12 18:02:52 --> Output Class Initialized
INFO - 2016-08-12 18:02:52 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:52 --> Input Class Initialized
INFO - 2016-08-12 18:02:52 --> Language Class Initialized
INFO - 2016-08-12 18:02:52 --> Loader Class Initialized
INFO - 2016-08-12 18:02:52 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:52 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:52 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:52 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:52 --> Email Class Initialized
INFO - 2016-08-12 18:02:52 --> Controller Class Initialized
INFO - 2016-08-12 18:02:52 --> Model Class Initialized
INFO - 2016-08-12 18:02:52 --> Model Class Initialized
INFO - 2016-08-12 18:02:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:02:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:52 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:52 --> Total execution time: 0.2720
INFO - 2016-08-12 18:02:54 --> Config Class Initialized
INFO - 2016-08-12 18:02:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:54 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:54 --> URI Class Initialized
INFO - 2016-08-12 18:02:54 --> Router Class Initialized
INFO - 2016-08-12 18:02:54 --> Output Class Initialized
INFO - 2016-08-12 18:02:54 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:54 --> Input Class Initialized
INFO - 2016-08-12 18:02:54 --> Language Class Initialized
INFO - 2016-08-12 18:02:54 --> Loader Class Initialized
INFO - 2016-08-12 18:02:54 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:54 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:54 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:54 --> Email Class Initialized
INFO - 2016-08-12 18:02:54 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:54 --> Model Class Initialized
INFO - 2016-08-12 18:02:54 --> Model Class Initialized
INFO - 2016-08-12 18:02:54 --> Config Class Initialized
INFO - 2016-08-12 18:02:54 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:54 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:54 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:54 --> URI Class Initialized
INFO - 2016-08-12 18:02:54 --> Router Class Initialized
INFO - 2016-08-12 18:02:54 --> Output Class Initialized
INFO - 2016-08-12 18:02:54 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:54 --> Input Class Initialized
INFO - 2016-08-12 18:02:54 --> Language Class Initialized
INFO - 2016-08-12 18:02:54 --> Loader Class Initialized
INFO - 2016-08-12 18:02:54 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:54 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:54 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:54 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:54 --> Email Class Initialized
INFO - 2016-08-12 18:02:54 --> Controller Class Initialized
INFO - 2016-08-12 18:02:54 --> Model Class Initialized
INFO - 2016-08-12 18:02:54 --> Model Class Initialized
INFO - 2016-08-12 18:02:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:02:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:54 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:54 --> Total execution time: 0.3225
INFO - 2016-08-12 18:02:57 --> Config Class Initialized
INFO - 2016-08-12 18:02:57 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:57 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:57 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:57 --> URI Class Initialized
INFO - 2016-08-12 18:02:57 --> Router Class Initialized
INFO - 2016-08-12 18:02:57 --> Output Class Initialized
INFO - 2016-08-12 18:02:57 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:57 --> Input Class Initialized
INFO - 2016-08-12 18:02:57 --> Language Class Initialized
INFO - 2016-08-12 18:02:57 --> Loader Class Initialized
INFO - 2016-08-12 18:02:57 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:57 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:58 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:58 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:58 --> Email Class Initialized
INFO - 2016-08-12 18:02:58 --> Controller Class Initialized
DEBUG - 2016-08-12 18:02:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:02:58 --> Model Class Initialized
INFO - 2016-08-12 18:02:58 --> Model Class Initialized
INFO - 2016-08-12 18:02:58 --> Config Class Initialized
INFO - 2016-08-12 18:02:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:02:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:02:58 --> Utf8 Class Initialized
INFO - 2016-08-12 18:02:58 --> URI Class Initialized
INFO - 2016-08-12 18:02:58 --> Router Class Initialized
INFO - 2016-08-12 18:02:58 --> Output Class Initialized
INFO - 2016-08-12 18:02:58 --> Security Class Initialized
DEBUG - 2016-08-12 18:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:02:58 --> Input Class Initialized
INFO - 2016-08-12 18:02:58 --> Language Class Initialized
INFO - 2016-08-12 18:02:58 --> Loader Class Initialized
INFO - 2016-08-12 18:02:58 --> Helper loaded: url_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: html_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: form_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: file_helper
INFO - 2016-08-12 18:02:58 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:02:58 --> Database Driver Class Initialized
INFO - 2016-08-12 18:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:02:58 --> Form Validation Class Initialized
INFO - 2016-08-12 18:02:58 --> Email Class Initialized
INFO - 2016-08-12 18:02:58 --> Controller Class Initialized
INFO - 2016-08-12 18:02:58 --> Model Class Initialized
INFO - 2016-08-12 18:02:58 --> Model Class Initialized
INFO - 2016-08-12 18:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:02:58 --> Final output sent to browser
DEBUG - 2016-08-12 18:02:58 --> Total execution time: 0.3628
INFO - 2016-08-12 18:04:01 --> Config Class Initialized
INFO - 2016-08-12 18:04:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:01 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:01 --> URI Class Initialized
INFO - 2016-08-12 18:04:01 --> Router Class Initialized
INFO - 2016-08-12 18:04:01 --> Output Class Initialized
INFO - 2016-08-12 18:04:01 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:01 --> Input Class Initialized
INFO - 2016-08-12 18:04:01 --> Language Class Initialized
INFO - 2016-08-12 18:04:01 --> Loader Class Initialized
INFO - 2016-08-12 18:04:01 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:01 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:01 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:01 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:01 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:01 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:01 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:01 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:01 --> Email Class Initialized
INFO - 2016-08-12 18:04:01 --> Controller Class Initialized
INFO - 2016-08-12 18:04:01 --> Model Class Initialized
INFO - 2016-08-12 18:04:01 --> Model Class Initialized
INFO - 2016-08-12 18:04:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:04:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:01 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:01 --> Total execution time: 0.3598
INFO - 2016-08-12 18:04:03 --> Config Class Initialized
INFO - 2016-08-12 18:04:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:03 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:03 --> URI Class Initialized
INFO - 2016-08-12 18:04:03 --> Router Class Initialized
INFO - 2016-08-12 18:04:03 --> Output Class Initialized
INFO - 2016-08-12 18:04:03 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:03 --> Input Class Initialized
INFO - 2016-08-12 18:04:03 --> Language Class Initialized
INFO - 2016-08-12 18:04:03 --> Loader Class Initialized
INFO - 2016-08-12 18:04:03 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:03 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:03 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:03 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:03 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:03 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:03 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:03 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:03 --> Email Class Initialized
INFO - 2016-08-12 18:04:03 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:03 --> Model Class Initialized
INFO - 2016-08-12 18:04:03 --> Model Class Initialized
INFO - 2016-08-12 18:04:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:04:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:03 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:03 --> Total execution time: 0.3799
INFO - 2016-08-12 18:04:12 --> Config Class Initialized
INFO - 2016-08-12 18:04:12 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:12 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:12 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:12 --> URI Class Initialized
INFO - 2016-08-12 18:04:12 --> Router Class Initialized
INFO - 2016-08-12 18:04:12 --> Output Class Initialized
INFO - 2016-08-12 18:04:12 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:12 --> Input Class Initialized
INFO - 2016-08-12 18:04:12 --> Language Class Initialized
INFO - 2016-08-12 18:04:12 --> Loader Class Initialized
INFO - 2016-08-12 18:04:12 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:12 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:12 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:12 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:12 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:12 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:12 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:12 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:12 --> Email Class Initialized
INFO - 2016-08-12 18:04:12 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:12 --> Model Class Initialized
INFO - 2016-08-12 18:04:12 --> Model Class Initialized
INFO - 2016-08-12 18:04:12 --> Model Class Initialized
INFO - 2016-08-12 18:04:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-12 18:04:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:12 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:12 --> Total execution time: 0.3898
INFO - 2016-08-12 18:04:17 --> Config Class Initialized
INFO - 2016-08-12 18:04:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:17 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:17 --> URI Class Initialized
INFO - 2016-08-12 18:04:17 --> Router Class Initialized
INFO - 2016-08-12 18:04:17 --> Output Class Initialized
INFO - 2016-08-12 18:04:17 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:17 --> Input Class Initialized
INFO - 2016-08-12 18:04:17 --> Language Class Initialized
INFO - 2016-08-12 18:04:17 --> Loader Class Initialized
INFO - 2016-08-12 18:04:17 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:17 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:17 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:17 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:17 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:17 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:17 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:17 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:17 --> Email Class Initialized
INFO - 2016-08-12 18:04:17 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:17 --> Model Class Initialized
INFO - 2016-08-12 18:04:17 --> Model Class Initialized
INFO - 2016-08-12 18:04:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:04:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:17 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:17 --> Total execution time: 0.4407
INFO - 2016-08-12 18:04:19 --> Config Class Initialized
INFO - 2016-08-12 18:04:19 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:19 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:19 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:19 --> URI Class Initialized
INFO - 2016-08-12 18:04:19 --> Router Class Initialized
INFO - 2016-08-12 18:04:19 --> Output Class Initialized
INFO - 2016-08-12 18:04:19 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:19 --> Input Class Initialized
INFO - 2016-08-12 18:04:19 --> Language Class Initialized
INFO - 2016-08-12 18:04:20 --> Loader Class Initialized
INFO - 2016-08-12 18:04:20 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:20 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:20 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:20 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:20 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:20 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:20 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:20 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:20 --> Email Class Initialized
INFO - 2016-08-12 18:04:20 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:20 --> Model Class Initialized
INFO - 2016-08-12 18:04:20 --> Model Class Initialized
INFO - 2016-08-12 18:04:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:04:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:20 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:20 --> Total execution time: 0.4699
INFO - 2016-08-12 18:04:29 --> Config Class Initialized
INFO - 2016-08-12 18:04:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:29 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:29 --> URI Class Initialized
INFO - 2016-08-12 18:04:29 --> Router Class Initialized
INFO - 2016-08-12 18:04:29 --> Output Class Initialized
INFO - 2016-08-12 18:04:29 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:29 --> Input Class Initialized
INFO - 2016-08-12 18:04:29 --> Language Class Initialized
INFO - 2016-08-12 18:04:29 --> Loader Class Initialized
INFO - 2016-08-12 18:04:29 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:29 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:29 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:29 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:29 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:29 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:29 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:29 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:29 --> Email Class Initialized
INFO - 2016-08-12 18:04:29 --> Controller Class Initialized
INFO - 2016-08-12 18:04:29 --> Model Class Initialized
INFO - 2016-08-12 18:04:29 --> Model Class Initialized
INFO - 2016-08-12 18:04:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:04:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:29 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:29 --> Total execution time: 0.3823
INFO - 2016-08-12 18:04:30 --> Config Class Initialized
INFO - 2016-08-12 18:04:30 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:30 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:30 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:30 --> URI Class Initialized
INFO - 2016-08-12 18:04:30 --> Router Class Initialized
INFO - 2016-08-12 18:04:30 --> Output Class Initialized
INFO - 2016-08-12 18:04:30 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:30 --> Input Class Initialized
INFO - 2016-08-12 18:04:30 --> Language Class Initialized
INFO - 2016-08-12 18:04:30 --> Loader Class Initialized
INFO - 2016-08-12 18:04:30 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:30 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:30 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:30 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:30 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:30 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:30 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:30 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:30 --> Email Class Initialized
INFO - 2016-08-12 18:04:31 --> Controller Class Initialized
INFO - 2016-08-12 18:04:31 --> Model Class Initialized
INFO - 2016-08-12 18:04:31 --> Model Class Initialized
INFO - 2016-08-12 18:04:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-12 18:04:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:31 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:31 --> Total execution time: 0.6577
INFO - 2016-08-12 18:04:32 --> Config Class Initialized
INFO - 2016-08-12 18:04:32 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:32 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:32 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:33 --> URI Class Initialized
INFO - 2016-08-12 18:04:33 --> Router Class Initialized
INFO - 2016-08-12 18:04:33 --> Output Class Initialized
INFO - 2016-08-12 18:04:33 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:33 --> Input Class Initialized
INFO - 2016-08-12 18:04:33 --> Language Class Initialized
INFO - 2016-08-12 18:04:33 --> Loader Class Initialized
INFO - 2016-08-12 18:04:33 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:33 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:33 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:33 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:33 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:33 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:33 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:33 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:33 --> Email Class Initialized
INFO - 2016-08-12 18:04:33 --> Controller Class Initialized
INFO - 2016-08-12 18:04:33 --> Model Class Initialized
INFO - 2016-08-12 18:04:33 --> Model Class Initialized
INFO - 2016-08-12 18:04:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:04:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:33 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:33 --> Total execution time: 0.3777
INFO - 2016-08-12 18:04:37 --> Config Class Initialized
INFO - 2016-08-12 18:04:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:37 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:37 --> URI Class Initialized
INFO - 2016-08-12 18:04:37 --> Router Class Initialized
INFO - 2016-08-12 18:04:37 --> Output Class Initialized
INFO - 2016-08-12 18:04:37 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:37 --> Input Class Initialized
INFO - 2016-08-12 18:04:37 --> Language Class Initialized
INFO - 2016-08-12 18:04:37 --> Loader Class Initialized
INFO - 2016-08-12 18:04:37 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:37 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:37 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:37 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:37 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:37 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:37 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:37 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:37 --> Email Class Initialized
INFO - 2016-08-12 18:04:37 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:37 --> Model Class Initialized
INFO - 2016-08-12 18:04:37 --> Model Class Initialized
INFO - 2016-08-12 18:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:37 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:37 --> Total execution time: 0.3894
INFO - 2016-08-12 18:04:50 --> Config Class Initialized
INFO - 2016-08-12 18:04:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:50 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:50 --> URI Class Initialized
INFO - 2016-08-12 18:04:50 --> Router Class Initialized
INFO - 2016-08-12 18:04:50 --> Output Class Initialized
INFO - 2016-08-12 18:04:50 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:50 --> Input Class Initialized
INFO - 2016-08-12 18:04:50 --> Language Class Initialized
INFO - 2016-08-12 18:04:50 --> Loader Class Initialized
INFO - 2016-08-12 18:04:50 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:50 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:50 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:50 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:50 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:50 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:50 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:50 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:50 --> Email Class Initialized
INFO - 2016-08-12 18:04:50 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:50 --> Model Class Initialized
INFO - 2016-08-12 18:04:50 --> Model Class Initialized
INFO - 2016-08-12 18:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:50 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:50 --> Total execution time: 0.4223
INFO - 2016-08-12 18:04:53 --> Config Class Initialized
INFO - 2016-08-12 18:04:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:53 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:53 --> URI Class Initialized
INFO - 2016-08-12 18:04:53 --> Router Class Initialized
INFO - 2016-08-12 18:04:53 --> Output Class Initialized
INFO - 2016-08-12 18:04:53 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:54 --> Input Class Initialized
INFO - 2016-08-12 18:04:54 --> Language Class Initialized
INFO - 2016-08-12 18:04:54 --> Loader Class Initialized
INFO - 2016-08-12 18:04:54 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:54 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:54 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:54 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:54 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:54 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:54 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:54 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:54 --> Email Class Initialized
INFO - 2016-08-12 18:04:54 --> Controller Class Initialized
INFO - 2016-08-12 18:04:54 --> Model Class Initialized
INFO - 2016-08-12 18:04:54 --> Model Class Initialized
INFO - 2016-08-12 18:04:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:04:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:54 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:54 --> Total execution time: 0.3864
INFO - 2016-08-12 18:04:56 --> Config Class Initialized
INFO - 2016-08-12 18:04:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:56 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:56 --> URI Class Initialized
INFO - 2016-08-12 18:04:56 --> Router Class Initialized
INFO - 2016-08-12 18:04:56 --> Output Class Initialized
INFO - 2016-08-12 18:04:56 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:57 --> Input Class Initialized
INFO - 2016-08-12 18:04:57 --> Language Class Initialized
INFO - 2016-08-12 18:04:57 --> Loader Class Initialized
INFO - 2016-08-12 18:04:57 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:57 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:57 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:57 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:57 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:57 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:57 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:57 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:57 --> Email Class Initialized
INFO - 2016-08-12 18:04:57 --> Controller Class Initialized
INFO - 2016-08-12 18:04:57 --> Model Class Initialized
INFO - 2016-08-12 18:04:57 --> Model Class Initialized
INFO - 2016-08-12 18:04:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:04:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:57 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:57 --> Total execution time: 0.3836
INFO - 2016-08-12 18:04:58 --> Config Class Initialized
INFO - 2016-08-12 18:04:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:04:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:04:58 --> Utf8 Class Initialized
INFO - 2016-08-12 18:04:58 --> URI Class Initialized
INFO - 2016-08-12 18:04:58 --> Router Class Initialized
INFO - 2016-08-12 18:04:58 --> Output Class Initialized
INFO - 2016-08-12 18:04:58 --> Security Class Initialized
DEBUG - 2016-08-12 18:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:04:58 --> Input Class Initialized
INFO - 2016-08-12 18:04:58 --> Language Class Initialized
INFO - 2016-08-12 18:04:58 --> Loader Class Initialized
INFO - 2016-08-12 18:04:58 --> Helper loaded: url_helper
INFO - 2016-08-12 18:04:58 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:04:58 --> Helper loaded: html_helper
INFO - 2016-08-12 18:04:58 --> Helper loaded: form_helper
INFO - 2016-08-12 18:04:58 --> Helper loaded: file_helper
INFO - 2016-08-12 18:04:58 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:04:58 --> Database Driver Class Initialized
INFO - 2016-08-12 18:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:04:58 --> Form Validation Class Initialized
INFO - 2016-08-12 18:04:58 --> Email Class Initialized
INFO - 2016-08-12 18:04:58 --> Controller Class Initialized
DEBUG - 2016-08-12 18:04:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:04:58 --> Model Class Initialized
INFO - 2016-08-12 18:04:58 --> Model Class Initialized
INFO - 2016-08-12 18:04:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:04:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:04:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:04:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:04:58 --> Final output sent to browser
DEBUG - 2016-08-12 18:04:58 --> Total execution time: 0.4244
INFO - 2016-08-12 18:05:03 --> Config Class Initialized
INFO - 2016-08-12 18:05:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:05:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:05:03 --> Utf8 Class Initialized
INFO - 2016-08-12 18:05:03 --> URI Class Initialized
INFO - 2016-08-12 18:05:03 --> Router Class Initialized
INFO - 2016-08-12 18:05:03 --> Output Class Initialized
INFO - 2016-08-12 18:05:03 --> Security Class Initialized
DEBUG - 2016-08-12 18:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:05:03 --> Input Class Initialized
INFO - 2016-08-12 18:05:03 --> Language Class Initialized
INFO - 2016-08-12 18:05:03 --> Loader Class Initialized
INFO - 2016-08-12 18:05:03 --> Helper loaded: url_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: html_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: form_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: file_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:05:03 --> Database Driver Class Initialized
INFO - 2016-08-12 18:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:05:03 --> Form Validation Class Initialized
INFO - 2016-08-12 18:05:03 --> Email Class Initialized
INFO - 2016-08-12 18:05:03 --> Controller Class Initialized
DEBUG - 2016-08-12 18:05:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:05:03 --> Model Class Initialized
INFO - 2016-08-12 18:05:03 --> Model Class Initialized
INFO - 2016-08-12 18:05:03 --> Config Class Initialized
INFO - 2016-08-12 18:05:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:05:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:05:03 --> Utf8 Class Initialized
INFO - 2016-08-12 18:05:03 --> URI Class Initialized
INFO - 2016-08-12 18:05:03 --> Router Class Initialized
INFO - 2016-08-12 18:05:03 --> Output Class Initialized
INFO - 2016-08-12 18:05:03 --> Security Class Initialized
DEBUG - 2016-08-12 18:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:05:03 --> Input Class Initialized
INFO - 2016-08-12 18:05:03 --> Language Class Initialized
INFO - 2016-08-12 18:05:03 --> Loader Class Initialized
INFO - 2016-08-12 18:05:03 --> Helper loaded: url_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: html_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: form_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: file_helper
INFO - 2016-08-12 18:05:03 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:05:03 --> Database Driver Class Initialized
INFO - 2016-08-12 18:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:05:03 --> Form Validation Class Initialized
INFO - 2016-08-12 18:05:03 --> Email Class Initialized
INFO - 2016-08-12 18:05:03 --> Controller Class Initialized
INFO - 2016-08-12 18:05:03 --> Model Class Initialized
INFO - 2016-08-12 18:05:03 --> Model Class Initialized
INFO - 2016-08-12 18:05:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:05:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:05:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:05:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:05:03 --> Final output sent to browser
DEBUG - 2016-08-12 18:05:03 --> Total execution time: 0.3749
INFO - 2016-08-12 18:07:35 --> Config Class Initialized
INFO - 2016-08-12 18:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:07:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:07:35 --> Utf8 Class Initialized
INFO - 2016-08-12 18:07:35 --> URI Class Initialized
INFO - 2016-08-12 18:07:35 --> Router Class Initialized
INFO - 2016-08-12 18:07:35 --> Output Class Initialized
INFO - 2016-08-12 18:07:35 --> Security Class Initialized
DEBUG - 2016-08-12 18:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:07:35 --> Input Class Initialized
INFO - 2016-08-12 18:07:35 --> Language Class Initialized
INFO - 2016-08-12 18:07:35 --> Loader Class Initialized
INFO - 2016-08-12 18:07:35 --> Helper loaded: url_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: html_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: form_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: file_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:07:35 --> Database Driver Class Initialized
INFO - 2016-08-12 18:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:07:35 --> Form Validation Class Initialized
INFO - 2016-08-12 18:07:35 --> Email Class Initialized
INFO - 2016-08-12 18:07:35 --> Controller Class Initialized
DEBUG - 2016-08-12 18:07:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:07:35 --> Model Class Initialized
INFO - 2016-08-12 18:07:35 --> Model Class Initialized
INFO - 2016-08-12 18:07:35 --> Config Class Initialized
INFO - 2016-08-12 18:07:35 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:07:35 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:07:35 --> Utf8 Class Initialized
INFO - 2016-08-12 18:07:35 --> URI Class Initialized
INFO - 2016-08-12 18:07:35 --> Router Class Initialized
INFO - 2016-08-12 18:07:35 --> Output Class Initialized
INFO - 2016-08-12 18:07:35 --> Security Class Initialized
DEBUG - 2016-08-12 18:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:07:35 --> Input Class Initialized
INFO - 2016-08-12 18:07:35 --> Language Class Initialized
INFO - 2016-08-12 18:07:35 --> Loader Class Initialized
INFO - 2016-08-12 18:07:35 --> Helper loaded: url_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: html_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: form_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: file_helper
INFO - 2016-08-12 18:07:35 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:07:35 --> Database Driver Class Initialized
INFO - 2016-08-12 18:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:07:35 --> Form Validation Class Initialized
INFO - 2016-08-12 18:07:35 --> Email Class Initialized
INFO - 2016-08-12 18:07:35 --> Controller Class Initialized
INFO - 2016-08-12 18:07:35 --> Model Class Initialized
INFO - 2016-08-12 18:07:35 --> Model Class Initialized
INFO - 2016-08-12 18:07:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:07:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:07:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:07:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:07:35 --> Final output sent to browser
DEBUG - 2016-08-12 18:07:35 --> Total execution time: 0.3954
INFO - 2016-08-12 18:08:08 --> Config Class Initialized
INFO - 2016-08-12 18:08:08 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:08 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:08 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:08 --> URI Class Initialized
INFO - 2016-08-12 18:08:08 --> Router Class Initialized
INFO - 2016-08-12 18:08:08 --> Output Class Initialized
INFO - 2016-08-12 18:08:08 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:08 --> Input Class Initialized
INFO - 2016-08-12 18:08:08 --> Language Class Initialized
INFO - 2016-08-12 18:08:08 --> Loader Class Initialized
INFO - 2016-08-12 18:08:08 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:08 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:09 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:09 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:09 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:09 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:09 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:09 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:09 --> Email Class Initialized
INFO - 2016-08-12 18:08:09 --> Controller Class Initialized
DEBUG - 2016-08-12 18:08:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:08:09 --> Model Class Initialized
INFO - 2016-08-12 18:08:09 --> Model Class Initialized
INFO - 2016-08-12 18:08:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:08:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:09 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:09 --> Total execution time: 0.4041
INFO - 2016-08-12 18:08:10 --> Config Class Initialized
INFO - 2016-08-12 18:08:10 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:10 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:10 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:10 --> URI Class Initialized
INFO - 2016-08-12 18:08:10 --> Router Class Initialized
INFO - 2016-08-12 18:08:10 --> Output Class Initialized
INFO - 2016-08-12 18:08:11 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:11 --> Input Class Initialized
INFO - 2016-08-12 18:08:11 --> Language Class Initialized
INFO - 2016-08-12 18:08:11 --> Loader Class Initialized
INFO - 2016-08-12 18:08:11 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:11 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:11 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:11 --> Email Class Initialized
INFO - 2016-08-12 18:08:11 --> Controller Class Initialized
DEBUG - 2016-08-12 18:08:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:08:11 --> Model Class Initialized
INFO - 2016-08-12 18:08:11 --> Model Class Initialized
INFO - 2016-08-12 18:08:11 --> Config Class Initialized
INFO - 2016-08-12 18:08:11 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:11 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:11 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:11 --> URI Class Initialized
INFO - 2016-08-12 18:08:11 --> Router Class Initialized
INFO - 2016-08-12 18:08:11 --> Output Class Initialized
INFO - 2016-08-12 18:08:11 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:11 --> Input Class Initialized
INFO - 2016-08-12 18:08:11 --> Language Class Initialized
INFO - 2016-08-12 18:08:11 --> Loader Class Initialized
INFO - 2016-08-12 18:08:11 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:11 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:11 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:11 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:11 --> Email Class Initialized
INFO - 2016-08-12 18:08:11 --> Controller Class Initialized
INFO - 2016-08-12 18:08:11 --> Model Class Initialized
INFO - 2016-08-12 18:08:11 --> Model Class Initialized
INFO - 2016-08-12 18:08:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:08:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:11 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:11 --> Total execution time: 0.3839
INFO - 2016-08-12 18:08:23 --> Config Class Initialized
INFO - 2016-08-12 18:08:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:23 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:23 --> URI Class Initialized
INFO - 2016-08-12 18:08:23 --> Router Class Initialized
INFO - 2016-08-12 18:08:23 --> Output Class Initialized
INFO - 2016-08-12 18:08:23 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:23 --> Input Class Initialized
INFO - 2016-08-12 18:08:23 --> Language Class Initialized
INFO - 2016-08-12 18:08:23 --> Loader Class Initialized
INFO - 2016-08-12 18:08:23 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:23 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:23 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:23 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:23 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:23 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:23 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:23 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:23 --> Email Class Initialized
INFO - 2016-08-12 18:08:23 --> Controller Class Initialized
DEBUG - 2016-08-12 18:08:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:08:23 --> Model Class Initialized
INFO - 2016-08-12 18:08:23 --> Model Class Initialized
INFO - 2016-08-12 18:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:23 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:23 --> Total execution time: 0.4146
INFO - 2016-08-12 18:08:27 --> Config Class Initialized
INFO - 2016-08-12 18:08:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:27 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:27 --> URI Class Initialized
INFO - 2016-08-12 18:08:27 --> Router Class Initialized
INFO - 2016-08-12 18:08:27 --> Output Class Initialized
INFO - 2016-08-12 18:08:27 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:27 --> Input Class Initialized
INFO - 2016-08-12 18:08:27 --> Language Class Initialized
INFO - 2016-08-12 18:08:28 --> Loader Class Initialized
INFO - 2016-08-12 18:08:28 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:28 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:28 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:28 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:28 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:28 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:28 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:28 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:28 --> Email Class Initialized
INFO - 2016-08-12 18:08:28 --> Controller Class Initialized
DEBUG - 2016-08-12 18:08:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:08:28 --> Model Class Initialized
INFO - 2016-08-12 18:08:28 --> Model Class Initialized
INFO - 2016-08-12 18:08:28 --> Model Class Initialized
INFO - 2016-08-12 18:08:28 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:28 --> Total execution time: 0.4253
INFO - 2016-08-12 18:08:45 --> Config Class Initialized
INFO - 2016-08-12 18:08:45 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:45 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:45 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:45 --> URI Class Initialized
INFO - 2016-08-12 18:08:46 --> Router Class Initialized
INFO - 2016-08-12 18:08:46 --> Output Class Initialized
INFO - 2016-08-12 18:08:46 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:46 --> Input Class Initialized
INFO - 2016-08-12 18:08:46 --> Language Class Initialized
INFO - 2016-08-12 18:08:46 --> Loader Class Initialized
INFO - 2016-08-12 18:08:46 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:46 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:46 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:46 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:46 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:46 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:46 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:46 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:46 --> Email Class Initialized
INFO - 2016-08-12 18:08:46 --> Controller Class Initialized
DEBUG - 2016-08-12 18:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:08:46 --> Model Class Initialized
INFO - 2016-08-12 18:08:46 --> Model Class Initialized
INFO - 2016-08-12 18:08:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:08:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:46 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:46 --> Total execution time: 0.4071
INFO - 2016-08-12 18:08:48 --> Config Class Initialized
INFO - 2016-08-12 18:08:48 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:48 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:48 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:48 --> URI Class Initialized
INFO - 2016-08-12 18:08:48 --> Router Class Initialized
INFO - 2016-08-12 18:08:48 --> Output Class Initialized
INFO - 2016-08-12 18:08:48 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:48 --> Input Class Initialized
INFO - 2016-08-12 18:08:48 --> Language Class Initialized
INFO - 2016-08-12 18:08:48 --> Loader Class Initialized
INFO - 2016-08-12 18:08:48 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:48 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:48 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:48 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:48 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:48 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:48 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:48 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:48 --> Email Class Initialized
INFO - 2016-08-12 18:08:48 --> Controller Class Initialized
INFO - 2016-08-12 18:08:48 --> Model Class Initialized
INFO - 2016-08-12 18:08:48 --> Model Class Initialized
INFO - 2016-08-12 18:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:48 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:48 --> Total execution time: 0.4058
INFO - 2016-08-12 18:08:49 --> Config Class Initialized
INFO - 2016-08-12 18:08:49 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:49 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:49 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:49 --> URI Class Initialized
INFO - 2016-08-12 18:08:49 --> Router Class Initialized
INFO - 2016-08-12 18:08:49 --> Output Class Initialized
INFO - 2016-08-12 18:08:49 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:49 --> Input Class Initialized
INFO - 2016-08-12 18:08:49 --> Language Class Initialized
INFO - 2016-08-12 18:08:49 --> Loader Class Initialized
INFO - 2016-08-12 18:08:49 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:49 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:49 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:49 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:49 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:50 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:50 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:50 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:50 --> Email Class Initialized
INFO - 2016-08-12 18:08:50 --> Controller Class Initialized
INFO - 2016-08-12 18:08:50 --> Model Class Initialized
INFO - 2016-08-12 18:08:50 --> Model Class Initialized
INFO - 2016-08-12 18:08:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:08:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:50 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:50 --> Total execution time: 0.4030
INFO - 2016-08-12 18:08:53 --> Config Class Initialized
INFO - 2016-08-12 18:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:53 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:53 --> URI Class Initialized
INFO - 2016-08-12 18:08:53 --> Router Class Initialized
INFO - 2016-08-12 18:08:53 --> Output Class Initialized
INFO - 2016-08-12 18:08:53 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:53 --> Input Class Initialized
INFO - 2016-08-12 18:08:53 --> Language Class Initialized
INFO - 2016-08-12 18:08:53 --> Loader Class Initialized
INFO - 2016-08-12 18:08:53 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:53 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:53 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:53 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:53 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:53 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:53 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:53 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:53 --> Email Class Initialized
INFO - 2016-08-12 18:08:53 --> Controller Class Initialized
INFO - 2016-08-12 18:08:53 --> Model Class Initialized
INFO - 2016-08-12 18:08:53 --> Model Class Initialized
INFO - 2016-08-12 18:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:54 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:54 --> Total execution time: 0.3916
INFO - 2016-08-12 18:08:56 --> Config Class Initialized
INFO - 2016-08-12 18:08:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:08:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:08:57 --> Utf8 Class Initialized
INFO - 2016-08-12 18:08:57 --> URI Class Initialized
INFO - 2016-08-12 18:08:57 --> Router Class Initialized
INFO - 2016-08-12 18:08:57 --> Output Class Initialized
INFO - 2016-08-12 18:08:57 --> Security Class Initialized
DEBUG - 2016-08-12 18:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:08:57 --> Input Class Initialized
INFO - 2016-08-12 18:08:57 --> Language Class Initialized
INFO - 2016-08-12 18:08:57 --> Loader Class Initialized
INFO - 2016-08-12 18:08:57 --> Helper loaded: url_helper
INFO - 2016-08-12 18:08:57 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:08:57 --> Helper loaded: html_helper
INFO - 2016-08-12 18:08:57 --> Helper loaded: form_helper
INFO - 2016-08-12 18:08:57 --> Helper loaded: file_helper
INFO - 2016-08-12 18:08:57 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:08:57 --> Database Driver Class Initialized
INFO - 2016-08-12 18:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:08:57 --> Form Validation Class Initialized
INFO - 2016-08-12 18:08:57 --> Email Class Initialized
INFO - 2016-08-12 18:08:57 --> Controller Class Initialized
INFO - 2016-08-12 18:08:57 --> Model Class Initialized
INFO - 2016-08-12 18:08:57 --> Model Class Initialized
INFO - 2016-08-12 18:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:08:57 --> Final output sent to browser
DEBUG - 2016-08-12 18:08:57 --> Total execution time: 0.4094
INFO - 2016-08-12 18:11:33 --> Config Class Initialized
INFO - 2016-08-12 18:11:33 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:11:33 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:11:33 --> Utf8 Class Initialized
INFO - 2016-08-12 18:11:33 --> URI Class Initialized
INFO - 2016-08-12 18:11:33 --> Router Class Initialized
INFO - 2016-08-12 18:11:33 --> Output Class Initialized
INFO - 2016-08-12 18:11:33 --> Security Class Initialized
DEBUG - 2016-08-12 18:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:11:33 --> Input Class Initialized
INFO - 2016-08-12 18:11:33 --> Language Class Initialized
INFO - 2016-08-12 18:11:33 --> Loader Class Initialized
INFO - 2016-08-12 18:11:33 --> Helper loaded: url_helper
INFO - 2016-08-12 18:11:33 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:11:33 --> Helper loaded: html_helper
INFO - 2016-08-12 18:11:33 --> Helper loaded: form_helper
INFO - 2016-08-12 18:11:33 --> Helper loaded: file_helper
INFO - 2016-08-12 18:11:33 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:11:33 --> Database Driver Class Initialized
INFO - 2016-08-12 18:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:11:33 --> Form Validation Class Initialized
INFO - 2016-08-12 18:11:33 --> Email Class Initialized
INFO - 2016-08-12 18:11:33 --> Controller Class Initialized
INFO - 2016-08-12 18:11:33 --> Model Class Initialized
INFO - 2016-08-12 18:11:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:11:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:11:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-12 18:11:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:11:33 --> Final output sent to browser
DEBUG - 2016-08-12 18:11:33 --> Total execution time: 0.3901
INFO - 2016-08-12 18:11:45 --> Config Class Initialized
INFO - 2016-08-12 18:11:45 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:11:45 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:11:45 --> Utf8 Class Initialized
INFO - 2016-08-12 18:11:46 --> URI Class Initialized
INFO - 2016-08-12 18:11:46 --> Router Class Initialized
INFO - 2016-08-12 18:11:46 --> Output Class Initialized
INFO - 2016-08-12 18:11:46 --> Security Class Initialized
DEBUG - 2016-08-12 18:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:11:46 --> Input Class Initialized
INFO - 2016-08-12 18:11:46 --> Language Class Initialized
INFO - 2016-08-12 18:11:46 --> Loader Class Initialized
INFO - 2016-08-12 18:11:46 --> Helper loaded: url_helper
INFO - 2016-08-12 18:11:46 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:11:46 --> Helper loaded: html_helper
INFO - 2016-08-12 18:11:46 --> Helper loaded: form_helper
INFO - 2016-08-12 18:11:46 --> Helper loaded: file_helper
INFO - 2016-08-12 18:11:46 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:11:46 --> Database Driver Class Initialized
INFO - 2016-08-12 18:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:11:46 --> Form Validation Class Initialized
INFO - 2016-08-12 18:11:46 --> Email Class Initialized
INFO - 2016-08-12 18:11:46 --> Controller Class Initialized
INFO - 2016-08-12 18:11:46 --> Model Class Initialized
INFO - 2016-08-12 18:11:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:11:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:11:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-12 18:11:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:11:46 --> Final output sent to browser
DEBUG - 2016-08-12 18:11:46 --> Total execution time: 0.3937
INFO - 2016-08-12 18:11:55 --> Config Class Initialized
INFO - 2016-08-12 18:11:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:11:55 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:11:55 --> Utf8 Class Initialized
INFO - 2016-08-12 18:11:55 --> URI Class Initialized
INFO - 2016-08-12 18:11:55 --> Router Class Initialized
INFO - 2016-08-12 18:11:55 --> Output Class Initialized
INFO - 2016-08-12 18:11:55 --> Security Class Initialized
DEBUG - 2016-08-12 18:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:11:55 --> Input Class Initialized
INFO - 2016-08-12 18:11:55 --> Language Class Initialized
INFO - 2016-08-12 18:11:55 --> Loader Class Initialized
INFO - 2016-08-12 18:11:55 --> Helper loaded: url_helper
INFO - 2016-08-12 18:11:55 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:11:55 --> Helper loaded: html_helper
INFO - 2016-08-12 18:11:55 --> Helper loaded: form_helper
INFO - 2016-08-12 18:11:55 --> Helper loaded: file_helper
INFO - 2016-08-12 18:11:55 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:11:55 --> Database Driver Class Initialized
INFO - 2016-08-12 18:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:11:55 --> Form Validation Class Initialized
INFO - 2016-08-12 18:11:55 --> Email Class Initialized
INFO - 2016-08-12 18:11:55 --> Controller Class Initialized
INFO - 2016-08-12 18:11:55 --> Model Class Initialized
DEBUG - 2016-08-12 18:11:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:11:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:11:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:11:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-12 18:11:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:11:55 --> Final output sent to browser
DEBUG - 2016-08-12 18:11:55 --> Total execution time: 0.4298
INFO - 2016-08-12 18:13:42 --> Config Class Initialized
INFO - 2016-08-12 18:13:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:13:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:13:42 --> Utf8 Class Initialized
INFO - 2016-08-12 18:13:42 --> URI Class Initialized
INFO - 2016-08-12 18:13:42 --> Router Class Initialized
INFO - 2016-08-12 18:13:42 --> Output Class Initialized
INFO - 2016-08-12 18:13:42 --> Security Class Initialized
DEBUG - 2016-08-12 18:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:13:42 --> Input Class Initialized
INFO - 2016-08-12 18:13:42 --> Language Class Initialized
INFO - 2016-08-12 18:13:42 --> Loader Class Initialized
INFO - 2016-08-12 18:13:42 --> Helper loaded: url_helper
INFO - 2016-08-12 18:13:42 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:13:42 --> Helper loaded: html_helper
INFO - 2016-08-12 18:13:42 --> Helper loaded: form_helper
INFO - 2016-08-12 18:13:42 --> Helper loaded: file_helper
INFO - 2016-08-12 18:13:42 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:13:42 --> Database Driver Class Initialized
INFO - 2016-08-12 18:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:13:42 --> Form Validation Class Initialized
INFO - 2016-08-12 18:13:42 --> Email Class Initialized
INFO - 2016-08-12 18:13:42 --> Controller Class Initialized
DEBUG - 2016-08-12 18:13:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:13:42 --> Model Class Initialized
INFO - 2016-08-12 18:13:42 --> Model Class Initialized
INFO - 2016-08-12 18:13:42 --> Config Class Initialized
INFO - 2016-08-12 18:13:42 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:13:42 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:13:42 --> Utf8 Class Initialized
INFO - 2016-08-12 18:13:43 --> URI Class Initialized
INFO - 2016-08-12 18:13:43 --> Router Class Initialized
INFO - 2016-08-12 18:13:43 --> Output Class Initialized
INFO - 2016-08-12 18:13:43 --> Security Class Initialized
DEBUG - 2016-08-12 18:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:13:43 --> Input Class Initialized
INFO - 2016-08-12 18:13:43 --> Language Class Initialized
INFO - 2016-08-12 18:13:43 --> Loader Class Initialized
INFO - 2016-08-12 18:13:43 --> Helper loaded: url_helper
INFO - 2016-08-12 18:13:43 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:13:43 --> Helper loaded: html_helper
INFO - 2016-08-12 18:13:43 --> Helper loaded: form_helper
INFO - 2016-08-12 18:13:43 --> Helper loaded: file_helper
INFO - 2016-08-12 18:13:43 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:13:43 --> Database Driver Class Initialized
INFO - 2016-08-12 18:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:13:43 --> Form Validation Class Initialized
INFO - 2016-08-12 18:13:43 --> Email Class Initialized
INFO - 2016-08-12 18:13:43 --> Controller Class Initialized
INFO - 2016-08-12 18:13:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:13:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:13:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:13:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:13:43 --> Final output sent to browser
DEBUG - 2016-08-12 18:13:43 --> Total execution time: 0.3663
INFO - 2016-08-12 18:20:32 --> Config Class Initialized
INFO - 2016-08-12 18:20:32 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:20:32 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:20:32 --> Utf8 Class Initialized
INFO - 2016-08-12 18:20:32 --> URI Class Initialized
INFO - 2016-08-12 18:20:32 --> Router Class Initialized
INFO - 2016-08-12 18:20:32 --> Output Class Initialized
INFO - 2016-08-12 18:20:32 --> Security Class Initialized
DEBUG - 2016-08-12 18:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:20:32 --> Input Class Initialized
INFO - 2016-08-12 18:20:32 --> Language Class Initialized
INFO - 2016-08-12 18:20:32 --> Loader Class Initialized
INFO - 2016-08-12 18:20:32 --> Helper loaded: url_helper
INFO - 2016-08-12 18:20:32 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:20:32 --> Helper loaded: html_helper
INFO - 2016-08-12 18:20:32 --> Helper loaded: form_helper
INFO - 2016-08-12 18:20:32 --> Helper loaded: file_helper
INFO - 2016-08-12 18:20:32 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:20:32 --> Database Driver Class Initialized
INFO - 2016-08-12 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:20:32 --> Form Validation Class Initialized
INFO - 2016-08-12 18:20:33 --> Email Class Initialized
INFO - 2016-08-12 18:20:33 --> Controller Class Initialized
INFO - 2016-08-12 18:20:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:20:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:20:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:20:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:20:33 --> Final output sent to browser
DEBUG - 2016-08-12 18:20:33 --> Total execution time: 0.4044
INFO - 2016-08-12 18:21:01 --> Config Class Initialized
INFO - 2016-08-12 18:21:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:21:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:21:01 --> Utf8 Class Initialized
INFO - 2016-08-12 18:21:01 --> URI Class Initialized
INFO - 2016-08-12 18:21:01 --> Router Class Initialized
INFO - 2016-08-12 18:21:01 --> Output Class Initialized
INFO - 2016-08-12 18:21:01 --> Security Class Initialized
DEBUG - 2016-08-12 18:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:21:01 --> Input Class Initialized
INFO - 2016-08-12 18:21:01 --> Language Class Initialized
INFO - 2016-08-12 18:21:01 --> Loader Class Initialized
INFO - 2016-08-12 18:21:01 --> Helper loaded: url_helper
INFO - 2016-08-12 18:21:01 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:21:01 --> Helper loaded: html_helper
INFO - 2016-08-12 18:21:01 --> Helper loaded: form_helper
INFO - 2016-08-12 18:21:01 --> Helper loaded: file_helper
INFO - 2016-08-12 18:21:01 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:21:01 --> Database Driver Class Initialized
INFO - 2016-08-12 18:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:21:01 --> Form Validation Class Initialized
INFO - 2016-08-12 18:21:01 --> Email Class Initialized
INFO - 2016-08-12 18:21:01 --> Controller Class Initialized
INFO - 2016-08-12 18:21:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:21:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:21:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:21:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:21:01 --> Final output sent to browser
DEBUG - 2016-08-12 18:21:01 --> Total execution time: 0.4140
INFO - 2016-08-12 18:21:55 --> Config Class Initialized
INFO - 2016-08-12 18:21:55 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:21:55 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:21:55 --> Utf8 Class Initialized
INFO - 2016-08-12 18:21:55 --> URI Class Initialized
INFO - 2016-08-12 18:21:55 --> Router Class Initialized
INFO - 2016-08-12 18:21:55 --> Output Class Initialized
INFO - 2016-08-12 18:21:55 --> Security Class Initialized
DEBUG - 2016-08-12 18:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:21:55 --> Input Class Initialized
INFO - 2016-08-12 18:21:55 --> Language Class Initialized
INFO - 2016-08-12 18:21:55 --> Loader Class Initialized
INFO - 2016-08-12 18:21:55 --> Helper loaded: url_helper
INFO - 2016-08-12 18:21:55 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:21:55 --> Helper loaded: html_helper
INFO - 2016-08-12 18:21:55 --> Helper loaded: form_helper
INFO - 2016-08-12 18:21:55 --> Helper loaded: file_helper
INFO - 2016-08-12 18:21:55 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:21:55 --> Database Driver Class Initialized
INFO - 2016-08-12 18:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:21:55 --> Form Validation Class Initialized
INFO - 2016-08-12 18:21:55 --> Email Class Initialized
INFO - 2016-08-12 18:21:55 --> Controller Class Initialized
INFO - 2016-08-12 18:21:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:21:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:21:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:21:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:21:55 --> Final output sent to browser
DEBUG - 2016-08-12 18:21:55 --> Total execution time: 0.3888
INFO - 2016-08-12 18:24:53 --> Config Class Initialized
INFO - 2016-08-12 18:24:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:24:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:24:53 --> Utf8 Class Initialized
INFO - 2016-08-12 18:24:53 --> URI Class Initialized
INFO - 2016-08-12 18:24:53 --> Router Class Initialized
INFO - 2016-08-12 18:24:53 --> Output Class Initialized
INFO - 2016-08-12 18:24:53 --> Security Class Initialized
DEBUG - 2016-08-12 18:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:24:53 --> Input Class Initialized
INFO - 2016-08-12 18:24:53 --> Language Class Initialized
INFO - 2016-08-12 18:24:53 --> Loader Class Initialized
INFO - 2016-08-12 18:24:53 --> Helper loaded: url_helper
INFO - 2016-08-12 18:24:53 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:24:53 --> Helper loaded: html_helper
INFO - 2016-08-12 18:24:53 --> Helper loaded: form_helper
INFO - 2016-08-12 18:24:53 --> Helper loaded: file_helper
INFO - 2016-08-12 18:24:53 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:24:53 --> Database Driver Class Initialized
INFO - 2016-08-12 18:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:24:53 --> Form Validation Class Initialized
INFO - 2016-08-12 18:24:53 --> Email Class Initialized
INFO - 2016-08-12 18:24:53 --> Controller Class Initialized
INFO - 2016-08-12 18:24:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:24:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:24:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:24:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:24:53 --> Final output sent to browser
DEBUG - 2016-08-12 18:24:53 --> Total execution time: 0.4056
INFO - 2016-08-12 18:25:15 --> Config Class Initialized
INFO - 2016-08-12 18:25:15 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:25:15 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:25:15 --> Utf8 Class Initialized
INFO - 2016-08-12 18:25:15 --> URI Class Initialized
DEBUG - 2016-08-12 18:25:15 --> No URI present. Default controller set.
INFO - 2016-08-12 18:25:15 --> Router Class Initialized
INFO - 2016-08-12 18:25:15 --> Output Class Initialized
INFO - 2016-08-12 18:25:15 --> Security Class Initialized
DEBUG - 2016-08-12 18:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:25:15 --> Input Class Initialized
INFO - 2016-08-12 18:25:15 --> Language Class Initialized
INFO - 2016-08-12 18:25:15 --> Loader Class Initialized
INFO - 2016-08-12 18:25:15 --> Helper loaded: url_helper
INFO - 2016-08-12 18:25:15 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:25:15 --> Helper loaded: html_helper
INFO - 2016-08-12 18:25:15 --> Helper loaded: form_helper
INFO - 2016-08-12 18:25:15 --> Helper loaded: file_helper
INFO - 2016-08-12 18:25:15 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:25:15 --> Database Driver Class Initialized
INFO - 2016-08-12 18:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:25:15 --> Form Validation Class Initialized
INFO - 2016-08-12 18:25:15 --> Email Class Initialized
INFO - 2016-08-12 18:25:15 --> Controller Class Initialized
INFO - 2016-08-12 18:25:15 --> Model Class Initialized
INFO - 2016-08-12 18:25:15 --> Model Class Initialized
INFO - 2016-08-12 18:25:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:25:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:25:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-12 18:25:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:25:16 --> Final output sent to browser
DEBUG - 2016-08-12 18:25:16 --> Total execution time: 0.4799
INFO - 2016-08-12 18:25:17 --> Config Class Initialized
INFO - 2016-08-12 18:25:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:25:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:25:18 --> Utf8 Class Initialized
INFO - 2016-08-12 18:25:18 --> URI Class Initialized
INFO - 2016-08-12 18:25:18 --> Router Class Initialized
INFO - 2016-08-12 18:25:18 --> Output Class Initialized
INFO - 2016-08-12 18:25:18 --> Security Class Initialized
DEBUG - 2016-08-12 18:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:25:18 --> Input Class Initialized
INFO - 2016-08-12 18:25:18 --> Language Class Initialized
INFO - 2016-08-12 18:25:18 --> Loader Class Initialized
INFO - 2016-08-12 18:25:18 --> Helper loaded: url_helper
INFO - 2016-08-12 18:25:18 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:25:18 --> Helper loaded: html_helper
INFO - 2016-08-12 18:25:18 --> Helper loaded: form_helper
INFO - 2016-08-12 18:25:18 --> Helper loaded: file_helper
INFO - 2016-08-12 18:25:18 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:25:18 --> Database Driver Class Initialized
INFO - 2016-08-12 18:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:25:18 --> Form Validation Class Initialized
INFO - 2016-08-12 18:25:18 --> Email Class Initialized
INFO - 2016-08-12 18:25:18 --> Controller Class Initialized
DEBUG - 2016-08-12 18:25:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:25:18 --> Model Class Initialized
INFO - 2016-08-12 18:25:18 --> Model Class Initialized
INFO - 2016-08-12 18:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:25:18 --> Final output sent to browser
DEBUG - 2016-08-12 18:25:18 --> Total execution time: 0.4225
INFO - 2016-08-12 18:25:23 --> Config Class Initialized
INFO - 2016-08-12 18:25:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:25:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:25:23 --> Utf8 Class Initialized
INFO - 2016-08-12 18:25:23 --> URI Class Initialized
INFO - 2016-08-12 18:25:23 --> Router Class Initialized
INFO - 2016-08-12 18:25:23 --> Output Class Initialized
INFO - 2016-08-12 18:25:23 --> Security Class Initialized
DEBUG - 2016-08-12 18:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:25:23 --> Input Class Initialized
INFO - 2016-08-12 18:25:23 --> Language Class Initialized
INFO - 2016-08-12 18:25:23 --> Loader Class Initialized
INFO - 2016-08-12 18:25:23 --> Helper loaded: url_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: html_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: form_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: file_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:25:23 --> Database Driver Class Initialized
INFO - 2016-08-12 18:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:25:23 --> Form Validation Class Initialized
INFO - 2016-08-12 18:25:23 --> Email Class Initialized
INFO - 2016-08-12 18:25:23 --> Controller Class Initialized
DEBUG - 2016-08-12 18:25:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:25:23 --> Model Class Initialized
INFO - 2016-08-12 18:25:23 --> Model Class Initialized
INFO - 2016-08-12 18:25:23 --> Config Class Initialized
INFO - 2016-08-12 18:25:23 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:25:23 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:25:23 --> Utf8 Class Initialized
INFO - 2016-08-12 18:25:23 --> URI Class Initialized
INFO - 2016-08-12 18:25:23 --> Router Class Initialized
INFO - 2016-08-12 18:25:23 --> Output Class Initialized
INFO - 2016-08-12 18:25:23 --> Security Class Initialized
DEBUG - 2016-08-12 18:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:25:23 --> Input Class Initialized
INFO - 2016-08-12 18:25:23 --> Language Class Initialized
INFO - 2016-08-12 18:25:23 --> Loader Class Initialized
INFO - 2016-08-12 18:25:23 --> Helper loaded: url_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: html_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: form_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: file_helper
INFO - 2016-08-12 18:25:23 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:25:23 --> Database Driver Class Initialized
INFO - 2016-08-12 18:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:25:23 --> Form Validation Class Initialized
INFO - 2016-08-12 18:25:23 --> Email Class Initialized
INFO - 2016-08-12 18:25:23 --> Controller Class Initialized
INFO - 2016-08-12 18:25:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:25:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:25:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:25:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:25:24 --> Final output sent to browser
DEBUG - 2016-08-12 18:25:24 --> Total execution time: 0.3749
INFO - 2016-08-12 18:25:56 --> Config Class Initialized
INFO - 2016-08-12 18:25:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:25:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:25:56 --> Utf8 Class Initialized
INFO - 2016-08-12 18:25:56 --> URI Class Initialized
INFO - 2016-08-12 18:25:56 --> Router Class Initialized
INFO - 2016-08-12 18:25:56 --> Output Class Initialized
INFO - 2016-08-12 18:25:56 --> Security Class Initialized
DEBUG - 2016-08-12 18:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:25:56 --> Input Class Initialized
INFO - 2016-08-12 18:25:56 --> Language Class Initialized
INFO - 2016-08-12 18:25:56 --> Loader Class Initialized
INFO - 2016-08-12 18:25:56 --> Helper loaded: url_helper
INFO - 2016-08-12 18:25:56 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:25:56 --> Helper loaded: html_helper
INFO - 2016-08-12 18:25:56 --> Helper loaded: form_helper
INFO - 2016-08-12 18:25:56 --> Helper loaded: file_helper
INFO - 2016-08-12 18:25:56 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:25:56 --> Database Driver Class Initialized
INFO - 2016-08-12 18:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:25:56 --> Form Validation Class Initialized
INFO - 2016-08-12 18:25:56 --> Email Class Initialized
INFO - 2016-08-12 18:25:56 --> Controller Class Initialized
INFO - 2016-08-12 18:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:25:56 --> Final output sent to browser
DEBUG - 2016-08-12 18:25:56 --> Total execution time: 0.3895
INFO - 2016-08-12 18:26:17 --> Config Class Initialized
INFO - 2016-08-12 18:26:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:17 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:17 --> URI Class Initialized
INFO - 2016-08-12 18:26:17 --> Router Class Initialized
INFO - 2016-08-12 18:26:17 --> Output Class Initialized
INFO - 2016-08-12 18:26:17 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:17 --> Input Class Initialized
INFO - 2016-08-12 18:26:17 --> Language Class Initialized
INFO - 2016-08-12 18:26:17 --> Loader Class Initialized
INFO - 2016-08-12 18:26:17 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:17 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:17 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:17 --> Email Class Initialized
INFO - 2016-08-12 18:26:17 --> Controller Class Initialized
INFO - 2016-08-12 18:26:17 --> Model Class Initialized
INFO - 2016-08-12 18:26:17 --> Config Class Initialized
INFO - 2016-08-12 18:26:17 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:17 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:17 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:17 --> URI Class Initialized
INFO - 2016-08-12 18:26:17 --> Router Class Initialized
INFO - 2016-08-12 18:26:17 --> Output Class Initialized
INFO - 2016-08-12 18:26:17 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:17 --> Input Class Initialized
INFO - 2016-08-12 18:26:17 --> Language Class Initialized
INFO - 2016-08-12 18:26:17 --> Loader Class Initialized
INFO - 2016-08-12 18:26:17 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:17 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:17 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:17 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:17 --> Email Class Initialized
INFO - 2016-08-12 18:26:17 --> Controller Class Initialized
INFO - 2016-08-12 18:26:17 --> Model Class Initialized
DEBUG - 2016-08-12 18:26:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:26:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-12 18:26:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:26:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-12 18:26:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:26:18 --> Final output sent to browser
DEBUG - 2016-08-12 18:26:18 --> Total execution time: 0.4241
INFO - 2016-08-12 18:26:21 --> Config Class Initialized
INFO - 2016-08-12 18:26:21 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:21 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:21 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:21 --> URI Class Initialized
INFO - 2016-08-12 18:26:21 --> Router Class Initialized
INFO - 2016-08-12 18:26:21 --> Output Class Initialized
INFO - 2016-08-12 18:26:21 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:21 --> Input Class Initialized
INFO - 2016-08-12 18:26:21 --> Language Class Initialized
INFO - 2016-08-12 18:26:21 --> Loader Class Initialized
INFO - 2016-08-12 18:26:21 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:21 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:21 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:21 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:21 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:21 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:22 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:22 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:22 --> Email Class Initialized
INFO - 2016-08-12 18:26:22 --> Controller Class Initialized
INFO - 2016-08-12 18:26:22 --> Model Class Initialized
DEBUG - 2016-08-12 18:26:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:26:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-12 18:26:22 --> Config Class Initialized
INFO - 2016-08-12 18:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:22 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:22 --> URI Class Initialized
INFO - 2016-08-12 18:26:22 --> Router Class Initialized
INFO - 2016-08-12 18:26:22 --> Output Class Initialized
INFO - 2016-08-12 18:26:22 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:22 --> Input Class Initialized
INFO - 2016-08-12 18:26:22 --> Language Class Initialized
INFO - 2016-08-12 18:26:22 --> Loader Class Initialized
INFO - 2016-08-12 18:26:22 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:22 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:22 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:22 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:22 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:22 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:22 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:22 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:22 --> Email Class Initialized
INFO - 2016-08-12 18:26:22 --> Controller Class Initialized
INFO - 2016-08-12 18:26:22 --> Model Class Initialized
INFO - 2016-08-12 18:26:22 --> Model Class Initialized
INFO - 2016-08-12 18:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:26:22 --> Final output sent to browser
DEBUG - 2016-08-12 18:26:22 --> Total execution time: 0.5429
INFO - 2016-08-12 18:26:27 --> Config Class Initialized
INFO - 2016-08-12 18:26:27 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:27 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:27 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:27 --> URI Class Initialized
INFO - 2016-08-12 18:26:27 --> Router Class Initialized
INFO - 2016-08-12 18:26:27 --> Output Class Initialized
INFO - 2016-08-12 18:26:27 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:27 --> Input Class Initialized
INFO - 2016-08-12 18:26:27 --> Language Class Initialized
INFO - 2016-08-12 18:26:27 --> Loader Class Initialized
INFO - 2016-08-12 18:26:27 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:27 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:27 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:27 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:27 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:27 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:27 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:27 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:27 --> Email Class Initialized
INFO - 2016-08-12 18:26:27 --> Controller Class Initialized
INFO - 2016-08-12 18:26:27 --> Model Class Initialized
INFO - 2016-08-12 18:26:27 --> Model Class Initialized
INFO - 2016-08-12 18:26:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:26:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:26:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-12 18:26:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:26:27 --> Final output sent to browser
DEBUG - 2016-08-12 18:26:27 --> Total execution time: 0.4469
INFO - 2016-08-12 18:26:29 --> Config Class Initialized
INFO - 2016-08-12 18:26:29 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:29 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:29 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:29 --> URI Class Initialized
INFO - 2016-08-12 18:26:29 --> Router Class Initialized
INFO - 2016-08-12 18:26:29 --> Output Class Initialized
INFO - 2016-08-12 18:26:29 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:29 --> Input Class Initialized
INFO - 2016-08-12 18:26:29 --> Language Class Initialized
INFO - 2016-08-12 18:26:29 --> Loader Class Initialized
INFO - 2016-08-12 18:26:29 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:29 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:29 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:29 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:29 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:29 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:29 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:29 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:29 --> Email Class Initialized
INFO - 2016-08-12 18:26:29 --> Controller Class Initialized
DEBUG - 2016-08-12 18:26:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:26:29 --> Model Class Initialized
INFO - 2016-08-12 18:26:29 --> Model Class Initialized
INFO - 2016-08-12 18:26:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:26:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:26:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:26:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:26:30 --> Final output sent to browser
DEBUG - 2016-08-12 18:26:30 --> Total execution time: 0.4651
INFO - 2016-08-12 18:26:36 --> Config Class Initialized
INFO - 2016-08-12 18:26:36 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:36 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:36 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:36 --> URI Class Initialized
INFO - 2016-08-12 18:26:36 --> Router Class Initialized
INFO - 2016-08-12 18:26:36 --> Output Class Initialized
INFO - 2016-08-12 18:26:36 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:36 --> Input Class Initialized
INFO - 2016-08-12 18:26:36 --> Language Class Initialized
INFO - 2016-08-12 18:26:36 --> Loader Class Initialized
INFO - 2016-08-12 18:26:36 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:36 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:36 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:36 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:36 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:36 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:36 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:36 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:36 --> Email Class Initialized
INFO - 2016-08-12 18:26:36 --> Controller Class Initialized
DEBUG - 2016-08-12 18:26:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:26:36 --> Model Class Initialized
INFO - 2016-08-12 18:26:36 --> Model Class Initialized
INFO - 2016-08-12 18:26:37 --> Config Class Initialized
INFO - 2016-08-12 18:26:37 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:26:37 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:26:37 --> Utf8 Class Initialized
INFO - 2016-08-12 18:26:37 --> URI Class Initialized
INFO - 2016-08-12 18:26:37 --> Router Class Initialized
INFO - 2016-08-12 18:26:37 --> Output Class Initialized
INFO - 2016-08-12 18:26:37 --> Security Class Initialized
DEBUG - 2016-08-12 18:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:26:37 --> Input Class Initialized
INFO - 2016-08-12 18:26:37 --> Language Class Initialized
INFO - 2016-08-12 18:26:37 --> Loader Class Initialized
INFO - 2016-08-12 18:26:37 --> Helper loaded: url_helper
INFO - 2016-08-12 18:26:37 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:26:37 --> Helper loaded: html_helper
INFO - 2016-08-12 18:26:37 --> Helper loaded: form_helper
INFO - 2016-08-12 18:26:37 --> Helper loaded: file_helper
INFO - 2016-08-12 18:26:37 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:26:37 --> Database Driver Class Initialized
INFO - 2016-08-12 18:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:26:37 --> Form Validation Class Initialized
INFO - 2016-08-12 18:26:37 --> Email Class Initialized
INFO - 2016-08-12 18:26:37 --> Controller Class Initialized
INFO - 2016-08-12 18:26:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:26:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:26:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:26:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:26:37 --> Final output sent to browser
DEBUG - 2016-08-12 18:26:37 --> Total execution time: 0.4065
INFO - 2016-08-12 18:27:46 --> Config Class Initialized
INFO - 2016-08-12 18:27:46 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:27:46 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:27:46 --> Utf8 Class Initialized
INFO - 2016-08-12 18:27:46 --> URI Class Initialized
INFO - 2016-08-12 18:27:46 --> Router Class Initialized
INFO - 2016-08-12 18:27:46 --> Output Class Initialized
INFO - 2016-08-12 18:27:46 --> Security Class Initialized
DEBUG - 2016-08-12 18:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:27:46 --> Input Class Initialized
INFO - 2016-08-12 18:27:46 --> Language Class Initialized
INFO - 2016-08-12 18:27:46 --> Loader Class Initialized
INFO - 2016-08-12 18:27:46 --> Helper loaded: url_helper
INFO - 2016-08-12 18:27:46 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:27:46 --> Helper loaded: html_helper
INFO - 2016-08-12 18:27:46 --> Helper loaded: form_helper
INFO - 2016-08-12 18:27:46 --> Helper loaded: file_helper
INFO - 2016-08-12 18:27:46 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:27:46 --> Database Driver Class Initialized
INFO - 2016-08-12 18:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:27:46 --> Form Validation Class Initialized
INFO - 2016-08-12 18:27:46 --> Email Class Initialized
INFO - 2016-08-12 18:27:46 --> Controller Class Initialized
INFO - 2016-08-12 18:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:27:46 --> Final output sent to browser
DEBUG - 2016-08-12 18:27:46 --> Total execution time: 0.3990
INFO - 2016-08-12 18:27:56 --> Config Class Initialized
INFO - 2016-08-12 18:27:56 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:27:56 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:27:56 --> Utf8 Class Initialized
INFO - 2016-08-12 18:27:56 --> URI Class Initialized
INFO - 2016-08-12 18:27:56 --> Router Class Initialized
INFO - 2016-08-12 18:27:56 --> Output Class Initialized
INFO - 2016-08-12 18:27:56 --> Security Class Initialized
DEBUG - 2016-08-12 18:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:27:56 --> Input Class Initialized
INFO - 2016-08-12 18:27:56 --> Language Class Initialized
INFO - 2016-08-12 18:27:56 --> Loader Class Initialized
INFO - 2016-08-12 18:27:56 --> Helper loaded: url_helper
INFO - 2016-08-12 18:27:56 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:27:56 --> Helper loaded: html_helper
INFO - 2016-08-12 18:27:56 --> Helper loaded: form_helper
INFO - 2016-08-12 18:27:56 --> Helper loaded: file_helper
INFO - 2016-08-12 18:27:56 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:27:56 --> Database Driver Class Initialized
INFO - 2016-08-12 18:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:27:56 --> Form Validation Class Initialized
INFO - 2016-08-12 18:27:56 --> Email Class Initialized
INFO - 2016-08-12 18:27:56 --> Controller Class Initialized
DEBUG - 2016-08-12 18:27:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:27:56 --> Model Class Initialized
INFO - 2016-08-12 18:27:56 --> Model Class Initialized
INFO - 2016-08-12 18:27:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:27:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:27:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:27:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:27:56 --> Final output sent to browser
DEBUG - 2016-08-12 18:27:56 --> Total execution time: 0.4496
INFO - 2016-08-12 18:27:58 --> Config Class Initialized
INFO - 2016-08-12 18:27:58 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:27:58 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:27:58 --> Utf8 Class Initialized
INFO - 2016-08-12 18:27:58 --> URI Class Initialized
INFO - 2016-08-12 18:27:58 --> Router Class Initialized
INFO - 2016-08-12 18:27:58 --> Output Class Initialized
INFO - 2016-08-12 18:27:58 --> Security Class Initialized
DEBUG - 2016-08-12 18:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:27:58 --> Input Class Initialized
INFO - 2016-08-12 18:27:58 --> Language Class Initialized
INFO - 2016-08-12 18:27:58 --> Loader Class Initialized
INFO - 2016-08-12 18:27:58 --> Helper loaded: url_helper
INFO - 2016-08-12 18:27:58 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:27:58 --> Helper loaded: html_helper
INFO - 2016-08-12 18:27:58 --> Helper loaded: form_helper
INFO - 2016-08-12 18:27:58 --> Helper loaded: file_helper
INFO - 2016-08-12 18:27:58 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:27:58 --> Database Driver Class Initialized
INFO - 2016-08-12 18:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:27:58 --> Form Validation Class Initialized
INFO - 2016-08-12 18:27:58 --> Email Class Initialized
INFO - 2016-08-12 18:27:58 --> Controller Class Initialized
INFO - 2016-08-12 18:27:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:27:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:27:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:27:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:27:58 --> Final output sent to browser
DEBUG - 2016-08-12 18:27:58 --> Total execution time: 0.4309
INFO - 2016-08-12 18:29:50 --> Config Class Initialized
INFO - 2016-08-12 18:29:50 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:29:50 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:29:50 --> Utf8 Class Initialized
INFO - 2016-08-12 18:29:50 --> URI Class Initialized
INFO - 2016-08-12 18:29:50 --> Router Class Initialized
INFO - 2016-08-12 18:29:50 --> Output Class Initialized
INFO - 2016-08-12 18:29:50 --> Security Class Initialized
DEBUG - 2016-08-12 18:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:29:50 --> Input Class Initialized
INFO - 2016-08-12 18:29:50 --> Language Class Initialized
INFO - 2016-08-12 18:29:50 --> Loader Class Initialized
INFO - 2016-08-12 18:29:50 --> Helper loaded: url_helper
INFO - 2016-08-12 18:29:50 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:29:50 --> Helper loaded: html_helper
INFO - 2016-08-12 18:29:50 --> Helper loaded: form_helper
INFO - 2016-08-12 18:29:50 --> Helper loaded: file_helper
INFO - 2016-08-12 18:29:50 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:29:50 --> Database Driver Class Initialized
INFO - 2016-08-12 18:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:29:50 --> Form Validation Class Initialized
INFO - 2016-08-12 18:29:50 --> Email Class Initialized
INFO - 2016-08-12 18:29:50 --> Controller Class Initialized
INFO - 2016-08-12 18:29:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:29:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:29:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-12 18:29:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:29:50 --> Final output sent to browser
DEBUG - 2016-08-12 18:29:50 --> Total execution time: 0.4528
INFO - 2016-08-12 18:30:01 --> Config Class Initialized
INFO - 2016-08-12 18:30:01 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:30:01 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:30:01 --> Utf8 Class Initialized
INFO - 2016-08-12 18:30:01 --> URI Class Initialized
INFO - 2016-08-12 18:30:01 --> Router Class Initialized
INFO - 2016-08-12 18:30:01 --> Output Class Initialized
INFO - 2016-08-12 18:30:01 --> Security Class Initialized
DEBUG - 2016-08-12 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:30:01 --> Input Class Initialized
INFO - 2016-08-12 18:30:01 --> Language Class Initialized
INFO - 2016-08-12 18:30:01 --> Loader Class Initialized
INFO - 2016-08-12 18:30:01 --> Helper loaded: url_helper
INFO - 2016-08-12 18:30:01 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:30:01 --> Helper loaded: html_helper
INFO - 2016-08-12 18:30:01 --> Helper loaded: form_helper
INFO - 2016-08-12 18:30:01 --> Helper loaded: file_helper
INFO - 2016-08-12 18:30:01 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:30:01 --> Database Driver Class Initialized
INFO - 2016-08-12 18:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:30:01 --> Form Validation Class Initialized
INFO - 2016-08-12 18:30:01 --> Email Class Initialized
INFO - 2016-08-12 18:30:01 --> Controller Class Initialized
DEBUG - 2016-08-12 18:30:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:30:01 --> Model Class Initialized
INFO - 2016-08-12 18:30:01 --> Model Class Initialized
INFO - 2016-08-12 18:30:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:30:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:30:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:30:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:30:01 --> Final output sent to browser
DEBUG - 2016-08-12 18:30:01 --> Total execution time: 0.4507
INFO - 2016-08-12 18:30:04 --> Config Class Initialized
INFO - 2016-08-12 18:30:04 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:30:04 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:30:04 --> Utf8 Class Initialized
INFO - 2016-08-12 18:30:04 --> URI Class Initialized
INFO - 2016-08-12 18:30:05 --> Router Class Initialized
INFO - 2016-08-12 18:30:05 --> Output Class Initialized
INFO - 2016-08-12 18:30:05 --> Security Class Initialized
DEBUG - 2016-08-12 18:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:30:05 --> Input Class Initialized
INFO - 2016-08-12 18:30:05 --> Language Class Initialized
INFO - 2016-08-12 18:30:05 --> Loader Class Initialized
INFO - 2016-08-12 18:30:05 --> Helper loaded: url_helper
INFO - 2016-08-12 18:30:05 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:30:05 --> Helper loaded: html_helper
INFO - 2016-08-12 18:30:05 --> Helper loaded: form_helper
INFO - 2016-08-12 18:30:05 --> Helper loaded: file_helper
INFO - 2016-08-12 18:30:05 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:30:05 --> Database Driver Class Initialized
INFO - 2016-08-12 18:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:30:05 --> Form Validation Class Initialized
INFO - 2016-08-12 18:30:05 --> Email Class Initialized
INFO - 2016-08-12 18:30:05 --> Controller Class Initialized
DEBUG - 2016-08-12 18:30:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:30:05 --> Model Class Initialized
INFO - 2016-08-12 18:30:05 --> Model Class Initialized
INFO - 2016-08-12 18:30:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:30:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:30:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:30:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:30:05 --> Final output sent to browser
DEBUG - 2016-08-12 18:30:05 --> Total execution time: 0.4423
INFO - 2016-08-12 18:30:22 --> Config Class Initialized
INFO - 2016-08-12 18:30:22 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:30:22 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:30:22 --> Utf8 Class Initialized
INFO - 2016-08-12 18:30:22 --> URI Class Initialized
INFO - 2016-08-12 18:30:22 --> Router Class Initialized
INFO - 2016-08-12 18:30:22 --> Output Class Initialized
INFO - 2016-08-12 18:30:22 --> Security Class Initialized
DEBUG - 2016-08-12 18:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:30:22 --> Input Class Initialized
INFO - 2016-08-12 18:30:22 --> Language Class Initialized
INFO - 2016-08-12 18:30:22 --> Loader Class Initialized
INFO - 2016-08-12 18:30:22 --> Helper loaded: url_helper
INFO - 2016-08-12 18:30:22 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:30:22 --> Helper loaded: html_helper
INFO - 2016-08-12 18:30:22 --> Helper loaded: form_helper
INFO - 2016-08-12 18:30:22 --> Helper loaded: file_helper
INFO - 2016-08-12 18:30:22 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:30:22 --> Database Driver Class Initialized
INFO - 2016-08-12 18:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:30:22 --> Form Validation Class Initialized
INFO - 2016-08-12 18:30:22 --> Email Class Initialized
INFO - 2016-08-12 18:30:22 --> Controller Class Initialized
DEBUG - 2016-08-12 18:30:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:30:22 --> Model Class Initialized
INFO - 2016-08-12 18:30:22 --> Model Class Initialized
INFO - 2016-08-12 18:30:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:30:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:30:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:30:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:30:22 --> Final output sent to browser
DEBUG - 2016-08-12 18:30:22 --> Total execution time: 0.4557
INFO - 2016-08-12 18:30:24 --> Config Class Initialized
INFO - 2016-08-12 18:30:24 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:30:24 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:30:24 --> Utf8 Class Initialized
INFO - 2016-08-12 18:30:24 --> URI Class Initialized
INFO - 2016-08-12 18:30:24 --> Router Class Initialized
INFO - 2016-08-12 18:30:24 --> Output Class Initialized
INFO - 2016-08-12 18:30:24 --> Security Class Initialized
DEBUG - 2016-08-12 18:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:30:24 --> Input Class Initialized
INFO - 2016-08-12 18:30:24 --> Language Class Initialized
INFO - 2016-08-12 18:30:24 --> Loader Class Initialized
INFO - 2016-08-12 18:30:24 --> Helper loaded: url_helper
INFO - 2016-08-12 18:30:24 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:30:24 --> Helper loaded: html_helper
INFO - 2016-08-12 18:30:24 --> Helper loaded: form_helper
INFO - 2016-08-12 18:30:24 --> Helper loaded: file_helper
INFO - 2016-08-12 18:30:24 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:30:24 --> Database Driver Class Initialized
INFO - 2016-08-12 18:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:30:25 --> Form Validation Class Initialized
INFO - 2016-08-12 18:30:25 --> Email Class Initialized
INFO - 2016-08-12 18:30:25 --> Controller Class Initialized
DEBUG - 2016-08-12 18:30:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:30:25 --> Model Class Initialized
INFO - 2016-08-12 18:30:25 --> Model Class Initialized
INFO - 2016-08-12 18:30:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:30:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:30:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:30:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:30:25 --> Final output sent to browser
DEBUG - 2016-08-12 18:30:25 --> Total execution time: 0.4413
INFO - 2016-08-12 18:31:49 --> Config Class Initialized
INFO - 2016-08-12 18:31:49 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:31:49 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:31:49 --> Utf8 Class Initialized
INFO - 2016-08-12 18:31:49 --> URI Class Initialized
INFO - 2016-08-12 18:31:49 --> Router Class Initialized
INFO - 2016-08-12 18:31:49 --> Output Class Initialized
INFO - 2016-08-12 18:31:49 --> Security Class Initialized
DEBUG - 2016-08-12 18:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:31:49 --> Input Class Initialized
INFO - 2016-08-12 18:31:49 --> Language Class Initialized
INFO - 2016-08-12 18:31:49 --> Loader Class Initialized
INFO - 2016-08-12 18:31:49 --> Helper loaded: url_helper
INFO - 2016-08-12 18:31:49 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:31:49 --> Helper loaded: html_helper
INFO - 2016-08-12 18:31:49 --> Helper loaded: form_helper
INFO - 2016-08-12 18:31:49 --> Helper loaded: file_helper
INFO - 2016-08-12 18:31:49 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:31:49 --> Database Driver Class Initialized
INFO - 2016-08-12 18:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:31:49 --> Form Validation Class Initialized
INFO - 2016-08-12 18:31:49 --> Email Class Initialized
INFO - 2016-08-12 18:31:49 --> Controller Class Initialized
DEBUG - 2016-08-12 18:31:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:31:49 --> Model Class Initialized
INFO - 2016-08-12 18:31:49 --> Model Class Initialized
INFO - 2016-08-12 18:31:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:31:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:31:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-12 18:31:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:31:49 --> Final output sent to browser
DEBUG - 2016-08-12 18:31:49 --> Total execution time: 0.4729
INFO - 2016-08-12 18:31:53 --> Config Class Initialized
INFO - 2016-08-12 18:31:53 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:31:53 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:31:53 --> Utf8 Class Initialized
INFO - 2016-08-12 18:31:53 --> URI Class Initialized
INFO - 2016-08-12 18:31:53 --> Router Class Initialized
INFO - 2016-08-12 18:31:53 --> Output Class Initialized
INFO - 2016-08-12 18:31:53 --> Security Class Initialized
DEBUG - 2016-08-12 18:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:31:53 --> Input Class Initialized
INFO - 2016-08-12 18:31:53 --> Language Class Initialized
INFO - 2016-08-12 18:31:53 --> Loader Class Initialized
INFO - 2016-08-12 18:31:53 --> Helper loaded: url_helper
INFO - 2016-08-12 18:31:53 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:31:53 --> Helper loaded: html_helper
INFO - 2016-08-12 18:31:53 --> Helper loaded: form_helper
INFO - 2016-08-12 18:31:53 --> Helper loaded: file_helper
INFO - 2016-08-12 18:31:53 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:31:53 --> Database Driver Class Initialized
INFO - 2016-08-12 18:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:31:53 --> Form Validation Class Initialized
INFO - 2016-08-12 18:31:53 --> Email Class Initialized
INFO - 2016-08-12 18:31:53 --> Controller Class Initialized
INFO - 2016-08-12 18:31:53 --> Model Class Initialized
INFO - 2016-08-12 18:31:53 --> Model Class Initialized
INFO - 2016-08-12 18:31:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:31:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:31:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-12 18:31:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:31:53 --> Final output sent to browser
DEBUG - 2016-08-12 18:31:53 --> Total execution time: 0.4307
INFO - 2016-08-12 18:32:03 --> Config Class Initialized
INFO - 2016-08-12 18:32:03 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:32:03 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:32:03 --> Utf8 Class Initialized
INFO - 2016-08-12 18:32:03 --> URI Class Initialized
INFO - 2016-08-12 18:32:03 --> Router Class Initialized
INFO - 2016-08-12 18:32:03 --> Output Class Initialized
INFO - 2016-08-12 18:32:03 --> Security Class Initialized
DEBUG - 2016-08-12 18:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:32:03 --> Input Class Initialized
INFO - 2016-08-12 18:32:03 --> Language Class Initialized
INFO - 2016-08-12 18:32:03 --> Loader Class Initialized
INFO - 2016-08-12 18:32:03 --> Helper loaded: url_helper
INFO - 2016-08-12 18:32:03 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:32:03 --> Helper loaded: html_helper
INFO - 2016-08-12 18:32:03 --> Helper loaded: form_helper
INFO - 2016-08-12 18:32:04 --> Helper loaded: file_helper
INFO - 2016-08-12 18:32:04 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:32:04 --> Database Driver Class Initialized
INFO - 2016-08-12 18:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:32:04 --> Form Validation Class Initialized
INFO - 2016-08-12 18:32:04 --> Email Class Initialized
INFO - 2016-08-12 18:32:04 --> Controller Class Initialized
DEBUG - 2016-08-12 18:32:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:32:04 --> Model Class Initialized
INFO - 2016-08-12 18:32:04 --> Model Class Initialized
INFO - 2016-08-12 18:32:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:32:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:32:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:32:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:32:04 --> Final output sent to browser
DEBUG - 2016-08-12 18:32:04 --> Total execution time: 0.4866
INFO - 2016-08-12 18:32:16 --> Config Class Initialized
INFO - 2016-08-12 18:32:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:32:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:32:16 --> Utf8 Class Initialized
INFO - 2016-08-12 18:32:16 --> URI Class Initialized
INFO - 2016-08-12 18:32:16 --> Router Class Initialized
INFO - 2016-08-12 18:32:16 --> Output Class Initialized
INFO - 2016-08-12 18:32:16 --> Security Class Initialized
DEBUG - 2016-08-12 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:32:16 --> Input Class Initialized
INFO - 2016-08-12 18:32:16 --> Language Class Initialized
INFO - 2016-08-12 18:32:16 --> Loader Class Initialized
INFO - 2016-08-12 18:32:16 --> Helper loaded: url_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: html_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: form_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: file_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:32:16 --> Database Driver Class Initialized
INFO - 2016-08-12 18:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:32:16 --> Form Validation Class Initialized
INFO - 2016-08-12 18:32:16 --> Email Class Initialized
INFO - 2016-08-12 18:32:16 --> Controller Class Initialized
DEBUG - 2016-08-12 18:32:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:32:16 --> Model Class Initialized
INFO - 2016-08-12 18:32:16 --> Model Class Initialized
INFO - 2016-08-12 18:32:16 --> Config Class Initialized
INFO - 2016-08-12 18:32:16 --> Hooks Class Initialized
DEBUG - 2016-08-12 18:32:16 --> UTF-8 Support Enabled
INFO - 2016-08-12 18:32:16 --> Utf8 Class Initialized
INFO - 2016-08-12 18:32:16 --> URI Class Initialized
INFO - 2016-08-12 18:32:16 --> Router Class Initialized
INFO - 2016-08-12 18:32:16 --> Output Class Initialized
INFO - 2016-08-12 18:32:16 --> Security Class Initialized
DEBUG - 2016-08-12 18:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-12 18:32:16 --> Input Class Initialized
INFO - 2016-08-12 18:32:16 --> Language Class Initialized
INFO - 2016-08-12 18:32:16 --> Loader Class Initialized
INFO - 2016-08-12 18:32:16 --> Helper loaded: url_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: utils_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: html_helper
INFO - 2016-08-12 18:32:16 --> Helper loaded: form_helper
INFO - 2016-08-12 18:32:17 --> Helper loaded: file_helper
INFO - 2016-08-12 18:32:17 --> Helper loaded: myemail_helper
INFO - 2016-08-12 18:32:17 --> Database Driver Class Initialized
INFO - 2016-08-12 18:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-12 18:32:17 --> Form Validation Class Initialized
INFO - 2016-08-12 18:32:17 --> Email Class Initialized
INFO - 2016-08-12 18:32:17 --> Controller Class Initialized
DEBUG - 2016-08-12 18:32:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-12 18:32:17 --> Model Class Initialized
INFO - 2016-08-12 18:32:17 --> Model Class Initialized
INFO - 2016-08-12 18:32:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-12 18:32:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-12 18:32:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-12 18:32:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-12 18:32:17 --> Final output sent to browser
DEBUG - 2016-08-12 18:32:17 --> Total execution time: 0.4531
