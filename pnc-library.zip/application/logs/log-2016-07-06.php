<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-06 01:48:50 --> Config Class Initialized
INFO - 2016-07-06 01:48:50 --> Hooks Class Initialized
DEBUG - 2016-07-06 01:48:50 --> UTF-8 Support Enabled
INFO - 2016-07-06 01:48:50 --> Utf8 Class Initialized
INFO - 2016-07-06 01:48:50 --> URI Class Initialized
INFO - 2016-07-06 01:48:50 --> Router Class Initialized
INFO - 2016-07-06 01:48:50 --> Output Class Initialized
INFO - 2016-07-06 01:48:50 --> Security Class Initialized
DEBUG - 2016-07-06 01:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 01:48:50 --> Input Class Initialized
INFO - 2016-07-06 01:48:50 --> Language Class Initialized
ERROR - 2016-07-06 01:48:50 --> 404 Page Not Found: Books/import_book
INFO - 2016-07-06 05:49:09 --> Config Class Initialized
INFO - 2016-07-06 05:49:09 --> Hooks Class Initialized
DEBUG - 2016-07-06 05:49:09 --> UTF-8 Support Enabled
INFO - 2016-07-06 05:49:09 --> Utf8 Class Initialized
INFO - 2016-07-06 05:49:09 --> URI Class Initialized
INFO - 2016-07-06 05:49:09 --> Router Class Initialized
INFO - 2016-07-06 05:49:09 --> Output Class Initialized
INFO - 2016-07-06 05:49:09 --> Security Class Initialized
DEBUG - 2016-07-06 05:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 05:49:09 --> Input Class Initialized
INFO - 2016-07-06 05:49:09 --> Language Class Initialized
ERROR - 2016-07-06 05:49:09 --> 404 Page Not Found: Books/import_book
INFO - 2016-07-06 07:51:47 --> Config Class Initialized
INFO - 2016-07-06 07:51:47 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:51:47 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:51:47 --> Utf8 Class Initialized
INFO - 2016-07-06 07:51:47 --> URI Class Initialized
INFO - 2016-07-06 07:51:47 --> Router Class Initialized
INFO - 2016-07-06 07:51:47 --> Output Class Initialized
INFO - 2016-07-06 07:51:47 --> Security Class Initialized
DEBUG - 2016-07-06 07:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:51:47 --> Input Class Initialized
INFO - 2016-07-06 07:51:47 --> Language Class Initialized
INFO - 2016-07-06 07:51:47 --> Loader Class Initialized
INFO - 2016-07-06 07:51:47 --> Helper loaded: url_helper
INFO - 2016-07-06 07:51:47 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:51:47 --> Helper loaded: html_helper
INFO - 2016-07-06 07:51:47 --> Helper loaded: form_helper
INFO - 2016-07-06 07:51:47 --> Helper loaded: file_helper
INFO - 2016-07-06 07:51:47 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:51:48 --> Database Driver Class Initialized
INFO - 2016-07-06 07:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:51:48 --> Form Validation Class Initialized
INFO - 2016-07-06 07:51:48 --> Email Class Initialized
INFO - 2016-07-06 07:51:48 --> Controller Class Initialized
INFO - 2016-07-06 07:51:48 --> Config Class Initialized
INFO - 2016-07-06 07:51:48 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:51:48 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:51:48 --> Utf8 Class Initialized
INFO - 2016-07-06 07:51:48 --> URI Class Initialized
INFO - 2016-07-06 07:51:48 --> Router Class Initialized
INFO - 2016-07-06 07:51:48 --> Output Class Initialized
INFO - 2016-07-06 07:51:48 --> Security Class Initialized
DEBUG - 2016-07-06 07:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:51:48 --> Input Class Initialized
INFO - 2016-07-06 07:51:48 --> Language Class Initialized
INFO - 2016-07-06 07:51:48 --> Loader Class Initialized
INFO - 2016-07-06 07:51:48 --> Helper loaded: url_helper
INFO - 2016-07-06 07:51:48 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:51:48 --> Helper loaded: html_helper
INFO - 2016-07-06 07:51:48 --> Helper loaded: form_helper
INFO - 2016-07-06 07:51:48 --> Helper loaded: file_helper
INFO - 2016-07-06 07:51:48 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:51:48 --> Database Driver Class Initialized
INFO - 2016-07-06 07:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:51:48 --> Form Validation Class Initialized
INFO - 2016-07-06 07:51:48 --> Email Class Initialized
INFO - 2016-07-06 07:51:48 --> Controller Class Initialized
INFO - 2016-07-06 07:51:48 --> Model Class Initialized
DEBUG - 2016-07-06 07:51:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:51:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-06 07:51:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 07:51:48 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-06 07:51:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 07:51:48 --> Final output sent to browser
DEBUG - 2016-07-06 07:51:48 --> Total execution time: 0.2763
INFO - 2016-07-06 07:51:50 --> Config Class Initialized
INFO - 2016-07-06 07:51:50 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:51:50 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:51:50 --> Utf8 Class Initialized
INFO - 2016-07-06 07:51:50 --> URI Class Initialized
INFO - 2016-07-06 07:51:50 --> Router Class Initialized
INFO - 2016-07-06 07:51:50 --> Output Class Initialized
INFO - 2016-07-06 07:51:50 --> Security Class Initialized
DEBUG - 2016-07-06 07:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:51:50 --> Input Class Initialized
INFO - 2016-07-06 07:51:50 --> Language Class Initialized
INFO - 2016-07-06 07:51:50 --> Loader Class Initialized
INFO - 2016-07-06 07:51:50 --> Helper loaded: url_helper
INFO - 2016-07-06 07:51:50 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:51:50 --> Helper loaded: html_helper
INFO - 2016-07-06 07:51:50 --> Helper loaded: form_helper
INFO - 2016-07-06 07:51:50 --> Helper loaded: file_helper
INFO - 2016-07-06 07:51:50 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:51:50 --> Database Driver Class Initialized
INFO - 2016-07-06 07:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:51:51 --> Form Validation Class Initialized
INFO - 2016-07-06 07:51:51 --> Email Class Initialized
INFO - 2016-07-06 07:51:51 --> Controller Class Initialized
INFO - 2016-07-06 07:51:51 --> Model Class Initialized
DEBUG - 2016-07-06 07:51:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:51:51 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-07-06 07:51:51 --> {controllers/session/login} Invalid login id or password for user=bpitet
INFO - 2016-07-06 07:51:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-06 07:51:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 07:51:51 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-06 07:51:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 07:51:51 --> Final output sent to browser
DEBUG - 2016-07-06 07:51:51 --> Total execution time: 0.3163
INFO - 2016-07-06 07:51:54 --> Config Class Initialized
INFO - 2016-07-06 07:51:54 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:51:54 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:51:54 --> Utf8 Class Initialized
INFO - 2016-07-06 07:51:54 --> URI Class Initialized
INFO - 2016-07-06 07:51:54 --> Router Class Initialized
INFO - 2016-07-06 07:51:54 --> Output Class Initialized
INFO - 2016-07-06 07:51:54 --> Security Class Initialized
DEBUG - 2016-07-06 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:51:54 --> Input Class Initialized
INFO - 2016-07-06 07:51:54 --> Language Class Initialized
INFO - 2016-07-06 07:51:54 --> Loader Class Initialized
INFO - 2016-07-06 07:51:54 --> Helper loaded: url_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: html_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: form_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: file_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:51:54 --> Database Driver Class Initialized
INFO - 2016-07-06 07:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:51:54 --> Form Validation Class Initialized
INFO - 2016-07-06 07:51:54 --> Email Class Initialized
INFO - 2016-07-06 07:51:54 --> Controller Class Initialized
INFO - 2016-07-06 07:51:54 --> Model Class Initialized
DEBUG - 2016-07-06 07:51:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:51:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-06 07:51:54 --> Config Class Initialized
INFO - 2016-07-06 07:51:54 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:51:54 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:51:54 --> Utf8 Class Initialized
INFO - 2016-07-06 07:51:54 --> URI Class Initialized
INFO - 2016-07-06 07:51:54 --> Router Class Initialized
INFO - 2016-07-06 07:51:54 --> Output Class Initialized
INFO - 2016-07-06 07:51:54 --> Security Class Initialized
DEBUG - 2016-07-06 07:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:51:54 --> Input Class Initialized
INFO - 2016-07-06 07:51:54 --> Language Class Initialized
INFO - 2016-07-06 07:51:54 --> Loader Class Initialized
INFO - 2016-07-06 07:51:54 --> Helper loaded: url_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: html_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: form_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: file_helper
INFO - 2016-07-06 07:51:54 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:51:54 --> Database Driver Class Initialized
INFO - 2016-07-06 07:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:51:54 --> Form Validation Class Initialized
INFO - 2016-07-06 07:51:54 --> Email Class Initialized
INFO - 2016-07-06 07:51:54 --> Controller Class Initialized
DEBUG - 2016-07-06 07:51:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:51:54 --> Final output sent to browser
DEBUG - 2016-07-06 07:51:54 --> Total execution time: 0.1840
INFO - 2016-07-06 07:52:00 --> Config Class Initialized
INFO - 2016-07-06 07:52:00 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:52:00 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:52:00 --> Utf8 Class Initialized
INFO - 2016-07-06 07:52:00 --> URI Class Initialized
INFO - 2016-07-06 07:52:00 --> Router Class Initialized
INFO - 2016-07-06 07:52:00 --> Output Class Initialized
INFO - 2016-07-06 07:52:00 --> Security Class Initialized
DEBUG - 2016-07-06 07:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:52:00 --> Input Class Initialized
INFO - 2016-07-06 07:52:00 --> Language Class Initialized
INFO - 2016-07-06 07:52:00 --> Loader Class Initialized
INFO - 2016-07-06 07:52:00 --> Helper loaded: url_helper
INFO - 2016-07-06 07:52:00 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:52:00 --> Helper loaded: html_helper
INFO - 2016-07-06 07:52:00 --> Helper loaded: form_helper
INFO - 2016-07-06 07:52:00 --> Helper loaded: file_helper
INFO - 2016-07-06 07:52:00 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:52:00 --> Database Driver Class Initialized
INFO - 2016-07-06 07:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:52:00 --> Form Validation Class Initialized
INFO - 2016-07-06 07:52:00 --> Email Class Initialized
INFO - 2016-07-06 07:52:00 --> Controller Class Initialized
DEBUG - 2016-07-06 07:52:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:52:00 --> Final output sent to browser
DEBUG - 2016-07-06 07:52:00 --> Total execution time: 0.1698
INFO - 2016-07-06 07:52:23 --> Config Class Initialized
INFO - 2016-07-06 07:52:23 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:52:23 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:52:23 --> Utf8 Class Initialized
INFO - 2016-07-06 07:52:23 --> URI Class Initialized
INFO - 2016-07-06 07:52:23 --> Router Class Initialized
INFO - 2016-07-06 07:52:23 --> Output Class Initialized
INFO - 2016-07-06 07:52:23 --> Security Class Initialized
DEBUG - 2016-07-06 07:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:52:23 --> Input Class Initialized
INFO - 2016-07-06 07:52:23 --> Language Class Initialized
INFO - 2016-07-06 07:52:23 --> Loader Class Initialized
INFO - 2016-07-06 07:52:23 --> Helper loaded: url_helper
INFO - 2016-07-06 07:52:23 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:52:23 --> Helper loaded: html_helper
INFO - 2016-07-06 07:52:23 --> Helper loaded: form_helper
INFO - 2016-07-06 07:52:23 --> Helper loaded: file_helper
INFO - 2016-07-06 07:52:23 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:52:23 --> Database Driver Class Initialized
INFO - 2016-07-06 07:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:52:23 --> Form Validation Class Initialized
INFO - 2016-07-06 07:52:23 --> Email Class Initialized
INFO - 2016-07-06 07:52:23 --> Controller Class Initialized
DEBUG - 2016-07-06 07:52:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:52:23 --> Model Class Initialized
INFO - 2016-07-06 07:52:23 --> Model Class Initialized
INFO - 2016-07-06 07:52:23 --> Model Class Initialized
INFO - 2016-07-06 07:52:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 07:52:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 07:52:23 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 07:52:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 07:52:23 --> Final output sent to browser
DEBUG - 2016-07-06 07:52:23 --> Total execution time: 0.2779
INFO - 2016-07-06 07:52:43 --> Config Class Initialized
INFO - 2016-07-06 07:52:43 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:52:43 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:52:43 --> Utf8 Class Initialized
INFO - 2016-07-06 07:52:43 --> URI Class Initialized
INFO - 2016-07-06 07:52:43 --> Router Class Initialized
INFO - 2016-07-06 07:52:43 --> Output Class Initialized
INFO - 2016-07-06 07:52:43 --> Security Class Initialized
DEBUG - 2016-07-06 07:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:52:43 --> Input Class Initialized
INFO - 2016-07-06 07:52:43 --> Language Class Initialized
INFO - 2016-07-06 07:52:43 --> Loader Class Initialized
INFO - 2016-07-06 07:52:43 --> Helper loaded: url_helper
INFO - 2016-07-06 07:52:43 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:52:43 --> Helper loaded: html_helper
INFO - 2016-07-06 07:52:43 --> Helper loaded: form_helper
INFO - 2016-07-06 07:52:43 --> Helper loaded: file_helper
INFO - 2016-07-06 07:52:43 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:52:43 --> Database Driver Class Initialized
INFO - 2016-07-06 07:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:52:43 --> Form Validation Class Initialized
INFO - 2016-07-06 07:52:43 --> Email Class Initialized
INFO - 2016-07-06 07:52:43 --> Controller Class Initialized
DEBUG - 2016-07-06 07:52:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:52:43 --> Model Class Initialized
INFO - 2016-07-06 07:52:43 --> Model Class Initialized
INFO - 2016-07-06 07:52:43 --> Model Class Initialized
INFO - 2016-07-06 07:52:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 07:52:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 07:52:43 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 07:52:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 07:53:15 --> Config Class Initialized
INFO - 2016-07-06 07:53:15 --> Hooks Class Initialized
DEBUG - 2016-07-06 07:53:15 --> UTF-8 Support Enabled
INFO - 2016-07-06 07:53:15 --> Utf8 Class Initialized
INFO - 2016-07-06 07:53:15 --> URI Class Initialized
INFO - 2016-07-06 07:53:15 --> Router Class Initialized
INFO - 2016-07-06 07:53:15 --> Output Class Initialized
INFO - 2016-07-06 07:53:15 --> Security Class Initialized
DEBUG - 2016-07-06 07:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 07:53:15 --> Input Class Initialized
INFO - 2016-07-06 07:53:15 --> Language Class Initialized
INFO - 2016-07-06 07:53:15 --> Loader Class Initialized
INFO - 2016-07-06 07:53:15 --> Helper loaded: url_helper
INFO - 2016-07-06 07:53:15 --> Helper loaded: utils_helper
INFO - 2016-07-06 07:53:15 --> Helper loaded: html_helper
INFO - 2016-07-06 07:53:15 --> Helper loaded: form_helper
INFO - 2016-07-06 07:53:15 --> Helper loaded: file_helper
INFO - 2016-07-06 07:53:15 --> Helper loaded: myemail_helper
INFO - 2016-07-06 07:53:15 --> Database Driver Class Initialized
INFO - 2016-07-06 07:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 07:53:15 --> Form Validation Class Initialized
INFO - 2016-07-06 07:53:15 --> Email Class Initialized
INFO - 2016-07-06 07:53:15 --> Controller Class Initialized
DEBUG - 2016-07-06 07:53:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 07:53:15 --> Model Class Initialized
INFO - 2016-07-06 07:53:15 --> Model Class Initialized
INFO - 2016-07-06 07:53:15 --> Model Class Initialized
INFO - 2016-07-06 07:53:15 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 07:53:15 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 07:53:15 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 07:53:15 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:27:05 --> Config Class Initialized
INFO - 2016-07-06 10:27:05 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:27:05 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:27:05 --> Utf8 Class Initialized
INFO - 2016-07-06 10:27:05 --> URI Class Initialized
INFO - 2016-07-06 10:27:05 --> Router Class Initialized
INFO - 2016-07-06 10:27:05 --> Output Class Initialized
INFO - 2016-07-06 10:27:06 --> Security Class Initialized
DEBUG - 2016-07-06 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:27:06 --> Input Class Initialized
INFO - 2016-07-06 10:27:06 --> Language Class Initialized
INFO - 2016-07-06 10:27:06 --> Loader Class Initialized
INFO - 2016-07-06 10:27:06 --> Helper loaded: url_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: html_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: form_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: file_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:27:06 --> Database Driver Class Initialized
INFO - 2016-07-06 10:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:27:06 --> Form Validation Class Initialized
INFO - 2016-07-06 10:27:06 --> Email Class Initialized
INFO - 2016-07-06 10:27:06 --> Controller Class Initialized
INFO - 2016-07-06 10:27:06 --> Config Class Initialized
INFO - 2016-07-06 10:27:06 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:27:06 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:27:06 --> Utf8 Class Initialized
INFO - 2016-07-06 10:27:06 --> URI Class Initialized
INFO - 2016-07-06 10:27:06 --> Router Class Initialized
INFO - 2016-07-06 10:27:06 --> Output Class Initialized
INFO - 2016-07-06 10:27:06 --> Security Class Initialized
DEBUG - 2016-07-06 10:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:27:06 --> Input Class Initialized
INFO - 2016-07-06 10:27:06 --> Language Class Initialized
INFO - 2016-07-06 10:27:06 --> Loader Class Initialized
INFO - 2016-07-06 10:27:06 --> Helper loaded: url_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: html_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: form_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: file_helper
INFO - 2016-07-06 10:27:06 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:27:06 --> Database Driver Class Initialized
INFO - 2016-07-06 10:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:27:06 --> Form Validation Class Initialized
INFO - 2016-07-06 10:27:06 --> Email Class Initialized
INFO - 2016-07-06 10:27:06 --> Controller Class Initialized
INFO - 2016-07-06 10:27:06 --> Model Class Initialized
DEBUG - 2016-07-06 10:27:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:27:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-06 10:27:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:27:06 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-06 10:27:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:27:06 --> Final output sent to browser
DEBUG - 2016-07-06 10:27:06 --> Total execution time: 0.2369
INFO - 2016-07-06 10:27:11 --> Config Class Initialized
INFO - 2016-07-06 10:27:11 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:27:11 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:27:11 --> Utf8 Class Initialized
INFO - 2016-07-06 10:27:11 --> URI Class Initialized
INFO - 2016-07-06 10:27:11 --> Router Class Initialized
INFO - 2016-07-06 10:27:11 --> Output Class Initialized
INFO - 2016-07-06 10:27:11 --> Security Class Initialized
DEBUG - 2016-07-06 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:27:11 --> Input Class Initialized
INFO - 2016-07-06 10:27:11 --> Language Class Initialized
INFO - 2016-07-06 10:27:11 --> Loader Class Initialized
INFO - 2016-07-06 10:27:11 --> Helper loaded: url_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: html_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: form_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: file_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:27:11 --> Database Driver Class Initialized
INFO - 2016-07-06 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:27:11 --> Form Validation Class Initialized
INFO - 2016-07-06 10:27:11 --> Email Class Initialized
INFO - 2016-07-06 10:27:11 --> Controller Class Initialized
INFO - 2016-07-06 10:27:11 --> Model Class Initialized
DEBUG - 2016-07-06 10:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:27:11 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-06 10:27:11 --> Config Class Initialized
INFO - 2016-07-06 10:27:11 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:27:11 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:27:11 --> Utf8 Class Initialized
INFO - 2016-07-06 10:27:11 --> URI Class Initialized
INFO - 2016-07-06 10:27:11 --> Router Class Initialized
INFO - 2016-07-06 10:27:11 --> Output Class Initialized
INFO - 2016-07-06 10:27:11 --> Security Class Initialized
DEBUG - 2016-07-06 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:27:11 --> Input Class Initialized
INFO - 2016-07-06 10:27:11 --> Language Class Initialized
INFO - 2016-07-06 10:27:11 --> Loader Class Initialized
INFO - 2016-07-06 10:27:11 --> Helper loaded: url_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: html_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: form_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: file_helper
INFO - 2016-07-06 10:27:11 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:27:11 --> Database Driver Class Initialized
INFO - 2016-07-06 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:27:11 --> Form Validation Class Initialized
INFO - 2016-07-06 10:27:11 --> Email Class Initialized
INFO - 2016-07-06 10:27:11 --> Controller Class Initialized
DEBUG - 2016-07-06 10:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:27:11 --> Model Class Initialized
INFO - 2016-07-06 10:27:11 --> Model Class Initialized
INFO - 2016-07-06 10:27:11 --> Model Class Initialized
INFO - 2016-07-06 10:27:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:27:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:27:11 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:27:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:27:11 --> Final output sent to browser
DEBUG - 2016-07-06 10:27:11 --> Total execution time: 0.2099
INFO - 2016-07-06 10:27:19 --> Config Class Initialized
INFO - 2016-07-06 10:27:19 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:27:19 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:27:19 --> Utf8 Class Initialized
INFO - 2016-07-06 10:27:19 --> URI Class Initialized
INFO - 2016-07-06 10:27:19 --> Router Class Initialized
INFO - 2016-07-06 10:27:19 --> Output Class Initialized
INFO - 2016-07-06 10:27:19 --> Security Class Initialized
DEBUG - 2016-07-06 10:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:27:19 --> Input Class Initialized
INFO - 2016-07-06 10:27:19 --> Language Class Initialized
INFO - 2016-07-06 10:27:19 --> Loader Class Initialized
INFO - 2016-07-06 10:27:19 --> Helper loaded: url_helper
INFO - 2016-07-06 10:27:19 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:27:19 --> Helper loaded: html_helper
INFO - 2016-07-06 10:27:19 --> Helper loaded: form_helper
INFO - 2016-07-06 10:27:19 --> Helper loaded: file_helper
INFO - 2016-07-06 10:27:19 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:27:19 --> Database Driver Class Initialized
INFO - 2016-07-06 10:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:27:19 --> Form Validation Class Initialized
INFO - 2016-07-06 10:27:19 --> Email Class Initialized
INFO - 2016-07-06 10:27:19 --> Controller Class Initialized
DEBUG - 2016-07-06 10:27:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:27:19 --> Model Class Initialized
INFO - 2016-07-06 10:27:19 --> Model Class Initialized
INFO - 2016-07-06 10:27:19 --> Model Class Initialized
INFO - 2016-07-06 10:27:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:27:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:27:19 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:27:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:28:06 --> Config Class Initialized
INFO - 2016-07-06 10:28:07 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:28:07 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:28:07 --> Utf8 Class Initialized
INFO - 2016-07-06 10:28:07 --> URI Class Initialized
INFO - 2016-07-06 10:28:07 --> Router Class Initialized
INFO - 2016-07-06 10:28:07 --> Output Class Initialized
INFO - 2016-07-06 10:28:07 --> Security Class Initialized
DEBUG - 2016-07-06 10:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:28:07 --> Input Class Initialized
INFO - 2016-07-06 10:28:07 --> Language Class Initialized
INFO - 2016-07-06 10:28:07 --> Loader Class Initialized
INFO - 2016-07-06 10:28:07 --> Helper loaded: url_helper
INFO - 2016-07-06 10:28:07 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:28:07 --> Helper loaded: html_helper
INFO - 2016-07-06 10:28:07 --> Helper loaded: form_helper
INFO - 2016-07-06 10:28:07 --> Helper loaded: file_helper
INFO - 2016-07-06 10:28:07 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:28:07 --> Database Driver Class Initialized
INFO - 2016-07-06 10:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:28:07 --> Form Validation Class Initialized
INFO - 2016-07-06 10:28:07 --> Email Class Initialized
INFO - 2016-07-06 10:28:07 --> Controller Class Initialized
DEBUG - 2016-07-06 10:28:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:28:07 --> Model Class Initialized
INFO - 2016-07-06 10:28:07 --> Model Class Initialized
INFO - 2016-07-06 10:28:07 --> Model Class Initialized
INFO - 2016-07-06 10:28:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:28:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:28:07 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:28:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:29:24 --> Config Class Initialized
INFO - 2016-07-06 10:29:24 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:29:24 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:29:24 --> Utf8 Class Initialized
INFO - 2016-07-06 10:29:24 --> URI Class Initialized
INFO - 2016-07-06 10:29:24 --> Router Class Initialized
INFO - 2016-07-06 10:29:24 --> Output Class Initialized
INFO - 2016-07-06 10:29:24 --> Security Class Initialized
DEBUG - 2016-07-06 10:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:29:24 --> Input Class Initialized
INFO - 2016-07-06 10:29:24 --> Language Class Initialized
INFO - 2016-07-06 10:29:24 --> Loader Class Initialized
INFO - 2016-07-06 10:29:24 --> Helper loaded: url_helper
INFO - 2016-07-06 10:29:24 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:29:24 --> Helper loaded: html_helper
INFO - 2016-07-06 10:29:24 --> Helper loaded: form_helper
INFO - 2016-07-06 10:29:24 --> Helper loaded: file_helper
INFO - 2016-07-06 10:29:24 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:29:24 --> Database Driver Class Initialized
INFO - 2016-07-06 10:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:29:24 --> Form Validation Class Initialized
INFO - 2016-07-06 10:29:24 --> Email Class Initialized
INFO - 2016-07-06 10:29:24 --> Controller Class Initialized
DEBUG - 2016-07-06 10:29:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:29:24 --> Model Class Initialized
INFO - 2016-07-06 10:29:24 --> Model Class Initialized
INFO - 2016-07-06 10:29:24 --> Model Class Initialized
INFO - 2016-07-06 10:29:24 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:29:24 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:29:24 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:29:24 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:29:24 --> Final output sent to browser
DEBUG - 2016-07-06 10:29:24 --> Total execution time: 0.2962
INFO - 2016-07-06 10:29:29 --> Config Class Initialized
INFO - 2016-07-06 10:29:29 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:29:29 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:29:29 --> Utf8 Class Initialized
INFO - 2016-07-06 10:29:29 --> URI Class Initialized
INFO - 2016-07-06 10:29:29 --> Router Class Initialized
INFO - 2016-07-06 10:29:29 --> Output Class Initialized
INFO - 2016-07-06 10:29:29 --> Security Class Initialized
DEBUG - 2016-07-06 10:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:29:29 --> Input Class Initialized
INFO - 2016-07-06 10:29:29 --> Language Class Initialized
INFO - 2016-07-06 10:29:29 --> Loader Class Initialized
INFO - 2016-07-06 10:29:29 --> Helper loaded: url_helper
INFO - 2016-07-06 10:29:29 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:29:29 --> Helper loaded: html_helper
INFO - 2016-07-06 10:29:29 --> Helper loaded: form_helper
INFO - 2016-07-06 10:29:29 --> Helper loaded: file_helper
INFO - 2016-07-06 10:29:29 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:29:29 --> Database Driver Class Initialized
INFO - 2016-07-06 10:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:29:29 --> Form Validation Class Initialized
INFO - 2016-07-06 10:29:29 --> Email Class Initialized
INFO - 2016-07-06 10:29:29 --> Controller Class Initialized
DEBUG - 2016-07-06 10:29:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:29:29 --> Model Class Initialized
INFO - 2016-07-06 10:29:29 --> Model Class Initialized
INFO - 2016-07-06 10:29:29 --> Model Class Initialized
INFO - 2016-07-06 10:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:29:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:29:29 --> Final output sent to browser
DEBUG - 2016-07-06 10:29:29 --> Total execution time: 0.2345
INFO - 2016-07-06 10:29:34 --> Config Class Initialized
INFO - 2016-07-06 10:29:34 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:29:34 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:29:34 --> Utf8 Class Initialized
INFO - 2016-07-06 10:29:34 --> URI Class Initialized
INFO - 2016-07-06 10:29:34 --> Router Class Initialized
INFO - 2016-07-06 10:29:34 --> Output Class Initialized
INFO - 2016-07-06 10:29:34 --> Security Class Initialized
DEBUG - 2016-07-06 10:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:29:34 --> Input Class Initialized
INFO - 2016-07-06 10:29:34 --> Language Class Initialized
INFO - 2016-07-06 10:29:34 --> Loader Class Initialized
INFO - 2016-07-06 10:29:34 --> Helper loaded: url_helper
INFO - 2016-07-06 10:29:34 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:29:34 --> Helper loaded: html_helper
INFO - 2016-07-06 10:29:34 --> Helper loaded: form_helper
INFO - 2016-07-06 10:29:34 --> Helper loaded: file_helper
INFO - 2016-07-06 10:29:34 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:29:34 --> Database Driver Class Initialized
INFO - 2016-07-06 10:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:29:34 --> Form Validation Class Initialized
INFO - 2016-07-06 10:29:34 --> Email Class Initialized
INFO - 2016-07-06 10:29:34 --> Controller Class Initialized
DEBUG - 2016-07-06 10:29:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:29:34 --> Model Class Initialized
INFO - 2016-07-06 10:29:34 --> Model Class Initialized
INFO - 2016-07-06 10:29:34 --> Model Class Initialized
INFO - 2016-07-06 10:29:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:29:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:29:34 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:29:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:29:49 --> Config Class Initialized
INFO - 2016-07-06 10:29:49 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:29:49 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:29:49 --> Utf8 Class Initialized
INFO - 2016-07-06 10:29:49 --> URI Class Initialized
INFO - 2016-07-06 10:29:49 --> Router Class Initialized
INFO - 2016-07-06 10:29:49 --> Output Class Initialized
INFO - 2016-07-06 10:29:49 --> Security Class Initialized
DEBUG - 2016-07-06 10:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:29:49 --> Input Class Initialized
INFO - 2016-07-06 10:29:49 --> Language Class Initialized
INFO - 2016-07-06 10:29:49 --> Loader Class Initialized
INFO - 2016-07-06 10:29:49 --> Helper loaded: url_helper
INFO - 2016-07-06 10:29:49 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:29:49 --> Helper loaded: html_helper
INFO - 2016-07-06 10:29:49 --> Helper loaded: form_helper
INFO - 2016-07-06 10:29:49 --> Helper loaded: file_helper
INFO - 2016-07-06 10:29:49 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:29:49 --> Database Driver Class Initialized
INFO - 2016-07-06 10:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:29:49 --> Form Validation Class Initialized
INFO - 2016-07-06 10:29:49 --> Email Class Initialized
INFO - 2016-07-06 10:29:49 --> Controller Class Initialized
DEBUG - 2016-07-06 10:29:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:29:49 --> Model Class Initialized
INFO - 2016-07-06 10:29:49 --> Model Class Initialized
INFO - 2016-07-06 10:29:49 --> Model Class Initialized
INFO - 2016-07-06 10:29:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:29:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:29:49 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:29:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:37:58 --> Config Class Initialized
INFO - 2016-07-06 10:37:58 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:37:58 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:37:58 --> Utf8 Class Initialized
INFO - 2016-07-06 10:37:58 --> URI Class Initialized
INFO - 2016-07-06 10:37:59 --> Router Class Initialized
INFO - 2016-07-06 10:37:59 --> Output Class Initialized
INFO - 2016-07-06 10:37:59 --> Security Class Initialized
DEBUG - 2016-07-06 10:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:37:59 --> Input Class Initialized
INFO - 2016-07-06 10:37:59 --> Language Class Initialized
INFO - 2016-07-06 10:37:59 --> Loader Class Initialized
INFO - 2016-07-06 10:37:59 --> Helper loaded: url_helper
INFO - 2016-07-06 10:37:59 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:37:59 --> Helper loaded: html_helper
INFO - 2016-07-06 10:37:59 --> Helper loaded: form_helper
INFO - 2016-07-06 10:37:59 --> Helper loaded: file_helper
INFO - 2016-07-06 10:37:59 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:37:59 --> Database Driver Class Initialized
INFO - 2016-07-06 10:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:37:59 --> Form Validation Class Initialized
INFO - 2016-07-06 10:37:59 --> Email Class Initialized
INFO - 2016-07-06 10:37:59 --> Controller Class Initialized
DEBUG - 2016-07-06 10:37:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:37:59 --> Model Class Initialized
INFO - 2016-07-06 10:37:59 --> Model Class Initialized
INFO - 2016-07-06 10:37:59 --> Model Class Initialized
INFO - 2016-07-06 10:37:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:37:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:37:59 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:37:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:39:33 --> Config Class Initialized
INFO - 2016-07-06 10:39:33 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:39:33 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:39:33 --> Utf8 Class Initialized
INFO - 2016-07-06 10:39:33 --> URI Class Initialized
INFO - 2016-07-06 10:39:33 --> Router Class Initialized
INFO - 2016-07-06 10:39:33 --> Output Class Initialized
INFO - 2016-07-06 10:39:33 --> Security Class Initialized
DEBUG - 2016-07-06 10:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:39:33 --> Input Class Initialized
INFO - 2016-07-06 10:39:33 --> Language Class Initialized
INFO - 2016-07-06 10:39:33 --> Loader Class Initialized
INFO - 2016-07-06 10:39:33 --> Helper loaded: url_helper
INFO - 2016-07-06 10:39:33 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:39:33 --> Helper loaded: html_helper
INFO - 2016-07-06 10:39:33 --> Helper loaded: form_helper
INFO - 2016-07-06 10:39:33 --> Helper loaded: file_helper
INFO - 2016-07-06 10:39:33 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:39:33 --> Database Driver Class Initialized
INFO - 2016-07-06 10:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:39:33 --> Form Validation Class Initialized
INFO - 2016-07-06 10:39:33 --> Email Class Initialized
INFO - 2016-07-06 10:39:33 --> Controller Class Initialized
DEBUG - 2016-07-06 10:39:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:39:33 --> Model Class Initialized
INFO - 2016-07-06 10:39:33 --> Model Class Initialized
INFO - 2016-07-06 10:39:33 --> Model Class Initialized
INFO - 2016-07-06 10:39:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:39:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:39:33 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:39:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:39:33 --> Final output sent to browser
DEBUG - 2016-07-06 10:39:33 --> Total execution time: 0.2620
INFO - 2016-07-06 10:40:10 --> Config Class Initialized
INFO - 2016-07-06 10:40:10 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:40:10 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:40:10 --> Utf8 Class Initialized
INFO - 2016-07-06 10:40:10 --> URI Class Initialized
INFO - 2016-07-06 10:40:10 --> Router Class Initialized
INFO - 2016-07-06 10:40:10 --> Output Class Initialized
INFO - 2016-07-06 10:40:10 --> Security Class Initialized
DEBUG - 2016-07-06 10:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:40:10 --> Input Class Initialized
INFO - 2016-07-06 10:40:10 --> Language Class Initialized
INFO - 2016-07-06 10:40:10 --> Loader Class Initialized
INFO - 2016-07-06 10:40:10 --> Helper loaded: url_helper
INFO - 2016-07-06 10:40:10 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:40:10 --> Helper loaded: html_helper
INFO - 2016-07-06 10:40:10 --> Helper loaded: form_helper
INFO - 2016-07-06 10:40:10 --> Helper loaded: file_helper
INFO - 2016-07-06 10:40:10 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:40:10 --> Database Driver Class Initialized
INFO - 2016-07-06 10:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:40:10 --> Form Validation Class Initialized
INFO - 2016-07-06 10:40:10 --> Email Class Initialized
INFO - 2016-07-06 10:40:10 --> Controller Class Initialized
DEBUG - 2016-07-06 10:40:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:40:10 --> Model Class Initialized
INFO - 2016-07-06 10:40:10 --> Model Class Initialized
INFO - 2016-07-06 10:40:10 --> Model Class Initialized
INFO - 2016-07-06 10:40:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:40:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:40:10 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:40:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:41:43 --> Config Class Initialized
INFO - 2016-07-06 10:41:43 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:41:43 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:41:43 --> Utf8 Class Initialized
INFO - 2016-07-06 10:41:43 --> URI Class Initialized
INFO - 2016-07-06 10:41:43 --> Router Class Initialized
INFO - 2016-07-06 10:41:43 --> Output Class Initialized
INFO - 2016-07-06 10:41:43 --> Security Class Initialized
DEBUG - 2016-07-06 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:41:43 --> Input Class Initialized
INFO - 2016-07-06 10:41:43 --> Language Class Initialized
INFO - 2016-07-06 10:41:43 --> Loader Class Initialized
INFO - 2016-07-06 10:41:43 --> Helper loaded: url_helper
INFO - 2016-07-06 10:41:43 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:41:43 --> Helper loaded: html_helper
INFO - 2016-07-06 10:41:43 --> Helper loaded: form_helper
INFO - 2016-07-06 10:41:43 --> Helper loaded: file_helper
INFO - 2016-07-06 10:41:43 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:41:43 --> Database Driver Class Initialized
INFO - 2016-07-06 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:41:43 --> Form Validation Class Initialized
INFO - 2016-07-06 10:41:43 --> Email Class Initialized
INFO - 2016-07-06 10:41:43 --> Controller Class Initialized
DEBUG - 2016-07-06 10:41:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:41:43 --> Model Class Initialized
INFO - 2016-07-06 10:41:43 --> Model Class Initialized
INFO - 2016-07-06 10:41:43 --> Model Class Initialized
INFO - 2016-07-06 10:41:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:41:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:41:43 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:41:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:41:43 --> Final output sent to browser
DEBUG - 2016-07-06 10:41:43 --> Total execution time: 0.2357
INFO - 2016-07-06 10:41:50 --> Config Class Initialized
INFO - 2016-07-06 10:41:50 --> Hooks Class Initialized
DEBUG - 2016-07-06 10:41:50 --> UTF-8 Support Enabled
INFO - 2016-07-06 10:41:50 --> Utf8 Class Initialized
INFO - 2016-07-06 10:41:50 --> URI Class Initialized
INFO - 2016-07-06 10:41:50 --> Router Class Initialized
INFO - 2016-07-06 10:41:50 --> Output Class Initialized
INFO - 2016-07-06 10:41:50 --> Security Class Initialized
DEBUG - 2016-07-06 10:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-06 10:41:50 --> Input Class Initialized
INFO - 2016-07-06 10:41:50 --> Language Class Initialized
INFO - 2016-07-06 10:41:50 --> Loader Class Initialized
INFO - 2016-07-06 10:41:50 --> Helper loaded: url_helper
INFO - 2016-07-06 10:41:50 --> Helper loaded: utils_helper
INFO - 2016-07-06 10:41:50 --> Helper loaded: html_helper
INFO - 2016-07-06 10:41:50 --> Helper loaded: form_helper
INFO - 2016-07-06 10:41:50 --> Helper loaded: file_helper
INFO - 2016-07-06 10:41:50 --> Helper loaded: myemail_helper
INFO - 2016-07-06 10:41:50 --> Database Driver Class Initialized
INFO - 2016-07-06 10:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-06 10:41:50 --> Form Validation Class Initialized
INFO - 2016-07-06 10:41:50 --> Email Class Initialized
INFO - 2016-07-06 10:41:50 --> Controller Class Initialized
DEBUG - 2016-07-06 10:41:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-06 10:41:50 --> Model Class Initialized
INFO - 2016-07-06 10:41:50 --> Model Class Initialized
INFO - 2016-07-06 10:41:50 --> Model Class Initialized
INFO - 2016-07-06 10:41:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-06 10:41:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-06 10:41:50 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-06 10:41:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-06 10:41:51 --> Final output sent to browser
DEBUG - 2016-07-06 10:41:51 --> Total execution time: 0.4950
