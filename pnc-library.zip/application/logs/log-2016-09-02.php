<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-02 08:45:09 --> Config Class Initialized
INFO - 2016-09-02 08:45:09 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:45:09 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:45:09 --> Utf8 Class Initialized
INFO - 2016-09-02 08:45:09 --> URI Class Initialized
INFO - 2016-09-02 08:45:09 --> Router Class Initialized
INFO - 2016-09-02 08:45:09 --> Output Class Initialized
INFO - 2016-09-02 08:45:09 --> Security Class Initialized
DEBUG - 2016-09-02 08:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:45:09 --> Input Class Initialized
INFO - 2016-09-02 08:45:09 --> Language Class Initialized
INFO - 2016-09-02 08:45:09 --> Loader Class Initialized
INFO - 2016-09-02 08:45:09 --> Helper loaded: url_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: html_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: form_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: file_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:45:09 --> Database Driver Class Initialized
INFO - 2016-09-02 08:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:45:09 --> Form Validation Class Initialized
INFO - 2016-09-02 08:45:09 --> Email Class Initialized
INFO - 2016-09-02 08:45:09 --> Controller Class Initialized
INFO - 2016-09-02 08:45:09 --> Model Class Initialized
DEBUG - 2016-09-02 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:45:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-02 08:45:09 --> Config Class Initialized
INFO - 2016-09-02 08:45:09 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:45:09 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:45:09 --> Utf8 Class Initialized
INFO - 2016-09-02 08:45:09 --> URI Class Initialized
INFO - 2016-09-02 08:45:09 --> Router Class Initialized
INFO - 2016-09-02 08:45:09 --> Output Class Initialized
INFO - 2016-09-02 08:45:09 --> Security Class Initialized
DEBUG - 2016-09-02 08:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:45:09 --> Input Class Initialized
INFO - 2016-09-02 08:45:09 --> Language Class Initialized
INFO - 2016-09-02 08:45:09 --> Loader Class Initialized
INFO - 2016-09-02 08:45:09 --> Helper loaded: url_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: html_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: form_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: file_helper
INFO - 2016-09-02 08:45:09 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:45:09 --> Database Driver Class Initialized
INFO - 2016-09-02 08:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:45:09 --> Form Validation Class Initialized
INFO - 2016-09-02 08:45:09 --> Email Class Initialized
INFO - 2016-09-02 08:45:09 --> Controller Class Initialized
DEBUG - 2016-09-02 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-02 08:45:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:45:09 --> Model Class Initialized
INFO - 2016-09-02 08:45:09 --> Model Class Initialized
INFO - 2016-09-02 08:45:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 08:45:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 08:45:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-09-02 08:45:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 08:45:09 --> Final output sent to browser
DEBUG - 2016-09-02 08:45:09 --> Total execution time: 0.3410
INFO - 2016-09-02 08:58:56 --> Config Class Initialized
INFO - 2016-09-02 08:58:56 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:58:56 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:58:56 --> Utf8 Class Initialized
INFO - 2016-09-02 08:58:56 --> URI Class Initialized
INFO - 2016-09-02 08:58:56 --> Router Class Initialized
INFO - 2016-09-02 08:58:56 --> Output Class Initialized
INFO - 2016-09-02 08:58:56 --> Security Class Initialized
DEBUG - 2016-09-02 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:58:56 --> Input Class Initialized
INFO - 2016-09-02 08:58:56 --> Language Class Initialized
INFO - 2016-09-02 08:58:56 --> Loader Class Initialized
INFO - 2016-09-02 08:58:56 --> Helper loaded: url_helper
INFO - 2016-09-02 08:58:56 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:58:56 --> Helper loaded: html_helper
INFO - 2016-09-02 08:58:56 --> Helper loaded: form_helper
INFO - 2016-09-02 08:58:56 --> Helper loaded: file_helper
INFO - 2016-09-02 08:58:56 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:58:56 --> Database Driver Class Initialized
INFO - 2016-09-02 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:58:56 --> Form Validation Class Initialized
INFO - 2016-09-02 08:58:56 --> Email Class Initialized
INFO - 2016-09-02 08:58:56 --> Controller Class Initialized
DEBUG - 2016-09-02 08:58:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:58:56 --> Model Class Initialized
INFO - 2016-09-02 08:58:56 --> Model Class Initialized
INFO - 2016-09-02 08:58:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 08:58:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 08:58:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 08:58:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 08:58:56 --> Final output sent to browser
DEBUG - 2016-09-02 08:58:56 --> Total execution time: 0.2510
INFO - 2016-09-02 08:59:02 --> Config Class Initialized
INFO - 2016-09-02 08:59:02 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:59:02 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:59:02 --> Utf8 Class Initialized
INFO - 2016-09-02 08:59:02 --> URI Class Initialized
INFO - 2016-09-02 08:59:02 --> Router Class Initialized
INFO - 2016-09-02 08:59:02 --> Output Class Initialized
INFO - 2016-09-02 08:59:02 --> Security Class Initialized
DEBUG - 2016-09-02 08:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:59:02 --> Input Class Initialized
INFO - 2016-09-02 08:59:02 --> Language Class Initialized
INFO - 2016-09-02 08:59:02 --> Loader Class Initialized
INFO - 2016-09-02 08:59:02 --> Helper loaded: url_helper
INFO - 2016-09-02 08:59:02 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:59:02 --> Helper loaded: html_helper
INFO - 2016-09-02 08:59:02 --> Helper loaded: form_helper
INFO - 2016-09-02 08:59:02 --> Helper loaded: file_helper
INFO - 2016-09-02 08:59:02 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:59:02 --> Database Driver Class Initialized
INFO - 2016-09-02 08:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:59:02 --> Form Validation Class Initialized
INFO - 2016-09-02 08:59:02 --> Email Class Initialized
INFO - 2016-09-02 08:59:02 --> Controller Class Initialized
DEBUG - 2016-09-02 08:59:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:59:02 --> Model Class Initialized
INFO - 2016-09-02 08:59:02 --> Model Class Initialized
INFO - 2016-09-02 08:59:02 --> Model Class Initialized
INFO - 2016-09-02 08:59:02 --> Model Class Initialized
INFO - 2016-09-02 08:59:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 08:59:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 08:59:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-09-02 08:59:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 08:59:02 --> Final output sent to browser
DEBUG - 2016-09-02 08:59:02 --> Total execution time: 0.2369
INFO - 2016-09-02 08:59:35 --> Config Class Initialized
INFO - 2016-09-02 08:59:35 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:59:35 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:59:35 --> Utf8 Class Initialized
INFO - 2016-09-02 08:59:35 --> URI Class Initialized
INFO - 2016-09-02 08:59:35 --> Router Class Initialized
INFO - 2016-09-02 08:59:35 --> Output Class Initialized
INFO - 2016-09-02 08:59:35 --> Security Class Initialized
DEBUG - 2016-09-02 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:59:35 --> Input Class Initialized
INFO - 2016-09-02 08:59:35 --> Language Class Initialized
INFO - 2016-09-02 08:59:35 --> Loader Class Initialized
INFO - 2016-09-02 08:59:35 --> Helper loaded: url_helper
INFO - 2016-09-02 08:59:35 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:59:35 --> Helper loaded: html_helper
INFO - 2016-09-02 08:59:35 --> Helper loaded: form_helper
INFO - 2016-09-02 08:59:35 --> Helper loaded: file_helper
INFO - 2016-09-02 08:59:35 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:59:35 --> Database Driver Class Initialized
INFO - 2016-09-02 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:59:35 --> Form Validation Class Initialized
INFO - 2016-09-02 08:59:35 --> Email Class Initialized
INFO - 2016-09-02 08:59:35 --> Controller Class Initialized
DEBUG - 2016-09-02 08:59:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:59:35 --> Model Class Initialized
INFO - 2016-09-02 08:59:35 --> Model Class Initialized
INFO - 2016-09-02 08:59:35 --> Model Class Initialized
INFO - 2016-09-02 08:59:35 --> Model Class Initialized
INFO - 2016-09-02 08:59:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 08:59:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 08:59:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-09-02 08:59:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 08:59:44 --> Config Class Initialized
INFO - 2016-09-02 08:59:44 --> Hooks Class Initialized
DEBUG - 2016-09-02 08:59:44 --> UTF-8 Support Enabled
INFO - 2016-09-02 08:59:44 --> Utf8 Class Initialized
INFO - 2016-09-02 08:59:44 --> URI Class Initialized
INFO - 2016-09-02 08:59:44 --> Router Class Initialized
INFO - 2016-09-02 08:59:44 --> Output Class Initialized
INFO - 2016-09-02 08:59:44 --> Security Class Initialized
DEBUG - 2016-09-02 08:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 08:59:44 --> Input Class Initialized
INFO - 2016-09-02 08:59:44 --> Language Class Initialized
INFO - 2016-09-02 08:59:44 --> Loader Class Initialized
INFO - 2016-09-02 08:59:44 --> Helper loaded: url_helper
INFO - 2016-09-02 08:59:44 --> Helper loaded: utils_helper
INFO - 2016-09-02 08:59:44 --> Helper loaded: html_helper
INFO - 2016-09-02 08:59:44 --> Helper loaded: form_helper
INFO - 2016-09-02 08:59:44 --> Helper loaded: file_helper
INFO - 2016-09-02 08:59:44 --> Helper loaded: myemail_helper
INFO - 2016-09-02 08:59:44 --> Database Driver Class Initialized
INFO - 2016-09-02 08:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 08:59:44 --> Form Validation Class Initialized
INFO - 2016-09-02 08:59:44 --> Email Class Initialized
INFO - 2016-09-02 08:59:44 --> Controller Class Initialized
DEBUG - 2016-09-02 08:59:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 08:59:45 --> Model Class Initialized
INFO - 2016-09-02 08:59:45 --> Model Class Initialized
INFO - 2016-09-02 08:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 08:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 08:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-09-02 08:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 08:59:45 --> Final output sent to browser
DEBUG - 2016-09-02 08:59:45 --> Total execution time: 0.2298
INFO - 2016-09-02 09:01:03 --> Config Class Initialized
INFO - 2016-09-02 09:01:03 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:01:03 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:01:03 --> Utf8 Class Initialized
INFO - 2016-09-02 09:01:03 --> URI Class Initialized
INFO - 2016-09-02 09:01:03 --> Router Class Initialized
INFO - 2016-09-02 09:01:04 --> Output Class Initialized
INFO - 2016-09-02 09:01:04 --> Security Class Initialized
DEBUG - 2016-09-02 09:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:01:04 --> Input Class Initialized
INFO - 2016-09-02 09:01:04 --> Language Class Initialized
INFO - 2016-09-02 09:01:04 --> Loader Class Initialized
INFO - 2016-09-02 09:01:04 --> Helper loaded: url_helper
INFO - 2016-09-02 09:01:04 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:01:04 --> Helper loaded: html_helper
INFO - 2016-09-02 09:01:04 --> Helper loaded: form_helper
INFO - 2016-09-02 09:01:04 --> Helper loaded: file_helper
INFO - 2016-09-02 09:01:04 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:01:04 --> Database Driver Class Initialized
INFO - 2016-09-02 09:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:01:04 --> Form Validation Class Initialized
INFO - 2016-09-02 09:01:04 --> Email Class Initialized
INFO - 2016-09-02 09:01:04 --> Controller Class Initialized
DEBUG - 2016-09-02 09:01:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:01:04 --> Model Class Initialized
INFO - 2016-09-02 09:01:04 --> Model Class Initialized
INFO - 2016-09-02 09:01:04 --> Model Class Initialized
INFO - 2016-09-02 09:01:04 --> Model Class Initialized
INFO - 2016-09-02 09:01:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:01:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:01:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-09-02 09:01:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:01:04 --> Final output sent to browser
DEBUG - 2016-09-02 09:01:04 --> Total execution time: 0.2516
INFO - 2016-09-02 09:01:07 --> Config Class Initialized
INFO - 2016-09-02 09:01:07 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:01:07 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:01:07 --> Utf8 Class Initialized
INFO - 2016-09-02 09:01:07 --> URI Class Initialized
INFO - 2016-09-02 09:01:07 --> Router Class Initialized
INFO - 2016-09-02 09:01:07 --> Output Class Initialized
INFO - 2016-09-02 09:01:07 --> Security Class Initialized
DEBUG - 2016-09-02 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:01:07 --> Input Class Initialized
INFO - 2016-09-02 09:01:07 --> Language Class Initialized
INFO - 2016-09-02 09:01:07 --> Loader Class Initialized
INFO - 2016-09-02 09:01:07 --> Helper loaded: url_helper
INFO - 2016-09-02 09:01:07 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:01:07 --> Helper loaded: html_helper
INFO - 2016-09-02 09:01:07 --> Helper loaded: form_helper
INFO - 2016-09-02 09:01:07 --> Helper loaded: file_helper
INFO - 2016-09-02 09:01:07 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:01:07 --> Database Driver Class Initialized
INFO - 2016-09-02 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:01:07 --> Form Validation Class Initialized
INFO - 2016-09-02 09:01:07 --> Email Class Initialized
INFO - 2016-09-02 09:01:07 --> Controller Class Initialized
DEBUG - 2016-09-02 09:01:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:01:07 --> Model Class Initialized
INFO - 2016-09-02 09:01:07 --> Model Class Initialized
INFO - 2016-09-02 09:01:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:01:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:01:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 09:01:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:01:08 --> Final output sent to browser
DEBUG - 2016-09-02 09:01:08 --> Total execution time: 0.2556
INFO - 2016-09-02 09:01:35 --> Config Class Initialized
INFO - 2016-09-02 09:01:35 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:01:35 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:01:35 --> Utf8 Class Initialized
INFO - 2016-09-02 09:01:35 --> URI Class Initialized
INFO - 2016-09-02 09:01:35 --> Router Class Initialized
INFO - 2016-09-02 09:01:35 --> Output Class Initialized
INFO - 2016-09-02 09:01:35 --> Security Class Initialized
DEBUG - 2016-09-02 09:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:01:35 --> Input Class Initialized
INFO - 2016-09-02 09:01:35 --> Language Class Initialized
INFO - 2016-09-02 09:01:35 --> Loader Class Initialized
INFO - 2016-09-02 09:01:35 --> Helper loaded: url_helper
INFO - 2016-09-02 09:01:35 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:01:35 --> Helper loaded: html_helper
INFO - 2016-09-02 09:01:35 --> Helper loaded: form_helper
INFO - 2016-09-02 09:01:35 --> Helper loaded: file_helper
INFO - 2016-09-02 09:01:35 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:01:35 --> Database Driver Class Initialized
INFO - 2016-09-02 09:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:01:35 --> Form Validation Class Initialized
INFO - 2016-09-02 09:01:35 --> Email Class Initialized
INFO - 2016-09-02 09:01:35 --> Controller Class Initialized
DEBUG - 2016-09-02 09:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:01:35 --> Model Class Initialized
INFO - 2016-09-02 09:01:35 --> Model Class Initialized
INFO - 2016-09-02 09:01:35 --> Final output sent to browser
DEBUG - 2016-09-02 09:01:35 --> Total execution time: 0.4592
INFO - 2016-09-02 09:03:10 --> Config Class Initialized
INFO - 2016-09-02 09:03:10 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:10 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:10 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:10 --> URI Class Initialized
INFO - 2016-09-02 09:03:10 --> Router Class Initialized
INFO - 2016-09-02 09:03:10 --> Output Class Initialized
INFO - 2016-09-02 09:03:10 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:10 --> Input Class Initialized
INFO - 2016-09-02 09:03:10 --> Language Class Initialized
INFO - 2016-09-02 09:03:10 --> Loader Class Initialized
INFO - 2016-09-02 09:03:10 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:10 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:10 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:10 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:10 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:10 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:10 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:10 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:10 --> Email Class Initialized
INFO - 2016-09-02 09:03:10 --> Controller Class Initialized
INFO - 2016-09-02 09:03:10 --> Model Class Initialized
INFO - 2016-09-02 09:03:10 --> Model Class Initialized
DEBUG - 2016-09-02 09:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:03:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-09-02 09:03:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:10 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:10 --> Total execution time: 0.2563
INFO - 2016-09-02 09:03:12 --> Config Class Initialized
INFO - 2016-09-02 09:03:12 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:12 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:12 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:12 --> URI Class Initialized
INFO - 2016-09-02 09:03:12 --> Router Class Initialized
INFO - 2016-09-02 09:03:12 --> Output Class Initialized
INFO - 2016-09-02 09:03:12 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:12 --> Input Class Initialized
INFO - 2016-09-02 09:03:12 --> Language Class Initialized
INFO - 2016-09-02 09:03:12 --> Loader Class Initialized
INFO - 2016-09-02 09:03:12 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:12 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:12 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:12 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:12 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:12 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:12 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:12 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:12 --> Email Class Initialized
INFO - 2016-09-02 09:03:12 --> Controller Class Initialized
INFO - 2016-09-02 09:03:12 --> Model Class Initialized
INFO - 2016-09-02 09:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-09-02 09:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:12 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:12 --> Total execution time: 0.2355
INFO - 2016-09-02 09:03:15 --> Config Class Initialized
INFO - 2016-09-02 09:03:15 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:15 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:15 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:15 --> URI Class Initialized
INFO - 2016-09-02 09:03:15 --> Router Class Initialized
INFO - 2016-09-02 09:03:15 --> Output Class Initialized
INFO - 2016-09-02 09:03:15 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:15 --> Input Class Initialized
INFO - 2016-09-02 09:03:15 --> Language Class Initialized
INFO - 2016-09-02 09:03:15 --> Loader Class Initialized
INFO - 2016-09-02 09:03:15 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:15 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:15 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:15 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:15 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:15 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:15 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:15 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:15 --> Email Class Initialized
INFO - 2016-09-02 09:03:15 --> Controller Class Initialized
DEBUG - 2016-09-02 09:03:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:03:15 --> Model Class Initialized
INFO - 2016-09-02 09:03:15 --> Model Class Initialized
INFO - 2016-09-02 09:03:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:15 --> Model Class Initialized
INFO - 2016-09-02 09:03:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-09-02 09:03:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:15 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:15 --> Total execution time: 0.2471
INFO - 2016-09-02 09:03:46 --> Config Class Initialized
INFO - 2016-09-02 09:03:46 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:46 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:46 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:46 --> URI Class Initialized
INFO - 2016-09-02 09:03:46 --> Router Class Initialized
INFO - 2016-09-02 09:03:46 --> Output Class Initialized
INFO - 2016-09-02 09:03:46 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:46 --> Input Class Initialized
INFO - 2016-09-02 09:03:46 --> Language Class Initialized
INFO - 2016-09-02 09:03:46 --> Loader Class Initialized
INFO - 2016-09-02 09:03:46 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:46 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:46 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:46 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:46 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:46 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:46 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:46 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:46 --> Email Class Initialized
INFO - 2016-09-02 09:03:46 --> Controller Class Initialized
DEBUG - 2016-09-02 09:03:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:03:46 --> Model Class Initialized
INFO - 2016-09-02 09:03:46 --> Model Class Initialized
INFO - 2016-09-02 09:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-09-02 09:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:46 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:46 --> Total execution time: 0.2454
INFO - 2016-09-02 09:03:47 --> Config Class Initialized
INFO - 2016-09-02 09:03:47 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:47 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:47 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:48 --> URI Class Initialized
INFO - 2016-09-02 09:03:48 --> Router Class Initialized
INFO - 2016-09-02 09:03:48 --> Output Class Initialized
INFO - 2016-09-02 09:03:48 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:48 --> Input Class Initialized
INFO - 2016-09-02 09:03:48 --> Language Class Initialized
INFO - 2016-09-02 09:03:48 --> Loader Class Initialized
INFO - 2016-09-02 09:03:48 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:48 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:48 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:48 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:48 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:48 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:48 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:48 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:48 --> Email Class Initialized
INFO - 2016-09-02 09:03:48 --> Controller Class Initialized
INFO - 2016-09-02 09:03:48 --> Model Class Initialized
INFO - 2016-09-02 09:03:48 --> Model Class Initialized
INFO - 2016-09-02 09:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-09-02 09:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:48 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:48 --> Total execution time: 0.2502
INFO - 2016-09-02 09:03:54 --> Config Class Initialized
INFO - 2016-09-02 09:03:54 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:03:54 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:03:54 --> Utf8 Class Initialized
INFO - 2016-09-02 09:03:54 --> URI Class Initialized
INFO - 2016-09-02 09:03:54 --> Router Class Initialized
INFO - 2016-09-02 09:03:54 --> Output Class Initialized
INFO - 2016-09-02 09:03:54 --> Security Class Initialized
DEBUG - 2016-09-02 09:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:03:54 --> Input Class Initialized
INFO - 2016-09-02 09:03:54 --> Language Class Initialized
INFO - 2016-09-02 09:03:54 --> Loader Class Initialized
INFO - 2016-09-02 09:03:54 --> Helper loaded: url_helper
INFO - 2016-09-02 09:03:54 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:03:54 --> Helper loaded: html_helper
INFO - 2016-09-02 09:03:54 --> Helper loaded: form_helper
INFO - 2016-09-02 09:03:55 --> Helper loaded: file_helper
INFO - 2016-09-02 09:03:55 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:03:55 --> Database Driver Class Initialized
INFO - 2016-09-02 09:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:03:55 --> Form Validation Class Initialized
INFO - 2016-09-02 09:03:55 --> Email Class Initialized
INFO - 2016-09-02 09:03:55 --> Controller Class Initialized
INFO - 2016-09-02 09:03:55 --> Model Class Initialized
INFO - 2016-09-02 09:03:55 --> Model Class Initialized
INFO - 2016-09-02 09:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-09-02 09:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:03:55 --> Final output sent to browser
DEBUG - 2016-09-02 09:03:55 --> Total execution time: 0.2914
INFO - 2016-09-02 09:05:27 --> Config Class Initialized
INFO - 2016-09-02 09:05:27 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:05:27 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:05:27 --> Utf8 Class Initialized
INFO - 2016-09-02 09:05:27 --> URI Class Initialized
INFO - 2016-09-02 09:05:27 --> Router Class Initialized
INFO - 2016-09-02 09:05:27 --> Output Class Initialized
INFO - 2016-09-02 09:05:27 --> Security Class Initialized
DEBUG - 2016-09-02 09:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:05:27 --> Input Class Initialized
INFO - 2016-09-02 09:05:27 --> Language Class Initialized
INFO - 2016-09-02 09:05:27 --> Loader Class Initialized
INFO - 2016-09-02 09:05:27 --> Helper loaded: url_helper
INFO - 2016-09-02 09:05:27 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:05:27 --> Helper loaded: html_helper
INFO - 2016-09-02 09:05:27 --> Helper loaded: form_helper
INFO - 2016-09-02 09:05:27 --> Helper loaded: file_helper
INFO - 2016-09-02 09:05:27 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:05:27 --> Database Driver Class Initialized
INFO - 2016-09-02 09:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:05:27 --> Form Validation Class Initialized
INFO - 2016-09-02 09:05:27 --> Email Class Initialized
INFO - 2016-09-02 09:05:27 --> Controller Class Initialized
DEBUG - 2016-09-02 09:05:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:05:27 --> Model Class Initialized
INFO - 2016-09-02 09:05:27 --> Model Class Initialized
INFO - 2016-09-02 09:05:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:05:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:05:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-09-02 09:05:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:05:27 --> Final output sent to browser
DEBUG - 2016-09-02 09:05:27 --> Total execution time: 0.2712
INFO - 2016-09-02 09:07:26 --> Config Class Initialized
INFO - 2016-09-02 09:07:26 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:07:26 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:07:26 --> Utf8 Class Initialized
INFO - 2016-09-02 09:07:26 --> URI Class Initialized
INFO - 2016-09-02 09:07:26 --> Router Class Initialized
INFO - 2016-09-02 09:07:26 --> Output Class Initialized
INFO - 2016-09-02 09:07:26 --> Security Class Initialized
DEBUG - 2016-09-02 09:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:07:26 --> Input Class Initialized
INFO - 2016-09-02 09:07:26 --> Language Class Initialized
INFO - 2016-09-02 09:07:26 --> Loader Class Initialized
INFO - 2016-09-02 09:07:26 --> Helper loaded: url_helper
INFO - 2016-09-02 09:07:26 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:07:26 --> Helper loaded: html_helper
INFO - 2016-09-02 09:07:26 --> Helper loaded: form_helper
INFO - 2016-09-02 09:07:26 --> Helper loaded: file_helper
INFO - 2016-09-02 09:07:26 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:07:26 --> Database Driver Class Initialized
INFO - 2016-09-02 09:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:07:26 --> Form Validation Class Initialized
INFO - 2016-09-02 09:07:26 --> Email Class Initialized
INFO - 2016-09-02 09:07:26 --> Controller Class Initialized
DEBUG - 2016-09-02 09:07:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:07:26 --> Model Class Initialized
INFO - 2016-09-02 09:07:26 --> Model Class Initialized
INFO - 2016-09-02 09:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 09:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:07:26 --> Final output sent to browser
DEBUG - 2016-09-02 09:07:26 --> Total execution time: 0.2745
INFO - 2016-09-02 09:07:39 --> Config Class Initialized
INFO - 2016-09-02 09:07:39 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:07:39 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:07:39 --> Utf8 Class Initialized
INFO - 2016-09-02 09:07:39 --> URI Class Initialized
INFO - 2016-09-02 09:07:39 --> Router Class Initialized
INFO - 2016-09-02 09:07:39 --> Output Class Initialized
INFO - 2016-09-02 09:07:39 --> Security Class Initialized
DEBUG - 2016-09-02 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:07:39 --> Input Class Initialized
INFO - 2016-09-02 09:07:39 --> Language Class Initialized
INFO - 2016-09-02 09:07:39 --> Loader Class Initialized
INFO - 2016-09-02 09:07:39 --> Helper loaded: url_helper
INFO - 2016-09-02 09:07:39 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:07:39 --> Helper loaded: html_helper
INFO - 2016-09-02 09:07:39 --> Helper loaded: form_helper
INFO - 2016-09-02 09:07:39 --> Helper loaded: file_helper
INFO - 2016-09-02 09:07:39 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:07:39 --> Database Driver Class Initialized
INFO - 2016-09-02 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:07:39 --> Form Validation Class Initialized
INFO - 2016-09-02 09:07:39 --> Email Class Initialized
INFO - 2016-09-02 09:07:39 --> Controller Class Initialized
DEBUG - 2016-09-02 09:07:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:07:40 --> Model Class Initialized
INFO - 2016-09-02 09:07:40 --> Model Class Initialized
INFO - 2016-09-02 09:07:40 --> Model Class Initialized
INFO - 2016-09-02 09:07:40 --> Model Class Initialized
INFO - 2016-09-02 09:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-09-02 09:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:07:40 --> Final output sent to browser
DEBUG - 2016-09-02 09:07:40 --> Total execution time: 0.2776
INFO - 2016-09-02 09:08:36 --> Config Class Initialized
INFO - 2016-09-02 09:08:36 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:08:36 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:08:36 --> Utf8 Class Initialized
INFO - 2016-09-02 09:08:36 --> URI Class Initialized
INFO - 2016-09-02 09:08:36 --> Router Class Initialized
INFO - 2016-09-02 09:08:36 --> Output Class Initialized
INFO - 2016-09-02 09:08:36 --> Security Class Initialized
DEBUG - 2016-09-02 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:08:36 --> Input Class Initialized
INFO - 2016-09-02 09:08:36 --> Language Class Initialized
INFO - 2016-09-02 09:08:36 --> Loader Class Initialized
INFO - 2016-09-02 09:08:36 --> Helper loaded: url_helper
INFO - 2016-09-02 09:08:36 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:08:36 --> Helper loaded: html_helper
INFO - 2016-09-02 09:08:36 --> Helper loaded: form_helper
INFO - 2016-09-02 09:08:36 --> Helper loaded: file_helper
INFO - 2016-09-02 09:08:36 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:08:36 --> Database Driver Class Initialized
INFO - 2016-09-02 09:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:08:36 --> Form Validation Class Initialized
INFO - 2016-09-02 09:08:36 --> Email Class Initialized
INFO - 2016-09-02 09:08:36 --> Controller Class Initialized
DEBUG - 2016-09-02 09:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:08:36 --> Model Class Initialized
INFO - 2016-09-02 09:08:36 --> Model Class Initialized
INFO - 2016-09-02 09:08:36 --> Helper loaded: download_helper
INFO - 2016-09-02 09:08:36 --> Config Class Initialized
INFO - 2016-09-02 09:08:36 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:08:36 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:08:36 --> Utf8 Class Initialized
INFO - 2016-09-02 09:08:36 --> URI Class Initialized
INFO - 2016-09-02 09:08:36 --> Router Class Initialized
INFO - 2016-09-02 09:08:36 --> Output Class Initialized
INFO - 2016-09-02 09:08:36 --> Security Class Initialized
DEBUG - 2016-09-02 09:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:08:36 --> Input Class Initialized
INFO - 2016-09-02 09:08:36 --> Language Class Initialized
ERROR - 2016-09-02 09:08:36 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-09-02 09:08:36 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 389
INFO - 2016-09-02 09:08:46 --> Config Class Initialized
INFO - 2016-09-02 09:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:08:46 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:08:46 --> Utf8 Class Initialized
INFO - 2016-09-02 09:08:46 --> URI Class Initialized
INFO - 2016-09-02 09:08:46 --> Router Class Initialized
INFO - 2016-09-02 09:08:46 --> Output Class Initialized
INFO - 2016-09-02 09:08:46 --> Security Class Initialized
DEBUG - 2016-09-02 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:08:46 --> Input Class Initialized
INFO - 2016-09-02 09:08:46 --> Language Class Initialized
INFO - 2016-09-02 09:08:46 --> Loader Class Initialized
INFO - 2016-09-02 09:08:46 --> Helper loaded: url_helper
INFO - 2016-09-02 09:08:46 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:08:46 --> Helper loaded: html_helper
INFO - 2016-09-02 09:08:46 --> Helper loaded: form_helper
INFO - 2016-09-02 09:08:46 --> Helper loaded: file_helper
INFO - 2016-09-02 09:08:46 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:08:46 --> Database Driver Class Initialized
INFO - 2016-09-02 09:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:08:46 --> Form Validation Class Initialized
INFO - 2016-09-02 09:08:46 --> Email Class Initialized
INFO - 2016-09-02 09:08:46 --> Controller Class Initialized
DEBUG - 2016-09-02 09:08:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:08:46 --> Model Class Initialized
INFO - 2016-09-02 09:08:46 --> Model Class Initialized
INFO - 2016-09-02 09:08:46 --> Helper loaded: download_helper
INFO - 2016-09-02 09:08:46 --> Config Class Initialized
INFO - 2016-09-02 09:08:46 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:08:46 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:08:46 --> Utf8 Class Initialized
INFO - 2016-09-02 09:08:46 --> URI Class Initialized
INFO - 2016-09-02 09:08:46 --> Router Class Initialized
INFO - 2016-09-02 09:08:46 --> Output Class Initialized
INFO - 2016-09-02 09:08:46 --> Security Class Initialized
DEBUG - 2016-09-02 09:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:08:46 --> Input Class Initialized
INFO - 2016-09-02 09:08:46 --> Language Class Initialized
ERROR - 2016-09-02 09:08:46 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-09-02 09:08:46 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 389
INFO - 2016-09-02 09:09:42 --> Config Class Initialized
INFO - 2016-09-02 09:09:42 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:09:42 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:09:42 --> Utf8 Class Initialized
INFO - 2016-09-02 09:09:42 --> URI Class Initialized
INFO - 2016-09-02 09:09:42 --> Router Class Initialized
INFO - 2016-09-02 09:09:42 --> Output Class Initialized
INFO - 2016-09-02 09:09:42 --> Security Class Initialized
DEBUG - 2016-09-02 09:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:09:42 --> Input Class Initialized
INFO - 2016-09-02 09:09:42 --> Language Class Initialized
INFO - 2016-09-02 09:09:42 --> Loader Class Initialized
INFO - 2016-09-02 09:09:42 --> Helper loaded: url_helper
INFO - 2016-09-02 09:09:42 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:09:42 --> Helper loaded: html_helper
INFO - 2016-09-02 09:09:42 --> Helper loaded: form_helper
INFO - 2016-09-02 09:09:42 --> Helper loaded: file_helper
INFO - 2016-09-02 09:09:42 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:09:42 --> Database Driver Class Initialized
INFO - 2016-09-02 09:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:09:42 --> Form Validation Class Initialized
INFO - 2016-09-02 09:09:42 --> Email Class Initialized
INFO - 2016-09-02 09:09:42 --> Controller Class Initialized
DEBUG - 2016-09-02 09:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:09:42 --> Model Class Initialized
INFO - 2016-09-02 09:09:42 --> Model Class Initialized
INFO - 2016-09-02 09:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 09:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:09:42 --> Final output sent to browser
DEBUG - 2016-09-02 09:09:42 --> Total execution time: 0.2706
INFO - 2016-09-02 09:09:47 --> Config Class Initialized
INFO - 2016-09-02 09:09:47 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:09:47 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:09:47 --> Utf8 Class Initialized
INFO - 2016-09-02 09:09:47 --> URI Class Initialized
INFO - 2016-09-02 09:09:47 --> Router Class Initialized
INFO - 2016-09-02 09:09:47 --> Output Class Initialized
INFO - 2016-09-02 09:09:47 --> Security Class Initialized
DEBUG - 2016-09-02 09:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:09:47 --> Input Class Initialized
INFO - 2016-09-02 09:09:47 --> Language Class Initialized
INFO - 2016-09-02 09:09:47 --> Loader Class Initialized
INFO - 2016-09-02 09:09:47 --> Helper loaded: url_helper
INFO - 2016-09-02 09:09:47 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:09:47 --> Helper loaded: html_helper
INFO - 2016-09-02 09:09:47 --> Helper loaded: form_helper
INFO - 2016-09-02 09:09:47 --> Helper loaded: file_helper
INFO - 2016-09-02 09:09:47 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:09:48 --> Database Driver Class Initialized
INFO - 2016-09-02 09:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:09:48 --> Form Validation Class Initialized
INFO - 2016-09-02 09:09:48 --> Email Class Initialized
INFO - 2016-09-02 09:09:48 --> Controller Class Initialized
INFO - 2016-09-02 09:09:48 --> Model Class Initialized
INFO - 2016-09-02 09:09:48 --> Config Class Initialized
INFO - 2016-09-02 09:09:48 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:09:48 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:09:48 --> Utf8 Class Initialized
INFO - 2016-09-02 09:09:48 --> URI Class Initialized
INFO - 2016-09-02 09:09:48 --> Router Class Initialized
INFO - 2016-09-02 09:09:48 --> Output Class Initialized
INFO - 2016-09-02 09:09:48 --> Security Class Initialized
DEBUG - 2016-09-02 09:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:09:48 --> Input Class Initialized
INFO - 2016-09-02 09:09:48 --> Language Class Initialized
INFO - 2016-09-02 09:09:48 --> Loader Class Initialized
INFO - 2016-09-02 09:09:48 --> Helper loaded: url_helper
INFO - 2016-09-02 09:09:48 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:09:48 --> Helper loaded: html_helper
INFO - 2016-09-02 09:09:48 --> Helper loaded: form_helper
INFO - 2016-09-02 09:09:48 --> Helper loaded: file_helper
INFO - 2016-09-02 09:09:48 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:09:48 --> Database Driver Class Initialized
INFO - 2016-09-02 09:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:09:48 --> Form Validation Class Initialized
INFO - 2016-09-02 09:09:48 --> Email Class Initialized
INFO - 2016-09-02 09:09:48 --> Controller Class Initialized
INFO - 2016-09-02 09:09:48 --> Model Class Initialized
DEBUG - 2016-09-02 09:09:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-09-02 09:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-09-02 09:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:09:48 --> Final output sent to browser
DEBUG - 2016-09-02 09:09:48 --> Total execution time: 0.3426
INFO - 2016-09-02 09:09:52 --> Config Class Initialized
INFO - 2016-09-02 09:09:52 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:09:52 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:09:52 --> Utf8 Class Initialized
INFO - 2016-09-02 09:09:52 --> URI Class Initialized
INFO - 2016-09-02 09:09:52 --> Router Class Initialized
INFO - 2016-09-02 09:09:52 --> Output Class Initialized
INFO - 2016-09-02 09:09:52 --> Security Class Initialized
DEBUG - 2016-09-02 09:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:09:52 --> Input Class Initialized
INFO - 2016-09-02 09:09:52 --> Language Class Initialized
ERROR - 2016-09-02 09:09:52 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-09-02 09:09:55 --> Config Class Initialized
INFO - 2016-09-02 09:09:55 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:09:55 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:09:55 --> Utf8 Class Initialized
INFO - 2016-09-02 09:09:55 --> URI Class Initialized
INFO - 2016-09-02 09:09:55 --> Router Class Initialized
INFO - 2016-09-02 09:09:55 --> Output Class Initialized
INFO - 2016-09-02 09:09:55 --> Security Class Initialized
DEBUG - 2016-09-02 09:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:09:55 --> Input Class Initialized
INFO - 2016-09-02 09:09:55 --> Language Class Initialized
INFO - 2016-09-02 09:09:55 --> Loader Class Initialized
INFO - 2016-09-02 09:09:55 --> Helper loaded: url_helper
INFO - 2016-09-02 09:09:56 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:09:56 --> Helper loaded: html_helper
INFO - 2016-09-02 09:09:56 --> Helper loaded: form_helper
INFO - 2016-09-02 09:09:56 --> Helper loaded: file_helper
INFO - 2016-09-02 09:09:56 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:09:56 --> Database Driver Class Initialized
INFO - 2016-09-02 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:09:56 --> Form Validation Class Initialized
INFO - 2016-09-02 09:09:56 --> Email Class Initialized
INFO - 2016-09-02 09:09:56 --> Controller Class Initialized
INFO - 2016-09-02 09:09:56 --> Model Class Initialized
DEBUG - 2016-09-02 09:09:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:09:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-09-02 09:09:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:09:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-09-02 09:09:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:09:56 --> Final output sent to browser
DEBUG - 2016-09-02 09:09:56 --> Total execution time: 0.2815
INFO - 2016-09-02 09:11:39 --> Config Class Initialized
INFO - 2016-09-02 09:11:39 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:11:39 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:11:39 --> Utf8 Class Initialized
INFO - 2016-09-02 09:11:39 --> URI Class Initialized
INFO - 2016-09-02 09:11:39 --> Router Class Initialized
INFO - 2016-09-02 09:11:39 --> Output Class Initialized
INFO - 2016-09-02 09:11:39 --> Security Class Initialized
DEBUG - 2016-09-02 09:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:11:39 --> Input Class Initialized
INFO - 2016-09-02 09:11:39 --> Language Class Initialized
INFO - 2016-09-02 09:11:39 --> Loader Class Initialized
INFO - 2016-09-02 09:11:39 --> Helper loaded: url_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: html_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: form_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: file_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:11:39 --> Database Driver Class Initialized
INFO - 2016-09-02 09:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:11:39 --> Form Validation Class Initialized
INFO - 2016-09-02 09:11:39 --> Email Class Initialized
INFO - 2016-09-02 09:11:39 --> Controller Class Initialized
INFO - 2016-09-02 09:11:39 --> Model Class Initialized
DEBUG - 2016-09-02 09:11:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:11:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-09-02 09:11:39 --> Config Class Initialized
INFO - 2016-09-02 09:11:39 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:11:39 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:11:39 --> Utf8 Class Initialized
INFO - 2016-09-02 09:11:39 --> URI Class Initialized
INFO - 2016-09-02 09:11:39 --> Router Class Initialized
INFO - 2016-09-02 09:11:39 --> Output Class Initialized
INFO - 2016-09-02 09:11:39 --> Security Class Initialized
DEBUG - 2016-09-02 09:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:11:39 --> Input Class Initialized
INFO - 2016-09-02 09:11:39 --> Language Class Initialized
INFO - 2016-09-02 09:11:39 --> Loader Class Initialized
INFO - 2016-09-02 09:11:39 --> Helper loaded: url_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: html_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: form_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: file_helper
INFO - 2016-09-02 09:11:39 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:11:39 --> Database Driver Class Initialized
INFO - 2016-09-02 09:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:11:39 --> Form Validation Class Initialized
INFO - 2016-09-02 09:11:39 --> Email Class Initialized
INFO - 2016-09-02 09:11:39 --> Controller Class Initialized
DEBUG - 2016-09-02 09:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-02 09:11:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:11:39 --> Model Class Initialized
INFO - 2016-09-02 09:11:39 --> Model Class Initialized
INFO - 2016-09-02 09:11:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:11:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:11:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-09-02 09:11:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:11:39 --> Final output sent to browser
DEBUG - 2016-09-02 09:11:39 --> Total execution time: 0.3186
INFO - 2016-09-02 09:11:43 --> Config Class Initialized
INFO - 2016-09-02 09:11:43 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:11:43 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:11:44 --> Utf8 Class Initialized
INFO - 2016-09-02 09:11:44 --> URI Class Initialized
INFO - 2016-09-02 09:11:44 --> Router Class Initialized
INFO - 2016-09-02 09:11:44 --> Output Class Initialized
INFO - 2016-09-02 09:11:44 --> Security Class Initialized
DEBUG - 2016-09-02 09:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:11:44 --> Input Class Initialized
INFO - 2016-09-02 09:11:44 --> Language Class Initialized
INFO - 2016-09-02 09:11:44 --> Loader Class Initialized
INFO - 2016-09-02 09:11:44 --> Helper loaded: url_helper
INFO - 2016-09-02 09:11:44 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:11:44 --> Helper loaded: html_helper
INFO - 2016-09-02 09:11:44 --> Helper loaded: form_helper
INFO - 2016-09-02 09:11:44 --> Helper loaded: file_helper
INFO - 2016-09-02 09:11:44 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:11:44 --> Database Driver Class Initialized
INFO - 2016-09-02 09:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:11:44 --> Form Validation Class Initialized
INFO - 2016-09-02 09:11:44 --> Email Class Initialized
INFO - 2016-09-02 09:11:44 --> Controller Class Initialized
DEBUG - 2016-09-02 09:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-09-02 09:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:11:44 --> Model Class Initialized
INFO - 2016-09-02 09:11:44 --> Model Class Initialized
INFO - 2016-09-02 09:11:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:11:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:11:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/users.php
INFO - 2016-09-02 09:11:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:11:44 --> Final output sent to browser
DEBUG - 2016-09-02 09:11:44 --> Total execution time: 0.2852
INFO - 2016-09-02 09:11:48 --> Config Class Initialized
INFO - 2016-09-02 09:11:48 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:11:48 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:11:48 --> Utf8 Class Initialized
INFO - 2016-09-02 09:11:48 --> URI Class Initialized
INFO - 2016-09-02 09:11:48 --> Router Class Initialized
INFO - 2016-09-02 09:11:48 --> Output Class Initialized
INFO - 2016-09-02 09:11:48 --> Security Class Initialized
DEBUG - 2016-09-02 09:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:11:48 --> Input Class Initialized
INFO - 2016-09-02 09:11:48 --> Language Class Initialized
INFO - 2016-09-02 09:11:48 --> Loader Class Initialized
INFO - 2016-09-02 09:11:48 --> Helper loaded: url_helper
INFO - 2016-09-02 09:11:48 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:11:48 --> Helper loaded: html_helper
INFO - 2016-09-02 09:11:48 --> Helper loaded: form_helper
INFO - 2016-09-02 09:11:48 --> Helper loaded: file_helper
INFO - 2016-09-02 09:11:48 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:11:48 --> Database Driver Class Initialized
INFO - 2016-09-02 09:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:11:48 --> Form Validation Class Initialized
INFO - 2016-09-02 09:11:48 --> Email Class Initialized
INFO - 2016-09-02 09:11:48 --> Controller Class Initialized
INFO - 2016-09-02 09:11:48 --> Model Class Initialized
INFO - 2016-09-02 09:11:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:11:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:11:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-09-02 09:11:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:11:48 --> Final output sent to browser
DEBUG - 2016-09-02 09:11:48 --> Total execution time: 0.2615
INFO - 2016-09-02 09:11:52 --> Config Class Initialized
INFO - 2016-09-02 09:11:52 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:11:52 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:11:52 --> Utf8 Class Initialized
INFO - 2016-09-02 09:11:52 --> URI Class Initialized
INFO - 2016-09-02 09:11:52 --> Router Class Initialized
INFO - 2016-09-02 09:11:52 --> Output Class Initialized
INFO - 2016-09-02 09:11:52 --> Security Class Initialized
DEBUG - 2016-09-02 09:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:11:52 --> Input Class Initialized
INFO - 2016-09-02 09:11:52 --> Language Class Initialized
INFO - 2016-09-02 09:11:52 --> Loader Class Initialized
INFO - 2016-09-02 09:11:52 --> Helper loaded: url_helper
INFO - 2016-09-02 09:11:52 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:11:52 --> Helper loaded: html_helper
INFO - 2016-09-02 09:11:52 --> Helper loaded: form_helper
INFO - 2016-09-02 09:11:52 --> Helper loaded: file_helper
INFO - 2016-09-02 09:11:52 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:11:52 --> Database Driver Class Initialized
INFO - 2016-09-02 09:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:11:52 --> Form Validation Class Initialized
INFO - 2016-09-02 09:11:52 --> Email Class Initialized
INFO - 2016-09-02 09:11:52 --> Controller Class Initialized
DEBUG - 2016-09-02 09:11:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:11:52 --> Model Class Initialized
INFO - 2016-09-02 09:11:52 --> Model Class Initialized
INFO - 2016-09-02 09:11:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:11:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:11:52 --> Model Class Initialized
INFO - 2016-09-02 09:11:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-09-02 09:11:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:11:52 --> Final output sent to browser
DEBUG - 2016-09-02 09:11:52 --> Total execution time: 0.2814
INFO - 2016-09-02 09:14:45 --> Config Class Initialized
INFO - 2016-09-02 09:14:45 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:14:45 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:14:45 --> Utf8 Class Initialized
INFO - 2016-09-02 09:14:45 --> URI Class Initialized
INFO - 2016-09-02 09:14:45 --> Router Class Initialized
INFO - 2016-09-02 09:14:45 --> Output Class Initialized
INFO - 2016-09-02 09:14:45 --> Security Class Initialized
DEBUG - 2016-09-02 09:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:14:45 --> Input Class Initialized
INFO - 2016-09-02 09:14:45 --> Language Class Initialized
INFO - 2016-09-02 09:14:45 --> Loader Class Initialized
INFO - 2016-09-02 09:14:45 --> Helper loaded: url_helper
INFO - 2016-09-02 09:14:45 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:14:45 --> Helper loaded: html_helper
INFO - 2016-09-02 09:14:45 --> Helper loaded: form_helper
INFO - 2016-09-02 09:14:45 --> Helper loaded: file_helper
INFO - 2016-09-02 09:14:45 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:14:45 --> Database Driver Class Initialized
INFO - 2016-09-02 09:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:14:45 --> Form Validation Class Initialized
INFO - 2016-09-02 09:14:45 --> Email Class Initialized
INFO - 2016-09-02 09:14:45 --> Controller Class Initialized
DEBUG - 2016-09-02 09:14:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:14:45 --> Model Class Initialized
INFO - 2016-09-02 09:14:45 --> Model Class Initialized
INFO - 2016-09-02 09:14:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:14:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:14:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-09-02 09:14:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:14:45 --> Final output sent to browser
DEBUG - 2016-09-02 09:14:45 --> Total execution time: 0.2881
INFO - 2016-09-02 09:14:49 --> Config Class Initialized
INFO - 2016-09-02 09:14:49 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:14:49 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:14:49 --> Utf8 Class Initialized
INFO - 2016-09-02 09:14:49 --> URI Class Initialized
INFO - 2016-09-02 09:14:49 --> Router Class Initialized
INFO - 2016-09-02 09:14:49 --> Output Class Initialized
INFO - 2016-09-02 09:14:49 --> Security Class Initialized
DEBUG - 2016-09-02 09:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:14:49 --> Input Class Initialized
INFO - 2016-09-02 09:14:49 --> Language Class Initialized
INFO - 2016-09-02 09:14:49 --> Loader Class Initialized
INFO - 2016-09-02 09:14:49 --> Helper loaded: url_helper
INFO - 2016-09-02 09:14:49 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:14:49 --> Helper loaded: html_helper
INFO - 2016-09-02 09:14:49 --> Helper loaded: form_helper
INFO - 2016-09-02 09:14:49 --> Helper loaded: file_helper
INFO - 2016-09-02 09:14:49 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:14:49 --> Database Driver Class Initialized
INFO - 2016-09-02 09:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:14:49 --> Form Validation Class Initialized
INFO - 2016-09-02 09:14:49 --> Email Class Initialized
INFO - 2016-09-02 09:14:49 --> Controller Class Initialized
DEBUG - 2016-09-02 09:14:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:14:49 --> Model Class Initialized
INFO - 2016-09-02 09:14:49 --> Model Class Initialized
INFO - 2016-09-02 09:14:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:14:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:14:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 09:14:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:14:49 --> Final output sent to browser
DEBUG - 2016-09-02 09:14:49 --> Total execution time: 0.2784
INFO - 2016-09-02 09:14:52 --> Config Class Initialized
INFO - 2016-09-02 09:14:52 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:14:52 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:14:52 --> Utf8 Class Initialized
INFO - 2016-09-02 09:14:52 --> URI Class Initialized
INFO - 2016-09-02 09:14:52 --> Router Class Initialized
INFO - 2016-09-02 09:14:52 --> Output Class Initialized
INFO - 2016-09-02 09:14:52 --> Security Class Initialized
DEBUG - 2016-09-02 09:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:14:52 --> Input Class Initialized
INFO - 2016-09-02 09:14:52 --> Language Class Initialized
INFO - 2016-09-02 09:14:52 --> Loader Class Initialized
INFO - 2016-09-02 09:14:52 --> Helper loaded: url_helper
INFO - 2016-09-02 09:14:52 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:14:52 --> Helper loaded: html_helper
INFO - 2016-09-02 09:14:52 --> Helper loaded: form_helper
INFO - 2016-09-02 09:14:52 --> Helper loaded: file_helper
INFO - 2016-09-02 09:14:52 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:14:52 --> Database Driver Class Initialized
INFO - 2016-09-02 09:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:14:52 --> Form Validation Class Initialized
INFO - 2016-09-02 09:14:52 --> Email Class Initialized
INFO - 2016-09-02 09:14:52 --> Controller Class Initialized
DEBUG - 2016-09-02 09:14:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:14:52 --> Model Class Initialized
INFO - 2016-09-02 09:14:52 --> Model Class Initialized
INFO - 2016-09-02 09:14:52 --> Model Class Initialized
INFO - 2016-09-02 09:14:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:14:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:14:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-09-02 09:14:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:14:52 --> Final output sent to browser
DEBUG - 2016-09-02 09:14:52 --> Total execution time: 0.2942
INFO - 2016-09-02 09:24:52 --> Config Class Initialized
INFO - 2016-09-02 09:24:52 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:24:52 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:24:52 --> Utf8 Class Initialized
INFO - 2016-09-02 09:24:52 --> URI Class Initialized
INFO - 2016-09-02 09:24:52 --> Router Class Initialized
INFO - 2016-09-02 09:24:52 --> Output Class Initialized
INFO - 2016-09-02 09:24:52 --> Security Class Initialized
DEBUG - 2016-09-02 09:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:24:52 --> Input Class Initialized
INFO - 2016-09-02 09:24:52 --> Language Class Initialized
INFO - 2016-09-02 09:24:52 --> Loader Class Initialized
INFO - 2016-09-02 09:24:52 --> Helper loaded: url_helper
INFO - 2016-09-02 09:24:52 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:24:52 --> Helper loaded: html_helper
INFO - 2016-09-02 09:24:52 --> Helper loaded: form_helper
INFO - 2016-09-02 09:24:52 --> Helper loaded: file_helper
INFO - 2016-09-02 09:24:52 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:24:52 --> Database Driver Class Initialized
INFO - 2016-09-02 09:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:24:52 --> Form Validation Class Initialized
INFO - 2016-09-02 09:24:52 --> Email Class Initialized
INFO - 2016-09-02 09:24:52 --> Controller Class Initialized
DEBUG - 2016-09-02 09:24:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:24:52 --> Model Class Initialized
INFO - 2016-09-02 09:24:52 --> Model Class Initialized
INFO - 2016-09-02 09:24:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:24:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:24:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-09-02 09:24:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:24:52 --> Final output sent to browser
DEBUG - 2016-09-02 09:24:52 --> Total execution time: 0.3697
INFO - 2016-09-02 09:24:59 --> Config Class Initialized
INFO - 2016-09-02 09:24:59 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:24:59 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:24:59 --> Utf8 Class Initialized
INFO - 2016-09-02 09:24:59 --> URI Class Initialized
INFO - 2016-09-02 09:24:59 --> Router Class Initialized
INFO - 2016-09-02 09:24:59 --> Output Class Initialized
INFO - 2016-09-02 09:24:59 --> Security Class Initialized
DEBUG - 2016-09-02 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:24:59 --> Input Class Initialized
INFO - 2016-09-02 09:24:59 --> Language Class Initialized
INFO - 2016-09-02 09:24:59 --> Loader Class Initialized
INFO - 2016-09-02 09:24:59 --> Helper loaded: url_helper
INFO - 2016-09-02 09:24:59 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:24:59 --> Helper loaded: html_helper
INFO - 2016-09-02 09:24:59 --> Helper loaded: form_helper
INFO - 2016-09-02 09:24:59 --> Helper loaded: file_helper
INFO - 2016-09-02 09:24:59 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:24:59 --> Database Driver Class Initialized
INFO - 2016-09-02 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:24:59 --> Form Validation Class Initialized
INFO - 2016-09-02 09:24:59 --> Email Class Initialized
INFO - 2016-09-02 09:24:59 --> Controller Class Initialized
INFO - 2016-09-02 09:24:59 --> Model Class Initialized
INFO - 2016-09-02 09:24:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:24:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:24:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-09-02 09:24:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:24:59 --> Final output sent to browser
DEBUG - 2016-09-02 09:24:59 --> Total execution time: 0.3407
INFO - 2016-09-02 09:25:13 --> Config Class Initialized
INFO - 2016-09-02 09:25:13 --> Hooks Class Initialized
DEBUG - 2016-09-02 09:25:13 --> UTF-8 Support Enabled
INFO - 2016-09-02 09:25:13 --> Utf8 Class Initialized
INFO - 2016-09-02 09:25:13 --> URI Class Initialized
INFO - 2016-09-02 09:25:13 --> Router Class Initialized
INFO - 2016-09-02 09:25:13 --> Output Class Initialized
INFO - 2016-09-02 09:25:13 --> Security Class Initialized
DEBUG - 2016-09-02 09:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-02 09:25:13 --> Input Class Initialized
INFO - 2016-09-02 09:25:13 --> Language Class Initialized
INFO - 2016-09-02 09:25:13 --> Loader Class Initialized
INFO - 2016-09-02 09:25:13 --> Helper loaded: url_helper
INFO - 2016-09-02 09:25:13 --> Helper loaded: utils_helper
INFO - 2016-09-02 09:25:13 --> Helper loaded: html_helper
INFO - 2016-09-02 09:25:13 --> Helper loaded: form_helper
INFO - 2016-09-02 09:25:13 --> Helper loaded: file_helper
INFO - 2016-09-02 09:25:13 --> Helper loaded: myemail_helper
INFO - 2016-09-02 09:25:13 --> Database Driver Class Initialized
INFO - 2016-09-02 09:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-02 09:25:13 --> Form Validation Class Initialized
INFO - 2016-09-02 09:25:13 --> Email Class Initialized
INFO - 2016-09-02 09:25:13 --> Controller Class Initialized
DEBUG - 2016-09-02 09:25:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-02 09:25:13 --> Model Class Initialized
INFO - 2016-09-02 09:25:13 --> Model Class Initialized
INFO - 2016-09-02 09:25:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-02 09:25:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-09-02 09:25:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-09-02 09:25:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-02 09:25:13 --> Final output sent to browser
DEBUG - 2016-09-02 09:25:13 --> Total execution time: 0.3070
