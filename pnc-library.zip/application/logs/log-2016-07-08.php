<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-08 01:34:01 --> Config Class Initialized
INFO - 2016-07-08 01:34:01 --> Hooks Class Initialized
DEBUG - 2016-07-08 01:34:01 --> UTF-8 Support Enabled
INFO - 2016-07-08 01:34:01 --> Utf8 Class Initialized
INFO - 2016-07-08 01:34:01 --> URI Class Initialized
INFO - 2016-07-08 01:34:01 --> Router Class Initialized
INFO - 2016-07-08 01:34:01 --> Output Class Initialized
INFO - 2016-07-08 01:34:01 --> Security Class Initialized
DEBUG - 2016-07-08 01:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-08 01:34:01 --> Input Class Initialized
INFO - 2016-07-08 01:34:01 --> Language Class Initialized
INFO - 2016-07-08 01:34:01 --> Loader Class Initialized
INFO - 2016-07-08 01:34:01 --> Helper loaded: url_helper
INFO - 2016-07-08 01:34:01 --> Helper loaded: utils_helper
INFO - 2016-07-08 01:34:02 --> Helper loaded: html_helper
INFO - 2016-07-08 01:34:02 --> Helper loaded: form_helper
INFO - 2016-07-08 01:34:02 --> Helper loaded: file_helper
INFO - 2016-07-08 01:34:02 --> Helper loaded: myemail_helper
INFO - 2016-07-08 01:34:02 --> Database Driver Class Initialized
INFO - 2016-07-08 01:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-08 01:34:02 --> Form Validation Class Initialized
INFO - 2016-07-08 01:34:02 --> Email Class Initialized
INFO - 2016-07-08 01:34:02 --> Controller Class Initialized
INFO - 2016-07-08 01:34:03 --> Config Class Initialized
INFO - 2016-07-08 01:34:03 --> Hooks Class Initialized
DEBUG - 2016-07-08 01:34:03 --> UTF-8 Support Enabled
INFO - 2016-07-08 01:34:03 --> Utf8 Class Initialized
INFO - 2016-07-08 01:34:03 --> URI Class Initialized
INFO - 2016-07-08 01:34:03 --> Router Class Initialized
INFO - 2016-07-08 01:34:03 --> Output Class Initialized
INFO - 2016-07-08 01:34:03 --> Security Class Initialized
DEBUG - 2016-07-08 01:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-08 01:34:03 --> Input Class Initialized
INFO - 2016-07-08 01:34:03 --> Language Class Initialized
INFO - 2016-07-08 01:34:03 --> Loader Class Initialized
INFO - 2016-07-08 01:34:03 --> Helper loaded: url_helper
INFO - 2016-07-08 01:34:03 --> Helper loaded: utils_helper
INFO - 2016-07-08 01:34:03 --> Helper loaded: html_helper
INFO - 2016-07-08 01:34:03 --> Helper loaded: form_helper
INFO - 2016-07-08 01:34:03 --> Helper loaded: file_helper
INFO - 2016-07-08 01:34:03 --> Helper loaded: myemail_helper
INFO - 2016-07-08 01:34:03 --> Database Driver Class Initialized
INFO - 2016-07-08 01:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-08 01:34:03 --> Form Validation Class Initialized
INFO - 2016-07-08 01:34:03 --> Email Class Initialized
INFO - 2016-07-08 01:34:03 --> Controller Class Initialized
INFO - 2016-07-08 01:34:03 --> Model Class Initialized
DEBUG - 2016-07-08 01:34:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-08 01:34:03 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-08 01:34:04 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-08 01:34:04 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-08 01:34:04 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-08 01:34:04 --> Final output sent to browser
DEBUG - 2016-07-08 01:34:04 --> Total execution time: 0.6832
INFO - 2016-07-08 04:33:24 --> Config Class Initialized
INFO - 2016-07-08 04:33:25 --> Hooks Class Initialized
DEBUG - 2016-07-08 04:33:25 --> UTF-8 Support Enabled
INFO - 2016-07-08 04:33:25 --> Utf8 Class Initialized
INFO - 2016-07-08 04:33:25 --> URI Class Initialized
INFO - 2016-07-08 04:33:25 --> Router Class Initialized
INFO - 2016-07-08 04:33:25 --> Output Class Initialized
INFO - 2016-07-08 04:33:25 --> Security Class Initialized
DEBUG - 2016-07-08 04:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-08 04:33:25 --> Input Class Initialized
INFO - 2016-07-08 04:33:25 --> Language Class Initialized
INFO - 2016-07-08 04:33:25 --> Loader Class Initialized
INFO - 2016-07-08 04:33:25 --> Helper loaded: url_helper
INFO - 2016-07-08 04:33:25 --> Helper loaded: utils_helper
INFO - 2016-07-08 04:33:25 --> Helper loaded: html_helper
INFO - 2016-07-08 04:33:25 --> Helper loaded: form_helper
INFO - 2016-07-08 04:33:25 --> Helper loaded: file_helper
INFO - 2016-07-08 04:33:25 --> Helper loaded: myemail_helper
INFO - 2016-07-08 04:33:25 --> Database Driver Class Initialized
INFO - 2016-07-08 04:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-08 04:33:25 --> Form Validation Class Initialized
INFO - 2016-07-08 04:33:25 --> Email Class Initialized
INFO - 2016-07-08 04:33:25 --> Controller Class Initialized
INFO - 2016-07-08 04:33:25 --> Model Class Initialized
DEBUG - 2016-07-08 04:33:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-08 04:33:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-08 04:33:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-08 04:33:25 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-08 04:33:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-08 04:33:25 --> Final output sent to browser
DEBUG - 2016-07-08 04:33:25 --> Total execution time: 0.9180
