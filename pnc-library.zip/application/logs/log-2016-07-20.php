<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-20 01:35:29 --> Config Class Initialized
INFO - 2016-07-20 01:35:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 01:35:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 01:35:29 --> Utf8 Class Initialized
INFO - 2016-07-20 01:35:29 --> URI Class Initialized
INFO - 2016-07-20 01:35:29 --> Router Class Initialized
INFO - 2016-07-20 01:35:29 --> Output Class Initialized
INFO - 2016-07-20 01:35:30 --> Security Class Initialized
DEBUG - 2016-07-20 01:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 01:35:30 --> Input Class Initialized
INFO - 2016-07-20 01:35:30 --> Language Class Initialized
INFO - 2016-07-20 01:35:30 --> Loader Class Initialized
INFO - 2016-07-20 01:35:31 --> Helper loaded: url_helper
INFO - 2016-07-20 01:35:31 --> Helper loaded: utils_helper
INFO - 2016-07-20 01:35:31 --> Helper loaded: html_helper
INFO - 2016-07-20 01:35:31 --> Helper loaded: form_helper
INFO - 2016-07-20 01:35:31 --> Helper loaded: file_helper
INFO - 2016-07-20 01:35:31 --> Helper loaded: myemail_helper
INFO - 2016-07-20 01:35:32 --> Database Driver Class Initialized
INFO - 2016-07-20 01:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 01:35:32 --> Form Validation Class Initialized
INFO - 2016-07-20 01:35:32 --> Email Class Initialized
INFO - 2016-07-20 01:35:32 --> Controller Class Initialized
INFO - 2016-07-20 01:35:33 --> Config Class Initialized
INFO - 2016-07-20 01:35:33 --> Hooks Class Initialized
DEBUG - 2016-07-20 01:35:33 --> UTF-8 Support Enabled
INFO - 2016-07-20 01:35:33 --> Utf8 Class Initialized
INFO - 2016-07-20 01:35:33 --> URI Class Initialized
INFO - 2016-07-20 01:35:33 --> Router Class Initialized
INFO - 2016-07-20 01:35:34 --> Output Class Initialized
INFO - 2016-07-20 01:35:34 --> Security Class Initialized
DEBUG - 2016-07-20 01:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 01:35:34 --> Input Class Initialized
INFO - 2016-07-20 01:35:34 --> Language Class Initialized
INFO - 2016-07-20 01:35:34 --> Loader Class Initialized
INFO - 2016-07-20 01:35:34 --> Helper loaded: url_helper
INFO - 2016-07-20 01:35:34 --> Helper loaded: utils_helper
INFO - 2016-07-20 01:35:34 --> Helper loaded: html_helper
INFO - 2016-07-20 01:35:34 --> Helper loaded: form_helper
INFO - 2016-07-20 01:35:34 --> Helper loaded: file_helper
INFO - 2016-07-20 01:35:34 --> Helper loaded: myemail_helper
INFO - 2016-07-20 01:35:34 --> Database Driver Class Initialized
INFO - 2016-07-20 01:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 01:35:34 --> Form Validation Class Initialized
INFO - 2016-07-20 01:35:34 --> Email Class Initialized
INFO - 2016-07-20 01:35:34 --> Controller Class Initialized
INFO - 2016-07-20 01:35:34 --> Model Class Initialized
DEBUG - 2016-07-20 01:35:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 01:35:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 01:35:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 01:35:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 01:35:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 01:35:35 --> Final output sent to browser
DEBUG - 2016-07-20 01:35:35 --> Total execution time: 1.2948
INFO - 2016-07-20 01:35:39 --> Config Class Initialized
INFO - 2016-07-20 01:35:39 --> Hooks Class Initialized
DEBUG - 2016-07-20 01:35:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 01:35:40 --> Utf8 Class Initialized
INFO - 2016-07-20 01:35:40 --> URI Class Initialized
INFO - 2016-07-20 01:35:40 --> Router Class Initialized
INFO - 2016-07-20 01:35:40 --> Output Class Initialized
INFO - 2016-07-20 01:35:40 --> Security Class Initialized
DEBUG - 2016-07-20 01:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 01:35:40 --> Input Class Initialized
INFO - 2016-07-20 01:35:40 --> Language Class Initialized
ERROR - 2016-07-20 01:35:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 01:35:40 --> Config Class Initialized
INFO - 2016-07-20 01:35:40 --> Hooks Class Initialized
DEBUG - 2016-07-20 01:35:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 01:35:40 --> Utf8 Class Initialized
INFO - 2016-07-20 01:35:40 --> URI Class Initialized
INFO - 2016-07-20 01:35:40 --> Router Class Initialized
INFO - 2016-07-20 01:35:40 --> Output Class Initialized
INFO - 2016-07-20 01:35:40 --> Security Class Initialized
DEBUG - 2016-07-20 01:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 01:35:40 --> Input Class Initialized
INFO - 2016-07-20 01:35:40 --> Language Class Initialized
ERROR - 2016-07-20 01:35:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 02:21:17 --> Config Class Initialized
INFO - 2016-07-20 02:21:17 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:21:17 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:21:17 --> Utf8 Class Initialized
INFO - 2016-07-20 02:21:17 --> URI Class Initialized
INFO - 2016-07-20 02:21:17 --> Router Class Initialized
INFO - 2016-07-20 02:21:17 --> Output Class Initialized
INFO - 2016-07-20 02:21:17 --> Security Class Initialized
DEBUG - 2016-07-20 02:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:21:17 --> Input Class Initialized
INFO - 2016-07-20 02:21:17 --> Language Class Initialized
INFO - 2016-07-20 02:21:17 --> Loader Class Initialized
INFO - 2016-07-20 02:21:17 --> Helper loaded: url_helper
INFO - 2016-07-20 02:21:17 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:21:17 --> Helper loaded: html_helper
INFO - 2016-07-20 02:21:17 --> Helper loaded: form_helper
INFO - 2016-07-20 02:21:17 --> Helper loaded: file_helper
INFO - 2016-07-20 02:21:17 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:21:17 --> Database Driver Class Initialized
INFO - 2016-07-20 02:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:21:18 --> Form Validation Class Initialized
INFO - 2016-07-20 02:21:18 --> Email Class Initialized
INFO - 2016-07-20 02:21:18 --> Controller Class Initialized
INFO - 2016-07-20 02:21:18 --> Model Class Initialized
DEBUG - 2016-07-20 02:21:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:21:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 02:21:18 --> Config Class Initialized
INFO - 2016-07-20 02:21:18 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:21:18 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:21:18 --> Utf8 Class Initialized
INFO - 2016-07-20 02:21:18 --> URI Class Initialized
INFO - 2016-07-20 02:21:18 --> Router Class Initialized
INFO - 2016-07-20 02:21:18 --> Output Class Initialized
INFO - 2016-07-20 02:21:18 --> Security Class Initialized
DEBUG - 2016-07-20 02:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:21:18 --> Input Class Initialized
INFO - 2016-07-20 02:21:18 --> Language Class Initialized
INFO - 2016-07-20 02:21:18 --> Loader Class Initialized
INFO - 2016-07-20 02:21:18 --> Helper loaded: url_helper
INFO - 2016-07-20 02:21:18 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:21:18 --> Helper loaded: html_helper
INFO - 2016-07-20 02:21:18 --> Helper loaded: form_helper
INFO - 2016-07-20 02:21:18 --> Helper loaded: file_helper
INFO - 2016-07-20 02:21:18 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:21:18 --> Database Driver Class Initialized
INFO - 2016-07-20 02:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:21:18 --> Form Validation Class Initialized
INFO - 2016-07-20 02:21:18 --> Email Class Initialized
INFO - 2016-07-20 02:21:18 --> Controller Class Initialized
DEBUG - 2016-07-20 02:21:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:21:18 --> Model Class Initialized
INFO - 2016-07-20 02:21:18 --> Model Class Initialized
ERROR - 2016-07-20 02:21:18 --> Severity: Error --> Cannot call private PHPExcel_IOFactory::__construct() D:\wamp\www\library.pnc.lan\application\libraries\iof_actory.php 10
INFO - 2016-07-20 02:21:40 --> Config Class Initialized
INFO - 2016-07-20 02:21:40 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:21:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:21:40 --> Utf8 Class Initialized
INFO - 2016-07-20 02:21:40 --> URI Class Initialized
INFO - 2016-07-20 02:21:40 --> Router Class Initialized
INFO - 2016-07-20 02:21:40 --> Output Class Initialized
INFO - 2016-07-20 02:21:40 --> Security Class Initialized
DEBUG - 2016-07-20 02:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:21:40 --> Input Class Initialized
INFO - 2016-07-20 02:21:40 --> Language Class Initialized
INFO - 2016-07-20 02:21:40 --> Loader Class Initialized
INFO - 2016-07-20 02:21:40 --> Helper loaded: url_helper
INFO - 2016-07-20 02:21:40 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:21:40 --> Helper loaded: html_helper
INFO - 2016-07-20 02:21:40 --> Helper loaded: form_helper
INFO - 2016-07-20 02:21:40 --> Helper loaded: file_helper
INFO - 2016-07-20 02:21:40 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:21:40 --> Database Driver Class Initialized
INFO - 2016-07-20 02:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:21:40 --> Form Validation Class Initialized
INFO - 2016-07-20 02:21:40 --> Email Class Initialized
INFO - 2016-07-20 02:21:40 --> Controller Class Initialized
DEBUG - 2016-07-20 02:21:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:21:40 --> Model Class Initialized
INFO - 2016-07-20 02:21:40 --> Model Class Initialized
ERROR - 2016-07-20 02:21:40 --> Severity: Error --> Call to private PHPExcel_IOFactory::__construct() from context 'CI_Loader' D:\wamp\www\library.pnc.lan\system\core\Loader.php 1247
INFO - 2016-07-20 02:21:42 --> Config Class Initialized
INFO - 2016-07-20 02:21:42 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:21:42 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:21:42 --> Utf8 Class Initialized
INFO - 2016-07-20 02:21:42 --> URI Class Initialized
INFO - 2016-07-20 02:21:42 --> Router Class Initialized
INFO - 2016-07-20 02:21:42 --> Output Class Initialized
INFO - 2016-07-20 02:21:42 --> Security Class Initialized
DEBUG - 2016-07-20 02:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:21:42 --> Input Class Initialized
INFO - 2016-07-20 02:21:42 --> Language Class Initialized
INFO - 2016-07-20 02:21:42 --> Loader Class Initialized
INFO - 2016-07-20 02:21:42 --> Helper loaded: url_helper
INFO - 2016-07-20 02:21:42 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:21:42 --> Helper loaded: html_helper
INFO - 2016-07-20 02:21:42 --> Helper loaded: form_helper
INFO - 2016-07-20 02:21:42 --> Helper loaded: file_helper
INFO - 2016-07-20 02:21:42 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:21:42 --> Database Driver Class Initialized
INFO - 2016-07-20 02:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:21:42 --> Form Validation Class Initialized
INFO - 2016-07-20 02:21:42 --> Email Class Initialized
INFO - 2016-07-20 02:21:42 --> Controller Class Initialized
DEBUG - 2016-07-20 02:21:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:21:42 --> Model Class Initialized
INFO - 2016-07-20 02:21:42 --> Model Class Initialized
ERROR - 2016-07-20 02:21:42 --> Severity: Error --> Call to private PHPExcel_IOFactory::__construct() from context 'CI_Loader' D:\wamp\www\library.pnc.lan\system\core\Loader.php 1247
INFO - 2016-07-20 02:21:43 --> Config Class Initialized
INFO - 2016-07-20 02:21:43 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:21:43 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:21:43 --> Utf8 Class Initialized
INFO - 2016-07-20 02:21:43 --> URI Class Initialized
INFO - 2016-07-20 02:21:43 --> Router Class Initialized
INFO - 2016-07-20 02:21:43 --> Output Class Initialized
INFO - 2016-07-20 02:21:43 --> Security Class Initialized
DEBUG - 2016-07-20 02:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:21:43 --> Input Class Initialized
INFO - 2016-07-20 02:21:43 --> Language Class Initialized
INFO - 2016-07-20 02:21:43 --> Loader Class Initialized
INFO - 2016-07-20 02:21:43 --> Helper loaded: url_helper
INFO - 2016-07-20 02:21:43 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:21:43 --> Helper loaded: html_helper
INFO - 2016-07-20 02:21:43 --> Helper loaded: form_helper
INFO - 2016-07-20 02:21:43 --> Helper loaded: file_helper
INFO - 2016-07-20 02:21:43 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:21:43 --> Database Driver Class Initialized
INFO - 2016-07-20 02:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:21:43 --> Form Validation Class Initialized
INFO - 2016-07-20 02:21:43 --> Email Class Initialized
INFO - 2016-07-20 02:21:43 --> Controller Class Initialized
DEBUG - 2016-07-20 02:21:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:21:43 --> Model Class Initialized
INFO - 2016-07-20 02:21:44 --> Model Class Initialized
ERROR - 2016-07-20 02:21:44 --> Severity: Error --> Call to private PHPExcel_IOFactory::__construct() from context 'CI_Loader' D:\wamp\www\library.pnc.lan\system\core\Loader.php 1247
INFO - 2016-07-20 02:25:44 --> Config Class Initialized
INFO - 2016-07-20 02:25:44 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:25:44 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:25:44 --> Utf8 Class Initialized
INFO - 2016-07-20 02:25:44 --> URI Class Initialized
INFO - 2016-07-20 02:25:44 --> Router Class Initialized
INFO - 2016-07-20 02:25:44 --> Output Class Initialized
INFO - 2016-07-20 02:25:44 --> Security Class Initialized
DEBUG - 2016-07-20 02:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:25:44 --> Input Class Initialized
INFO - 2016-07-20 02:25:44 --> Language Class Initialized
INFO - 2016-07-20 02:25:44 --> Loader Class Initialized
INFO - 2016-07-20 02:25:44 --> Helper loaded: url_helper
INFO - 2016-07-20 02:25:44 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:25:44 --> Helper loaded: html_helper
INFO - 2016-07-20 02:25:44 --> Helper loaded: form_helper
INFO - 2016-07-20 02:25:44 --> Helper loaded: file_helper
INFO - 2016-07-20 02:25:44 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:25:44 --> Database Driver Class Initialized
INFO - 2016-07-20 02:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:25:44 --> Form Validation Class Initialized
INFO - 2016-07-20 02:25:44 --> Email Class Initialized
INFO - 2016-07-20 02:25:44 --> Controller Class Initialized
DEBUG - 2016-07-20 02:25:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:25:44 --> Model Class Initialized
INFO - 2016-07-20 02:25:44 --> Model Class Initialized
INFO - 2016-07-20 02:25:45 --> Final output sent to browser
DEBUG - 2016-07-20 02:25:45 --> Total execution time: 0.6705
INFO - 2016-07-20 02:28:17 --> Config Class Initialized
INFO - 2016-07-20 02:28:17 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:28:17 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:28:17 --> Utf8 Class Initialized
INFO - 2016-07-20 02:28:17 --> URI Class Initialized
INFO - 2016-07-20 02:28:17 --> Router Class Initialized
INFO - 2016-07-20 02:28:17 --> Output Class Initialized
INFO - 2016-07-20 02:28:17 --> Security Class Initialized
DEBUG - 2016-07-20 02:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:28:17 --> Input Class Initialized
INFO - 2016-07-20 02:28:17 --> Language Class Initialized
INFO - 2016-07-20 02:28:17 --> Loader Class Initialized
INFO - 2016-07-20 02:28:17 --> Helper loaded: url_helper
INFO - 2016-07-20 02:28:17 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:28:17 --> Helper loaded: html_helper
INFO - 2016-07-20 02:28:17 --> Helper loaded: form_helper
INFO - 2016-07-20 02:28:17 --> Helper loaded: file_helper
INFO - 2016-07-20 02:28:17 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:28:17 --> Database Driver Class Initialized
INFO - 2016-07-20 02:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:28:17 --> Form Validation Class Initialized
INFO - 2016-07-20 02:28:17 --> Email Class Initialized
INFO - 2016-07-20 02:28:17 --> Controller Class Initialized
DEBUG - 2016-07-20 02:28:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:28:17 --> Model Class Initialized
INFO - 2016-07-20 02:28:17 --> Model Class Initialized
INFO - 2016-07-20 02:28:18 --> Final output sent to browser
DEBUG - 2016-07-20 02:28:18 --> Total execution time: 0.4138
INFO - 2016-07-20 02:43:36 --> Config Class Initialized
INFO - 2016-07-20 02:43:36 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:43:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:43:36 --> Utf8 Class Initialized
INFO - 2016-07-20 02:43:36 --> URI Class Initialized
INFO - 2016-07-20 02:43:36 --> Router Class Initialized
INFO - 2016-07-20 02:43:36 --> Output Class Initialized
INFO - 2016-07-20 02:43:36 --> Security Class Initialized
DEBUG - 2016-07-20 02:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:43:36 --> Input Class Initialized
INFO - 2016-07-20 02:43:36 --> Language Class Initialized
INFO - 2016-07-20 02:43:36 --> Loader Class Initialized
INFO - 2016-07-20 02:43:36 --> Helper loaded: url_helper
INFO - 2016-07-20 02:43:36 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:43:36 --> Helper loaded: html_helper
INFO - 2016-07-20 02:43:36 --> Helper loaded: form_helper
INFO - 2016-07-20 02:43:36 --> Helper loaded: file_helper
INFO - 2016-07-20 02:43:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:43:36 --> Database Driver Class Initialized
INFO - 2016-07-20 02:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:43:36 --> Form Validation Class Initialized
INFO - 2016-07-20 02:43:36 --> Email Class Initialized
INFO - 2016-07-20 02:43:36 --> Controller Class Initialized
INFO - 2016-07-20 02:43:36 --> Model Class Initialized
DEBUG - 2016-07-20 02:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 02:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 02:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 02:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 02:43:36 --> Final output sent to browser
DEBUG - 2016-07-20 02:43:36 --> Total execution time: 0.2090
INFO - 2016-07-20 02:44:01 --> Config Class Initialized
INFO - 2016-07-20 02:44:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:44:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:44:01 --> Utf8 Class Initialized
INFO - 2016-07-20 02:44:01 --> URI Class Initialized
INFO - 2016-07-20 02:44:01 --> Router Class Initialized
INFO - 2016-07-20 02:44:01 --> Output Class Initialized
INFO - 2016-07-20 02:44:01 --> Security Class Initialized
DEBUG - 2016-07-20 02:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:44:01 --> Input Class Initialized
INFO - 2016-07-20 02:44:01 --> Language Class Initialized
INFO - 2016-07-20 02:44:01 --> Loader Class Initialized
INFO - 2016-07-20 02:44:01 --> Helper loaded: url_helper
INFO - 2016-07-20 02:44:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:44:01 --> Helper loaded: html_helper
INFO - 2016-07-20 02:44:01 --> Helper loaded: form_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: file_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:44:02 --> Database Driver Class Initialized
INFO - 2016-07-20 02:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:44:02 --> Form Validation Class Initialized
INFO - 2016-07-20 02:44:02 --> Email Class Initialized
INFO - 2016-07-20 02:44:02 --> Controller Class Initialized
INFO - 2016-07-20 02:44:02 --> Model Class Initialized
DEBUG - 2016-07-20 02:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:44:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 02:44:02 --> Config Class Initialized
INFO - 2016-07-20 02:44:02 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:44:02 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:44:02 --> Utf8 Class Initialized
INFO - 2016-07-20 02:44:02 --> URI Class Initialized
INFO - 2016-07-20 02:44:02 --> Router Class Initialized
INFO - 2016-07-20 02:44:02 --> Output Class Initialized
INFO - 2016-07-20 02:44:02 --> Security Class Initialized
DEBUG - 2016-07-20 02:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:44:02 --> Input Class Initialized
INFO - 2016-07-20 02:44:02 --> Language Class Initialized
INFO - 2016-07-20 02:44:02 --> Loader Class Initialized
INFO - 2016-07-20 02:44:02 --> Helper loaded: url_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: html_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: form_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: file_helper
INFO - 2016-07-20 02:44:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:44:02 --> Database Driver Class Initialized
INFO - 2016-07-20 02:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:44:02 --> Form Validation Class Initialized
INFO - 2016-07-20 02:44:02 --> Email Class Initialized
INFO - 2016-07-20 02:44:02 --> Controller Class Initialized
DEBUG - 2016-07-20 02:44:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:44:02 --> Model Class Initialized
INFO - 2016-07-20 02:44:02 --> Model Class Initialized
ERROR - 2016-07-20 02:44:02 --> Query error: Unknown column 'b_ids' in 'order clause' - Invalid query: SELECT *
FROM `books`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
ORDER BY `b_ids` DESC
INFO - 2016-07-20 02:44:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 02:54:21 --> Config Class Initialized
INFO - 2016-07-20 02:54:21 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:54:21 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:54:21 --> Utf8 Class Initialized
INFO - 2016-07-20 02:54:21 --> URI Class Initialized
INFO - 2016-07-20 02:54:21 --> Router Class Initialized
INFO - 2016-07-20 02:54:21 --> Output Class Initialized
INFO - 2016-07-20 02:54:21 --> Security Class Initialized
DEBUG - 2016-07-20 02:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:54:21 --> Input Class Initialized
INFO - 2016-07-20 02:54:21 --> Language Class Initialized
INFO - 2016-07-20 02:54:21 --> Loader Class Initialized
INFO - 2016-07-20 02:54:21 --> Helper loaded: url_helper
INFO - 2016-07-20 02:54:21 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:54:21 --> Helper loaded: html_helper
INFO - 2016-07-20 02:54:21 --> Helper loaded: form_helper
INFO - 2016-07-20 02:54:21 --> Helper loaded: file_helper
INFO - 2016-07-20 02:54:21 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:54:21 --> Database Driver Class Initialized
INFO - 2016-07-20 02:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:54:21 --> Form Validation Class Initialized
INFO - 2016-07-20 02:54:21 --> Email Class Initialized
INFO - 2016-07-20 02:54:21 --> Controller Class Initialized
DEBUG - 2016-07-20 02:54:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:54:21 --> Model Class Initialized
INFO - 2016-07-20 02:54:21 --> Model Class Initialized
ERROR - 2016-07-20 02:54:21 --> Query error: Unknown column 'b_title_kh "Titles in' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh "Titles in` `Khmer`, b_auther as "Author(s)", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
ORDER BY `b_ids` DESC
INFO - 2016-07-20 02:54:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 02:54:35 --> Config Class Initialized
INFO - 2016-07-20 02:54:35 --> Hooks Class Initialized
DEBUG - 2016-07-20 02:54:35 --> UTF-8 Support Enabled
INFO - 2016-07-20 02:54:35 --> Utf8 Class Initialized
INFO - 2016-07-20 02:54:35 --> URI Class Initialized
INFO - 2016-07-20 02:54:35 --> Router Class Initialized
INFO - 2016-07-20 02:54:35 --> Output Class Initialized
INFO - 2016-07-20 02:54:35 --> Security Class Initialized
DEBUG - 2016-07-20 02:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 02:54:35 --> Input Class Initialized
INFO - 2016-07-20 02:54:35 --> Language Class Initialized
INFO - 2016-07-20 02:54:35 --> Loader Class Initialized
INFO - 2016-07-20 02:54:35 --> Helper loaded: url_helper
INFO - 2016-07-20 02:54:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 02:54:35 --> Helper loaded: html_helper
INFO - 2016-07-20 02:54:35 --> Helper loaded: form_helper
INFO - 2016-07-20 02:54:35 --> Helper loaded: file_helper
INFO - 2016-07-20 02:54:35 --> Helper loaded: myemail_helper
INFO - 2016-07-20 02:54:35 --> Database Driver Class Initialized
INFO - 2016-07-20 02:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 02:54:35 --> Form Validation Class Initialized
INFO - 2016-07-20 02:54:35 --> Email Class Initialized
INFO - 2016-07-20 02:54:35 --> Controller Class Initialized
DEBUG - 2016-07-20 02:54:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 02:54:35 --> Model Class Initialized
INFO - 2016-07-20 02:54:35 --> Model Class Initialized
ERROR - 2016-07-20 02:54:35 --> Query error: Unknown column 'b_title_kh "Titles in' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh "Titles in` `Khmer`, b_auther as "Author(s)", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
ORDER BY `b_id` DESC
INFO - 2016-07-20 02:54:35 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:16:25 --> Config Class Initialized
INFO - 2016-07-20 03:16:25 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:16:25 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:16:25 --> Utf8 Class Initialized
INFO - 2016-07-20 03:16:25 --> URI Class Initialized
INFO - 2016-07-20 03:16:25 --> Router Class Initialized
INFO - 2016-07-20 03:16:25 --> Output Class Initialized
INFO - 2016-07-20 03:16:25 --> Security Class Initialized
DEBUG - 2016-07-20 03:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:16:25 --> Input Class Initialized
INFO - 2016-07-20 03:16:25 --> Language Class Initialized
INFO - 2016-07-20 03:16:25 --> Loader Class Initialized
INFO - 2016-07-20 03:16:25 --> Helper loaded: url_helper
INFO - 2016-07-20 03:16:25 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:16:25 --> Helper loaded: html_helper
INFO - 2016-07-20 03:16:25 --> Helper loaded: form_helper
INFO - 2016-07-20 03:16:25 --> Helper loaded: file_helper
INFO - 2016-07-20 03:16:25 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:16:25 --> Database Driver Class Initialized
INFO - 2016-07-20 03:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:16:25 --> Form Validation Class Initialized
INFO - 2016-07-20 03:16:25 --> Email Class Initialized
INFO - 2016-07-20 03:16:25 --> Controller Class Initialized
DEBUG - 2016-07-20 03:16:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:16:25 --> Model Class Initialized
INFO - 2016-07-20 03:16:25 --> Model Class Initialized
ERROR - 2016-07-20 03:16:25 --> Query error: Unknown column 'b_title_kh "Titles in' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh "Titles in` `Khmer"`, b_auther as "Author(s)", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:16:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:16:53 --> Config Class Initialized
INFO - 2016-07-20 03:16:53 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:16:53 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:16:53 --> Utf8 Class Initialized
INFO - 2016-07-20 03:16:53 --> URI Class Initialized
INFO - 2016-07-20 03:16:53 --> Router Class Initialized
INFO - 2016-07-20 03:16:53 --> Output Class Initialized
INFO - 2016-07-20 03:16:53 --> Security Class Initialized
DEBUG - 2016-07-20 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:16:53 --> Input Class Initialized
INFO - 2016-07-20 03:16:53 --> Language Class Initialized
INFO - 2016-07-20 03:16:53 --> Loader Class Initialized
INFO - 2016-07-20 03:16:53 --> Helper loaded: url_helper
INFO - 2016-07-20 03:16:53 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:16:53 --> Helper loaded: html_helper
INFO - 2016-07-20 03:16:53 --> Helper loaded: form_helper
INFO - 2016-07-20 03:16:53 --> Helper loaded: file_helper
INFO - 2016-07-20 03:16:53 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:16:53 --> Database Driver Class Initialized
INFO - 2016-07-20 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:16:53 --> Form Validation Class Initialized
INFO - 2016-07-20 03:16:53 --> Email Class Initialized
INFO - 2016-07-20 03:16:53 --> Controller Class Initialized
DEBUG - 2016-07-20 03:16:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:16:53 --> Model Class Initialized
INFO - 2016-07-20 03:16:53 --> Model Class Initialized
ERROR - 2016-07-20 03:16:53 --> Query error: Unknown column 'b_auther' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", b_auther as "Author(s)", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:16:53 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:17:24 --> Config Class Initialized
INFO - 2016-07-20 03:17:24 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:17:24 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:17:24 --> Utf8 Class Initialized
INFO - 2016-07-20 03:17:24 --> URI Class Initialized
INFO - 2016-07-20 03:17:24 --> Router Class Initialized
INFO - 2016-07-20 03:17:24 --> Output Class Initialized
INFO - 2016-07-20 03:17:24 --> Security Class Initialized
DEBUG - 2016-07-20 03:17:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:17:24 --> Input Class Initialized
INFO - 2016-07-20 03:17:24 --> Language Class Initialized
INFO - 2016-07-20 03:17:24 --> Loader Class Initialized
INFO - 2016-07-20 03:17:24 --> Helper loaded: url_helper
INFO - 2016-07-20 03:17:24 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:17:24 --> Helper loaded: html_helper
INFO - 2016-07-20 03:17:24 --> Helper loaded: form_helper
INFO - 2016-07-20 03:17:24 --> Helper loaded: file_helper
INFO - 2016-07-20 03:17:24 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:17:24 --> Database Driver Class Initialized
INFO - 2016-07-20 03:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:17:24 --> Form Validation Class Initialized
INFO - 2016-07-20 03:17:24 --> Email Class Initialized
INFO - 2016-07-20 03:17:24 --> Controller Class Initialized
DEBUG - 2016-07-20 03:17:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:17:24 --> Model Class Initialized
INFO - 2016-07-20 03:17:24 --> Model Class Initialized
ERROR - 2016-07-20 03:17:24 --> Query error: Unknown column 'b_auther' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_auther` as "Author", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:17:24 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:17:39 --> Config Class Initialized
INFO - 2016-07-20 03:17:39 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:17:39 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:17:39 --> Utf8 Class Initialized
INFO - 2016-07-20 03:17:39 --> URI Class Initialized
INFO - 2016-07-20 03:17:39 --> Router Class Initialized
INFO - 2016-07-20 03:17:39 --> Output Class Initialized
INFO - 2016-07-20 03:17:39 --> Security Class Initialized
DEBUG - 2016-07-20 03:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:17:39 --> Input Class Initialized
INFO - 2016-07-20 03:17:39 --> Language Class Initialized
INFO - 2016-07-20 03:17:39 --> Loader Class Initialized
INFO - 2016-07-20 03:17:39 --> Helper loaded: url_helper
INFO - 2016-07-20 03:17:39 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:17:39 --> Helper loaded: html_helper
INFO - 2016-07-20 03:17:39 --> Helper loaded: form_helper
INFO - 2016-07-20 03:17:39 --> Helper loaded: file_helper
INFO - 2016-07-20 03:17:39 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:17:39 --> Database Driver Class Initialized
INFO - 2016-07-20 03:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:17:39 --> Form Validation Class Initialized
INFO - 2016-07-20 03:17:39 --> Email Class Initialized
INFO - 2016-07-20 03:17:39 --> Controller Class Initialized
DEBUG - 2016-07-20 03:17:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:17:39 --> Model Class Initialized
INFO - 2016-07-20 03:17:39 --> Model Class Initialized
ERROR - 2016-07-20 03:17:40 --> Query error: Unknown column 'b_atuher_kh' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_atuher_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:17:40 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:18:04 --> Config Class Initialized
INFO - 2016-07-20 03:18:04 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:18:04 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:18:04 --> Utf8 Class Initialized
INFO - 2016-07-20 03:18:04 --> URI Class Initialized
INFO - 2016-07-20 03:18:04 --> Router Class Initialized
INFO - 2016-07-20 03:18:04 --> Output Class Initialized
INFO - 2016-07-20 03:18:04 --> Security Class Initialized
DEBUG - 2016-07-20 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:18:04 --> Input Class Initialized
INFO - 2016-07-20 03:18:04 --> Language Class Initialized
INFO - 2016-07-20 03:18:04 --> Loader Class Initialized
INFO - 2016-07-20 03:18:04 --> Helper loaded: url_helper
INFO - 2016-07-20 03:18:04 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:18:04 --> Helper loaded: html_helper
INFO - 2016-07-20 03:18:04 --> Helper loaded: form_helper
INFO - 2016-07-20 03:18:04 --> Helper loaded: file_helper
INFO - 2016-07-20 03:18:04 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:18:04 --> Database Driver Class Initialized
INFO - 2016-07-20 03:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:18:04 --> Form Validation Class Initialized
INFO - 2016-07-20 03:18:04 --> Email Class Initialized
INFO - 2016-07-20 03:18:04 --> Controller Class Initialized
DEBUG - 2016-07-20 03:18:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:18:04 --> Model Class Initialized
INFO - 2016-07-20 03:18:04 --> Model Class Initialized
ERROR - 2016-07-20 03:18:04 --> Query error: Unknown column 'b_atuthor_kh' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_atuthor_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:18:04 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:18:15 --> Config Class Initialized
INFO - 2016-07-20 03:18:15 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:18:15 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:18:15 --> Utf8 Class Initialized
INFO - 2016-07-20 03:18:15 --> URI Class Initialized
INFO - 2016-07-20 03:18:15 --> Router Class Initialized
INFO - 2016-07-20 03:18:15 --> Output Class Initialized
INFO - 2016-07-20 03:18:15 --> Security Class Initialized
DEBUG - 2016-07-20 03:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:18:15 --> Input Class Initialized
INFO - 2016-07-20 03:18:15 --> Language Class Initialized
INFO - 2016-07-20 03:18:15 --> Loader Class Initialized
INFO - 2016-07-20 03:18:15 --> Helper loaded: url_helper
INFO - 2016-07-20 03:18:15 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:18:15 --> Helper loaded: html_helper
INFO - 2016-07-20 03:18:15 --> Helper loaded: form_helper
INFO - 2016-07-20 03:18:15 --> Helper loaded: file_helper
INFO - 2016-07-20 03:18:15 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:18:15 --> Database Driver Class Initialized
INFO - 2016-07-20 03:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:18:15 --> Form Validation Class Initialized
INFO - 2016-07-20 03:18:15 --> Email Class Initialized
INFO - 2016-07-20 03:18:15 --> Controller Class Initialized
DEBUG - 2016-07-20 03:18:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:18:15 --> Model Class Initialized
INFO - 2016-07-20 03:18:15 --> Model Class Initialized
ERROR - 2016-07-20 03:18:15 --> Query error: Unknown column 'b_author_kh' in 'field list' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:18:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:18:52 --> Config Class Initialized
INFO - 2016-07-20 03:18:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:18:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:18:52 --> Utf8 Class Initialized
INFO - 2016-07-20 03:18:52 --> URI Class Initialized
INFO - 2016-07-20 03:18:52 --> Router Class Initialized
INFO - 2016-07-20 03:18:52 --> Output Class Initialized
INFO - 2016-07-20 03:18:52 --> Security Class Initialized
DEBUG - 2016-07-20 03:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:18:52 --> Input Class Initialized
INFO - 2016-07-20 03:18:52 --> Language Class Initialized
INFO - 2016-07-20 03:18:52 --> Loader Class Initialized
INFO - 2016-07-20 03:18:52 --> Helper loaded: url_helper
INFO - 2016-07-20 03:18:52 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:18:52 --> Helper loaded: html_helper
INFO - 2016-07-20 03:18:52 --> Helper loaded: form_helper
INFO - 2016-07-20 03:18:52 --> Helper loaded: file_helper
INFO - 2016-07-20 03:18:52 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:18:52 --> Database Driver Class Initialized
INFO - 2016-07-20 03:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:18:52 --> Form Validation Class Initialized
INFO - 2016-07-20 03:18:52 --> Email Class Initialized
INFO - 2016-07-20 03:18:52 --> Controller Class Initialized
DEBUG - 2016-07-20 03:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:18:52 --> Model Class Initialized
INFO - 2016-07-20 03:18:52 --> Model Class Initialized
ERROR - 2016-07-20 03:18:52 --> Query error: Unknown column 'books.cat_id' in 'on clause' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:18:52 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:20:11 --> Config Class Initialized
INFO - 2016-07-20 03:20:11 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:20:11 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:20:11 --> Utf8 Class Initialized
INFO - 2016-07-20 03:20:11 --> URI Class Initialized
INFO - 2016-07-20 03:20:11 --> Router Class Initialized
INFO - 2016-07-20 03:20:11 --> Output Class Initialized
INFO - 2016-07-20 03:20:11 --> Security Class Initialized
DEBUG - 2016-07-20 03:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:20:11 --> Input Class Initialized
INFO - 2016-07-20 03:20:11 --> Language Class Initialized
INFO - 2016-07-20 03:20:11 --> Loader Class Initialized
INFO - 2016-07-20 03:20:11 --> Helper loaded: url_helper
INFO - 2016-07-20 03:20:11 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:20:11 --> Helper loaded: html_helper
INFO - 2016-07-20 03:20:11 --> Helper loaded: form_helper
INFO - 2016-07-20 03:20:11 --> Helper loaded: file_helper
INFO - 2016-07-20 03:20:11 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:20:11 --> Database Driver Class Initialized
INFO - 2016-07-20 03:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:20:11 --> Form Validation Class Initialized
INFO - 2016-07-20 03:20:11 --> Email Class Initialized
INFO - 2016-07-20 03:20:11 --> Controller Class Initialized
DEBUG - 2016-07-20 03:20:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:20:11 --> Model Class Initialized
INFO - 2016-07-20 03:20:11 --> Model Class Initialized
ERROR - 2016-07-20 03:20:11 --> Query error: Unknown column 'books.cat_id' in 'on clause' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` `cat` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` `sta` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` `con` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` `use` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:20:11 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:21:29 --> Config Class Initialized
INFO - 2016-07-20 03:21:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:21:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:21:29 --> Utf8 Class Initialized
INFO - 2016-07-20 03:21:30 --> URI Class Initialized
INFO - 2016-07-20 03:21:30 --> Router Class Initialized
INFO - 2016-07-20 03:21:30 --> Output Class Initialized
INFO - 2016-07-20 03:21:30 --> Security Class Initialized
DEBUG - 2016-07-20 03:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:21:30 --> Input Class Initialized
INFO - 2016-07-20 03:21:30 --> Language Class Initialized
INFO - 2016-07-20 03:21:30 --> Loader Class Initialized
INFO - 2016-07-20 03:21:30 --> Helper loaded: url_helper
INFO - 2016-07-20 03:21:30 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:21:30 --> Helper loaded: html_helper
INFO - 2016-07-20 03:21:30 --> Helper loaded: form_helper
INFO - 2016-07-20 03:21:30 --> Helper loaded: file_helper
INFO - 2016-07-20 03:21:30 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:21:30 --> Database Driver Class Initialized
INFO - 2016-07-20 03:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:21:30 --> Form Validation Class Initialized
INFO - 2016-07-20 03:21:30 --> Email Class Initialized
INFO - 2016-07-20 03:21:30 --> Controller Class Initialized
DEBUG - 2016-07-20 03:21:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:21:30 --> Model Class Initialized
INFO - 2016-07-20 03:21:30 --> Model Class Initialized
ERROR - 2016-07-20 03:21:30 --> Query error: Unknown column 'books.sta_id' in 'on clause' - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer"
FROM `books` `boo`
JOIN `categories` `cat` ON `boo`.`cat_id` = `cat`.`cat_id`
JOIN `status` `sta` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` `con` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` `use` ON `books`.`users_id` = `users`.`id`
INFO - 2016-07-20 03:21:30 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:33:33 --> Config Class Initialized
INFO - 2016-07-20 03:33:33 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:33:33 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:33:33 --> Utf8 Class Initialized
INFO - 2016-07-20 03:33:33 --> URI Class Initialized
INFO - 2016-07-20 03:33:33 --> Router Class Initialized
INFO - 2016-07-20 03:33:33 --> Output Class Initialized
INFO - 2016-07-20 03:33:33 --> Security Class Initialized
DEBUG - 2016-07-20 03:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:33:33 --> Input Class Initialized
INFO - 2016-07-20 03:33:33 --> Language Class Initialized
INFO - 2016-07-20 03:33:33 --> Loader Class Initialized
INFO - 2016-07-20 03:33:34 --> Helper loaded: url_helper
INFO - 2016-07-20 03:33:34 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:33:34 --> Helper loaded: html_helper
INFO - 2016-07-20 03:33:34 --> Helper loaded: form_helper
INFO - 2016-07-20 03:33:34 --> Helper loaded: file_helper
INFO - 2016-07-20 03:33:34 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:33:34 --> Database Driver Class Initialized
INFO - 2016-07-20 03:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:33:34 --> Form Validation Class Initialized
INFO - 2016-07-20 03:33:34 --> Email Class Initialized
INFO - 2016-07-20 03:33:34 --> Controller Class Initialized
DEBUG - 2016-07-20 03:33:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:33:34 --> Model Class Initialized
INFO - 2016-07-20 03:33:34 --> Model Class Initialized
INFO - 2016-07-20 03:33:34 --> Final output sent to browser
DEBUG - 2016-07-20 03:33:34 --> Total execution time: 0.3416
INFO - 2016-07-20 03:47:33 --> Config Class Initialized
INFO - 2016-07-20 03:47:33 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:47:33 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:47:33 --> Utf8 Class Initialized
INFO - 2016-07-20 03:47:33 --> URI Class Initialized
INFO - 2016-07-20 03:47:33 --> Router Class Initialized
INFO - 2016-07-20 03:47:33 --> Output Class Initialized
INFO - 2016-07-20 03:47:33 --> Security Class Initialized
DEBUG - 2016-07-20 03:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:47:33 --> Input Class Initialized
INFO - 2016-07-20 03:47:33 --> Language Class Initialized
INFO - 2016-07-20 03:47:33 --> Loader Class Initialized
INFO - 2016-07-20 03:47:33 --> Helper loaded: url_helper
INFO - 2016-07-20 03:47:33 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:47:33 --> Helper loaded: html_helper
INFO - 2016-07-20 03:47:33 --> Helper loaded: form_helper
INFO - 2016-07-20 03:47:33 --> Helper loaded: file_helper
INFO - 2016-07-20 03:47:33 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:47:33 --> Database Driver Class Initialized
INFO - 2016-07-20 03:47:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:47:33 --> Form Validation Class Initialized
INFO - 2016-07-20 03:47:33 --> Email Class Initialized
INFO - 2016-07-20 03:47:33 --> Controller Class Initialized
DEBUG - 2016-07-20 03:47:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:47:33 --> Model Class Initialized
INFO - 2016-07-20 03:47:33 --> Model Class Initialized
ERROR - 2016-07-20 03:47:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'b_publisher as "Publisher"b_year as "Year"b_language as "Language"b_isbn as "ISB' at line 1 - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer"b_publisher as "Publisher"b_year as "Year"b_language as "Language"b_isbn as "ISBN"con_name as "Condition (New-Correct)")b_keyword as "Key Words (separeted by;)"cat_name as "Category name"cat.cat_id as "Category ID"b_label as "Label"b_barcode as "Barcode"b_comment as "Comment"b_edition as "Edition"
FROM `books` `boo`
JOIN `categories` `cat` ON `boo`.`cat_id` = `cat`.`cat_id`
JOIN `status` `sta` ON `boo`.`sta_id` = `sta`.`sta_id`
JOIN `conditions` `con` ON `boo`.`con_id` = `con`.`con_id`
JOIN `users` `use` ON `boo`.`users_id` = `use`.`id`
INFO - 2016-07-20 03:47:33 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:48:31 --> Config Class Initialized
INFO - 2016-07-20 03:48:31 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:48:31 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:48:31 --> Utf8 Class Initialized
INFO - 2016-07-20 03:48:31 --> URI Class Initialized
INFO - 2016-07-20 03:48:31 --> Router Class Initialized
INFO - 2016-07-20 03:48:31 --> Output Class Initialized
INFO - 2016-07-20 03:48:31 --> Security Class Initialized
DEBUG - 2016-07-20 03:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:48:31 --> Input Class Initialized
INFO - 2016-07-20 03:48:31 --> Language Class Initialized
INFO - 2016-07-20 03:48:31 --> Loader Class Initialized
INFO - 2016-07-20 03:48:31 --> Helper loaded: url_helper
INFO - 2016-07-20 03:48:31 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:48:31 --> Helper loaded: html_helper
INFO - 2016-07-20 03:48:31 --> Helper loaded: form_helper
INFO - 2016-07-20 03:48:31 --> Helper loaded: file_helper
INFO - 2016-07-20 03:48:31 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:48:31 --> Database Driver Class Initialized
INFO - 2016-07-20 03:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:48:31 --> Form Validation Class Initialized
INFO - 2016-07-20 03:48:31 --> Email Class Initialized
INFO - 2016-07-20 03:48:31 --> Controller Class Initialized
DEBUG - 2016-07-20 03:48:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:48:31 --> Model Class Initialized
INFO - 2016-07-20 03:48:31 --> Model Class Initialized
ERROR - 2016-07-20 03:48:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '), b_keyword as "Key Words (separeted by;)", `cat_name` as "Category name", `cat' at line 1 - Invalid query: SELECT `b_title_en` as "Title", `b_title_kh` as "Titles in Khmer", `b_author` as "Author", b_author_kh as "Author(s) in Khmer", `b_publisher` as "Publisher", `b_year` as "Year", `b_language` as "Language", `b_isbn` as "ISBN", con_name as "Condition (New-Correct)"), b_keyword as "Key Words (separeted by;)", `cat_name` as "Category name", `cat`.`cat_id` as "Category ID", `b_label` as "Label", `b_barcode` as "Barcode", `b_comment` as "Comment", `b_edition` as "Edition"
FROM `books` `boo`
JOIN `categories` `cat` ON `boo`.`cat_id` = `cat`.`cat_id`
JOIN `status` `sta` ON `boo`.`sta_id` = `sta`.`sta_id`
JOIN `conditions` `con` ON `boo`.`con_id` = `con`.`con_id`
JOIN `users` `use` ON `boo`.`users_id` = `use`.`id`
INFO - 2016-07-20 03:48:31 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 03:49:12 --> Config Class Initialized
INFO - 2016-07-20 03:49:12 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:49:12 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:49:12 --> Utf8 Class Initialized
INFO - 2016-07-20 03:49:12 --> URI Class Initialized
INFO - 2016-07-20 03:49:12 --> Router Class Initialized
INFO - 2016-07-20 03:49:12 --> Output Class Initialized
INFO - 2016-07-20 03:49:12 --> Security Class Initialized
DEBUG - 2016-07-20 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:49:12 --> Input Class Initialized
INFO - 2016-07-20 03:49:12 --> Language Class Initialized
INFO - 2016-07-20 03:49:12 --> Loader Class Initialized
INFO - 2016-07-20 03:49:12 --> Helper loaded: url_helper
INFO - 2016-07-20 03:49:12 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:49:12 --> Helper loaded: html_helper
INFO - 2016-07-20 03:49:12 --> Helper loaded: form_helper
INFO - 2016-07-20 03:49:12 --> Helper loaded: file_helper
INFO - 2016-07-20 03:49:12 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:49:12 --> Database Driver Class Initialized
INFO - 2016-07-20 03:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:49:12 --> Form Validation Class Initialized
INFO - 2016-07-20 03:49:12 --> Email Class Initialized
INFO - 2016-07-20 03:49:12 --> Controller Class Initialized
DEBUG - 2016-07-20 03:49:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:49:12 --> Model Class Initialized
INFO - 2016-07-20 03:49:12 --> Model Class Initialized
INFO - 2016-07-20 03:49:12 --> Final output sent to browser
DEBUG - 2016-07-20 03:49:12 --> Total execution time: 0.4559
INFO - 2016-07-20 03:53:46 --> Config Class Initialized
INFO - 2016-07-20 03:53:46 --> Hooks Class Initialized
DEBUG - 2016-07-20 03:53:46 --> UTF-8 Support Enabled
INFO - 2016-07-20 03:53:46 --> Utf8 Class Initialized
INFO - 2016-07-20 03:53:46 --> URI Class Initialized
INFO - 2016-07-20 03:53:46 --> Router Class Initialized
INFO - 2016-07-20 03:53:46 --> Output Class Initialized
INFO - 2016-07-20 03:53:46 --> Security Class Initialized
DEBUG - 2016-07-20 03:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 03:53:46 --> Input Class Initialized
INFO - 2016-07-20 03:53:46 --> Language Class Initialized
INFO - 2016-07-20 03:53:46 --> Loader Class Initialized
INFO - 2016-07-20 03:53:46 --> Helper loaded: url_helper
INFO - 2016-07-20 03:53:46 --> Helper loaded: utils_helper
INFO - 2016-07-20 03:53:46 --> Helper loaded: html_helper
INFO - 2016-07-20 03:53:46 --> Helper loaded: form_helper
INFO - 2016-07-20 03:53:46 --> Helper loaded: file_helper
INFO - 2016-07-20 03:53:46 --> Helper loaded: myemail_helper
INFO - 2016-07-20 03:53:46 --> Database Driver Class Initialized
INFO - 2016-07-20 03:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 03:53:46 --> Form Validation Class Initialized
INFO - 2016-07-20 03:53:46 --> Email Class Initialized
INFO - 2016-07-20 03:53:46 --> Controller Class Initialized
DEBUG - 2016-07-20 03:53:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 03:53:46 --> Model Class Initialized
INFO - 2016-07-20 03:53:46 --> Model Class Initialized
INFO - 2016-07-20 03:53:46 --> Final output sent to browser
DEBUG - 2016-07-20 03:53:46 --> Total execution time: 0.3999
INFO - 2016-07-20 09:33:01 --> Config Class Initialized
INFO - 2016-07-20 09:33:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:01 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:01 --> URI Class Initialized
INFO - 2016-07-20 09:33:01 --> Router Class Initialized
INFO - 2016-07-20 09:33:01 --> Output Class Initialized
INFO - 2016-07-20 09:33:01 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:01 --> Input Class Initialized
INFO - 2016-07-20 09:33:01 --> Language Class Initialized
INFO - 2016-07-20 09:33:01 --> Loader Class Initialized
INFO - 2016-07-20 09:33:01 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:01 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:01 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:01 --> Email Class Initialized
INFO - 2016-07-20 09:33:01 --> Controller Class Initialized
INFO - 2016-07-20 09:33:01 --> Config Class Initialized
INFO - 2016-07-20 09:33:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:01 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:01 --> URI Class Initialized
INFO - 2016-07-20 09:33:01 --> Router Class Initialized
INFO - 2016-07-20 09:33:01 --> Output Class Initialized
INFO - 2016-07-20 09:33:01 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:01 --> Input Class Initialized
INFO - 2016-07-20 09:33:01 --> Language Class Initialized
INFO - 2016-07-20 09:33:01 --> Loader Class Initialized
INFO - 2016-07-20 09:33:01 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:01 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:01 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:01 --> Email Class Initialized
INFO - 2016-07-20 09:33:01 --> Controller Class Initialized
INFO - 2016-07-20 09:33:01 --> Model Class Initialized
DEBUG - 2016-07-20 09:33:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 09:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 09:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:33:02 --> Final output sent to browser
DEBUG - 2016-07-20 09:33:02 --> Total execution time: 0.8301
INFO - 2016-07-20 09:33:08 --> Config Class Initialized
INFO - 2016-07-20 09:33:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:08 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:08 --> URI Class Initialized
INFO - 2016-07-20 09:33:08 --> Router Class Initialized
INFO - 2016-07-20 09:33:08 --> Output Class Initialized
INFO - 2016-07-20 09:33:08 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:08 --> Input Class Initialized
INFO - 2016-07-20 09:33:08 --> Language Class Initialized
INFO - 2016-07-20 09:33:08 --> Loader Class Initialized
INFO - 2016-07-20 09:33:08 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:08 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:08 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:08 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:08 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:08 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:08 --> Email Class Initialized
INFO - 2016-07-20 09:33:08 --> Controller Class Initialized
INFO - 2016-07-20 09:33:08 --> Model Class Initialized
DEBUG - 2016-07-20 09:33:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:33:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 09:33:09 --> Config Class Initialized
INFO - 2016-07-20 09:33:09 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:09 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:09 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:09 --> URI Class Initialized
INFO - 2016-07-20 09:33:09 --> Router Class Initialized
INFO - 2016-07-20 09:33:09 --> Output Class Initialized
INFO - 2016-07-20 09:33:09 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:09 --> Input Class Initialized
INFO - 2016-07-20 09:33:09 --> Language Class Initialized
INFO - 2016-07-20 09:33:09 --> Loader Class Initialized
INFO - 2016-07-20 09:33:09 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:09 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:09 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:09 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:09 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:09 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:09 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:09 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:09 --> Email Class Initialized
INFO - 2016-07-20 09:33:09 --> Controller Class Initialized
DEBUG - 2016-07-20 09:33:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:33:09 --> Model Class Initialized
INFO - 2016-07-20 09:33:09 --> Model Class Initialized
INFO - 2016-07-20 09:33:09 --> Final output sent to browser
DEBUG - 2016-07-20 09:33:09 --> Total execution time: 0.4136
INFO - 2016-07-20 09:33:18 --> Config Class Initialized
INFO - 2016-07-20 09:33:18 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:18 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:18 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:18 --> URI Class Initialized
INFO - 2016-07-20 09:33:18 --> Router Class Initialized
INFO - 2016-07-20 09:33:18 --> Output Class Initialized
INFO - 2016-07-20 09:33:18 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:18 --> Input Class Initialized
INFO - 2016-07-20 09:33:18 --> Language Class Initialized
INFO - 2016-07-20 09:33:18 --> Loader Class Initialized
INFO - 2016-07-20 09:33:18 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:18 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:18 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:18 --> Email Class Initialized
INFO - 2016-07-20 09:33:18 --> Controller Class Initialized
INFO - 2016-07-20 09:33:18 --> Model Class Initialized
DEBUG - 2016-07-20 09:33:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:33:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 09:33:18 --> Config Class Initialized
INFO - 2016-07-20 09:33:18 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:33:18 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:33:18 --> Utf8 Class Initialized
INFO - 2016-07-20 09:33:18 --> URI Class Initialized
INFO - 2016-07-20 09:33:18 --> Router Class Initialized
INFO - 2016-07-20 09:33:18 --> Output Class Initialized
INFO - 2016-07-20 09:33:18 --> Security Class Initialized
DEBUG - 2016-07-20 09:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:33:18 --> Input Class Initialized
INFO - 2016-07-20 09:33:18 --> Language Class Initialized
INFO - 2016-07-20 09:33:18 --> Loader Class Initialized
INFO - 2016-07-20 09:33:18 --> Helper loaded: url_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: html_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: form_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: file_helper
INFO - 2016-07-20 09:33:18 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:33:18 --> Database Driver Class Initialized
INFO - 2016-07-20 09:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:33:18 --> Form Validation Class Initialized
INFO - 2016-07-20 09:33:18 --> Email Class Initialized
INFO - 2016-07-20 09:33:18 --> Controller Class Initialized
DEBUG - 2016-07-20 09:33:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:33:18 --> Model Class Initialized
INFO - 2016-07-20 09:33:18 --> Model Class Initialized
INFO - 2016-07-20 09:33:18 --> Final output sent to browser
DEBUG - 2016-07-20 09:33:18 --> Total execution time: 0.3795
INFO - 2016-07-20 09:35:08 --> Config Class Initialized
INFO - 2016-07-20 09:35:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:35:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:35:08 --> Utf8 Class Initialized
INFO - 2016-07-20 09:35:08 --> URI Class Initialized
INFO - 2016-07-20 09:35:08 --> Router Class Initialized
INFO - 2016-07-20 09:35:08 --> Output Class Initialized
INFO - 2016-07-20 09:35:08 --> Security Class Initialized
DEBUG - 2016-07-20 09:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:35:08 --> Input Class Initialized
INFO - 2016-07-20 09:35:08 --> Language Class Initialized
INFO - 2016-07-20 09:35:08 --> Loader Class Initialized
INFO - 2016-07-20 09:35:08 --> Helper loaded: url_helper
INFO - 2016-07-20 09:35:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:35:08 --> Helper loaded: html_helper
INFO - 2016-07-20 09:35:08 --> Helper loaded: form_helper
INFO - 2016-07-20 09:35:08 --> Helper loaded: file_helper
INFO - 2016-07-20 09:35:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:35:08 --> Database Driver Class Initialized
INFO - 2016-07-20 09:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:35:08 --> Form Validation Class Initialized
INFO - 2016-07-20 09:35:08 --> Email Class Initialized
INFO - 2016-07-20 09:35:08 --> Controller Class Initialized
INFO - 2016-07-20 09:35:08 --> Model Class Initialized
DEBUG - 2016-07-20 09:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 09:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 09:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:35:08 --> Final output sent to browser
DEBUG - 2016-07-20 09:35:08 --> Total execution time: 0.2846
INFO - 2016-07-20 09:35:10 --> Config Class Initialized
INFO - 2016-07-20 09:35:10 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:35:10 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:35:10 --> Utf8 Class Initialized
INFO - 2016-07-20 09:35:10 --> URI Class Initialized
INFO - 2016-07-20 09:35:10 --> Router Class Initialized
INFO - 2016-07-20 09:35:10 --> Output Class Initialized
INFO - 2016-07-20 09:35:10 --> Security Class Initialized
DEBUG - 2016-07-20 09:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:35:10 --> Input Class Initialized
INFO - 2016-07-20 09:35:10 --> Language Class Initialized
INFO - 2016-07-20 09:35:10 --> Loader Class Initialized
INFO - 2016-07-20 09:35:10 --> Helper loaded: url_helper
INFO - 2016-07-20 09:35:10 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:35:10 --> Helper loaded: html_helper
INFO - 2016-07-20 09:35:10 --> Helper loaded: form_helper
INFO - 2016-07-20 09:35:10 --> Helper loaded: file_helper
INFO - 2016-07-20 09:35:10 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:35:10 --> Database Driver Class Initialized
INFO - 2016-07-20 09:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:35:10 --> Form Validation Class Initialized
INFO - 2016-07-20 09:35:10 --> Email Class Initialized
INFO - 2016-07-20 09:35:10 --> Controller Class Initialized
INFO - 2016-07-20 09:35:10 --> Model Class Initialized
DEBUG - 2016-07-20 09:35:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:35:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 09:35:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 09:35:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:35:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 09:35:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:35:10 --> Final output sent to browser
DEBUG - 2016-07-20 09:35:10 --> Total execution time: 0.2934
INFO - 2016-07-20 09:35:16 --> Config Class Initialized
INFO - 2016-07-20 09:35:16 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:35:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:35:16 --> Utf8 Class Initialized
INFO - 2016-07-20 09:35:16 --> URI Class Initialized
INFO - 2016-07-20 09:35:16 --> Router Class Initialized
INFO - 2016-07-20 09:35:16 --> Output Class Initialized
INFO - 2016-07-20 09:35:16 --> Security Class Initialized
DEBUG - 2016-07-20 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:35:16 --> Input Class Initialized
INFO - 2016-07-20 09:35:16 --> Language Class Initialized
INFO - 2016-07-20 09:35:16 --> Loader Class Initialized
INFO - 2016-07-20 09:35:16 --> Helper loaded: url_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: html_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: form_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: file_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:35:16 --> Database Driver Class Initialized
INFO - 2016-07-20 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:35:16 --> Form Validation Class Initialized
INFO - 2016-07-20 09:35:16 --> Email Class Initialized
INFO - 2016-07-20 09:35:16 --> Controller Class Initialized
INFO - 2016-07-20 09:35:16 --> Model Class Initialized
DEBUG - 2016-07-20 09:35:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:35:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 09:35:16 --> Config Class Initialized
INFO - 2016-07-20 09:35:16 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:35:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:35:16 --> Utf8 Class Initialized
INFO - 2016-07-20 09:35:16 --> URI Class Initialized
INFO - 2016-07-20 09:35:16 --> Router Class Initialized
INFO - 2016-07-20 09:35:16 --> Output Class Initialized
INFO - 2016-07-20 09:35:16 --> Security Class Initialized
DEBUG - 2016-07-20 09:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:35:16 --> Input Class Initialized
INFO - 2016-07-20 09:35:16 --> Language Class Initialized
INFO - 2016-07-20 09:35:16 --> Loader Class Initialized
INFO - 2016-07-20 09:35:16 --> Helper loaded: url_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: html_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: form_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: file_helper
INFO - 2016-07-20 09:35:16 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:35:16 --> Database Driver Class Initialized
INFO - 2016-07-20 09:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:35:16 --> Form Validation Class Initialized
INFO - 2016-07-20 09:35:16 --> Email Class Initialized
INFO - 2016-07-20 09:35:16 --> Controller Class Initialized
DEBUG - 2016-07-20 09:35:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:35:17 --> Model Class Initialized
INFO - 2016-07-20 09:35:17 --> Model Class Initialized
INFO - 2016-07-20 09:35:17 --> Final output sent to browser
DEBUG - 2016-07-20 09:35:17 --> Total execution time: 0.4024
INFO - 2016-07-20 09:37:27 --> Config Class Initialized
INFO - 2016-07-20 09:37:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:37:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:37:27 --> Utf8 Class Initialized
INFO - 2016-07-20 09:37:27 --> URI Class Initialized
INFO - 2016-07-20 09:37:27 --> Router Class Initialized
INFO - 2016-07-20 09:37:27 --> Output Class Initialized
INFO - 2016-07-20 09:37:27 --> Security Class Initialized
DEBUG - 2016-07-20 09:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:37:27 --> Input Class Initialized
INFO - 2016-07-20 09:37:27 --> Language Class Initialized
INFO - 2016-07-20 09:37:27 --> Loader Class Initialized
INFO - 2016-07-20 09:37:27 --> Helper loaded: url_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: html_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: form_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: file_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:37:27 --> Database Driver Class Initialized
INFO - 2016-07-20 09:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:37:27 --> Form Validation Class Initialized
INFO - 2016-07-20 09:37:27 --> Email Class Initialized
INFO - 2016-07-20 09:37:27 --> Controller Class Initialized
INFO - 2016-07-20 09:37:27 --> Model Class Initialized
DEBUG - 2016-07-20 09:37:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:37:27 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 09:37:27 --> Config Class Initialized
INFO - 2016-07-20 09:37:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:37:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:37:27 --> Utf8 Class Initialized
INFO - 2016-07-20 09:37:27 --> URI Class Initialized
INFO - 2016-07-20 09:37:27 --> Router Class Initialized
INFO - 2016-07-20 09:37:27 --> Output Class Initialized
INFO - 2016-07-20 09:37:27 --> Security Class Initialized
DEBUG - 2016-07-20 09:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:37:27 --> Input Class Initialized
INFO - 2016-07-20 09:37:27 --> Language Class Initialized
INFO - 2016-07-20 09:37:27 --> Loader Class Initialized
INFO - 2016-07-20 09:37:27 --> Helper loaded: url_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: html_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: form_helper
INFO - 2016-07-20 09:37:27 --> Helper loaded: file_helper
INFO - 2016-07-20 09:37:28 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:37:28 --> Database Driver Class Initialized
INFO - 2016-07-20 09:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:37:28 --> Form Validation Class Initialized
INFO - 2016-07-20 09:37:28 --> Email Class Initialized
INFO - 2016-07-20 09:37:28 --> Controller Class Initialized
DEBUG - 2016-07-20 09:37:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:37:28 --> Model Class Initialized
INFO - 2016-07-20 09:37:28 --> Model Class Initialized
INFO - 2016-07-20 09:37:28 --> Final output sent to browser
DEBUG - 2016-07-20 09:37:28 --> Total execution time: 0.4061
INFO - 2016-07-20 09:37:41 --> Config Class Initialized
INFO - 2016-07-20 09:37:41 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:37:41 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:37:41 --> Utf8 Class Initialized
INFO - 2016-07-20 09:37:41 --> URI Class Initialized
INFO - 2016-07-20 09:37:41 --> Router Class Initialized
INFO - 2016-07-20 09:37:41 --> Output Class Initialized
INFO - 2016-07-20 09:37:41 --> Security Class Initialized
DEBUG - 2016-07-20 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:37:41 --> Input Class Initialized
INFO - 2016-07-20 09:37:41 --> Language Class Initialized
INFO - 2016-07-20 09:37:41 --> Loader Class Initialized
INFO - 2016-07-20 09:37:41 --> Helper loaded: url_helper
INFO - 2016-07-20 09:37:41 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:37:41 --> Helper loaded: html_helper
INFO - 2016-07-20 09:37:41 --> Helper loaded: form_helper
INFO - 2016-07-20 09:37:41 --> Helper loaded: file_helper
INFO - 2016-07-20 09:37:41 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:37:41 --> Database Driver Class Initialized
INFO - 2016-07-20 09:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:37:41 --> Form Validation Class Initialized
INFO - 2016-07-20 09:37:41 --> Email Class Initialized
INFO - 2016-07-20 09:37:41 --> Controller Class Initialized
DEBUG - 2016-07-20 09:37:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:37:41 --> Model Class Initialized
INFO - 2016-07-20 09:37:41 --> Model Class Initialized
INFO - 2016-07-20 09:37:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:37:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:37:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:37:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:37:41 --> Final output sent to browser
DEBUG - 2016-07-20 09:37:41 --> Total execution time: 0.3856
INFO - 2016-07-20 09:41:22 --> Config Class Initialized
INFO - 2016-07-20 09:41:22 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:41:22 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:41:22 --> Utf8 Class Initialized
INFO - 2016-07-20 09:41:22 --> URI Class Initialized
INFO - 2016-07-20 09:41:22 --> Router Class Initialized
INFO - 2016-07-20 09:41:22 --> Output Class Initialized
INFO - 2016-07-20 09:41:22 --> Security Class Initialized
DEBUG - 2016-07-20 09:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:41:22 --> Input Class Initialized
INFO - 2016-07-20 09:41:22 --> Language Class Initialized
INFO - 2016-07-20 09:41:22 --> Loader Class Initialized
INFO - 2016-07-20 09:41:22 --> Helper loaded: url_helper
INFO - 2016-07-20 09:41:22 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:41:22 --> Helper loaded: html_helper
INFO - 2016-07-20 09:41:22 --> Helper loaded: form_helper
INFO - 2016-07-20 09:41:22 --> Helper loaded: file_helper
INFO - 2016-07-20 09:41:22 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:41:22 --> Database Driver Class Initialized
INFO - 2016-07-20 09:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:41:22 --> Form Validation Class Initialized
INFO - 2016-07-20 09:41:22 --> Email Class Initialized
INFO - 2016-07-20 09:41:22 --> Controller Class Initialized
DEBUG - 2016-07-20 09:41:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:41:22 --> Model Class Initialized
INFO - 2016-07-20 09:41:22 --> Model Class Initialized
INFO - 2016-07-20 09:41:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:41:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:41:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:41:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:41:22 --> Final output sent to browser
DEBUG - 2016-07-20 09:41:22 --> Total execution time: 0.3356
INFO - 2016-07-20 09:41:46 --> Config Class Initialized
INFO - 2016-07-20 09:41:46 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:41:46 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:41:46 --> Utf8 Class Initialized
INFO - 2016-07-20 09:41:46 --> URI Class Initialized
INFO - 2016-07-20 09:41:46 --> Router Class Initialized
INFO - 2016-07-20 09:41:46 --> Output Class Initialized
INFO - 2016-07-20 09:41:46 --> Security Class Initialized
DEBUG - 2016-07-20 09:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:41:46 --> Input Class Initialized
INFO - 2016-07-20 09:41:46 --> Language Class Initialized
INFO - 2016-07-20 09:41:46 --> Loader Class Initialized
INFO - 2016-07-20 09:41:46 --> Helper loaded: url_helper
INFO - 2016-07-20 09:41:46 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:41:46 --> Helper loaded: html_helper
INFO - 2016-07-20 09:41:46 --> Helper loaded: form_helper
INFO - 2016-07-20 09:41:46 --> Helper loaded: file_helper
INFO - 2016-07-20 09:41:46 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:41:46 --> Database Driver Class Initialized
INFO - 2016-07-20 09:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:41:46 --> Form Validation Class Initialized
INFO - 2016-07-20 09:41:46 --> Email Class Initialized
INFO - 2016-07-20 09:41:46 --> Controller Class Initialized
DEBUG - 2016-07-20 09:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:41:46 --> Model Class Initialized
INFO - 2016-07-20 09:41:46 --> Model Class Initialized
INFO - 2016-07-20 09:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:41:46 --> Final output sent to browser
DEBUG - 2016-07-20 09:41:46 --> Total execution time: 0.3040
INFO - 2016-07-20 09:41:52 --> Config Class Initialized
INFO - 2016-07-20 09:41:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:41:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:41:52 --> Config Class Initialized
INFO - 2016-07-20 09:41:52 --> Hooks Class Initialized
INFO - 2016-07-20 09:41:52 --> Utf8 Class Initialized
INFO - 2016-07-20 09:41:52 --> URI Class Initialized
DEBUG - 2016-07-20 09:41:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:41:52 --> Utf8 Class Initialized
INFO - 2016-07-20 09:41:52 --> Router Class Initialized
INFO - 2016-07-20 09:41:52 --> URI Class Initialized
INFO - 2016-07-20 09:41:52 --> Output Class Initialized
INFO - 2016-07-20 09:41:52 --> Security Class Initialized
INFO - 2016-07-20 09:41:52 --> Router Class Initialized
DEBUG - 2016-07-20 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:41:52 --> Output Class Initialized
INFO - 2016-07-20 09:41:52 --> Input Class Initialized
INFO - 2016-07-20 09:41:52 --> Security Class Initialized
INFO - 2016-07-20 09:41:52 --> Language Class Initialized
DEBUG - 2016-07-20 09:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:41:52 --> Input Class Initialized
INFO - 2016-07-20 09:41:52 --> Loader Class Initialized
INFO - 2016-07-20 09:41:52 --> Language Class Initialized
INFO - 2016-07-20 09:41:52 --> Helper loaded: url_helper
INFO - 2016-07-20 09:41:52 --> Helper loaded: utils_helper
ERROR - 2016-07-20 09:41:52 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:41:52 --> Helper loaded: html_helper
INFO - 2016-07-20 09:41:52 --> Helper loaded: form_helper
INFO - 2016-07-20 09:41:52 --> Helper loaded: file_helper
INFO - 2016-07-20 09:41:52 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:41:52 --> Database Driver Class Initialized
INFO - 2016-07-20 09:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:41:52 --> Form Validation Class Initialized
INFO - 2016-07-20 09:41:52 --> Email Class Initialized
INFO - 2016-07-20 09:41:52 --> Controller Class Initialized
DEBUG - 2016-07-20 09:41:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:41:52 --> Model Class Initialized
INFO - 2016-07-20 09:41:52 --> Model Class Initialized
INFO - 2016-07-20 09:41:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:41:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:41:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:41:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:41:52 --> Final output sent to browser
DEBUG - 2016-07-20 09:41:52 --> Total execution time: 0.3987
INFO - 2016-07-20 09:42:30 --> Config Class Initialized
INFO - 2016-07-20 09:42:30 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:42:30 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:30 --> Utf8 Class Initialized
INFO - 2016-07-20 09:42:30 --> URI Class Initialized
INFO - 2016-07-20 09:42:30 --> Router Class Initialized
INFO - 2016-07-20 09:42:30 --> Output Class Initialized
INFO - 2016-07-20 09:42:30 --> Security Class Initialized
DEBUG - 2016-07-20 09:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:30 --> Input Class Initialized
INFO - 2016-07-20 09:42:30 --> Language Class Initialized
INFO - 2016-07-20 09:42:30 --> Loader Class Initialized
INFO - 2016-07-20 09:42:30 --> Helper loaded: url_helper
INFO - 2016-07-20 09:42:30 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:42:31 --> Helper loaded: html_helper
INFO - 2016-07-20 09:42:31 --> Helper loaded: form_helper
INFO - 2016-07-20 09:42:31 --> Helper loaded: file_helper
INFO - 2016-07-20 09:42:31 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:42:31 --> Database Driver Class Initialized
INFO - 2016-07-20 09:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:42:31 --> Form Validation Class Initialized
INFO - 2016-07-20 09:42:31 --> Email Class Initialized
INFO - 2016-07-20 09:42:31 --> Controller Class Initialized
DEBUG - 2016-07-20 09:42:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:42:31 --> Model Class Initialized
INFO - 2016-07-20 09:42:31 --> Model Class Initialized
INFO - 2016-07-20 09:42:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:42:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:42:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:42:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:42:31 --> Final output sent to browser
DEBUG - 2016-07-20 09:42:31 --> Total execution time: 0.2926
INFO - 2016-07-20 09:42:32 --> Config Class Initialized
INFO - 2016-07-20 09:42:32 --> Hooks Class Initialized
INFO - 2016-07-20 09:42:32 --> Config Class Initialized
INFO - 2016-07-20 09:42:32 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:42:32 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:32 --> Utf8 Class Initialized
DEBUG - 2016-07-20 09:42:32 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:32 --> URI Class Initialized
INFO - 2016-07-20 09:42:32 --> Router Class Initialized
INFO - 2016-07-20 09:42:32 --> Output Class Initialized
INFO - 2016-07-20 09:42:32 --> Security Class Initialized
DEBUG - 2016-07-20 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:32 --> Input Class Initialized
INFO - 2016-07-20 09:42:32 --> Language Class Initialized
INFO - 2016-07-20 09:42:32 --> Utf8 Class Initialized
INFO - 2016-07-20 09:42:32 --> Loader Class Initialized
INFO - 2016-07-20 09:42:32 --> URI Class Initialized
INFO - 2016-07-20 09:42:32 --> Helper loaded: url_helper
INFO - 2016-07-20 09:42:32 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:42:32 --> Router Class Initialized
INFO - 2016-07-20 09:42:32 --> Helper loaded: html_helper
INFO - 2016-07-20 09:42:32 --> Output Class Initialized
INFO - 2016-07-20 09:42:32 --> Security Class Initialized
INFO - 2016-07-20 09:42:32 --> Helper loaded: form_helper
DEBUG - 2016-07-20 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:32 --> Input Class Initialized
INFO - 2016-07-20 09:42:32 --> Language Class Initialized
ERROR - 2016-07-20 09:42:32 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:42:32 --> Helper loaded: file_helper
INFO - 2016-07-20 09:42:32 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:42:32 --> Database Driver Class Initialized
INFO - 2016-07-20 09:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:42:32 --> Form Validation Class Initialized
INFO - 2016-07-20 09:42:32 --> Email Class Initialized
INFO - 2016-07-20 09:42:32 --> Controller Class Initialized
DEBUG - 2016-07-20 09:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:42:32 --> Model Class Initialized
INFO - 2016-07-20 09:42:33 --> Model Class Initialized
INFO - 2016-07-20 09:42:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:42:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:42:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:42:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:42:33 --> Final output sent to browser
DEBUG - 2016-07-20 09:42:33 --> Total execution time: 0.7329
INFO - 2016-07-20 09:42:34 --> Config Class Initialized
INFO - 2016-07-20 09:42:34 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:42:34 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:34 --> Utf8 Class Initialized
INFO - 2016-07-20 09:42:34 --> URI Class Initialized
INFO - 2016-07-20 09:42:34 --> Router Class Initialized
INFO - 2016-07-20 09:42:34 --> Output Class Initialized
INFO - 2016-07-20 09:42:34 --> Security Class Initialized
DEBUG - 2016-07-20 09:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:34 --> Input Class Initialized
INFO - 2016-07-20 09:42:34 --> Language Class Initialized
INFO - 2016-07-20 09:42:34 --> Loader Class Initialized
INFO - 2016-07-20 09:42:34 --> Helper loaded: url_helper
INFO - 2016-07-20 09:42:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:42:35 --> Helper loaded: html_helper
INFO - 2016-07-20 09:42:35 --> Helper loaded: form_helper
INFO - 2016-07-20 09:42:35 --> Helper loaded: file_helper
INFO - 2016-07-20 09:42:35 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:42:35 --> Database Driver Class Initialized
INFO - 2016-07-20 09:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:42:35 --> Form Validation Class Initialized
INFO - 2016-07-20 09:42:35 --> Email Class Initialized
INFO - 2016-07-20 09:42:35 --> Controller Class Initialized
DEBUG - 2016-07-20 09:42:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:42:35 --> Model Class Initialized
INFO - 2016-07-20 09:42:35 --> Model Class Initialized
INFO - 2016-07-20 09:42:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:42:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:42:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:42:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:42:35 --> Final output sent to browser
DEBUG - 2016-07-20 09:42:35 --> Total execution time: 0.3102
INFO - 2016-07-20 09:42:36 --> Config Class Initialized
INFO - 2016-07-20 09:42:36 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:42:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:36 --> Utf8 Class Initialized
INFO - 2016-07-20 09:42:37 --> Config Class Initialized
INFO - 2016-07-20 09:42:37 --> Hooks Class Initialized
INFO - 2016-07-20 09:42:37 --> URI Class Initialized
INFO - 2016-07-20 09:42:37 --> Router Class Initialized
DEBUG - 2016-07-20 09:42:37 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:42:37 --> Utf8 Class Initialized
INFO - 2016-07-20 09:42:37 --> Output Class Initialized
INFO - 2016-07-20 09:42:37 --> URI Class Initialized
INFO - 2016-07-20 09:42:37 --> Security Class Initialized
DEBUG - 2016-07-20 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:37 --> Input Class Initialized
INFO - 2016-07-20 09:42:37 --> Language Class Initialized
INFO - 2016-07-20 09:42:37 --> Loader Class Initialized
INFO - 2016-07-20 09:42:37 --> Router Class Initialized
INFO - 2016-07-20 09:42:37 --> Helper loaded: url_helper
INFO - 2016-07-20 09:42:37 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:42:37 --> Helper loaded: html_helper
INFO - 2016-07-20 09:42:37 --> Helper loaded: form_helper
INFO - 2016-07-20 09:42:37 --> Output Class Initialized
INFO - 2016-07-20 09:42:37 --> Helper loaded: file_helper
INFO - 2016-07-20 09:42:37 --> Security Class Initialized
INFO - 2016-07-20 09:42:37 --> Helper loaded: myemail_helper
DEBUG - 2016-07-20 09:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:42:37 --> Database Driver Class Initialized
INFO - 2016-07-20 09:42:37 --> Input Class Initialized
INFO - 2016-07-20 09:42:37 --> Language Class Initialized
INFO - 2016-07-20 09:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:42:37 --> Form Validation Class Initialized
INFO - 2016-07-20 09:42:37 --> Email Class Initialized
INFO - 2016-07-20 09:42:37 --> Controller Class Initialized
DEBUG - 2016-07-20 09:42:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2016-07-20 09:42:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:42:37 --> Model Class Initialized
INFO - 2016-07-20 09:42:37 --> Model Class Initialized
INFO - 2016-07-20 09:42:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:42:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:42:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:42:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:42:37 --> Final output sent to browser
DEBUG - 2016-07-20 09:42:37 --> Total execution time: 0.6571
INFO - 2016-07-20 09:43:23 --> Config Class Initialized
INFO - 2016-07-20 09:43:23 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:43:23 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:43:23 --> Utf8 Class Initialized
INFO - 2016-07-20 09:43:23 --> URI Class Initialized
INFO - 2016-07-20 09:43:23 --> Router Class Initialized
INFO - 2016-07-20 09:43:23 --> Output Class Initialized
INFO - 2016-07-20 09:43:23 --> Security Class Initialized
DEBUG - 2016-07-20 09:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:43:23 --> Input Class Initialized
INFO - 2016-07-20 09:43:23 --> Language Class Initialized
INFO - 2016-07-20 09:43:23 --> Loader Class Initialized
INFO - 2016-07-20 09:43:23 --> Helper loaded: url_helper
INFO - 2016-07-20 09:43:23 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:43:23 --> Helper loaded: html_helper
INFO - 2016-07-20 09:43:23 --> Helper loaded: form_helper
INFO - 2016-07-20 09:43:23 --> Helper loaded: file_helper
INFO - 2016-07-20 09:43:23 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:43:24 --> Database Driver Class Initialized
INFO - 2016-07-20 09:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:43:24 --> Form Validation Class Initialized
INFO - 2016-07-20 09:43:24 --> Email Class Initialized
INFO - 2016-07-20 09:43:24 --> Controller Class Initialized
DEBUG - 2016-07-20 09:43:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:43:24 --> Model Class Initialized
INFO - 2016-07-20 09:43:24 --> Model Class Initialized
INFO - 2016-07-20 09:43:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:43:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:43:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:43:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:43:24 --> Final output sent to browser
DEBUG - 2016-07-20 09:43:24 --> Total execution time: 0.3312
INFO - 2016-07-20 09:43:25 --> Config Class Initialized
INFO - 2016-07-20 09:43:25 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:43:25 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:43:25 --> Config Class Initialized
INFO - 2016-07-20 09:43:25 --> Hooks Class Initialized
INFO - 2016-07-20 09:43:25 --> Utf8 Class Initialized
INFO - 2016-07-20 09:43:25 --> URI Class Initialized
DEBUG - 2016-07-20 09:43:25 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:43:25 --> Utf8 Class Initialized
INFO - 2016-07-20 09:43:25 --> Router Class Initialized
INFO - 2016-07-20 09:43:25 --> URI Class Initialized
INFO - 2016-07-20 09:43:25 --> Output Class Initialized
INFO - 2016-07-20 09:43:25 --> Security Class Initialized
INFO - 2016-07-20 09:43:25 --> Router Class Initialized
DEBUG - 2016-07-20 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:43:25 --> Output Class Initialized
INFO - 2016-07-20 09:43:25 --> Input Class Initialized
INFO - 2016-07-20 09:43:25 --> Security Class Initialized
INFO - 2016-07-20 09:43:25 --> Language Class Initialized
DEBUG - 2016-07-20 09:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:43:25 --> Input Class Initialized
INFO - 2016-07-20 09:43:25 --> Loader Class Initialized
INFO - 2016-07-20 09:43:25 --> Language Class Initialized
INFO - 2016-07-20 09:43:25 --> Helper loaded: url_helper
INFO - 2016-07-20 09:43:25 --> Helper loaded: utils_helper
ERROR - 2016-07-20 09:43:25 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:43:25 --> Helper loaded: html_helper
INFO - 2016-07-20 09:43:25 --> Helper loaded: form_helper
INFO - 2016-07-20 09:43:25 --> Helper loaded: file_helper
INFO - 2016-07-20 09:43:25 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:43:25 --> Database Driver Class Initialized
INFO - 2016-07-20 09:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:43:25 --> Form Validation Class Initialized
INFO - 2016-07-20 09:43:25 --> Email Class Initialized
INFO - 2016-07-20 09:43:25 --> Controller Class Initialized
DEBUG - 2016-07-20 09:43:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:43:25 --> Model Class Initialized
INFO - 2016-07-20 09:43:25 --> Model Class Initialized
INFO - 2016-07-20 09:43:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:43:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:43:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:43:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:43:26 --> Final output sent to browser
DEBUG - 2016-07-20 09:43:26 --> Total execution time: 0.5982
INFO - 2016-07-20 09:45:11 --> Config Class Initialized
INFO - 2016-07-20 09:45:11 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:45:11 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:11 --> Utf8 Class Initialized
INFO - 2016-07-20 09:45:11 --> URI Class Initialized
INFO - 2016-07-20 09:45:11 --> Router Class Initialized
INFO - 2016-07-20 09:45:11 --> Output Class Initialized
INFO - 2016-07-20 09:45:11 --> Security Class Initialized
DEBUG - 2016-07-20 09:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:11 --> Input Class Initialized
INFO - 2016-07-20 09:45:11 --> Language Class Initialized
INFO - 2016-07-20 09:45:11 --> Loader Class Initialized
INFO - 2016-07-20 09:45:11 --> Helper loaded: url_helper
INFO - 2016-07-20 09:45:11 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:45:11 --> Helper loaded: html_helper
INFO - 2016-07-20 09:45:11 --> Helper loaded: form_helper
INFO - 2016-07-20 09:45:11 --> Helper loaded: file_helper
INFO - 2016-07-20 09:45:11 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:45:11 --> Database Driver Class Initialized
INFO - 2016-07-20 09:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:45:11 --> Form Validation Class Initialized
INFO - 2016-07-20 09:45:11 --> Email Class Initialized
INFO - 2016-07-20 09:45:11 --> Controller Class Initialized
DEBUG - 2016-07-20 09:45:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:45:11 --> Model Class Initialized
INFO - 2016-07-20 09:45:11 --> Model Class Initialized
INFO - 2016-07-20 09:45:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:45:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:45:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:45:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:45:11 --> Final output sent to browser
DEBUG - 2016-07-20 09:45:11 --> Total execution time: 0.6194
INFO - 2016-07-20 09:45:12 --> Config Class Initialized
INFO - 2016-07-20 09:45:12 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:45:12 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:12 --> Config Class Initialized
INFO - 2016-07-20 09:45:12 --> Utf8 Class Initialized
INFO - 2016-07-20 09:45:12 --> Hooks Class Initialized
INFO - 2016-07-20 09:45:12 --> URI Class Initialized
INFO - 2016-07-20 09:45:12 --> Router Class Initialized
DEBUG - 2016-07-20 09:45:12 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:13 --> Utf8 Class Initialized
INFO - 2016-07-20 09:45:13 --> Output Class Initialized
INFO - 2016-07-20 09:45:13 --> URI Class Initialized
INFO - 2016-07-20 09:45:13 --> Security Class Initialized
DEBUG - 2016-07-20 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:13 --> Router Class Initialized
INFO - 2016-07-20 09:45:13 --> Input Class Initialized
INFO - 2016-07-20 09:45:13 --> Output Class Initialized
INFO - 2016-07-20 09:45:13 --> Language Class Initialized
INFO - 2016-07-20 09:45:13 --> Security Class Initialized
INFO - 2016-07-20 09:45:13 --> Loader Class Initialized
INFO - 2016-07-20 09:45:13 --> Helper loaded: url_helper
INFO - 2016-07-20 09:45:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:45:13 --> Helper loaded: html_helper
DEBUG - 2016-07-20 09:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:13 --> Helper loaded: form_helper
INFO - 2016-07-20 09:45:13 --> Input Class Initialized
INFO - 2016-07-20 09:45:13 --> Language Class Initialized
ERROR - 2016-07-20 09:45:13 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:45:13 --> Helper loaded: file_helper
INFO - 2016-07-20 09:45:13 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:45:13 --> Database Driver Class Initialized
INFO - 2016-07-20 09:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:45:13 --> Form Validation Class Initialized
INFO - 2016-07-20 09:45:13 --> Email Class Initialized
INFO - 2016-07-20 09:45:13 --> Controller Class Initialized
DEBUG - 2016-07-20 09:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:45:13 --> Model Class Initialized
INFO - 2016-07-20 09:45:13 --> Model Class Initialized
INFO - 2016-07-20 09:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:45:13 --> Final output sent to browser
DEBUG - 2016-07-20 09:45:13 --> Total execution time: 0.6364
INFO - 2016-07-20 09:45:34 --> Config Class Initialized
INFO - 2016-07-20 09:45:34 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:45:34 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:34 --> Utf8 Class Initialized
INFO - 2016-07-20 09:45:34 --> URI Class Initialized
INFO - 2016-07-20 09:45:34 --> Router Class Initialized
INFO - 2016-07-20 09:45:34 --> Output Class Initialized
INFO - 2016-07-20 09:45:34 --> Security Class Initialized
DEBUG - 2016-07-20 09:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:34 --> Input Class Initialized
INFO - 2016-07-20 09:45:34 --> Language Class Initialized
INFO - 2016-07-20 09:45:34 --> Loader Class Initialized
INFO - 2016-07-20 09:45:34 --> Helper loaded: url_helper
INFO - 2016-07-20 09:45:34 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:45:34 --> Helper loaded: html_helper
INFO - 2016-07-20 09:45:34 --> Helper loaded: form_helper
INFO - 2016-07-20 09:45:34 --> Helper loaded: file_helper
INFO - 2016-07-20 09:45:34 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:45:34 --> Database Driver Class Initialized
INFO - 2016-07-20 09:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:45:34 --> Form Validation Class Initialized
INFO - 2016-07-20 09:45:34 --> Email Class Initialized
INFO - 2016-07-20 09:45:34 --> Controller Class Initialized
DEBUG - 2016-07-20 09:45:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:45:34 --> Model Class Initialized
INFO - 2016-07-20 09:45:34 --> Model Class Initialized
INFO - 2016-07-20 09:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:45:34 --> Final output sent to browser
DEBUG - 2016-07-20 09:45:34 --> Total execution time: 0.3167
INFO - 2016-07-20 09:45:36 --> Config Class Initialized
INFO - 2016-07-20 09:45:36 --> Hooks Class Initialized
INFO - 2016-07-20 09:45:36 --> Config Class Initialized
DEBUG - 2016-07-20 09:45:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:36 --> Hooks Class Initialized
INFO - 2016-07-20 09:45:36 --> Utf8 Class Initialized
DEBUG - 2016-07-20 09:45:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:45:36 --> Utf8 Class Initialized
INFO - 2016-07-20 09:45:36 --> URI Class Initialized
INFO - 2016-07-20 09:45:36 --> URI Class Initialized
INFO - 2016-07-20 09:45:36 --> Router Class Initialized
INFO - 2016-07-20 09:45:36 --> Router Class Initialized
INFO - 2016-07-20 09:45:36 --> Output Class Initialized
INFO - 2016-07-20 09:45:36 --> Output Class Initialized
INFO - 2016-07-20 09:45:36 --> Security Class Initialized
DEBUG - 2016-07-20 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:36 --> Input Class Initialized
INFO - 2016-07-20 09:45:36 --> Language Class Initialized
ERROR - 2016-07-20 09:45:36 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:45:36 --> Security Class Initialized
DEBUG - 2016-07-20 09:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:45:36 --> Input Class Initialized
INFO - 2016-07-20 09:45:36 --> Language Class Initialized
INFO - 2016-07-20 09:45:36 --> Loader Class Initialized
INFO - 2016-07-20 09:45:36 --> Helper loaded: url_helper
INFO - 2016-07-20 09:45:36 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:45:36 --> Helper loaded: html_helper
INFO - 2016-07-20 09:45:36 --> Helper loaded: form_helper
INFO - 2016-07-20 09:45:36 --> Helper loaded: file_helper
INFO - 2016-07-20 09:45:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:45:36 --> Database Driver Class Initialized
INFO - 2016-07-20 09:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:45:36 --> Form Validation Class Initialized
INFO - 2016-07-20 09:45:36 --> Email Class Initialized
INFO - 2016-07-20 09:45:36 --> Controller Class Initialized
DEBUG - 2016-07-20 09:45:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:45:36 --> Model Class Initialized
INFO - 2016-07-20 09:45:36 --> Model Class Initialized
INFO - 2016-07-20 09:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:45:36 --> Final output sent to browser
DEBUG - 2016-07-20 09:45:36 --> Total execution time: 0.7964
INFO - 2016-07-20 09:50:34 --> Config Class Initialized
INFO - 2016-07-20 09:50:34 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:50:34 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:50:34 --> Utf8 Class Initialized
INFO - 2016-07-20 09:50:34 --> URI Class Initialized
INFO - 2016-07-20 09:50:34 --> Router Class Initialized
INFO - 2016-07-20 09:50:34 --> Output Class Initialized
INFO - 2016-07-20 09:50:34 --> Security Class Initialized
DEBUG - 2016-07-20 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:50:34 --> Input Class Initialized
INFO - 2016-07-20 09:50:34 --> Language Class Initialized
INFO - 2016-07-20 09:50:34 --> Loader Class Initialized
INFO - 2016-07-20 09:50:34 --> Helper loaded: url_helper
INFO - 2016-07-20 09:50:34 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:50:34 --> Helper loaded: html_helper
INFO - 2016-07-20 09:50:34 --> Helper loaded: form_helper
INFO - 2016-07-20 09:50:34 --> Helper loaded: file_helper
INFO - 2016-07-20 09:50:34 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:50:34 --> Database Driver Class Initialized
INFO - 2016-07-20 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:50:34 --> Form Validation Class Initialized
INFO - 2016-07-20 09:50:34 --> Email Class Initialized
INFO - 2016-07-20 09:50:34 --> Controller Class Initialized
DEBUG - 2016-07-20 09:50:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:50:34 --> Model Class Initialized
INFO - 2016-07-20 09:50:34 --> Model Class Initialized
INFO - 2016-07-20 09:50:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:50:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:50:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:50:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:50:34 --> Final output sent to browser
DEBUG - 2016-07-20 09:50:34 --> Total execution time: 0.3390
INFO - 2016-07-20 09:50:38 --> Config Class Initialized
INFO - 2016-07-20 09:50:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:50:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:50:38 --> Utf8 Class Initialized
INFO - 2016-07-20 09:50:38 --> URI Class Initialized
INFO - 2016-07-20 09:50:38 --> Router Class Initialized
INFO - 2016-07-20 09:50:38 --> Output Class Initialized
INFO - 2016-07-20 09:50:38 --> Security Class Initialized
DEBUG - 2016-07-20 09:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:50:38 --> Config Class Initialized
INFO - 2016-07-20 09:50:39 --> Hooks Class Initialized
INFO - 2016-07-20 09:50:39 --> Input Class Initialized
INFO - 2016-07-20 09:50:39 --> Language Class Initialized
DEBUG - 2016-07-20 09:50:39 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:50:39 --> Utf8 Class Initialized
INFO - 2016-07-20 09:50:39 --> Loader Class Initialized
INFO - 2016-07-20 09:50:39 --> URI Class Initialized
INFO - 2016-07-20 09:50:39 --> Helper loaded: url_helper
INFO - 2016-07-20 09:50:39 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:50:39 --> Router Class Initialized
INFO - 2016-07-20 09:50:39 --> Helper loaded: html_helper
INFO - 2016-07-20 09:50:39 --> Output Class Initialized
INFO - 2016-07-20 09:50:39 --> Security Class Initialized
INFO - 2016-07-20 09:50:39 --> Helper loaded: form_helper
INFO - 2016-07-20 09:50:39 --> Helper loaded: file_helper
DEBUG - 2016-07-20 09:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:50:39 --> Input Class Initialized
INFO - 2016-07-20 09:50:39 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:50:39 --> Language Class Initialized
INFO - 2016-07-20 09:50:39 --> Database Driver Class Initialized
ERROR - 2016-07-20 09:50:39 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:50:39 --> Form Validation Class Initialized
INFO - 2016-07-20 09:50:39 --> Email Class Initialized
INFO - 2016-07-20 09:50:39 --> Controller Class Initialized
DEBUG - 2016-07-20 09:50:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:50:39 --> Model Class Initialized
INFO - 2016-07-20 09:50:39 --> Model Class Initialized
INFO - 2016-07-20 09:50:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:50:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:50:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:50:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:50:39 --> Final output sent to browser
DEBUG - 2016-07-20 09:50:39 --> Total execution time: 0.3884
INFO - 2016-07-20 09:53:27 --> Config Class Initialized
INFO - 2016-07-20 09:53:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:53:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:53:27 --> Utf8 Class Initialized
INFO - 2016-07-20 09:53:27 --> URI Class Initialized
INFO - 2016-07-20 09:53:27 --> Router Class Initialized
INFO - 2016-07-20 09:53:27 --> Output Class Initialized
INFO - 2016-07-20 09:53:27 --> Security Class Initialized
DEBUG - 2016-07-20 09:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:53:27 --> Input Class Initialized
INFO - 2016-07-20 09:53:27 --> Language Class Initialized
INFO - 2016-07-20 09:53:27 --> Loader Class Initialized
INFO - 2016-07-20 09:53:27 --> Helper loaded: url_helper
INFO - 2016-07-20 09:53:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:53:27 --> Helper loaded: html_helper
INFO - 2016-07-20 09:53:27 --> Helper loaded: form_helper
INFO - 2016-07-20 09:53:27 --> Helper loaded: file_helper
INFO - 2016-07-20 09:53:27 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:53:27 --> Database Driver Class Initialized
INFO - 2016-07-20 09:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:53:27 --> Form Validation Class Initialized
INFO - 2016-07-20 09:53:27 --> Email Class Initialized
INFO - 2016-07-20 09:53:27 --> Controller Class Initialized
DEBUG - 2016-07-20 09:53:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:53:27 --> Model Class Initialized
INFO - 2016-07-20 09:53:27 --> Model Class Initialized
INFO - 2016-07-20 09:53:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:53:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:53:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:53:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:53:27 --> Final output sent to browser
DEBUG - 2016-07-20 09:53:27 --> Total execution time: 0.3834
INFO - 2016-07-20 09:53:29 --> Config Class Initialized
INFO - 2016-07-20 09:53:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:53:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:53:29 --> Utf8 Class Initialized
INFO - 2016-07-20 09:53:29 --> URI Class Initialized
INFO - 2016-07-20 09:53:29 --> Router Class Initialized
INFO - 2016-07-20 09:53:29 --> Output Class Initialized
INFO - 2016-07-20 09:53:29 --> Security Class Initialized
DEBUG - 2016-07-20 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:53:29 --> Input Class Initialized
INFO - 2016-07-20 09:53:29 --> Language Class Initialized
INFO - 2016-07-20 09:53:29 --> Loader Class Initialized
INFO - 2016-07-20 09:53:29 --> Helper loaded: url_helper
INFO - 2016-07-20 09:53:29 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:53:29 --> Helper loaded: html_helper
INFO - 2016-07-20 09:53:29 --> Helper loaded: form_helper
INFO - 2016-07-20 09:53:29 --> Config Class Initialized
INFO - 2016-07-20 09:53:29 --> Hooks Class Initialized
INFO - 2016-07-20 09:53:29 --> Helper loaded: file_helper
INFO - 2016-07-20 09:53:29 --> Helper loaded: myemail_helper
DEBUG - 2016-07-20 09:53:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:53:29 --> Utf8 Class Initialized
INFO - 2016-07-20 09:53:29 --> URI Class Initialized
INFO - 2016-07-20 09:53:29 --> Router Class Initialized
INFO - 2016-07-20 09:53:29 --> Output Class Initialized
INFO - 2016-07-20 09:53:29 --> Security Class Initialized
INFO - 2016-07-20 09:53:29 --> Database Driver Class Initialized
DEBUG - 2016-07-20 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:53:29 --> Input Class Initialized
INFO - 2016-07-20 09:53:29 --> Language Class Initialized
ERROR - 2016-07-20 09:53:29 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:53:29 --> Form Validation Class Initialized
INFO - 2016-07-20 09:53:29 --> Email Class Initialized
INFO - 2016-07-20 09:53:29 --> Controller Class Initialized
DEBUG - 2016-07-20 09:53:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:53:29 --> Model Class Initialized
INFO - 2016-07-20 09:53:29 --> Model Class Initialized
INFO - 2016-07-20 09:53:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:53:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:53:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:53:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:53:29 --> Final output sent to browser
DEBUG - 2016-07-20 09:53:29 --> Total execution time: 0.6163
INFO - 2016-07-20 09:54:38 --> Config Class Initialized
INFO - 2016-07-20 09:54:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:54:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:54:38 --> Utf8 Class Initialized
INFO - 2016-07-20 09:54:38 --> URI Class Initialized
INFO - 2016-07-20 09:54:38 --> Router Class Initialized
INFO - 2016-07-20 09:54:38 --> Output Class Initialized
INFO - 2016-07-20 09:54:38 --> Security Class Initialized
DEBUG - 2016-07-20 09:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:54:38 --> Input Class Initialized
INFO - 2016-07-20 09:54:38 --> Language Class Initialized
INFO - 2016-07-20 09:54:38 --> Loader Class Initialized
INFO - 2016-07-20 09:54:38 --> Helper loaded: url_helper
INFO - 2016-07-20 09:54:38 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:54:38 --> Helper loaded: html_helper
INFO - 2016-07-20 09:54:38 --> Helper loaded: form_helper
INFO - 2016-07-20 09:54:38 --> Helper loaded: file_helper
INFO - 2016-07-20 09:54:38 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:54:38 --> Database Driver Class Initialized
INFO - 2016-07-20 09:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:54:38 --> Form Validation Class Initialized
INFO - 2016-07-20 09:54:38 --> Email Class Initialized
INFO - 2016-07-20 09:54:38 --> Controller Class Initialized
DEBUG - 2016-07-20 09:54:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:54:38 --> Model Class Initialized
INFO - 2016-07-20 09:54:38 --> Model Class Initialized
INFO - 2016-07-20 09:54:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:54:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:54:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:54:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:54:38 --> Final output sent to browser
DEBUG - 2016-07-20 09:54:38 --> Total execution time: 0.4740
INFO - 2016-07-20 09:54:40 --> Config Class Initialized
INFO - 2016-07-20 09:54:41 --> Hooks Class Initialized
INFO - 2016-07-20 09:54:41 --> Config Class Initialized
DEBUG - 2016-07-20 09:54:41 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:54:41 --> Hooks Class Initialized
INFO - 2016-07-20 09:54:41 --> Utf8 Class Initialized
INFO - 2016-07-20 09:54:41 --> URI Class Initialized
DEBUG - 2016-07-20 09:54:41 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:54:41 --> Utf8 Class Initialized
INFO - 2016-07-20 09:54:41 --> Router Class Initialized
INFO - 2016-07-20 09:54:41 --> URI Class Initialized
INFO - 2016-07-20 09:54:41 --> Output Class Initialized
INFO - 2016-07-20 09:54:41 --> Security Class Initialized
INFO - 2016-07-20 09:54:41 --> Router Class Initialized
DEBUG - 2016-07-20 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:54:41 --> Output Class Initialized
INFO - 2016-07-20 09:54:41 --> Input Class Initialized
INFO - 2016-07-20 09:54:41 --> Security Class Initialized
INFO - 2016-07-20 09:54:41 --> Language Class Initialized
DEBUG - 2016-07-20 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:54:41 --> Input Class Initialized
INFO - 2016-07-20 09:54:41 --> Loader Class Initialized
INFO - 2016-07-20 09:54:41 --> Language Class Initialized
INFO - 2016-07-20 09:54:41 --> Helper loaded: url_helper
INFO - 2016-07-20 09:54:41 --> Helper loaded: utils_helper
ERROR - 2016-07-20 09:54:41 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:54:41 --> Helper loaded: html_helper
INFO - 2016-07-20 09:54:41 --> Helper loaded: form_helper
INFO - 2016-07-20 09:54:41 --> Helper loaded: file_helper
INFO - 2016-07-20 09:54:41 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:54:41 --> Database Driver Class Initialized
INFO - 2016-07-20 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:54:41 --> Form Validation Class Initialized
INFO - 2016-07-20 09:54:41 --> Email Class Initialized
INFO - 2016-07-20 09:54:41 --> Controller Class Initialized
DEBUG - 2016-07-20 09:54:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:54:41 --> Model Class Initialized
INFO - 2016-07-20 09:54:41 --> Model Class Initialized
INFO - 2016-07-20 09:54:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:54:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:54:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:54:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:54:41 --> Final output sent to browser
DEBUG - 2016-07-20 09:54:41 --> Total execution time: 0.4251
INFO - 2016-07-20 09:56:28 --> Config Class Initialized
INFO - 2016-07-20 09:56:28 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:56:28 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:56:28 --> Utf8 Class Initialized
INFO - 2016-07-20 09:56:28 --> URI Class Initialized
INFO - 2016-07-20 09:56:28 --> Router Class Initialized
INFO - 2016-07-20 09:56:28 --> Output Class Initialized
INFO - 2016-07-20 09:56:28 --> Security Class Initialized
DEBUG - 2016-07-20 09:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:56:28 --> Input Class Initialized
INFO - 2016-07-20 09:56:28 --> Language Class Initialized
INFO - 2016-07-20 09:56:28 --> Loader Class Initialized
INFO - 2016-07-20 09:56:28 --> Helper loaded: url_helper
INFO - 2016-07-20 09:56:28 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:56:28 --> Helper loaded: html_helper
INFO - 2016-07-20 09:56:28 --> Helper loaded: form_helper
INFO - 2016-07-20 09:56:28 --> Helper loaded: file_helper
INFO - 2016-07-20 09:56:28 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:56:28 --> Database Driver Class Initialized
INFO - 2016-07-20 09:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:56:28 --> Form Validation Class Initialized
INFO - 2016-07-20 09:56:28 --> Email Class Initialized
INFO - 2016-07-20 09:56:28 --> Controller Class Initialized
DEBUG - 2016-07-20 09:56:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:56:28 --> Model Class Initialized
INFO - 2016-07-20 09:56:28 --> Model Class Initialized
INFO - 2016-07-20 09:56:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:56:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:56:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:56:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:56:29 --> Final output sent to browser
DEBUG - 2016-07-20 09:56:29 --> Total execution time: 0.3500
INFO - 2016-07-20 09:56:30 --> Config Class Initialized
INFO - 2016-07-20 09:56:30 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:56:30 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:56:30 --> Utf8 Class Initialized
INFO - 2016-07-20 09:56:30 --> URI Class Initialized
INFO - 2016-07-20 09:56:30 --> Router Class Initialized
INFO - 2016-07-20 09:56:30 --> Output Class Initialized
INFO - 2016-07-20 09:56:30 --> Security Class Initialized
INFO - 2016-07-20 09:56:30 --> Config Class Initialized
INFO - 2016-07-20 09:56:30 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:56:31 --> Input Class Initialized
DEBUG - 2016-07-20 09:56:31 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:56:31 --> Utf8 Class Initialized
INFO - 2016-07-20 09:56:31 --> Language Class Initialized
INFO - 2016-07-20 09:56:31 --> URI Class Initialized
INFO - 2016-07-20 09:56:31 --> Loader Class Initialized
INFO - 2016-07-20 09:56:31 --> Router Class Initialized
INFO - 2016-07-20 09:56:31 --> Helper loaded: url_helper
INFO - 2016-07-20 09:56:31 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:56:31 --> Output Class Initialized
INFO - 2016-07-20 09:56:31 --> Helper loaded: html_helper
INFO - 2016-07-20 09:56:31 --> Security Class Initialized
DEBUG - 2016-07-20 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:56:31 --> Helper loaded: form_helper
INFO - 2016-07-20 09:56:31 --> Input Class Initialized
INFO - 2016-07-20 09:56:31 --> Helper loaded: file_helper
INFO - 2016-07-20 09:56:31 --> Language Class Initialized
INFO - 2016-07-20 09:56:31 --> Helper loaded: myemail_helper
ERROR - 2016-07-20 09:56:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 09:56:31 --> Database Driver Class Initialized
INFO - 2016-07-20 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:56:31 --> Form Validation Class Initialized
INFO - 2016-07-20 09:56:31 --> Email Class Initialized
INFO - 2016-07-20 09:56:31 --> Controller Class Initialized
DEBUG - 2016-07-20 09:56:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:56:31 --> Model Class Initialized
INFO - 2016-07-20 09:56:31 --> Model Class Initialized
INFO - 2016-07-20 09:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 09:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 09:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 09:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 09:56:31 --> Final output sent to browser
DEBUG - 2016-07-20 09:56:31 --> Total execution time: 0.5051
INFO - 2016-07-20 09:58:04 --> Config Class Initialized
INFO - 2016-07-20 09:58:05 --> Hooks Class Initialized
DEBUG - 2016-07-20 09:58:05 --> UTF-8 Support Enabled
INFO - 2016-07-20 09:58:05 --> Utf8 Class Initialized
INFO - 2016-07-20 09:58:05 --> URI Class Initialized
INFO - 2016-07-20 09:58:05 --> Router Class Initialized
INFO - 2016-07-20 09:58:05 --> Output Class Initialized
INFO - 2016-07-20 09:58:05 --> Security Class Initialized
DEBUG - 2016-07-20 09:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 09:58:05 --> Input Class Initialized
INFO - 2016-07-20 09:58:05 --> Language Class Initialized
INFO - 2016-07-20 09:58:05 --> Loader Class Initialized
INFO - 2016-07-20 09:58:05 --> Helper loaded: url_helper
INFO - 2016-07-20 09:58:05 --> Helper loaded: utils_helper
INFO - 2016-07-20 09:58:05 --> Helper loaded: html_helper
INFO - 2016-07-20 09:58:05 --> Helper loaded: form_helper
INFO - 2016-07-20 09:58:05 --> Helper loaded: file_helper
INFO - 2016-07-20 09:58:05 --> Helper loaded: myemail_helper
INFO - 2016-07-20 09:58:05 --> Database Driver Class Initialized
INFO - 2016-07-20 09:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 09:58:05 --> Form Validation Class Initialized
INFO - 2016-07-20 09:58:05 --> Email Class Initialized
INFO - 2016-07-20 09:58:05 --> Controller Class Initialized
DEBUG - 2016-07-20 09:58:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 09:58:05 --> Model Class Initialized
INFO - 2016-07-20 09:58:05 --> Model Class Initialized
INFO - 2016-07-20 09:58:05 --> Final output sent to browser
DEBUG - 2016-07-20 09:58:05 --> Total execution time: 0.5368
INFO - 2016-07-20 10:00:08 --> Config Class Initialized
INFO - 2016-07-20 10:00:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:00:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:00:08 --> Utf8 Class Initialized
INFO - 2016-07-20 10:00:08 --> URI Class Initialized
INFO - 2016-07-20 10:00:08 --> Router Class Initialized
INFO - 2016-07-20 10:00:08 --> Output Class Initialized
INFO - 2016-07-20 10:00:08 --> Security Class Initialized
DEBUG - 2016-07-20 10:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:00:08 --> Input Class Initialized
INFO - 2016-07-20 10:00:08 --> Language Class Initialized
INFO - 2016-07-20 10:00:08 --> Loader Class Initialized
INFO - 2016-07-20 10:00:08 --> Helper loaded: url_helper
INFO - 2016-07-20 10:00:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:00:08 --> Helper loaded: html_helper
INFO - 2016-07-20 10:00:08 --> Helper loaded: form_helper
INFO - 2016-07-20 10:00:08 --> Helper loaded: file_helper
INFO - 2016-07-20 10:00:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:00:08 --> Database Driver Class Initialized
INFO - 2016-07-20 10:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:00:08 --> Form Validation Class Initialized
INFO - 2016-07-20 10:00:08 --> Email Class Initialized
INFO - 2016-07-20 10:00:08 --> Controller Class Initialized
DEBUG - 2016-07-20 10:00:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:00:08 --> Model Class Initialized
INFO - 2016-07-20 10:00:08 --> Model Class Initialized
INFO - 2016-07-20 10:00:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:00:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:00:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:00:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:00:08 --> Final output sent to browser
DEBUG - 2016-07-20 10:00:08 --> Total execution time: 0.3653
INFO - 2016-07-20 10:02:20 --> Config Class Initialized
INFO - 2016-07-20 10:02:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:02:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:02:20 --> Utf8 Class Initialized
INFO - 2016-07-20 10:02:20 --> URI Class Initialized
INFO - 2016-07-20 10:02:20 --> Router Class Initialized
INFO - 2016-07-20 10:02:20 --> Output Class Initialized
INFO - 2016-07-20 10:02:20 --> Security Class Initialized
DEBUG - 2016-07-20 10:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:02:20 --> Input Class Initialized
INFO - 2016-07-20 10:02:20 --> Language Class Initialized
INFO - 2016-07-20 10:02:20 --> Loader Class Initialized
INFO - 2016-07-20 10:02:20 --> Helper loaded: url_helper
INFO - 2016-07-20 10:02:20 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:02:20 --> Helper loaded: html_helper
INFO - 2016-07-20 10:02:20 --> Helper loaded: form_helper
INFO - 2016-07-20 10:02:20 --> Helper loaded: file_helper
INFO - 2016-07-20 10:02:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:02:20 --> Database Driver Class Initialized
INFO - 2016-07-20 10:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:02:20 --> Form Validation Class Initialized
INFO - 2016-07-20 10:02:20 --> Email Class Initialized
INFO - 2016-07-20 10:02:20 --> Controller Class Initialized
DEBUG - 2016-07-20 10:02:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:02:20 --> Model Class Initialized
INFO - 2016-07-20 10:02:20 --> Model Class Initialized
INFO - 2016-07-20 10:02:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:02:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:02:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:02:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:02:20 --> Final output sent to browser
DEBUG - 2016-07-20 10:02:20 --> Total execution time: 0.3562
INFO - 2016-07-20 10:07:27 --> Config Class Initialized
INFO - 2016-07-20 10:07:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:07:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:07:27 --> Utf8 Class Initialized
INFO - 2016-07-20 10:07:27 --> URI Class Initialized
INFO - 2016-07-20 10:07:27 --> Router Class Initialized
INFO - 2016-07-20 10:07:27 --> Output Class Initialized
INFO - 2016-07-20 10:07:27 --> Security Class Initialized
DEBUG - 2016-07-20 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:07:27 --> Input Class Initialized
INFO - 2016-07-20 10:07:27 --> Language Class Initialized
INFO - 2016-07-20 10:07:27 --> Loader Class Initialized
INFO - 2016-07-20 10:07:27 --> Helper loaded: url_helper
INFO - 2016-07-20 10:07:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:07:27 --> Helper loaded: html_helper
INFO - 2016-07-20 10:07:27 --> Helper loaded: form_helper
INFO - 2016-07-20 10:07:27 --> Helper loaded: file_helper
INFO - 2016-07-20 10:07:27 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:07:27 --> Database Driver Class Initialized
INFO - 2016-07-20 10:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:07:27 --> Form Validation Class Initialized
INFO - 2016-07-20 10:07:27 --> Email Class Initialized
INFO - 2016-07-20 10:07:27 --> Controller Class Initialized
INFO - 2016-07-20 10:07:27 --> Model Class Initialized
INFO - 2016-07-20 10:07:27 --> Model Class Initialized
DEBUG - 2016-07-20 10:07:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:07:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:07:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:07:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-07-20 10:07:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:07:27 --> Final output sent to browser
DEBUG - 2016-07-20 10:07:27 --> Total execution time: 0.5125
INFO - 2016-07-20 10:14:23 --> Config Class Initialized
INFO - 2016-07-20 10:14:23 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:14:23 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:14:23 --> Utf8 Class Initialized
INFO - 2016-07-20 10:14:23 --> URI Class Initialized
INFO - 2016-07-20 10:14:23 --> Router Class Initialized
INFO - 2016-07-20 10:14:23 --> Output Class Initialized
INFO - 2016-07-20 10:14:23 --> Security Class Initialized
DEBUG - 2016-07-20 10:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:14:23 --> Input Class Initialized
INFO - 2016-07-20 10:14:23 --> Language Class Initialized
INFO - 2016-07-20 10:14:23 --> Loader Class Initialized
INFO - 2016-07-20 10:14:23 --> Helper loaded: url_helper
INFO - 2016-07-20 10:14:23 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:14:23 --> Helper loaded: html_helper
INFO - 2016-07-20 10:14:23 --> Helper loaded: form_helper
INFO - 2016-07-20 10:14:23 --> Helper loaded: file_helper
INFO - 2016-07-20 10:14:23 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:14:23 --> Database Driver Class Initialized
INFO - 2016-07-20 10:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:14:23 --> Form Validation Class Initialized
INFO - 2016-07-20 10:14:23 --> Email Class Initialized
INFO - 2016-07-20 10:14:23 --> Controller Class Initialized
DEBUG - 2016-07-20 10:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:14:23 --> Model Class Initialized
INFO - 2016-07-20 10:14:23 --> Model Class Initialized
INFO - 2016-07-20 10:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:14:23 --> Final output sent to browser
DEBUG - 2016-07-20 10:14:23 --> Total execution time: 0.3519
INFO - 2016-07-20 10:14:35 --> Config Class Initialized
INFO - 2016-07-20 10:14:35 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:14:35 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:14:35 --> Utf8 Class Initialized
INFO - 2016-07-20 10:14:35 --> URI Class Initialized
INFO - 2016-07-20 10:14:35 --> Router Class Initialized
INFO - 2016-07-20 10:14:35 --> Output Class Initialized
INFO - 2016-07-20 10:14:35 --> Security Class Initialized
DEBUG - 2016-07-20 10:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:14:35 --> Input Class Initialized
INFO - 2016-07-20 10:14:35 --> Language Class Initialized
INFO - 2016-07-20 10:14:35 --> Loader Class Initialized
INFO - 2016-07-20 10:14:35 --> Helper loaded: url_helper
INFO - 2016-07-20 10:14:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:14:35 --> Helper loaded: html_helper
INFO - 2016-07-20 10:14:35 --> Helper loaded: form_helper
INFO - 2016-07-20 10:14:35 --> Helper loaded: file_helper
INFO - 2016-07-20 10:14:35 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:14:35 --> Database Driver Class Initialized
INFO - 2016-07-20 10:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:14:35 --> Form Validation Class Initialized
INFO - 2016-07-20 10:14:35 --> Email Class Initialized
INFO - 2016-07-20 10:14:35 --> Controller Class Initialized
DEBUG - 2016-07-20 10:14:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:14:35 --> Model Class Initialized
INFO - 2016-07-20 10:14:35 --> Model Class Initialized
INFO - 2016-07-20 10:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-20 10:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:14:36 --> Final output sent to browser
DEBUG - 2016-07-20 10:14:36 --> Total execution time: 0.6163
INFO - 2016-07-20 10:14:46 --> Config Class Initialized
INFO - 2016-07-20 10:14:46 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:14:46 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:14:46 --> Utf8 Class Initialized
INFO - 2016-07-20 10:14:46 --> URI Class Initialized
INFO - 2016-07-20 10:14:46 --> Router Class Initialized
INFO - 2016-07-20 10:14:46 --> Output Class Initialized
INFO - 2016-07-20 10:14:46 --> Security Class Initialized
DEBUG - 2016-07-20 10:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:14:46 --> Input Class Initialized
INFO - 2016-07-20 10:14:46 --> Language Class Initialized
INFO - 2016-07-20 10:14:46 --> Loader Class Initialized
INFO - 2016-07-20 10:14:47 --> Helper loaded: url_helper
INFO - 2016-07-20 10:14:47 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:14:47 --> Helper loaded: html_helper
INFO - 2016-07-20 10:14:47 --> Helper loaded: form_helper
INFO - 2016-07-20 10:14:47 --> Helper loaded: file_helper
INFO - 2016-07-20 10:14:47 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:14:47 --> Database Driver Class Initialized
INFO - 2016-07-20 10:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:14:47 --> Form Validation Class Initialized
INFO - 2016-07-20 10:14:47 --> Email Class Initialized
INFO - 2016-07-20 10:14:47 --> Controller Class Initialized
DEBUG - 2016-07-20 10:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:14:47 --> Model Class Initialized
INFO - 2016-07-20 10:14:47 --> Model Class Initialized
INFO - 2016-07-20 10:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:14:47 --> Final output sent to browser
DEBUG - 2016-07-20 10:14:47 --> Total execution time: 0.3596
INFO - 2016-07-20 10:14:55 --> Config Class Initialized
INFO - 2016-07-20 10:14:56 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:14:56 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:14:56 --> Utf8 Class Initialized
INFO - 2016-07-20 10:14:56 --> URI Class Initialized
INFO - 2016-07-20 10:14:56 --> Router Class Initialized
INFO - 2016-07-20 10:14:56 --> Output Class Initialized
INFO - 2016-07-20 10:14:56 --> Security Class Initialized
DEBUG - 2016-07-20 10:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:14:56 --> Input Class Initialized
INFO - 2016-07-20 10:14:56 --> Language Class Initialized
INFO - 2016-07-20 10:14:56 --> Loader Class Initialized
INFO - 2016-07-20 10:14:56 --> Helper loaded: url_helper
INFO - 2016-07-20 10:14:56 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:14:56 --> Helper loaded: html_helper
INFO - 2016-07-20 10:14:56 --> Helper loaded: form_helper
INFO - 2016-07-20 10:14:56 --> Helper loaded: file_helper
INFO - 2016-07-20 10:14:56 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:14:56 --> Database Driver Class Initialized
INFO - 2016-07-20 10:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:14:56 --> Form Validation Class Initialized
INFO - 2016-07-20 10:14:56 --> Email Class Initialized
INFO - 2016-07-20 10:14:56 --> Controller Class Initialized
DEBUG - 2016-07-20 10:14:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:14:56 --> Model Class Initialized
INFO - 2016-07-20 10:14:56 --> Model Class Initialized
INFO - 2016-07-20 10:14:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:14:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:14:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-20 10:14:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:14:56 --> Final output sent to browser
DEBUG - 2016-07-20 10:14:56 --> Total execution time: 0.3480
INFO - 2016-07-20 10:17:08 --> Config Class Initialized
INFO - 2016-07-20 10:17:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:17:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:17:08 --> Utf8 Class Initialized
INFO - 2016-07-20 10:17:08 --> URI Class Initialized
INFO - 2016-07-20 10:17:08 --> Router Class Initialized
INFO - 2016-07-20 10:17:08 --> Output Class Initialized
INFO - 2016-07-20 10:17:08 --> Security Class Initialized
DEBUG - 2016-07-20 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:17:08 --> Input Class Initialized
INFO - 2016-07-20 10:17:08 --> Language Class Initialized
INFO - 2016-07-20 10:17:08 --> Loader Class Initialized
INFO - 2016-07-20 10:17:08 --> Helper loaded: url_helper
INFO - 2016-07-20 10:17:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:17:08 --> Helper loaded: html_helper
INFO - 2016-07-20 10:17:08 --> Helper loaded: form_helper
INFO - 2016-07-20 10:17:08 --> Helper loaded: file_helper
INFO - 2016-07-20 10:17:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:17:08 --> Database Driver Class Initialized
INFO - 2016-07-20 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:17:08 --> Form Validation Class Initialized
INFO - 2016-07-20 10:17:08 --> Email Class Initialized
INFO - 2016-07-20 10:17:08 --> Controller Class Initialized
DEBUG - 2016-07-20 10:17:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:17:08 --> Model Class Initialized
INFO - 2016-07-20 10:17:08 --> Model Class Initialized
INFO - 2016-07-20 10:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:17:08 --> Final output sent to browser
DEBUG - 2016-07-20 10:17:08 --> Total execution time: 0.4049
INFO - 2016-07-20 10:17:11 --> Config Class Initialized
INFO - 2016-07-20 10:17:11 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:17:11 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:17:11 --> Utf8 Class Initialized
INFO - 2016-07-20 10:17:11 --> URI Class Initialized
INFO - 2016-07-20 10:17:11 --> Router Class Initialized
INFO - 2016-07-20 10:17:11 --> Output Class Initialized
INFO - 2016-07-20 10:17:11 --> Security Class Initialized
DEBUG - 2016-07-20 10:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:17:11 --> Input Class Initialized
INFO - 2016-07-20 10:17:11 --> Language Class Initialized
INFO - 2016-07-20 10:17:11 --> Loader Class Initialized
INFO - 2016-07-20 10:17:11 --> Helper loaded: url_helper
INFO - 2016-07-20 10:17:11 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:17:11 --> Helper loaded: html_helper
INFO - 2016-07-20 10:17:11 --> Helper loaded: form_helper
INFO - 2016-07-20 10:17:11 --> Helper loaded: file_helper
INFO - 2016-07-20 10:17:11 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:17:11 --> Database Driver Class Initialized
INFO - 2016-07-20 10:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:17:11 --> Form Validation Class Initialized
INFO - 2016-07-20 10:17:11 --> Email Class Initialized
INFO - 2016-07-20 10:17:11 --> Controller Class Initialized
DEBUG - 2016-07-20 10:17:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:17:11 --> Model Class Initialized
INFO - 2016-07-20 10:17:11 --> Model Class Initialized
INFO - 2016-07-20 10:17:11 --> Model Class Initialized
INFO - 2016-07-20 10:17:11 --> Model Class Initialized
INFO - 2016-07-20 10:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:17:11 --> Final output sent to browser
DEBUG - 2016-07-20 10:17:11 --> Total execution time: 0.6113
INFO - 2016-07-20 10:17:14 --> Config Class Initialized
INFO - 2016-07-20 10:17:14 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:17:14 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:17:14 --> Utf8 Class Initialized
INFO - 2016-07-20 10:17:14 --> URI Class Initialized
INFO - 2016-07-20 10:17:14 --> Router Class Initialized
INFO - 2016-07-20 10:17:14 --> Output Class Initialized
INFO - 2016-07-20 10:17:14 --> Security Class Initialized
DEBUG - 2016-07-20 10:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:17:14 --> Input Class Initialized
INFO - 2016-07-20 10:17:14 --> Language Class Initialized
INFO - 2016-07-20 10:17:14 --> Loader Class Initialized
INFO - 2016-07-20 10:17:14 --> Helper loaded: url_helper
INFO - 2016-07-20 10:17:14 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:17:14 --> Helper loaded: html_helper
INFO - 2016-07-20 10:17:14 --> Helper loaded: form_helper
INFO - 2016-07-20 10:17:14 --> Helper loaded: file_helper
INFO - 2016-07-20 10:17:14 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:17:14 --> Database Driver Class Initialized
INFO - 2016-07-20 10:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:17:14 --> Form Validation Class Initialized
INFO - 2016-07-20 10:17:14 --> Email Class Initialized
INFO - 2016-07-20 10:17:14 --> Controller Class Initialized
DEBUG - 2016-07-20 10:17:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:17:14 --> Model Class Initialized
INFO - 2016-07-20 10:17:14 --> Model Class Initialized
INFO - 2016-07-20 10:17:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:17:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:17:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:17:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:17:14 --> Final output sent to browser
DEBUG - 2016-07-20 10:17:14 --> Total execution time: 0.3977
INFO - 2016-07-20 10:17:19 --> Config Class Initialized
INFO - 2016-07-20 10:17:19 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:17:19 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:17:19 --> Utf8 Class Initialized
INFO - 2016-07-20 10:17:19 --> URI Class Initialized
INFO - 2016-07-20 10:17:19 --> Router Class Initialized
INFO - 2016-07-20 10:17:19 --> Output Class Initialized
INFO - 2016-07-20 10:17:19 --> Security Class Initialized
DEBUG - 2016-07-20 10:17:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:17:19 --> Input Class Initialized
INFO - 2016-07-20 10:17:19 --> Language Class Initialized
INFO - 2016-07-20 10:17:19 --> Loader Class Initialized
INFO - 2016-07-20 10:17:19 --> Helper loaded: url_helper
INFO - 2016-07-20 10:17:20 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:17:20 --> Helper loaded: html_helper
INFO - 2016-07-20 10:17:20 --> Helper loaded: form_helper
INFO - 2016-07-20 10:17:20 --> Helper loaded: file_helper
INFO - 2016-07-20 10:17:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:17:20 --> Database Driver Class Initialized
INFO - 2016-07-20 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:17:20 --> Form Validation Class Initialized
INFO - 2016-07-20 10:17:20 --> Email Class Initialized
INFO - 2016-07-20 10:17:20 --> Controller Class Initialized
DEBUG - 2016-07-20 10:17:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:17:20 --> Model Class Initialized
INFO - 2016-07-20 10:17:20 --> Model Class Initialized
INFO - 2016-07-20 10:17:20 --> Model Class Initialized
INFO - 2016-07-20 10:17:20 --> Model Class Initialized
INFO - 2016-07-20 10:17:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:17:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:17:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:17:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:17:20 --> Final output sent to browser
DEBUG - 2016-07-20 10:17:20 --> Total execution time: 0.3935
INFO - 2016-07-20 10:17:26 --> Config Class Initialized
INFO - 2016-07-20 10:17:26 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:17:26 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:17:26 --> Utf8 Class Initialized
INFO - 2016-07-20 10:17:26 --> URI Class Initialized
INFO - 2016-07-20 10:17:26 --> Router Class Initialized
INFO - 2016-07-20 10:17:26 --> Output Class Initialized
INFO - 2016-07-20 10:17:26 --> Security Class Initialized
DEBUG - 2016-07-20 10:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:17:26 --> Input Class Initialized
INFO - 2016-07-20 10:17:26 --> Language Class Initialized
INFO - 2016-07-20 10:17:26 --> Loader Class Initialized
INFO - 2016-07-20 10:17:26 --> Helper loaded: url_helper
INFO - 2016-07-20 10:17:26 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:17:26 --> Helper loaded: html_helper
INFO - 2016-07-20 10:17:26 --> Helper loaded: form_helper
INFO - 2016-07-20 10:17:26 --> Helper loaded: file_helper
INFO - 2016-07-20 10:17:26 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:17:26 --> Database Driver Class Initialized
INFO - 2016-07-20 10:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:17:26 --> Form Validation Class Initialized
INFO - 2016-07-20 10:17:26 --> Email Class Initialized
INFO - 2016-07-20 10:17:26 --> Controller Class Initialized
DEBUG - 2016-07-20 10:17:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:17:27 --> Model Class Initialized
INFO - 2016-07-20 10:17:27 --> Model Class Initialized
INFO - 2016-07-20 10:17:27 --> Model Class Initialized
INFO - 2016-07-20 10:17:27 --> Model Class Initialized
INFO - 2016-07-20 10:17:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:17:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:17:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:17:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 10:17:27 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1520
ERROR - 2016-07-20 10:17:27 --> Severity: Warning --> sort() expects parameter 1 to be array, null given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1521
ERROR - 2016-07-20 10:17:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1549
INFO - 2016-07-20 10:17:27 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 10:19:02 --> Config Class Initialized
INFO - 2016-07-20 10:19:02 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:19:02 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:19:02 --> Utf8 Class Initialized
INFO - 2016-07-20 10:19:02 --> URI Class Initialized
INFO - 2016-07-20 10:19:02 --> Router Class Initialized
INFO - 2016-07-20 10:19:02 --> Output Class Initialized
INFO - 2016-07-20 10:19:02 --> Security Class Initialized
DEBUG - 2016-07-20 10:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:19:02 --> Input Class Initialized
INFO - 2016-07-20 10:19:02 --> Language Class Initialized
INFO - 2016-07-20 10:19:02 --> Loader Class Initialized
INFO - 2016-07-20 10:19:02 --> Helper loaded: url_helper
INFO - 2016-07-20 10:19:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:19:02 --> Helper loaded: html_helper
INFO - 2016-07-20 10:19:02 --> Helper loaded: form_helper
INFO - 2016-07-20 10:19:02 --> Helper loaded: file_helper
INFO - 2016-07-20 10:19:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:19:02 --> Database Driver Class Initialized
INFO - 2016-07-20 10:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:19:02 --> Form Validation Class Initialized
INFO - 2016-07-20 10:19:02 --> Email Class Initialized
INFO - 2016-07-20 10:19:02 --> Controller Class Initialized
DEBUG - 2016-07-20 10:19:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:19:02 --> Model Class Initialized
INFO - 2016-07-20 10:19:02 --> Model Class Initialized
INFO - 2016-07-20 10:19:02 --> Model Class Initialized
INFO - 2016-07-20 10:19:02 --> Model Class Initialized
INFO - 2016-07-20 10:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:19:02 --> Final output sent to browser
DEBUG - 2016-07-20 10:19:02 --> Total execution time: 0.4018
INFO - 2016-07-20 10:19:29 --> Config Class Initialized
INFO - 2016-07-20 10:19:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:19:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:19:29 --> Utf8 Class Initialized
INFO - 2016-07-20 10:19:29 --> URI Class Initialized
INFO - 2016-07-20 10:19:29 --> Router Class Initialized
INFO - 2016-07-20 10:19:29 --> Output Class Initialized
INFO - 2016-07-20 10:19:29 --> Security Class Initialized
DEBUG - 2016-07-20 10:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:19:29 --> Input Class Initialized
INFO - 2016-07-20 10:19:29 --> Language Class Initialized
INFO - 2016-07-20 10:19:29 --> Loader Class Initialized
INFO - 2016-07-20 10:19:29 --> Helper loaded: url_helper
INFO - 2016-07-20 10:19:29 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:19:29 --> Helper loaded: html_helper
INFO - 2016-07-20 10:19:29 --> Helper loaded: form_helper
INFO - 2016-07-20 10:19:29 --> Helper loaded: file_helper
INFO - 2016-07-20 10:19:29 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:19:29 --> Database Driver Class Initialized
INFO - 2016-07-20 10:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:19:29 --> Form Validation Class Initialized
INFO - 2016-07-20 10:19:29 --> Email Class Initialized
INFO - 2016-07-20 10:19:29 --> Controller Class Initialized
DEBUG - 2016-07-20 10:19:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:19:29 --> Model Class Initialized
INFO - 2016-07-20 10:19:29 --> Model Class Initialized
INFO - 2016-07-20 10:19:29 --> Model Class Initialized
INFO - 2016-07-20 10:19:29 --> Model Class Initialized
INFO - 2016-07-20 10:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 10:19:29 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1520
ERROR - 2016-07-20 10:19:29 --> Severity: Warning --> sort() expects parameter 1 to be array, null given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1521
ERROR - 2016-07-20 10:19:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1549
INFO - 2016-07-20 10:19:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 10:19:43 --> Config Class Initialized
INFO - 2016-07-20 10:19:43 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:19:43 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:19:43 --> Utf8 Class Initialized
INFO - 2016-07-20 10:19:43 --> URI Class Initialized
INFO - 2016-07-20 10:19:43 --> Router Class Initialized
INFO - 2016-07-20 10:19:43 --> Output Class Initialized
INFO - 2016-07-20 10:19:43 --> Security Class Initialized
DEBUG - 2016-07-20 10:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:19:43 --> Input Class Initialized
INFO - 2016-07-20 10:19:43 --> Language Class Initialized
INFO - 2016-07-20 10:19:43 --> Loader Class Initialized
INFO - 2016-07-20 10:19:43 --> Helper loaded: url_helper
INFO - 2016-07-20 10:19:43 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:19:43 --> Helper loaded: html_helper
INFO - 2016-07-20 10:19:43 --> Helper loaded: form_helper
INFO - 2016-07-20 10:19:43 --> Helper loaded: file_helper
INFO - 2016-07-20 10:19:43 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:19:44 --> Database Driver Class Initialized
INFO - 2016-07-20 10:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:19:44 --> Form Validation Class Initialized
INFO - 2016-07-20 10:19:44 --> Email Class Initialized
INFO - 2016-07-20 10:19:44 --> Controller Class Initialized
DEBUG - 2016-07-20 10:19:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:19:44 --> Model Class Initialized
INFO - 2016-07-20 10:19:44 --> Model Class Initialized
INFO - 2016-07-20 10:19:44 --> Model Class Initialized
INFO - 2016-07-20 10:19:44 --> Model Class Initialized
INFO - 2016-07-20 10:19:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:19:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:19:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 10:19:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:19:44 --> Final output sent to browser
DEBUG - 2016-07-20 10:19:44 --> Total execution time: 0.4525
INFO - 2016-07-20 10:22:10 --> Config Class Initialized
INFO - 2016-07-20 10:22:10 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:22:10 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:22:10 --> Utf8 Class Initialized
INFO - 2016-07-20 10:22:10 --> URI Class Initialized
INFO - 2016-07-20 10:22:10 --> Router Class Initialized
INFO - 2016-07-20 10:22:10 --> Output Class Initialized
INFO - 2016-07-20 10:22:10 --> Security Class Initialized
DEBUG - 2016-07-20 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:22:10 --> Input Class Initialized
INFO - 2016-07-20 10:22:10 --> Language Class Initialized
INFO - 2016-07-20 10:22:10 --> Loader Class Initialized
INFO - 2016-07-20 10:22:10 --> Helper loaded: url_helper
INFO - 2016-07-20 10:22:10 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:22:10 --> Helper loaded: html_helper
INFO - 2016-07-20 10:22:10 --> Helper loaded: form_helper
INFO - 2016-07-20 10:22:10 --> Helper loaded: file_helper
INFO - 2016-07-20 10:22:10 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:22:10 --> Database Driver Class Initialized
INFO - 2016-07-20 10:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:22:10 --> Form Validation Class Initialized
INFO - 2016-07-20 10:22:10 --> Email Class Initialized
INFO - 2016-07-20 10:22:10 --> Controller Class Initialized
DEBUG - 2016-07-20 10:22:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:22:10 --> Model Class Initialized
INFO - 2016-07-20 10:22:10 --> Model Class Initialized
INFO - 2016-07-20 10:22:10 --> Helper loaded: download_helper
INFO - 2016-07-20 10:22:10 --> Config Class Initialized
INFO - 2016-07-20 10:22:10 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:22:10 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:22:10 --> Utf8 Class Initialized
INFO - 2016-07-20 10:22:10 --> URI Class Initialized
INFO - 2016-07-20 10:22:10 --> Router Class Initialized
INFO - 2016-07-20 10:22:10 --> Output Class Initialized
INFO - 2016-07-20 10:22:10 --> Security Class Initialized
DEBUG - 2016-07-20 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:22:10 --> Input Class Initialized
INFO - 2016-07-20 10:22:10 --> Language Class Initialized
ERROR - 2016-07-20 10:22:10 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-20 10:22:10 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 414
INFO - 2016-07-20 10:22:13 --> Config Class Initialized
INFO - 2016-07-20 10:22:13 --> Hooks Class Initialized
DEBUG - 2016-07-20 10:22:13 --> UTF-8 Support Enabled
INFO - 2016-07-20 10:22:13 --> Utf8 Class Initialized
INFO - 2016-07-20 10:22:13 --> URI Class Initialized
INFO - 2016-07-20 10:22:13 --> Router Class Initialized
INFO - 2016-07-20 10:22:13 --> Output Class Initialized
INFO - 2016-07-20 10:22:13 --> Security Class Initialized
DEBUG - 2016-07-20 10:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 10:22:13 --> Input Class Initialized
INFO - 2016-07-20 10:22:13 --> Language Class Initialized
INFO - 2016-07-20 10:22:13 --> Loader Class Initialized
INFO - 2016-07-20 10:22:13 --> Helper loaded: url_helper
INFO - 2016-07-20 10:22:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 10:22:13 --> Helper loaded: html_helper
INFO - 2016-07-20 10:22:13 --> Helper loaded: form_helper
INFO - 2016-07-20 10:22:13 --> Helper loaded: file_helper
INFO - 2016-07-20 10:22:14 --> Helper loaded: myemail_helper
INFO - 2016-07-20 10:22:14 --> Database Driver Class Initialized
INFO - 2016-07-20 10:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 10:22:14 --> Form Validation Class Initialized
INFO - 2016-07-20 10:22:14 --> Email Class Initialized
INFO - 2016-07-20 10:22:14 --> Controller Class Initialized
DEBUG - 2016-07-20 10:22:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 10:22:14 --> Model Class Initialized
INFO - 2016-07-20 10:22:14 --> Model Class Initialized
INFO - 2016-07-20 10:22:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 10:22:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 10:22:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 10:22:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 10:22:14 --> Final output sent to browser
DEBUG - 2016-07-20 10:22:14 --> Total execution time: 0.4531
INFO - 2016-07-20 15:04:37 --> Config Class Initialized
INFO - 2016-07-20 15:04:37 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:04:37 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:04:37 --> Utf8 Class Initialized
INFO - 2016-07-20 15:04:37 --> URI Class Initialized
INFO - 2016-07-20 15:04:37 --> Router Class Initialized
INFO - 2016-07-20 15:04:37 --> Output Class Initialized
INFO - 2016-07-20 15:04:37 --> Security Class Initialized
DEBUG - 2016-07-20 15:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:04:37 --> Input Class Initialized
INFO - 2016-07-20 15:04:37 --> Language Class Initialized
INFO - 2016-07-20 15:04:37 --> Loader Class Initialized
INFO - 2016-07-20 15:04:37 --> Helper loaded: url_helper
INFO - 2016-07-20 15:04:37 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:04:37 --> Helper loaded: html_helper
INFO - 2016-07-20 15:04:37 --> Helper loaded: form_helper
INFO - 2016-07-20 15:04:37 --> Helper loaded: file_helper
INFO - 2016-07-20 15:04:37 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:04:37 --> Database Driver Class Initialized
INFO - 2016-07-20 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:04:38 --> Form Validation Class Initialized
INFO - 2016-07-20 15:04:38 --> Email Class Initialized
INFO - 2016-07-20 15:04:38 --> Controller Class Initialized
INFO - 2016-07-20 15:04:39 --> Config Class Initialized
INFO - 2016-07-20 15:04:39 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:04:39 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:04:39 --> Utf8 Class Initialized
INFO - 2016-07-20 15:04:39 --> URI Class Initialized
INFO - 2016-07-20 15:04:39 --> Router Class Initialized
INFO - 2016-07-20 15:04:39 --> Output Class Initialized
INFO - 2016-07-20 15:04:39 --> Security Class Initialized
DEBUG - 2016-07-20 15:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:04:39 --> Input Class Initialized
INFO - 2016-07-20 15:04:39 --> Language Class Initialized
INFO - 2016-07-20 15:04:39 --> Loader Class Initialized
INFO - 2016-07-20 15:04:39 --> Helper loaded: url_helper
INFO - 2016-07-20 15:04:39 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:04:39 --> Helper loaded: html_helper
INFO - 2016-07-20 15:04:39 --> Helper loaded: form_helper
INFO - 2016-07-20 15:04:39 --> Helper loaded: file_helper
INFO - 2016-07-20 15:04:39 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:04:39 --> Database Driver Class Initialized
INFO - 2016-07-20 15:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:04:39 --> Form Validation Class Initialized
INFO - 2016-07-20 15:04:39 --> Email Class Initialized
INFO - 2016-07-20 15:04:40 --> Controller Class Initialized
INFO - 2016-07-20 15:04:40 --> Model Class Initialized
DEBUG - 2016-07-20 15:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-20 15:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-20 15:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 15:04:40 --> Final output sent to browser
DEBUG - 2016-07-20 15:04:40 --> Total execution time: 0.5553
INFO - 2016-07-20 15:04:40 --> Config Class Initialized
INFO - 2016-07-20 15:04:40 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:04:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:04:40 --> Utf8 Class Initialized
INFO - 2016-07-20 15:04:40 --> URI Class Initialized
INFO - 2016-07-20 15:04:40 --> Router Class Initialized
INFO - 2016-07-20 15:04:40 --> Output Class Initialized
INFO - 2016-07-20 15:04:40 --> Security Class Initialized
DEBUG - 2016-07-20 15:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:04:40 --> Input Class Initialized
INFO - 2016-07-20 15:04:40 --> Language Class Initialized
ERROR - 2016-07-20 15:04:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 15:04:40 --> Config Class Initialized
INFO - 2016-07-20 15:04:40 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:04:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:04:40 --> Utf8 Class Initialized
INFO - 2016-07-20 15:04:40 --> URI Class Initialized
INFO - 2016-07-20 15:04:40 --> Router Class Initialized
INFO - 2016-07-20 15:04:40 --> Output Class Initialized
INFO - 2016-07-20 15:04:40 --> Security Class Initialized
DEBUG - 2016-07-20 15:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:04:40 --> Input Class Initialized
INFO - 2016-07-20 15:04:40 --> Language Class Initialized
ERROR - 2016-07-20 15:04:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 15:23:00 --> Config Class Initialized
INFO - 2016-07-20 15:23:00 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:23:00 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:23:00 --> Utf8 Class Initialized
INFO - 2016-07-20 15:23:00 --> URI Class Initialized
INFO - 2016-07-20 15:23:00 --> Router Class Initialized
INFO - 2016-07-20 15:23:00 --> Output Class Initialized
INFO - 2016-07-20 15:23:00 --> Security Class Initialized
DEBUG - 2016-07-20 15:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:23:00 --> Input Class Initialized
INFO - 2016-07-20 15:23:00 --> Language Class Initialized
INFO - 2016-07-20 15:23:00 --> Loader Class Initialized
INFO - 2016-07-20 15:23:00 --> Helper loaded: url_helper
INFO - 2016-07-20 15:23:00 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:23:00 --> Helper loaded: html_helper
INFO - 2016-07-20 15:23:00 --> Helper loaded: form_helper
INFO - 2016-07-20 15:23:00 --> Helper loaded: file_helper
INFO - 2016-07-20 15:23:00 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:23:00 --> Database Driver Class Initialized
INFO - 2016-07-20 15:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:23:00 --> Form Validation Class Initialized
INFO - 2016-07-20 15:23:00 --> Email Class Initialized
INFO - 2016-07-20 15:23:00 --> Controller Class Initialized
INFO - 2016-07-20 15:23:00 --> Model Class Initialized
DEBUG - 2016-07-20 15:23:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:23:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 15:23:00 --> Config Class Initialized
INFO - 2016-07-20 15:23:00 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:23:00 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:23:00 --> Utf8 Class Initialized
INFO - 2016-07-20 15:23:00 --> URI Class Initialized
INFO - 2016-07-20 15:23:00 --> Router Class Initialized
INFO - 2016-07-20 15:23:00 --> Output Class Initialized
INFO - 2016-07-20 15:23:00 --> Security Class Initialized
DEBUG - 2016-07-20 15:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:23:00 --> Input Class Initialized
INFO - 2016-07-20 15:23:01 --> Language Class Initialized
INFO - 2016-07-20 15:23:01 --> Loader Class Initialized
INFO - 2016-07-20 15:23:01 --> Helper loaded: url_helper
INFO - 2016-07-20 15:23:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:23:01 --> Helper loaded: html_helper
INFO - 2016-07-20 15:23:01 --> Helper loaded: form_helper
INFO - 2016-07-20 15:23:01 --> Helper loaded: file_helper
INFO - 2016-07-20 15:23:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:23:01 --> Database Driver Class Initialized
INFO - 2016-07-20 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:23:01 --> Form Validation Class Initialized
INFO - 2016-07-20 15:23:01 --> Email Class Initialized
INFO - 2016-07-20 15:23:01 --> Controller Class Initialized
DEBUG - 2016-07-20 15:23:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:23:01 --> Model Class Initialized
INFO - 2016-07-20 15:23:01 --> Model Class Initialized
INFO - 2016-07-20 15:23:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:23:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:23:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 15:23:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 15:23:01 --> Final output sent to browser
DEBUG - 2016-07-20 15:23:01 --> Total execution time: 0.5488
INFO - 2016-07-20 15:23:46 --> Config Class Initialized
INFO - 2016-07-20 15:23:47 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:23:47 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:23:47 --> Utf8 Class Initialized
INFO - 2016-07-20 15:23:47 --> URI Class Initialized
INFO - 2016-07-20 15:23:47 --> Router Class Initialized
INFO - 2016-07-20 15:23:47 --> Output Class Initialized
INFO - 2016-07-20 15:23:47 --> Security Class Initialized
DEBUG - 2016-07-20 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:23:47 --> Input Class Initialized
INFO - 2016-07-20 15:23:47 --> Language Class Initialized
INFO - 2016-07-20 15:23:47 --> Loader Class Initialized
INFO - 2016-07-20 15:23:47 --> Helper loaded: url_helper
INFO - 2016-07-20 15:23:47 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:23:47 --> Helper loaded: html_helper
INFO - 2016-07-20 15:23:47 --> Helper loaded: form_helper
INFO - 2016-07-20 15:23:47 --> Helper loaded: file_helper
INFO - 2016-07-20 15:23:47 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:23:47 --> Database Driver Class Initialized
INFO - 2016-07-20 15:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:23:47 --> Form Validation Class Initialized
INFO - 2016-07-20 15:23:47 --> Email Class Initialized
INFO - 2016-07-20 15:23:47 --> Controller Class Initialized
DEBUG - 2016-07-20 15:23:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:23:47 --> Model Class Initialized
INFO - 2016-07-20 15:23:47 --> Model Class Initialized
INFO - 2016-07-20 15:23:47 --> Model Class Initialized
INFO - 2016-07-20 15:23:47 --> Model Class Initialized
INFO - 2016-07-20 15:23:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:23:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:23:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:23:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 15:23:47 --> Final output sent to browser
DEBUG - 2016-07-20 15:23:47 --> Total execution time: 0.3990
INFO - 2016-07-20 15:24:01 --> Config Class Initialized
INFO - 2016-07-20 15:24:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:24:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:24:01 --> Utf8 Class Initialized
INFO - 2016-07-20 15:24:01 --> URI Class Initialized
INFO - 2016-07-20 15:24:01 --> Router Class Initialized
INFO - 2016-07-20 15:24:01 --> Output Class Initialized
INFO - 2016-07-20 15:24:01 --> Security Class Initialized
DEBUG - 2016-07-20 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:24:01 --> Input Class Initialized
INFO - 2016-07-20 15:24:01 --> Language Class Initialized
INFO - 2016-07-20 15:24:02 --> Loader Class Initialized
INFO - 2016-07-20 15:24:02 --> Helper loaded: url_helper
INFO - 2016-07-20 15:24:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:24:02 --> Helper loaded: html_helper
INFO - 2016-07-20 15:24:02 --> Helper loaded: form_helper
INFO - 2016-07-20 15:24:02 --> Helper loaded: file_helper
INFO - 2016-07-20 15:24:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:24:02 --> Database Driver Class Initialized
INFO - 2016-07-20 15:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:24:02 --> Form Validation Class Initialized
INFO - 2016-07-20 15:24:02 --> Email Class Initialized
INFO - 2016-07-20 15:24:02 --> Controller Class Initialized
DEBUG - 2016-07-20 15:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:24:02 --> Model Class Initialized
INFO - 2016-07-20 15:24:02 --> Model Class Initialized
INFO - 2016-07-20 15:24:02 --> Model Class Initialized
INFO - 2016-07-20 15:24:02 --> Model Class Initialized
INFO - 2016-07-20 15:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 15:24:02 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1520
ERROR - 2016-07-20 15:24:02 --> Severity: Warning --> sort() expects parameter 1 to be array, null given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1521
ERROR - 2016-07-20 15:24:02 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1549
INFO - 2016-07-20 15:24:02 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 15:31:09 --> Config Class Initialized
INFO - 2016-07-20 15:31:09 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:31:09 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:31:09 --> Utf8 Class Initialized
INFO - 2016-07-20 15:31:09 --> URI Class Initialized
INFO - 2016-07-20 15:31:09 --> Router Class Initialized
INFO - 2016-07-20 15:31:09 --> Output Class Initialized
INFO - 2016-07-20 15:31:09 --> Security Class Initialized
DEBUG - 2016-07-20 15:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:31:09 --> Input Class Initialized
INFO - 2016-07-20 15:31:09 --> Language Class Initialized
INFO - 2016-07-20 15:31:09 --> Loader Class Initialized
INFO - 2016-07-20 15:31:09 --> Helper loaded: url_helper
INFO - 2016-07-20 15:31:09 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:31:09 --> Helper loaded: html_helper
INFO - 2016-07-20 15:31:09 --> Helper loaded: form_helper
INFO - 2016-07-20 15:31:09 --> Helper loaded: file_helper
INFO - 2016-07-20 15:31:09 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:31:09 --> Database Driver Class Initialized
INFO - 2016-07-20 15:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:31:09 --> Form Validation Class Initialized
INFO - 2016-07-20 15:31:09 --> Email Class Initialized
INFO - 2016-07-20 15:31:09 --> Controller Class Initialized
DEBUG - 2016-07-20 15:31:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:31:09 --> Model Class Initialized
INFO - 2016-07-20 15:31:09 --> Model Class Initialized
INFO - 2016-07-20 15:31:09 --> Model Class Initialized
INFO - 2016-07-20 15:31:09 --> Model Class Initialized
INFO - 2016-07-20 15:31:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:31:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:31:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:31:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 15:31:09 --> Final output sent to browser
DEBUG - 2016-07-20 15:31:09 --> Total execution time: 0.4055
INFO - 2016-07-20 15:33:39 --> Config Class Initialized
INFO - 2016-07-20 15:33:39 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:33:39 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:33:39 --> Utf8 Class Initialized
INFO - 2016-07-20 15:33:39 --> URI Class Initialized
INFO - 2016-07-20 15:33:39 --> Router Class Initialized
INFO - 2016-07-20 15:33:39 --> Output Class Initialized
INFO - 2016-07-20 15:33:39 --> Security Class Initialized
DEBUG - 2016-07-20 15:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:33:39 --> Input Class Initialized
INFO - 2016-07-20 15:33:39 --> Language Class Initialized
INFO - 2016-07-20 15:33:39 --> Loader Class Initialized
INFO - 2016-07-20 15:33:39 --> Helper loaded: url_helper
INFO - 2016-07-20 15:33:39 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:33:39 --> Helper loaded: html_helper
INFO - 2016-07-20 15:33:39 --> Helper loaded: form_helper
INFO - 2016-07-20 15:33:39 --> Helper loaded: file_helper
INFO - 2016-07-20 15:33:39 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:33:39 --> Database Driver Class Initialized
INFO - 2016-07-20 15:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:33:39 --> Form Validation Class Initialized
INFO - 2016-07-20 15:33:39 --> Email Class Initialized
INFO - 2016-07-20 15:33:39 --> Controller Class Initialized
DEBUG - 2016-07-20 15:33:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:33:39 --> Model Class Initialized
INFO - 2016-07-20 15:33:39 --> Model Class Initialized
INFO - 2016-07-20 15:33:39 --> Model Class Initialized
INFO - 2016-07-20 15:33:39 --> Model Class Initialized
INFO - 2016-07-20 15:33:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:33:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:33:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:33:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 15:33:39 --> Severity: Warning --> array_keys() expects parameter 1 to be array, boolean given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1520
ERROR - 2016-07-20 15:33:39 --> Severity: Warning --> sort() expects parameter 1 to be array, null given D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1521
ERROR - 2016-07-20 15:33:39 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\system\database\DB_query_builder.php 1549
INFO - 2016-07-20 15:33:39 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 15:54:29 --> Config Class Initialized
INFO - 2016-07-20 15:54:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:54:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:54:29 --> Utf8 Class Initialized
INFO - 2016-07-20 15:54:29 --> URI Class Initialized
INFO - 2016-07-20 15:54:29 --> Router Class Initialized
INFO - 2016-07-20 15:54:29 --> Output Class Initialized
INFO - 2016-07-20 15:54:29 --> Security Class Initialized
DEBUG - 2016-07-20 15:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:54:29 --> Input Class Initialized
INFO - 2016-07-20 15:54:29 --> Language Class Initialized
INFO - 2016-07-20 15:54:29 --> Loader Class Initialized
INFO - 2016-07-20 15:54:29 --> Helper loaded: url_helper
INFO - 2016-07-20 15:54:29 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:54:29 --> Helper loaded: html_helper
INFO - 2016-07-20 15:54:29 --> Helper loaded: form_helper
INFO - 2016-07-20 15:54:29 --> Helper loaded: file_helper
INFO - 2016-07-20 15:54:29 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:54:29 --> Database Driver Class Initialized
INFO - 2016-07-20 15:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:54:29 --> Form Validation Class Initialized
INFO - 2016-07-20 15:54:29 --> Email Class Initialized
INFO - 2016-07-20 15:54:29 --> Controller Class Initialized
DEBUG - 2016-07-20 15:54:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:54:29 --> Model Class Initialized
INFO - 2016-07-20 15:54:29 --> Model Class Initialized
INFO - 2016-07-20 15:54:29 --> Model Class Initialized
INFO - 2016-07-20 15:54:29 --> Model Class Initialized
INFO - 2016-07-20 15:54:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:54:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:54:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:54:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 15:54:29 --> Severity: Notice --> Array to string conversion D:\wamp\www\library.pnc.lan\application\controllers\Books.php 292
INFO - 2016-07-20 15:54:49 --> Config Class Initialized
INFO - 2016-07-20 15:54:49 --> Hooks Class Initialized
DEBUG - 2016-07-20 15:54:49 --> UTF-8 Support Enabled
INFO - 2016-07-20 15:54:49 --> Utf8 Class Initialized
INFO - 2016-07-20 15:54:49 --> URI Class Initialized
INFO - 2016-07-20 15:54:49 --> Router Class Initialized
INFO - 2016-07-20 15:54:49 --> Output Class Initialized
INFO - 2016-07-20 15:54:49 --> Security Class Initialized
DEBUG - 2016-07-20 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 15:54:49 --> Input Class Initialized
INFO - 2016-07-20 15:54:49 --> Language Class Initialized
INFO - 2016-07-20 15:54:49 --> Loader Class Initialized
INFO - 2016-07-20 15:54:49 --> Helper loaded: url_helper
INFO - 2016-07-20 15:54:49 --> Helper loaded: utils_helper
INFO - 2016-07-20 15:54:49 --> Helper loaded: html_helper
INFO - 2016-07-20 15:54:49 --> Helper loaded: form_helper
INFO - 2016-07-20 15:54:49 --> Helper loaded: file_helper
INFO - 2016-07-20 15:54:49 --> Helper loaded: myemail_helper
INFO - 2016-07-20 15:54:49 --> Database Driver Class Initialized
INFO - 2016-07-20 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 15:54:49 --> Form Validation Class Initialized
INFO - 2016-07-20 15:54:49 --> Email Class Initialized
INFO - 2016-07-20 15:54:49 --> Controller Class Initialized
DEBUG - 2016-07-20 15:54:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 15:54:49 --> Model Class Initialized
INFO - 2016-07-20 15:54:49 --> Model Class Initialized
INFO - 2016-07-20 15:54:49 --> Model Class Initialized
INFO - 2016-07-20 15:54:49 --> Model Class Initialized
INFO - 2016-07-20 15:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 15:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 15:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 15:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:02:08 --> Config Class Initialized
INFO - 2016-07-20 16:02:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:02:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:02:08 --> Utf8 Class Initialized
INFO - 2016-07-20 16:02:08 --> URI Class Initialized
INFO - 2016-07-20 16:02:08 --> Router Class Initialized
INFO - 2016-07-20 16:02:08 --> Output Class Initialized
INFO - 2016-07-20 16:02:08 --> Security Class Initialized
DEBUG - 2016-07-20 16:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:02:08 --> Input Class Initialized
INFO - 2016-07-20 16:02:08 --> Language Class Initialized
INFO - 2016-07-20 16:02:08 --> Loader Class Initialized
INFO - 2016-07-20 16:02:08 --> Helper loaded: url_helper
INFO - 2016-07-20 16:02:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:02:08 --> Helper loaded: html_helper
INFO - 2016-07-20 16:02:08 --> Helper loaded: form_helper
INFO - 2016-07-20 16:02:08 --> Helper loaded: file_helper
INFO - 2016-07-20 16:02:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:02:08 --> Database Driver Class Initialized
INFO - 2016-07-20 16:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:02:08 --> Form Validation Class Initialized
INFO - 2016-07-20 16:02:08 --> Email Class Initialized
INFO - 2016-07-20 16:02:08 --> Controller Class Initialized
DEBUG - 2016-07-20 16:02:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:02:08 --> Model Class Initialized
INFO - 2016-07-20 16:02:08 --> Model Class Initialized
INFO - 2016-07-20 16:02:08 --> Model Class Initialized
INFO - 2016-07-20 16:02:08 --> Model Class Initialized
INFO - 2016-07-20 16:02:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:02:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:02:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:02:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:02:11 --> Config Class Initialized
INFO - 2016-07-20 16:02:11 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:02:11 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:02:11 --> Utf8 Class Initialized
INFO - 2016-07-20 16:02:11 --> URI Class Initialized
INFO - 2016-07-20 16:02:11 --> Router Class Initialized
INFO - 2016-07-20 16:02:11 --> Output Class Initialized
INFO - 2016-07-20 16:02:11 --> Security Class Initialized
DEBUG - 2016-07-20 16:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:02:11 --> Input Class Initialized
INFO - 2016-07-20 16:02:11 --> Language Class Initialized
INFO - 2016-07-20 16:02:11 --> Loader Class Initialized
INFO - 2016-07-20 16:02:11 --> Helper loaded: url_helper
INFO - 2016-07-20 16:02:11 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:02:11 --> Helper loaded: html_helper
INFO - 2016-07-20 16:02:11 --> Helper loaded: form_helper
INFO - 2016-07-20 16:02:11 --> Helper loaded: file_helper
INFO - 2016-07-20 16:02:11 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:02:11 --> Database Driver Class Initialized
INFO - 2016-07-20 16:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:02:11 --> Form Validation Class Initialized
INFO - 2016-07-20 16:02:11 --> Email Class Initialized
INFO - 2016-07-20 16:02:11 --> Controller Class Initialized
DEBUG - 2016-07-20 16:02:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:02:11 --> Model Class Initialized
INFO - 2016-07-20 16:02:11 --> Model Class Initialized
INFO - 2016-07-20 16:02:11 --> Model Class Initialized
INFO - 2016-07-20 16:02:11 --> Model Class Initialized
INFO - 2016-07-20 16:02:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:02:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:02:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:02:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:02:11 --> Final output sent to browser
DEBUG - 2016-07-20 16:02:11 --> Total execution time: 0.4027
INFO - 2016-07-20 16:02:12 --> Config Class Initialized
INFO - 2016-07-20 16:02:12 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:02:12 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:02:13 --> Utf8 Class Initialized
INFO - 2016-07-20 16:02:13 --> URI Class Initialized
INFO - 2016-07-20 16:02:13 --> Router Class Initialized
INFO - 2016-07-20 16:02:13 --> Output Class Initialized
INFO - 2016-07-20 16:02:13 --> Security Class Initialized
DEBUG - 2016-07-20 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:02:13 --> Input Class Initialized
INFO - 2016-07-20 16:02:13 --> Language Class Initialized
INFO - 2016-07-20 16:02:13 --> Loader Class Initialized
INFO - 2016-07-20 16:02:13 --> Helper loaded: url_helper
INFO - 2016-07-20 16:02:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:02:13 --> Helper loaded: html_helper
INFO - 2016-07-20 16:02:13 --> Helper loaded: form_helper
INFO - 2016-07-20 16:02:13 --> Helper loaded: file_helper
INFO - 2016-07-20 16:02:13 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:02:13 --> Database Driver Class Initialized
INFO - 2016-07-20 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:02:13 --> Form Validation Class Initialized
INFO - 2016-07-20 16:02:13 --> Email Class Initialized
INFO - 2016-07-20 16:02:13 --> Controller Class Initialized
DEBUG - 2016-07-20 16:02:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:02:13 --> Model Class Initialized
INFO - 2016-07-20 16:02:13 --> Model Class Initialized
INFO - 2016-07-20 16:02:13 --> Model Class Initialized
INFO - 2016-07-20 16:02:13 --> Model Class Initialized
INFO - 2016-07-20 16:02:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:02:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:02:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:02:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:02:13 --> Final output sent to browser
DEBUG - 2016-07-20 16:02:13 --> Total execution time: 0.4057
INFO - 2016-07-20 16:02:22 --> Config Class Initialized
INFO - 2016-07-20 16:02:22 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:02:22 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:02:22 --> Utf8 Class Initialized
INFO - 2016-07-20 16:02:22 --> URI Class Initialized
INFO - 2016-07-20 16:02:22 --> Router Class Initialized
INFO - 2016-07-20 16:02:22 --> Output Class Initialized
INFO - 2016-07-20 16:02:22 --> Security Class Initialized
DEBUG - 2016-07-20 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:02:22 --> Input Class Initialized
INFO - 2016-07-20 16:02:22 --> Language Class Initialized
INFO - 2016-07-20 16:02:22 --> Loader Class Initialized
INFO - 2016-07-20 16:02:22 --> Helper loaded: url_helper
INFO - 2016-07-20 16:02:22 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:02:23 --> Helper loaded: html_helper
INFO - 2016-07-20 16:02:23 --> Helper loaded: form_helper
INFO - 2016-07-20 16:02:23 --> Helper loaded: file_helper
INFO - 2016-07-20 16:02:23 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:02:23 --> Database Driver Class Initialized
INFO - 2016-07-20 16:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:02:23 --> Form Validation Class Initialized
INFO - 2016-07-20 16:02:23 --> Email Class Initialized
INFO - 2016-07-20 16:02:23 --> Controller Class Initialized
DEBUG - 2016-07-20 16:02:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:02:23 --> Model Class Initialized
INFO - 2016-07-20 16:02:23 --> Model Class Initialized
INFO - 2016-07-20 16:02:23 --> Model Class Initialized
INFO - 2016-07-20 16:02:23 --> Model Class Initialized
INFO - 2016-07-20 16:02:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:02:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:02:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:02:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:02:55 --> Config Class Initialized
INFO - 2016-07-20 16:02:55 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:02:55 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:02:55 --> Utf8 Class Initialized
INFO - 2016-07-20 16:02:55 --> URI Class Initialized
INFO - 2016-07-20 16:02:55 --> Router Class Initialized
INFO - 2016-07-20 16:02:55 --> Output Class Initialized
INFO - 2016-07-20 16:02:55 --> Security Class Initialized
DEBUG - 2016-07-20 16:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:02:55 --> Input Class Initialized
INFO - 2016-07-20 16:02:55 --> Language Class Initialized
INFO - 2016-07-20 16:02:55 --> Loader Class Initialized
INFO - 2016-07-20 16:02:55 --> Helper loaded: url_helper
INFO - 2016-07-20 16:02:55 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:02:55 --> Helper loaded: html_helper
INFO - 2016-07-20 16:02:55 --> Helper loaded: form_helper
INFO - 2016-07-20 16:02:55 --> Helper loaded: file_helper
INFO - 2016-07-20 16:02:55 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:02:55 --> Database Driver Class Initialized
INFO - 2016-07-20 16:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:02:55 --> Form Validation Class Initialized
INFO - 2016-07-20 16:02:55 --> Email Class Initialized
INFO - 2016-07-20 16:02:55 --> Controller Class Initialized
DEBUG - 2016-07-20 16:02:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:02:55 --> Model Class Initialized
INFO - 2016-07-20 16:02:55 --> Model Class Initialized
INFO - 2016-07-20 16:02:55 --> Model Class Initialized
INFO - 2016-07-20 16:02:55 --> Model Class Initialized
INFO - 2016-07-20 16:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:03:12 --> Config Class Initialized
INFO - 2016-07-20 16:03:12 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:03:12 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:03:12 --> Utf8 Class Initialized
INFO - 2016-07-20 16:03:12 --> URI Class Initialized
INFO - 2016-07-20 16:03:12 --> Router Class Initialized
INFO - 2016-07-20 16:03:12 --> Output Class Initialized
INFO - 2016-07-20 16:03:12 --> Security Class Initialized
DEBUG - 2016-07-20 16:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:03:12 --> Input Class Initialized
INFO - 2016-07-20 16:03:12 --> Language Class Initialized
INFO - 2016-07-20 16:03:12 --> Loader Class Initialized
INFO - 2016-07-20 16:03:12 --> Helper loaded: url_helper
INFO - 2016-07-20 16:03:12 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:03:12 --> Helper loaded: html_helper
INFO - 2016-07-20 16:03:12 --> Helper loaded: form_helper
INFO - 2016-07-20 16:03:12 --> Helper loaded: file_helper
INFO - 2016-07-20 16:03:12 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:03:12 --> Database Driver Class Initialized
INFO - 2016-07-20 16:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:03:12 --> Form Validation Class Initialized
INFO - 2016-07-20 16:03:12 --> Email Class Initialized
INFO - 2016-07-20 16:03:12 --> Controller Class Initialized
DEBUG - 2016-07-20 16:03:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:03:12 --> Model Class Initialized
INFO - 2016-07-20 16:03:12 --> Model Class Initialized
INFO - 2016-07-20 16:03:12 --> Model Class Initialized
INFO - 2016-07-20 16:03:12 --> Model Class Initialized
INFO - 2016-07-20 16:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:05:57 --> Config Class Initialized
INFO - 2016-07-20 16:05:57 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:05:57 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:05:57 --> Utf8 Class Initialized
INFO - 2016-07-20 16:05:57 --> URI Class Initialized
INFO - 2016-07-20 16:05:58 --> Router Class Initialized
INFO - 2016-07-20 16:05:58 --> Output Class Initialized
INFO - 2016-07-20 16:05:58 --> Security Class Initialized
DEBUG - 2016-07-20 16:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:05:58 --> Input Class Initialized
INFO - 2016-07-20 16:05:58 --> Language Class Initialized
INFO - 2016-07-20 16:05:58 --> Loader Class Initialized
INFO - 2016-07-20 16:05:58 --> Helper loaded: url_helper
INFO - 2016-07-20 16:05:58 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:05:58 --> Helper loaded: html_helper
INFO - 2016-07-20 16:05:58 --> Helper loaded: form_helper
INFO - 2016-07-20 16:05:58 --> Helper loaded: file_helper
INFO - 2016-07-20 16:05:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:05:58 --> Database Driver Class Initialized
INFO - 2016-07-20 16:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:05:58 --> Form Validation Class Initialized
INFO - 2016-07-20 16:05:58 --> Email Class Initialized
INFO - 2016-07-20 16:05:58 --> Controller Class Initialized
DEBUG - 2016-07-20 16:05:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:05:58 --> Model Class Initialized
INFO - 2016-07-20 16:05:58 --> Model Class Initialized
INFO - 2016-07-20 16:05:58 --> Model Class Initialized
INFO - 2016-07-20 16:05:58 --> Model Class Initialized
INFO - 2016-07-20 16:05:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:05:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:05:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:05:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:05:58 --> Final output sent to browser
DEBUG - 2016-07-20 16:05:58 --> Total execution time: 0.4191
INFO - 2016-07-20 16:06:08 --> Config Class Initialized
INFO - 2016-07-20 16:06:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:06:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:06:08 --> Utf8 Class Initialized
INFO - 2016-07-20 16:06:08 --> URI Class Initialized
INFO - 2016-07-20 16:06:08 --> Router Class Initialized
INFO - 2016-07-20 16:06:08 --> Output Class Initialized
INFO - 2016-07-20 16:06:08 --> Security Class Initialized
DEBUG - 2016-07-20 16:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:06:08 --> Input Class Initialized
INFO - 2016-07-20 16:06:08 --> Language Class Initialized
INFO - 2016-07-20 16:06:08 --> Loader Class Initialized
INFO - 2016-07-20 16:06:08 --> Helper loaded: url_helper
INFO - 2016-07-20 16:06:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:06:08 --> Helper loaded: html_helper
INFO - 2016-07-20 16:06:08 --> Helper loaded: form_helper
INFO - 2016-07-20 16:06:08 --> Helper loaded: file_helper
INFO - 2016-07-20 16:06:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:06:08 --> Database Driver Class Initialized
INFO - 2016-07-20 16:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:06:08 --> Form Validation Class Initialized
INFO - 2016-07-20 16:06:08 --> Email Class Initialized
INFO - 2016-07-20 16:06:08 --> Controller Class Initialized
DEBUG - 2016-07-20 16:06:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:06:08 --> Model Class Initialized
INFO - 2016-07-20 16:06:08 --> Model Class Initialized
INFO - 2016-07-20 16:06:09 --> Model Class Initialized
INFO - 2016-07-20 16:06:09 --> Model Class Initialized
INFO - 2016-07-20 16:06:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:06:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:06:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:06:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
ERROR - 2016-07-20 16:06:09 --> Query error: Unknown column 'b_auther_kh' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_keyword`, `b_label`, `b_language`, `b_publisher`, `b_title_en`, `b_title_kh`, `b_year`, `cat_id`, `con_id`, `sta_id`) VALUES (NULL,'Jon Naunton ; Mark Tulip',2016070195,NULL,9780194575782,'Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','នីតិកិច្ចសន្យា',2004,15,2,1), (NULL,'Jon Naunton ; Mark Tulip',2016070237,NULL,9780194575782,'Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','នីតិកិច្ចសន្យា',2004,15,2,1), ('ជាប សាកល','Chheab Sakal',2016070277,NULL,'No ISBN','Law','300 ជាប','Khmer','University of National Management','Contract Law','នីតិកិច្ចសន្យា',2011,15,2,1)
INFO - 2016-07-20 16:06:09 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-20 16:09:36 --> Config Class Initialized
INFO - 2016-07-20 16:09:36 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:09:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:09:36 --> Utf8 Class Initialized
INFO - 2016-07-20 16:09:36 --> URI Class Initialized
INFO - 2016-07-20 16:09:36 --> Router Class Initialized
INFO - 2016-07-20 16:09:36 --> Output Class Initialized
INFO - 2016-07-20 16:09:36 --> Security Class Initialized
DEBUG - 2016-07-20 16:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:09:36 --> Input Class Initialized
INFO - 2016-07-20 16:09:36 --> Language Class Initialized
INFO - 2016-07-20 16:09:36 --> Loader Class Initialized
INFO - 2016-07-20 16:09:36 --> Helper loaded: url_helper
INFO - 2016-07-20 16:09:36 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:09:36 --> Helper loaded: html_helper
INFO - 2016-07-20 16:09:36 --> Helper loaded: form_helper
INFO - 2016-07-20 16:09:36 --> Helper loaded: file_helper
INFO - 2016-07-20 16:09:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:09:36 --> Database Driver Class Initialized
INFO - 2016-07-20 16:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:09:36 --> Form Validation Class Initialized
INFO - 2016-07-20 16:09:36 --> Email Class Initialized
INFO - 2016-07-20 16:09:36 --> Controller Class Initialized
DEBUG - 2016-07-20 16:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:09:36 --> Model Class Initialized
INFO - 2016-07-20 16:09:36 --> Model Class Initialized
INFO - 2016-07-20 16:09:36 --> Model Class Initialized
INFO - 2016-07-20 16:09:36 --> Model Class Initialized
INFO - 2016-07-20 16:09:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:09:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:09:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:09:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:09:37 --> Config Class Initialized
INFO - 2016-07-20 16:09:37 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:09:37 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:09:37 --> Utf8 Class Initialized
INFO - 2016-07-20 16:09:37 --> URI Class Initialized
INFO - 2016-07-20 16:09:37 --> Router Class Initialized
INFO - 2016-07-20 16:09:37 --> Output Class Initialized
INFO - 2016-07-20 16:09:37 --> Security Class Initialized
DEBUG - 2016-07-20 16:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:09:37 --> Input Class Initialized
INFO - 2016-07-20 16:09:37 --> Language Class Initialized
INFO - 2016-07-20 16:09:37 --> Loader Class Initialized
INFO - 2016-07-20 16:09:37 --> Helper loaded: url_helper
INFO - 2016-07-20 16:09:37 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:09:37 --> Helper loaded: html_helper
INFO - 2016-07-20 16:09:37 --> Helper loaded: form_helper
INFO - 2016-07-20 16:09:37 --> Helper loaded: file_helper
INFO - 2016-07-20 16:09:37 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:09:37 --> Database Driver Class Initialized
INFO - 2016-07-20 16:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:09:37 --> Form Validation Class Initialized
INFO - 2016-07-20 16:09:37 --> Email Class Initialized
INFO - 2016-07-20 16:09:37 --> Controller Class Initialized
DEBUG - 2016-07-20 16:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:09:37 --> Model Class Initialized
INFO - 2016-07-20 16:09:37 --> Model Class Initialized
INFO - 2016-07-20 16:09:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:09:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:09:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:09:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:09:37 --> Final output sent to browser
DEBUG - 2016-07-20 16:09:37 --> Total execution time: 0.3838
INFO - 2016-07-20 16:09:59 --> Config Class Initialized
INFO - 2016-07-20 16:09:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:09:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:09:59 --> Config Class Initialized
INFO - 2016-07-20 16:09:59 --> Hooks Class Initialized
INFO - 2016-07-20 16:09:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:09:59 --> URI Class Initialized
DEBUG - 2016-07-20 16:09:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:09:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:09:59 --> Router Class Initialized
INFO - 2016-07-20 16:09:59 --> URI Class Initialized
INFO - 2016-07-20 16:09:59 --> Output Class Initialized
INFO - 2016-07-20 16:09:59 --> Security Class Initialized
INFO - 2016-07-20 16:09:59 --> Router Class Initialized
INFO - 2016-07-20 16:09:59 --> Output Class Initialized
DEBUG - 2016-07-20 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:09:59 --> Input Class Initialized
INFO - 2016-07-20 16:09:59 --> Security Class Initialized
INFO - 2016-07-20 16:09:59 --> Language Class Initialized
DEBUG - 2016-07-20 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:09:59 --> Input Class Initialized
INFO - 2016-07-20 16:09:59 --> Loader Class Initialized
INFO - 2016-07-20 16:09:59 --> Language Class Initialized
INFO - 2016-07-20 16:09:59 --> Helper loaded: url_helper
INFO - 2016-07-20 16:09:59 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:09:59 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:09:59 --> Helper loaded: html_helper
INFO - 2016-07-20 16:09:59 --> Helper loaded: form_helper
INFO - 2016-07-20 16:09:59 --> Helper loaded: file_helper
INFO - 2016-07-20 16:09:59 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:09:59 --> Database Driver Class Initialized
INFO - 2016-07-20 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:09:59 --> Form Validation Class Initialized
INFO - 2016-07-20 16:09:59 --> Email Class Initialized
INFO - 2016-07-20 16:09:59 --> Controller Class Initialized
DEBUG - 2016-07-20 16:09:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:09:59 --> Model Class Initialized
INFO - 2016-07-20 16:09:59 --> Model Class Initialized
INFO - 2016-07-20 16:09:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:09:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:09:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:09:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:09:59 --> Final output sent to browser
DEBUG - 2016-07-20 16:09:59 --> Total execution time: 0.4665
INFO - 2016-07-20 16:13:51 --> Config Class Initialized
INFO - 2016-07-20 16:13:51 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:51 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:51 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:51 --> URI Class Initialized
INFO - 2016-07-20 16:13:51 --> Router Class Initialized
INFO - 2016-07-20 16:13:51 --> Output Class Initialized
INFO - 2016-07-20 16:13:51 --> Security Class Initialized
DEBUG - 2016-07-20 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:51 --> Input Class Initialized
INFO - 2016-07-20 16:13:51 --> Language Class Initialized
INFO - 2016-07-20 16:13:51 --> Loader Class Initialized
INFO - 2016-07-20 16:13:51 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:51 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:13:51 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:51 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:51 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:51 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:51 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:51 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:51 --> Email Class Initialized
INFO - 2016-07-20 16:13:51 --> Controller Class Initialized
DEBUG - 2016-07-20 16:13:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:13:51 --> Model Class Initialized
INFO - 2016-07-20 16:13:51 --> Model Class Initialized
INFO - 2016-07-20 16:13:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:13:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:51 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:51 --> Total execution time: 0.3988
INFO - 2016-07-20 16:13:52 --> Config Class Initialized
INFO - 2016-07-20 16:13:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:52 --> Config Class Initialized
INFO - 2016-07-20 16:13:52 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:52 --> Hooks Class Initialized
INFO - 2016-07-20 16:13:52 --> URI Class Initialized
DEBUG - 2016-07-20 16:13:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:52 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:52 --> Router Class Initialized
INFO - 2016-07-20 16:13:52 --> URI Class Initialized
INFO - 2016-07-20 16:13:52 --> Output Class Initialized
INFO - 2016-07-20 16:13:52 --> Router Class Initialized
INFO - 2016-07-20 16:13:52 --> Security Class Initialized
INFO - 2016-07-20 16:13:52 --> Output Class Initialized
DEBUG - 2016-07-20 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:52 --> Input Class Initialized
INFO - 2016-07-20 16:13:52 --> Security Class Initialized
INFO - 2016-07-20 16:13:52 --> Language Class Initialized
DEBUG - 2016-07-20 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:52 --> Input Class Initialized
INFO - 2016-07-20 16:13:52 --> Loader Class Initialized
INFO - 2016-07-20 16:13:52 --> Language Class Initialized
INFO - 2016-07-20 16:13:52 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:52 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:13:52 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:13:52 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:52 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:52 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:52 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:52 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:52 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:52 --> Email Class Initialized
INFO - 2016-07-20 16:13:52 --> Controller Class Initialized
DEBUG - 2016-07-20 16:13:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:13:52 --> Model Class Initialized
INFO - 2016-07-20 16:13:52 --> Model Class Initialized
INFO - 2016-07-20 16:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:52 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:52 --> Total execution time: 0.4590
INFO - 2016-07-20 16:13:54 --> Config Class Initialized
INFO - 2016-07-20 16:13:54 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:54 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:54 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:54 --> URI Class Initialized
INFO - 2016-07-20 16:13:54 --> Router Class Initialized
INFO - 2016-07-20 16:13:54 --> Output Class Initialized
INFO - 2016-07-20 16:13:54 --> Security Class Initialized
DEBUG - 2016-07-20 16:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:54 --> Input Class Initialized
INFO - 2016-07-20 16:13:54 --> Language Class Initialized
INFO - 2016-07-20 16:13:54 --> Loader Class Initialized
INFO - 2016-07-20 16:13:54 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:54 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:13:54 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:54 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:54 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:54 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:54 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:54 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:54 --> Email Class Initialized
INFO - 2016-07-20 16:13:54 --> Controller Class Initialized
DEBUG - 2016-07-20 16:13:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:13:54 --> Model Class Initialized
INFO - 2016-07-20 16:13:54 --> Model Class Initialized
INFO - 2016-07-20 16:13:54 --> Model Class Initialized
INFO - 2016-07-20 16:13:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-07-20 16:13:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:54 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:54 --> Total execution time: 0.4426
INFO - 2016-07-20 16:13:55 --> Config Class Initialized
INFO - 2016-07-20 16:13:55 --> Hooks Class Initialized
INFO - 2016-07-20 16:13:55 --> Config Class Initialized
INFO - 2016-07-20 16:13:55 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:55 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:55 --> Utf8 Class Initialized
DEBUG - 2016-07-20 16:13:55 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:55 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:55 --> URI Class Initialized
INFO - 2016-07-20 16:13:55 --> URI Class Initialized
INFO - 2016-07-20 16:13:55 --> Router Class Initialized
INFO - 2016-07-20 16:13:55 --> Router Class Initialized
INFO - 2016-07-20 16:13:55 --> Output Class Initialized
INFO - 2016-07-20 16:13:55 --> Security Class Initialized
INFO - 2016-07-20 16:13:55 --> Output Class Initialized
DEBUG - 2016-07-20 16:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:55 --> Security Class Initialized
INFO - 2016-07-20 16:13:55 --> Input Class Initialized
DEBUG - 2016-07-20 16:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:55 --> Input Class Initialized
INFO - 2016-07-20 16:13:55 --> Language Class Initialized
INFO - 2016-07-20 16:13:55 --> Language Class Initialized
INFO - 2016-07-20 16:13:55 --> Loader Class Initialized
ERROR - 2016-07-20 16:13:55 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:13:55 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:55 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:13:55 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:55 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:55 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:55 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:55 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:55 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:55 --> Email Class Initialized
INFO - 2016-07-20 16:13:55 --> Controller Class Initialized
DEBUG - 2016-07-20 16:13:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:13:55 --> Model Class Initialized
INFO - 2016-07-20 16:13:55 --> Model Class Initialized
INFO - 2016-07-20 16:13:55 --> Model Class Initialized
INFO - 2016-07-20 16:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-07-20 16:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:56 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:56 --> Total execution time: 0.4978
INFO - 2016-07-20 16:13:56 --> Config Class Initialized
INFO - 2016-07-20 16:13:56 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:56 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:56 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:56 --> URI Class Initialized
INFO - 2016-07-20 16:13:56 --> Router Class Initialized
INFO - 2016-07-20 16:13:56 --> Output Class Initialized
INFO - 2016-07-20 16:13:56 --> Security Class Initialized
DEBUG - 2016-07-20 16:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:56 --> Input Class Initialized
INFO - 2016-07-20 16:13:56 --> Language Class Initialized
INFO - 2016-07-20 16:13:56 --> Loader Class Initialized
INFO - 2016-07-20 16:13:56 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:56 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:13:56 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:56 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:56 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:56 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:56 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:56 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:56 --> Email Class Initialized
INFO - 2016-07-20 16:13:56 --> Controller Class Initialized
INFO - 2016-07-20 16:13:56 --> Model Class Initialized
INFO - 2016-07-20 16:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-07-20 16:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:57 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:57 --> Total execution time: 0.5137
INFO - 2016-07-20 16:13:57 --> Config Class Initialized
INFO - 2016-07-20 16:13:57 --> Hooks Class Initialized
INFO - 2016-07-20 16:13:57 --> Config Class Initialized
DEBUG - 2016-07-20 16:13:57 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:57 --> Hooks Class Initialized
INFO - 2016-07-20 16:13:57 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:57 --> URI Class Initialized
DEBUG - 2016-07-20 16:13:57 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:57 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:57 --> Router Class Initialized
INFO - 2016-07-20 16:13:57 --> URI Class Initialized
INFO - 2016-07-20 16:13:57 --> Output Class Initialized
INFO - 2016-07-20 16:13:57 --> Security Class Initialized
INFO - 2016-07-20 16:13:57 --> Router Class Initialized
DEBUG - 2016-07-20 16:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:57 --> Output Class Initialized
INFO - 2016-07-20 16:13:57 --> Input Class Initialized
INFO - 2016-07-20 16:13:57 --> Security Class Initialized
INFO - 2016-07-20 16:13:57 --> Language Class Initialized
DEBUG - 2016-07-20 16:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:57 --> Input Class Initialized
INFO - 2016-07-20 16:13:57 --> Loader Class Initialized
INFO - 2016-07-20 16:13:57 --> Language Class Initialized
INFO - 2016-07-20 16:13:57 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:57 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:13:57 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:13:57 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:58 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:58 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:58 --> Email Class Initialized
INFO - 2016-07-20 16:13:58 --> Controller Class Initialized
INFO - 2016-07-20 16:13:58 --> Model Class Initialized
INFO - 2016-07-20 16:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-07-20 16:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:58 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:58 --> Total execution time: 0.4198
INFO - 2016-07-20 16:13:58 --> Config Class Initialized
INFO - 2016-07-20 16:13:58 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:58 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:58 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:58 --> URI Class Initialized
INFO - 2016-07-20 16:13:58 --> Router Class Initialized
INFO - 2016-07-20 16:13:58 --> Output Class Initialized
INFO - 2016-07-20 16:13:58 --> Security Class Initialized
DEBUG - 2016-07-20 16:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:13:58 --> Input Class Initialized
INFO - 2016-07-20 16:13:58 --> Language Class Initialized
INFO - 2016-07-20 16:13:58 --> Loader Class Initialized
INFO - 2016-07-20 16:13:58 --> Helper loaded: url_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: html_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: form_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: file_helper
INFO - 2016-07-20 16:13:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:13:58 --> Database Driver Class Initialized
INFO - 2016-07-20 16:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:13:59 --> Form Validation Class Initialized
INFO - 2016-07-20 16:13:59 --> Email Class Initialized
INFO - 2016-07-20 16:13:59 --> Controller Class Initialized
INFO - 2016-07-20 16:13:59 --> Model Class Initialized
INFO - 2016-07-20 16:13:59 --> Model Class Initialized
DEBUG - 2016-07-20 16:13:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-07-20 16:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:13:59 --> Final output sent to browser
DEBUG - 2016-07-20 16:13:59 --> Total execution time: 0.4042
INFO - 2016-07-20 16:13:59 --> Config Class Initialized
INFO - 2016-07-20 16:13:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:13:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:59 --> Config Class Initialized
INFO - 2016-07-20 16:13:59 --> Hooks Class Initialized
INFO - 2016-07-20 16:13:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:59 --> URI Class Initialized
DEBUG - 2016-07-20 16:13:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:13:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:13:59 --> Router Class Initialized
INFO - 2016-07-20 16:13:59 --> URI Class Initialized
INFO - 2016-07-20 16:13:59 --> Output Class Initialized
INFO - 2016-07-20 16:13:59 --> Security Class Initialized
INFO - 2016-07-20 16:13:59 --> Router Class Initialized
DEBUG - 2016-07-20 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:00 --> Output Class Initialized
INFO - 2016-07-20 16:14:00 --> Input Class Initialized
INFO - 2016-07-20 16:14:00 --> Security Class Initialized
INFO - 2016-07-20 16:14:00 --> Language Class Initialized
DEBUG - 2016-07-20 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:00 --> Input Class Initialized
INFO - 2016-07-20 16:14:00 --> Loader Class Initialized
INFO - 2016-07-20 16:14:00 --> Language Class Initialized
INFO - 2016-07-20 16:14:00 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:00 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:14:00 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:14:00 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:00 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:00 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:00 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:00 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:00 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:00 --> Email Class Initialized
INFO - 2016-07-20 16:14:00 --> Controller Class Initialized
INFO - 2016-07-20 16:14:00 --> Model Class Initialized
INFO - 2016-07-20 16:14:00 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-07-20 16:14:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:00 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:00 --> Total execution time: 0.5173
INFO - 2016-07-20 16:14:00 --> Config Class Initialized
INFO - 2016-07-20 16:14:00 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:14:00 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:00 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:00 --> URI Class Initialized
INFO - 2016-07-20 16:14:00 --> Router Class Initialized
INFO - 2016-07-20 16:14:00 --> Output Class Initialized
INFO - 2016-07-20 16:14:00 --> Security Class Initialized
DEBUG - 2016-07-20 16:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:00 --> Input Class Initialized
INFO - 2016-07-20 16:14:00 --> Language Class Initialized
INFO - 2016-07-20 16:14:01 --> Loader Class Initialized
INFO - 2016-07-20 16:14:01 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:14:01 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:01 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:01 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:01 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:01 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:01 --> Email Class Initialized
INFO - 2016-07-20 16:14:01 --> Controller Class Initialized
INFO - 2016-07-20 16:14:01 --> Model Class Initialized
INFO - 2016-07-20 16:14:01 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-07-20 16:14:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:01 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:01 --> Total execution time: 0.4122
INFO - 2016-07-20 16:14:01 --> Config Class Initialized
INFO - 2016-07-20 16:14:01 --> Hooks Class Initialized
INFO - 2016-07-20 16:14:01 --> Config Class Initialized
DEBUG - 2016-07-20 16:14:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:01 --> Hooks Class Initialized
INFO - 2016-07-20 16:14:01 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:01 --> URI Class Initialized
DEBUG - 2016-07-20 16:14:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:01 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:01 --> Router Class Initialized
INFO - 2016-07-20 16:14:02 --> URI Class Initialized
INFO - 2016-07-20 16:14:02 --> Output Class Initialized
INFO - 2016-07-20 16:14:02 --> Security Class Initialized
INFO - 2016-07-20 16:14:02 --> Router Class Initialized
DEBUG - 2016-07-20 16:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:02 --> Output Class Initialized
INFO - 2016-07-20 16:14:02 --> Input Class Initialized
INFO - 2016-07-20 16:14:02 --> Security Class Initialized
INFO - 2016-07-20 16:14:02 --> Language Class Initialized
DEBUG - 2016-07-20 16:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:02 --> Input Class Initialized
INFO - 2016-07-20 16:14:02 --> Loader Class Initialized
INFO - 2016-07-20 16:14:02 --> Language Class Initialized
INFO - 2016-07-20 16:14:02 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:02 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:14:02 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:14:02 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:02 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:02 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:02 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:02 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:02 --> Email Class Initialized
INFO - 2016-07-20 16:14:02 --> Controller Class Initialized
INFO - 2016-07-20 16:14:02 --> Model Class Initialized
INFO - 2016-07-20 16:14:02 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-07-20 16:14:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:02 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:02 --> Total execution time: 0.4364
INFO - 2016-07-20 16:14:08 --> Config Class Initialized
INFO - 2016-07-20 16:14:08 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:14:08 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:08 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:08 --> URI Class Initialized
INFO - 2016-07-20 16:14:08 --> Router Class Initialized
INFO - 2016-07-20 16:14:08 --> Output Class Initialized
INFO - 2016-07-20 16:14:08 --> Security Class Initialized
DEBUG - 2016-07-20 16:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:08 --> Input Class Initialized
INFO - 2016-07-20 16:14:08 --> Language Class Initialized
INFO - 2016-07-20 16:14:08 --> Loader Class Initialized
INFO - 2016-07-20 16:14:08 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:08 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:14:08 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:08 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:08 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:08 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:08 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:08 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:08 --> Email Class Initialized
INFO - 2016-07-20 16:14:08 --> Controller Class Initialized
INFO - 2016-07-20 16:14:08 --> Model Class Initialized
INFO - 2016-07-20 16:14:08 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 16:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-07-20 16:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:08 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:08 --> Total execution time: 0.4577
INFO - 2016-07-20 16:14:09 --> Config Class Initialized
INFO - 2016-07-20 16:14:09 --> Hooks Class Initialized
INFO - 2016-07-20 16:14:09 --> Config Class Initialized
DEBUG - 2016-07-20 16:14:09 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:09 --> Hooks Class Initialized
INFO - 2016-07-20 16:14:09 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:09 --> URI Class Initialized
DEBUG - 2016-07-20 16:14:09 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:09 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:09 --> Router Class Initialized
INFO - 2016-07-20 16:14:09 --> URI Class Initialized
INFO - 2016-07-20 16:14:09 --> Output Class Initialized
INFO - 2016-07-20 16:14:09 --> Security Class Initialized
INFO - 2016-07-20 16:14:09 --> Router Class Initialized
INFO - 2016-07-20 16:14:09 --> Output Class Initialized
DEBUG - 2016-07-20 16:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:09 --> Input Class Initialized
INFO - 2016-07-20 16:14:09 --> Security Class Initialized
INFO - 2016-07-20 16:14:09 --> Language Class Initialized
DEBUG - 2016-07-20 16:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:09 --> Input Class Initialized
INFO - 2016-07-20 16:14:09 --> Loader Class Initialized
INFO - 2016-07-20 16:14:09 --> Language Class Initialized
INFO - 2016-07-20 16:14:09 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:09 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:14:09 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:14:09 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:09 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:09 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:09 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:09 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:09 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:09 --> Email Class Initialized
INFO - 2016-07-20 16:14:09 --> Controller Class Initialized
INFO - 2016-07-20 16:14:09 --> Model Class Initialized
INFO - 2016-07-20 16:14:09 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-07-20 16:14:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:09 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:09 --> Total execution time: 0.4563
INFO - 2016-07-20 16:14:18 --> Config Class Initialized
INFO - 2016-07-20 16:14:18 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:14:18 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:18 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:18 --> URI Class Initialized
INFO - 2016-07-20 16:14:18 --> Router Class Initialized
INFO - 2016-07-20 16:14:18 --> Output Class Initialized
INFO - 2016-07-20 16:14:18 --> Security Class Initialized
DEBUG - 2016-07-20 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:18 --> Input Class Initialized
INFO - 2016-07-20 16:14:18 --> Language Class Initialized
INFO - 2016-07-20 16:14:18 --> Loader Class Initialized
INFO - 2016-07-20 16:14:18 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:18 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:14:18 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:18 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:18 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:18 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:18 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:18 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:18 --> Email Class Initialized
INFO - 2016-07-20 16:14:18 --> Controller Class Initialized
INFO - 2016-07-20 16:14:18 --> Model Class Initialized
INFO - 2016-07-20 16:14:18 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-20 16:14:19 --> Config Class Initialized
INFO - 2016-07-20 16:14:19 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:14:19 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:19 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:19 --> URI Class Initialized
INFO - 2016-07-20 16:14:19 --> Router Class Initialized
INFO - 2016-07-20 16:14:19 --> Output Class Initialized
INFO - 2016-07-20 16:14:19 --> Security Class Initialized
DEBUG - 2016-07-20 16:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:19 --> Input Class Initialized
INFO - 2016-07-20 16:14:19 --> Language Class Initialized
INFO - 2016-07-20 16:14:19 --> Loader Class Initialized
INFO - 2016-07-20 16:14:19 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:19 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:14:19 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:19 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:19 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:19 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:19 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:19 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:19 --> Email Class Initialized
INFO - 2016-07-20 16:14:19 --> Controller Class Initialized
INFO - 2016-07-20 16:14:19 --> Model Class Initialized
INFO - 2016-07-20 16:14:19 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-07-20 16:14:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:19 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:19 --> Total execution time: 0.4087
INFO - 2016-07-20 16:14:20 --> Config Class Initialized
INFO - 2016-07-20 16:14:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:14:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:20 --> Config Class Initialized
INFO - 2016-07-20 16:14:20 --> Hooks Class Initialized
INFO - 2016-07-20 16:14:20 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:20 --> URI Class Initialized
DEBUG - 2016-07-20 16:14:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:14:20 --> Utf8 Class Initialized
INFO - 2016-07-20 16:14:20 --> Router Class Initialized
INFO - 2016-07-20 16:14:20 --> URI Class Initialized
INFO - 2016-07-20 16:14:20 --> Output Class Initialized
INFO - 2016-07-20 16:14:20 --> Security Class Initialized
INFO - 2016-07-20 16:14:20 --> Router Class Initialized
DEBUG - 2016-07-20 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:20 --> Output Class Initialized
INFO - 2016-07-20 16:14:20 --> Input Class Initialized
INFO - 2016-07-20 16:14:20 --> Security Class Initialized
INFO - 2016-07-20 16:14:20 --> Language Class Initialized
DEBUG - 2016-07-20 16:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:14:20 --> Input Class Initialized
INFO - 2016-07-20 16:14:20 --> Loader Class Initialized
INFO - 2016-07-20 16:14:20 --> Language Class Initialized
INFO - 2016-07-20 16:14:20 --> Helper loaded: url_helper
INFO - 2016-07-20 16:14:20 --> Helper loaded: utils_helper
ERROR - 2016-07-20 16:14:20 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:14:20 --> Helper loaded: html_helper
INFO - 2016-07-20 16:14:20 --> Helper loaded: form_helper
INFO - 2016-07-20 16:14:20 --> Helper loaded: file_helper
INFO - 2016-07-20 16:14:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:14:20 --> Database Driver Class Initialized
INFO - 2016-07-20 16:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:14:20 --> Form Validation Class Initialized
INFO - 2016-07-20 16:14:20 --> Email Class Initialized
INFO - 2016-07-20 16:14:20 --> Controller Class Initialized
INFO - 2016-07-20 16:14:20 --> Model Class Initialized
INFO - 2016-07-20 16:14:20 --> Model Class Initialized
DEBUG - 2016-07-20 16:14:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-07-20 16:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:14:20 --> Final output sent to browser
DEBUG - 2016-07-20 16:14:20 --> Total execution time: 0.4760
INFO - 2016-07-20 16:15:13 --> Config Class Initialized
INFO - 2016-07-20 16:15:13 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:15:13 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:15:13 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:13 --> URI Class Initialized
INFO - 2016-07-20 16:15:13 --> Router Class Initialized
INFO - 2016-07-20 16:15:13 --> Output Class Initialized
INFO - 2016-07-20 16:15:13 --> Security Class Initialized
DEBUG - 2016-07-20 16:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:13 --> Input Class Initialized
INFO - 2016-07-20 16:15:13 --> Language Class Initialized
INFO - 2016-07-20 16:15:13 --> Loader Class Initialized
INFO - 2016-07-20 16:15:13 --> Helper loaded: url_helper
INFO - 2016-07-20 16:15:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:15:13 --> Helper loaded: html_helper
INFO - 2016-07-20 16:15:13 --> Helper loaded: form_helper
INFO - 2016-07-20 16:15:13 --> Helper loaded: file_helper
INFO - 2016-07-20 16:15:13 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:15:13 --> Database Driver Class Initialized
INFO - 2016-07-20 16:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:15:13 --> Form Validation Class Initialized
INFO - 2016-07-20 16:15:13 --> Email Class Initialized
INFO - 2016-07-20 16:15:13 --> Controller Class Initialized
INFO - 2016-07-20 16:15:13 --> Model Class Initialized
INFO - 2016-07-20 16:15:13 --> Model Class Initialized
INFO - 2016-07-20 16:15:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:15:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:15:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-07-20 16:15:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:15:13 --> Final output sent to browser
DEBUG - 2016-07-20 16:15:13 --> Total execution time: 0.4013
INFO - 2016-07-20 16:15:14 --> Config Class Initialized
INFO - 2016-07-20 16:15:14 --> Hooks Class Initialized
INFO - 2016-07-20 16:15:14 --> Config Class Initialized
DEBUG - 2016-07-20 16:15:14 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:15:14 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:14 --> Hooks Class Initialized
INFO - 2016-07-20 16:15:14 --> URI Class Initialized
DEBUG - 2016-07-20 16:15:14 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:15:14 --> Router Class Initialized
INFO - 2016-07-20 16:15:14 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:14 --> Output Class Initialized
INFO - 2016-07-20 16:15:14 --> Security Class Initialized
INFO - 2016-07-20 16:15:14 --> URI Class Initialized
DEBUG - 2016-07-20 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:14 --> Router Class Initialized
INFO - 2016-07-20 16:15:14 --> Input Class Initialized
INFO - 2016-07-20 16:15:14 --> Output Class Initialized
INFO - 2016-07-20 16:15:14 --> Language Class Initialized
INFO - 2016-07-20 16:15:14 --> Security Class Initialized
DEBUG - 2016-07-20 16:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:14 --> Loader Class Initialized
INFO - 2016-07-20 16:15:14 --> Input Class Initialized
INFO - 2016-07-20 16:15:14 --> Helper loaded: url_helper
INFO - 2016-07-20 16:15:14 --> Language Class Initialized
INFO - 2016-07-20 16:15:14 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:15:14 --> Helper loaded: html_helper
ERROR - 2016-07-20 16:15:14 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:15:14 --> Helper loaded: form_helper
INFO - 2016-07-20 16:15:14 --> Helper loaded: file_helper
INFO - 2016-07-20 16:15:14 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:15:14 --> Database Driver Class Initialized
INFO - 2016-07-20 16:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:15:14 --> Form Validation Class Initialized
INFO - 2016-07-20 16:15:14 --> Email Class Initialized
INFO - 2016-07-20 16:15:14 --> Controller Class Initialized
INFO - 2016-07-20 16:15:14 --> Model Class Initialized
INFO - 2016-07-20 16:15:14 --> Model Class Initialized
INFO - 2016-07-20 16:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-07-20 16:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:15:14 --> Final output sent to browser
DEBUG - 2016-07-20 16:15:14 --> Total execution time: 0.4463
INFO - 2016-07-20 16:15:45 --> Config Class Initialized
INFO - 2016-07-20 16:15:45 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:15:45 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:15:45 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:45 --> URI Class Initialized
INFO - 2016-07-20 16:15:45 --> Router Class Initialized
INFO - 2016-07-20 16:15:45 --> Output Class Initialized
INFO - 2016-07-20 16:15:45 --> Security Class Initialized
DEBUG - 2016-07-20 16:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:45 --> Input Class Initialized
INFO - 2016-07-20 16:15:46 --> Language Class Initialized
INFO - 2016-07-20 16:15:46 --> Loader Class Initialized
INFO - 2016-07-20 16:15:46 --> Helper loaded: url_helper
INFO - 2016-07-20 16:15:46 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:15:46 --> Helper loaded: html_helper
INFO - 2016-07-20 16:15:46 --> Helper loaded: form_helper
INFO - 2016-07-20 16:15:46 --> Helper loaded: file_helper
INFO - 2016-07-20 16:15:46 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:15:46 --> Database Driver Class Initialized
INFO - 2016-07-20 16:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:15:46 --> Form Validation Class Initialized
INFO - 2016-07-20 16:15:46 --> Email Class Initialized
INFO - 2016-07-20 16:15:46 --> Controller Class Initialized
DEBUG - 2016-07-20 16:15:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:15:46 --> Model Class Initialized
INFO - 2016-07-20 16:15:46 --> Model Class Initialized
INFO - 2016-07-20 16:15:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:15:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:15:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:15:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:15:46 --> Final output sent to browser
DEBUG - 2016-07-20 16:15:46 --> Total execution time: 0.4170
INFO - 2016-07-20 16:15:47 --> Config Class Initialized
INFO - 2016-07-20 16:15:47 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:15:47 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:15:47 --> Config Class Initialized
INFO - 2016-07-20 16:15:47 --> Hooks Class Initialized
INFO - 2016-07-20 16:15:47 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:47 --> URI Class Initialized
INFO - 2016-07-20 16:15:47 --> Router Class Initialized
INFO - 2016-07-20 16:15:47 --> Output Class Initialized
INFO - 2016-07-20 16:15:47 --> Security Class Initialized
DEBUG - 2016-07-20 16:15:47 --> UTF-8 Support Enabled
DEBUG - 2016-07-20 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:47 --> Input Class Initialized
INFO - 2016-07-20 16:15:47 --> Utf8 Class Initialized
INFO - 2016-07-20 16:15:47 --> Language Class Initialized
INFO - 2016-07-20 16:15:47 --> URI Class Initialized
INFO - 2016-07-20 16:15:47 --> Loader Class Initialized
INFO - 2016-07-20 16:15:47 --> Helper loaded: url_helper
INFO - 2016-07-20 16:15:47 --> Router Class Initialized
INFO - 2016-07-20 16:15:47 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:15:47 --> Output Class Initialized
INFO - 2016-07-20 16:15:47 --> Helper loaded: html_helper
INFO - 2016-07-20 16:15:47 --> Security Class Initialized
DEBUG - 2016-07-20 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:15:47 --> Helper loaded: form_helper
INFO - 2016-07-20 16:15:47 --> Input Class Initialized
INFO - 2016-07-20 16:15:47 --> Helper loaded: file_helper
INFO - 2016-07-20 16:15:47 --> Language Class Initialized
INFO - 2016-07-20 16:15:47 --> Helper loaded: myemail_helper
ERROR - 2016-07-20 16:15:47 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-20 16:15:47 --> Database Driver Class Initialized
INFO - 2016-07-20 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:15:47 --> Form Validation Class Initialized
INFO - 2016-07-20 16:15:47 --> Email Class Initialized
INFO - 2016-07-20 16:15:47 --> Controller Class Initialized
DEBUG - 2016-07-20 16:15:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:15:47 --> Model Class Initialized
INFO - 2016-07-20 16:15:47 --> Model Class Initialized
INFO - 2016-07-20 16:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:15:47 --> Final output sent to browser
DEBUG - 2016-07-20 16:15:47 --> Total execution time: 0.4608
INFO - 2016-07-20 16:16:46 --> Config Class Initialized
INFO - 2016-07-20 16:16:46 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:16:46 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:16:46 --> Utf8 Class Initialized
INFO - 2016-07-20 16:16:46 --> URI Class Initialized
INFO - 2016-07-20 16:16:46 --> Router Class Initialized
INFO - 2016-07-20 16:16:46 --> Output Class Initialized
INFO - 2016-07-20 16:16:46 --> Security Class Initialized
DEBUG - 2016-07-20 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:16:46 --> Input Class Initialized
INFO - 2016-07-20 16:16:46 --> Language Class Initialized
INFO - 2016-07-20 16:16:46 --> Loader Class Initialized
INFO - 2016-07-20 16:16:46 --> Helper loaded: url_helper
INFO - 2016-07-20 16:16:46 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:16:46 --> Helper loaded: html_helper
INFO - 2016-07-20 16:16:46 --> Helper loaded: form_helper
INFO - 2016-07-20 16:16:46 --> Helper loaded: file_helper
INFO - 2016-07-20 16:16:46 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:16:46 --> Database Driver Class Initialized
INFO - 2016-07-20 16:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:16:46 --> Form Validation Class Initialized
INFO - 2016-07-20 16:16:46 --> Email Class Initialized
INFO - 2016-07-20 16:16:46 --> Controller Class Initialized
DEBUG - 2016-07-20 16:16:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:16:46 --> Model Class Initialized
INFO - 2016-07-20 16:16:46 --> Model Class Initialized
INFO - 2016-07-20 16:16:46 --> Model Class Initialized
INFO - 2016-07-20 16:16:46 --> Model Class Initialized
INFO - 2016-07-20 16:16:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:16:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:16:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:16:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:16:46 --> Final output sent to browser
DEBUG - 2016-07-20 16:16:46 --> Total execution time: 0.4378
INFO - 2016-07-20 16:16:59 --> Config Class Initialized
INFO - 2016-07-20 16:16:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:16:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:16:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:16:59 --> URI Class Initialized
INFO - 2016-07-20 16:16:59 --> Router Class Initialized
INFO - 2016-07-20 16:16:59 --> Output Class Initialized
INFO - 2016-07-20 16:16:59 --> Security Class Initialized
DEBUG - 2016-07-20 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:16:59 --> Input Class Initialized
INFO - 2016-07-20 16:16:59 --> Language Class Initialized
INFO - 2016-07-20 16:16:59 --> Loader Class Initialized
INFO - 2016-07-20 16:16:59 --> Helper loaded: url_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: html_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: form_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: file_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:16:59 --> Database Driver Class Initialized
INFO - 2016-07-20 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:16:59 --> Form Validation Class Initialized
INFO - 2016-07-20 16:16:59 --> Email Class Initialized
INFO - 2016-07-20 16:16:59 --> Controller Class Initialized
DEBUG - 2016-07-20 16:16:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:16:59 --> Model Class Initialized
INFO - 2016-07-20 16:16:59 --> Model Class Initialized
INFO - 2016-07-20 16:16:59 --> Model Class Initialized
INFO - 2016-07-20 16:16:59 --> Model Class Initialized
INFO - 2016-07-20 16:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:16:59 --> Config Class Initialized
INFO - 2016-07-20 16:16:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:16:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:16:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:16:59 --> URI Class Initialized
INFO - 2016-07-20 16:16:59 --> Router Class Initialized
INFO - 2016-07-20 16:16:59 --> Output Class Initialized
INFO - 2016-07-20 16:16:59 --> Security Class Initialized
DEBUG - 2016-07-20 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:16:59 --> Input Class Initialized
INFO - 2016-07-20 16:16:59 --> Language Class Initialized
INFO - 2016-07-20 16:16:59 --> Loader Class Initialized
INFO - 2016-07-20 16:16:59 --> Helper loaded: url_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: html_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: form_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: file_helper
INFO - 2016-07-20 16:16:59 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:17:00 --> Database Driver Class Initialized
INFO - 2016-07-20 16:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:17:00 --> Form Validation Class Initialized
INFO - 2016-07-20 16:17:00 --> Email Class Initialized
INFO - 2016-07-20 16:17:00 --> Controller Class Initialized
DEBUG - 2016-07-20 16:17:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:17:00 --> Model Class Initialized
INFO - 2016-07-20 16:17:00 --> Model Class Initialized
INFO - 2016-07-20 16:17:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:17:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:17:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:17:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:17:00 --> Final output sent to browser
DEBUG - 2016-07-20 16:17:00 --> Total execution time: 0.4122
INFO - 2016-07-20 16:19:16 --> Config Class Initialized
INFO - 2016-07-20 16:19:16 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:19:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:19:16 --> Utf8 Class Initialized
INFO - 2016-07-20 16:19:16 --> URI Class Initialized
INFO - 2016-07-20 16:19:16 --> Router Class Initialized
INFO - 2016-07-20 16:19:16 --> Output Class Initialized
INFO - 2016-07-20 16:19:16 --> Security Class Initialized
DEBUG - 2016-07-20 16:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:19:17 --> Input Class Initialized
INFO - 2016-07-20 16:19:17 --> Language Class Initialized
INFO - 2016-07-20 16:19:17 --> Loader Class Initialized
INFO - 2016-07-20 16:19:17 --> Helper loaded: url_helper
INFO - 2016-07-20 16:19:17 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:19:17 --> Helper loaded: html_helper
INFO - 2016-07-20 16:19:17 --> Helper loaded: form_helper
INFO - 2016-07-20 16:19:17 --> Helper loaded: file_helper
INFO - 2016-07-20 16:19:17 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:19:17 --> Database Driver Class Initialized
INFO - 2016-07-20 16:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:19:17 --> Form Validation Class Initialized
INFO - 2016-07-20 16:19:17 --> Email Class Initialized
INFO - 2016-07-20 16:19:17 --> Controller Class Initialized
DEBUG - 2016-07-20 16:19:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:19:17 --> Model Class Initialized
INFO - 2016-07-20 16:19:17 --> Model Class Initialized
INFO - 2016-07-20 16:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:19:17 --> Final output sent to browser
DEBUG - 2016-07-20 16:19:17 --> Total execution time: 0.4246
INFO - 2016-07-20 16:19:21 --> Config Class Initialized
INFO - 2016-07-20 16:19:21 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:19:21 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:19:21 --> Utf8 Class Initialized
INFO - 2016-07-20 16:19:21 --> URI Class Initialized
INFO - 2016-07-20 16:19:21 --> Router Class Initialized
INFO - 2016-07-20 16:19:21 --> Output Class Initialized
INFO - 2016-07-20 16:19:21 --> Security Class Initialized
DEBUG - 2016-07-20 16:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:19:21 --> Input Class Initialized
INFO - 2016-07-20 16:19:21 --> Language Class Initialized
INFO - 2016-07-20 16:19:21 --> Loader Class Initialized
INFO - 2016-07-20 16:19:22 --> Helper loaded: url_helper
INFO - 2016-07-20 16:19:22 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:19:22 --> Helper loaded: html_helper
INFO - 2016-07-20 16:19:22 --> Helper loaded: form_helper
INFO - 2016-07-20 16:19:22 --> Helper loaded: file_helper
INFO - 2016-07-20 16:19:22 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:19:22 --> Database Driver Class Initialized
INFO - 2016-07-20 16:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:19:22 --> Form Validation Class Initialized
INFO - 2016-07-20 16:19:22 --> Email Class Initialized
INFO - 2016-07-20 16:19:22 --> Controller Class Initialized
DEBUG - 2016-07-20 16:19:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:19:22 --> Model Class Initialized
INFO - 2016-07-20 16:19:22 --> Model Class Initialized
INFO - 2016-07-20 16:19:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:19:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:19:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:19:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:19:22 --> Final output sent to browser
DEBUG - 2016-07-20 16:19:22 --> Total execution time: 0.4206
INFO - 2016-07-20 16:19:24 --> Config Class Initialized
INFO - 2016-07-20 16:19:24 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:19:24 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:19:24 --> Utf8 Class Initialized
INFO - 2016-07-20 16:19:24 --> URI Class Initialized
INFO - 2016-07-20 16:19:24 --> Router Class Initialized
INFO - 2016-07-20 16:19:24 --> Output Class Initialized
INFO - 2016-07-20 16:19:24 --> Security Class Initialized
DEBUG - 2016-07-20 16:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:19:24 --> Input Class Initialized
INFO - 2016-07-20 16:19:24 --> Language Class Initialized
INFO - 2016-07-20 16:19:24 --> Loader Class Initialized
INFO - 2016-07-20 16:19:24 --> Helper loaded: url_helper
INFO - 2016-07-20 16:19:24 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:19:24 --> Helper loaded: html_helper
INFO - 2016-07-20 16:19:24 --> Helper loaded: form_helper
INFO - 2016-07-20 16:19:24 --> Helper loaded: file_helper
INFO - 2016-07-20 16:19:24 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:19:24 --> Database Driver Class Initialized
INFO - 2016-07-20 16:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:19:24 --> Form Validation Class Initialized
INFO - 2016-07-20 16:19:24 --> Email Class Initialized
INFO - 2016-07-20 16:19:24 --> Controller Class Initialized
DEBUG - 2016-07-20 16:19:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:19:24 --> Model Class Initialized
INFO - 2016-07-20 16:19:24 --> Model Class Initialized
INFO - 2016-07-20 16:19:24 --> Model Class Initialized
INFO - 2016-07-20 16:19:24 --> Model Class Initialized
INFO - 2016-07-20 16:19:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:19:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:19:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:19:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:19:24 --> Final output sent to browser
DEBUG - 2016-07-20 16:19:24 --> Total execution time: 0.4463
INFO - 2016-07-20 16:19:27 --> Config Class Initialized
INFO - 2016-07-20 16:19:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:19:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:19:27 --> Utf8 Class Initialized
INFO - 2016-07-20 16:19:27 --> URI Class Initialized
INFO - 2016-07-20 16:19:27 --> Router Class Initialized
INFO - 2016-07-20 16:19:27 --> Output Class Initialized
INFO - 2016-07-20 16:19:27 --> Security Class Initialized
DEBUG - 2016-07-20 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:19:27 --> Input Class Initialized
INFO - 2016-07-20 16:19:27 --> Language Class Initialized
INFO - 2016-07-20 16:19:27 --> Loader Class Initialized
INFO - 2016-07-20 16:19:27 --> Helper loaded: url_helper
INFO - 2016-07-20 16:19:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:19:27 --> Helper loaded: html_helper
INFO - 2016-07-20 16:19:27 --> Helper loaded: form_helper
INFO - 2016-07-20 16:19:27 --> Helper loaded: file_helper
INFO - 2016-07-20 16:19:27 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:19:27 --> Database Driver Class Initialized
INFO - 2016-07-20 16:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:19:27 --> Form Validation Class Initialized
INFO - 2016-07-20 16:19:27 --> Email Class Initialized
INFO - 2016-07-20 16:19:27 --> Controller Class Initialized
DEBUG - 2016-07-20 16:19:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:19:27 --> Model Class Initialized
INFO - 2016-07-20 16:19:27 --> Model Class Initialized
INFO - 2016-07-20 16:19:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:19:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:19:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:19:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:19:27 --> Final output sent to browser
DEBUG - 2016-07-20 16:19:27 --> Total execution time: 0.4205
INFO - 2016-07-20 16:19:32 --> Config Class Initialized
INFO - 2016-07-20 16:19:32 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:19:32 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:19:32 --> Utf8 Class Initialized
INFO - 2016-07-20 16:19:32 --> URI Class Initialized
INFO - 2016-07-20 16:19:32 --> Router Class Initialized
INFO - 2016-07-20 16:19:32 --> Output Class Initialized
INFO - 2016-07-20 16:19:32 --> Security Class Initialized
DEBUG - 2016-07-20 16:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:19:32 --> Input Class Initialized
INFO - 2016-07-20 16:19:32 --> Language Class Initialized
INFO - 2016-07-20 16:19:32 --> Loader Class Initialized
INFO - 2016-07-20 16:19:32 --> Helper loaded: url_helper
INFO - 2016-07-20 16:19:32 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:19:32 --> Helper loaded: html_helper
INFO - 2016-07-20 16:19:32 --> Helper loaded: form_helper
INFO - 2016-07-20 16:19:32 --> Helper loaded: file_helper
INFO - 2016-07-20 16:19:32 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:19:32 --> Database Driver Class Initialized
INFO - 2016-07-20 16:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:19:32 --> Form Validation Class Initialized
INFO - 2016-07-20 16:19:32 --> Email Class Initialized
INFO - 2016-07-20 16:19:32 --> Controller Class Initialized
DEBUG - 2016-07-20 16:19:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:19:32 --> Model Class Initialized
INFO - 2016-07-20 16:19:32 --> Model Class Initialized
INFO - 2016-07-20 16:19:32 --> Model Class Initialized
INFO - 2016-07-20 16:19:32 --> Model Class Initialized
INFO - 2016-07-20 16:19:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:19:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:19:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:19:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:19:32 --> Final output sent to browser
DEBUG - 2016-07-20 16:19:32 --> Total execution time: 0.4465
INFO - 2016-07-20 16:44:37 --> Config Class Initialized
INFO - 2016-07-20 16:44:37 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:44:37 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:44:37 --> Utf8 Class Initialized
INFO - 2016-07-20 16:44:37 --> URI Class Initialized
INFO - 2016-07-20 16:44:37 --> Router Class Initialized
INFO - 2016-07-20 16:44:37 --> Output Class Initialized
INFO - 2016-07-20 16:44:37 --> Security Class Initialized
DEBUG - 2016-07-20 16:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:44:37 --> Input Class Initialized
INFO - 2016-07-20 16:44:37 --> Language Class Initialized
INFO - 2016-07-20 16:44:37 --> Loader Class Initialized
INFO - 2016-07-20 16:44:37 --> Helper loaded: url_helper
INFO - 2016-07-20 16:44:37 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:44:37 --> Helper loaded: html_helper
INFO - 2016-07-20 16:44:37 --> Helper loaded: form_helper
INFO - 2016-07-20 16:44:37 --> Helper loaded: file_helper
INFO - 2016-07-20 16:44:37 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:44:37 --> Database Driver Class Initialized
INFO - 2016-07-20 16:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:44:37 --> Form Validation Class Initialized
INFO - 2016-07-20 16:44:37 --> Email Class Initialized
INFO - 2016-07-20 16:44:37 --> Controller Class Initialized
DEBUG - 2016-07-20 16:44:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:44:38 --> Config Class Initialized
INFO - 2016-07-20 16:44:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:44:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:44:38 --> Utf8 Class Initialized
INFO - 2016-07-20 16:44:38 --> URI Class Initialized
INFO - 2016-07-20 16:44:38 --> Router Class Initialized
INFO - 2016-07-20 16:44:38 --> Output Class Initialized
INFO - 2016-07-20 16:44:38 --> Security Class Initialized
DEBUG - 2016-07-20 16:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:44:38 --> Input Class Initialized
INFO - 2016-07-20 16:44:38 --> Language Class Initialized
INFO - 2016-07-20 16:44:38 --> Loader Class Initialized
INFO - 2016-07-20 16:44:38 --> Helper loaded: url_helper
INFO - 2016-07-20 16:44:38 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:44:38 --> Helper loaded: html_helper
INFO - 2016-07-20 16:44:38 --> Helper loaded: form_helper
INFO - 2016-07-20 16:44:38 --> Helper loaded: file_helper
INFO - 2016-07-20 16:44:38 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:44:38 --> Database Driver Class Initialized
INFO - 2016-07-20 16:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:44:38 --> Form Validation Class Initialized
INFO - 2016-07-20 16:44:38 --> Email Class Initialized
INFO - 2016-07-20 16:44:38 --> Controller Class Initialized
DEBUG - 2016-07-20 16:44:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> Model Class Initialized
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:44:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:44:38 --> Final output sent to browser
DEBUG - 2016-07-20 16:44:38 --> Total execution time: 0.4215
INFO - 2016-07-20 16:46:32 --> Config Class Initialized
INFO - 2016-07-20 16:46:32 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:46:32 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:46:32 --> Utf8 Class Initialized
INFO - 2016-07-20 16:46:32 --> URI Class Initialized
INFO - 2016-07-20 16:46:32 --> Router Class Initialized
INFO - 2016-07-20 16:46:32 --> Output Class Initialized
INFO - 2016-07-20 16:46:32 --> Security Class Initialized
DEBUG - 2016-07-20 16:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:46:32 --> Input Class Initialized
INFO - 2016-07-20 16:46:32 --> Language Class Initialized
INFO - 2016-07-20 16:46:32 --> Loader Class Initialized
INFO - 2016-07-20 16:46:32 --> Helper loaded: url_helper
INFO - 2016-07-20 16:46:32 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:46:32 --> Helper loaded: html_helper
INFO - 2016-07-20 16:46:32 --> Helper loaded: form_helper
INFO - 2016-07-20 16:46:32 --> Helper loaded: file_helper
INFO - 2016-07-20 16:46:32 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:46:32 --> Database Driver Class Initialized
INFO - 2016-07-20 16:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:46:32 --> Form Validation Class Initialized
INFO - 2016-07-20 16:46:32 --> Email Class Initialized
INFO - 2016-07-20 16:46:32 --> Controller Class Initialized
DEBUG - 2016-07-20 16:46:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:46:32 --> Model Class Initialized
INFO - 2016-07-20 16:46:32 --> Model Class Initialized
INFO - 2016-07-20 16:46:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:46:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:46:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:46:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:46:32 --> Final output sent to browser
DEBUG - 2016-07-20 16:46:32 --> Total execution time: 0.4385
INFO - 2016-07-20 16:46:48 --> Config Class Initialized
INFO - 2016-07-20 16:46:48 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:46:48 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:46:48 --> Utf8 Class Initialized
INFO - 2016-07-20 16:46:48 --> URI Class Initialized
INFO - 2016-07-20 16:46:48 --> Router Class Initialized
INFO - 2016-07-20 16:46:48 --> Output Class Initialized
INFO - 2016-07-20 16:46:48 --> Security Class Initialized
DEBUG - 2016-07-20 16:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:46:48 --> Input Class Initialized
INFO - 2016-07-20 16:46:49 --> Language Class Initialized
INFO - 2016-07-20 16:46:49 --> Loader Class Initialized
INFO - 2016-07-20 16:46:49 --> Helper loaded: url_helper
INFO - 2016-07-20 16:46:49 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:46:49 --> Helper loaded: html_helper
INFO - 2016-07-20 16:46:49 --> Helper loaded: form_helper
INFO - 2016-07-20 16:46:49 --> Helper loaded: file_helper
INFO - 2016-07-20 16:46:49 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:46:49 --> Database Driver Class Initialized
INFO - 2016-07-20 16:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:46:49 --> Form Validation Class Initialized
INFO - 2016-07-20 16:46:49 --> Email Class Initialized
INFO - 2016-07-20 16:46:49 --> Controller Class Initialized
DEBUG - 2016-07-20 16:46:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:46:49 --> Model Class Initialized
INFO - 2016-07-20 16:46:49 --> Model Class Initialized
INFO - 2016-07-20 16:46:49 --> Model Class Initialized
INFO - 2016-07-20 16:46:49 --> Model Class Initialized
INFO - 2016-07-20 16:46:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:46:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:46:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:46:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:46:49 --> Final output sent to browser
DEBUG - 2016-07-20 16:46:49 --> Total execution time: 0.4527
INFO - 2016-07-20 16:47:00 --> Config Class Initialized
INFO - 2016-07-20 16:47:00 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:00 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:00 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:00 --> URI Class Initialized
INFO - 2016-07-20 16:47:00 --> Router Class Initialized
INFO - 2016-07-20 16:47:00 --> Output Class Initialized
INFO - 2016-07-20 16:47:00 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:00 --> Input Class Initialized
INFO - 2016-07-20 16:47:00 --> Language Class Initialized
INFO - 2016-07-20 16:47:00 --> Loader Class Initialized
INFO - 2016-07-20 16:47:00 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:00 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:00 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:00 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:00 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:00 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:00 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:00 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:00 --> Email Class Initialized
INFO - 2016-07-20 16:47:00 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:00 --> Model Class Initialized
INFO - 2016-07-20 16:47:00 --> Model Class Initialized
INFO - 2016-07-20 16:47:00 --> Model Class Initialized
INFO - 2016-07-20 16:47:00 --> Model Class Initialized
INFO - 2016-07-20 16:47:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:47:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:00 --> Config Class Initialized
INFO - 2016-07-20 16:47:00 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:00 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:00 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:00 --> URI Class Initialized
INFO - 2016-07-20 16:47:00 --> Router Class Initialized
INFO - 2016-07-20 16:47:00 --> Output Class Initialized
INFO - 2016-07-20 16:47:01 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:01 --> Input Class Initialized
INFO - 2016-07-20 16:47:01 --> Language Class Initialized
INFO - 2016-07-20 16:47:01 --> Loader Class Initialized
INFO - 2016-07-20 16:47:01 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:01 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:01 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:01 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:01 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:01 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:01 --> Email Class Initialized
INFO - 2016-07-20 16:47:01 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:01 --> Model Class Initialized
INFO - 2016-07-20 16:47:01 --> Model Class Initialized
INFO - 2016-07-20 16:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:47:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:01 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:01 --> Total execution time: 0.4209
INFO - 2016-07-20 16:47:22 --> Config Class Initialized
INFO - 2016-07-20 16:47:22 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:22 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:22 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:22 --> URI Class Initialized
INFO - 2016-07-20 16:47:22 --> Router Class Initialized
INFO - 2016-07-20 16:47:22 --> Output Class Initialized
INFO - 2016-07-20 16:47:22 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:22 --> Input Class Initialized
INFO - 2016-07-20 16:47:22 --> Language Class Initialized
INFO - 2016-07-20 16:47:22 --> Loader Class Initialized
INFO - 2016-07-20 16:47:22 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:22 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:22 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:22 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:22 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:22 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:22 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:22 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:22 --> Email Class Initialized
INFO - 2016-07-20 16:47:22 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:22 --> Model Class Initialized
INFO - 2016-07-20 16:47:22 --> Model Class Initialized
INFO - 2016-07-20 16:47:22 --> Model Class Initialized
INFO - 2016-07-20 16:47:22 --> Model Class Initialized
INFO - 2016-07-20 16:47:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:23 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:23 --> Total execution time: 0.4628
INFO - 2016-07-20 16:47:42 --> Config Class Initialized
INFO - 2016-07-20 16:47:42 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:42 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:42 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:42 --> URI Class Initialized
INFO - 2016-07-20 16:47:42 --> Router Class Initialized
INFO - 2016-07-20 16:47:42 --> Output Class Initialized
INFO - 2016-07-20 16:47:42 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:42 --> Input Class Initialized
INFO - 2016-07-20 16:47:42 --> Language Class Initialized
INFO - 2016-07-20 16:47:42 --> Loader Class Initialized
INFO - 2016-07-20 16:47:42 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:42 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:42 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:42 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:42 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:42 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:42 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:42 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:42 --> Email Class Initialized
INFO - 2016-07-20 16:47:42 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:42 --> Model Class Initialized
INFO - 2016-07-20 16:47:42 --> Model Class Initialized
INFO - 2016-07-20 16:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:42 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:42 --> Total execution time: 0.4398
INFO - 2016-07-20 16:47:50 --> Config Class Initialized
INFO - 2016-07-20 16:47:50 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:50 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:50 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:50 --> URI Class Initialized
INFO - 2016-07-20 16:47:51 --> Router Class Initialized
INFO - 2016-07-20 16:47:51 --> Output Class Initialized
INFO - 2016-07-20 16:47:51 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:51 --> Input Class Initialized
INFO - 2016-07-20 16:47:51 --> Language Class Initialized
INFO - 2016-07-20 16:47:51 --> Loader Class Initialized
INFO - 2016-07-20 16:47:51 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:51 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:51 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:51 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:51 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:51 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:51 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:51 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:51 --> Email Class Initialized
INFO - 2016-07-20 16:47:51 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:51 --> Model Class Initialized
INFO - 2016-07-20 16:47:51 --> Model Class Initialized
INFO - 2016-07-20 16:47:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-20 16:47:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:51 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:51 --> Total execution time: 0.4331
INFO - 2016-07-20 16:47:55 --> Config Class Initialized
INFO - 2016-07-20 16:47:55 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:55 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:55 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:55 --> URI Class Initialized
INFO - 2016-07-20 16:47:55 --> Router Class Initialized
INFO - 2016-07-20 16:47:55 --> Output Class Initialized
INFO - 2016-07-20 16:47:55 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:55 --> Input Class Initialized
INFO - 2016-07-20 16:47:55 --> Language Class Initialized
INFO - 2016-07-20 16:47:56 --> Loader Class Initialized
INFO - 2016-07-20 16:47:56 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:56 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:56 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:56 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:56 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:56 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:56 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:56 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:56 --> Email Class Initialized
INFO - 2016-07-20 16:47:56 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:56 --> Model Class Initialized
INFO - 2016-07-20 16:47:56 --> Model Class Initialized
INFO - 2016-07-20 16:47:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-20 16:47:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:56 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:56 --> Total execution time: 0.4290
INFO - 2016-07-20 16:47:58 --> Config Class Initialized
INFO - 2016-07-20 16:47:58 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:47:58 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:47:58 --> Utf8 Class Initialized
INFO - 2016-07-20 16:47:58 --> URI Class Initialized
INFO - 2016-07-20 16:47:58 --> Router Class Initialized
INFO - 2016-07-20 16:47:58 --> Output Class Initialized
INFO - 2016-07-20 16:47:58 --> Security Class Initialized
DEBUG - 2016-07-20 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:47:58 --> Input Class Initialized
INFO - 2016-07-20 16:47:58 --> Language Class Initialized
INFO - 2016-07-20 16:47:58 --> Loader Class Initialized
INFO - 2016-07-20 16:47:58 --> Helper loaded: url_helper
INFO - 2016-07-20 16:47:58 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:47:58 --> Helper loaded: html_helper
INFO - 2016-07-20 16:47:58 --> Helper loaded: form_helper
INFO - 2016-07-20 16:47:58 --> Helper loaded: file_helper
INFO - 2016-07-20 16:47:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:47:58 --> Database Driver Class Initialized
INFO - 2016-07-20 16:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:47:58 --> Form Validation Class Initialized
INFO - 2016-07-20 16:47:58 --> Email Class Initialized
INFO - 2016-07-20 16:47:58 --> Controller Class Initialized
DEBUG - 2016-07-20 16:47:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:47:58 --> Model Class Initialized
INFO - 2016-07-20 16:47:58 --> Model Class Initialized
INFO - 2016-07-20 16:47:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:47:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:47:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:47:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:47:58 --> Final output sent to browser
DEBUG - 2016-07-20 16:47:58 --> Total execution time: 0.4562
INFO - 2016-07-20 16:48:41 --> Config Class Initialized
INFO - 2016-07-20 16:48:41 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:48:41 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:48:41 --> Utf8 Class Initialized
INFO - 2016-07-20 16:48:41 --> URI Class Initialized
INFO - 2016-07-20 16:48:41 --> Router Class Initialized
INFO - 2016-07-20 16:48:41 --> Output Class Initialized
INFO - 2016-07-20 16:48:41 --> Security Class Initialized
DEBUG - 2016-07-20 16:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:48:41 --> Input Class Initialized
INFO - 2016-07-20 16:48:41 --> Language Class Initialized
INFO - 2016-07-20 16:48:41 --> Loader Class Initialized
INFO - 2016-07-20 16:48:41 --> Helper loaded: url_helper
INFO - 2016-07-20 16:48:41 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:48:41 --> Helper loaded: html_helper
INFO - 2016-07-20 16:48:41 --> Helper loaded: form_helper
INFO - 2016-07-20 16:48:41 --> Helper loaded: file_helper
INFO - 2016-07-20 16:48:41 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:48:41 --> Database Driver Class Initialized
INFO - 2016-07-20 16:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:48:41 --> Form Validation Class Initialized
INFO - 2016-07-20 16:48:41 --> Email Class Initialized
INFO - 2016-07-20 16:48:41 --> Controller Class Initialized
DEBUG - 2016-07-20 16:48:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:48:41 --> Model Class Initialized
INFO - 2016-07-20 16:48:41 --> Model Class Initialized
INFO - 2016-07-20 16:48:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:48:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:48:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:48:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:48:41 --> Final output sent to browser
DEBUG - 2016-07-20 16:48:41 --> Total execution time: 0.4496
INFO - 2016-07-20 16:55:02 --> Config Class Initialized
INFO - 2016-07-20 16:55:02 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:02 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:02 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:02 --> URI Class Initialized
INFO - 2016-07-20 16:55:02 --> Router Class Initialized
INFO - 2016-07-20 16:55:02 --> Output Class Initialized
INFO - 2016-07-20 16:55:02 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:02 --> Input Class Initialized
INFO - 2016-07-20 16:55:02 --> Language Class Initialized
INFO - 2016-07-20 16:55:02 --> Loader Class Initialized
INFO - 2016-07-20 16:55:02 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:02 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:02 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:02 --> Email Class Initialized
INFO - 2016-07-20 16:55:02 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:02 --> Model Class Initialized
INFO - 2016-07-20 16:55:02 --> Model Class Initialized
INFO - 2016-07-20 16:55:02 --> Config Class Initialized
INFO - 2016-07-20 16:55:02 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:02 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:02 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:02 --> URI Class Initialized
INFO - 2016-07-20 16:55:02 --> Router Class Initialized
INFO - 2016-07-20 16:55:02 --> Output Class Initialized
INFO - 2016-07-20 16:55:02 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:02 --> Input Class Initialized
INFO - 2016-07-20 16:55:02 --> Language Class Initialized
INFO - 2016-07-20 16:55:02 --> Loader Class Initialized
INFO - 2016-07-20 16:55:02 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:02 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:02 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:02 --> Email Class Initialized
INFO - 2016-07-20 16:55:02 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:02 --> Model Class Initialized
INFO - 2016-07-20 16:55:02 --> Model Class Initialized
INFO - 2016-07-20 16:55:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:55:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:03 --> Final output sent to browser
DEBUG - 2016-07-20 16:55:03 --> Total execution time: 0.4499
INFO - 2016-07-20 16:55:10 --> Config Class Initialized
INFO - 2016-07-20 16:55:10 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:10 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:10 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:10 --> URI Class Initialized
INFO - 2016-07-20 16:55:10 --> Router Class Initialized
INFO - 2016-07-20 16:55:10 --> Output Class Initialized
INFO - 2016-07-20 16:55:10 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:10 --> Input Class Initialized
INFO - 2016-07-20 16:55:10 --> Language Class Initialized
INFO - 2016-07-20 16:55:10 --> Loader Class Initialized
INFO - 2016-07-20 16:55:10 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:10 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:10 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:10 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:10 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:10 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:10 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:10 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:10 --> Email Class Initialized
INFO - 2016-07-20 16:55:10 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:10 --> Model Class Initialized
INFO - 2016-07-20 16:55:10 --> Model Class Initialized
INFO - 2016-07-20 16:55:10 --> Model Class Initialized
INFO - 2016-07-20 16:55:10 --> Model Class Initialized
INFO - 2016-07-20 16:55:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:55:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:10 --> Final output sent to browser
DEBUG - 2016-07-20 16:55:10 --> Total execution time: 0.4747
INFO - 2016-07-20 16:55:22 --> Config Class Initialized
INFO - 2016-07-20 16:55:22 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:22 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:22 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:22 --> URI Class Initialized
INFO - 2016-07-20 16:55:22 --> Router Class Initialized
INFO - 2016-07-20 16:55:22 --> Output Class Initialized
INFO - 2016-07-20 16:55:22 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:22 --> Input Class Initialized
INFO - 2016-07-20 16:55:22 --> Language Class Initialized
INFO - 2016-07-20 16:55:22 --> Loader Class Initialized
INFO - 2016-07-20 16:55:22 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:22 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:22 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:22 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:22 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:22 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:22 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:22 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:22 --> Email Class Initialized
INFO - 2016-07-20 16:55:22 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:22 --> Model Class Initialized
INFO - 2016-07-20 16:55:22 --> Model Class Initialized
INFO - 2016-07-20 16:55:22 --> Model Class Initialized
INFO - 2016-07-20 16:55:22 --> Model Class Initialized
INFO - 2016-07-20 16:55:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:55:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:31 --> Config Class Initialized
INFO - 2016-07-20 16:55:31 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:31 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:31 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:31 --> URI Class Initialized
INFO - 2016-07-20 16:55:31 --> Router Class Initialized
INFO - 2016-07-20 16:55:31 --> Output Class Initialized
INFO - 2016-07-20 16:55:31 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:31 --> Input Class Initialized
INFO - 2016-07-20 16:55:31 --> Language Class Initialized
INFO - 2016-07-20 16:55:31 --> Loader Class Initialized
INFO - 2016-07-20 16:55:31 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:31 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:31 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:31 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:31 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:31 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:31 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:31 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:31 --> Email Class Initialized
INFO - 2016-07-20 16:55:31 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:31 --> Model Class Initialized
INFO - 2016-07-20 16:55:31 --> Model Class Initialized
INFO - 2016-07-20 16:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:31 --> Final output sent to browser
DEBUG - 2016-07-20 16:55:31 --> Total execution time: 0.4327
INFO - 2016-07-20 16:55:56 --> Config Class Initialized
INFO - 2016-07-20 16:55:56 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:56 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:56 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:56 --> URI Class Initialized
INFO - 2016-07-20 16:55:56 --> Router Class Initialized
INFO - 2016-07-20 16:55:56 --> Output Class Initialized
INFO - 2016-07-20 16:55:56 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:56 --> Input Class Initialized
INFO - 2016-07-20 16:55:56 --> Language Class Initialized
INFO - 2016-07-20 16:55:56 --> Loader Class Initialized
INFO - 2016-07-20 16:55:56 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:56 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:56 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:56 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:56 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:56 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:56 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:56 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:56 --> Email Class Initialized
INFO - 2016-07-20 16:55:56 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:56 --> Model Class Initialized
INFO - 2016-07-20 16:55:56 --> Model Class Initialized
INFO - 2016-07-20 16:55:56 --> Model Class Initialized
INFO - 2016-07-20 16:55:56 --> Model Class Initialized
INFO - 2016-07-20 16:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:56 --> Final output sent to browser
DEBUG - 2016-07-20 16:55:56 --> Total execution time: 0.4724
INFO - 2016-07-20 16:55:59 --> Config Class Initialized
INFO - 2016-07-20 16:55:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:55:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:55:59 --> Utf8 Class Initialized
INFO - 2016-07-20 16:55:59 --> URI Class Initialized
INFO - 2016-07-20 16:55:59 --> Router Class Initialized
INFO - 2016-07-20 16:55:59 --> Output Class Initialized
INFO - 2016-07-20 16:55:59 --> Security Class Initialized
DEBUG - 2016-07-20 16:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:55:59 --> Input Class Initialized
INFO - 2016-07-20 16:55:59 --> Language Class Initialized
INFO - 2016-07-20 16:55:59 --> Loader Class Initialized
INFO - 2016-07-20 16:55:59 --> Helper loaded: url_helper
INFO - 2016-07-20 16:55:59 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:55:59 --> Helper loaded: html_helper
INFO - 2016-07-20 16:55:59 --> Helper loaded: form_helper
INFO - 2016-07-20 16:55:59 --> Helper loaded: file_helper
INFO - 2016-07-20 16:55:59 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:55:59 --> Database Driver Class Initialized
INFO - 2016-07-20 16:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:55:59 --> Form Validation Class Initialized
INFO - 2016-07-20 16:55:59 --> Email Class Initialized
INFO - 2016-07-20 16:55:59 --> Controller Class Initialized
DEBUG - 2016-07-20 16:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:55:59 --> Model Class Initialized
INFO - 2016-07-20 16:55:59 --> Model Class Initialized
INFO - 2016-07-20 16:55:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:55:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:55:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:55:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:55:59 --> Final output sent to browser
DEBUG - 2016-07-20 16:55:59 --> Total execution time: 0.4403
INFO - 2016-07-20 16:56:38 --> Config Class Initialized
INFO - 2016-07-20 16:56:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:56:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:56:38 --> Utf8 Class Initialized
INFO - 2016-07-20 16:56:38 --> URI Class Initialized
INFO - 2016-07-20 16:56:38 --> Router Class Initialized
INFO - 2016-07-20 16:56:38 --> Output Class Initialized
INFO - 2016-07-20 16:56:38 --> Security Class Initialized
DEBUG - 2016-07-20 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:56:39 --> Input Class Initialized
INFO - 2016-07-20 16:56:39 --> Language Class Initialized
INFO - 2016-07-20 16:56:39 --> Loader Class Initialized
INFO - 2016-07-20 16:56:39 --> Helper loaded: url_helper
INFO - 2016-07-20 16:56:39 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:56:39 --> Helper loaded: html_helper
INFO - 2016-07-20 16:56:39 --> Helper loaded: form_helper
INFO - 2016-07-20 16:56:39 --> Helper loaded: file_helper
INFO - 2016-07-20 16:56:39 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:56:39 --> Database Driver Class Initialized
INFO - 2016-07-20 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:56:39 --> Form Validation Class Initialized
INFO - 2016-07-20 16:56:39 --> Email Class Initialized
INFO - 2016-07-20 16:56:39 --> Controller Class Initialized
DEBUG - 2016-07-20 16:56:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:56:39 --> Model Class Initialized
INFO - 2016-07-20 16:56:39 --> Model Class Initialized
INFO - 2016-07-20 16:56:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:56:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:56:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:56:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:56:39 --> Final output sent to browser
DEBUG - 2016-07-20 16:56:39 --> Total execution time: 0.4597
INFO - 2016-07-20 16:56:55 --> Config Class Initialized
INFO - 2016-07-20 16:56:55 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:56:55 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:56:55 --> Utf8 Class Initialized
INFO - 2016-07-20 16:56:55 --> URI Class Initialized
INFO - 2016-07-20 16:56:55 --> Router Class Initialized
INFO - 2016-07-20 16:56:55 --> Output Class Initialized
INFO - 2016-07-20 16:56:55 --> Security Class Initialized
DEBUG - 2016-07-20 16:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:56:55 --> Input Class Initialized
INFO - 2016-07-20 16:56:55 --> Language Class Initialized
INFO - 2016-07-20 16:56:55 --> Loader Class Initialized
INFO - 2016-07-20 16:56:55 --> Helper loaded: url_helper
INFO - 2016-07-20 16:56:55 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:56:55 --> Helper loaded: html_helper
INFO - 2016-07-20 16:56:55 --> Helper loaded: form_helper
INFO - 2016-07-20 16:56:55 --> Helper loaded: file_helper
INFO - 2016-07-20 16:56:55 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:56:55 --> Database Driver Class Initialized
INFO - 2016-07-20 16:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:56:55 --> Form Validation Class Initialized
INFO - 2016-07-20 16:56:55 --> Email Class Initialized
INFO - 2016-07-20 16:56:55 --> Controller Class Initialized
DEBUG - 2016-07-20 16:56:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:56:55 --> Model Class Initialized
INFO - 2016-07-20 16:56:55 --> Model Class Initialized
INFO - 2016-07-20 16:56:55 --> Model Class Initialized
INFO - 2016-07-20 16:56:55 --> Model Class Initialized
INFO - 2016-07-20 16:56:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:56:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:56:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:56:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:56:55 --> Final output sent to browser
DEBUG - 2016-07-20 16:56:55 --> Total execution time: 0.4694
INFO - 2016-07-20 16:57:40 --> Config Class Initialized
INFO - 2016-07-20 16:57:40 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:57:40 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:57:40 --> Utf8 Class Initialized
INFO - 2016-07-20 16:57:40 --> URI Class Initialized
INFO - 2016-07-20 16:57:40 --> Router Class Initialized
INFO - 2016-07-20 16:57:40 --> Output Class Initialized
INFO - 2016-07-20 16:57:40 --> Security Class Initialized
DEBUG - 2016-07-20 16:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:57:40 --> Input Class Initialized
INFO - 2016-07-20 16:57:40 --> Language Class Initialized
INFO - 2016-07-20 16:57:40 --> Loader Class Initialized
INFO - 2016-07-20 16:57:40 --> Helper loaded: url_helper
INFO - 2016-07-20 16:57:40 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:57:40 --> Helper loaded: html_helper
INFO - 2016-07-20 16:57:40 --> Helper loaded: form_helper
INFO - 2016-07-20 16:57:40 --> Helper loaded: file_helper
INFO - 2016-07-20 16:57:40 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:57:40 --> Database Driver Class Initialized
INFO - 2016-07-20 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:57:40 --> Form Validation Class Initialized
INFO - 2016-07-20 16:57:40 --> Email Class Initialized
INFO - 2016-07-20 16:57:40 --> Controller Class Initialized
DEBUG - 2016-07-20 16:57:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:57:40 --> Model Class Initialized
INFO - 2016-07-20 16:57:40 --> Model Class Initialized
INFO - 2016-07-20 16:57:40 --> Model Class Initialized
INFO - 2016-07-20 16:57:40 --> Model Class Initialized
INFO - 2016-07-20 16:57:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:57:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:57:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:57:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:57:48 --> Config Class Initialized
INFO - 2016-07-20 16:57:48 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:57:48 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:57:48 --> Utf8 Class Initialized
INFO - 2016-07-20 16:57:48 --> URI Class Initialized
INFO - 2016-07-20 16:57:48 --> Router Class Initialized
INFO - 2016-07-20 16:57:48 --> Output Class Initialized
INFO - 2016-07-20 16:57:48 --> Security Class Initialized
DEBUG - 2016-07-20 16:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:57:49 --> Input Class Initialized
INFO - 2016-07-20 16:57:49 --> Language Class Initialized
INFO - 2016-07-20 16:57:49 --> Loader Class Initialized
INFO - 2016-07-20 16:57:49 --> Helper loaded: url_helper
INFO - 2016-07-20 16:57:49 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:57:49 --> Helper loaded: html_helper
INFO - 2016-07-20 16:57:49 --> Helper loaded: form_helper
INFO - 2016-07-20 16:57:49 --> Helper loaded: file_helper
INFO - 2016-07-20 16:57:49 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:57:49 --> Database Driver Class Initialized
INFO - 2016-07-20 16:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:57:49 --> Form Validation Class Initialized
INFO - 2016-07-20 16:57:49 --> Email Class Initialized
INFO - 2016-07-20 16:57:49 --> Controller Class Initialized
DEBUG - 2016-07-20 16:57:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:57:49 --> Model Class Initialized
INFO - 2016-07-20 16:57:49 --> Model Class Initialized
INFO - 2016-07-20 16:57:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:57:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:57:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 16:57:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:57:49 --> Final output sent to browser
DEBUG - 2016-07-20 16:57:49 --> Total execution time: 0.4774
INFO - 2016-07-20 16:57:58 --> Config Class Initialized
INFO - 2016-07-20 16:57:58 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:57:58 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:57:58 --> Utf8 Class Initialized
INFO - 2016-07-20 16:57:58 --> URI Class Initialized
INFO - 2016-07-20 16:57:58 --> Router Class Initialized
INFO - 2016-07-20 16:57:58 --> Output Class Initialized
INFO - 2016-07-20 16:57:58 --> Security Class Initialized
DEBUG - 2016-07-20 16:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:57:58 --> Input Class Initialized
INFO - 2016-07-20 16:57:58 --> Language Class Initialized
INFO - 2016-07-20 16:57:58 --> Loader Class Initialized
INFO - 2016-07-20 16:57:58 --> Helper loaded: url_helper
INFO - 2016-07-20 16:57:58 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:57:58 --> Helper loaded: html_helper
INFO - 2016-07-20 16:57:58 --> Helper loaded: form_helper
INFO - 2016-07-20 16:57:58 --> Helper loaded: file_helper
INFO - 2016-07-20 16:57:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:57:58 --> Database Driver Class Initialized
INFO - 2016-07-20 16:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:57:58 --> Form Validation Class Initialized
INFO - 2016-07-20 16:57:58 --> Email Class Initialized
INFO - 2016-07-20 16:57:58 --> Controller Class Initialized
DEBUG - 2016-07-20 16:57:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:57:58 --> Model Class Initialized
INFO - 2016-07-20 16:57:58 --> Model Class Initialized
INFO - 2016-07-20 16:57:58 --> Model Class Initialized
INFO - 2016-07-20 16:57:58 --> Model Class Initialized
INFO - 2016-07-20 16:57:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:57:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:57:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:57:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:57:58 --> Final output sent to browser
DEBUG - 2016-07-20 16:57:58 --> Total execution time: 0.4737
INFO - 2016-07-20 16:58:01 --> Config Class Initialized
INFO - 2016-07-20 16:58:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:58:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:58:01 --> Utf8 Class Initialized
INFO - 2016-07-20 16:58:01 --> URI Class Initialized
INFO - 2016-07-20 16:58:01 --> Router Class Initialized
INFO - 2016-07-20 16:58:01 --> Output Class Initialized
INFO - 2016-07-20 16:58:01 --> Security Class Initialized
DEBUG - 2016-07-20 16:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:58:01 --> Input Class Initialized
INFO - 2016-07-20 16:58:01 --> Language Class Initialized
INFO - 2016-07-20 16:58:01 --> Loader Class Initialized
INFO - 2016-07-20 16:58:01 --> Helper loaded: url_helper
INFO - 2016-07-20 16:58:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:58:01 --> Helper loaded: html_helper
INFO - 2016-07-20 16:58:01 --> Helper loaded: form_helper
INFO - 2016-07-20 16:58:01 --> Helper loaded: file_helper
INFO - 2016-07-20 16:58:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:58:01 --> Database Driver Class Initialized
INFO - 2016-07-20 16:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:58:01 --> Form Validation Class Initialized
INFO - 2016-07-20 16:58:01 --> Email Class Initialized
INFO - 2016-07-20 16:58:01 --> Controller Class Initialized
DEBUG - 2016-07-20 16:58:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:58:01 --> Model Class Initialized
INFO - 2016-07-20 16:58:01 --> Model Class Initialized
INFO - 2016-07-20 16:58:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:58:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:58:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 16:58:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:58:01 --> Final output sent to browser
DEBUG - 2016-07-20 16:58:01 --> Total execution time: 0.4493
INFO - 2016-07-20 16:58:17 --> Config Class Initialized
INFO - 2016-07-20 16:58:17 --> Hooks Class Initialized
DEBUG - 2016-07-20 16:58:17 --> UTF-8 Support Enabled
INFO - 2016-07-20 16:58:17 --> Utf8 Class Initialized
INFO - 2016-07-20 16:58:17 --> URI Class Initialized
INFO - 2016-07-20 16:58:17 --> Router Class Initialized
INFO - 2016-07-20 16:58:17 --> Output Class Initialized
INFO - 2016-07-20 16:58:17 --> Security Class Initialized
DEBUG - 2016-07-20 16:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 16:58:17 --> Input Class Initialized
INFO - 2016-07-20 16:58:17 --> Language Class Initialized
INFO - 2016-07-20 16:58:17 --> Loader Class Initialized
INFO - 2016-07-20 16:58:17 --> Helper loaded: url_helper
INFO - 2016-07-20 16:58:17 --> Helper loaded: utils_helper
INFO - 2016-07-20 16:58:17 --> Helper loaded: html_helper
INFO - 2016-07-20 16:58:17 --> Helper loaded: form_helper
INFO - 2016-07-20 16:58:17 --> Helper loaded: file_helper
INFO - 2016-07-20 16:58:17 --> Helper loaded: myemail_helper
INFO - 2016-07-20 16:58:17 --> Database Driver Class Initialized
INFO - 2016-07-20 16:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 16:58:17 --> Form Validation Class Initialized
INFO - 2016-07-20 16:58:17 --> Email Class Initialized
INFO - 2016-07-20 16:58:17 --> Controller Class Initialized
DEBUG - 2016-07-20 16:58:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 16:58:17 --> Model Class Initialized
INFO - 2016-07-20 16:58:17 --> Model Class Initialized
INFO - 2016-07-20 16:58:17 --> Model Class Initialized
INFO - 2016-07-20 16:58:17 --> Model Class Initialized
INFO - 2016-07-20 16:58:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 16:58:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 16:58:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 16:58:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 16:58:17 --> Final output sent to browser
DEBUG - 2016-07-20 16:58:17 --> Total execution time: 0.4712
INFO - 2016-07-20 17:23:44 --> Config Class Initialized
INFO - 2016-07-20 17:23:44 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:23:44 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:23:44 --> Utf8 Class Initialized
INFO - 2016-07-20 17:23:44 --> URI Class Initialized
INFO - 2016-07-20 17:23:44 --> Router Class Initialized
INFO - 2016-07-20 17:23:44 --> Output Class Initialized
INFO - 2016-07-20 17:23:44 --> Security Class Initialized
DEBUG - 2016-07-20 17:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:23:44 --> Input Class Initialized
INFO - 2016-07-20 17:23:44 --> Language Class Initialized
INFO - 2016-07-20 17:23:44 --> Loader Class Initialized
INFO - 2016-07-20 17:23:44 --> Helper loaded: url_helper
INFO - 2016-07-20 17:23:44 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:23:44 --> Helper loaded: html_helper
INFO - 2016-07-20 17:23:44 --> Helper loaded: form_helper
INFO - 2016-07-20 17:23:44 --> Helper loaded: file_helper
INFO - 2016-07-20 17:23:44 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:23:44 --> Database Driver Class Initialized
INFO - 2016-07-20 17:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:23:44 --> Form Validation Class Initialized
INFO - 2016-07-20 17:23:44 --> Email Class Initialized
INFO - 2016-07-20 17:23:44 --> Controller Class Initialized
DEBUG - 2016-07-20 17:23:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:23:44 --> Model Class Initialized
INFO - 2016-07-20 17:23:44 --> Model Class Initialized
INFO - 2016-07-20 17:23:44 --> Model Class Initialized
INFO - 2016-07-20 17:23:44 --> Model Class Initialized
INFO - 2016-07-20 17:23:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:23:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:23:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:23:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:23:52 --> Config Class Initialized
INFO - 2016-07-20 17:23:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:23:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:23:52 --> Utf8 Class Initialized
INFO - 2016-07-20 17:23:52 --> URI Class Initialized
INFO - 2016-07-20 17:23:52 --> Router Class Initialized
INFO - 2016-07-20 17:23:52 --> Output Class Initialized
INFO - 2016-07-20 17:23:52 --> Security Class Initialized
DEBUG - 2016-07-20 17:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:23:52 --> Input Class Initialized
INFO - 2016-07-20 17:23:52 --> Language Class Initialized
INFO - 2016-07-20 17:23:52 --> Loader Class Initialized
INFO - 2016-07-20 17:23:52 --> Helper loaded: url_helper
INFO - 2016-07-20 17:23:52 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:23:52 --> Helper loaded: html_helper
INFO - 2016-07-20 17:23:52 --> Helper loaded: form_helper
INFO - 2016-07-20 17:23:53 --> Helper loaded: file_helper
INFO - 2016-07-20 17:23:53 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:23:53 --> Database Driver Class Initialized
INFO - 2016-07-20 17:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:23:53 --> Form Validation Class Initialized
INFO - 2016-07-20 17:23:53 --> Email Class Initialized
INFO - 2016-07-20 17:23:53 --> Controller Class Initialized
DEBUG - 2016-07-20 17:23:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:23:53 --> Model Class Initialized
INFO - 2016-07-20 17:23:53 --> Model Class Initialized
INFO - 2016-07-20 17:23:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:23:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:23:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:23:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:23:53 --> Final output sent to browser
DEBUG - 2016-07-20 17:23:53 --> Total execution time: 0.4596
INFO - 2016-07-20 17:23:58 --> Config Class Initialized
INFO - 2016-07-20 17:23:58 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:23:58 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:23:58 --> Utf8 Class Initialized
INFO - 2016-07-20 17:23:58 --> URI Class Initialized
INFO - 2016-07-20 17:23:58 --> Router Class Initialized
INFO - 2016-07-20 17:23:58 --> Output Class Initialized
INFO - 2016-07-20 17:23:58 --> Security Class Initialized
DEBUG - 2016-07-20 17:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:23:58 --> Input Class Initialized
INFO - 2016-07-20 17:23:58 --> Language Class Initialized
INFO - 2016-07-20 17:23:58 --> Loader Class Initialized
INFO - 2016-07-20 17:23:58 --> Helper loaded: url_helper
INFO - 2016-07-20 17:23:58 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:23:58 --> Helper loaded: html_helper
INFO - 2016-07-20 17:23:58 --> Helper loaded: form_helper
INFO - 2016-07-20 17:23:58 --> Helper loaded: file_helper
INFO - 2016-07-20 17:23:58 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:23:58 --> Database Driver Class Initialized
INFO - 2016-07-20 17:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:23:58 --> Form Validation Class Initialized
INFO - 2016-07-20 17:23:58 --> Email Class Initialized
INFO - 2016-07-20 17:23:58 --> Controller Class Initialized
DEBUG - 2016-07-20 17:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:23:58 --> Model Class Initialized
INFO - 2016-07-20 17:23:58 --> Model Class Initialized
INFO - 2016-07-20 17:23:58 --> Model Class Initialized
INFO - 2016-07-20 17:23:58 --> Model Class Initialized
INFO - 2016-07-20 17:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:23:58 --> Final output sent to browser
DEBUG - 2016-07-20 17:23:58 --> Total execution time: 0.4806
INFO - 2016-07-20 17:24:01 --> Config Class Initialized
INFO - 2016-07-20 17:24:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:24:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:24:01 --> Utf8 Class Initialized
INFO - 2016-07-20 17:24:01 --> URI Class Initialized
INFO - 2016-07-20 17:24:01 --> Router Class Initialized
INFO - 2016-07-20 17:24:01 --> Output Class Initialized
INFO - 2016-07-20 17:24:01 --> Security Class Initialized
DEBUG - 2016-07-20 17:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:24:01 --> Input Class Initialized
INFO - 2016-07-20 17:24:01 --> Language Class Initialized
INFO - 2016-07-20 17:24:01 --> Loader Class Initialized
INFO - 2016-07-20 17:24:01 --> Helper loaded: url_helper
INFO - 2016-07-20 17:24:01 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:24:01 --> Helper loaded: html_helper
INFO - 2016-07-20 17:24:01 --> Helper loaded: form_helper
INFO - 2016-07-20 17:24:01 --> Helper loaded: file_helper
INFO - 2016-07-20 17:24:01 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:24:01 --> Database Driver Class Initialized
INFO - 2016-07-20 17:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:24:02 --> Form Validation Class Initialized
INFO - 2016-07-20 17:24:02 --> Email Class Initialized
INFO - 2016-07-20 17:24:02 --> Controller Class Initialized
DEBUG - 2016-07-20 17:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:24:02 --> Model Class Initialized
INFO - 2016-07-20 17:24:02 --> Model Class Initialized
INFO - 2016-07-20 17:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 17:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:24:02 --> Final output sent to browser
DEBUG - 2016-07-20 17:24:02 --> Total execution time: 0.4871
INFO - 2016-07-20 17:27:45 --> Config Class Initialized
INFO - 2016-07-20 17:27:45 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:27:45 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:27:45 --> Utf8 Class Initialized
INFO - 2016-07-20 17:27:45 --> URI Class Initialized
INFO - 2016-07-20 17:27:45 --> Router Class Initialized
INFO - 2016-07-20 17:27:45 --> Output Class Initialized
INFO - 2016-07-20 17:27:45 --> Security Class Initialized
DEBUG - 2016-07-20 17:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:27:46 --> Input Class Initialized
INFO - 2016-07-20 17:27:46 --> Language Class Initialized
INFO - 2016-07-20 17:27:46 --> Loader Class Initialized
INFO - 2016-07-20 17:27:46 --> Helper loaded: url_helper
INFO - 2016-07-20 17:27:46 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:27:46 --> Helper loaded: html_helper
INFO - 2016-07-20 17:27:46 --> Helper loaded: form_helper
INFO - 2016-07-20 17:27:46 --> Helper loaded: file_helper
INFO - 2016-07-20 17:27:46 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:27:46 --> Database Driver Class Initialized
INFO - 2016-07-20 17:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:27:46 --> Form Validation Class Initialized
INFO - 2016-07-20 17:27:46 --> Email Class Initialized
INFO - 2016-07-20 17:27:46 --> Controller Class Initialized
DEBUG - 2016-07-20 17:27:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:27:46 --> Model Class Initialized
INFO - 2016-07-20 17:27:46 --> Model Class Initialized
INFO - 2016-07-20 17:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 17:27:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:27:46 --> Final output sent to browser
DEBUG - 2016-07-20 17:27:46 --> Total execution time: 0.4612
INFO - 2016-07-20 17:27:52 --> Config Class Initialized
INFO - 2016-07-20 17:27:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:27:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:27:52 --> Utf8 Class Initialized
INFO - 2016-07-20 17:27:53 --> URI Class Initialized
INFO - 2016-07-20 17:27:53 --> Router Class Initialized
INFO - 2016-07-20 17:27:53 --> Output Class Initialized
INFO - 2016-07-20 17:27:53 --> Security Class Initialized
DEBUG - 2016-07-20 17:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:27:53 --> Input Class Initialized
INFO - 2016-07-20 17:27:53 --> Language Class Initialized
INFO - 2016-07-20 17:27:53 --> Loader Class Initialized
INFO - 2016-07-20 17:27:53 --> Helper loaded: url_helper
INFO - 2016-07-20 17:27:53 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:27:53 --> Helper loaded: html_helper
INFO - 2016-07-20 17:27:53 --> Helper loaded: form_helper
INFO - 2016-07-20 17:27:53 --> Helper loaded: file_helper
INFO - 2016-07-20 17:27:53 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:27:53 --> Database Driver Class Initialized
INFO - 2016-07-20 17:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:27:53 --> Form Validation Class Initialized
INFO - 2016-07-20 17:27:53 --> Email Class Initialized
INFO - 2016-07-20 17:27:53 --> Controller Class Initialized
DEBUG - 2016-07-20 17:27:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:27:53 --> Model Class Initialized
INFO - 2016-07-20 17:27:53 --> Model Class Initialized
INFO - 2016-07-20 17:27:53 --> Model Class Initialized
INFO - 2016-07-20 17:27:53 --> Model Class Initialized
INFO - 2016-07-20 17:27:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:27:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:27:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:27:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:27:53 --> Final output sent to browser
DEBUG - 2016-07-20 17:27:53 --> Total execution time: 0.5160
INFO - 2016-07-20 17:28:16 --> Config Class Initialized
INFO - 2016-07-20 17:28:16 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:28:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:28:17 --> Utf8 Class Initialized
INFO - 2016-07-20 17:28:17 --> URI Class Initialized
INFO - 2016-07-20 17:28:17 --> Router Class Initialized
INFO - 2016-07-20 17:28:17 --> Output Class Initialized
INFO - 2016-07-20 17:28:17 --> Security Class Initialized
DEBUG - 2016-07-20 17:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:28:17 --> Input Class Initialized
INFO - 2016-07-20 17:28:17 --> Language Class Initialized
INFO - 2016-07-20 17:28:17 --> Loader Class Initialized
INFO - 2016-07-20 17:28:17 --> Helper loaded: url_helper
INFO - 2016-07-20 17:28:17 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:28:17 --> Helper loaded: html_helper
INFO - 2016-07-20 17:28:17 --> Helper loaded: form_helper
INFO - 2016-07-20 17:28:17 --> Helper loaded: file_helper
INFO - 2016-07-20 17:28:17 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:28:17 --> Database Driver Class Initialized
INFO - 2016-07-20 17:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:28:17 --> Form Validation Class Initialized
INFO - 2016-07-20 17:28:17 --> Email Class Initialized
INFO - 2016-07-20 17:28:17 --> Controller Class Initialized
DEBUG - 2016-07-20 17:28:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:28:17 --> Model Class Initialized
INFO - 2016-07-20 17:28:17 --> Model Class Initialized
INFO - 2016-07-20 17:28:17 --> Model Class Initialized
INFO - 2016-07-20 17:28:17 --> Model Class Initialized
INFO - 2016-07-20 17:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:31:37 --> Config Class Initialized
INFO - 2016-07-20 17:31:37 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:31:37 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:31:37 --> Utf8 Class Initialized
INFO - 2016-07-20 17:31:37 --> URI Class Initialized
INFO - 2016-07-20 17:31:37 --> Router Class Initialized
INFO - 2016-07-20 17:31:37 --> Output Class Initialized
INFO - 2016-07-20 17:31:37 --> Security Class Initialized
DEBUG - 2016-07-20 17:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:31:37 --> Input Class Initialized
INFO - 2016-07-20 17:31:37 --> Language Class Initialized
INFO - 2016-07-20 17:31:37 --> Loader Class Initialized
INFO - 2016-07-20 17:31:37 --> Helper loaded: url_helper
INFO - 2016-07-20 17:31:37 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:31:37 --> Helper loaded: html_helper
INFO - 2016-07-20 17:31:37 --> Helper loaded: form_helper
INFO - 2016-07-20 17:31:37 --> Helper loaded: file_helper
INFO - 2016-07-20 17:31:37 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:31:37 --> Database Driver Class Initialized
INFO - 2016-07-20 17:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:31:37 --> Form Validation Class Initialized
INFO - 2016-07-20 17:31:38 --> Email Class Initialized
INFO - 2016-07-20 17:31:38 --> Controller Class Initialized
DEBUG - 2016-07-20 17:31:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:31:38 --> Config Class Initialized
INFO - 2016-07-20 17:31:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:31:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:31:38 --> Utf8 Class Initialized
INFO - 2016-07-20 17:31:38 --> URI Class Initialized
INFO - 2016-07-20 17:31:38 --> Router Class Initialized
INFO - 2016-07-20 17:31:38 --> Output Class Initialized
INFO - 2016-07-20 17:31:38 --> Security Class Initialized
DEBUG - 2016-07-20 17:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:31:38 --> Input Class Initialized
INFO - 2016-07-20 17:31:38 --> Language Class Initialized
INFO - 2016-07-20 17:31:38 --> Loader Class Initialized
INFO - 2016-07-20 17:31:38 --> Helper loaded: url_helper
INFO - 2016-07-20 17:31:38 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:31:38 --> Helper loaded: html_helper
INFO - 2016-07-20 17:31:38 --> Helper loaded: form_helper
INFO - 2016-07-20 17:31:38 --> Helper loaded: file_helper
INFO - 2016-07-20 17:31:38 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:31:38 --> Database Driver Class Initialized
INFO - 2016-07-20 17:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:31:38 --> Form Validation Class Initialized
INFO - 2016-07-20 17:31:38 --> Email Class Initialized
INFO - 2016-07-20 17:31:38 --> Controller Class Initialized
DEBUG - 2016-07-20 17:31:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> Model Class Initialized
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:31:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:31:38 --> Final output sent to browser
DEBUG - 2016-07-20 17:31:38 --> Total execution time: 0.4620
INFO - 2016-07-20 17:34:35 --> Config Class Initialized
INFO - 2016-07-20 17:34:35 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:34:35 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:34:35 --> Utf8 Class Initialized
INFO - 2016-07-20 17:34:35 --> URI Class Initialized
INFO - 2016-07-20 17:34:35 --> Router Class Initialized
INFO - 2016-07-20 17:34:35 --> Output Class Initialized
INFO - 2016-07-20 17:34:35 --> Security Class Initialized
DEBUG - 2016-07-20 17:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:34:35 --> Input Class Initialized
INFO - 2016-07-20 17:34:35 --> Language Class Initialized
INFO - 2016-07-20 17:34:35 --> Loader Class Initialized
INFO - 2016-07-20 17:34:35 --> Helper loaded: url_helper
INFO - 2016-07-20 17:34:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:34:35 --> Helper loaded: html_helper
INFO - 2016-07-20 17:34:35 --> Helper loaded: form_helper
INFO - 2016-07-20 17:34:35 --> Helper loaded: file_helper
INFO - 2016-07-20 17:34:35 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:34:35 --> Database Driver Class Initialized
INFO - 2016-07-20 17:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:34:35 --> Form Validation Class Initialized
INFO - 2016-07-20 17:34:35 --> Email Class Initialized
INFO - 2016-07-20 17:34:36 --> Controller Class Initialized
DEBUG - 2016-07-20 17:34:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:34:36 --> Model Class Initialized
INFO - 2016-07-20 17:34:36 --> Model Class Initialized
INFO - 2016-07-20 17:34:36 --> Model Class Initialized
INFO - 2016-07-20 17:34:36 --> Model Class Initialized
INFO - 2016-07-20 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:34:36 --> Final output sent to browser
DEBUG - 2016-07-20 17:34:36 --> Total execution time: 0.4967
INFO - 2016-07-20 17:37:20 --> Config Class Initialized
INFO - 2016-07-20 17:37:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:37:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:37:20 --> Utf8 Class Initialized
INFO - 2016-07-20 17:37:20 --> URI Class Initialized
INFO - 2016-07-20 17:37:20 --> Router Class Initialized
INFO - 2016-07-20 17:37:20 --> Output Class Initialized
INFO - 2016-07-20 17:37:20 --> Security Class Initialized
DEBUG - 2016-07-20 17:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:37:20 --> Input Class Initialized
INFO - 2016-07-20 17:37:20 --> Language Class Initialized
INFO - 2016-07-20 17:37:20 --> Loader Class Initialized
INFO - 2016-07-20 17:37:20 --> Helper loaded: url_helper
INFO - 2016-07-20 17:37:20 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:37:20 --> Helper loaded: html_helper
INFO - 2016-07-20 17:37:20 --> Helper loaded: form_helper
INFO - 2016-07-20 17:37:20 --> Helper loaded: file_helper
INFO - 2016-07-20 17:37:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:37:20 --> Database Driver Class Initialized
INFO - 2016-07-20 17:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:37:20 --> Form Validation Class Initialized
INFO - 2016-07-20 17:37:20 --> Email Class Initialized
INFO - 2016-07-20 17:37:20 --> Controller Class Initialized
DEBUG - 2016-07-20 17:37:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:37:20 --> Model Class Initialized
INFO - 2016-07-20 17:37:20 --> Model Class Initialized
INFO - 2016-07-20 17:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 17:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:37:20 --> Final output sent to browser
DEBUG - 2016-07-20 17:37:20 --> Total execution time: 0.4726
INFO - 2016-07-20 17:42:13 --> Config Class Initialized
INFO - 2016-07-20 17:42:13 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:42:13 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:42:13 --> Utf8 Class Initialized
INFO - 2016-07-20 17:42:13 --> URI Class Initialized
INFO - 2016-07-20 17:42:13 --> Router Class Initialized
INFO - 2016-07-20 17:42:13 --> Output Class Initialized
INFO - 2016-07-20 17:42:13 --> Security Class Initialized
DEBUG - 2016-07-20 17:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:42:13 --> Input Class Initialized
INFO - 2016-07-20 17:42:13 --> Language Class Initialized
INFO - 2016-07-20 17:42:13 --> Loader Class Initialized
INFO - 2016-07-20 17:42:13 --> Helper loaded: url_helper
INFO - 2016-07-20 17:42:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:42:13 --> Helper loaded: html_helper
INFO - 2016-07-20 17:42:13 --> Helper loaded: form_helper
INFO - 2016-07-20 17:42:13 --> Helper loaded: file_helper
INFO - 2016-07-20 17:42:13 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:42:13 --> Database Driver Class Initialized
INFO - 2016-07-20 17:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:42:13 --> Form Validation Class Initialized
INFO - 2016-07-20 17:42:13 --> Email Class Initialized
INFO - 2016-07-20 17:42:13 --> Controller Class Initialized
DEBUG - 2016-07-20 17:42:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:42:13 --> Model Class Initialized
INFO - 2016-07-20 17:42:13 --> Model Class Initialized
INFO - 2016-07-20 17:42:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:42:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:42:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 17:42:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:42:13 --> Final output sent to browser
DEBUG - 2016-07-20 17:42:13 --> Total execution time: 0.4771
INFO - 2016-07-20 17:42:18 --> Config Class Initialized
INFO - 2016-07-20 17:42:18 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:42:18 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:42:18 --> Utf8 Class Initialized
INFO - 2016-07-20 17:42:18 --> URI Class Initialized
INFO - 2016-07-20 17:42:18 --> Router Class Initialized
INFO - 2016-07-20 17:42:18 --> Output Class Initialized
INFO - 2016-07-20 17:42:18 --> Security Class Initialized
DEBUG - 2016-07-20 17:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:42:18 --> Input Class Initialized
INFO - 2016-07-20 17:42:18 --> Language Class Initialized
INFO - 2016-07-20 17:42:18 --> Loader Class Initialized
INFO - 2016-07-20 17:42:18 --> Helper loaded: url_helper
INFO - 2016-07-20 17:42:18 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:42:18 --> Helper loaded: html_helper
INFO - 2016-07-20 17:42:18 --> Helper loaded: form_helper
INFO - 2016-07-20 17:42:18 --> Helper loaded: file_helper
INFO - 2016-07-20 17:42:18 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:42:18 --> Database Driver Class Initialized
INFO - 2016-07-20 17:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:42:18 --> Form Validation Class Initialized
INFO - 2016-07-20 17:42:18 --> Email Class Initialized
INFO - 2016-07-20 17:42:18 --> Controller Class Initialized
DEBUG - 2016-07-20 17:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:42:18 --> Model Class Initialized
INFO - 2016-07-20 17:42:18 --> Model Class Initialized
INFO - 2016-07-20 17:42:18 --> Model Class Initialized
INFO - 2016-07-20 17:42:18 --> Model Class Initialized
INFO - 2016-07-20 17:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:42:18 --> Final output sent to browser
DEBUG - 2016-07-20 17:42:18 --> Total execution time: 0.5135
INFO - 2016-07-20 17:42:33 --> Config Class Initialized
INFO - 2016-07-20 17:42:33 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:42:33 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:42:33 --> Utf8 Class Initialized
INFO - 2016-07-20 17:42:33 --> URI Class Initialized
INFO - 2016-07-20 17:42:33 --> Router Class Initialized
INFO - 2016-07-20 17:42:33 --> Output Class Initialized
INFO - 2016-07-20 17:42:33 --> Security Class Initialized
DEBUG - 2016-07-20 17:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:42:33 --> Input Class Initialized
INFO - 2016-07-20 17:42:33 --> Language Class Initialized
INFO - 2016-07-20 17:42:33 --> Loader Class Initialized
INFO - 2016-07-20 17:42:33 --> Helper loaded: url_helper
INFO - 2016-07-20 17:42:33 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:42:34 --> Helper loaded: html_helper
INFO - 2016-07-20 17:42:34 --> Helper loaded: form_helper
INFO - 2016-07-20 17:42:34 --> Helper loaded: file_helper
INFO - 2016-07-20 17:42:34 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:42:34 --> Database Driver Class Initialized
INFO - 2016-07-20 17:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:42:34 --> Form Validation Class Initialized
INFO - 2016-07-20 17:42:34 --> Email Class Initialized
INFO - 2016-07-20 17:42:34 --> Controller Class Initialized
DEBUG - 2016-07-20 17:42:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:42:34 --> Model Class Initialized
INFO - 2016-07-20 17:42:34 --> Model Class Initialized
INFO - 2016-07-20 17:42:34 --> Model Class Initialized
INFO - 2016-07-20 17:42:34 --> Model Class Initialized
INFO - 2016-07-20 17:42:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:42:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:42:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:42:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:42:42 --> Config Class Initialized
INFO - 2016-07-20 17:42:42 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:42:42 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:42:42 --> Utf8 Class Initialized
INFO - 2016-07-20 17:42:42 --> URI Class Initialized
INFO - 2016-07-20 17:42:42 --> Router Class Initialized
INFO - 2016-07-20 17:42:42 --> Output Class Initialized
INFO - 2016-07-20 17:42:42 --> Security Class Initialized
DEBUG - 2016-07-20 17:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:42:42 --> Input Class Initialized
INFO - 2016-07-20 17:42:42 --> Language Class Initialized
INFO - 2016-07-20 17:42:42 --> Loader Class Initialized
INFO - 2016-07-20 17:42:42 --> Helper loaded: url_helper
INFO - 2016-07-20 17:42:42 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:42:42 --> Helper loaded: html_helper
INFO - 2016-07-20 17:42:42 --> Helper loaded: form_helper
INFO - 2016-07-20 17:42:42 --> Helper loaded: file_helper
INFO - 2016-07-20 17:42:42 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:42:42 --> Database Driver Class Initialized
INFO - 2016-07-20 17:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:42:42 --> Form Validation Class Initialized
INFO - 2016-07-20 17:42:42 --> Email Class Initialized
INFO - 2016-07-20 17:42:42 --> Controller Class Initialized
DEBUG - 2016-07-20 17:42:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:42:42 --> Model Class Initialized
INFO - 2016-07-20 17:42:42 --> Model Class Initialized
INFO - 2016-07-20 17:42:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:42:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:42:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:42:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:42:42 --> Final output sent to browser
DEBUG - 2016-07-20 17:42:42 --> Total execution time: 0.4622
INFO - 2016-07-20 17:42:59 --> Config Class Initialized
INFO - 2016-07-20 17:42:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:42:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:42:59 --> Utf8 Class Initialized
INFO - 2016-07-20 17:42:59 --> URI Class Initialized
INFO - 2016-07-20 17:42:59 --> Router Class Initialized
INFO - 2016-07-20 17:42:59 --> Output Class Initialized
INFO - 2016-07-20 17:42:59 --> Security Class Initialized
DEBUG - 2016-07-20 17:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:42:59 --> Input Class Initialized
INFO - 2016-07-20 17:42:59 --> Language Class Initialized
INFO - 2016-07-20 17:42:59 --> Loader Class Initialized
INFO - 2016-07-20 17:42:59 --> Helper loaded: url_helper
INFO - 2016-07-20 17:42:59 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:42:59 --> Helper loaded: html_helper
INFO - 2016-07-20 17:42:59 --> Helper loaded: form_helper
INFO - 2016-07-20 17:43:00 --> Helper loaded: file_helper
INFO - 2016-07-20 17:43:00 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:43:00 --> Database Driver Class Initialized
INFO - 2016-07-20 17:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:43:00 --> Form Validation Class Initialized
INFO - 2016-07-20 17:43:00 --> Email Class Initialized
INFO - 2016-07-20 17:43:00 --> Controller Class Initialized
DEBUG - 2016-07-20 17:43:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:43:00 --> Model Class Initialized
INFO - 2016-07-20 17:43:00 --> Model Class Initialized
INFO - 2016-07-20 17:43:00 --> Model Class Initialized
INFO - 2016-07-20 17:43:00 --> Model Class Initialized
INFO - 2016-07-20 17:43:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:43:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:43:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:43:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:43:00 --> Final output sent to browser
DEBUG - 2016-07-20 17:43:00 --> Total execution time: 0.5008
INFO - 2016-07-20 17:43:36 --> Config Class Initialized
INFO - 2016-07-20 17:43:36 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:43:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:43:36 --> Utf8 Class Initialized
INFO - 2016-07-20 17:43:36 --> URI Class Initialized
INFO - 2016-07-20 17:43:36 --> Router Class Initialized
INFO - 2016-07-20 17:43:36 --> Output Class Initialized
INFO - 2016-07-20 17:43:36 --> Security Class Initialized
DEBUG - 2016-07-20 17:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:43:36 --> Input Class Initialized
INFO - 2016-07-20 17:43:36 --> Language Class Initialized
INFO - 2016-07-20 17:43:36 --> Loader Class Initialized
INFO - 2016-07-20 17:43:36 --> Helper loaded: url_helper
INFO - 2016-07-20 17:43:36 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:43:36 --> Helper loaded: html_helper
INFO - 2016-07-20 17:43:36 --> Helper loaded: form_helper
INFO - 2016-07-20 17:43:36 --> Helper loaded: file_helper
INFO - 2016-07-20 17:43:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:43:36 --> Database Driver Class Initialized
INFO - 2016-07-20 17:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:43:36 --> Form Validation Class Initialized
INFO - 2016-07-20 17:43:36 --> Email Class Initialized
INFO - 2016-07-20 17:43:36 --> Controller Class Initialized
DEBUG - 2016-07-20 17:43:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:43:36 --> Model Class Initialized
INFO - 2016-07-20 17:43:36 --> Model Class Initialized
INFO - 2016-07-20 17:43:36 --> Model Class Initialized
INFO - 2016-07-20 17:43:36 --> Model Class Initialized
INFO - 2016-07-20 17:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:43:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:43:44 --> Config Class Initialized
INFO - 2016-07-20 17:43:44 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:43:44 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:43:44 --> Utf8 Class Initialized
INFO - 2016-07-20 17:43:44 --> URI Class Initialized
INFO - 2016-07-20 17:43:44 --> Router Class Initialized
INFO - 2016-07-20 17:43:44 --> Output Class Initialized
INFO - 2016-07-20 17:43:44 --> Security Class Initialized
DEBUG - 2016-07-20 17:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:43:44 --> Input Class Initialized
INFO - 2016-07-20 17:43:44 --> Language Class Initialized
INFO - 2016-07-20 17:43:44 --> Loader Class Initialized
INFO - 2016-07-20 17:43:44 --> Helper loaded: url_helper
INFO - 2016-07-20 17:43:44 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:43:44 --> Helper loaded: html_helper
INFO - 2016-07-20 17:43:44 --> Helper loaded: form_helper
INFO - 2016-07-20 17:43:44 --> Helper loaded: file_helper
INFO - 2016-07-20 17:43:44 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:43:44 --> Database Driver Class Initialized
INFO - 2016-07-20 17:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:43:44 --> Form Validation Class Initialized
INFO - 2016-07-20 17:43:44 --> Email Class Initialized
INFO - 2016-07-20 17:43:44 --> Controller Class Initialized
DEBUG - 2016-07-20 17:43:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:43:44 --> Model Class Initialized
INFO - 2016-07-20 17:43:44 --> Model Class Initialized
INFO - 2016-07-20 17:43:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:43:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:43:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:43:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:43:44 --> Final output sent to browser
DEBUG - 2016-07-20 17:43:44 --> Total execution time: 0.4687
INFO - 2016-07-20 17:44:49 --> Config Class Initialized
INFO - 2016-07-20 17:44:49 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:44:49 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:44:49 --> Utf8 Class Initialized
INFO - 2016-07-20 17:44:49 --> URI Class Initialized
INFO - 2016-07-20 17:44:49 --> Router Class Initialized
INFO - 2016-07-20 17:44:49 --> Output Class Initialized
INFO - 2016-07-20 17:44:49 --> Security Class Initialized
DEBUG - 2016-07-20 17:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:44:49 --> Input Class Initialized
INFO - 2016-07-20 17:44:49 --> Language Class Initialized
INFO - 2016-07-20 17:44:49 --> Loader Class Initialized
INFO - 2016-07-20 17:44:49 --> Helper loaded: url_helper
INFO - 2016-07-20 17:44:49 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:44:49 --> Helper loaded: html_helper
INFO - 2016-07-20 17:44:49 --> Helper loaded: form_helper
INFO - 2016-07-20 17:44:49 --> Helper loaded: file_helper
INFO - 2016-07-20 17:44:49 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:44:49 --> Database Driver Class Initialized
INFO - 2016-07-20 17:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:44:49 --> Form Validation Class Initialized
INFO - 2016-07-20 17:44:49 --> Email Class Initialized
INFO - 2016-07-20 17:44:49 --> Controller Class Initialized
DEBUG - 2016-07-20 17:44:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:44:49 --> Model Class Initialized
INFO - 2016-07-20 17:44:49 --> Model Class Initialized
INFO - 2016-07-20 17:44:49 --> Model Class Initialized
INFO - 2016-07-20 17:44:49 --> Model Class Initialized
INFO - 2016-07-20 17:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:44:49 --> Final output sent to browser
DEBUG - 2016-07-20 17:44:49 --> Total execution time: 0.5164
INFO - 2016-07-20 17:46:35 --> Config Class Initialized
INFO - 2016-07-20 17:46:35 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:46:35 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:46:35 --> Utf8 Class Initialized
INFO - 2016-07-20 17:46:35 --> URI Class Initialized
INFO - 2016-07-20 17:46:35 --> Router Class Initialized
INFO - 2016-07-20 17:46:35 --> Output Class Initialized
INFO - 2016-07-20 17:46:35 --> Security Class Initialized
DEBUG - 2016-07-20 17:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:46:35 --> Input Class Initialized
INFO - 2016-07-20 17:46:35 --> Language Class Initialized
INFO - 2016-07-20 17:46:35 --> Loader Class Initialized
INFO - 2016-07-20 17:46:35 --> Helper loaded: url_helper
INFO - 2016-07-20 17:46:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:46:35 --> Helper loaded: html_helper
INFO - 2016-07-20 17:46:35 --> Helper loaded: form_helper
INFO - 2016-07-20 17:46:35 --> Helper loaded: file_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:46:36 --> Database Driver Class Initialized
INFO - 2016-07-20 17:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:46:36 --> Form Validation Class Initialized
INFO - 2016-07-20 17:46:36 --> Email Class Initialized
INFO - 2016-07-20 17:46:36 --> Controller Class Initialized
DEBUG - 2016-07-20 17:46:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:46:36 --> Config Class Initialized
INFO - 2016-07-20 17:46:36 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:46:36 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:46:36 --> Utf8 Class Initialized
INFO - 2016-07-20 17:46:36 --> URI Class Initialized
INFO - 2016-07-20 17:46:36 --> Router Class Initialized
INFO - 2016-07-20 17:46:36 --> Output Class Initialized
INFO - 2016-07-20 17:46:36 --> Security Class Initialized
DEBUG - 2016-07-20 17:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:46:36 --> Input Class Initialized
INFO - 2016-07-20 17:46:36 --> Language Class Initialized
INFO - 2016-07-20 17:46:36 --> Loader Class Initialized
INFO - 2016-07-20 17:46:36 --> Helper loaded: url_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: html_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: form_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: file_helper
INFO - 2016-07-20 17:46:36 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:46:36 --> Database Driver Class Initialized
INFO - 2016-07-20 17:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:46:36 --> Form Validation Class Initialized
INFO - 2016-07-20 17:46:36 --> Email Class Initialized
INFO - 2016-07-20 17:46:36 --> Controller Class Initialized
DEBUG - 2016-07-20 17:46:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> Model Class Initialized
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:46:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:46:36 --> Final output sent to browser
DEBUG - 2016-07-20 17:46:36 --> Total execution time: 0.4753
INFO - 2016-07-20 17:46:52 --> Config Class Initialized
INFO - 2016-07-20 17:46:52 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:46:52 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:46:52 --> Utf8 Class Initialized
INFO - 2016-07-20 17:46:52 --> URI Class Initialized
INFO - 2016-07-20 17:46:52 --> Router Class Initialized
INFO - 2016-07-20 17:46:52 --> Output Class Initialized
INFO - 2016-07-20 17:46:52 --> Security Class Initialized
DEBUG - 2016-07-20 17:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:46:52 --> Input Class Initialized
INFO - 2016-07-20 17:46:52 --> Language Class Initialized
INFO - 2016-07-20 17:46:52 --> Loader Class Initialized
INFO - 2016-07-20 17:46:52 --> Helper loaded: url_helper
INFO - 2016-07-20 17:46:52 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:46:52 --> Helper loaded: html_helper
INFO - 2016-07-20 17:46:53 --> Helper loaded: form_helper
INFO - 2016-07-20 17:46:53 --> Helper loaded: file_helper
INFO - 2016-07-20 17:46:53 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:46:53 --> Database Driver Class Initialized
INFO - 2016-07-20 17:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:46:53 --> Form Validation Class Initialized
INFO - 2016-07-20 17:46:53 --> Email Class Initialized
INFO - 2016-07-20 17:46:53 --> Controller Class Initialized
DEBUG - 2016-07-20 17:46:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:46:53 --> Model Class Initialized
INFO - 2016-07-20 17:46:53 --> Model Class Initialized
INFO - 2016-07-20 17:46:53 --> Model Class Initialized
INFO - 2016-07-20 17:46:53 --> Model Class Initialized
INFO - 2016-07-20 17:46:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:46:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:46:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:46:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:46:53 --> Final output sent to browser
DEBUG - 2016-07-20 17:46:53 --> Total execution time: 0.5289
INFO - 2016-07-20 17:46:57 --> Config Class Initialized
INFO - 2016-07-20 17:46:57 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:46:57 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:46:57 --> Utf8 Class Initialized
INFO - 2016-07-20 17:46:57 --> URI Class Initialized
INFO - 2016-07-20 17:46:57 --> Router Class Initialized
INFO - 2016-07-20 17:46:57 --> Output Class Initialized
INFO - 2016-07-20 17:46:57 --> Security Class Initialized
DEBUG - 2016-07-20 17:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:46:57 --> Input Class Initialized
INFO - 2016-07-20 17:46:57 --> Language Class Initialized
INFO - 2016-07-20 17:46:57 --> Loader Class Initialized
INFO - 2016-07-20 17:46:57 --> Helper loaded: url_helper
INFO - 2016-07-20 17:46:57 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:46:57 --> Helper loaded: html_helper
INFO - 2016-07-20 17:46:57 --> Helper loaded: form_helper
INFO - 2016-07-20 17:46:57 --> Helper loaded: file_helper
INFO - 2016-07-20 17:46:57 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:46:57 --> Database Driver Class Initialized
INFO - 2016-07-20 17:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:46:57 --> Form Validation Class Initialized
INFO - 2016-07-20 17:46:57 --> Email Class Initialized
INFO - 2016-07-20 17:46:57 --> Controller Class Initialized
DEBUG - 2016-07-20 17:46:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:46:58 --> Model Class Initialized
INFO - 2016-07-20 17:46:58 --> Model Class Initialized
INFO - 2016-07-20 17:46:58 --> Model Class Initialized
INFO - 2016-07-20 17:46:58 --> Model Class Initialized
INFO - 2016-07-20 17:46:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:46:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:46:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:46:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:46:58 --> Final output sent to browser
DEBUG - 2016-07-20 17:46:58 --> Total execution time: 0.5221
INFO - 2016-07-20 17:47:14 --> Config Class Initialized
INFO - 2016-07-20 17:47:14 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:47:14 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:47:14 --> Utf8 Class Initialized
INFO - 2016-07-20 17:47:14 --> URI Class Initialized
INFO - 2016-07-20 17:47:14 --> Router Class Initialized
INFO - 2016-07-20 17:47:14 --> Output Class Initialized
INFO - 2016-07-20 17:47:14 --> Security Class Initialized
DEBUG - 2016-07-20 17:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:47:14 --> Input Class Initialized
INFO - 2016-07-20 17:47:14 --> Language Class Initialized
INFO - 2016-07-20 17:47:14 --> Loader Class Initialized
INFO - 2016-07-20 17:47:14 --> Helper loaded: url_helper
INFO - 2016-07-20 17:47:15 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:47:15 --> Helper loaded: html_helper
INFO - 2016-07-20 17:47:15 --> Helper loaded: form_helper
INFO - 2016-07-20 17:47:15 --> Helper loaded: file_helper
INFO - 2016-07-20 17:47:15 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:47:15 --> Database Driver Class Initialized
INFO - 2016-07-20 17:47:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:47:15 --> Form Validation Class Initialized
INFO - 2016-07-20 17:47:15 --> Email Class Initialized
INFO - 2016-07-20 17:47:15 --> Controller Class Initialized
DEBUG - 2016-07-20 17:47:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:47:15 --> Model Class Initialized
INFO - 2016-07-20 17:47:15 --> Model Class Initialized
INFO - 2016-07-20 17:47:15 --> Model Class Initialized
INFO - 2016-07-20 17:47:15 --> Model Class Initialized
INFO - 2016-07-20 17:47:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:47:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:47:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:47:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:47:23 --> Config Class Initialized
INFO - 2016-07-20 17:47:23 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:47:23 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:47:23 --> Utf8 Class Initialized
INFO - 2016-07-20 17:47:23 --> URI Class Initialized
INFO - 2016-07-20 17:47:23 --> Router Class Initialized
INFO - 2016-07-20 17:47:23 --> Output Class Initialized
INFO - 2016-07-20 17:47:23 --> Security Class Initialized
DEBUG - 2016-07-20 17:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:47:23 --> Input Class Initialized
INFO - 2016-07-20 17:47:23 --> Language Class Initialized
INFO - 2016-07-20 17:47:23 --> Loader Class Initialized
INFO - 2016-07-20 17:47:23 --> Helper loaded: url_helper
INFO - 2016-07-20 17:47:23 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:47:23 --> Helper loaded: html_helper
INFO - 2016-07-20 17:47:23 --> Helper loaded: form_helper
INFO - 2016-07-20 17:47:23 --> Helper loaded: file_helper
INFO - 2016-07-20 17:47:23 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:47:23 --> Database Driver Class Initialized
INFO - 2016-07-20 17:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:47:23 --> Form Validation Class Initialized
INFO - 2016-07-20 17:47:23 --> Email Class Initialized
INFO - 2016-07-20 17:47:23 --> Controller Class Initialized
DEBUG - 2016-07-20 17:47:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:47:23 --> Model Class Initialized
INFO - 2016-07-20 17:47:23 --> Model Class Initialized
INFO - 2016-07-20 17:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:47:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:47:23 --> Final output sent to browser
DEBUG - 2016-07-20 17:47:23 --> Total execution time: 0.4792
INFO - 2016-07-20 17:47:42 --> Config Class Initialized
INFO - 2016-07-20 17:47:42 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:47:42 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:47:42 --> Utf8 Class Initialized
INFO - 2016-07-20 17:47:42 --> URI Class Initialized
INFO - 2016-07-20 17:47:42 --> Router Class Initialized
INFO - 2016-07-20 17:47:42 --> Output Class Initialized
INFO - 2016-07-20 17:47:42 --> Security Class Initialized
DEBUG - 2016-07-20 17:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:47:42 --> Input Class Initialized
INFO - 2016-07-20 17:47:42 --> Language Class Initialized
INFO - 2016-07-20 17:47:42 --> Loader Class Initialized
INFO - 2016-07-20 17:47:42 --> Helper loaded: url_helper
INFO - 2016-07-20 17:47:42 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:47:42 --> Helper loaded: html_helper
INFO - 2016-07-20 17:47:42 --> Helper loaded: form_helper
INFO - 2016-07-20 17:47:42 --> Helper loaded: file_helper
INFO - 2016-07-20 17:47:42 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:47:42 --> Database Driver Class Initialized
INFO - 2016-07-20 17:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:47:42 --> Form Validation Class Initialized
INFO - 2016-07-20 17:47:42 --> Email Class Initialized
INFO - 2016-07-20 17:47:42 --> Controller Class Initialized
DEBUG - 2016-07-20 17:47:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:47:42 --> Model Class Initialized
INFO - 2016-07-20 17:47:42 --> Model Class Initialized
INFO - 2016-07-20 17:47:42 --> Model Class Initialized
INFO - 2016-07-20 17:47:42 --> Model Class Initialized
INFO - 2016-07-20 17:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:47:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:47:42 --> Final output sent to browser
DEBUG - 2016-07-20 17:47:42 --> Total execution time: 0.5143
INFO - 2016-07-20 17:47:56 --> Config Class Initialized
INFO - 2016-07-20 17:47:56 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:47:56 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:47:56 --> Utf8 Class Initialized
INFO - 2016-07-20 17:47:56 --> URI Class Initialized
INFO - 2016-07-20 17:47:57 --> Router Class Initialized
INFO - 2016-07-20 17:47:57 --> Output Class Initialized
INFO - 2016-07-20 17:47:57 --> Security Class Initialized
DEBUG - 2016-07-20 17:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:47:57 --> Input Class Initialized
INFO - 2016-07-20 17:47:57 --> Language Class Initialized
INFO - 2016-07-20 17:47:57 --> Loader Class Initialized
INFO - 2016-07-20 17:47:57 --> Helper loaded: url_helper
INFO - 2016-07-20 17:47:57 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:47:57 --> Helper loaded: html_helper
INFO - 2016-07-20 17:47:57 --> Helper loaded: form_helper
INFO - 2016-07-20 17:47:57 --> Helper loaded: file_helper
INFO - 2016-07-20 17:47:57 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:47:57 --> Database Driver Class Initialized
INFO - 2016-07-20 17:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:47:57 --> Form Validation Class Initialized
INFO - 2016-07-20 17:47:57 --> Email Class Initialized
INFO - 2016-07-20 17:47:57 --> Controller Class Initialized
DEBUG - 2016-07-20 17:47:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:47:57 --> Model Class Initialized
INFO - 2016-07-20 17:47:57 --> Model Class Initialized
INFO - 2016-07-20 17:47:57 --> Model Class Initialized
INFO - 2016-07-20 17:47:57 --> Model Class Initialized
INFO - 2016-07-20 17:47:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:47:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:47:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 17:47:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:48:05 --> Config Class Initialized
INFO - 2016-07-20 17:48:05 --> Hooks Class Initialized
DEBUG - 2016-07-20 17:48:05 --> UTF-8 Support Enabled
INFO - 2016-07-20 17:48:05 --> Utf8 Class Initialized
INFO - 2016-07-20 17:48:05 --> URI Class Initialized
INFO - 2016-07-20 17:48:05 --> Router Class Initialized
INFO - 2016-07-20 17:48:05 --> Output Class Initialized
INFO - 2016-07-20 17:48:05 --> Security Class Initialized
DEBUG - 2016-07-20 17:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 17:48:05 --> Input Class Initialized
INFO - 2016-07-20 17:48:05 --> Language Class Initialized
INFO - 2016-07-20 17:48:05 --> Loader Class Initialized
INFO - 2016-07-20 17:48:05 --> Helper loaded: url_helper
INFO - 2016-07-20 17:48:05 --> Helper loaded: utils_helper
INFO - 2016-07-20 17:48:05 --> Helper loaded: html_helper
INFO - 2016-07-20 17:48:05 --> Helper loaded: form_helper
INFO - 2016-07-20 17:48:05 --> Helper loaded: file_helper
INFO - 2016-07-20 17:48:05 --> Helper loaded: myemail_helper
INFO - 2016-07-20 17:48:05 --> Database Driver Class Initialized
INFO - 2016-07-20 17:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 17:48:05 --> Form Validation Class Initialized
INFO - 2016-07-20 17:48:05 --> Email Class Initialized
INFO - 2016-07-20 17:48:05 --> Controller Class Initialized
DEBUG - 2016-07-20 17:48:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 17:48:05 --> Model Class Initialized
INFO - 2016-07-20 17:48:05 --> Model Class Initialized
INFO - 2016-07-20 17:48:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 17:48:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 17:48:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 17:48:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 17:48:05 --> Final output sent to browser
DEBUG - 2016-07-20 17:48:05 --> Total execution time: 0.4868
INFO - 2016-07-20 18:15:57 --> Config Class Initialized
INFO - 2016-07-20 18:15:57 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:15:57 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:15:57 --> Utf8 Class Initialized
INFO - 2016-07-20 18:15:57 --> URI Class Initialized
INFO - 2016-07-20 18:15:57 --> Router Class Initialized
INFO - 2016-07-20 18:15:57 --> Output Class Initialized
INFO - 2016-07-20 18:15:57 --> Security Class Initialized
DEBUG - 2016-07-20 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:15:57 --> Input Class Initialized
INFO - 2016-07-20 18:15:57 --> Language Class Initialized
INFO - 2016-07-20 18:15:57 --> Loader Class Initialized
INFO - 2016-07-20 18:15:57 --> Helper loaded: url_helper
INFO - 2016-07-20 18:15:57 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:15:57 --> Helper loaded: html_helper
INFO - 2016-07-20 18:15:57 --> Helper loaded: form_helper
INFO - 2016-07-20 18:15:57 --> Helper loaded: file_helper
INFO - 2016-07-20 18:15:57 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:15:57 --> Database Driver Class Initialized
INFO - 2016-07-20 18:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:15:57 --> Form Validation Class Initialized
INFO - 2016-07-20 18:15:57 --> Email Class Initialized
INFO - 2016-07-20 18:15:57 --> Controller Class Initialized
DEBUG - 2016-07-20 18:15:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:15:57 --> Model Class Initialized
INFO - 2016-07-20 18:15:57 --> Model Class Initialized
INFO - 2016-07-20 18:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:15:58 --> Final output sent to browser
DEBUG - 2016-07-20 18:15:58 --> Total execution time: 0.5387
INFO - 2016-07-20 18:16:01 --> Config Class Initialized
INFO - 2016-07-20 18:16:01 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:16:01 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:16:01 --> Utf8 Class Initialized
INFO - 2016-07-20 18:16:01 --> URI Class Initialized
INFO - 2016-07-20 18:16:01 --> Router Class Initialized
INFO - 2016-07-20 18:16:01 --> Output Class Initialized
INFO - 2016-07-20 18:16:01 --> Security Class Initialized
DEBUG - 2016-07-20 18:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:16:01 --> Input Class Initialized
INFO - 2016-07-20 18:16:01 --> Language Class Initialized
INFO - 2016-07-20 18:16:01 --> Loader Class Initialized
INFO - 2016-07-20 18:16:02 --> Helper loaded: url_helper
INFO - 2016-07-20 18:16:02 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:16:02 --> Helper loaded: html_helper
INFO - 2016-07-20 18:16:02 --> Helper loaded: form_helper
INFO - 2016-07-20 18:16:02 --> Helper loaded: file_helper
INFO - 2016-07-20 18:16:02 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:16:02 --> Database Driver Class Initialized
INFO - 2016-07-20 18:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:16:02 --> Form Validation Class Initialized
INFO - 2016-07-20 18:16:02 --> Email Class Initialized
INFO - 2016-07-20 18:16:02 --> Controller Class Initialized
DEBUG - 2016-07-20 18:16:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:16:02 --> Model Class Initialized
INFO - 2016-07-20 18:16:02 --> Model Class Initialized
INFO - 2016-07-20 18:16:02 --> Model Class Initialized
INFO - 2016-07-20 18:16:02 --> Model Class Initialized
INFO - 2016-07-20 18:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:16:02 --> Final output sent to browser
DEBUG - 2016-07-20 18:16:02 --> Total execution time: 0.5270
INFO - 2016-07-20 18:16:15 --> Config Class Initialized
INFO - 2016-07-20 18:16:15 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:16:15 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:16:15 --> Utf8 Class Initialized
INFO - 2016-07-20 18:16:15 --> URI Class Initialized
INFO - 2016-07-20 18:16:15 --> Router Class Initialized
INFO - 2016-07-20 18:16:15 --> Output Class Initialized
INFO - 2016-07-20 18:16:15 --> Security Class Initialized
DEBUG - 2016-07-20 18:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:16:15 --> Input Class Initialized
INFO - 2016-07-20 18:16:15 --> Language Class Initialized
INFO - 2016-07-20 18:16:15 --> Loader Class Initialized
INFO - 2016-07-20 18:16:15 --> Helper loaded: url_helper
INFO - 2016-07-20 18:16:15 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:16:15 --> Helper loaded: html_helper
INFO - 2016-07-20 18:16:15 --> Helper loaded: form_helper
INFO - 2016-07-20 18:16:15 --> Helper loaded: file_helper
INFO - 2016-07-20 18:16:15 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:16:15 --> Database Driver Class Initialized
INFO - 2016-07-20 18:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:16:15 --> Form Validation Class Initialized
INFO - 2016-07-20 18:16:15 --> Email Class Initialized
INFO - 2016-07-20 18:16:15 --> Controller Class Initialized
DEBUG - 2016-07-20 18:16:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:16:15 --> Model Class Initialized
INFO - 2016-07-20 18:16:15 --> Model Class Initialized
INFO - 2016-07-20 18:16:15 --> Model Class Initialized
INFO - 2016-07-20 18:16:15 --> Model Class Initialized
INFO - 2016-07-20 18:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:16:15 --> Config Class Initialized
INFO - 2016-07-20 18:16:15 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:16:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:16:16 --> Utf8 Class Initialized
INFO - 2016-07-20 18:16:16 --> URI Class Initialized
INFO - 2016-07-20 18:16:16 --> Router Class Initialized
INFO - 2016-07-20 18:16:16 --> Output Class Initialized
INFO - 2016-07-20 18:16:16 --> Security Class Initialized
DEBUG - 2016-07-20 18:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:16:16 --> Input Class Initialized
INFO - 2016-07-20 18:16:16 --> Language Class Initialized
INFO - 2016-07-20 18:16:16 --> Loader Class Initialized
INFO - 2016-07-20 18:16:16 --> Helper loaded: url_helper
INFO - 2016-07-20 18:16:16 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:16:16 --> Helper loaded: html_helper
INFO - 2016-07-20 18:16:16 --> Helper loaded: form_helper
INFO - 2016-07-20 18:16:16 --> Helper loaded: file_helper
INFO - 2016-07-20 18:16:16 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:16:16 --> Database Driver Class Initialized
INFO - 2016-07-20 18:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:16:16 --> Form Validation Class Initialized
INFO - 2016-07-20 18:16:16 --> Email Class Initialized
INFO - 2016-07-20 18:16:16 --> Controller Class Initialized
DEBUG - 2016-07-20 18:16:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:16:16 --> Model Class Initialized
INFO - 2016-07-20 18:16:16 --> Model Class Initialized
INFO - 2016-07-20 18:16:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:16:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:16:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:16:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:16:16 --> Final output sent to browser
DEBUG - 2016-07-20 18:16:16 --> Total execution time: 0.4823
INFO - 2016-07-20 18:16:27 --> Config Class Initialized
INFO - 2016-07-20 18:16:27 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:16:27 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:16:27 --> Utf8 Class Initialized
INFO - 2016-07-20 18:16:27 --> URI Class Initialized
INFO - 2016-07-20 18:16:27 --> Router Class Initialized
INFO - 2016-07-20 18:16:27 --> Output Class Initialized
INFO - 2016-07-20 18:16:27 --> Security Class Initialized
DEBUG - 2016-07-20 18:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:16:27 --> Input Class Initialized
INFO - 2016-07-20 18:16:27 --> Language Class Initialized
INFO - 2016-07-20 18:16:27 --> Loader Class Initialized
INFO - 2016-07-20 18:16:27 --> Helper loaded: url_helper
INFO - 2016-07-20 18:16:27 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:16:27 --> Helper loaded: html_helper
INFO - 2016-07-20 18:16:27 --> Helper loaded: form_helper
INFO - 2016-07-20 18:16:27 --> Helper loaded: file_helper
INFO - 2016-07-20 18:16:27 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:16:27 --> Database Driver Class Initialized
INFO - 2016-07-20 18:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:16:27 --> Form Validation Class Initialized
INFO - 2016-07-20 18:16:27 --> Email Class Initialized
INFO - 2016-07-20 18:16:27 --> Controller Class Initialized
DEBUG - 2016-07-20 18:16:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:16:27 --> Model Class Initialized
INFO - 2016-07-20 18:16:27 --> Model Class Initialized
INFO - 2016-07-20 18:16:27 --> Model Class Initialized
INFO - 2016-07-20 18:16:27 --> Model Class Initialized
INFO - 2016-07-20 18:16:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:16:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:16:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:16:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:16:27 --> Final output sent to browser
DEBUG - 2016-07-20 18:16:27 --> Total execution time: 0.5226
INFO - 2016-07-20 18:27:29 --> Config Class Initialized
INFO - 2016-07-20 18:27:29 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:27:29 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:29 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:29 --> URI Class Initialized
INFO - 2016-07-20 18:27:29 --> Router Class Initialized
INFO - 2016-07-20 18:27:29 --> Output Class Initialized
INFO - 2016-07-20 18:27:29 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:29 --> Input Class Initialized
INFO - 2016-07-20 18:27:29 --> Language Class Initialized
INFO - 2016-07-20 18:27:29 --> Loader Class Initialized
INFO - 2016-07-20 18:27:29 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:29 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:29 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:29 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:29 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:29 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:29 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:29 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:29 --> Email Class Initialized
INFO - 2016-07-20 18:27:29 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:29 --> Model Class Initialized
INFO - 2016-07-20 18:27:29 --> Model Class Initialized
INFO - 2016-07-20 18:27:29 --> Model Class Initialized
INFO - 2016-07-20 18:27:29 --> Model Class Initialized
INFO - 2016-07-20 18:27:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:27:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:27:29 --> Final output sent to browser
DEBUG - 2016-07-20 18:27:29 --> Total execution time: 0.5712
INFO - 2016-07-20 18:27:43 --> Config Class Initialized
INFO - 2016-07-20 18:27:43 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:27:43 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:43 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:43 --> URI Class Initialized
INFO - 2016-07-20 18:27:43 --> Router Class Initialized
INFO - 2016-07-20 18:27:43 --> Output Class Initialized
INFO - 2016-07-20 18:27:43 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:43 --> Input Class Initialized
INFO - 2016-07-20 18:27:43 --> Language Class Initialized
INFO - 2016-07-20 18:27:43 --> Loader Class Initialized
INFO - 2016-07-20 18:27:43 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:43 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:43 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:43 --> Email Class Initialized
INFO - 2016-07-20 18:27:43 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:43 --> Model Class Initialized
INFO - 2016-07-20 18:27:43 --> Model Class Initialized
INFO - 2016-07-20 18:27:43 --> Model Class Initialized
INFO - 2016-07-20 18:27:43 --> Model Class Initialized
INFO - 2016-07-20 18:27:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:27:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:27:43 --> Config Class Initialized
INFO - 2016-07-20 18:27:43 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:27:43 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:43 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:43 --> URI Class Initialized
INFO - 2016-07-20 18:27:43 --> Router Class Initialized
INFO - 2016-07-20 18:27:43 --> Output Class Initialized
INFO - 2016-07-20 18:27:43 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:43 --> Input Class Initialized
INFO - 2016-07-20 18:27:43 --> Language Class Initialized
INFO - 2016-07-20 18:27:43 --> Loader Class Initialized
INFO - 2016-07-20 18:27:43 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:43 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:44 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:44 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:44 --> Email Class Initialized
INFO - 2016-07-20 18:27:44 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:44 --> Config Class Initialized
INFO - 2016-07-20 18:27:44 --> Hooks Class Initialized
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
DEBUG - 2016-07-20 18:27:44 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:44 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:44 --> Final output sent to browser
DEBUG - 2016-07-20 18:27:44 --> Total execution time: 0.5033
INFO - 2016-07-20 18:27:44 --> URI Class Initialized
INFO - 2016-07-20 18:27:44 --> Router Class Initialized
INFO - 2016-07-20 18:27:44 --> Output Class Initialized
INFO - 2016-07-20 18:27:44 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:44 --> Input Class Initialized
INFO - 2016-07-20 18:27:44 --> Language Class Initialized
INFO - 2016-07-20 18:27:44 --> Loader Class Initialized
INFO - 2016-07-20 18:27:44 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:44 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:44 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:44 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:44 --> Email Class Initialized
INFO - 2016-07-20 18:27:44 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> Model Class Initialized
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:27:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:27:44 --> Config Class Initialized
INFO - 2016-07-20 18:27:44 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:27:44 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:44 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:44 --> URI Class Initialized
INFO - 2016-07-20 18:27:44 --> Router Class Initialized
INFO - 2016-07-20 18:27:45 --> Output Class Initialized
INFO - 2016-07-20 18:27:45 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:45 --> Input Class Initialized
INFO - 2016-07-20 18:27:45 --> Language Class Initialized
INFO - 2016-07-20 18:27:45 --> Loader Class Initialized
INFO - 2016-07-20 18:27:45 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:45 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:45 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:45 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:45 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:45 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:45 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:45 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:45 --> Email Class Initialized
INFO - 2016-07-20 18:27:45 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:45 --> Model Class Initialized
INFO - 2016-07-20 18:27:45 --> Model Class Initialized
INFO - 2016-07-20 18:27:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:27:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:27:45 --> Final output sent to browser
DEBUG - 2016-07-20 18:27:45 --> Total execution time: 0.5262
INFO - 2016-07-20 18:27:58 --> Config Class Initialized
INFO - 2016-07-20 18:27:59 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:27:59 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:27:59 --> Utf8 Class Initialized
INFO - 2016-07-20 18:27:59 --> URI Class Initialized
INFO - 2016-07-20 18:27:59 --> Router Class Initialized
INFO - 2016-07-20 18:27:59 --> Output Class Initialized
INFO - 2016-07-20 18:27:59 --> Security Class Initialized
DEBUG - 2016-07-20 18:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:27:59 --> Input Class Initialized
INFO - 2016-07-20 18:27:59 --> Language Class Initialized
INFO - 2016-07-20 18:27:59 --> Loader Class Initialized
INFO - 2016-07-20 18:27:59 --> Helper loaded: url_helper
INFO - 2016-07-20 18:27:59 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:27:59 --> Helper loaded: html_helper
INFO - 2016-07-20 18:27:59 --> Helper loaded: form_helper
INFO - 2016-07-20 18:27:59 --> Helper loaded: file_helper
INFO - 2016-07-20 18:27:59 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:27:59 --> Database Driver Class Initialized
INFO - 2016-07-20 18:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:27:59 --> Form Validation Class Initialized
INFO - 2016-07-20 18:27:59 --> Email Class Initialized
INFO - 2016-07-20 18:27:59 --> Controller Class Initialized
DEBUG - 2016-07-20 18:27:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:27:59 --> Model Class Initialized
INFO - 2016-07-20 18:27:59 --> Model Class Initialized
INFO - 2016-07-20 18:27:59 --> Model Class Initialized
INFO - 2016-07-20 18:27:59 --> Model Class Initialized
INFO - 2016-07-20 18:27:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:27:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:27:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:27:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:27:59 --> Final output sent to browser
DEBUG - 2016-07-20 18:27:59 --> Total execution time: 0.5452
INFO - 2016-07-20 18:28:10 --> Config Class Initialized
INFO - 2016-07-20 18:28:10 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:28:10 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:28:10 --> Utf8 Class Initialized
INFO - 2016-07-20 18:28:10 --> URI Class Initialized
INFO - 2016-07-20 18:28:10 --> Router Class Initialized
INFO - 2016-07-20 18:28:10 --> Output Class Initialized
INFO - 2016-07-20 18:28:10 --> Security Class Initialized
DEBUG - 2016-07-20 18:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:28:10 --> Input Class Initialized
INFO - 2016-07-20 18:28:10 --> Language Class Initialized
INFO - 2016-07-20 18:28:10 --> Loader Class Initialized
INFO - 2016-07-20 18:28:10 --> Helper loaded: url_helper
INFO - 2016-07-20 18:28:10 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:28:10 --> Helper loaded: html_helper
INFO - 2016-07-20 18:28:10 --> Helper loaded: form_helper
INFO - 2016-07-20 18:28:10 --> Helper loaded: file_helper
INFO - 2016-07-20 18:28:10 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:28:10 --> Database Driver Class Initialized
INFO - 2016-07-20 18:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:28:11 --> Form Validation Class Initialized
INFO - 2016-07-20 18:28:11 --> Email Class Initialized
INFO - 2016-07-20 18:28:11 --> Controller Class Initialized
DEBUG - 2016-07-20 18:28:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:28:11 --> Model Class Initialized
INFO - 2016-07-20 18:28:11 --> Model Class Initialized
INFO - 2016-07-20 18:28:11 --> Model Class Initialized
INFO - 2016-07-20 18:28:11 --> Model Class Initialized
INFO - 2016-07-20 18:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:28:20 --> Config Class Initialized
INFO - 2016-07-20 18:28:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:28:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:28:20 --> Utf8 Class Initialized
INFO - 2016-07-20 18:28:20 --> URI Class Initialized
INFO - 2016-07-20 18:28:20 --> Router Class Initialized
INFO - 2016-07-20 18:28:20 --> Output Class Initialized
INFO - 2016-07-20 18:28:20 --> Security Class Initialized
DEBUG - 2016-07-20 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:28:20 --> Input Class Initialized
INFO - 2016-07-20 18:28:20 --> Language Class Initialized
INFO - 2016-07-20 18:28:20 --> Loader Class Initialized
INFO - 2016-07-20 18:28:20 --> Helper loaded: url_helper
INFO - 2016-07-20 18:28:20 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:28:20 --> Helper loaded: html_helper
INFO - 2016-07-20 18:28:20 --> Helper loaded: form_helper
INFO - 2016-07-20 18:28:20 --> Helper loaded: file_helper
INFO - 2016-07-20 18:28:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:28:20 --> Database Driver Class Initialized
INFO - 2016-07-20 18:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:28:20 --> Form Validation Class Initialized
INFO - 2016-07-20 18:28:20 --> Email Class Initialized
INFO - 2016-07-20 18:28:20 --> Controller Class Initialized
DEBUG - 2016-07-20 18:28:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:28:20 --> Model Class Initialized
INFO - 2016-07-20 18:28:20 --> Model Class Initialized
INFO - 2016-07-20 18:28:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:28:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:28:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:28:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:28:20 --> Final output sent to browser
DEBUG - 2016-07-20 18:28:20 --> Total execution time: 0.5015
INFO - 2016-07-20 18:28:35 --> Config Class Initialized
INFO - 2016-07-20 18:28:35 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:28:35 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:28:35 --> Utf8 Class Initialized
INFO - 2016-07-20 18:28:35 --> URI Class Initialized
INFO - 2016-07-20 18:28:35 --> Router Class Initialized
INFO - 2016-07-20 18:28:35 --> Output Class Initialized
INFO - 2016-07-20 18:28:35 --> Security Class Initialized
DEBUG - 2016-07-20 18:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:28:35 --> Input Class Initialized
INFO - 2016-07-20 18:28:35 --> Language Class Initialized
INFO - 2016-07-20 18:28:35 --> Loader Class Initialized
INFO - 2016-07-20 18:28:35 --> Helper loaded: url_helper
INFO - 2016-07-20 18:28:35 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:28:35 --> Helper loaded: html_helper
INFO - 2016-07-20 18:28:35 --> Helper loaded: form_helper
INFO - 2016-07-20 18:28:35 --> Helper loaded: file_helper
INFO - 2016-07-20 18:28:35 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:28:35 --> Database Driver Class Initialized
INFO - 2016-07-20 18:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:28:35 --> Form Validation Class Initialized
INFO - 2016-07-20 18:28:35 --> Email Class Initialized
INFO - 2016-07-20 18:28:35 --> Controller Class Initialized
DEBUG - 2016-07-20 18:28:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:28:35 --> Model Class Initialized
INFO - 2016-07-20 18:28:35 --> Model Class Initialized
INFO - 2016-07-20 18:28:35 --> Model Class Initialized
INFO - 2016-07-20 18:28:35 --> Model Class Initialized
INFO - 2016-07-20 18:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:28:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:28:36 --> Final output sent to browser
DEBUG - 2016-07-20 18:28:36 --> Total execution time: 0.5467
INFO - 2016-07-20 18:39:47 --> Config Class Initialized
INFO - 2016-07-20 18:39:47 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:39:47 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:39:47 --> Utf8 Class Initialized
INFO - 2016-07-20 18:39:47 --> URI Class Initialized
INFO - 2016-07-20 18:39:47 --> Router Class Initialized
INFO - 2016-07-20 18:39:47 --> Output Class Initialized
INFO - 2016-07-20 18:39:47 --> Security Class Initialized
DEBUG - 2016-07-20 18:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:39:47 --> Input Class Initialized
INFO - 2016-07-20 18:39:47 --> Language Class Initialized
INFO - 2016-07-20 18:39:47 --> Loader Class Initialized
INFO - 2016-07-20 18:39:47 --> Helper loaded: url_helper
INFO - 2016-07-20 18:39:47 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:39:47 --> Helper loaded: html_helper
INFO - 2016-07-20 18:39:47 --> Helper loaded: form_helper
INFO - 2016-07-20 18:39:47 --> Helper loaded: file_helper
INFO - 2016-07-20 18:39:47 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:39:47 --> Database Driver Class Initialized
INFO - 2016-07-20 18:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:39:47 --> Form Validation Class Initialized
INFO - 2016-07-20 18:39:47 --> Email Class Initialized
INFO - 2016-07-20 18:39:47 --> Controller Class Initialized
DEBUG - 2016-07-20 18:39:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:39:47 --> Model Class Initialized
INFO - 2016-07-20 18:39:47 --> Model Class Initialized
INFO - 2016-07-20 18:39:47 --> Model Class Initialized
INFO - 2016-07-20 18:39:47 --> Model Class Initialized
INFO - 2016-07-20 18:39:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:39:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:39:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:39:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:39:48 --> Final output sent to browser
DEBUG - 2016-07-20 18:39:48 --> Total execution time: 0.5823
INFO - 2016-07-20 18:40:06 --> Config Class Initialized
INFO - 2016-07-20 18:40:06 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:40:06 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:40:06 --> Utf8 Class Initialized
INFO - 2016-07-20 18:40:06 --> URI Class Initialized
INFO - 2016-07-20 18:40:06 --> Router Class Initialized
INFO - 2016-07-20 18:40:06 --> Output Class Initialized
INFO - 2016-07-20 18:40:06 --> Security Class Initialized
DEBUG - 2016-07-20 18:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:40:06 --> Input Class Initialized
INFO - 2016-07-20 18:40:06 --> Language Class Initialized
INFO - 2016-07-20 18:40:06 --> Loader Class Initialized
INFO - 2016-07-20 18:40:06 --> Helper loaded: url_helper
INFO - 2016-07-20 18:40:06 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:40:06 --> Helper loaded: html_helper
INFO - 2016-07-20 18:40:06 --> Helper loaded: form_helper
INFO - 2016-07-20 18:40:06 --> Helper loaded: file_helper
INFO - 2016-07-20 18:40:06 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:40:06 --> Database Driver Class Initialized
INFO - 2016-07-20 18:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:40:06 --> Form Validation Class Initialized
INFO - 2016-07-20 18:40:06 --> Email Class Initialized
INFO - 2016-07-20 18:40:06 --> Controller Class Initialized
DEBUG - 2016-07-20 18:40:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:40:06 --> Model Class Initialized
INFO - 2016-07-20 18:40:06 --> Model Class Initialized
INFO - 2016-07-20 18:40:07 --> Model Class Initialized
INFO - 2016-07-20 18:40:07 --> Model Class Initialized
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:40:07 --> Config Class Initialized
INFO - 2016-07-20 18:40:07 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:40:07 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:40:07 --> Utf8 Class Initialized
INFO - 2016-07-20 18:40:07 --> URI Class Initialized
INFO - 2016-07-20 18:40:07 --> Router Class Initialized
INFO - 2016-07-20 18:40:07 --> Output Class Initialized
INFO - 2016-07-20 18:40:07 --> Security Class Initialized
DEBUG - 2016-07-20 18:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:40:07 --> Input Class Initialized
INFO - 2016-07-20 18:40:07 --> Language Class Initialized
INFO - 2016-07-20 18:40:07 --> Loader Class Initialized
INFO - 2016-07-20 18:40:07 --> Helper loaded: url_helper
INFO - 2016-07-20 18:40:07 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:40:07 --> Helper loaded: html_helper
INFO - 2016-07-20 18:40:07 --> Helper loaded: form_helper
INFO - 2016-07-20 18:40:07 --> Helper loaded: file_helper
INFO - 2016-07-20 18:40:07 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:40:07 --> Database Driver Class Initialized
INFO - 2016-07-20 18:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:40:07 --> Form Validation Class Initialized
INFO - 2016-07-20 18:40:07 --> Email Class Initialized
INFO - 2016-07-20 18:40:07 --> Controller Class Initialized
DEBUG - 2016-07-20 18:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:40:07 --> Model Class Initialized
INFO - 2016-07-20 18:40:07 --> Model Class Initialized
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:40:07 --> Final output sent to browser
DEBUG - 2016-07-20 18:40:07 --> Total execution time: 0.5157
INFO - 2016-07-20 18:40:16 --> Config Class Initialized
INFO - 2016-07-20 18:40:16 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:40:16 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:40:16 --> Utf8 Class Initialized
INFO - 2016-07-20 18:40:16 --> URI Class Initialized
INFO - 2016-07-20 18:40:16 --> Router Class Initialized
INFO - 2016-07-20 18:40:16 --> Output Class Initialized
INFO - 2016-07-20 18:40:16 --> Security Class Initialized
DEBUG - 2016-07-20 18:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:40:16 --> Input Class Initialized
INFO - 2016-07-20 18:40:16 --> Language Class Initialized
INFO - 2016-07-20 18:40:16 --> Loader Class Initialized
INFO - 2016-07-20 18:40:16 --> Helper loaded: url_helper
INFO - 2016-07-20 18:40:16 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:40:16 --> Helper loaded: html_helper
INFO - 2016-07-20 18:40:16 --> Helper loaded: form_helper
INFO - 2016-07-20 18:40:16 --> Helper loaded: file_helper
INFO - 2016-07-20 18:40:16 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:40:16 --> Database Driver Class Initialized
INFO - 2016-07-20 18:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:40:16 --> Form Validation Class Initialized
INFO - 2016-07-20 18:40:16 --> Email Class Initialized
INFO - 2016-07-20 18:40:16 --> Controller Class Initialized
DEBUG - 2016-07-20 18:40:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:40:16 --> Model Class Initialized
INFO - 2016-07-20 18:40:16 --> Model Class Initialized
INFO - 2016-07-20 18:40:16 --> Model Class Initialized
INFO - 2016-07-20 18:40:16 --> Model Class Initialized
INFO - 2016-07-20 18:40:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:40:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:40:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:40:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:40:16 --> Final output sent to browser
DEBUG - 2016-07-20 18:40:16 --> Total execution time: 0.5508
INFO - 2016-07-20 18:41:20 --> Config Class Initialized
INFO - 2016-07-20 18:41:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:41:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:41:20 --> Utf8 Class Initialized
INFO - 2016-07-20 18:41:20 --> URI Class Initialized
INFO - 2016-07-20 18:41:20 --> Router Class Initialized
INFO - 2016-07-20 18:41:20 --> Output Class Initialized
INFO - 2016-07-20 18:41:20 --> Security Class Initialized
DEBUG - 2016-07-20 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:41:20 --> Input Class Initialized
INFO - 2016-07-20 18:41:20 --> Language Class Initialized
INFO - 2016-07-20 18:41:20 --> Loader Class Initialized
INFO - 2016-07-20 18:41:20 --> Helper loaded: url_helper
INFO - 2016-07-20 18:41:20 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:41:20 --> Helper loaded: html_helper
INFO - 2016-07-20 18:41:20 --> Helper loaded: form_helper
INFO - 2016-07-20 18:41:20 --> Helper loaded: file_helper
INFO - 2016-07-20 18:41:20 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:41:20 --> Database Driver Class Initialized
INFO - 2016-07-20 18:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:41:20 --> Form Validation Class Initialized
INFO - 2016-07-20 18:41:20 --> Email Class Initialized
INFO - 2016-07-20 18:41:20 --> Controller Class Initialized
DEBUG - 2016-07-20 18:41:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:41:20 --> Model Class Initialized
INFO - 2016-07-20 18:41:20 --> Model Class Initialized
INFO - 2016-07-20 18:41:20 --> Model Class Initialized
INFO - 2016-07-20 18:41:20 --> Model Class Initialized
INFO - 2016-07-20 18:41:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:41:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:41:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:41:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:41:20 --> Config Class Initialized
INFO - 2016-07-20 18:41:20 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:41:20 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:41:20 --> Utf8 Class Initialized
INFO - 2016-07-20 18:41:20 --> URI Class Initialized
INFO - 2016-07-20 18:41:20 --> Router Class Initialized
INFO - 2016-07-20 18:41:20 --> Output Class Initialized
INFO - 2016-07-20 18:41:20 --> Security Class Initialized
DEBUG - 2016-07-20 18:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:41:20 --> Input Class Initialized
INFO - 2016-07-20 18:41:20 --> Language Class Initialized
INFO - 2016-07-20 18:41:20 --> Loader Class Initialized
INFO - 2016-07-20 18:41:21 --> Helper loaded: url_helper
INFO - 2016-07-20 18:41:21 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:41:21 --> Helper loaded: html_helper
INFO - 2016-07-20 18:41:21 --> Helper loaded: form_helper
INFO - 2016-07-20 18:41:21 --> Helper loaded: file_helper
INFO - 2016-07-20 18:41:21 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:41:21 --> Database Driver Class Initialized
INFO - 2016-07-20 18:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:41:21 --> Form Validation Class Initialized
INFO - 2016-07-20 18:41:21 --> Email Class Initialized
INFO - 2016-07-20 18:41:21 --> Controller Class Initialized
DEBUG - 2016-07-20 18:41:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:41:21 --> Model Class Initialized
INFO - 2016-07-20 18:41:21 --> Model Class Initialized
INFO - 2016-07-20 18:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:41:21 --> Final output sent to browser
DEBUG - 2016-07-20 18:41:21 --> Total execution time: 0.5117
INFO - 2016-07-20 18:41:38 --> Config Class Initialized
INFO - 2016-07-20 18:41:38 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:41:38 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:41:38 --> Utf8 Class Initialized
INFO - 2016-07-20 18:41:38 --> URI Class Initialized
INFO - 2016-07-20 18:41:38 --> Router Class Initialized
INFO - 2016-07-20 18:41:38 --> Output Class Initialized
INFO - 2016-07-20 18:41:38 --> Security Class Initialized
DEBUG - 2016-07-20 18:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:41:38 --> Input Class Initialized
INFO - 2016-07-20 18:41:38 --> Language Class Initialized
INFO - 2016-07-20 18:41:38 --> Loader Class Initialized
INFO - 2016-07-20 18:41:38 --> Helper loaded: url_helper
INFO - 2016-07-20 18:41:38 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:41:38 --> Helper loaded: html_helper
INFO - 2016-07-20 18:41:38 --> Helper loaded: form_helper
INFO - 2016-07-20 18:41:38 --> Helper loaded: file_helper
INFO - 2016-07-20 18:41:38 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:41:38 --> Database Driver Class Initialized
INFO - 2016-07-20 18:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:41:38 --> Form Validation Class Initialized
INFO - 2016-07-20 18:41:38 --> Email Class Initialized
INFO - 2016-07-20 18:41:38 --> Controller Class Initialized
DEBUG - 2016-07-20 18:41:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:41:38 --> Model Class Initialized
INFO - 2016-07-20 18:41:38 --> Model Class Initialized
INFO - 2016-07-20 18:41:38 --> Model Class Initialized
INFO - 2016-07-20 18:41:38 --> Model Class Initialized
INFO - 2016-07-20 18:41:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:41:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:41:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:41:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:41:38 --> Final output sent to browser
DEBUG - 2016-07-20 18:41:38 --> Total execution time: 0.5382
INFO - 2016-07-20 18:43:32 --> Config Class Initialized
INFO - 2016-07-20 18:43:32 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:43:32 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:43:32 --> Utf8 Class Initialized
INFO - 2016-07-20 18:43:32 --> URI Class Initialized
INFO - 2016-07-20 18:43:33 --> Router Class Initialized
INFO - 2016-07-20 18:43:33 --> Output Class Initialized
INFO - 2016-07-20 18:43:33 --> Security Class Initialized
DEBUG - 2016-07-20 18:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:43:33 --> Input Class Initialized
INFO - 2016-07-20 18:43:33 --> Language Class Initialized
INFO - 2016-07-20 18:43:33 --> Loader Class Initialized
INFO - 2016-07-20 18:43:33 --> Helper loaded: url_helper
INFO - 2016-07-20 18:43:33 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:43:33 --> Helper loaded: html_helper
INFO - 2016-07-20 18:43:33 --> Helper loaded: form_helper
INFO - 2016-07-20 18:43:33 --> Helper loaded: file_helper
INFO - 2016-07-20 18:43:33 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:43:33 --> Database Driver Class Initialized
INFO - 2016-07-20 18:43:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:43:33 --> Form Validation Class Initialized
INFO - 2016-07-20 18:43:33 --> Email Class Initialized
INFO - 2016-07-20 18:43:33 --> Controller Class Initialized
DEBUG - 2016-07-20 18:43:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:43:33 --> Model Class Initialized
INFO - 2016-07-20 18:43:33 --> Model Class Initialized
INFO - 2016-07-20 18:43:33 --> Model Class Initialized
INFO - 2016-07-20 18:43:33 --> Model Class Initialized
INFO - 2016-07-20 18:43:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:43:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:43:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:43:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:43:41 --> Config Class Initialized
INFO - 2016-07-20 18:43:41 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:43:41 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:43:41 --> Utf8 Class Initialized
INFO - 2016-07-20 18:43:41 --> URI Class Initialized
INFO - 2016-07-20 18:43:41 --> Router Class Initialized
INFO - 2016-07-20 18:43:41 --> Output Class Initialized
INFO - 2016-07-20 18:43:41 --> Security Class Initialized
DEBUG - 2016-07-20 18:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:43:41 --> Input Class Initialized
INFO - 2016-07-20 18:43:41 --> Language Class Initialized
INFO - 2016-07-20 18:43:41 --> Loader Class Initialized
INFO - 2016-07-20 18:43:41 --> Helper loaded: url_helper
INFO - 2016-07-20 18:43:42 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:43:42 --> Helper loaded: html_helper
INFO - 2016-07-20 18:43:42 --> Helper loaded: form_helper
INFO - 2016-07-20 18:43:42 --> Helper loaded: file_helper
INFO - 2016-07-20 18:43:42 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:43:42 --> Database Driver Class Initialized
INFO - 2016-07-20 18:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:43:42 --> Form Validation Class Initialized
INFO - 2016-07-20 18:43:42 --> Email Class Initialized
INFO - 2016-07-20 18:43:42 --> Controller Class Initialized
DEBUG - 2016-07-20 18:43:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:43:42 --> Model Class Initialized
INFO - 2016-07-20 18:43:42 --> Model Class Initialized
INFO - 2016-07-20 18:43:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:43:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:43:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-07-20 18:43:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:43:42 --> Final output sent to browser
DEBUG - 2016-07-20 18:43:42 --> Total execution time: 0.5170
INFO - 2016-07-20 18:44:11 --> Config Class Initialized
INFO - 2016-07-20 18:44:11 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:44:11 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:44:11 --> Utf8 Class Initialized
INFO - 2016-07-20 18:44:11 --> URI Class Initialized
INFO - 2016-07-20 18:44:11 --> Router Class Initialized
INFO - 2016-07-20 18:44:11 --> Output Class Initialized
INFO - 2016-07-20 18:44:11 --> Security Class Initialized
DEBUG - 2016-07-20 18:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:44:11 --> Input Class Initialized
INFO - 2016-07-20 18:44:11 --> Language Class Initialized
INFO - 2016-07-20 18:44:11 --> Loader Class Initialized
INFO - 2016-07-20 18:44:11 --> Helper loaded: url_helper
INFO - 2016-07-20 18:44:11 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:44:11 --> Helper loaded: html_helper
INFO - 2016-07-20 18:44:11 --> Helper loaded: form_helper
INFO - 2016-07-20 18:44:11 --> Helper loaded: file_helper
INFO - 2016-07-20 18:44:11 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:44:11 --> Database Driver Class Initialized
INFO - 2016-07-20 18:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:44:11 --> Form Validation Class Initialized
INFO - 2016-07-20 18:44:11 --> Email Class Initialized
INFO - 2016-07-20 18:44:11 --> Controller Class Initialized
DEBUG - 2016-07-20 18:44:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:44:11 --> Model Class Initialized
INFO - 2016-07-20 18:44:11 --> Model Class Initialized
INFO - 2016-07-20 18:44:11 --> Model Class Initialized
INFO - 2016-07-20 18:44:11 --> Model Class Initialized
INFO - 2016-07-20 18:44:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:44:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:44:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-20 18:44:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:44:11 --> Final output sent to browser
DEBUG - 2016-07-20 18:44:11 --> Total execution time: 0.5575
INFO - 2016-07-20 18:48:03 --> Config Class Initialized
INFO - 2016-07-20 18:48:03 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:48:03 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:48:03 --> Utf8 Class Initialized
INFO - 2016-07-20 18:48:03 --> URI Class Initialized
INFO - 2016-07-20 18:48:03 --> Router Class Initialized
INFO - 2016-07-20 18:48:03 --> Output Class Initialized
INFO - 2016-07-20 18:48:03 --> Security Class Initialized
DEBUG - 2016-07-20 18:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:48:03 --> Input Class Initialized
INFO - 2016-07-20 18:48:03 --> Language Class Initialized
INFO - 2016-07-20 18:48:03 --> Loader Class Initialized
INFO - 2016-07-20 18:48:03 --> Helper loaded: url_helper
INFO - 2016-07-20 18:48:03 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:48:03 --> Helper loaded: html_helper
INFO - 2016-07-20 18:48:03 --> Helper loaded: form_helper
INFO - 2016-07-20 18:48:03 --> Helper loaded: file_helper
INFO - 2016-07-20 18:48:03 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:48:03 --> Database Driver Class Initialized
INFO - 2016-07-20 18:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:48:03 --> Form Validation Class Initialized
INFO - 2016-07-20 18:48:03 --> Email Class Initialized
INFO - 2016-07-20 18:48:03 --> Controller Class Initialized
DEBUG - 2016-07-20 18:48:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:48:03 --> Model Class Initialized
INFO - 2016-07-20 18:48:03 --> Model Class Initialized
INFO - 2016-07-20 18:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-20 18:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-20 18:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-20 18:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-20 18:48:03 --> Final output sent to browser
DEBUG - 2016-07-20 18:48:03 --> Total execution time: 0.5452
INFO - 2016-07-20 18:48:13 --> Config Class Initialized
INFO - 2016-07-20 18:48:13 --> Hooks Class Initialized
DEBUG - 2016-07-20 18:48:13 --> UTF-8 Support Enabled
INFO - 2016-07-20 18:48:13 --> Utf8 Class Initialized
INFO - 2016-07-20 18:48:13 --> URI Class Initialized
INFO - 2016-07-20 18:48:13 --> Router Class Initialized
INFO - 2016-07-20 18:48:13 --> Output Class Initialized
INFO - 2016-07-20 18:48:13 --> Security Class Initialized
DEBUG - 2016-07-20 18:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-20 18:48:13 --> Input Class Initialized
INFO - 2016-07-20 18:48:13 --> Language Class Initialized
INFO - 2016-07-20 18:48:13 --> Loader Class Initialized
INFO - 2016-07-20 18:48:13 --> Helper loaded: url_helper
INFO - 2016-07-20 18:48:13 --> Helper loaded: utils_helper
INFO - 2016-07-20 18:48:13 --> Helper loaded: html_helper
INFO - 2016-07-20 18:48:13 --> Helper loaded: form_helper
INFO - 2016-07-20 18:48:13 --> Helper loaded: file_helper
INFO - 2016-07-20 18:48:13 --> Helper loaded: myemail_helper
INFO - 2016-07-20 18:48:13 --> Database Driver Class Initialized
INFO - 2016-07-20 18:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-20 18:48:13 --> Form Validation Class Initialized
INFO - 2016-07-20 18:48:13 --> Email Class Initialized
INFO - 2016-07-20 18:48:13 --> Controller Class Initialized
DEBUG - 2016-07-20 18:48:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-20 18:48:13 --> Model Class Initialized
INFO - 2016-07-20 18:48:13 --> Model Class Initialized
INFO - 2016-07-20 18:48:13 --> Final output sent to browser
DEBUG - 2016-07-20 18:48:13 --> Total execution time: 0.7015
