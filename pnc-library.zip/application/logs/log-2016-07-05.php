<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-05 18:08:56 --> Config Class Initialized
INFO - 2016-07-05 18:08:56 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:08:56 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:08:56 --> Utf8 Class Initialized
INFO - 2016-07-05 18:08:56 --> URI Class Initialized
INFO - 2016-07-05 18:08:56 --> Router Class Initialized
INFO - 2016-07-05 18:08:56 --> Output Class Initialized
INFO - 2016-07-05 18:08:56 --> Security Class Initialized
DEBUG - 2016-07-05 18:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:08:56 --> Input Class Initialized
INFO - 2016-07-05 18:08:56 --> Language Class Initialized
INFO - 2016-07-05 18:08:56 --> Loader Class Initialized
INFO - 2016-07-05 18:08:56 --> Helper loaded: url_helper
INFO - 2016-07-05 18:08:56 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:08:56 --> Helper loaded: html_helper
INFO - 2016-07-05 18:08:56 --> Helper loaded: form_helper
INFO - 2016-07-05 18:08:56 --> Helper loaded: file_helper
INFO - 2016-07-05 18:08:56 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:08:56 --> Database Driver Class Initialized
INFO - 2016-07-05 18:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:08:56 --> Form Validation Class Initialized
INFO - 2016-07-05 18:08:56 --> Email Class Initialized
INFO - 2016-07-05 18:08:56 --> Controller Class Initialized
INFO - 2016-07-05 18:08:56 --> Model Class Initialized
INFO - 2016-07-05 18:08:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:08:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:08:56 --> File loaded: D:\wamp\www\pnc-library\application\views\users/index.php
INFO - 2016-07-05 18:08:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:08:56 --> Final output sent to browser
DEBUG - 2016-07-05 18:08:56 --> Total execution time: 0.2313
INFO - 2016-07-05 18:09:05 --> Config Class Initialized
INFO - 2016-07-05 18:09:05 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:05 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:05 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:05 --> URI Class Initialized
DEBUG - 2016-07-05 18:09:05 --> No URI present. Default controller set.
INFO - 2016-07-05 18:09:05 --> Router Class Initialized
INFO - 2016-07-05 18:09:05 --> Output Class Initialized
INFO - 2016-07-05 18:09:05 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:05 --> Input Class Initialized
INFO - 2016-07-05 18:09:05 --> Language Class Initialized
INFO - 2016-07-05 18:09:05 --> Loader Class Initialized
INFO - 2016-07-05 18:09:05 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:05 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:05 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:05 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:05 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:05 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:05 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:05 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:05 --> Email Class Initialized
INFO - 2016-07-05 18:09:05 --> Controller Class Initialized
INFO - 2016-07-05 18:09:05 --> Model Class Initialized
INFO - 2016-07-05 18:09:05 --> Model Class Initialized
INFO - 2016-07-05 18:09:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:05 --> File loaded: D:\wamp\www\pnc-library\application\views\account/index.php
INFO - 2016-07-05 18:09:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:05 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:05 --> Total execution time: 0.2532
INFO - 2016-07-05 18:09:07 --> Config Class Initialized
INFO - 2016-07-05 18:09:07 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:08 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:08 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:08 --> URI Class Initialized
INFO - 2016-07-05 18:09:08 --> Router Class Initialized
INFO - 2016-07-05 18:09:08 --> Output Class Initialized
INFO - 2016-07-05 18:09:08 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:08 --> Input Class Initialized
INFO - 2016-07-05 18:09:08 --> Language Class Initialized
INFO - 2016-07-05 18:09:08 --> Loader Class Initialized
INFO - 2016-07-05 18:09:08 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:08 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:08 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:08 --> Email Class Initialized
INFO - 2016-07-05 18:09:08 --> Controller Class Initialized
INFO - 2016-07-05 18:09:08 --> Model Class Initialized
INFO - 2016-07-05 18:09:08 --> Config Class Initialized
INFO - 2016-07-05 18:09:08 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:08 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:08 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:08 --> URI Class Initialized
INFO - 2016-07-05 18:09:08 --> Router Class Initialized
INFO - 2016-07-05 18:09:08 --> Output Class Initialized
INFO - 2016-07-05 18:09:08 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:08 --> Input Class Initialized
INFO - 2016-07-05 18:09:08 --> Language Class Initialized
INFO - 2016-07-05 18:09:08 --> Loader Class Initialized
INFO - 2016-07-05 18:09:08 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:08 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:08 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:08 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:08 --> Email Class Initialized
INFO - 2016-07-05 18:09:08 --> Controller Class Initialized
INFO - 2016-07-05 18:09:08 --> Model Class Initialized
DEBUG - 2016-07-05 18:09:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-05 18:09:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:08 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-05 18:09:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:08 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:08 --> Total execution time: 0.1868
INFO - 2016-07-05 18:09:10 --> Config Class Initialized
INFO - 2016-07-05 18:09:10 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:10 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:10 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:10 --> URI Class Initialized
INFO - 2016-07-05 18:09:10 --> Router Class Initialized
INFO - 2016-07-05 18:09:10 --> Output Class Initialized
INFO - 2016-07-05 18:09:10 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:10 --> Input Class Initialized
INFO - 2016-07-05 18:09:10 --> Language Class Initialized
INFO - 2016-07-05 18:09:10 --> Loader Class Initialized
INFO - 2016-07-05 18:09:10 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:10 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:10 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:10 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:10 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:10 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:10 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:10 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:10 --> Email Class Initialized
INFO - 2016-07-05 18:09:10 --> Controller Class Initialized
INFO - 2016-07-05 18:09:10 --> Model Class Initialized
DEBUG - 2016-07-05 18:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:10 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-07-05 18:09:10 --> {controllers/session/login} Invalid login id or password for user=bpitet
INFO - 2016-07-05 18:09:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/flash-connection.php
INFO - 2016-07-05 18:09:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:10 --> File loaded: D:\wamp\www\pnc-library\application\views\connection/login.php
INFO - 2016-07-05 18:09:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:10 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:10 --> Total execution time: 0.2409
INFO - 2016-07-05 18:09:13 --> Config Class Initialized
INFO - 2016-07-05 18:09:13 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:13 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:13 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:13 --> URI Class Initialized
INFO - 2016-07-05 18:09:13 --> Router Class Initialized
INFO - 2016-07-05 18:09:13 --> Output Class Initialized
INFO - 2016-07-05 18:09:13 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:14 --> Input Class Initialized
INFO - 2016-07-05 18:09:14 --> Language Class Initialized
INFO - 2016-07-05 18:09:14 --> Loader Class Initialized
INFO - 2016-07-05 18:09:14 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:14 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:14 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:14 --> Email Class Initialized
INFO - 2016-07-05 18:09:14 --> Controller Class Initialized
INFO - 2016-07-05 18:09:14 --> Model Class Initialized
DEBUG - 2016-07-05 18:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-05 18:09:14 --> Config Class Initialized
INFO - 2016-07-05 18:09:14 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:14 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:14 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:14 --> URI Class Initialized
INFO - 2016-07-05 18:09:14 --> Router Class Initialized
INFO - 2016-07-05 18:09:14 --> Output Class Initialized
INFO - 2016-07-05 18:09:14 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:14 --> Input Class Initialized
INFO - 2016-07-05 18:09:14 --> Language Class Initialized
INFO - 2016-07-05 18:09:14 --> Loader Class Initialized
INFO - 2016-07-05 18:09:14 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:14 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:14 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:14 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:14 --> Email Class Initialized
INFO - 2016-07-05 18:09:14 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:14 --> Model Class Initialized
INFO - 2016-07-05 18:09:14 --> Model Class Initialized
INFO - 2016-07-05 18:09:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:14 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:09:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:14 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:14 --> Total execution time: 0.3931
INFO - 2016-07-05 18:09:40 --> Config Class Initialized
INFO - 2016-07-05 18:09:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:40 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:40 --> URI Class Initialized
INFO - 2016-07-05 18:09:40 --> Router Class Initialized
INFO - 2016-07-05 18:09:40 --> Output Class Initialized
INFO - 2016-07-05 18:09:40 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:40 --> Input Class Initialized
INFO - 2016-07-05 18:09:40 --> Language Class Initialized
INFO - 2016-07-05 18:09:40 --> Loader Class Initialized
INFO - 2016-07-05 18:09:40 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:40 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:40 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:40 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:40 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:40 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:40 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:40 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:40 --> Email Class Initialized
INFO - 2016-07-05 18:09:40 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:40 --> Model Class Initialized
INFO - 2016-07-05 18:09:40 --> Model Class Initialized
INFO - 2016-07-05 18:09:40 --> Model Class Initialized
INFO - 2016-07-05 18:09:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:40 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/all_books.php
INFO - 2016-07-05 18:09:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:40 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:40 --> Total execution time: 0.2245
INFO - 2016-07-05 18:09:44 --> Config Class Initialized
INFO - 2016-07-05 18:09:44 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:44 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:44 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:44 --> URI Class Initialized
INFO - 2016-07-05 18:09:44 --> Router Class Initialized
INFO - 2016-07-05 18:09:44 --> Output Class Initialized
INFO - 2016-07-05 18:09:44 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:44 --> Input Class Initialized
INFO - 2016-07-05 18:09:44 --> Language Class Initialized
INFO - 2016-07-05 18:09:44 --> Loader Class Initialized
INFO - 2016-07-05 18:09:44 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:44 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:44 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:44 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:44 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:44 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:44 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:44 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:44 --> Email Class Initialized
INFO - 2016-07-05 18:09:44 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:44 --> Model Class Initialized
INFO - 2016-07-05 18:09:44 --> Model Class Initialized
INFO - 2016-07-05 18:09:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:44 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:09:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:44 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:44 --> Total execution time: 0.2943
INFO - 2016-07-05 18:09:47 --> Config Class Initialized
INFO - 2016-07-05 18:09:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:47 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:47 --> URI Class Initialized
INFO - 2016-07-05 18:09:47 --> Router Class Initialized
INFO - 2016-07-05 18:09:47 --> Output Class Initialized
INFO - 2016-07-05 18:09:47 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:47 --> Input Class Initialized
INFO - 2016-07-05 18:09:47 --> Language Class Initialized
INFO - 2016-07-05 18:09:47 --> Loader Class Initialized
INFO - 2016-07-05 18:09:47 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:47 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:47 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:47 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:47 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:47 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:47 --> Email Class Initialized
INFO - 2016-07-05 18:09:47 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:47 --> Model Class Initialized
INFO - 2016-07-05 18:09:47 --> Model Class Initialized
INFO - 2016-07-05 18:09:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:47 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/users.php
INFO - 2016-07-05 18:09:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:47 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:47 --> Total execution time: 0.2607
INFO - 2016-07-05 18:09:50 --> Config Class Initialized
INFO - 2016-07-05 18:09:50 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:50 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:50 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:50 --> URI Class Initialized
INFO - 2016-07-05 18:09:50 --> Router Class Initialized
INFO - 2016-07-05 18:09:50 --> Output Class Initialized
INFO - 2016-07-05 18:09:50 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:51 --> Input Class Initialized
INFO - 2016-07-05 18:09:51 --> Language Class Initialized
INFO - 2016-07-05 18:09:51 --> Loader Class Initialized
INFO - 2016-07-05 18:09:51 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:51 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:51 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:51 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:51 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:51 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:51 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:51 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:51 --> Email Class Initialized
INFO - 2016-07-05 18:09:51 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:51 --> Model Class Initialized
INFO - 2016-07-05 18:09:51 --> Model Class Initialized
INFO - 2016-07-05 18:09:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:51 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:09:51 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:51 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:51 --> Total execution time: 0.2937
INFO - 2016-07-05 18:09:53 --> Config Class Initialized
INFO - 2016-07-05 18:09:53 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:53 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:53 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:53 --> URI Class Initialized
INFO - 2016-07-05 18:09:53 --> Router Class Initialized
INFO - 2016-07-05 18:09:53 --> Output Class Initialized
INFO - 2016-07-05 18:09:53 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:53 --> Input Class Initialized
INFO - 2016-07-05 18:09:53 --> Language Class Initialized
INFO - 2016-07-05 18:09:53 --> Loader Class Initialized
INFO - 2016-07-05 18:09:53 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:53 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:53 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:53 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:53 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:53 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:53 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:53 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:53 --> Email Class Initialized
INFO - 2016-07-05 18:09:53 --> Controller Class Initialized
DEBUG - 2016-07-05 18:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:09:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:09:53 --> Model Class Initialized
INFO - 2016-07-05 18:09:53 --> Model Class Initialized
INFO - 2016-07-05 18:09:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:53 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/borrowing.php
INFO - 2016-07-05 18:09:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:53 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:53 --> Total execution time: 0.2749
INFO - 2016-07-05 18:09:57 --> Config Class Initialized
INFO - 2016-07-05 18:09:57 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:57 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:57 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:57 --> URI Class Initialized
INFO - 2016-07-05 18:09:57 --> Router Class Initialized
INFO - 2016-07-05 18:09:57 --> Output Class Initialized
INFO - 2016-07-05 18:09:57 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:57 --> Input Class Initialized
INFO - 2016-07-05 18:09:57 --> Language Class Initialized
INFO - 2016-07-05 18:09:57 --> Loader Class Initialized
INFO - 2016-07-05 18:09:57 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:57 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:57 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:57 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:57 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:57 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:57 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:57 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:57 --> Email Class Initialized
INFO - 2016-07-05 18:09:57 --> Controller Class Initialized
INFO - 2016-07-05 18:09:57 --> Model Class Initialized
INFO - 2016-07-05 18:09:57 --> Model Class Initialized
INFO - 2016-07-05 18:09:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:57 --> File loaded: D:\wamp\www\pnc-library\application\views\search/searchpage.php
INFO - 2016-07-05 18:09:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:57 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:57 --> Total execution time: 0.2122
INFO - 2016-07-05 18:09:59 --> Config Class Initialized
INFO - 2016-07-05 18:09:59 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:09:59 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:09:59 --> Utf8 Class Initialized
INFO - 2016-07-05 18:09:59 --> URI Class Initialized
INFO - 2016-07-05 18:09:59 --> Router Class Initialized
INFO - 2016-07-05 18:09:59 --> Output Class Initialized
INFO - 2016-07-05 18:09:59 --> Security Class Initialized
DEBUG - 2016-07-05 18:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:09:59 --> Input Class Initialized
INFO - 2016-07-05 18:09:59 --> Language Class Initialized
INFO - 2016-07-05 18:09:59 --> Loader Class Initialized
INFO - 2016-07-05 18:09:59 --> Helper loaded: url_helper
INFO - 2016-07-05 18:09:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:09:59 --> Helper loaded: html_helper
INFO - 2016-07-05 18:09:59 --> Helper loaded: form_helper
INFO - 2016-07-05 18:09:59 --> Helper loaded: file_helper
INFO - 2016-07-05 18:09:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:09:59 --> Database Driver Class Initialized
INFO - 2016-07-05 18:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:09:59 --> Form Validation Class Initialized
INFO - 2016-07-05 18:09:59 --> Email Class Initialized
INFO - 2016-07-05 18:09:59 --> Controller Class Initialized
INFO - 2016-07-05 18:09:59 --> Model Class Initialized
INFO - 2016-07-05 18:09:59 --> Model Class Initialized
INFO - 2016-07-05 18:09:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:09:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:09:59 --> File loaded: D:\wamp\www\pnc-library\application\views\account/acount_state.php
INFO - 2016-07-05 18:09:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:09:59 --> Final output sent to browser
DEBUG - 2016-07-05 18:09:59 --> Total execution time: 0.2925
INFO - 2016-07-05 18:10:00 --> Config Class Initialized
INFO - 2016-07-05 18:10:00 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:00 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:00 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:00 --> URI Class Initialized
INFO - 2016-07-05 18:10:00 --> Router Class Initialized
INFO - 2016-07-05 18:10:00 --> Output Class Initialized
INFO - 2016-07-05 18:10:00 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:00 --> Input Class Initialized
INFO - 2016-07-05 18:10:00 --> Language Class Initialized
INFO - 2016-07-05 18:10:00 --> Loader Class Initialized
INFO - 2016-07-05 18:10:00 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:00 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:00 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:00 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:00 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:00 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:00 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:00 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:01 --> Email Class Initialized
INFO - 2016-07-05 18:10:01 --> Controller Class Initialized
INFO - 2016-07-05 18:10:01 --> Model Class Initialized
INFO - 2016-07-05 18:10:01 --> Model Class Initialized
INFO - 2016-07-05 18:10:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:01 --> File loaded: D:\wamp\www\pnc-library\application\views\books/book_request.php
INFO - 2016-07-05 18:10:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:01 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:01 --> Total execution time: 0.2521
INFO - 2016-07-05 18:10:02 --> Config Class Initialized
INFO - 2016-07-05 18:10:02 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:02 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:02 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:02 --> URI Class Initialized
INFO - 2016-07-05 18:10:02 --> Router Class Initialized
INFO - 2016-07-05 18:10:02 --> Output Class Initialized
INFO - 2016-07-05 18:10:02 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:02 --> Input Class Initialized
INFO - 2016-07-05 18:10:02 --> Language Class Initialized
INFO - 2016-07-05 18:10:02 --> Loader Class Initialized
INFO - 2016-07-05 18:10:02 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:02 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:02 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:02 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:02 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:02 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:02 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:02 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:02 --> Email Class Initialized
INFO - 2016-07-05 18:10:02 --> Controller Class Initialized
DEBUG - 2016-07-05 18:10:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:10:02 --> Model Class Initialized
INFO - 2016-07-05 18:10:02 --> Model Class Initialized
INFO - 2016-07-05 18:10:02 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:02 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:02 --> File loaded: D:\wamp\www\pnc-library\application\views\books/borrow.php
INFO - 2016-07-05 18:10:02 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:02 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:02 --> Total execution time: 0.2478
INFO - 2016-07-05 18:10:04 --> Config Class Initialized
INFO - 2016-07-05 18:10:04 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:04 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:04 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:04 --> URI Class Initialized
INFO - 2016-07-05 18:10:04 --> Router Class Initialized
INFO - 2016-07-05 18:10:04 --> Output Class Initialized
INFO - 2016-07-05 18:10:04 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:04 --> Input Class Initialized
INFO - 2016-07-05 18:10:04 --> Language Class Initialized
INFO - 2016-07-05 18:10:04 --> Loader Class Initialized
INFO - 2016-07-05 18:10:04 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:04 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:04 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:04 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:04 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:04 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:04 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:04 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:04 --> Email Class Initialized
INFO - 2016-07-05 18:10:04 --> Controller Class Initialized
DEBUG - 2016-07-05 18:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:10:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:10:04 --> Model Class Initialized
INFO - 2016-07-05 18:10:04 --> Model Class Initialized
INFO - 2016-07-05 18:10:04 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:04 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:04 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:10:04 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:04 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:04 --> Total execution time: 0.3014
INFO - 2016-07-05 18:10:49 --> Config Class Initialized
INFO - 2016-07-05 18:10:49 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:49 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:49 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:49 --> URI Class Initialized
INFO - 2016-07-05 18:10:49 --> Router Class Initialized
INFO - 2016-07-05 18:10:49 --> Output Class Initialized
INFO - 2016-07-05 18:10:49 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:49 --> Input Class Initialized
INFO - 2016-07-05 18:10:49 --> Language Class Initialized
INFO - 2016-07-05 18:10:49 --> Loader Class Initialized
INFO - 2016-07-05 18:10:50 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:50 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:50 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:50 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:50 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:50 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:50 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:50 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:50 --> Email Class Initialized
INFO - 2016-07-05 18:10:50 --> Controller Class Initialized
DEBUG - 2016-07-05 18:10:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:10:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:50 --> Model Class Initialized
INFO - 2016-07-05 18:10:50 --> Model Class Initialized
INFO - 2016-07-05 18:10:50 --> File loaded: D:\wamp\www\pnc-library\application\views\books/list_books.php
INFO - 2016-07-05 18:10:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:50 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:50 --> Total execution time: 0.2318
INFO - 2016-07-05 18:10:56 --> Config Class Initialized
INFO - 2016-07-05 18:10:56 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:56 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:56 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:56 --> URI Class Initialized
INFO - 2016-07-05 18:10:56 --> Router Class Initialized
INFO - 2016-07-05 18:10:56 --> Output Class Initialized
INFO - 2016-07-05 18:10:56 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:56 --> Input Class Initialized
INFO - 2016-07-05 18:10:56 --> Language Class Initialized
INFO - 2016-07-05 18:10:56 --> Loader Class Initialized
INFO - 2016-07-05 18:10:56 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:56 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:56 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:56 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:56 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:56 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:56 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:56 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:56 --> Email Class Initialized
INFO - 2016-07-05 18:10:56 --> Controller Class Initialized
DEBUG - 2016-07-05 18:10:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:10:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:56 --> Model Class Initialized
INFO - 2016-07-05 18:10:56 --> Model Class Initialized
INFO - 2016-07-05 18:10:56 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-05 18:10:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:56 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:56 --> Total execution time: 0.2328
INFO - 2016-07-05 18:10:58 --> Config Class Initialized
INFO - 2016-07-05 18:10:58 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:10:58 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:10:58 --> Utf8 Class Initialized
INFO - 2016-07-05 18:10:58 --> URI Class Initialized
INFO - 2016-07-05 18:10:58 --> Router Class Initialized
INFO - 2016-07-05 18:10:58 --> Output Class Initialized
INFO - 2016-07-05 18:10:58 --> Security Class Initialized
DEBUG - 2016-07-05 18:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:10:58 --> Input Class Initialized
INFO - 2016-07-05 18:10:58 --> Language Class Initialized
INFO - 2016-07-05 18:10:59 --> Loader Class Initialized
INFO - 2016-07-05 18:10:59 --> Helper loaded: url_helper
INFO - 2016-07-05 18:10:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:10:59 --> Helper loaded: html_helper
INFO - 2016-07-05 18:10:59 --> Helper loaded: form_helper
INFO - 2016-07-05 18:10:59 --> Helper loaded: file_helper
INFO - 2016-07-05 18:10:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:10:59 --> Database Driver Class Initialized
INFO - 2016-07-05 18:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:10:59 --> Form Validation Class Initialized
INFO - 2016-07-05 18:10:59 --> Email Class Initialized
INFO - 2016-07-05 18:10:59 --> Controller Class Initialized
DEBUG - 2016-07-05 18:10:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:10:59 --> Model Class Initialized
INFO - 2016-07-05 18:10:59 --> Model Class Initialized
INFO - 2016-07-05 18:10:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:10:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:10:59 --> Model Class Initialized
INFO - 2016-07-05 18:10:59 --> File loaded: D:\wamp\www\pnc-library\application\views\books/add.php
INFO - 2016-07-05 18:10:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:10:59 --> Final output sent to browser
DEBUG - 2016-07-05 18:10:59 --> Total execution time: 0.2463
INFO - 2016-07-05 18:37:42 --> Config Class Initialized
INFO - 2016-07-05 18:37:42 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:37:42 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:37:42 --> Utf8 Class Initialized
INFO - 2016-07-05 18:37:42 --> URI Class Initialized
INFO - 2016-07-05 18:37:42 --> Router Class Initialized
INFO - 2016-07-05 18:37:42 --> Output Class Initialized
INFO - 2016-07-05 18:37:42 --> Security Class Initialized
DEBUG - 2016-07-05 18:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:37:42 --> Input Class Initialized
INFO - 2016-07-05 18:37:42 --> Language Class Initialized
INFO - 2016-07-05 18:37:42 --> Loader Class Initialized
INFO - 2016-07-05 18:37:42 --> Helper loaded: url_helper
INFO - 2016-07-05 18:37:42 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:37:42 --> Helper loaded: html_helper
INFO - 2016-07-05 18:37:42 --> Helper loaded: form_helper
INFO - 2016-07-05 18:37:42 --> Helper loaded: file_helper
INFO - 2016-07-05 18:37:42 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:37:42 --> Database Driver Class Initialized
INFO - 2016-07-05 18:37:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:37:42 --> Form Validation Class Initialized
INFO - 2016-07-05 18:37:42 --> Email Class Initialized
INFO - 2016-07-05 18:37:42 --> Controller Class Initialized
DEBUG - 2016-07-05 18:37:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:37:42 --> Model Class Initialized
INFO - 2016-07-05 18:37:42 --> Model Class Initialized
INFO - 2016-07-05 18:37:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:37:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
ERROR - 2016-07-05 18:37:42 --> Severity: Notice --> Undefined variable: condition D:\wamp\www\pnc-library\application\views\books\import_book.php 60
ERROR - 2016-07-05 18:37:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 60
ERROR - 2016-07-05 18:37:42 --> Severity: Notice --> Undefined variable: cate_label D:\wamp\www\pnc-library\application\views\books\import_book.php 85
ERROR - 2016-07-05 18:37:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 85
ERROR - 2016-07-05 18:37:42 --> Severity: Notice --> Undefined variable: status D:\wamp\www\pnc-library\application\views\books\import_book.php 112
ERROR - 2016-07-05 18:37:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 112
INFO - 2016-07-05 18:37:42 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:37:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:37:42 --> Final output sent to browser
DEBUG - 2016-07-05 18:37:42 --> Total execution time: 0.2762
INFO - 2016-07-05 18:38:38 --> Config Class Initialized
INFO - 2016-07-05 18:38:38 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:38:38 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:38:38 --> Utf8 Class Initialized
INFO - 2016-07-05 18:38:38 --> URI Class Initialized
INFO - 2016-07-05 18:38:38 --> Router Class Initialized
INFO - 2016-07-05 18:38:38 --> Output Class Initialized
INFO - 2016-07-05 18:38:38 --> Security Class Initialized
DEBUG - 2016-07-05 18:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:38:38 --> Input Class Initialized
INFO - 2016-07-05 18:38:38 --> Language Class Initialized
INFO - 2016-07-05 18:38:38 --> Loader Class Initialized
INFO - 2016-07-05 18:38:38 --> Helper loaded: url_helper
INFO - 2016-07-05 18:38:38 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:38:38 --> Helper loaded: html_helper
INFO - 2016-07-05 18:38:38 --> Helper loaded: form_helper
INFO - 2016-07-05 18:38:38 --> Helper loaded: file_helper
INFO - 2016-07-05 18:38:38 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:38:38 --> Database Driver Class Initialized
INFO - 2016-07-05 18:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:38:38 --> Form Validation Class Initialized
INFO - 2016-07-05 18:38:38 --> Email Class Initialized
INFO - 2016-07-05 18:38:38 --> Controller Class Initialized
DEBUG - 2016-07-05 18:38:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:38:38 --> Model Class Initialized
INFO - 2016-07-05 18:38:38 --> Model Class Initialized
INFO - 2016-07-05 18:38:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:38:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
ERROR - 2016-07-05 18:38:38 --> Severity: Notice --> Undefined variable: condition D:\wamp\www\pnc-library\application\views\books\import_book.php 61
ERROR - 2016-07-05 18:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 61
ERROR - 2016-07-05 18:38:38 --> Severity: Notice --> Undefined variable: cate_label D:\wamp\www\pnc-library\application\views\books\import_book.php 86
ERROR - 2016-07-05 18:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 86
ERROR - 2016-07-05 18:38:38 --> Severity: Notice --> Undefined variable: status D:\wamp\www\pnc-library\application\views\books\import_book.php 113
ERROR - 2016-07-05 18:38:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 113
INFO - 2016-07-05 18:38:38 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:38:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:38:38 --> Final output sent to browser
DEBUG - 2016-07-05 18:38:38 --> Total execution time: 0.2771
INFO - 2016-07-05 18:38:54 --> Config Class Initialized
INFO - 2016-07-05 18:38:54 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:38:54 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:38:54 --> Utf8 Class Initialized
INFO - 2016-07-05 18:38:54 --> URI Class Initialized
INFO - 2016-07-05 18:38:54 --> Router Class Initialized
INFO - 2016-07-05 18:38:54 --> Output Class Initialized
INFO - 2016-07-05 18:38:54 --> Security Class Initialized
DEBUG - 2016-07-05 18:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:38:54 --> Input Class Initialized
INFO - 2016-07-05 18:38:54 --> Language Class Initialized
INFO - 2016-07-05 18:38:54 --> Loader Class Initialized
INFO - 2016-07-05 18:38:54 --> Helper loaded: url_helper
INFO - 2016-07-05 18:38:54 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:38:54 --> Helper loaded: html_helper
INFO - 2016-07-05 18:38:54 --> Helper loaded: form_helper
INFO - 2016-07-05 18:38:54 --> Helper loaded: file_helper
INFO - 2016-07-05 18:38:54 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:38:54 --> Database Driver Class Initialized
INFO - 2016-07-05 18:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:38:54 --> Form Validation Class Initialized
INFO - 2016-07-05 18:38:54 --> Email Class Initialized
INFO - 2016-07-05 18:38:54 --> Controller Class Initialized
DEBUG - 2016-07-05 18:38:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:38:54 --> Model Class Initialized
INFO - 2016-07-05 18:38:54 --> Model Class Initialized
INFO - 2016-07-05 18:38:54 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:38:54 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
ERROR - 2016-07-05 18:38:54 --> Severity: Notice --> Undefined variable: condition D:\wamp\www\pnc-library\application\views\books\import_book.php 61
ERROR - 2016-07-05 18:38:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\pnc-library\application\views\books\import_book.php 61
INFO - 2016-07-05 18:38:54 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:38:54 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:38:54 --> Final output sent to browser
DEBUG - 2016-07-05 18:38:54 --> Total execution time: 0.2805
INFO - 2016-07-05 18:39:40 --> Config Class Initialized
INFO - 2016-07-05 18:39:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:39:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:39:40 --> Utf8 Class Initialized
INFO - 2016-07-05 18:39:40 --> URI Class Initialized
INFO - 2016-07-05 18:39:40 --> Router Class Initialized
INFO - 2016-07-05 18:39:40 --> Output Class Initialized
INFO - 2016-07-05 18:39:40 --> Security Class Initialized
DEBUG - 2016-07-05 18:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:39:40 --> Input Class Initialized
INFO - 2016-07-05 18:39:40 --> Language Class Initialized
INFO - 2016-07-05 18:39:40 --> Loader Class Initialized
INFO - 2016-07-05 18:39:40 --> Helper loaded: url_helper
INFO - 2016-07-05 18:39:40 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:39:40 --> Helper loaded: html_helper
INFO - 2016-07-05 18:39:40 --> Helper loaded: form_helper
INFO - 2016-07-05 18:39:40 --> Helper loaded: file_helper
INFO - 2016-07-05 18:39:40 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:39:40 --> Database Driver Class Initialized
INFO - 2016-07-05 18:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:39:40 --> Form Validation Class Initialized
INFO - 2016-07-05 18:39:40 --> Email Class Initialized
INFO - 2016-07-05 18:39:40 --> Controller Class Initialized
DEBUG - 2016-07-05 18:39:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:39:40 --> Model Class Initialized
INFO - 2016-07-05 18:39:40 --> Model Class Initialized
INFO - 2016-07-05 18:39:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:39:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:39:40 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:39:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:39:40 --> Final output sent to browser
DEBUG - 2016-07-05 18:39:40 --> Total execution time: 0.2487
INFO - 2016-07-05 18:44:23 --> Config Class Initialized
INFO - 2016-07-05 18:44:23 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:44:23 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:44:23 --> Utf8 Class Initialized
INFO - 2016-07-05 18:44:23 --> URI Class Initialized
INFO - 2016-07-05 18:44:23 --> Router Class Initialized
INFO - 2016-07-05 18:44:23 --> Output Class Initialized
INFO - 2016-07-05 18:44:23 --> Security Class Initialized
DEBUG - 2016-07-05 18:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:44:23 --> Input Class Initialized
INFO - 2016-07-05 18:44:23 --> Language Class Initialized
INFO - 2016-07-05 18:44:23 --> Loader Class Initialized
INFO - 2016-07-05 18:44:23 --> Helper loaded: url_helper
INFO - 2016-07-05 18:44:23 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:44:23 --> Helper loaded: html_helper
INFO - 2016-07-05 18:44:23 --> Helper loaded: form_helper
INFO - 2016-07-05 18:44:23 --> Helper loaded: file_helper
INFO - 2016-07-05 18:44:23 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:44:23 --> Database Driver Class Initialized
INFO - 2016-07-05 18:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:44:23 --> Form Validation Class Initialized
INFO - 2016-07-05 18:44:23 --> Email Class Initialized
INFO - 2016-07-05 18:44:23 --> Controller Class Initialized
DEBUG - 2016-07-05 18:44:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:44:23 --> Model Class Initialized
INFO - 2016-07-05 18:44:23 --> Model Class Initialized
INFO - 2016-07-05 18:44:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:44:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:44:23 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:44:23 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:44:23 --> Final output sent to browser
DEBUG - 2016-07-05 18:44:23 --> Total execution time: 0.2481
INFO - 2016-07-05 18:44:25 --> Config Class Initialized
INFO - 2016-07-05 18:44:25 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:44:25 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:44:25 --> Utf8 Class Initialized
INFO - 2016-07-05 18:44:25 --> URI Class Initialized
INFO - 2016-07-05 18:44:25 --> Router Class Initialized
INFO - 2016-07-05 18:44:25 --> Output Class Initialized
INFO - 2016-07-05 18:44:25 --> Security Class Initialized
DEBUG - 2016-07-05 18:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:44:25 --> Input Class Initialized
INFO - 2016-07-05 18:44:25 --> Language Class Initialized
INFO - 2016-07-05 18:44:25 --> Loader Class Initialized
INFO - 2016-07-05 18:44:25 --> Helper loaded: url_helper
INFO - 2016-07-05 18:44:25 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:44:26 --> Helper loaded: html_helper
INFO - 2016-07-05 18:44:26 --> Helper loaded: form_helper
INFO - 2016-07-05 18:44:26 --> Helper loaded: file_helper
INFO - 2016-07-05 18:44:26 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:44:26 --> Database Driver Class Initialized
INFO - 2016-07-05 18:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:44:26 --> Form Validation Class Initialized
INFO - 2016-07-05 18:44:26 --> Email Class Initialized
INFO - 2016-07-05 18:44:26 --> Controller Class Initialized
DEBUG - 2016-07-05 18:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:44:26 --> Model Class Initialized
INFO - 2016-07-05 18:44:26 --> Model Class Initialized
INFO - 2016-07-05 18:44:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:44:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:44:26 --> Model Class Initialized
INFO - 2016-07-05 18:44:26 --> File loaded: D:\wamp\www\pnc-library\application\views\books/add.php
INFO - 2016-07-05 18:44:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:44:26 --> Final output sent to browser
DEBUG - 2016-07-05 18:44:26 --> Total execution time: 0.2632
INFO - 2016-07-05 18:44:27 --> Config Class Initialized
INFO - 2016-07-05 18:44:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:44:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:44:27 --> Utf8 Class Initialized
INFO - 2016-07-05 18:44:27 --> URI Class Initialized
INFO - 2016-07-05 18:44:27 --> Router Class Initialized
INFO - 2016-07-05 18:44:27 --> Output Class Initialized
INFO - 2016-07-05 18:44:27 --> Security Class Initialized
DEBUG - 2016-07-05 18:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:44:27 --> Input Class Initialized
INFO - 2016-07-05 18:44:27 --> Language Class Initialized
INFO - 2016-07-05 18:44:27 --> Loader Class Initialized
INFO - 2016-07-05 18:44:27 --> Helper loaded: url_helper
INFO - 2016-07-05 18:44:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:44:27 --> Helper loaded: html_helper
INFO - 2016-07-05 18:44:28 --> Helper loaded: form_helper
INFO - 2016-07-05 18:44:28 --> Helper loaded: file_helper
INFO - 2016-07-05 18:44:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:44:28 --> Database Driver Class Initialized
INFO - 2016-07-05 18:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:44:28 --> Form Validation Class Initialized
INFO - 2016-07-05 18:44:28 --> Email Class Initialized
INFO - 2016-07-05 18:44:28 --> Controller Class Initialized
DEBUG - 2016-07-05 18:44:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:44:28 --> Model Class Initialized
INFO - 2016-07-05 18:44:28 --> Model Class Initialized
INFO - 2016-07-05 18:44:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:44:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:44:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:44:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:44:28 --> Final output sent to browser
DEBUG - 2016-07-05 18:44:28 --> Total execution time: 0.2778
INFO - 2016-07-05 18:44:47 --> Config Class Initialized
INFO - 2016-07-05 18:44:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:44:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:44:47 --> Utf8 Class Initialized
INFO - 2016-07-05 18:44:47 --> URI Class Initialized
INFO - 2016-07-05 18:44:47 --> Router Class Initialized
INFO - 2016-07-05 18:44:47 --> Output Class Initialized
INFO - 2016-07-05 18:44:47 --> Security Class Initialized
DEBUG - 2016-07-05 18:44:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:44:47 --> Input Class Initialized
INFO - 2016-07-05 18:44:47 --> Language Class Initialized
INFO - 2016-07-05 18:44:47 --> Loader Class Initialized
INFO - 2016-07-05 18:44:47 --> Helper loaded: url_helper
INFO - 2016-07-05 18:44:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:44:47 --> Helper loaded: html_helper
INFO - 2016-07-05 18:44:47 --> Helper loaded: form_helper
INFO - 2016-07-05 18:44:47 --> Helper loaded: file_helper
INFO - 2016-07-05 18:44:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:44:47 --> Database Driver Class Initialized
INFO - 2016-07-05 18:44:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:44:47 --> Form Validation Class Initialized
INFO - 2016-07-05 18:44:47 --> Email Class Initialized
INFO - 2016-07-05 18:44:47 --> Controller Class Initialized
DEBUG - 2016-07-05 18:44:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:44:47 --> Model Class Initialized
INFO - 2016-07-05 18:44:47 --> Model Class Initialized
INFO - 2016-07-05 18:44:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:44:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:44:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:44:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:44:47 --> Final output sent to browser
DEBUG - 2016-07-05 18:44:47 --> Total execution time: 0.2966
INFO - 2016-07-05 18:48:44 --> Config Class Initialized
INFO - 2016-07-05 18:48:44 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:48:44 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:48:44 --> Utf8 Class Initialized
INFO - 2016-07-05 18:48:44 --> URI Class Initialized
INFO - 2016-07-05 18:48:44 --> Router Class Initialized
INFO - 2016-07-05 18:48:44 --> Output Class Initialized
INFO - 2016-07-05 18:48:44 --> Security Class Initialized
DEBUG - 2016-07-05 18:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:48:44 --> Input Class Initialized
INFO - 2016-07-05 18:48:44 --> Language Class Initialized
INFO - 2016-07-05 18:48:44 --> Loader Class Initialized
INFO - 2016-07-05 18:48:44 --> Helper loaded: url_helper
INFO - 2016-07-05 18:48:44 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:48:44 --> Helper loaded: html_helper
INFO - 2016-07-05 18:48:44 --> Helper loaded: form_helper
INFO - 2016-07-05 18:48:44 --> Helper loaded: file_helper
INFO - 2016-07-05 18:48:44 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:48:44 --> Database Driver Class Initialized
INFO - 2016-07-05 18:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:48:44 --> Form Validation Class Initialized
INFO - 2016-07-05 18:48:44 --> Email Class Initialized
INFO - 2016-07-05 18:48:44 --> Controller Class Initialized
DEBUG - 2016-07-05 18:48:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:48:44 --> Model Class Initialized
INFO - 2016-07-05 18:48:44 --> Model Class Initialized
INFO - 2016-07-05 18:48:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:48:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:48:44 --> Model Class Initialized
INFO - 2016-07-05 18:48:44 --> File loaded: D:\wamp\www\pnc-library\application\views\books/add.php
INFO - 2016-07-05 18:48:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:48:44 --> Final output sent to browser
DEBUG - 2016-07-05 18:48:44 --> Total execution time: 0.3265
INFO - 2016-07-05 18:49:09 --> Config Class Initialized
INFO - 2016-07-05 18:49:09 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:49:09 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:49:09 --> Utf8 Class Initialized
INFO - 2016-07-05 18:49:09 --> URI Class Initialized
INFO - 2016-07-05 18:49:09 --> Router Class Initialized
INFO - 2016-07-05 18:49:09 --> Output Class Initialized
INFO - 2016-07-05 18:49:09 --> Security Class Initialized
DEBUG - 2016-07-05 18:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:49:09 --> Input Class Initialized
INFO - 2016-07-05 18:49:09 --> Language Class Initialized
INFO - 2016-07-05 18:49:09 --> Loader Class Initialized
INFO - 2016-07-05 18:49:09 --> Helper loaded: url_helper
INFO - 2016-07-05 18:49:09 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:49:09 --> Helper loaded: html_helper
INFO - 2016-07-05 18:49:09 --> Helper loaded: form_helper
INFO - 2016-07-05 18:49:09 --> Helper loaded: file_helper
INFO - 2016-07-05 18:49:09 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:49:09 --> Database Driver Class Initialized
INFO - 2016-07-05 18:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:49:09 --> Form Validation Class Initialized
INFO - 2016-07-05 18:49:09 --> Email Class Initialized
INFO - 2016-07-05 18:49:09 --> Controller Class Initialized
DEBUG - 2016-07-05 18:49:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:49:09 --> Model Class Initialized
INFO - 2016-07-05 18:49:09 --> Model Class Initialized
INFO - 2016-07-05 18:49:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:49:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:49:09 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:49:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:49:09 --> Final output sent to browser
DEBUG - 2016-07-05 18:49:09 --> Total execution time: 0.3343
INFO - 2016-07-05 18:49:11 --> Config Class Initialized
INFO - 2016-07-05 18:49:11 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:49:11 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:49:11 --> Utf8 Class Initialized
INFO - 2016-07-05 18:49:11 --> URI Class Initialized
INFO - 2016-07-05 18:49:11 --> Router Class Initialized
INFO - 2016-07-05 18:49:11 --> Output Class Initialized
INFO - 2016-07-05 18:49:11 --> Security Class Initialized
DEBUG - 2016-07-05 18:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:49:11 --> Input Class Initialized
INFO - 2016-07-05 18:49:11 --> Language Class Initialized
INFO - 2016-07-05 18:49:11 --> Loader Class Initialized
INFO - 2016-07-05 18:49:11 --> Helper loaded: url_helper
INFO - 2016-07-05 18:49:11 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:49:11 --> Helper loaded: html_helper
INFO - 2016-07-05 18:49:11 --> Helper loaded: form_helper
INFO - 2016-07-05 18:49:11 --> Helper loaded: file_helper
INFO - 2016-07-05 18:49:11 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:49:11 --> Database Driver Class Initialized
INFO - 2016-07-05 18:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:49:11 --> Form Validation Class Initialized
INFO - 2016-07-05 18:49:11 --> Email Class Initialized
INFO - 2016-07-05 18:49:11 --> Controller Class Initialized
DEBUG - 2016-07-05 18:49:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:49:11 --> Model Class Initialized
INFO - 2016-07-05 18:49:11 --> Model Class Initialized
INFO - 2016-07-05 18:49:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:49:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:49:11 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:49:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:49:11 --> Final output sent to browser
DEBUG - 2016-07-05 18:49:11 --> Total execution time: 0.3292
INFO - 2016-07-05 18:49:16 --> Config Class Initialized
INFO - 2016-07-05 18:49:16 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:49:16 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:49:16 --> Utf8 Class Initialized
INFO - 2016-07-05 18:49:16 --> URI Class Initialized
INFO - 2016-07-05 18:49:16 --> Router Class Initialized
INFO - 2016-07-05 18:49:16 --> Output Class Initialized
INFO - 2016-07-05 18:49:16 --> Security Class Initialized
DEBUG - 2016-07-05 18:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:49:16 --> Input Class Initialized
INFO - 2016-07-05 18:49:16 --> Language Class Initialized
INFO - 2016-07-05 18:49:16 --> Loader Class Initialized
INFO - 2016-07-05 18:49:16 --> Helper loaded: url_helper
INFO - 2016-07-05 18:49:16 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:49:16 --> Helper loaded: html_helper
INFO - 2016-07-05 18:49:16 --> Helper loaded: form_helper
INFO - 2016-07-05 18:49:16 --> Helper loaded: file_helper
INFO - 2016-07-05 18:49:16 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:49:16 --> Database Driver Class Initialized
INFO - 2016-07-05 18:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:49:16 --> Form Validation Class Initialized
INFO - 2016-07-05 18:49:16 --> Email Class Initialized
INFO - 2016-07-05 18:49:16 --> Controller Class Initialized
DEBUG - 2016-07-05 18:49:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:49:16 --> Model Class Initialized
INFO - 2016-07-05 18:49:16 --> Model Class Initialized
INFO - 2016-07-05 18:49:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:49:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:49:16 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:49:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:49:16 --> Final output sent to browser
DEBUG - 2016-07-05 18:49:16 --> Total execution time: 0.3155
INFO - 2016-07-05 18:54:00 --> Config Class Initialized
INFO - 2016-07-05 18:54:00 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:54:00 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:54:00 --> Utf8 Class Initialized
INFO - 2016-07-05 18:54:00 --> URI Class Initialized
INFO - 2016-07-05 18:54:00 --> Router Class Initialized
INFO - 2016-07-05 18:54:00 --> Output Class Initialized
INFO - 2016-07-05 18:54:00 --> Security Class Initialized
DEBUG - 2016-07-05 18:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:54:00 --> Input Class Initialized
INFO - 2016-07-05 18:54:00 --> Language Class Initialized
INFO - 2016-07-05 18:54:00 --> Loader Class Initialized
INFO - 2016-07-05 18:54:00 --> Helper loaded: url_helper
INFO - 2016-07-05 18:54:00 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:54:00 --> Helper loaded: html_helper
INFO - 2016-07-05 18:54:00 --> Helper loaded: form_helper
INFO - 2016-07-05 18:54:00 --> Helper loaded: file_helper
INFO - 2016-07-05 18:54:00 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:54:00 --> Database Driver Class Initialized
INFO - 2016-07-05 18:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:54:00 --> Form Validation Class Initialized
INFO - 2016-07-05 18:54:00 --> Email Class Initialized
INFO - 2016-07-05 18:54:00 --> Controller Class Initialized
DEBUG - 2016-07-05 18:54:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:54:00 --> Model Class Initialized
INFO - 2016-07-05 18:54:00 --> Model Class Initialized
INFO - 2016-07-05 18:54:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:54:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:54:00 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:54:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:54:00 --> Final output sent to browser
DEBUG - 2016-07-05 18:54:00 --> Total execution time: 0.3236
INFO - 2016-07-05 18:54:10 --> Config Class Initialized
INFO - 2016-07-05 18:54:11 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:54:11 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:54:11 --> Utf8 Class Initialized
INFO - 2016-07-05 18:54:11 --> URI Class Initialized
INFO - 2016-07-05 18:54:11 --> Router Class Initialized
INFO - 2016-07-05 18:54:11 --> Output Class Initialized
INFO - 2016-07-05 18:54:11 --> Security Class Initialized
DEBUG - 2016-07-05 18:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:54:11 --> Input Class Initialized
INFO - 2016-07-05 18:54:11 --> Language Class Initialized
INFO - 2016-07-05 18:54:11 --> Loader Class Initialized
INFO - 2016-07-05 18:54:11 --> Helper loaded: url_helper
INFO - 2016-07-05 18:54:11 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:54:11 --> Helper loaded: html_helper
INFO - 2016-07-05 18:54:11 --> Helper loaded: form_helper
INFO - 2016-07-05 18:54:11 --> Helper loaded: file_helper
INFO - 2016-07-05 18:54:11 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:54:11 --> Database Driver Class Initialized
INFO - 2016-07-05 18:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:54:11 --> Form Validation Class Initialized
INFO - 2016-07-05 18:54:11 --> Email Class Initialized
INFO - 2016-07-05 18:54:11 --> Controller Class Initialized
DEBUG - 2016-07-05 18:54:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:54:11 --> Model Class Initialized
INFO - 2016-07-05 18:54:11 --> Model Class Initialized
INFO - 2016-07-05 18:54:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:54:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:54:11 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:54:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:54:11 --> Final output sent to browser
DEBUG - 2016-07-05 18:54:11 --> Total execution time: 0.3202
INFO - 2016-07-05 18:55:59 --> Config Class Initialized
INFO - 2016-07-05 18:55:59 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:55:59 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:55:59 --> Utf8 Class Initialized
INFO - 2016-07-05 18:55:59 --> URI Class Initialized
INFO - 2016-07-05 18:55:59 --> Router Class Initialized
INFO - 2016-07-05 18:55:59 --> Output Class Initialized
INFO - 2016-07-05 18:55:59 --> Security Class Initialized
DEBUG - 2016-07-05 18:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:55:59 --> Input Class Initialized
INFO - 2016-07-05 18:55:59 --> Language Class Initialized
INFO - 2016-07-05 18:55:59 --> Loader Class Initialized
INFO - 2016-07-05 18:55:59 --> Helper loaded: url_helper
INFO - 2016-07-05 18:55:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:55:59 --> Helper loaded: html_helper
INFO - 2016-07-05 18:55:59 --> Helper loaded: form_helper
INFO - 2016-07-05 18:55:59 --> Helper loaded: file_helper
INFO - 2016-07-05 18:55:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:55:59 --> Database Driver Class Initialized
INFO - 2016-07-05 18:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:55:59 --> Form Validation Class Initialized
INFO - 2016-07-05 18:55:59 --> Email Class Initialized
INFO - 2016-07-05 18:55:59 --> Controller Class Initialized
DEBUG - 2016-07-05 18:55:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:55:59 --> Model Class Initialized
INFO - 2016-07-05 18:55:59 --> Model Class Initialized
INFO - 2016-07-05 18:55:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:55:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:55:59 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:55:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:55:59 --> Final output sent to browser
DEBUG - 2016-07-05 18:55:59 --> Total execution time: 0.3274
INFO - 2016-07-05 18:57:37 --> Config Class Initialized
INFO - 2016-07-05 18:57:37 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:57:37 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:57:37 --> Utf8 Class Initialized
INFO - 2016-07-05 18:57:37 --> URI Class Initialized
INFO - 2016-07-05 18:57:37 --> Router Class Initialized
INFO - 2016-07-05 18:57:37 --> Output Class Initialized
INFO - 2016-07-05 18:57:37 --> Security Class Initialized
DEBUG - 2016-07-05 18:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:57:37 --> Input Class Initialized
INFO - 2016-07-05 18:57:37 --> Language Class Initialized
INFO - 2016-07-05 18:57:37 --> Loader Class Initialized
INFO - 2016-07-05 18:57:37 --> Helper loaded: url_helper
INFO - 2016-07-05 18:57:37 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:57:37 --> Helper loaded: html_helper
INFO - 2016-07-05 18:57:37 --> Helper loaded: form_helper
INFO - 2016-07-05 18:57:37 --> Helper loaded: file_helper
INFO - 2016-07-05 18:57:37 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:57:37 --> Database Driver Class Initialized
INFO - 2016-07-05 18:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:57:37 --> Form Validation Class Initialized
INFO - 2016-07-05 18:57:37 --> Email Class Initialized
INFO - 2016-07-05 18:57:37 --> Controller Class Initialized
DEBUG - 2016-07-05 18:57:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:57:37 --> Model Class Initialized
INFO - 2016-07-05 18:57:37 --> Model Class Initialized
INFO - 2016-07-05 18:57:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:57:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:57:37 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:57:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:57:37 --> Final output sent to browser
DEBUG - 2016-07-05 18:57:37 --> Total execution time: 0.3334
INFO - 2016-07-05 18:58:32 --> Config Class Initialized
INFO - 2016-07-05 18:58:32 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:58:32 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:58:32 --> Utf8 Class Initialized
INFO - 2016-07-05 18:58:32 --> URI Class Initialized
INFO - 2016-07-05 18:58:32 --> Router Class Initialized
INFO - 2016-07-05 18:58:32 --> Output Class Initialized
INFO - 2016-07-05 18:58:32 --> Security Class Initialized
DEBUG - 2016-07-05 18:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:58:32 --> Input Class Initialized
INFO - 2016-07-05 18:58:32 --> Language Class Initialized
INFO - 2016-07-05 18:58:32 --> Loader Class Initialized
INFO - 2016-07-05 18:58:32 --> Helper loaded: url_helper
INFO - 2016-07-05 18:58:32 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:58:32 --> Helper loaded: html_helper
INFO - 2016-07-05 18:58:32 --> Helper loaded: form_helper
INFO - 2016-07-05 18:58:32 --> Helper loaded: file_helper
INFO - 2016-07-05 18:58:32 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:58:32 --> Database Driver Class Initialized
INFO - 2016-07-05 18:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:58:32 --> Form Validation Class Initialized
INFO - 2016-07-05 18:58:32 --> Email Class Initialized
INFO - 2016-07-05 18:58:32 --> Controller Class Initialized
DEBUG - 2016-07-05 18:58:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:58:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:58:32 --> Model Class Initialized
INFO - 2016-07-05 18:58:32 --> Model Class Initialized
INFO - 2016-07-05 18:58:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:58:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:58:32 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:58:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:58:32 --> Final output sent to browser
DEBUG - 2016-07-05 18:58:32 --> Total execution time: 0.4069
INFO - 2016-07-05 18:58:43 --> Config Class Initialized
INFO - 2016-07-05 18:58:43 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:58:43 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:58:43 --> Utf8 Class Initialized
INFO - 2016-07-05 18:58:43 --> URI Class Initialized
INFO - 2016-07-05 18:58:43 --> Router Class Initialized
INFO - 2016-07-05 18:58:43 --> Output Class Initialized
INFO - 2016-07-05 18:58:43 --> Security Class Initialized
DEBUG - 2016-07-05 18:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:58:43 --> Input Class Initialized
INFO - 2016-07-05 18:58:43 --> Language Class Initialized
ERROR - 2016-07-05 18:58:43 --> 404 Page Not Found: Import_excel/index
INFO - 2016-07-05 18:58:50 --> Config Class Initialized
INFO - 2016-07-05 18:58:50 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:58:50 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:58:50 --> Utf8 Class Initialized
INFO - 2016-07-05 18:58:50 --> URI Class Initialized
INFO - 2016-07-05 18:58:50 --> Router Class Initialized
INFO - 2016-07-05 18:58:50 --> Output Class Initialized
INFO - 2016-07-05 18:58:50 --> Security Class Initialized
DEBUG - 2016-07-05 18:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:58:50 --> Input Class Initialized
INFO - 2016-07-05 18:58:50 --> Language Class Initialized
ERROR - 2016-07-05 18:58:50 --> 404 Page Not Found: Import_book/index
INFO - 2016-07-05 18:59:26 --> Config Class Initialized
INFO - 2016-07-05 18:59:26 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:26 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:26 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:26 --> URI Class Initialized
INFO - 2016-07-05 18:59:26 --> Router Class Initialized
INFO - 2016-07-05 18:59:26 --> Output Class Initialized
INFO - 2016-07-05 18:59:26 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:26 --> Input Class Initialized
INFO - 2016-07-05 18:59:26 --> Language Class Initialized
ERROR - 2016-07-05 18:59:26 --> 404 Page Not Found: Import_excel/index
INFO - 2016-07-05 18:59:27 --> Config Class Initialized
INFO - 2016-07-05 18:59:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:27 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:27 --> URI Class Initialized
INFO - 2016-07-05 18:59:27 --> Router Class Initialized
INFO - 2016-07-05 18:59:27 --> Output Class Initialized
INFO - 2016-07-05 18:59:27 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:27 --> Input Class Initialized
INFO - 2016-07-05 18:59:27 --> Language Class Initialized
INFO - 2016-07-05 18:59:27 --> Loader Class Initialized
INFO - 2016-07-05 18:59:27 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:27 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:27 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:27 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:27 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:27 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:27 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:27 --> Email Class Initialized
INFO - 2016-07-05 18:59:27 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 18:59:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:27 --> Model Class Initialized
INFO - 2016-07-05 18:59:27 --> Model Class Initialized
INFO - 2016-07-05 18:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 18:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:59:28 --> Final output sent to browser
DEBUG - 2016-07-05 18:59:28 --> Total execution time: 0.5395
INFO - 2016-07-05 18:59:31 --> Config Class Initialized
INFO - 2016-07-05 18:59:31 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:31 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:31 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:31 --> URI Class Initialized
INFO - 2016-07-05 18:59:31 --> Router Class Initialized
INFO - 2016-07-05 18:59:31 --> Output Class Initialized
INFO - 2016-07-05 18:59:31 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:31 --> Input Class Initialized
INFO - 2016-07-05 18:59:31 --> Language Class Initialized
INFO - 2016-07-05 18:59:31 --> Loader Class Initialized
INFO - 2016-07-05 18:59:31 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:31 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:31 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:31 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:31 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:31 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:31 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:31 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:31 --> Email Class Initialized
INFO - 2016-07-05 18:59:31 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:31 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:31 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:31 --> Model Class Initialized
INFO - 2016-07-05 18:59:31 --> Model Class Initialized
INFO - 2016-07-05 18:59:31 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-05 18:59:31 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:59:31 --> Final output sent to browser
DEBUG - 2016-07-05 18:59:31 --> Total execution time: 0.3251
INFO - 2016-07-05 18:59:35 --> Config Class Initialized
INFO - 2016-07-05 18:59:35 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:35 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:35 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:35 --> URI Class Initialized
INFO - 2016-07-05 18:59:35 --> Router Class Initialized
INFO - 2016-07-05 18:59:36 --> Output Class Initialized
INFO - 2016-07-05 18:59:36 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:36 --> Input Class Initialized
INFO - 2016-07-05 18:59:36 --> Language Class Initialized
INFO - 2016-07-05 18:59:36 --> Loader Class Initialized
INFO - 2016-07-05 18:59:36 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:36 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:36 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:36 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:36 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:36 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:36 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:36 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:36 --> Email Class Initialized
INFO - 2016-07-05 18:59:36 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:36 --> Model Class Initialized
INFO - 2016-07-05 18:59:36 --> Model Class Initialized
INFO - 2016-07-05 18:59:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:36 --> Model Class Initialized
INFO - 2016-07-05 18:59:36 --> File loaded: D:\wamp\www\pnc-library\application\views\books/add.php
INFO - 2016-07-05 18:59:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:59:36 --> Final output sent to browser
DEBUG - 2016-07-05 18:59:36 --> Total execution time: 0.3336
INFO - 2016-07-05 18:59:40 --> Config Class Initialized
INFO - 2016-07-05 18:59:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:41 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:41 --> URI Class Initialized
INFO - 2016-07-05 18:59:41 --> Router Class Initialized
INFO - 2016-07-05 18:59:41 --> Output Class Initialized
INFO - 2016-07-05 18:59:41 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:41 --> Input Class Initialized
INFO - 2016-07-05 18:59:41 --> Language Class Initialized
INFO - 2016-07-05 18:59:41 --> Loader Class Initialized
INFO - 2016-07-05 18:59:41 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:41 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:41 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:41 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:41 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:41 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:41 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:41 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:41 --> Email Class Initialized
INFO - 2016-07-05 18:59:41 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:41 --> Model Class Initialized
INFO - 2016-07-05 18:59:41 --> Model Class Initialized
INFO - 2016-07-05 18:59:41 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-05 18:59:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:59:41 --> Final output sent to browser
DEBUG - 2016-07-05 18:59:41 --> Total execution time: 0.3478
INFO - 2016-07-05 18:59:46 --> Config Class Initialized
INFO - 2016-07-05 18:59:46 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:46 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:46 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:46 --> URI Class Initialized
INFO - 2016-07-05 18:59:46 --> Router Class Initialized
INFO - 2016-07-05 18:59:46 --> Output Class Initialized
INFO - 2016-07-05 18:59:46 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:46 --> Input Class Initialized
INFO - 2016-07-05 18:59:46 --> Language Class Initialized
INFO - 2016-07-05 18:59:46 --> Loader Class Initialized
INFO - 2016-07-05 18:59:46 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:46 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:46 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:46 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:46 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:46 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:46 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:46 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:46 --> Email Class Initialized
INFO - 2016-07-05 18:59:46 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:46 --> Model Class Initialized
INFO - 2016-07-05 18:59:46 --> Model Class Initialized
INFO - 2016-07-05 18:59:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:46 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:59:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 18:59:46 --> Final output sent to browser
DEBUG - 2016-07-05 18:59:46 --> Total execution time: 0.3284
INFO - 2016-07-05 18:59:55 --> Config Class Initialized
INFO - 2016-07-05 18:59:55 --> Hooks Class Initialized
DEBUG - 2016-07-05 18:59:55 --> UTF-8 Support Enabled
INFO - 2016-07-05 18:59:55 --> Utf8 Class Initialized
INFO - 2016-07-05 18:59:55 --> URI Class Initialized
INFO - 2016-07-05 18:59:55 --> Router Class Initialized
INFO - 2016-07-05 18:59:55 --> Output Class Initialized
INFO - 2016-07-05 18:59:55 --> Security Class Initialized
DEBUG - 2016-07-05 18:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 18:59:55 --> Input Class Initialized
INFO - 2016-07-05 18:59:55 --> Language Class Initialized
INFO - 2016-07-05 18:59:55 --> Loader Class Initialized
INFO - 2016-07-05 18:59:55 --> Helper loaded: url_helper
INFO - 2016-07-05 18:59:55 --> Helper loaded: utils_helper
INFO - 2016-07-05 18:59:55 --> Helper loaded: html_helper
INFO - 2016-07-05 18:59:55 --> Helper loaded: form_helper
INFO - 2016-07-05 18:59:55 --> Helper loaded: file_helper
INFO - 2016-07-05 18:59:55 --> Helper loaded: myemail_helper
INFO - 2016-07-05 18:59:56 --> Database Driver Class Initialized
INFO - 2016-07-05 18:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 18:59:56 --> Form Validation Class Initialized
INFO - 2016-07-05 18:59:56 --> Email Class Initialized
INFO - 2016-07-05 18:59:56 --> Controller Class Initialized
DEBUG - 2016-07-05 18:59:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 18:59:56 --> Model Class Initialized
INFO - 2016-07-05 18:59:56 --> Model Class Initialized
INFO - 2016-07-05 18:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 18:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 18:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 18:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:01:47 --> Config Class Initialized
INFO - 2016-07-05 19:01:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:01:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:01:47 --> Utf8 Class Initialized
INFO - 2016-07-05 19:01:47 --> URI Class Initialized
INFO - 2016-07-05 19:01:47 --> Router Class Initialized
INFO - 2016-07-05 19:01:47 --> Output Class Initialized
INFO - 2016-07-05 19:01:47 --> Security Class Initialized
DEBUG - 2016-07-05 19:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:01:47 --> Input Class Initialized
INFO - 2016-07-05 19:01:47 --> Language Class Initialized
INFO - 2016-07-05 19:01:47 --> Loader Class Initialized
INFO - 2016-07-05 19:01:47 --> Helper loaded: url_helper
INFO - 2016-07-05 19:01:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:01:47 --> Helper loaded: html_helper
INFO - 2016-07-05 19:01:47 --> Helper loaded: form_helper
INFO - 2016-07-05 19:01:47 --> Helper loaded: file_helper
INFO - 2016-07-05 19:01:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:01:47 --> Database Driver Class Initialized
INFO - 2016-07-05 19:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:01:47 --> Form Validation Class Initialized
INFO - 2016-07-05 19:01:47 --> Email Class Initialized
INFO - 2016-07-05 19:01:47 --> Controller Class Initialized
DEBUG - 2016-07-05 19:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:01:47 --> Model Class Initialized
INFO - 2016-07-05 19:01:47 --> Model Class Initialized
INFO - 2016-07-05 19:01:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:01:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:01:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:01:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 19:01:47 --> Severity: Warning --> explode() expects parameter 2 to be string, array given D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 19:01:48 --> Final output sent to browser
DEBUG - 2016-07-05 19:01:48 --> Total execution time: 0.3425
INFO - 2016-07-05 19:02:41 --> Config Class Initialized
INFO - 2016-07-05 19:02:41 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:02:41 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:02:41 --> Utf8 Class Initialized
INFO - 2016-07-05 19:02:41 --> URI Class Initialized
INFO - 2016-07-05 19:02:41 --> Router Class Initialized
INFO - 2016-07-05 19:02:41 --> Output Class Initialized
INFO - 2016-07-05 19:02:41 --> Security Class Initialized
DEBUG - 2016-07-05 19:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:02:41 --> Input Class Initialized
INFO - 2016-07-05 19:02:41 --> Language Class Initialized
INFO - 2016-07-05 19:02:41 --> Loader Class Initialized
INFO - 2016-07-05 19:02:41 --> Helper loaded: url_helper
INFO - 2016-07-05 19:02:41 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:02:42 --> Helper loaded: html_helper
INFO - 2016-07-05 19:02:42 --> Helper loaded: form_helper
INFO - 2016-07-05 19:02:42 --> Helper loaded: file_helper
INFO - 2016-07-05 19:02:42 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:02:42 --> Database Driver Class Initialized
INFO - 2016-07-05 19:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:02:42 --> Form Validation Class Initialized
INFO - 2016-07-05 19:02:42 --> Email Class Initialized
INFO - 2016-07-05 19:02:42 --> Controller Class Initialized
DEBUG - 2016-07-05 19:02:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:02:42 --> Model Class Initialized
INFO - 2016-07-05 19:02:42 --> Model Class Initialized
INFO - 2016-07-05 19:02:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:02:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:02:42 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:02:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 19:02:42 --> Severity: Warning --> explode() expects parameter 2 to be string, array given D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 19:02:42 --> Final output sent to browser
DEBUG - 2016-07-05 19:02:42 --> Total execution time: 0.3540
INFO - 2016-07-05 19:03:10 --> Config Class Initialized
INFO - 2016-07-05 19:03:10 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:03:10 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:03:10 --> Utf8 Class Initialized
INFO - 2016-07-05 19:03:10 --> URI Class Initialized
INFO - 2016-07-05 19:03:10 --> Router Class Initialized
INFO - 2016-07-05 19:03:10 --> Output Class Initialized
INFO - 2016-07-05 19:03:10 --> Security Class Initialized
DEBUG - 2016-07-05 19:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:03:10 --> Input Class Initialized
INFO - 2016-07-05 19:03:10 --> Language Class Initialized
INFO - 2016-07-05 19:03:10 --> Loader Class Initialized
INFO - 2016-07-05 19:03:11 --> Helper loaded: url_helper
INFO - 2016-07-05 19:03:11 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:03:11 --> Helper loaded: html_helper
INFO - 2016-07-05 19:03:11 --> Helper loaded: form_helper
INFO - 2016-07-05 19:03:11 --> Helper loaded: file_helper
INFO - 2016-07-05 19:03:11 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:03:11 --> Database Driver Class Initialized
INFO - 2016-07-05 19:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:03:11 --> Form Validation Class Initialized
INFO - 2016-07-05 19:03:11 --> Email Class Initialized
INFO - 2016-07-05 19:03:11 --> Controller Class Initialized
DEBUG - 2016-07-05 19:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:03:11 --> Model Class Initialized
INFO - 2016-07-05 19:03:11 --> Model Class Initialized
INFO - 2016-07-05 19:03:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:03:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:03:11 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:03:11 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:19:10 --> Config Class Initialized
INFO - 2016-07-05 19:19:10 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:19:10 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:19:10 --> Utf8 Class Initialized
INFO - 2016-07-05 19:19:10 --> URI Class Initialized
INFO - 2016-07-05 19:19:10 --> Router Class Initialized
INFO - 2016-07-05 19:19:10 --> Output Class Initialized
INFO - 2016-07-05 19:19:10 --> Security Class Initialized
DEBUG - 2016-07-05 19:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:19:10 --> Input Class Initialized
INFO - 2016-07-05 19:19:10 --> Language Class Initialized
INFO - 2016-07-05 19:19:10 --> Loader Class Initialized
INFO - 2016-07-05 19:19:10 --> Helper loaded: url_helper
INFO - 2016-07-05 19:19:10 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:19:10 --> Helper loaded: html_helper
INFO - 2016-07-05 19:19:10 --> Helper loaded: form_helper
INFO - 2016-07-05 19:19:10 --> Helper loaded: file_helper
INFO - 2016-07-05 19:19:10 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:19:10 --> Database Driver Class Initialized
INFO - 2016-07-05 19:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:19:10 --> Form Validation Class Initialized
INFO - 2016-07-05 19:19:10 --> Email Class Initialized
INFO - 2016-07-05 19:19:10 --> Controller Class Initialized
DEBUG - 2016-07-05 19:19:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:19:10 --> Model Class Initialized
INFO - 2016-07-05 19:19:10 --> Model Class Initialized
INFO - 2016-07-05 19:19:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:19:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:19:10 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:19:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:19:10 --> Final output sent to browser
DEBUG - 2016-07-05 19:19:10 --> Total execution time: 0.3968
INFO - 2016-07-05 19:19:14 --> Config Class Initialized
INFO - 2016-07-05 19:19:14 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:19:14 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:19:14 --> Utf8 Class Initialized
INFO - 2016-07-05 19:19:14 --> URI Class Initialized
INFO - 2016-07-05 19:19:14 --> Router Class Initialized
INFO - 2016-07-05 19:19:14 --> Output Class Initialized
INFO - 2016-07-05 19:19:14 --> Security Class Initialized
DEBUG - 2016-07-05 19:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:19:14 --> Input Class Initialized
INFO - 2016-07-05 19:19:14 --> Language Class Initialized
INFO - 2016-07-05 19:19:14 --> Loader Class Initialized
INFO - 2016-07-05 19:19:14 --> Helper loaded: url_helper
INFO - 2016-07-05 19:19:14 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:19:14 --> Helper loaded: html_helper
INFO - 2016-07-05 19:19:14 --> Helper loaded: form_helper
INFO - 2016-07-05 19:19:14 --> Helper loaded: file_helper
INFO - 2016-07-05 19:19:14 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:19:14 --> Database Driver Class Initialized
INFO - 2016-07-05 19:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:19:14 --> Form Validation Class Initialized
INFO - 2016-07-05 19:19:14 --> Email Class Initialized
INFO - 2016-07-05 19:19:14 --> Controller Class Initialized
DEBUG - 2016-07-05 19:19:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:19:14 --> Model Class Initialized
INFO - 2016-07-05 19:19:14 --> Model Class Initialized
INFO - 2016-07-05 19:19:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:19:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:19:14 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:19:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:19:14 --> Final output sent to browser
DEBUG - 2016-07-05 19:19:14 --> Total execution time: 0.3457
INFO - 2016-07-05 19:19:37 --> Config Class Initialized
INFO - 2016-07-05 19:19:37 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:19:37 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:19:37 --> Utf8 Class Initialized
INFO - 2016-07-05 19:19:37 --> URI Class Initialized
INFO - 2016-07-05 19:19:37 --> Router Class Initialized
INFO - 2016-07-05 19:19:37 --> Output Class Initialized
INFO - 2016-07-05 19:19:37 --> Security Class Initialized
DEBUG - 2016-07-05 19:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:19:37 --> Input Class Initialized
INFO - 2016-07-05 19:19:37 --> Language Class Initialized
INFO - 2016-07-05 19:19:37 --> Loader Class Initialized
INFO - 2016-07-05 19:19:37 --> Helper loaded: url_helper
INFO - 2016-07-05 19:19:37 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:19:37 --> Helper loaded: html_helper
INFO - 2016-07-05 19:19:37 --> Helper loaded: form_helper
INFO - 2016-07-05 19:19:37 --> Helper loaded: file_helper
INFO - 2016-07-05 19:19:37 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:19:37 --> Database Driver Class Initialized
INFO - 2016-07-05 19:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:19:37 --> Form Validation Class Initialized
INFO - 2016-07-05 19:19:37 --> Email Class Initialized
INFO - 2016-07-05 19:19:37 --> Controller Class Initialized
DEBUG - 2016-07-05 19:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:19:38 --> Model Class Initialized
INFO - 2016-07-05 19:19:38 --> Model Class Initialized
INFO - 2016-07-05 19:19:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:19:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:19:38 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:19:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:19:38 --> Final output sent to browser
DEBUG - 2016-07-05 19:19:38 --> Total execution time: 0.3423
INFO - 2016-07-05 19:20:09 --> Config Class Initialized
INFO - 2016-07-05 19:20:09 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:20:10 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:20:10 --> Utf8 Class Initialized
INFO - 2016-07-05 19:20:10 --> URI Class Initialized
INFO - 2016-07-05 19:20:10 --> Router Class Initialized
INFO - 2016-07-05 19:20:10 --> Output Class Initialized
INFO - 2016-07-05 19:20:10 --> Security Class Initialized
DEBUG - 2016-07-05 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:20:10 --> Input Class Initialized
INFO - 2016-07-05 19:20:10 --> Language Class Initialized
INFO - 2016-07-05 19:20:10 --> Loader Class Initialized
INFO - 2016-07-05 19:20:10 --> Helper loaded: url_helper
INFO - 2016-07-05 19:20:10 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:20:10 --> Helper loaded: html_helper
INFO - 2016-07-05 19:20:10 --> Helper loaded: form_helper
INFO - 2016-07-05 19:20:10 --> Helper loaded: file_helper
INFO - 2016-07-05 19:20:10 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:20:10 --> Database Driver Class Initialized
INFO - 2016-07-05 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:20:10 --> Form Validation Class Initialized
INFO - 2016-07-05 19:20:10 --> Email Class Initialized
INFO - 2016-07-05 19:20:10 --> Controller Class Initialized
DEBUG - 2016-07-05 19:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:20:10 --> Model Class Initialized
INFO - 2016-07-05 19:20:10 --> Model Class Initialized
INFO - 2016-07-05 19:20:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:20:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:20:10 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:20:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:20:10 --> Final output sent to browser
DEBUG - 2016-07-05 19:20:10 --> Total execution time: 0.3493
INFO - 2016-07-05 19:21:07 --> Config Class Initialized
INFO - 2016-07-05 19:21:07 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:21:07 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:21:07 --> Utf8 Class Initialized
INFO - 2016-07-05 19:21:07 --> URI Class Initialized
INFO - 2016-07-05 19:21:07 --> Router Class Initialized
INFO - 2016-07-05 19:21:07 --> Output Class Initialized
INFO - 2016-07-05 19:21:07 --> Security Class Initialized
DEBUG - 2016-07-05 19:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:21:07 --> Input Class Initialized
INFO - 2016-07-05 19:21:07 --> Language Class Initialized
INFO - 2016-07-05 19:21:07 --> Loader Class Initialized
INFO - 2016-07-05 19:21:07 --> Helper loaded: url_helper
INFO - 2016-07-05 19:21:07 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:21:07 --> Helper loaded: html_helper
INFO - 2016-07-05 19:21:07 --> Helper loaded: form_helper
INFO - 2016-07-05 19:21:07 --> Helper loaded: file_helper
INFO - 2016-07-05 19:21:07 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:21:07 --> Database Driver Class Initialized
INFO - 2016-07-05 19:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:21:07 --> Form Validation Class Initialized
INFO - 2016-07-05 19:21:07 --> Email Class Initialized
INFO - 2016-07-05 19:21:07 --> Controller Class Initialized
DEBUG - 2016-07-05 19:21:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:21:07 --> Model Class Initialized
INFO - 2016-07-05 19:21:07 --> Model Class Initialized
INFO - 2016-07-05 19:21:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:21:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:21:07 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:21:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:21:07 --> Final output sent to browser
DEBUG - 2016-07-05 19:21:07 --> Total execution time: 0.3502
INFO - 2016-07-05 19:22:08 --> Config Class Initialized
INFO - 2016-07-05 19:22:08 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:22:08 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:22:08 --> Utf8 Class Initialized
INFO - 2016-07-05 19:22:08 --> URI Class Initialized
INFO - 2016-07-05 19:22:08 --> Router Class Initialized
INFO - 2016-07-05 19:22:08 --> Output Class Initialized
INFO - 2016-07-05 19:22:08 --> Security Class Initialized
DEBUG - 2016-07-05 19:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:22:08 --> Input Class Initialized
INFO - 2016-07-05 19:22:08 --> Language Class Initialized
INFO - 2016-07-05 19:22:08 --> Loader Class Initialized
INFO - 2016-07-05 19:22:08 --> Helper loaded: url_helper
INFO - 2016-07-05 19:22:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:22:08 --> Helper loaded: html_helper
INFO - 2016-07-05 19:22:08 --> Helper loaded: form_helper
INFO - 2016-07-05 19:22:08 --> Helper loaded: file_helper
INFO - 2016-07-05 19:22:08 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:22:08 --> Database Driver Class Initialized
INFO - 2016-07-05 19:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:22:08 --> Form Validation Class Initialized
INFO - 2016-07-05 19:22:08 --> Email Class Initialized
INFO - 2016-07-05 19:22:08 --> Controller Class Initialized
DEBUG - 2016-07-05 19:22:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:22:08 --> Model Class Initialized
INFO - 2016-07-05 19:22:08 --> Model Class Initialized
INFO - 2016-07-05 19:22:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:22:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:22:09 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:22:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:22:09 --> Final output sent to browser
DEBUG - 2016-07-05 19:22:09 --> Total execution time: 0.3418
INFO - 2016-07-05 19:49:32 --> Config Class Initialized
INFO - 2016-07-05 19:49:32 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:49:32 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:49:32 --> Utf8 Class Initialized
INFO - 2016-07-05 19:49:32 --> URI Class Initialized
DEBUG - 2016-07-05 19:49:32 --> No URI present. Default controller set.
INFO - 2016-07-05 19:49:32 --> Router Class Initialized
INFO - 2016-07-05 19:49:32 --> Output Class Initialized
INFO - 2016-07-05 19:49:32 --> Security Class Initialized
DEBUG - 2016-07-05 19:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:49:32 --> Input Class Initialized
INFO - 2016-07-05 19:49:32 --> Language Class Initialized
INFO - 2016-07-05 19:49:32 --> Loader Class Initialized
INFO - 2016-07-05 19:49:32 --> Helper loaded: url_helper
INFO - 2016-07-05 19:49:32 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:49:32 --> Helper loaded: html_helper
INFO - 2016-07-05 19:49:32 --> Helper loaded: form_helper
INFO - 2016-07-05 19:49:32 --> Helper loaded: file_helper
INFO - 2016-07-05 19:49:32 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:49:32 --> Database Driver Class Initialized
INFO - 2016-07-05 19:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:49:32 --> Form Validation Class Initialized
INFO - 2016-07-05 19:49:32 --> Email Class Initialized
INFO - 2016-07-05 19:49:32 --> Controller Class Initialized
INFO - 2016-07-05 19:49:32 --> Model Class Initialized
INFO - 2016-07-05 19:49:32 --> Model Class Initialized
INFO - 2016-07-05 19:49:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:49:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:49:32 --> File loaded: D:\wamp\www\pnc-library\application\views\account/index.php
INFO - 2016-07-05 19:49:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:49:32 --> Final output sent to browser
DEBUG - 2016-07-05 19:49:32 --> Total execution time: 0.3529
INFO - 2016-07-05 19:49:40 --> Config Class Initialized
INFO - 2016-07-05 19:49:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:49:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:49:40 --> Utf8 Class Initialized
INFO - 2016-07-05 19:49:40 --> URI Class Initialized
INFO - 2016-07-05 19:49:40 --> Router Class Initialized
INFO - 2016-07-05 19:49:40 --> Output Class Initialized
INFO - 2016-07-05 19:49:40 --> Security Class Initialized
DEBUG - 2016-07-05 19:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:49:40 --> Input Class Initialized
INFO - 2016-07-05 19:49:40 --> Language Class Initialized
INFO - 2016-07-05 19:49:40 --> Loader Class Initialized
INFO - 2016-07-05 19:49:40 --> Helper loaded: url_helper
INFO - 2016-07-05 19:49:40 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:49:40 --> Helper loaded: html_helper
INFO - 2016-07-05 19:49:40 --> Helper loaded: form_helper
INFO - 2016-07-05 19:49:40 --> Helper loaded: file_helper
INFO - 2016-07-05 19:49:40 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:49:40 --> Database Driver Class Initialized
INFO - 2016-07-05 19:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:49:40 --> Form Validation Class Initialized
INFO - 2016-07-05 19:49:40 --> Email Class Initialized
INFO - 2016-07-05 19:49:40 --> Controller Class Initialized
DEBUG - 2016-07-05 19:49:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-05 19:49:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:49:40 --> Model Class Initialized
INFO - 2016-07-05 19:49:40 --> Model Class Initialized
INFO - 2016-07-05 19:49:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:49:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:49:40 --> File loaded: D:\wamp\www\pnc-library\application\views\dashboard/dashboard.php
INFO - 2016-07-05 19:49:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:49:40 --> Final output sent to browser
DEBUG - 2016-07-05 19:49:40 --> Total execution time: 0.4235
INFO - 2016-07-05 19:49:48 --> Config Class Initialized
INFO - 2016-07-05 19:49:48 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:49:48 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:49:48 --> Utf8 Class Initialized
INFO - 2016-07-05 19:49:48 --> URI Class Initialized
INFO - 2016-07-05 19:49:48 --> Router Class Initialized
INFO - 2016-07-05 19:49:48 --> Output Class Initialized
INFO - 2016-07-05 19:49:48 --> Security Class Initialized
DEBUG - 2016-07-05 19:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:49:48 --> Input Class Initialized
INFO - 2016-07-05 19:49:48 --> Language Class Initialized
INFO - 2016-07-05 19:49:48 --> Loader Class Initialized
INFO - 2016-07-05 19:49:48 --> Helper loaded: url_helper
INFO - 2016-07-05 19:49:48 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:49:48 --> Helper loaded: html_helper
INFO - 2016-07-05 19:49:48 --> Helper loaded: form_helper
INFO - 2016-07-05 19:49:48 --> Helper loaded: file_helper
INFO - 2016-07-05 19:49:48 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:49:48 --> Database Driver Class Initialized
INFO - 2016-07-05 19:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:49:48 --> Form Validation Class Initialized
INFO - 2016-07-05 19:49:48 --> Email Class Initialized
INFO - 2016-07-05 19:49:48 --> Controller Class Initialized
DEBUG - 2016-07-05 19:49:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:49:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:49:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:49:48 --> Model Class Initialized
INFO - 2016-07-05 19:49:48 --> Model Class Initialized
INFO - 2016-07-05 19:49:48 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-05 19:49:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:49:48 --> Final output sent to browser
DEBUG - 2016-07-05 19:49:48 --> Total execution time: 0.3960
INFO - 2016-07-05 19:49:53 --> Config Class Initialized
INFO - 2016-07-05 19:49:53 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:49:53 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:49:53 --> Utf8 Class Initialized
INFO - 2016-07-05 19:49:53 --> URI Class Initialized
INFO - 2016-07-05 19:49:53 --> Router Class Initialized
INFO - 2016-07-05 19:49:53 --> Output Class Initialized
INFO - 2016-07-05 19:49:53 --> Security Class Initialized
DEBUG - 2016-07-05 19:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:49:53 --> Input Class Initialized
INFO - 2016-07-05 19:49:53 --> Language Class Initialized
INFO - 2016-07-05 19:49:53 --> Loader Class Initialized
INFO - 2016-07-05 19:49:53 --> Helper loaded: url_helper
INFO - 2016-07-05 19:49:53 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:49:53 --> Helper loaded: html_helper
INFO - 2016-07-05 19:49:53 --> Helper loaded: form_helper
INFO - 2016-07-05 19:49:53 --> Helper loaded: file_helper
INFO - 2016-07-05 19:49:53 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:49:53 --> Database Driver Class Initialized
INFO - 2016-07-05 19:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:49:53 --> Form Validation Class Initialized
INFO - 2016-07-05 19:49:53 --> Email Class Initialized
INFO - 2016-07-05 19:49:53 --> Controller Class Initialized
DEBUG - 2016-07-05 19:49:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:49:53 --> Model Class Initialized
INFO - 2016-07-05 19:49:53 --> Model Class Initialized
INFO - 2016-07-05 19:49:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:49:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:49:53 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:49:53 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:49:53 --> Final output sent to browser
DEBUG - 2016-07-05 19:49:53 --> Total execution time: 0.3517
INFO - 2016-07-05 19:50:07 --> Config Class Initialized
INFO - 2016-07-05 19:50:07 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:50:07 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:50:07 --> Utf8 Class Initialized
INFO - 2016-07-05 19:50:07 --> URI Class Initialized
INFO - 2016-07-05 19:50:07 --> Router Class Initialized
INFO - 2016-07-05 19:50:07 --> Output Class Initialized
INFO - 2016-07-05 19:50:07 --> Security Class Initialized
DEBUG - 2016-07-05 19:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:50:07 --> Input Class Initialized
INFO - 2016-07-05 19:50:07 --> Language Class Initialized
INFO - 2016-07-05 19:50:07 --> Loader Class Initialized
INFO - 2016-07-05 19:50:07 --> Helper loaded: url_helper
INFO - 2016-07-05 19:50:07 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:50:07 --> Helper loaded: html_helper
INFO - 2016-07-05 19:50:07 --> Helper loaded: form_helper
INFO - 2016-07-05 19:50:07 --> Helper loaded: file_helper
INFO - 2016-07-05 19:50:07 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:50:07 --> Database Driver Class Initialized
INFO - 2016-07-05 19:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:50:07 --> Form Validation Class Initialized
INFO - 2016-07-05 19:50:07 --> Email Class Initialized
INFO - 2016-07-05 19:50:07 --> Controller Class Initialized
DEBUG - 2016-07-05 19:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:50:07 --> Model Class Initialized
INFO - 2016-07-05 19:50:07 --> Model Class Initialized
INFO - 2016-07-05 19:50:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:50:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:50:07 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:50:07 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:50:57 --> Config Class Initialized
INFO - 2016-07-05 19:50:57 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:50:57 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:50:57 --> Utf8 Class Initialized
INFO - 2016-07-05 19:50:57 --> URI Class Initialized
INFO - 2016-07-05 19:50:57 --> Router Class Initialized
INFO - 2016-07-05 19:50:57 --> Output Class Initialized
INFO - 2016-07-05 19:50:57 --> Security Class Initialized
DEBUG - 2016-07-05 19:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:50:57 --> Input Class Initialized
INFO - 2016-07-05 19:50:57 --> Language Class Initialized
INFO - 2016-07-05 19:50:57 --> Loader Class Initialized
INFO - 2016-07-05 19:50:57 --> Helper loaded: url_helper
INFO - 2016-07-05 19:50:57 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:50:57 --> Helper loaded: html_helper
INFO - 2016-07-05 19:50:57 --> Helper loaded: form_helper
INFO - 2016-07-05 19:50:57 --> Helper loaded: file_helper
INFO - 2016-07-05 19:50:57 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:50:57 --> Database Driver Class Initialized
INFO - 2016-07-05 19:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:50:57 --> Form Validation Class Initialized
INFO - 2016-07-05 19:50:57 --> Email Class Initialized
INFO - 2016-07-05 19:50:57 --> Controller Class Initialized
DEBUG - 2016-07-05 19:50:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:50:57 --> Model Class Initialized
INFO - 2016-07-05 19:50:57 --> Model Class Initialized
INFO - 2016-07-05 19:50:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:50:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:50:57 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:50:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 19:50:57 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 266
INFO - 2016-07-05 19:53:16 --> Config Class Initialized
INFO - 2016-07-05 19:53:16 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:53:16 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:53:16 --> Utf8 Class Initialized
INFO - 2016-07-05 19:53:16 --> URI Class Initialized
INFO - 2016-07-05 19:53:16 --> Router Class Initialized
INFO - 2016-07-05 19:53:16 --> Output Class Initialized
INFO - 2016-07-05 19:53:16 --> Security Class Initialized
DEBUG - 2016-07-05 19:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:53:16 --> Input Class Initialized
INFO - 2016-07-05 19:53:16 --> Language Class Initialized
INFO - 2016-07-05 19:53:16 --> Loader Class Initialized
INFO - 2016-07-05 19:53:16 --> Helper loaded: url_helper
INFO - 2016-07-05 19:53:16 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:53:16 --> Helper loaded: html_helper
INFO - 2016-07-05 19:53:16 --> Helper loaded: form_helper
INFO - 2016-07-05 19:53:16 --> Helper loaded: file_helper
INFO - 2016-07-05 19:53:16 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:53:16 --> Database Driver Class Initialized
INFO - 2016-07-05 19:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:53:16 --> Form Validation Class Initialized
INFO - 2016-07-05 19:53:16 --> Email Class Initialized
INFO - 2016-07-05 19:53:16 --> Controller Class Initialized
DEBUG - 2016-07-05 19:53:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:53:16 --> Model Class Initialized
INFO - 2016-07-05 19:53:16 --> Model Class Initialized
INFO - 2016-07-05 19:53:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:53:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:53:16 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:53:16 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:53:16 --> Final output sent to browser
DEBUG - 2016-07-05 19:53:16 --> Total execution time: 0.3871
INFO - 2016-07-05 19:53:21 --> Config Class Initialized
INFO - 2016-07-05 19:53:21 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:53:21 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:53:21 --> Utf8 Class Initialized
INFO - 2016-07-05 19:53:21 --> URI Class Initialized
INFO - 2016-07-05 19:53:21 --> Router Class Initialized
INFO - 2016-07-05 19:53:21 --> Output Class Initialized
INFO - 2016-07-05 19:53:21 --> Security Class Initialized
DEBUG - 2016-07-05 19:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:53:21 --> Input Class Initialized
INFO - 2016-07-05 19:53:21 --> Language Class Initialized
INFO - 2016-07-05 19:53:21 --> Loader Class Initialized
INFO - 2016-07-05 19:53:21 --> Helper loaded: url_helper
INFO - 2016-07-05 19:53:21 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:53:21 --> Helper loaded: html_helper
INFO - 2016-07-05 19:53:22 --> Helper loaded: form_helper
INFO - 2016-07-05 19:53:22 --> Helper loaded: file_helper
INFO - 2016-07-05 19:53:22 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:53:22 --> Database Driver Class Initialized
INFO - 2016-07-05 19:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:53:22 --> Form Validation Class Initialized
INFO - 2016-07-05 19:53:22 --> Email Class Initialized
INFO - 2016-07-05 19:53:22 --> Controller Class Initialized
DEBUG - 2016-07-05 19:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:53:22 --> Model Class Initialized
INFO - 2016-07-05 19:53:22 --> Model Class Initialized
INFO - 2016-07-05 19:53:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:53:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:53:22 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:53:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 19:53:22 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 266
INFO - 2016-07-05 19:53:45 --> Config Class Initialized
INFO - 2016-07-05 19:53:45 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:53:45 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:53:45 --> Utf8 Class Initialized
INFO - 2016-07-05 19:53:45 --> URI Class Initialized
INFO - 2016-07-05 19:53:45 --> Router Class Initialized
INFO - 2016-07-05 19:53:45 --> Output Class Initialized
INFO - 2016-07-05 19:53:45 --> Security Class Initialized
DEBUG - 2016-07-05 19:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:53:45 --> Input Class Initialized
INFO - 2016-07-05 19:53:45 --> Language Class Initialized
INFO - 2016-07-05 19:53:45 --> Loader Class Initialized
INFO - 2016-07-05 19:53:45 --> Helper loaded: url_helper
INFO - 2016-07-05 19:53:45 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:53:45 --> Helper loaded: html_helper
INFO - 2016-07-05 19:53:45 --> Helper loaded: form_helper
INFO - 2016-07-05 19:53:45 --> Helper loaded: file_helper
INFO - 2016-07-05 19:53:45 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:53:45 --> Database Driver Class Initialized
INFO - 2016-07-05 19:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:53:45 --> Form Validation Class Initialized
INFO - 2016-07-05 19:53:45 --> Email Class Initialized
INFO - 2016-07-05 19:53:45 --> Controller Class Initialized
DEBUG - 2016-07-05 19:53:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:53:45 --> Model Class Initialized
INFO - 2016-07-05 19:53:45 --> Model Class Initialized
INFO - 2016-07-05 19:53:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:53:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:53:45 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:53:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:55:38 --> Config Class Initialized
INFO - 2016-07-05 19:55:38 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:55:38 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:55:38 --> Utf8 Class Initialized
INFO - 2016-07-05 19:55:38 --> URI Class Initialized
INFO - 2016-07-05 19:55:38 --> Router Class Initialized
INFO - 2016-07-05 19:55:38 --> Output Class Initialized
INFO - 2016-07-05 19:55:38 --> Security Class Initialized
DEBUG - 2016-07-05 19:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:55:38 --> Input Class Initialized
INFO - 2016-07-05 19:55:38 --> Language Class Initialized
INFO - 2016-07-05 19:55:38 --> Loader Class Initialized
INFO - 2016-07-05 19:55:38 --> Helper loaded: url_helper
INFO - 2016-07-05 19:55:38 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:55:38 --> Helper loaded: html_helper
INFO - 2016-07-05 19:55:38 --> Helper loaded: form_helper
INFO - 2016-07-05 19:55:38 --> Helper loaded: file_helper
INFO - 2016-07-05 19:55:38 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:55:38 --> Database Driver Class Initialized
INFO - 2016-07-05 19:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:55:38 --> Form Validation Class Initialized
INFO - 2016-07-05 19:55:38 --> Email Class Initialized
INFO - 2016-07-05 19:55:38 --> Controller Class Initialized
DEBUG - 2016-07-05 19:55:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:55:38 --> Model Class Initialized
INFO - 2016-07-05 19:55:38 --> Model Class Initialized
INFO - 2016-07-05 19:55:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:55:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:55:38 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:55:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:58:43 --> Config Class Initialized
INFO - 2016-07-05 19:58:43 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:58:43 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:58:43 --> Utf8 Class Initialized
INFO - 2016-07-05 19:58:43 --> URI Class Initialized
INFO - 2016-07-05 19:58:43 --> Router Class Initialized
INFO - 2016-07-05 19:58:43 --> Output Class Initialized
INFO - 2016-07-05 19:58:43 --> Security Class Initialized
DEBUG - 2016-07-05 19:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:58:43 --> Input Class Initialized
INFO - 2016-07-05 19:58:43 --> Language Class Initialized
INFO - 2016-07-05 19:58:43 --> Loader Class Initialized
INFO - 2016-07-05 19:58:43 --> Helper loaded: url_helper
INFO - 2016-07-05 19:58:43 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:58:43 --> Helper loaded: html_helper
INFO - 2016-07-05 19:58:43 --> Helper loaded: form_helper
INFO - 2016-07-05 19:58:43 --> Helper loaded: file_helper
INFO - 2016-07-05 19:58:43 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:58:43 --> Database Driver Class Initialized
INFO - 2016-07-05 19:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:58:43 --> Form Validation Class Initialized
INFO - 2016-07-05 19:58:43 --> Email Class Initialized
INFO - 2016-07-05 19:58:43 --> Controller Class Initialized
DEBUG - 2016-07-05 19:58:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:58:44 --> Model Class Initialized
INFO - 2016-07-05 19:58:44 --> Model Class Initialized
INFO - 2016-07-05 19:58:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:58:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:58:44 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:58:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:58:44 --> Final output sent to browser
DEBUG - 2016-07-05 19:58:44 --> Total execution time: 0.3756
INFO - 2016-07-05 19:58:48 --> Config Class Initialized
INFO - 2016-07-05 19:58:48 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:58:48 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:58:48 --> Utf8 Class Initialized
INFO - 2016-07-05 19:58:48 --> URI Class Initialized
INFO - 2016-07-05 19:58:49 --> Router Class Initialized
INFO - 2016-07-05 19:58:49 --> Output Class Initialized
INFO - 2016-07-05 19:58:49 --> Security Class Initialized
DEBUG - 2016-07-05 19:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:58:49 --> Input Class Initialized
INFO - 2016-07-05 19:58:49 --> Language Class Initialized
INFO - 2016-07-05 19:58:49 --> Loader Class Initialized
INFO - 2016-07-05 19:58:49 --> Helper loaded: url_helper
INFO - 2016-07-05 19:58:49 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:58:49 --> Helper loaded: html_helper
INFO - 2016-07-05 19:58:49 --> Helper loaded: form_helper
INFO - 2016-07-05 19:58:49 --> Helper loaded: file_helper
INFO - 2016-07-05 19:58:49 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:58:49 --> Database Driver Class Initialized
INFO - 2016-07-05 19:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:58:49 --> Form Validation Class Initialized
INFO - 2016-07-05 19:58:49 --> Email Class Initialized
INFO - 2016-07-05 19:58:49 --> Controller Class Initialized
DEBUG - 2016-07-05 19:58:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:58:49 --> Model Class Initialized
INFO - 2016-07-05 19:58:49 --> Model Class Initialized
INFO - 2016-07-05 19:58:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:58:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:58:49 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:58:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:59:44 --> Config Class Initialized
INFO - 2016-07-05 19:59:44 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:59:44 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:59:44 --> Utf8 Class Initialized
INFO - 2016-07-05 19:59:44 --> URI Class Initialized
INFO - 2016-07-05 19:59:44 --> Router Class Initialized
INFO - 2016-07-05 19:59:44 --> Output Class Initialized
INFO - 2016-07-05 19:59:44 --> Security Class Initialized
DEBUG - 2016-07-05 19:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:59:44 --> Input Class Initialized
INFO - 2016-07-05 19:59:44 --> Language Class Initialized
INFO - 2016-07-05 19:59:44 --> Loader Class Initialized
INFO - 2016-07-05 19:59:44 --> Helper loaded: url_helper
INFO - 2016-07-05 19:59:44 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:59:44 --> Helper loaded: html_helper
INFO - 2016-07-05 19:59:44 --> Helper loaded: form_helper
INFO - 2016-07-05 19:59:45 --> Helper loaded: file_helper
INFO - 2016-07-05 19:59:45 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:59:45 --> Database Driver Class Initialized
INFO - 2016-07-05 19:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:59:45 --> Form Validation Class Initialized
INFO - 2016-07-05 19:59:45 --> Email Class Initialized
INFO - 2016-07-05 19:59:45 --> Controller Class Initialized
DEBUG - 2016-07-05 19:59:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:59:45 --> Model Class Initialized
INFO - 2016-07-05 19:59:45 --> Model Class Initialized
INFO - 2016-07-05 19:59:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:59:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:59:45 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:59:45 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 19:59:45 --> Final output sent to browser
DEBUG - 2016-07-05 19:59:45 --> Total execution time: 0.3910
INFO - 2016-07-05 19:59:49 --> Config Class Initialized
INFO - 2016-07-05 19:59:49 --> Hooks Class Initialized
DEBUG - 2016-07-05 19:59:49 --> UTF-8 Support Enabled
INFO - 2016-07-05 19:59:49 --> Utf8 Class Initialized
INFO - 2016-07-05 19:59:49 --> URI Class Initialized
INFO - 2016-07-05 19:59:49 --> Router Class Initialized
INFO - 2016-07-05 19:59:50 --> Output Class Initialized
INFO - 2016-07-05 19:59:50 --> Security Class Initialized
DEBUG - 2016-07-05 19:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 19:59:50 --> Input Class Initialized
INFO - 2016-07-05 19:59:50 --> Language Class Initialized
INFO - 2016-07-05 19:59:50 --> Loader Class Initialized
INFO - 2016-07-05 19:59:50 --> Helper loaded: url_helper
INFO - 2016-07-05 19:59:50 --> Helper loaded: utils_helper
INFO - 2016-07-05 19:59:50 --> Helper loaded: html_helper
INFO - 2016-07-05 19:59:50 --> Helper loaded: form_helper
INFO - 2016-07-05 19:59:50 --> Helper loaded: file_helper
INFO - 2016-07-05 19:59:50 --> Helper loaded: myemail_helper
INFO - 2016-07-05 19:59:50 --> Database Driver Class Initialized
INFO - 2016-07-05 19:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 19:59:50 --> Form Validation Class Initialized
INFO - 2016-07-05 19:59:50 --> Email Class Initialized
INFO - 2016-07-05 19:59:50 --> Controller Class Initialized
DEBUG - 2016-07-05 19:59:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 19:59:50 --> Model Class Initialized
INFO - 2016-07-05 19:59:50 --> Model Class Initialized
INFO - 2016-07-05 19:59:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 19:59:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 19:59:50 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 19:59:50 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:50 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:51 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:52 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:53 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:54 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:55 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:56 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:57 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:58 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 19:59:59 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:00 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:01 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:02 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:03 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:04 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:05 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:06 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:07 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:08 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:09 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:10 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:11 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:12 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:13 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:14 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:15 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:16 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:17 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:18 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 10 D:\wamp\www\pnc-library\application\controllers\Books.php 241
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 11 D:\wamp\www\pnc-library\application\controllers\Books.php 242
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 12 D:\wamp\www\pnc-library\application\controllers\Books.php 243
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 13 D:\wamp\www\pnc-library\application\controllers\Books.php 244
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 14 D:\wamp\www\pnc-library\application\controllers\Books.php 245
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 1 D:\wamp\www\pnc-library\application\controllers\Books.php 232
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 2 D:\wamp\www\pnc-library\application\controllers\Books.php 233
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 3 D:\wamp\www\pnc-library\application\controllers\Books.php 234
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 4 D:\wamp\www\pnc-library\application\controllers\Books.php 235
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 5 D:\wamp\www\pnc-library\application\controllers\Books.php 236
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 6 D:\wamp\www\pnc-library\application\controllers\Books.php 237
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 7 D:\wamp\www\pnc-library\application\controllers\Books.php 238
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 8 D:\wamp\www\pnc-library\application\controllers\Books.php 239
ERROR - 2016-07-05 20:00:19 --> Severity: Notice --> Undefined offset: 9 D:\wamp\www\pnc-library\application\controllers\Books.php 240
ERROR - 2016-07-05 20:00:19 --> Severity: Error --> Maximum execution time of 30 seconds exceeded D:\wamp\www\pnc-library\system\core\Log.php 220
INFO - 2016-07-05 20:00:27 --> Config Class Initialized
INFO - 2016-07-05 20:00:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:00:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:00:27 --> Utf8 Class Initialized
INFO - 2016-07-05 20:00:27 --> URI Class Initialized
INFO - 2016-07-05 20:00:27 --> Router Class Initialized
INFO - 2016-07-05 20:00:27 --> Output Class Initialized
INFO - 2016-07-05 20:00:27 --> Security Class Initialized
DEBUG - 2016-07-05 20:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:00:27 --> Input Class Initialized
INFO - 2016-07-05 20:00:27 --> Language Class Initialized
INFO - 2016-07-05 20:00:27 --> Loader Class Initialized
INFO - 2016-07-05 20:00:27 --> Helper loaded: url_helper
INFO - 2016-07-05 20:00:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:00:27 --> Helper loaded: html_helper
INFO - 2016-07-05 20:00:27 --> Helper loaded: form_helper
INFO - 2016-07-05 20:00:27 --> Helper loaded: file_helper
INFO - 2016-07-05 20:00:27 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:00:27 --> Database Driver Class Initialized
INFO - 2016-07-05 20:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:00:27 --> Form Validation Class Initialized
INFO - 2016-07-05 20:00:27 --> Email Class Initialized
INFO - 2016-07-05 20:00:27 --> Controller Class Initialized
DEBUG - 2016-07-05 20:00:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:00:27 --> Model Class Initialized
INFO - 2016-07-05 20:00:27 --> Model Class Initialized
INFO - 2016-07-05 20:00:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:00:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:00:27 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:00:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:00:27 --> Final output sent to browser
DEBUG - 2016-07-05 20:00:27 --> Total execution time: 0.5400
INFO - 2016-07-05 20:00:31 --> Config Class Initialized
INFO - 2016-07-05 20:00:31 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:00:31 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:00:31 --> Utf8 Class Initialized
INFO - 2016-07-05 20:00:31 --> URI Class Initialized
INFO - 2016-07-05 20:00:31 --> Router Class Initialized
INFO - 2016-07-05 20:00:31 --> Output Class Initialized
INFO - 2016-07-05 20:00:31 --> Security Class Initialized
DEBUG - 2016-07-05 20:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:00:31 --> Input Class Initialized
INFO - 2016-07-05 20:00:31 --> Language Class Initialized
INFO - 2016-07-05 20:00:31 --> Loader Class Initialized
INFO - 2016-07-05 20:00:31 --> Helper loaded: url_helper
INFO - 2016-07-05 20:00:31 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:00:31 --> Helper loaded: html_helper
INFO - 2016-07-05 20:00:31 --> Helper loaded: form_helper
INFO - 2016-07-05 20:00:31 --> Helper loaded: file_helper
INFO - 2016-07-05 20:00:31 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:00:31 --> Database Driver Class Initialized
INFO - 2016-07-05 20:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:00:31 --> Form Validation Class Initialized
INFO - 2016-07-05 20:00:31 --> Email Class Initialized
INFO - 2016-07-05 20:00:31 --> Controller Class Initialized
DEBUG - 2016-07-05 20:00:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:00:32 --> Model Class Initialized
INFO - 2016-07-05 20:00:32 --> Model Class Initialized
INFO - 2016-07-05 20:00:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:00:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:00:32 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:00:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:00:32 --> Final output sent to browser
DEBUG - 2016-07-05 20:00:32 --> Total execution time: 0.5277
INFO - 2016-07-05 20:00:36 --> Config Class Initialized
INFO - 2016-07-05 20:00:36 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:00:36 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:00:36 --> Utf8 Class Initialized
INFO - 2016-07-05 20:00:36 --> URI Class Initialized
INFO - 2016-07-05 20:00:36 --> Router Class Initialized
INFO - 2016-07-05 20:00:36 --> Output Class Initialized
INFO - 2016-07-05 20:00:36 --> Security Class Initialized
DEBUG - 2016-07-05 20:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:00:36 --> Input Class Initialized
INFO - 2016-07-05 20:00:36 --> Language Class Initialized
INFO - 2016-07-05 20:00:36 --> Loader Class Initialized
INFO - 2016-07-05 20:00:36 --> Helper loaded: url_helper
INFO - 2016-07-05 20:00:36 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:00:36 --> Helper loaded: html_helper
INFO - 2016-07-05 20:00:36 --> Helper loaded: form_helper
INFO - 2016-07-05 20:00:36 --> Helper loaded: file_helper
INFO - 2016-07-05 20:00:36 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:00:36 --> Database Driver Class Initialized
INFO - 2016-07-05 20:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:00:36 --> Form Validation Class Initialized
INFO - 2016-07-05 20:00:36 --> Email Class Initialized
INFO - 2016-07-05 20:00:36 --> Controller Class Initialized
DEBUG - 2016-07-05 20:00:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:00:36 --> Model Class Initialized
INFO - 2016-07-05 20:00:36 --> Model Class Initialized
INFO - 2016-07-05 20:00:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:00:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:00:36 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:00:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:00:36 --> Final output sent to browser
DEBUG - 2016-07-05 20:00:36 --> Total execution time: 0.5591
INFO - 2016-07-05 20:00:41 --> Config Class Initialized
INFO - 2016-07-05 20:00:41 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:00:41 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:00:41 --> Utf8 Class Initialized
INFO - 2016-07-05 20:00:41 --> URI Class Initialized
INFO - 2016-07-05 20:00:41 --> Router Class Initialized
INFO - 2016-07-05 20:00:41 --> Output Class Initialized
INFO - 2016-07-05 20:00:41 --> Security Class Initialized
DEBUG - 2016-07-05 20:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:00:41 --> Input Class Initialized
INFO - 2016-07-05 20:00:41 --> Language Class Initialized
INFO - 2016-07-05 20:00:41 --> Loader Class Initialized
INFO - 2016-07-05 20:00:41 --> Helper loaded: url_helper
INFO - 2016-07-05 20:00:41 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:00:41 --> Helper loaded: html_helper
INFO - 2016-07-05 20:00:41 --> Helper loaded: form_helper
INFO - 2016-07-05 20:00:41 --> Helper loaded: file_helper
INFO - 2016-07-05 20:00:41 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:00:41 --> Database Driver Class Initialized
INFO - 2016-07-05 20:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:00:42 --> Form Validation Class Initialized
INFO - 2016-07-05 20:00:42 --> Email Class Initialized
INFO - 2016-07-05 20:00:42 --> Controller Class Initialized
DEBUG - 2016-07-05 20:00:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:00:42 --> Model Class Initialized
INFO - 2016-07-05 20:00:42 --> Model Class Initialized
INFO - 2016-07-05 20:00:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:00:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:00:42 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:00:42 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:07:40 --> Config Class Initialized
INFO - 2016-07-05 20:07:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:07:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:07:40 --> Utf8 Class Initialized
INFO - 2016-07-05 20:07:40 --> URI Class Initialized
INFO - 2016-07-05 20:07:41 --> Router Class Initialized
INFO - 2016-07-05 20:07:41 --> Output Class Initialized
INFO - 2016-07-05 20:07:41 --> Security Class Initialized
DEBUG - 2016-07-05 20:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:07:41 --> Input Class Initialized
INFO - 2016-07-05 20:07:41 --> Language Class Initialized
INFO - 2016-07-05 20:07:41 --> Loader Class Initialized
INFO - 2016-07-05 20:07:41 --> Helper loaded: url_helper
INFO - 2016-07-05 20:07:41 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:07:41 --> Helper loaded: html_helper
INFO - 2016-07-05 20:07:41 --> Helper loaded: form_helper
INFO - 2016-07-05 20:07:41 --> Helper loaded: file_helper
INFO - 2016-07-05 20:07:41 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:07:41 --> Database Driver Class Initialized
INFO - 2016-07-05 20:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:07:41 --> Form Validation Class Initialized
INFO - 2016-07-05 20:07:41 --> Email Class Initialized
INFO - 2016-07-05 20:07:41 --> Controller Class Initialized
DEBUG - 2016-07-05 20:07:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:07:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:07:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:07:41 --> Model Class Initialized
INFO - 2016-07-05 20:07:41 --> Model Class Initialized
INFO - 2016-07-05 20:07:41 --> File loaded: D:\wamp\www\pnc-library\application\views\books/index.php
INFO - 2016-07-05 20:07:41 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:07:41 --> Final output sent to browser
DEBUG - 2016-07-05 20:07:41 --> Total execution time: 0.5626
INFO - 2016-07-05 20:07:44 --> Config Class Initialized
INFO - 2016-07-05 20:07:44 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:07:44 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:07:44 --> Utf8 Class Initialized
INFO - 2016-07-05 20:07:44 --> URI Class Initialized
INFO - 2016-07-05 20:07:44 --> Router Class Initialized
INFO - 2016-07-05 20:07:44 --> Output Class Initialized
INFO - 2016-07-05 20:07:44 --> Security Class Initialized
DEBUG - 2016-07-05 20:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:07:44 --> Input Class Initialized
INFO - 2016-07-05 20:07:44 --> Language Class Initialized
INFO - 2016-07-05 20:07:44 --> Loader Class Initialized
INFO - 2016-07-05 20:07:44 --> Helper loaded: url_helper
INFO - 2016-07-05 20:07:44 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:07:44 --> Helper loaded: html_helper
INFO - 2016-07-05 20:07:44 --> Helper loaded: form_helper
INFO - 2016-07-05 20:07:44 --> Helper loaded: file_helper
INFO - 2016-07-05 20:07:44 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:07:44 --> Database Driver Class Initialized
INFO - 2016-07-05 20:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:07:44 --> Form Validation Class Initialized
INFO - 2016-07-05 20:07:44 --> Email Class Initialized
INFO - 2016-07-05 20:07:44 --> Controller Class Initialized
DEBUG - 2016-07-05 20:07:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:07:44 --> Model Class Initialized
INFO - 2016-07-05 20:07:44 --> Model Class Initialized
INFO - 2016-07-05 20:07:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:07:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:07:44 --> Model Class Initialized
INFO - 2016-07-05 20:07:44 --> File loaded: D:\wamp\www\pnc-library\application\views\books/add.php
INFO - 2016-07-05 20:07:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:07:44 --> Final output sent to browser
DEBUG - 2016-07-05 20:07:44 --> Total execution time: 0.5629
INFO - 2016-07-05 20:56:55 --> Config Class Initialized
INFO - 2016-07-05 20:56:55 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:56:55 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:56:55 --> Utf8 Class Initialized
INFO - 2016-07-05 20:56:55 --> URI Class Initialized
INFO - 2016-07-05 20:56:55 --> Router Class Initialized
INFO - 2016-07-05 20:56:55 --> Output Class Initialized
INFO - 2016-07-05 20:56:55 --> Security Class Initialized
DEBUG - 2016-07-05 20:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:56:55 --> Input Class Initialized
INFO - 2016-07-05 20:56:55 --> Language Class Initialized
INFO - 2016-07-05 20:56:55 --> Loader Class Initialized
INFO - 2016-07-05 20:56:55 --> Helper loaded: url_helper
INFO - 2016-07-05 20:56:55 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:56:55 --> Helper loaded: html_helper
INFO - 2016-07-05 20:56:55 --> Helper loaded: form_helper
INFO - 2016-07-05 20:56:55 --> Helper loaded: file_helper
INFO - 2016-07-05 20:56:55 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:56:55 --> Database Driver Class Initialized
INFO - 2016-07-05 20:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:56:55 --> Form Validation Class Initialized
INFO - 2016-07-05 20:56:56 --> Email Class Initialized
INFO - 2016-07-05 20:56:56 --> Controller Class Initialized
DEBUG - 2016-07-05 20:56:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:56:56 --> Model Class Initialized
INFO - 2016-07-05 20:56:56 --> Model Class Initialized
INFO - 2016-07-05 20:56:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:56:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:56:56 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:56:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 20:56:56 --> Final output sent to browser
DEBUG - 2016-07-05 20:56:56 --> Total execution time: 0.5226
INFO - 2016-07-05 20:59:28 --> Config Class Initialized
INFO - 2016-07-05 20:59:28 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:59:28 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:59:28 --> Utf8 Class Initialized
INFO - 2016-07-05 20:59:28 --> URI Class Initialized
INFO - 2016-07-05 20:59:28 --> Router Class Initialized
INFO - 2016-07-05 20:59:28 --> Output Class Initialized
INFO - 2016-07-05 20:59:28 --> Security Class Initialized
DEBUG - 2016-07-05 20:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:59:28 --> Input Class Initialized
INFO - 2016-07-05 20:59:28 --> Language Class Initialized
INFO - 2016-07-05 20:59:28 --> Loader Class Initialized
INFO - 2016-07-05 20:59:28 --> Helper loaded: url_helper
INFO - 2016-07-05 20:59:28 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:59:28 --> Helper loaded: html_helper
INFO - 2016-07-05 20:59:28 --> Helper loaded: form_helper
INFO - 2016-07-05 20:59:28 --> Helper loaded: file_helper
INFO - 2016-07-05 20:59:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:59:28 --> Database Driver Class Initialized
INFO - 2016-07-05 20:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:59:28 --> Form Validation Class Initialized
INFO - 2016-07-05 20:59:28 --> Email Class Initialized
INFO - 2016-07-05 20:59:28 --> Controller Class Initialized
DEBUG - 2016-07-05 20:59:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:59:28 --> Model Class Initialized
INFO - 2016-07-05 20:59:28 --> Model Class Initialized
INFO - 2016-07-05 20:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:59:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 20:59:28 --> Severity: Error --> Call to undefined method Books_model::getCategoriesName() D:\wamp\www\pnc-library\application\controllers\Books.php 218
INFO - 2016-07-05 20:59:55 --> Config Class Initialized
INFO - 2016-07-05 20:59:55 --> Hooks Class Initialized
DEBUG - 2016-07-05 20:59:55 --> UTF-8 Support Enabled
INFO - 2016-07-05 20:59:55 --> Utf8 Class Initialized
INFO - 2016-07-05 20:59:55 --> URI Class Initialized
INFO - 2016-07-05 20:59:55 --> Router Class Initialized
INFO - 2016-07-05 20:59:55 --> Output Class Initialized
INFO - 2016-07-05 20:59:55 --> Security Class Initialized
DEBUG - 2016-07-05 20:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 20:59:55 --> Input Class Initialized
INFO - 2016-07-05 20:59:55 --> Language Class Initialized
INFO - 2016-07-05 20:59:55 --> Loader Class Initialized
INFO - 2016-07-05 20:59:55 --> Helper loaded: url_helper
INFO - 2016-07-05 20:59:56 --> Helper loaded: utils_helper
INFO - 2016-07-05 20:59:56 --> Helper loaded: html_helper
INFO - 2016-07-05 20:59:56 --> Helper loaded: form_helper
INFO - 2016-07-05 20:59:56 --> Helper loaded: file_helper
INFO - 2016-07-05 20:59:56 --> Helper loaded: myemail_helper
INFO - 2016-07-05 20:59:56 --> Database Driver Class Initialized
INFO - 2016-07-05 20:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 20:59:56 --> Form Validation Class Initialized
INFO - 2016-07-05 20:59:56 --> Email Class Initialized
INFO - 2016-07-05 20:59:56 --> Controller Class Initialized
DEBUG - 2016-07-05 20:59:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 20:59:56 --> Model Class Initialized
INFO - 2016-07-05 20:59:56 --> Model Class Initialized
INFO - 2016-07-05 20:59:56 --> Model Class Initialized
INFO - 2016-07-05 20:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 20:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 20:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 20:59:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 21:02:09 --> Config Class Initialized
INFO - 2016-07-05 21:02:09 --> Hooks Class Initialized
DEBUG - 2016-07-05 21:02:09 --> UTF-8 Support Enabled
INFO - 2016-07-05 21:02:09 --> Utf8 Class Initialized
INFO - 2016-07-05 21:02:09 --> URI Class Initialized
INFO - 2016-07-05 21:02:09 --> Router Class Initialized
INFO - 2016-07-05 21:02:09 --> Output Class Initialized
INFO - 2016-07-05 21:02:09 --> Security Class Initialized
DEBUG - 2016-07-05 21:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 21:02:09 --> Input Class Initialized
INFO - 2016-07-05 21:02:09 --> Language Class Initialized
INFO - 2016-07-05 21:02:09 --> Loader Class Initialized
INFO - 2016-07-05 21:02:09 --> Helper loaded: url_helper
INFO - 2016-07-05 21:02:09 --> Helper loaded: utils_helper
INFO - 2016-07-05 21:02:09 --> Helper loaded: html_helper
INFO - 2016-07-05 21:02:09 --> Helper loaded: form_helper
INFO - 2016-07-05 21:02:09 --> Helper loaded: file_helper
INFO - 2016-07-05 21:02:09 --> Helper loaded: myemail_helper
INFO - 2016-07-05 21:02:09 --> Database Driver Class Initialized
INFO - 2016-07-05 21:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 21:02:10 --> Form Validation Class Initialized
INFO - 2016-07-05 21:02:10 --> Email Class Initialized
INFO - 2016-07-05 21:02:10 --> Controller Class Initialized
DEBUG - 2016-07-05 21:02:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 21:02:10 --> Model Class Initialized
INFO - 2016-07-05 21:02:10 --> Model Class Initialized
INFO - 2016-07-05 21:02:10 --> Model Class Initialized
INFO - 2016-07-05 21:02:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 21:02:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 21:02:10 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 21:02:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 21:02:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 21:06:33 --> Config Class Initialized
INFO - 2016-07-05 21:06:33 --> Hooks Class Initialized
DEBUG - 2016-07-05 21:06:33 --> UTF-8 Support Enabled
INFO - 2016-07-05 21:06:33 --> Utf8 Class Initialized
INFO - 2016-07-05 21:06:33 --> URI Class Initialized
INFO - 2016-07-05 21:06:33 --> Router Class Initialized
INFO - 2016-07-05 21:06:33 --> Output Class Initialized
INFO - 2016-07-05 21:06:34 --> Security Class Initialized
DEBUG - 2016-07-05 21:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 21:06:34 --> Input Class Initialized
INFO - 2016-07-05 21:06:34 --> Language Class Initialized
INFO - 2016-07-05 21:06:34 --> Loader Class Initialized
INFO - 2016-07-05 21:06:34 --> Helper loaded: url_helper
INFO - 2016-07-05 21:06:34 --> Helper loaded: utils_helper
INFO - 2016-07-05 21:06:34 --> Helper loaded: html_helper
INFO - 2016-07-05 21:06:34 --> Helper loaded: form_helper
INFO - 2016-07-05 21:06:34 --> Helper loaded: file_helper
INFO - 2016-07-05 21:06:34 --> Helper loaded: myemail_helper
INFO - 2016-07-05 21:06:34 --> Database Driver Class Initialized
INFO - 2016-07-05 21:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 21:06:34 --> Form Validation Class Initialized
INFO - 2016-07-05 21:06:34 --> Email Class Initialized
INFO - 2016-07-05 21:06:34 --> Controller Class Initialized
DEBUG - 2016-07-05 21:06:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 21:06:34 --> Model Class Initialized
INFO - 2016-07-05 21:06:34 --> Model Class Initialized
INFO - 2016-07-05 21:06:34 --> Model Class Initialized
INFO - 2016-07-05 21:06:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 21:06:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 21:06:34 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 21:06:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:09:31 --> Config Class Initialized
INFO - 2016-07-05 22:09:31 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:09:31 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:09:31 --> Utf8 Class Initialized
INFO - 2016-07-05 22:09:31 --> URI Class Initialized
INFO - 2016-07-05 22:09:31 --> Router Class Initialized
INFO - 2016-07-05 22:09:31 --> Output Class Initialized
INFO - 2016-07-05 22:09:31 --> Security Class Initialized
DEBUG - 2016-07-05 22:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:09:31 --> Input Class Initialized
INFO - 2016-07-05 22:09:31 --> Language Class Initialized
INFO - 2016-07-05 22:09:31 --> Loader Class Initialized
INFO - 2016-07-05 22:09:32 --> Helper loaded: url_helper
INFO - 2016-07-05 22:09:32 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:09:32 --> Helper loaded: html_helper
INFO - 2016-07-05 22:09:32 --> Helper loaded: form_helper
INFO - 2016-07-05 22:09:32 --> Helper loaded: file_helper
INFO - 2016-07-05 22:09:32 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:09:32 --> Database Driver Class Initialized
INFO - 2016-07-05 22:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:09:32 --> Form Validation Class Initialized
INFO - 2016-07-05 22:09:32 --> Email Class Initialized
INFO - 2016-07-05 22:09:32 --> Controller Class Initialized
DEBUG - 2016-07-05 22:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:09:32 --> Model Class Initialized
INFO - 2016-07-05 22:09:32 --> Model Class Initialized
INFO - 2016-07-05 22:09:32 --> Model Class Initialized
INFO - 2016-07-05 22:09:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:09:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:09:32 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:09:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:10:54 --> Config Class Initialized
INFO - 2016-07-05 22:10:54 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:10:54 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:10:54 --> Utf8 Class Initialized
INFO - 2016-07-05 22:10:54 --> URI Class Initialized
INFO - 2016-07-05 22:10:54 --> Router Class Initialized
INFO - 2016-07-05 22:10:54 --> Output Class Initialized
INFO - 2016-07-05 22:10:54 --> Security Class Initialized
DEBUG - 2016-07-05 22:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:10:54 --> Input Class Initialized
INFO - 2016-07-05 22:10:54 --> Language Class Initialized
INFO - 2016-07-05 22:10:54 --> Loader Class Initialized
INFO - 2016-07-05 22:10:54 --> Helper loaded: url_helper
INFO - 2016-07-05 22:10:54 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:10:54 --> Helper loaded: html_helper
INFO - 2016-07-05 22:10:54 --> Helper loaded: form_helper
INFO - 2016-07-05 22:10:54 --> Helper loaded: file_helper
INFO - 2016-07-05 22:10:54 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:10:54 --> Database Driver Class Initialized
INFO - 2016-07-05 22:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:10:54 --> Form Validation Class Initialized
INFO - 2016-07-05 22:10:54 --> Email Class Initialized
INFO - 2016-07-05 22:10:54 --> Controller Class Initialized
DEBUG - 2016-07-05 22:10:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:10:55 --> Model Class Initialized
INFO - 2016-07-05 22:10:55 --> Model Class Initialized
INFO - 2016-07-05 22:10:55 --> Model Class Initialized
INFO - 2016-07-05 22:10:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:10:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:10:55 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:10:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:10:55 --> Severity: 4096 --> Object of class CI_DB_mysqli_result could not be converted to string D:\wamp\www\pnc-library\application\models\category_model.php 35
INFO - 2016-07-05 22:11:12 --> Config Class Initialized
INFO - 2016-07-05 22:11:12 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:11:12 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:11:12 --> Utf8 Class Initialized
INFO - 2016-07-05 22:11:12 --> URI Class Initialized
INFO - 2016-07-05 22:11:12 --> Router Class Initialized
INFO - 2016-07-05 22:11:12 --> Output Class Initialized
INFO - 2016-07-05 22:11:12 --> Security Class Initialized
DEBUG - 2016-07-05 22:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:11:12 --> Input Class Initialized
INFO - 2016-07-05 22:11:12 --> Language Class Initialized
INFO - 2016-07-05 22:11:12 --> Loader Class Initialized
INFO - 2016-07-05 22:11:12 --> Helper loaded: url_helper
INFO - 2016-07-05 22:11:12 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:11:12 --> Helper loaded: html_helper
INFO - 2016-07-05 22:11:12 --> Helper loaded: form_helper
INFO - 2016-07-05 22:11:12 --> Helper loaded: file_helper
INFO - 2016-07-05 22:11:12 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:11:12 --> Database Driver Class Initialized
INFO - 2016-07-05 22:11:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:11:12 --> Form Validation Class Initialized
INFO - 2016-07-05 22:11:12 --> Email Class Initialized
INFO - 2016-07-05 22:11:12 --> Controller Class Initialized
DEBUG - 2016-07-05 22:11:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:11:12 --> Model Class Initialized
INFO - 2016-07-05 22:11:12 --> Model Class Initialized
INFO - 2016-07-05 22:11:12 --> Model Class Initialized
INFO - 2016-07-05 22:11:12 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:11:12 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:11:12 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:11:13 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:11:31 --> Config Class Initialized
INFO - 2016-07-05 22:11:31 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:11:31 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:11:31 --> Utf8 Class Initialized
INFO - 2016-07-05 22:11:32 --> URI Class Initialized
INFO - 2016-07-05 22:11:32 --> Router Class Initialized
INFO - 2016-07-05 22:11:32 --> Output Class Initialized
INFO - 2016-07-05 22:11:32 --> Security Class Initialized
DEBUG - 2016-07-05 22:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:11:32 --> Input Class Initialized
INFO - 2016-07-05 22:11:32 --> Language Class Initialized
INFO - 2016-07-05 22:11:32 --> Loader Class Initialized
INFO - 2016-07-05 22:11:32 --> Helper loaded: url_helper
INFO - 2016-07-05 22:11:32 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:11:32 --> Helper loaded: html_helper
INFO - 2016-07-05 22:11:32 --> Helper loaded: form_helper
INFO - 2016-07-05 22:11:32 --> Helper loaded: file_helper
INFO - 2016-07-05 22:11:32 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:11:32 --> Database Driver Class Initialized
INFO - 2016-07-05 22:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:11:32 --> Form Validation Class Initialized
INFO - 2016-07-05 22:11:32 --> Email Class Initialized
INFO - 2016-07-05 22:11:32 --> Controller Class Initialized
DEBUG - 2016-07-05 22:11:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:11:32 --> Model Class Initialized
INFO - 2016-07-05 22:11:32 --> Model Class Initialized
INFO - 2016-07-05 22:11:32 --> Model Class Initialized
INFO - 2016-07-05 22:11:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:11:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:11:32 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:11:32 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:13:46 --> Config Class Initialized
INFO - 2016-07-05 22:13:46 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:13:46 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:13:46 --> Utf8 Class Initialized
INFO - 2016-07-05 22:13:46 --> URI Class Initialized
INFO - 2016-07-05 22:13:46 --> Router Class Initialized
INFO - 2016-07-05 22:13:46 --> Output Class Initialized
INFO - 2016-07-05 22:13:46 --> Security Class Initialized
DEBUG - 2016-07-05 22:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:13:46 --> Input Class Initialized
INFO - 2016-07-05 22:13:46 --> Language Class Initialized
INFO - 2016-07-05 22:13:46 --> Loader Class Initialized
INFO - 2016-07-05 22:13:46 --> Helper loaded: url_helper
INFO - 2016-07-05 22:13:46 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:13:46 --> Helper loaded: html_helper
INFO - 2016-07-05 22:13:46 --> Helper loaded: form_helper
INFO - 2016-07-05 22:13:46 --> Helper loaded: file_helper
INFO - 2016-07-05 22:13:46 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:13:46 --> Database Driver Class Initialized
INFO - 2016-07-05 22:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:13:46 --> Form Validation Class Initialized
INFO - 2016-07-05 22:13:46 --> Email Class Initialized
INFO - 2016-07-05 22:13:46 --> Controller Class Initialized
DEBUG - 2016-07-05 22:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:13:46 --> Model Class Initialized
INFO - 2016-07-05 22:13:46 --> Model Class Initialized
INFO - 2016-07-05 22:13:46 --> Model Class Initialized
INFO - 2016-07-05 22:13:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:13:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:13:47 --> Severity: Notice --> Trying to get property of non-object D:\wamp\www\pnc-library\application\models\category_model.php 35
INFO - 2016-07-05 22:14:18 --> Config Class Initialized
INFO - 2016-07-05 22:14:18 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:14:18 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:14:18 --> Utf8 Class Initialized
INFO - 2016-07-05 22:14:18 --> URI Class Initialized
INFO - 2016-07-05 22:14:18 --> Router Class Initialized
INFO - 2016-07-05 22:14:18 --> Output Class Initialized
INFO - 2016-07-05 22:14:18 --> Security Class Initialized
DEBUG - 2016-07-05 22:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:14:18 --> Input Class Initialized
INFO - 2016-07-05 22:14:18 --> Language Class Initialized
INFO - 2016-07-05 22:14:18 --> Loader Class Initialized
INFO - 2016-07-05 22:14:18 --> Helper loaded: url_helper
INFO - 2016-07-05 22:14:18 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:14:18 --> Helper loaded: html_helper
INFO - 2016-07-05 22:14:18 --> Helper loaded: form_helper
INFO - 2016-07-05 22:14:18 --> Helper loaded: file_helper
INFO - 2016-07-05 22:14:19 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:14:19 --> Database Driver Class Initialized
INFO - 2016-07-05 22:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:14:19 --> Form Validation Class Initialized
INFO - 2016-07-05 22:14:19 --> Email Class Initialized
INFO - 2016-07-05 22:14:19 --> Controller Class Initialized
DEBUG - 2016-07-05 22:14:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:14:19 --> Model Class Initialized
INFO - 2016-07-05 22:14:19 --> Model Class Initialized
INFO - 2016-07-05 22:14:19 --> Model Class Initialized
INFO - 2016-07-05 22:14:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:14:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:14:19 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:14:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:14:19 --> Severity: Notice --> Trying to get property of non-object D:\wamp\www\pnc-library\application\models\category_model.php 35
INFO - 2016-07-05 22:14:59 --> Config Class Initialized
INFO - 2016-07-05 22:14:59 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:14:59 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:14:59 --> Utf8 Class Initialized
INFO - 2016-07-05 22:14:59 --> URI Class Initialized
INFO - 2016-07-05 22:14:59 --> Router Class Initialized
INFO - 2016-07-05 22:14:59 --> Output Class Initialized
INFO - 2016-07-05 22:14:59 --> Security Class Initialized
DEBUG - 2016-07-05 22:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:14:59 --> Input Class Initialized
INFO - 2016-07-05 22:14:59 --> Language Class Initialized
INFO - 2016-07-05 22:14:59 --> Loader Class Initialized
INFO - 2016-07-05 22:14:59 --> Helper loaded: url_helper
INFO - 2016-07-05 22:14:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:14:59 --> Helper loaded: html_helper
INFO - 2016-07-05 22:14:59 --> Helper loaded: form_helper
INFO - 2016-07-05 22:14:59 --> Helper loaded: file_helper
INFO - 2016-07-05 22:14:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:14:59 --> Database Driver Class Initialized
INFO - 2016-07-05 22:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:15:00 --> Form Validation Class Initialized
INFO - 2016-07-05 22:15:00 --> Email Class Initialized
INFO - 2016-07-05 22:15:00 --> Controller Class Initialized
DEBUG - 2016-07-05 22:15:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:15:00 --> Model Class Initialized
INFO - 2016-07-05 22:15:00 --> Model Class Initialized
INFO - 2016-07-05 22:15:00 --> Model Class Initialized
INFO - 2016-07-05 22:15:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:15:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:15:00 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:15:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:15:00 --> Severity: Notice --> Trying to get property of non-object D:\wamp\www\pnc-library\application\models\category_model.php 36
INFO - 2016-07-05 22:15:25 --> Config Class Initialized
INFO - 2016-07-05 22:15:25 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:15:25 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:15:25 --> Utf8 Class Initialized
INFO - 2016-07-05 22:15:25 --> URI Class Initialized
INFO - 2016-07-05 22:15:25 --> Router Class Initialized
INFO - 2016-07-05 22:15:25 --> Output Class Initialized
INFO - 2016-07-05 22:15:25 --> Security Class Initialized
DEBUG - 2016-07-05 22:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:15:26 --> Input Class Initialized
INFO - 2016-07-05 22:15:26 --> Language Class Initialized
INFO - 2016-07-05 22:15:26 --> Loader Class Initialized
INFO - 2016-07-05 22:15:26 --> Helper loaded: url_helper
INFO - 2016-07-05 22:15:26 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:15:26 --> Helper loaded: html_helper
INFO - 2016-07-05 22:15:26 --> Helper loaded: form_helper
INFO - 2016-07-05 22:15:26 --> Helper loaded: file_helper
INFO - 2016-07-05 22:15:26 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:15:26 --> Database Driver Class Initialized
INFO - 2016-07-05 22:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:15:26 --> Form Validation Class Initialized
INFO - 2016-07-05 22:15:26 --> Email Class Initialized
INFO - 2016-07-05 22:15:26 --> Controller Class Initialized
DEBUG - 2016-07-05 22:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:15:26 --> Model Class Initialized
INFO - 2016-07-05 22:15:26 --> Model Class Initialized
INFO - 2016-07-05 22:15:26 --> Model Class Initialized
INFO - 2016-07-05 22:15:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:15:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:15:26 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:15:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:15:26 --> Severity: Error --> Call to a member function num_rows() on a non-object D:\wamp\www\pnc-library\application\models\category_model.php 36
INFO - 2016-07-05 22:16:27 --> Config Class Initialized
INFO - 2016-07-05 22:16:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:16:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:16:27 --> Utf8 Class Initialized
INFO - 2016-07-05 22:16:27 --> URI Class Initialized
INFO - 2016-07-05 22:16:27 --> Router Class Initialized
INFO - 2016-07-05 22:16:27 --> Output Class Initialized
INFO - 2016-07-05 22:16:27 --> Security Class Initialized
DEBUG - 2016-07-05 22:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:16:27 --> Input Class Initialized
INFO - 2016-07-05 22:16:27 --> Language Class Initialized
INFO - 2016-07-05 22:16:27 --> Loader Class Initialized
INFO - 2016-07-05 22:16:27 --> Helper loaded: url_helper
INFO - 2016-07-05 22:16:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:16:27 --> Helper loaded: html_helper
INFO - 2016-07-05 22:16:27 --> Helper loaded: form_helper
INFO - 2016-07-05 22:16:27 --> Helper loaded: file_helper
INFO - 2016-07-05 22:16:27 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:16:27 --> Database Driver Class Initialized
INFO - 2016-07-05 22:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:16:27 --> Form Validation Class Initialized
INFO - 2016-07-05 22:16:27 --> Email Class Initialized
INFO - 2016-07-05 22:16:27 --> Controller Class Initialized
DEBUG - 2016-07-05 22:16:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:16:27 --> Model Class Initialized
INFO - 2016-07-05 22:16:27 --> Model Class Initialized
INFO - 2016-07-05 22:16:28 --> Model Class Initialized
INFO - 2016-07-05 22:16:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:16:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:16:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:16:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:18:08 --> Config Class Initialized
INFO - 2016-07-05 22:18:08 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:18:08 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:18:08 --> Utf8 Class Initialized
INFO - 2016-07-05 22:18:08 --> URI Class Initialized
INFO - 2016-07-05 22:18:08 --> Router Class Initialized
INFO - 2016-07-05 22:18:08 --> Output Class Initialized
INFO - 2016-07-05 22:18:08 --> Security Class Initialized
DEBUG - 2016-07-05 22:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:18:08 --> Input Class Initialized
INFO - 2016-07-05 22:18:08 --> Language Class Initialized
INFO - 2016-07-05 22:18:08 --> Loader Class Initialized
INFO - 2016-07-05 22:18:08 --> Helper loaded: url_helper
INFO - 2016-07-05 22:18:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:18:09 --> Helper loaded: html_helper
INFO - 2016-07-05 22:18:09 --> Helper loaded: form_helper
INFO - 2016-07-05 22:18:09 --> Helper loaded: file_helper
INFO - 2016-07-05 22:18:09 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:18:09 --> Database Driver Class Initialized
INFO - 2016-07-05 22:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:18:09 --> Form Validation Class Initialized
INFO - 2016-07-05 22:18:09 --> Email Class Initialized
INFO - 2016-07-05 22:18:09 --> Controller Class Initialized
DEBUG - 2016-07-05 22:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:18:09 --> Model Class Initialized
INFO - 2016-07-05 22:18:09 --> Model Class Initialized
INFO - 2016-07-05 22:18:09 --> Model Class Initialized
INFO - 2016-07-05 22:18:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:18:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:18:09 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:18:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:18:51 --> Config Class Initialized
INFO - 2016-07-05 22:18:51 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:18:51 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:18:51 --> Utf8 Class Initialized
INFO - 2016-07-05 22:18:51 --> URI Class Initialized
INFO - 2016-07-05 22:18:51 --> Router Class Initialized
INFO - 2016-07-05 22:18:51 --> Output Class Initialized
INFO - 2016-07-05 22:18:51 --> Security Class Initialized
DEBUG - 2016-07-05 22:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:18:51 --> Input Class Initialized
INFO - 2016-07-05 22:18:51 --> Language Class Initialized
INFO - 2016-07-05 22:18:51 --> Loader Class Initialized
INFO - 2016-07-05 22:18:51 --> Helper loaded: url_helper
INFO - 2016-07-05 22:18:51 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:18:52 --> Helper loaded: html_helper
INFO - 2016-07-05 22:18:52 --> Helper loaded: form_helper
INFO - 2016-07-05 22:18:52 --> Helper loaded: file_helper
INFO - 2016-07-05 22:18:52 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:18:52 --> Database Driver Class Initialized
INFO - 2016-07-05 22:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:18:52 --> Form Validation Class Initialized
INFO - 2016-07-05 22:18:52 --> Email Class Initialized
INFO - 2016-07-05 22:18:52 --> Controller Class Initialized
DEBUG - 2016-07-05 22:18:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:18:52 --> Model Class Initialized
INFO - 2016-07-05 22:18:52 --> Model Class Initialized
INFO - 2016-07-05 22:18:52 --> Model Class Initialized
INFO - 2016-07-05 22:18:52 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:18:52 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:18:52 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:18:52 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:25:04 --> Config Class Initialized
INFO - 2016-07-05 22:25:04 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:25:04 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:25:04 --> Utf8 Class Initialized
INFO - 2016-07-05 22:25:04 --> URI Class Initialized
INFO - 2016-07-05 22:25:04 --> Router Class Initialized
INFO - 2016-07-05 22:25:04 --> Output Class Initialized
INFO - 2016-07-05 22:25:04 --> Security Class Initialized
DEBUG - 2016-07-05 22:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:25:04 --> Input Class Initialized
INFO - 2016-07-05 22:25:04 --> Language Class Initialized
INFO - 2016-07-05 22:25:04 --> Loader Class Initialized
INFO - 2016-07-05 22:25:04 --> Helper loaded: url_helper
INFO - 2016-07-05 22:25:04 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:25:04 --> Helper loaded: html_helper
INFO - 2016-07-05 22:25:04 --> Helper loaded: form_helper
INFO - 2016-07-05 22:25:04 --> Helper loaded: file_helper
INFO - 2016-07-05 22:25:04 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:25:04 --> Database Driver Class Initialized
INFO - 2016-07-05 22:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:25:04 --> Form Validation Class Initialized
INFO - 2016-07-05 22:25:04 --> Email Class Initialized
INFO - 2016-07-05 22:25:04 --> Controller Class Initialized
DEBUG - 2016-07-05 22:25:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:25:04 --> Model Class Initialized
INFO - 2016-07-05 22:25:05 --> Model Class Initialized
INFO - 2016-07-05 22:25:05 --> Model Class Initialized
INFO - 2016-07-05 22:25:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:25:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:25:05 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:25:05 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:25:33 --> Config Class Initialized
INFO - 2016-07-05 22:25:33 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:25:33 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:25:33 --> Utf8 Class Initialized
INFO - 2016-07-05 22:25:33 --> URI Class Initialized
INFO - 2016-07-05 22:25:33 --> Router Class Initialized
INFO - 2016-07-05 22:25:33 --> Output Class Initialized
INFO - 2016-07-05 22:25:33 --> Security Class Initialized
DEBUG - 2016-07-05 22:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:25:33 --> Input Class Initialized
INFO - 2016-07-05 22:25:33 --> Language Class Initialized
INFO - 2016-07-05 22:25:33 --> Loader Class Initialized
INFO - 2016-07-05 22:25:33 --> Helper loaded: url_helper
INFO - 2016-07-05 22:25:33 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:25:33 --> Helper loaded: html_helper
INFO - 2016-07-05 22:25:34 --> Helper loaded: form_helper
INFO - 2016-07-05 22:25:34 --> Helper loaded: file_helper
INFO - 2016-07-05 22:25:34 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:25:34 --> Database Driver Class Initialized
INFO - 2016-07-05 22:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:25:34 --> Form Validation Class Initialized
INFO - 2016-07-05 22:25:34 --> Email Class Initialized
INFO - 2016-07-05 22:25:34 --> Controller Class Initialized
DEBUG - 2016-07-05 22:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:25:34 --> Model Class Initialized
INFO - 2016-07-05 22:25:34 --> Model Class Initialized
INFO - 2016-07-05 22:25:34 --> Model Class Initialized
INFO - 2016-07-05 22:25:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:25:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:25:34 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:25:34 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:25:59 --> Config Class Initialized
INFO - 2016-07-05 22:25:59 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:25:59 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:25:59 --> Utf8 Class Initialized
INFO - 2016-07-05 22:25:59 --> URI Class Initialized
INFO - 2016-07-05 22:25:59 --> Router Class Initialized
INFO - 2016-07-05 22:25:59 --> Output Class Initialized
INFO - 2016-07-05 22:25:59 --> Security Class Initialized
DEBUG - 2016-07-05 22:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:25:59 --> Input Class Initialized
INFO - 2016-07-05 22:25:59 --> Language Class Initialized
INFO - 2016-07-05 22:25:59 --> Loader Class Initialized
INFO - 2016-07-05 22:25:59 --> Helper loaded: url_helper
INFO - 2016-07-05 22:25:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:25:59 --> Helper loaded: html_helper
INFO - 2016-07-05 22:25:59 --> Helper loaded: form_helper
INFO - 2016-07-05 22:25:59 --> Helper loaded: file_helper
INFO - 2016-07-05 22:25:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:26:00 --> Database Driver Class Initialized
INFO - 2016-07-05 22:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:26:00 --> Form Validation Class Initialized
INFO - 2016-07-05 22:26:00 --> Email Class Initialized
INFO - 2016-07-05 22:26:00 --> Controller Class Initialized
DEBUG - 2016-07-05 22:26:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:26:00 --> Model Class Initialized
INFO - 2016-07-05 22:26:00 --> Model Class Initialized
INFO - 2016-07-05 22:26:00 --> Model Class Initialized
INFO - 2016-07-05 22:26:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:26:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:26:00 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:26:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:26:00 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 220
INFO - 2016-07-05 22:26:28 --> Config Class Initialized
INFO - 2016-07-05 22:26:28 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:26:28 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:26:28 --> Utf8 Class Initialized
INFO - 2016-07-05 22:26:28 --> URI Class Initialized
INFO - 2016-07-05 22:26:28 --> Router Class Initialized
INFO - 2016-07-05 22:26:28 --> Output Class Initialized
INFO - 2016-07-05 22:26:28 --> Security Class Initialized
DEBUG - 2016-07-05 22:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:26:28 --> Input Class Initialized
INFO - 2016-07-05 22:26:28 --> Language Class Initialized
INFO - 2016-07-05 22:26:28 --> Loader Class Initialized
INFO - 2016-07-05 22:26:28 --> Helper loaded: url_helper
INFO - 2016-07-05 22:26:28 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:26:28 --> Helper loaded: html_helper
INFO - 2016-07-05 22:26:28 --> Helper loaded: form_helper
INFO - 2016-07-05 22:26:28 --> Helper loaded: file_helper
INFO - 2016-07-05 22:26:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:26:28 --> Database Driver Class Initialized
INFO - 2016-07-05 22:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:26:28 --> Form Validation Class Initialized
INFO - 2016-07-05 22:26:28 --> Email Class Initialized
INFO - 2016-07-05 22:26:28 --> Controller Class Initialized
DEBUG - 2016-07-05 22:26:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:26:28 --> Model Class Initialized
INFO - 2016-07-05 22:26:28 --> Model Class Initialized
INFO - 2016-07-05 22:26:28 --> Model Class Initialized
INFO - 2016-07-05 22:26:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:26:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:26:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:26:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:26:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 22:27:10 --> Config Class Initialized
INFO - 2016-07-05 22:27:10 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:27:10 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:27:10 --> Utf8 Class Initialized
INFO - 2016-07-05 22:27:10 --> URI Class Initialized
INFO - 2016-07-05 22:27:10 --> Router Class Initialized
INFO - 2016-07-05 22:27:10 --> Output Class Initialized
INFO - 2016-07-05 22:27:10 --> Security Class Initialized
DEBUG - 2016-07-05 22:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:27:10 --> Input Class Initialized
INFO - 2016-07-05 22:27:10 --> Language Class Initialized
INFO - 2016-07-05 22:27:10 --> Loader Class Initialized
INFO - 2016-07-05 22:27:10 --> Helper loaded: url_helper
INFO - 2016-07-05 22:27:10 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:27:10 --> Helper loaded: html_helper
INFO - 2016-07-05 22:27:10 --> Helper loaded: form_helper
INFO - 2016-07-05 22:27:10 --> Helper loaded: file_helper
INFO - 2016-07-05 22:27:10 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:27:10 --> Database Driver Class Initialized
INFO - 2016-07-05 22:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:27:10 --> Form Validation Class Initialized
INFO - 2016-07-05 22:27:10 --> Email Class Initialized
INFO - 2016-07-05 22:27:10 --> Controller Class Initialized
DEBUG - 2016-07-05 22:27:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:27:10 --> Model Class Initialized
INFO - 2016-07-05 22:27:10 --> Model Class Initialized
INFO - 2016-07-05 22:27:10 --> Model Class Initialized
INFO - 2016-07-05 22:27:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:27:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:27:10 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:27:10 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:10 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
ERROR - 2016-07-05 22:27:11 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 22:30:43 --> Config Class Initialized
INFO - 2016-07-05 22:30:43 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:30:43 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:30:43 --> Utf8 Class Initialized
INFO - 2016-07-05 22:30:43 --> URI Class Initialized
INFO - 2016-07-05 22:30:43 --> Router Class Initialized
INFO - 2016-07-05 22:30:43 --> Output Class Initialized
INFO - 2016-07-05 22:30:43 --> Security Class Initialized
DEBUG - 2016-07-05 22:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:30:43 --> Input Class Initialized
INFO - 2016-07-05 22:30:43 --> Language Class Initialized
INFO - 2016-07-05 22:30:43 --> Loader Class Initialized
INFO - 2016-07-05 22:30:43 --> Helper loaded: url_helper
INFO - 2016-07-05 22:30:43 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:30:43 --> Helper loaded: html_helper
INFO - 2016-07-05 22:30:43 --> Helper loaded: form_helper
INFO - 2016-07-05 22:30:43 --> Helper loaded: file_helper
INFO - 2016-07-05 22:30:43 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:30:43 --> Database Driver Class Initialized
INFO - 2016-07-05 22:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:30:43 --> Form Validation Class Initialized
INFO - 2016-07-05 22:30:43 --> Email Class Initialized
INFO - 2016-07-05 22:30:43 --> Controller Class Initialized
DEBUG - 2016-07-05 22:30:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:30:43 --> Model Class Initialized
INFO - 2016-07-05 22:30:43 --> Model Class Initialized
INFO - 2016-07-05 22:30:43 --> Model Class Initialized
INFO - 2016-07-05 22:30:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:30:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:30:43 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:30:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:30:43 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
INFO - 2016-07-05 22:31:43 --> Config Class Initialized
INFO - 2016-07-05 22:31:43 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:31:43 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:31:43 --> Utf8 Class Initialized
INFO - 2016-07-05 22:31:43 --> URI Class Initialized
INFO - 2016-07-05 22:31:43 --> Router Class Initialized
INFO - 2016-07-05 22:31:43 --> Output Class Initialized
INFO - 2016-07-05 22:31:43 --> Security Class Initialized
DEBUG - 2016-07-05 22:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:31:43 --> Input Class Initialized
INFO - 2016-07-05 22:31:43 --> Language Class Initialized
INFO - 2016-07-05 22:31:43 --> Loader Class Initialized
INFO - 2016-07-05 22:31:43 --> Helper loaded: url_helper
INFO - 2016-07-05 22:31:43 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:31:43 --> Helper loaded: html_helper
INFO - 2016-07-05 22:31:43 --> Helper loaded: form_helper
INFO - 2016-07-05 22:31:43 --> Helper loaded: file_helper
INFO - 2016-07-05 22:31:43 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:31:44 --> Database Driver Class Initialized
INFO - 2016-07-05 22:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:31:44 --> Form Validation Class Initialized
INFO - 2016-07-05 22:31:44 --> Email Class Initialized
INFO - 2016-07-05 22:31:44 --> Controller Class Initialized
DEBUG - 2016-07-05 22:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:31:44 --> Model Class Initialized
INFO - 2016-07-05 22:31:44 --> Model Class Initialized
INFO - 2016-07-05 22:31:44 --> Model Class Initialized
INFO - 2016-07-05 22:31:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:31:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:31:44 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:31:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
ERROR - 2016-07-05 22:31:44 --> Severity: Notice --> Undefined variable: catRow D:\wamp\www\pnc-library\application\controllers\Books.php 222
INFO - 2016-07-05 22:31:54 --> Config Class Initialized
INFO - 2016-07-05 22:31:54 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:31:55 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:31:55 --> Utf8 Class Initialized
INFO - 2016-07-05 22:31:55 --> URI Class Initialized
INFO - 2016-07-05 22:31:55 --> Router Class Initialized
INFO - 2016-07-05 22:31:55 --> Output Class Initialized
INFO - 2016-07-05 22:31:55 --> Security Class Initialized
DEBUG - 2016-07-05 22:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:31:55 --> Input Class Initialized
INFO - 2016-07-05 22:31:55 --> Language Class Initialized
INFO - 2016-07-05 22:31:55 --> Loader Class Initialized
INFO - 2016-07-05 22:31:55 --> Helper loaded: url_helper
INFO - 2016-07-05 22:31:55 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:31:55 --> Helper loaded: html_helper
INFO - 2016-07-05 22:31:55 --> Helper loaded: form_helper
INFO - 2016-07-05 22:31:55 --> Helper loaded: file_helper
INFO - 2016-07-05 22:31:55 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:31:55 --> Database Driver Class Initialized
INFO - 2016-07-05 22:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:31:55 --> Form Validation Class Initialized
INFO - 2016-07-05 22:31:55 --> Email Class Initialized
INFO - 2016-07-05 22:31:55 --> Controller Class Initialized
DEBUG - 2016-07-05 22:31:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:31:55 --> Model Class Initialized
INFO - 2016-07-05 22:31:55 --> Model Class Initialized
INFO - 2016-07-05 22:31:55 --> Model Class Initialized
INFO - 2016-07-05 22:31:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:31:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:31:55 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:31:55 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:32:17 --> Config Class Initialized
INFO - 2016-07-05 22:32:17 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:32:17 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:32:17 --> Utf8 Class Initialized
INFO - 2016-07-05 22:32:17 --> URI Class Initialized
INFO - 2016-07-05 22:32:17 --> Router Class Initialized
INFO - 2016-07-05 22:32:17 --> Output Class Initialized
INFO - 2016-07-05 22:32:17 --> Security Class Initialized
DEBUG - 2016-07-05 22:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:32:17 --> Input Class Initialized
INFO - 2016-07-05 22:32:17 --> Language Class Initialized
INFO - 2016-07-05 22:32:17 --> Loader Class Initialized
INFO - 2016-07-05 22:32:17 --> Helper loaded: url_helper
INFO - 2016-07-05 22:32:17 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:32:17 --> Helper loaded: html_helper
INFO - 2016-07-05 22:32:17 --> Helper loaded: form_helper
INFO - 2016-07-05 22:32:17 --> Helper loaded: file_helper
INFO - 2016-07-05 22:32:17 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:32:17 --> Database Driver Class Initialized
INFO - 2016-07-05 22:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:32:17 --> Form Validation Class Initialized
INFO - 2016-07-05 22:32:17 --> Email Class Initialized
INFO - 2016-07-05 22:32:17 --> Controller Class Initialized
DEBUG - 2016-07-05 22:32:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:32:17 --> Model Class Initialized
INFO - 2016-07-05 22:32:18 --> Model Class Initialized
INFO - 2016-07-05 22:32:18 --> Model Class Initialized
INFO - 2016-07-05 22:32:18 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:32:18 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:32:18 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:32:18 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:32:18 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 225
INFO - 2016-07-05 22:32:27 --> Config Class Initialized
INFO - 2016-07-05 22:32:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:32:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:32:27 --> Utf8 Class Initialized
INFO - 2016-07-05 22:32:27 --> URI Class Initialized
INFO - 2016-07-05 22:32:28 --> Router Class Initialized
INFO - 2016-07-05 22:32:28 --> Output Class Initialized
INFO - 2016-07-05 22:32:28 --> Security Class Initialized
DEBUG - 2016-07-05 22:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:32:28 --> Input Class Initialized
INFO - 2016-07-05 22:32:28 --> Language Class Initialized
INFO - 2016-07-05 22:32:28 --> Loader Class Initialized
INFO - 2016-07-05 22:32:28 --> Helper loaded: url_helper
INFO - 2016-07-05 22:32:28 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:32:28 --> Helper loaded: html_helper
INFO - 2016-07-05 22:32:28 --> Helper loaded: form_helper
INFO - 2016-07-05 22:32:28 --> Helper loaded: file_helper
INFO - 2016-07-05 22:32:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:32:28 --> Database Driver Class Initialized
INFO - 2016-07-05 22:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:32:28 --> Form Validation Class Initialized
INFO - 2016-07-05 22:32:28 --> Email Class Initialized
INFO - 2016-07-05 22:32:28 --> Controller Class Initialized
DEBUG - 2016-07-05 22:32:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:32:28 --> Model Class Initialized
INFO - 2016-07-05 22:32:28 --> Model Class Initialized
INFO - 2016-07-05 22:32:28 --> Model Class Initialized
INFO - 2016-07-05 22:32:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:32:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:32:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:32:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:32:28 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 225
INFO - 2016-07-05 22:32:36 --> Config Class Initialized
INFO - 2016-07-05 22:32:36 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:32:36 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:32:36 --> Utf8 Class Initialized
INFO - 2016-07-05 22:32:36 --> URI Class Initialized
INFO - 2016-07-05 22:32:36 --> Router Class Initialized
INFO - 2016-07-05 22:32:36 --> Output Class Initialized
INFO - 2016-07-05 22:32:36 --> Security Class Initialized
DEBUG - 2016-07-05 22:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:32:36 --> Input Class Initialized
INFO - 2016-07-05 22:32:36 --> Language Class Initialized
INFO - 2016-07-05 22:32:36 --> Loader Class Initialized
INFO - 2016-07-05 22:32:36 --> Helper loaded: url_helper
INFO - 2016-07-05 22:32:36 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:32:36 --> Helper loaded: html_helper
INFO - 2016-07-05 22:32:36 --> Helper loaded: form_helper
INFO - 2016-07-05 22:32:36 --> Helper loaded: file_helper
INFO - 2016-07-05 22:32:36 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:32:36 --> Database Driver Class Initialized
INFO - 2016-07-05 22:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:32:36 --> Form Validation Class Initialized
INFO - 2016-07-05 22:32:36 --> Email Class Initialized
INFO - 2016-07-05 22:32:36 --> Controller Class Initialized
DEBUG - 2016-07-05 22:32:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:32:36 --> Model Class Initialized
INFO - 2016-07-05 22:32:36 --> Model Class Initialized
INFO - 2016-07-05 22:32:36 --> Model Class Initialized
INFO - 2016-07-05 22:32:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:32:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:32:36 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:32:36 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:32:36 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 225
INFO - 2016-07-05 22:33:13 --> Config Class Initialized
INFO - 2016-07-05 22:33:13 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:33:13 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:33:13 --> Utf8 Class Initialized
INFO - 2016-07-05 22:33:13 --> URI Class Initialized
INFO - 2016-07-05 22:33:13 --> Router Class Initialized
INFO - 2016-07-05 22:33:13 --> Output Class Initialized
INFO - 2016-07-05 22:33:13 --> Security Class Initialized
DEBUG - 2016-07-05 22:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:33:13 --> Input Class Initialized
INFO - 2016-07-05 22:33:13 --> Language Class Initialized
INFO - 2016-07-05 22:33:13 --> Loader Class Initialized
INFO - 2016-07-05 22:33:13 --> Helper loaded: url_helper
INFO - 2016-07-05 22:33:13 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:33:13 --> Helper loaded: html_helper
INFO - 2016-07-05 22:33:13 --> Helper loaded: form_helper
INFO - 2016-07-05 22:33:13 --> Helper loaded: file_helper
INFO - 2016-07-05 22:33:13 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:33:13 --> Database Driver Class Initialized
INFO - 2016-07-05 22:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:33:13 --> Form Validation Class Initialized
INFO - 2016-07-05 22:33:13 --> Email Class Initialized
INFO - 2016-07-05 22:33:13 --> Controller Class Initialized
DEBUG - 2016-07-05 22:33:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:33:13 --> Model Class Initialized
INFO - 2016-07-05 22:33:13 --> Model Class Initialized
INFO - 2016-07-05 22:33:13 --> Model Class Initialized
INFO - 2016-07-05 22:33:13 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:33:13 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:33:13 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:33:13 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:33:13 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 225
INFO - 2016-07-05 22:35:37 --> Config Class Initialized
INFO - 2016-07-05 22:35:37 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:35:37 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:35:37 --> Utf8 Class Initialized
INFO - 2016-07-05 22:35:37 --> URI Class Initialized
INFO - 2016-07-05 22:35:37 --> Router Class Initialized
INFO - 2016-07-05 22:35:37 --> Output Class Initialized
INFO - 2016-07-05 22:35:37 --> Security Class Initialized
DEBUG - 2016-07-05 22:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:35:37 --> Input Class Initialized
INFO - 2016-07-05 22:35:37 --> Language Class Initialized
INFO - 2016-07-05 22:35:37 --> Loader Class Initialized
INFO - 2016-07-05 22:35:37 --> Helper loaded: url_helper
INFO - 2016-07-05 22:35:37 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:35:37 --> Helper loaded: html_helper
INFO - 2016-07-05 22:35:37 --> Helper loaded: form_helper
INFO - 2016-07-05 22:35:37 --> Helper loaded: file_helper
INFO - 2016-07-05 22:35:37 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:35:37 --> Database Driver Class Initialized
INFO - 2016-07-05 22:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:35:37 --> Form Validation Class Initialized
INFO - 2016-07-05 22:35:37 --> Email Class Initialized
INFO - 2016-07-05 22:35:37 --> Controller Class Initialized
DEBUG - 2016-07-05 22:35:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:35:37 --> Model Class Initialized
INFO - 2016-07-05 22:35:37 --> Model Class Initialized
INFO - 2016-07-05 22:35:37 --> Model Class Initialized
INFO - 2016-07-05 22:35:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:35:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:35:37 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:35:37 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:40:21 --> Config Class Initialized
INFO - 2016-07-05 22:40:22 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:40:22 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:40:22 --> Utf8 Class Initialized
INFO - 2016-07-05 22:40:22 --> URI Class Initialized
INFO - 2016-07-05 22:40:22 --> Router Class Initialized
INFO - 2016-07-05 22:40:22 --> Output Class Initialized
INFO - 2016-07-05 22:40:22 --> Security Class Initialized
DEBUG - 2016-07-05 22:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:40:22 --> Input Class Initialized
INFO - 2016-07-05 22:40:22 --> Language Class Initialized
INFO - 2016-07-05 22:40:22 --> Loader Class Initialized
INFO - 2016-07-05 22:40:22 --> Helper loaded: url_helper
INFO - 2016-07-05 22:40:22 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:40:22 --> Helper loaded: html_helper
INFO - 2016-07-05 22:40:22 --> Helper loaded: form_helper
INFO - 2016-07-05 22:40:22 --> Helper loaded: file_helper
INFO - 2016-07-05 22:40:22 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:40:22 --> Database Driver Class Initialized
INFO - 2016-07-05 22:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:40:22 --> Form Validation Class Initialized
INFO - 2016-07-05 22:40:22 --> Email Class Initialized
INFO - 2016-07-05 22:40:22 --> Controller Class Initialized
DEBUG - 2016-07-05 22:40:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:40:22 --> Model Class Initialized
INFO - 2016-07-05 22:40:22 --> Model Class Initialized
INFO - 2016-07-05 22:40:22 --> Model Class Initialized
INFO - 2016-07-05 22:40:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:40:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:40:22 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:40:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:40:25 --> Config Class Initialized
INFO - 2016-07-05 22:40:25 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:40:25 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:40:25 --> Utf8 Class Initialized
INFO - 2016-07-05 22:40:25 --> URI Class Initialized
INFO - 2016-07-05 22:40:25 --> Router Class Initialized
INFO - 2016-07-05 22:40:25 --> Output Class Initialized
INFO - 2016-07-05 22:40:25 --> Security Class Initialized
DEBUG - 2016-07-05 22:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:40:25 --> Input Class Initialized
INFO - 2016-07-05 22:40:25 --> Language Class Initialized
INFO - 2016-07-05 22:40:25 --> Loader Class Initialized
INFO - 2016-07-05 22:40:25 --> Helper loaded: url_helper
INFO - 2016-07-05 22:40:25 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:40:25 --> Helper loaded: html_helper
INFO - 2016-07-05 22:40:25 --> Helper loaded: form_helper
INFO - 2016-07-05 22:40:25 --> Helper loaded: file_helper
INFO - 2016-07-05 22:40:25 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:40:25 --> Database Driver Class Initialized
INFO - 2016-07-05 22:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:40:25 --> Form Validation Class Initialized
INFO - 2016-07-05 22:40:25 --> Email Class Initialized
INFO - 2016-07-05 22:40:25 --> Controller Class Initialized
DEBUG - 2016-07-05 22:40:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:40:25 --> Model Class Initialized
INFO - 2016-07-05 22:40:25 --> Model Class Initialized
INFO - 2016-07-05 22:40:25 --> Model Class Initialized
INFO - 2016-07-05 22:40:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:40:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:40:26 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:40:26 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:41:06 --> Config Class Initialized
INFO - 2016-07-05 22:41:06 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:41:06 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:41:06 --> Utf8 Class Initialized
INFO - 2016-07-05 22:41:06 --> URI Class Initialized
INFO - 2016-07-05 22:41:06 --> Router Class Initialized
INFO - 2016-07-05 22:41:06 --> Output Class Initialized
INFO - 2016-07-05 22:41:06 --> Security Class Initialized
DEBUG - 2016-07-05 22:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:41:06 --> Input Class Initialized
INFO - 2016-07-05 22:41:06 --> Language Class Initialized
INFO - 2016-07-05 22:41:06 --> Loader Class Initialized
INFO - 2016-07-05 22:41:06 --> Helper loaded: url_helper
INFO - 2016-07-05 22:41:06 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:41:06 --> Helper loaded: html_helper
INFO - 2016-07-05 22:41:06 --> Helper loaded: form_helper
INFO - 2016-07-05 22:41:06 --> Helper loaded: file_helper
INFO - 2016-07-05 22:41:06 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:41:06 --> Database Driver Class Initialized
INFO - 2016-07-05 22:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:41:06 --> Form Validation Class Initialized
INFO - 2016-07-05 22:41:06 --> Email Class Initialized
INFO - 2016-07-05 22:41:06 --> Controller Class Initialized
DEBUG - 2016-07-05 22:41:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:41:06 --> Model Class Initialized
INFO - 2016-07-05 22:41:06 --> Model Class Initialized
INFO - 2016-07-05 22:41:06 --> Model Class Initialized
INFO - 2016-07-05 22:41:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:41:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:41:06 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:41:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:41:24 --> Config Class Initialized
INFO - 2016-07-05 22:41:24 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:41:24 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:41:24 --> Utf8 Class Initialized
INFO - 2016-07-05 22:41:24 --> URI Class Initialized
INFO - 2016-07-05 22:41:24 --> Router Class Initialized
INFO - 2016-07-05 22:41:24 --> Output Class Initialized
INFO - 2016-07-05 22:41:24 --> Security Class Initialized
DEBUG - 2016-07-05 22:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:41:24 --> Input Class Initialized
INFO - 2016-07-05 22:41:24 --> Language Class Initialized
INFO - 2016-07-05 22:41:24 --> Loader Class Initialized
INFO - 2016-07-05 22:41:24 --> Helper loaded: url_helper
INFO - 2016-07-05 22:41:24 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:41:24 --> Helper loaded: html_helper
INFO - 2016-07-05 22:41:24 --> Helper loaded: form_helper
INFO - 2016-07-05 22:41:24 --> Helper loaded: file_helper
INFO - 2016-07-05 22:41:24 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:41:24 --> Database Driver Class Initialized
INFO - 2016-07-05 22:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:41:25 --> Form Validation Class Initialized
INFO - 2016-07-05 22:41:25 --> Email Class Initialized
INFO - 2016-07-05 22:41:25 --> Controller Class Initialized
DEBUG - 2016-07-05 22:41:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:41:25 --> Model Class Initialized
INFO - 2016-07-05 22:41:25 --> Model Class Initialized
INFO - 2016-07-05 22:41:25 --> Model Class Initialized
INFO - 2016-07-05 22:41:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:41:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:41:25 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:41:25 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:41:32 --> Config Class Initialized
INFO - 2016-07-05 22:41:32 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:41:32 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:41:32 --> Utf8 Class Initialized
INFO - 2016-07-05 22:41:32 --> URI Class Initialized
INFO - 2016-07-05 22:41:32 --> Router Class Initialized
INFO - 2016-07-05 22:41:32 --> Output Class Initialized
INFO - 2016-07-05 22:41:32 --> Security Class Initialized
DEBUG - 2016-07-05 22:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:41:32 --> Input Class Initialized
INFO - 2016-07-05 22:41:32 --> Language Class Initialized
INFO - 2016-07-05 22:41:32 --> Loader Class Initialized
INFO - 2016-07-05 22:41:32 --> Helper loaded: url_helper
INFO - 2016-07-05 22:41:32 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:41:32 --> Helper loaded: html_helper
INFO - 2016-07-05 22:41:32 --> Helper loaded: form_helper
INFO - 2016-07-05 22:41:32 --> Helper loaded: file_helper
INFO - 2016-07-05 22:41:32 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:41:32 --> Database Driver Class Initialized
INFO - 2016-07-05 22:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:41:32 --> Form Validation Class Initialized
INFO - 2016-07-05 22:41:33 --> Email Class Initialized
INFO - 2016-07-05 22:41:33 --> Controller Class Initialized
DEBUG - 2016-07-05 22:41:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:41:33 --> Model Class Initialized
INFO - 2016-07-05 22:41:33 --> Model Class Initialized
INFO - 2016-07-05 22:41:33 --> Model Class Initialized
INFO - 2016-07-05 22:41:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:41:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:41:33 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:41:33 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:41:47 --> Config Class Initialized
INFO - 2016-07-05 22:41:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:41:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:41:47 --> Utf8 Class Initialized
INFO - 2016-07-05 22:41:47 --> URI Class Initialized
INFO - 2016-07-05 22:41:47 --> Router Class Initialized
INFO - 2016-07-05 22:41:47 --> Output Class Initialized
INFO - 2016-07-05 22:41:47 --> Security Class Initialized
DEBUG - 2016-07-05 22:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:41:47 --> Input Class Initialized
INFO - 2016-07-05 22:41:47 --> Language Class Initialized
INFO - 2016-07-05 22:41:47 --> Loader Class Initialized
INFO - 2016-07-05 22:41:48 --> Helper loaded: url_helper
INFO - 2016-07-05 22:41:48 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:41:48 --> Helper loaded: html_helper
INFO - 2016-07-05 22:41:48 --> Helper loaded: form_helper
INFO - 2016-07-05 22:41:48 --> Helper loaded: file_helper
INFO - 2016-07-05 22:41:48 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:41:48 --> Database Driver Class Initialized
INFO - 2016-07-05 22:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:41:48 --> Form Validation Class Initialized
INFO - 2016-07-05 22:41:48 --> Email Class Initialized
INFO - 2016-07-05 22:41:48 --> Controller Class Initialized
DEBUG - 2016-07-05 22:41:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:41:48 --> Model Class Initialized
INFO - 2016-07-05 22:41:48 --> Model Class Initialized
INFO - 2016-07-05 22:41:48 --> Model Class Initialized
INFO - 2016-07-05 22:41:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:41:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:41:48 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:41:48 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:42:07 --> Config Class Initialized
INFO - 2016-07-05 22:42:07 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:42:07 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:42:07 --> Utf8 Class Initialized
INFO - 2016-07-05 22:42:08 --> URI Class Initialized
INFO - 2016-07-05 22:42:08 --> Router Class Initialized
INFO - 2016-07-05 22:42:08 --> Output Class Initialized
INFO - 2016-07-05 22:42:08 --> Security Class Initialized
DEBUG - 2016-07-05 22:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:42:08 --> Input Class Initialized
INFO - 2016-07-05 22:42:08 --> Language Class Initialized
INFO - 2016-07-05 22:42:08 --> Loader Class Initialized
INFO - 2016-07-05 22:42:08 --> Helper loaded: url_helper
INFO - 2016-07-05 22:42:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:42:08 --> Helper loaded: html_helper
INFO - 2016-07-05 22:42:08 --> Helper loaded: form_helper
INFO - 2016-07-05 22:42:08 --> Helper loaded: file_helper
INFO - 2016-07-05 22:42:08 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:42:08 --> Database Driver Class Initialized
INFO - 2016-07-05 22:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:42:08 --> Form Validation Class Initialized
INFO - 2016-07-05 22:42:08 --> Email Class Initialized
INFO - 2016-07-05 22:42:08 --> Controller Class Initialized
DEBUG - 2016-07-05 22:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:42:08 --> Model Class Initialized
INFO - 2016-07-05 22:42:08 --> Model Class Initialized
INFO - 2016-07-05 22:42:08 --> Model Class Initialized
INFO - 2016-07-05 22:42:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:42:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:42:08 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:42:08 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:42:58 --> Config Class Initialized
INFO - 2016-07-05 22:42:58 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:42:58 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:42:58 --> Utf8 Class Initialized
INFO - 2016-07-05 22:42:58 --> URI Class Initialized
INFO - 2016-07-05 22:42:58 --> Router Class Initialized
INFO - 2016-07-05 22:42:58 --> Output Class Initialized
INFO - 2016-07-05 22:42:58 --> Security Class Initialized
DEBUG - 2016-07-05 22:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:42:58 --> Input Class Initialized
INFO - 2016-07-05 22:42:58 --> Language Class Initialized
INFO - 2016-07-05 22:42:58 --> Loader Class Initialized
INFO - 2016-07-05 22:42:58 --> Helper loaded: url_helper
INFO - 2016-07-05 22:42:58 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:42:58 --> Helper loaded: html_helper
INFO - 2016-07-05 22:42:58 --> Helper loaded: form_helper
INFO - 2016-07-05 22:42:58 --> Helper loaded: file_helper
INFO - 2016-07-05 22:42:58 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:42:59 --> Database Driver Class Initialized
INFO - 2016-07-05 22:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:42:59 --> Form Validation Class Initialized
INFO - 2016-07-05 22:42:59 --> Email Class Initialized
INFO - 2016-07-05 22:42:59 --> Controller Class Initialized
DEBUG - 2016-07-05 22:42:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:42:59 --> Model Class Initialized
INFO - 2016-07-05 22:42:59 --> Model Class Initialized
INFO - 2016-07-05 22:42:59 --> Model Class Initialized
INFO - 2016-07-05 22:42:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:42:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:42:59 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:42:59 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:42:59 --> Severity: Notice --> Array to string conversion D:\wamp\www\pnc-library\application\controllers\Books.php 224
INFO - 2016-07-05 22:44:08 --> Config Class Initialized
INFO - 2016-07-05 22:44:08 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:44:08 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:44:08 --> Utf8 Class Initialized
INFO - 2016-07-05 22:44:08 --> URI Class Initialized
INFO - 2016-07-05 22:44:08 --> Router Class Initialized
INFO - 2016-07-05 22:44:08 --> Output Class Initialized
INFO - 2016-07-05 22:44:08 --> Security Class Initialized
DEBUG - 2016-07-05 22:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:44:08 --> Input Class Initialized
INFO - 2016-07-05 22:44:08 --> Language Class Initialized
INFO - 2016-07-05 22:44:08 --> Loader Class Initialized
INFO - 2016-07-05 22:44:08 --> Helper loaded: url_helper
INFO - 2016-07-05 22:44:08 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:44:08 --> Helper loaded: html_helper
INFO - 2016-07-05 22:44:08 --> Helper loaded: form_helper
INFO - 2016-07-05 22:44:08 --> Helper loaded: file_helper
INFO - 2016-07-05 22:44:08 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:44:08 --> Database Driver Class Initialized
INFO - 2016-07-05 22:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:44:09 --> Form Validation Class Initialized
INFO - 2016-07-05 22:44:09 --> Email Class Initialized
INFO - 2016-07-05 22:44:09 --> Controller Class Initialized
DEBUG - 2016-07-05 22:44:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:44:09 --> Model Class Initialized
INFO - 2016-07-05 22:44:09 --> Model Class Initialized
INFO - 2016-07-05 22:44:09 --> Model Class Initialized
INFO - 2016-07-05 22:44:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:44:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:44:09 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:44:09 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:50:22 --> Config Class Initialized
INFO - 2016-07-05 22:50:22 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:50:22 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:50:22 --> Utf8 Class Initialized
INFO - 2016-07-05 22:50:22 --> URI Class Initialized
INFO - 2016-07-05 22:50:22 --> Router Class Initialized
INFO - 2016-07-05 22:50:22 --> Output Class Initialized
INFO - 2016-07-05 22:50:22 --> Security Class Initialized
DEBUG - 2016-07-05 22:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:50:22 --> Input Class Initialized
INFO - 2016-07-05 22:50:22 --> Language Class Initialized
INFO - 2016-07-05 22:50:22 --> Loader Class Initialized
INFO - 2016-07-05 22:50:22 --> Helper loaded: url_helper
INFO - 2016-07-05 22:50:22 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:50:22 --> Helper loaded: html_helper
INFO - 2016-07-05 22:50:22 --> Helper loaded: form_helper
INFO - 2016-07-05 22:50:22 --> Helper loaded: file_helper
INFO - 2016-07-05 22:50:22 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:50:22 --> Database Driver Class Initialized
INFO - 2016-07-05 22:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:50:22 --> Form Validation Class Initialized
INFO - 2016-07-05 22:50:22 --> Email Class Initialized
INFO - 2016-07-05 22:50:22 --> Controller Class Initialized
DEBUG - 2016-07-05 22:50:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:50:22 --> Model Class Initialized
INFO - 2016-07-05 22:50:22 --> Model Class Initialized
INFO - 2016-07-05 22:50:22 --> Model Class Initialized
INFO - 2016-07-05 22:50:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:50:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:50:22 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:50:22 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:52:00 --> Config Class Initialized
INFO - 2016-07-05 22:52:00 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:52:00 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:52:00 --> Utf8 Class Initialized
INFO - 2016-07-05 22:52:00 --> URI Class Initialized
INFO - 2016-07-05 22:52:00 --> Router Class Initialized
INFO - 2016-07-05 22:52:00 --> Output Class Initialized
INFO - 2016-07-05 22:52:00 --> Security Class Initialized
DEBUG - 2016-07-05 22:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:52:00 --> Input Class Initialized
INFO - 2016-07-05 22:52:00 --> Language Class Initialized
INFO - 2016-07-05 22:52:00 --> Loader Class Initialized
INFO - 2016-07-05 22:52:00 --> Helper loaded: url_helper
INFO - 2016-07-05 22:52:01 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:52:01 --> Helper loaded: html_helper
INFO - 2016-07-05 22:52:01 --> Helper loaded: form_helper
INFO - 2016-07-05 22:52:01 --> Helper loaded: file_helper
INFO - 2016-07-05 22:52:01 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:52:01 --> Database Driver Class Initialized
INFO - 2016-07-05 22:52:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:52:01 --> Form Validation Class Initialized
INFO - 2016-07-05 22:52:01 --> Email Class Initialized
INFO - 2016-07-05 22:52:01 --> Controller Class Initialized
DEBUG - 2016-07-05 22:52:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:52:01 --> Model Class Initialized
INFO - 2016-07-05 22:52:01 --> Model Class Initialized
INFO - 2016-07-05 22:52:01 --> Model Class Initialized
INFO - 2016-07-05 22:52:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:52:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:52:01 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:52:01 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:52:01 --> Severity: Notice --> Undefined variable: db_object D:\wamp\www\pnc-library\application\models\category_model.php 36
ERROR - 2016-07-05 22:52:01 --> Severity: Error --> Call to a member function num_rows() on a non-object D:\wamp\www\pnc-library\application\models\category_model.php 36
INFO - 2016-07-05 22:52:20 --> Config Class Initialized
INFO - 2016-07-05 22:52:20 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:52:20 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:52:20 --> Utf8 Class Initialized
INFO - 2016-07-05 22:52:20 --> URI Class Initialized
INFO - 2016-07-05 22:52:20 --> Router Class Initialized
INFO - 2016-07-05 22:52:20 --> Output Class Initialized
INFO - 2016-07-05 22:52:20 --> Security Class Initialized
DEBUG - 2016-07-05 22:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:52:20 --> Input Class Initialized
INFO - 2016-07-05 22:52:20 --> Language Class Initialized
INFO - 2016-07-05 22:52:20 --> Loader Class Initialized
INFO - 2016-07-05 22:52:20 --> Helper loaded: url_helper
INFO - 2016-07-05 22:52:20 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:52:20 --> Helper loaded: html_helper
INFO - 2016-07-05 22:52:20 --> Helper loaded: form_helper
INFO - 2016-07-05 22:52:20 --> Helper loaded: file_helper
INFO - 2016-07-05 22:52:20 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:52:20 --> Database Driver Class Initialized
INFO - 2016-07-05 22:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:52:20 --> Form Validation Class Initialized
INFO - 2016-07-05 22:52:20 --> Email Class Initialized
INFO - 2016-07-05 22:52:20 --> Controller Class Initialized
DEBUG - 2016-07-05 22:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:52:20 --> Model Class Initialized
INFO - 2016-07-05 22:52:20 --> Model Class Initialized
INFO - 2016-07-05 22:52:20 --> Model Class Initialized
INFO - 2016-07-05 22:52:20 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:52:20 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:52:20 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:52:20 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:52:27 --> Config Class Initialized
INFO - 2016-07-05 22:52:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:52:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:52:27 --> Utf8 Class Initialized
INFO - 2016-07-05 22:52:27 --> URI Class Initialized
INFO - 2016-07-05 22:52:27 --> Router Class Initialized
INFO - 2016-07-05 22:52:27 --> Output Class Initialized
INFO - 2016-07-05 22:52:27 --> Security Class Initialized
DEBUG - 2016-07-05 22:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:52:27 --> Input Class Initialized
INFO - 2016-07-05 22:52:27 --> Language Class Initialized
INFO - 2016-07-05 22:52:27 --> Loader Class Initialized
INFO - 2016-07-05 22:52:27 --> Helper loaded: url_helper
INFO - 2016-07-05 22:52:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:52:27 --> Helper loaded: html_helper
INFO - 2016-07-05 22:52:27 --> Helper loaded: form_helper
INFO - 2016-07-05 22:52:27 --> Helper loaded: file_helper
INFO - 2016-07-05 22:52:27 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:52:27 --> Database Driver Class Initialized
INFO - 2016-07-05 22:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:52:27 --> Form Validation Class Initialized
INFO - 2016-07-05 22:52:27 --> Email Class Initialized
INFO - 2016-07-05 22:52:27 --> Controller Class Initialized
DEBUG - 2016-07-05 22:52:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:52:27 --> Model Class Initialized
INFO - 2016-07-05 22:52:27 --> Model Class Initialized
INFO - 2016-07-05 22:52:27 --> Model Class Initialized
INFO - 2016-07-05 22:52:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:52:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:52:27 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:52:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:52:27 --> Severity: Notice --> Undefined variable: db_object D:\wamp\www\pnc-library\application\models\category_model.php 40
ERROR - 2016-07-05 22:52:27 --> Severity: Error --> Call to a member function result_array() on a non-object D:\wamp\www\pnc-library\application\models\category_model.php 40
INFO - 2016-07-05 22:52:43 --> Config Class Initialized
INFO - 2016-07-05 22:52:43 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:52:43 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:52:43 --> Utf8 Class Initialized
INFO - 2016-07-05 22:52:43 --> URI Class Initialized
INFO - 2016-07-05 22:52:43 --> Router Class Initialized
INFO - 2016-07-05 22:52:43 --> Output Class Initialized
INFO - 2016-07-05 22:52:43 --> Security Class Initialized
DEBUG - 2016-07-05 22:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:52:43 --> Input Class Initialized
INFO - 2016-07-05 22:52:43 --> Language Class Initialized
INFO - 2016-07-05 22:52:43 --> Loader Class Initialized
INFO - 2016-07-05 22:52:43 --> Helper loaded: url_helper
INFO - 2016-07-05 22:52:44 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:52:44 --> Helper loaded: html_helper
INFO - 2016-07-05 22:52:44 --> Helper loaded: form_helper
INFO - 2016-07-05 22:52:44 --> Helper loaded: file_helper
INFO - 2016-07-05 22:52:44 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:52:44 --> Database Driver Class Initialized
INFO - 2016-07-05 22:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:52:44 --> Form Validation Class Initialized
INFO - 2016-07-05 22:52:44 --> Email Class Initialized
INFO - 2016-07-05 22:52:44 --> Controller Class Initialized
DEBUG - 2016-07-05 22:52:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:52:44 --> Model Class Initialized
INFO - 2016-07-05 22:52:44 --> Model Class Initialized
INFO - 2016-07-05 22:52:44 --> Model Class Initialized
INFO - 2016-07-05 22:52:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:52:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:52:44 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:52:44 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:53:13 --> Config Class Initialized
INFO - 2016-07-05 22:53:13 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:53:13 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:53:13 --> Utf8 Class Initialized
INFO - 2016-07-05 22:53:13 --> URI Class Initialized
INFO - 2016-07-05 22:53:13 --> Router Class Initialized
INFO - 2016-07-05 22:53:13 --> Output Class Initialized
INFO - 2016-07-05 22:53:13 --> Security Class Initialized
DEBUG - 2016-07-05 22:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:53:13 --> Input Class Initialized
INFO - 2016-07-05 22:53:13 --> Language Class Initialized
INFO - 2016-07-05 22:53:13 --> Loader Class Initialized
INFO - 2016-07-05 22:53:14 --> Helper loaded: url_helper
INFO - 2016-07-05 22:53:14 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:53:14 --> Helper loaded: html_helper
INFO - 2016-07-05 22:53:14 --> Helper loaded: form_helper
INFO - 2016-07-05 22:53:14 --> Helper loaded: file_helper
INFO - 2016-07-05 22:53:14 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:53:14 --> Database Driver Class Initialized
INFO - 2016-07-05 22:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:53:14 --> Form Validation Class Initialized
INFO - 2016-07-05 22:53:14 --> Email Class Initialized
INFO - 2016-07-05 22:53:14 --> Controller Class Initialized
DEBUG - 2016-07-05 22:53:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:53:14 --> Model Class Initialized
INFO - 2016-07-05 22:53:14 --> Model Class Initialized
INFO - 2016-07-05 22:53:14 --> Model Class Initialized
INFO - 2016-07-05 22:53:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:53:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:53:14 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:53:14 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:53:49 --> Config Class Initialized
INFO - 2016-07-05 22:53:49 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:53:49 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:53:49 --> Utf8 Class Initialized
INFO - 2016-07-05 22:53:49 --> URI Class Initialized
INFO - 2016-07-05 22:53:49 --> Router Class Initialized
INFO - 2016-07-05 22:53:49 --> Output Class Initialized
INFO - 2016-07-05 22:53:49 --> Security Class Initialized
DEBUG - 2016-07-05 22:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:53:49 --> Input Class Initialized
INFO - 2016-07-05 22:53:49 --> Language Class Initialized
INFO - 2016-07-05 22:53:49 --> Loader Class Initialized
INFO - 2016-07-05 22:53:49 --> Helper loaded: url_helper
INFO - 2016-07-05 22:53:49 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:53:49 --> Helper loaded: html_helper
INFO - 2016-07-05 22:53:49 --> Helper loaded: form_helper
INFO - 2016-07-05 22:53:49 --> Helper loaded: file_helper
INFO - 2016-07-05 22:53:49 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:53:49 --> Database Driver Class Initialized
INFO - 2016-07-05 22:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:53:49 --> Form Validation Class Initialized
INFO - 2016-07-05 22:53:49 --> Email Class Initialized
INFO - 2016-07-05 22:53:49 --> Controller Class Initialized
DEBUG - 2016-07-05 22:53:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:53:49 --> Model Class Initialized
INFO - 2016-07-05 22:53:49 --> Model Class Initialized
INFO - 2016-07-05 22:53:49 --> Model Class Initialized
INFO - 2016-07-05 22:53:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:53:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:53:49 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:53:49 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:54:46 --> Config Class Initialized
INFO - 2016-07-05 22:54:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:54:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:54:47 --> Utf8 Class Initialized
INFO - 2016-07-05 22:54:47 --> URI Class Initialized
INFO - 2016-07-05 22:54:47 --> Router Class Initialized
INFO - 2016-07-05 22:54:47 --> Output Class Initialized
INFO - 2016-07-05 22:54:47 --> Security Class Initialized
DEBUG - 2016-07-05 22:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:54:47 --> Input Class Initialized
INFO - 2016-07-05 22:54:47 --> Language Class Initialized
INFO - 2016-07-05 22:54:47 --> Loader Class Initialized
INFO - 2016-07-05 22:54:47 --> Helper loaded: url_helper
INFO - 2016-07-05 22:54:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:54:47 --> Helper loaded: html_helper
INFO - 2016-07-05 22:54:47 --> Helper loaded: form_helper
INFO - 2016-07-05 22:54:47 --> Helper loaded: file_helper
INFO - 2016-07-05 22:54:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:54:47 --> Database Driver Class Initialized
INFO - 2016-07-05 22:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:54:47 --> Form Validation Class Initialized
INFO - 2016-07-05 22:54:47 --> Email Class Initialized
INFO - 2016-07-05 22:54:47 --> Controller Class Initialized
DEBUG - 2016-07-05 22:54:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:54:47 --> Model Class Initialized
INFO - 2016-07-05 22:54:47 --> Model Class Initialized
INFO - 2016-07-05 22:54:47 --> Model Class Initialized
INFO - 2016-07-05 22:54:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:54:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:54:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:54:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:55:18 --> Config Class Initialized
INFO - 2016-07-05 22:55:18 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:55:18 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:55:19 --> Utf8 Class Initialized
INFO - 2016-07-05 22:55:19 --> URI Class Initialized
INFO - 2016-07-05 22:55:19 --> Router Class Initialized
INFO - 2016-07-05 22:55:19 --> Output Class Initialized
INFO - 2016-07-05 22:55:19 --> Security Class Initialized
DEBUG - 2016-07-05 22:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:55:19 --> Input Class Initialized
INFO - 2016-07-05 22:55:19 --> Language Class Initialized
INFO - 2016-07-05 22:55:19 --> Loader Class Initialized
INFO - 2016-07-05 22:55:19 --> Helper loaded: url_helper
INFO - 2016-07-05 22:55:19 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:55:19 --> Helper loaded: html_helper
INFO - 2016-07-05 22:55:19 --> Helper loaded: form_helper
INFO - 2016-07-05 22:55:19 --> Helper loaded: file_helper
INFO - 2016-07-05 22:55:19 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:55:19 --> Database Driver Class Initialized
INFO - 2016-07-05 22:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:55:19 --> Form Validation Class Initialized
INFO - 2016-07-05 22:55:19 --> Email Class Initialized
INFO - 2016-07-05 22:55:19 --> Controller Class Initialized
DEBUG - 2016-07-05 22:55:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:55:19 --> Model Class Initialized
INFO - 2016-07-05 22:55:19 --> Model Class Initialized
INFO - 2016-07-05 22:55:19 --> Model Class Initialized
INFO - 2016-07-05 22:55:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:55:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:55:19 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:55:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 22:55:57 --> Config Class Initialized
INFO - 2016-07-05 22:55:57 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:55:57 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:55:57 --> Utf8 Class Initialized
INFO - 2016-07-05 22:55:57 --> URI Class Initialized
INFO - 2016-07-05 22:55:57 --> Router Class Initialized
INFO - 2016-07-05 22:55:57 --> Output Class Initialized
INFO - 2016-07-05 22:55:57 --> Security Class Initialized
DEBUG - 2016-07-05 22:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:55:57 --> Input Class Initialized
INFO - 2016-07-05 22:55:57 --> Language Class Initialized
INFO - 2016-07-05 22:55:57 --> Loader Class Initialized
INFO - 2016-07-05 22:55:57 --> Helper loaded: url_helper
INFO - 2016-07-05 22:55:57 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:55:57 --> Helper loaded: html_helper
INFO - 2016-07-05 22:55:57 --> Helper loaded: form_helper
INFO - 2016-07-05 22:55:57 --> Helper loaded: file_helper
INFO - 2016-07-05 22:55:57 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:55:57 --> Database Driver Class Initialized
INFO - 2016-07-05 22:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:55:57 --> Form Validation Class Initialized
INFO - 2016-07-05 22:55:57 --> Email Class Initialized
INFO - 2016-07-05 22:55:57 --> Controller Class Initialized
DEBUG - 2016-07-05 22:55:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:55:57 --> Model Class Initialized
INFO - 2016-07-05 22:55:57 --> Model Class Initialized
INFO - 2016-07-05 22:55:57 --> Model Class Initialized
INFO - 2016-07-05 22:55:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:55:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:55:57 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:55:57 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 22:55:57 --> Severity: Notice --> Undefined variable: key D:\wamp\www\pnc-library\application\controllers\Books.php 221
INFO - 2016-07-05 22:57:06 --> Config Class Initialized
INFO - 2016-07-05 22:57:06 --> Hooks Class Initialized
DEBUG - 2016-07-05 22:57:06 --> UTF-8 Support Enabled
INFO - 2016-07-05 22:57:06 --> Utf8 Class Initialized
INFO - 2016-07-05 22:57:06 --> URI Class Initialized
INFO - 2016-07-05 22:57:06 --> Router Class Initialized
INFO - 2016-07-05 22:57:06 --> Output Class Initialized
INFO - 2016-07-05 22:57:06 --> Security Class Initialized
DEBUG - 2016-07-05 22:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 22:57:06 --> Input Class Initialized
INFO - 2016-07-05 22:57:06 --> Language Class Initialized
INFO - 2016-07-05 22:57:06 --> Loader Class Initialized
INFO - 2016-07-05 22:57:06 --> Helper loaded: url_helper
INFO - 2016-07-05 22:57:06 --> Helper loaded: utils_helper
INFO - 2016-07-05 22:57:06 --> Helper loaded: html_helper
INFO - 2016-07-05 22:57:06 --> Helper loaded: form_helper
INFO - 2016-07-05 22:57:06 --> Helper loaded: file_helper
INFO - 2016-07-05 22:57:06 --> Helper loaded: myemail_helper
INFO - 2016-07-05 22:57:06 --> Database Driver Class Initialized
INFO - 2016-07-05 22:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 22:57:06 --> Form Validation Class Initialized
INFO - 2016-07-05 22:57:06 --> Email Class Initialized
INFO - 2016-07-05 22:57:06 --> Controller Class Initialized
DEBUG - 2016-07-05 22:57:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 22:57:06 --> Model Class Initialized
INFO - 2016-07-05 22:57:06 --> Model Class Initialized
INFO - 2016-07-05 22:57:06 --> Model Class Initialized
INFO - 2016-07-05 22:57:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 22:57:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 22:57:06 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 22:57:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:08:27 --> Config Class Initialized
INFO - 2016-07-05 23:08:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:08:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:08:27 --> Utf8 Class Initialized
INFO - 2016-07-05 23:08:27 --> URI Class Initialized
INFO - 2016-07-05 23:08:27 --> Router Class Initialized
INFO - 2016-07-05 23:08:27 --> Output Class Initialized
INFO - 2016-07-05 23:08:27 --> Security Class Initialized
DEBUG - 2016-07-05 23:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:08:27 --> Input Class Initialized
INFO - 2016-07-05 23:08:27 --> Language Class Initialized
INFO - 2016-07-05 23:08:27 --> Loader Class Initialized
INFO - 2016-07-05 23:08:27 --> Helper loaded: url_helper
INFO - 2016-07-05 23:08:27 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:08:27 --> Helper loaded: html_helper
INFO - 2016-07-05 23:08:27 --> Helper loaded: form_helper
INFO - 2016-07-05 23:08:27 --> Helper loaded: file_helper
INFO - 2016-07-05 23:08:27 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:08:27 --> Database Driver Class Initialized
INFO - 2016-07-05 23:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:08:27 --> Form Validation Class Initialized
INFO - 2016-07-05 23:08:27 --> Email Class Initialized
INFO - 2016-07-05 23:08:27 --> Controller Class Initialized
DEBUG - 2016-07-05 23:08:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:08:27 --> Model Class Initialized
INFO - 2016-07-05 23:08:27 --> Model Class Initialized
INFO - 2016-07-05 23:08:27 --> Model Class Initialized
INFO - 2016-07-05 23:08:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:08:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:08:27 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:08:27 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:08:27 --> Severity: Notice --> Undefined property: Books::$books_model D:\wamp\www\pnc-library\application\controllers\Books.php 219
ERROR - 2016-07-05 23:08:27 --> Severity: Error --> Call to a member function getBookCondition() on a non-object D:\wamp\www\pnc-library\application\controllers\Books.php 219
INFO - 2016-07-05 23:09:12 --> Config Class Initialized
INFO - 2016-07-05 23:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:09:12 --> Utf8 Class Initialized
INFO - 2016-07-05 23:09:12 --> URI Class Initialized
INFO - 2016-07-05 23:09:12 --> Router Class Initialized
INFO - 2016-07-05 23:09:12 --> Output Class Initialized
INFO - 2016-07-05 23:09:12 --> Security Class Initialized
DEBUG - 2016-07-05 23:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:09:12 --> Input Class Initialized
INFO - 2016-07-05 23:09:12 --> Language Class Initialized
INFO - 2016-07-05 23:09:12 --> Loader Class Initialized
INFO - 2016-07-05 23:09:12 --> Helper loaded: url_helper
INFO - 2016-07-05 23:09:12 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:09:12 --> Helper loaded: html_helper
INFO - 2016-07-05 23:09:12 --> Helper loaded: form_helper
INFO - 2016-07-05 23:09:12 --> Helper loaded: file_helper
INFO - 2016-07-05 23:09:12 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:09:12 --> Database Driver Class Initialized
INFO - 2016-07-05 23:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:09:12 --> Form Validation Class Initialized
INFO - 2016-07-05 23:09:12 --> Email Class Initialized
INFO - 2016-07-05 23:09:12 --> Controller Class Initialized
DEBUG - 2016-07-05 23:09:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:09:12 --> Model Class Initialized
INFO - 2016-07-05 23:09:12 --> Model Class Initialized
INFO - 2016-07-05 23:09:12 --> Model Class Initialized
INFO - 2016-07-05 23:09:12 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:09:12 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:09:12 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:09:12 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:09:12 --> Final output sent to browser
DEBUG - 2016-07-05 23:09:12 --> Total execution time: 0.5222
INFO - 2016-07-05 23:09:18 --> Config Class Initialized
INFO - 2016-07-05 23:09:18 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:09:18 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:09:18 --> Utf8 Class Initialized
INFO - 2016-07-05 23:09:18 --> URI Class Initialized
INFO - 2016-07-05 23:09:18 --> Router Class Initialized
INFO - 2016-07-05 23:09:18 --> Output Class Initialized
INFO - 2016-07-05 23:09:18 --> Security Class Initialized
DEBUG - 2016-07-05 23:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:09:18 --> Input Class Initialized
INFO - 2016-07-05 23:09:18 --> Language Class Initialized
INFO - 2016-07-05 23:09:18 --> Loader Class Initialized
INFO - 2016-07-05 23:09:18 --> Helper loaded: url_helper
INFO - 2016-07-05 23:09:18 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:09:19 --> Helper loaded: html_helper
INFO - 2016-07-05 23:09:19 --> Helper loaded: form_helper
INFO - 2016-07-05 23:09:19 --> Helper loaded: file_helper
INFO - 2016-07-05 23:09:19 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:09:19 --> Database Driver Class Initialized
INFO - 2016-07-05 23:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:09:19 --> Form Validation Class Initialized
INFO - 2016-07-05 23:09:19 --> Email Class Initialized
INFO - 2016-07-05 23:09:19 --> Controller Class Initialized
DEBUG - 2016-07-05 23:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:09:19 --> Model Class Initialized
INFO - 2016-07-05 23:09:19 --> Model Class Initialized
INFO - 2016-07-05 23:09:19 --> Model Class Initialized
INFO - 2016-07-05 23:09:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:09:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:09:19 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:09:19 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:13:47 --> Config Class Initialized
INFO - 2016-07-05 23:13:47 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:13:47 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:13:47 --> Utf8 Class Initialized
INFO - 2016-07-05 23:13:47 --> URI Class Initialized
INFO - 2016-07-05 23:13:47 --> Router Class Initialized
INFO - 2016-07-05 23:13:47 --> Output Class Initialized
INFO - 2016-07-05 23:13:47 --> Security Class Initialized
DEBUG - 2016-07-05 23:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:13:47 --> Input Class Initialized
INFO - 2016-07-05 23:13:47 --> Language Class Initialized
INFO - 2016-07-05 23:13:47 --> Loader Class Initialized
INFO - 2016-07-05 23:13:47 --> Helper loaded: url_helper
INFO - 2016-07-05 23:13:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:13:47 --> Helper loaded: html_helper
INFO - 2016-07-05 23:13:47 --> Helper loaded: form_helper
INFO - 2016-07-05 23:13:47 --> Helper loaded: file_helper
INFO - 2016-07-05 23:13:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:13:47 --> Database Driver Class Initialized
INFO - 2016-07-05 23:13:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:13:47 --> Form Validation Class Initialized
INFO - 2016-07-05 23:13:47 --> Email Class Initialized
INFO - 2016-07-05 23:13:47 --> Controller Class Initialized
DEBUG - 2016-07-05 23:13:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:13:47 --> Model Class Initialized
INFO - 2016-07-05 23:13:47 --> Model Class Initialized
INFO - 2016-07-05 23:13:47 --> Model Class Initialized
INFO - 2016-07-05 23:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:13:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:13:47 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: INSERT INTO `bookss` (`auther`, `auther_kh`, `barcode`, `category_id`, `comment`, `condition`, `isbn`, `keywords`, `lable`, `language`, `publisher`, `title`, `title_kh`, `year`) VALUES ('Author(s)','Author(s) in Khmer','Barcode',0,'comment',0,'ISBN','Key Words (separated by ;)','Label','Language','Publisher','Titles','Titles in Khmer','Year'), ('Jon Naunton ; Mark Tulip','','2016070195',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Jon Naunton ; Mark Tulip','','2016070237',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Chheab Sakal','??? ????','2016070277',15,'',2,'No ISBN','Law','300 ???','Khmer','University of National Management','Contract Law','??????????????','2011'), ('Vicki Hollett','','2016070196',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('Vicki Hollett','','2016070182',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('American Academic Associates Ltd.','','',15,'',2,'','Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','300 AME','English','American Academic Associates Ltd.','Essential Business Communication Skills','','')
INFO - 2016-07-05 23:13:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:15:37 --> Config Class Initialized
INFO - 2016-07-05 23:15:38 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:15:38 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:15:38 --> Utf8 Class Initialized
INFO - 2016-07-05 23:15:38 --> URI Class Initialized
INFO - 2016-07-05 23:15:38 --> Router Class Initialized
INFO - 2016-07-05 23:15:38 --> Output Class Initialized
INFO - 2016-07-05 23:15:38 --> Security Class Initialized
DEBUG - 2016-07-05 23:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:15:38 --> Input Class Initialized
INFO - 2016-07-05 23:15:38 --> Language Class Initialized
INFO - 2016-07-05 23:15:38 --> Loader Class Initialized
INFO - 2016-07-05 23:15:38 --> Helper loaded: url_helper
INFO - 2016-07-05 23:15:38 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:15:38 --> Helper loaded: html_helper
INFO - 2016-07-05 23:15:38 --> Helper loaded: form_helper
INFO - 2016-07-05 23:15:38 --> Helper loaded: file_helper
INFO - 2016-07-05 23:15:38 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:15:38 --> Database Driver Class Initialized
INFO - 2016-07-05 23:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:15:38 --> Form Validation Class Initialized
INFO - 2016-07-05 23:15:38 --> Email Class Initialized
INFO - 2016-07-05 23:15:38 --> Controller Class Initialized
DEBUG - 2016-07-05 23:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:15:38 --> Model Class Initialized
INFO - 2016-07-05 23:15:38 --> Model Class Initialized
INFO - 2016-07-05 23:15:38 --> Model Class Initialized
INFO - 2016-07-05 23:15:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:15:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:15:38 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:15:38 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:15:38 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: INSERT INTO `bookss` (`auther`, `auther_kh`, `barcode`, `category_id`, `comment`, `condition`, `isbn`, `keywords`, `lable`, `language`, `publisher`, `title`, `title_kh`, `year`) VALUES ('Jon Naunton ; Mark Tulip','','2016070195',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Jon Naunton ; Mark Tulip','','2016070237',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Chheab Sakal','??? ????','2016070277',15,'',2,'No ISBN','Law','300 ???','Khmer','University of National Management','Contract Law','??????????????','2011'), ('Vicki Hollett','','2016070196',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('Vicki Hollett','','2016070182',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('American Academic Associates Ltd.','','',15,'',2,'','Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','300 AME','English','American Academic Associates Ltd.','Essential Business Communication Skills','','')
INFO - 2016-07-05 23:15:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:19:55 --> Config Class Initialized
INFO - 2016-07-05 23:19:55 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:19:55 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:19:55 --> Utf8 Class Initialized
INFO - 2016-07-05 23:19:55 --> URI Class Initialized
INFO - 2016-07-05 23:19:55 --> Router Class Initialized
INFO - 2016-07-05 23:19:55 --> Output Class Initialized
INFO - 2016-07-05 23:19:55 --> Security Class Initialized
DEBUG - 2016-07-05 23:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:19:55 --> Input Class Initialized
INFO - 2016-07-05 23:19:56 --> Language Class Initialized
INFO - 2016-07-05 23:19:56 --> Loader Class Initialized
INFO - 2016-07-05 23:19:56 --> Helper loaded: url_helper
INFO - 2016-07-05 23:19:56 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:19:56 --> Helper loaded: html_helper
INFO - 2016-07-05 23:19:56 --> Helper loaded: form_helper
INFO - 2016-07-05 23:19:56 --> Helper loaded: file_helper
INFO - 2016-07-05 23:19:56 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:19:56 --> Database Driver Class Initialized
INFO - 2016-07-05 23:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:19:56 --> Form Validation Class Initialized
INFO - 2016-07-05 23:19:56 --> Email Class Initialized
INFO - 2016-07-05 23:19:56 --> Controller Class Initialized
DEBUG - 2016-07-05 23:19:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:19:56 --> Model Class Initialized
INFO - 2016-07-05 23:19:56 --> Model Class Initialized
INFO - 2016-07-05 23:19:56 --> Model Class Initialized
INFO - 2016-07-05 23:19:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:19:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:19:56 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:19:56 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:20:38 --> Config Class Initialized
INFO - 2016-07-05 23:20:38 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:20:38 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:20:38 --> Utf8 Class Initialized
INFO - 2016-07-05 23:20:38 --> URI Class Initialized
INFO - 2016-07-05 23:20:38 --> Router Class Initialized
INFO - 2016-07-05 23:20:38 --> Output Class Initialized
INFO - 2016-07-05 23:20:38 --> Security Class Initialized
DEBUG - 2016-07-05 23:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:20:39 --> Input Class Initialized
INFO - 2016-07-05 23:20:39 --> Language Class Initialized
INFO - 2016-07-05 23:20:39 --> Loader Class Initialized
INFO - 2016-07-05 23:20:39 --> Helper loaded: url_helper
INFO - 2016-07-05 23:20:39 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:20:39 --> Helper loaded: html_helper
INFO - 2016-07-05 23:20:39 --> Helper loaded: form_helper
INFO - 2016-07-05 23:20:39 --> Helper loaded: file_helper
INFO - 2016-07-05 23:20:39 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:20:39 --> Database Driver Class Initialized
INFO - 2016-07-05 23:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:20:39 --> Form Validation Class Initialized
INFO - 2016-07-05 23:20:39 --> Email Class Initialized
INFO - 2016-07-05 23:20:39 --> Controller Class Initialized
DEBUG - 2016-07-05 23:20:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:20:39 --> Model Class Initialized
INFO - 2016-07-05 23:20:39 --> Model Class Initialized
INFO - 2016-07-05 23:20:39 --> Model Class Initialized
INFO - 2016-07-05 23:20:39 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:20:39 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:20:39 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:20:39 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:20:39 --> Final output sent to browser
DEBUG - 2016-07-05 23:20:39 --> Total execution time: 0.5448
INFO - 2016-07-05 23:20:42 --> Config Class Initialized
INFO - 2016-07-05 23:20:42 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:20:42 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:20:42 --> Utf8 Class Initialized
INFO - 2016-07-05 23:20:42 --> URI Class Initialized
INFO - 2016-07-05 23:20:42 --> Router Class Initialized
INFO - 2016-07-05 23:20:42 --> Output Class Initialized
INFO - 2016-07-05 23:20:42 --> Security Class Initialized
DEBUG - 2016-07-05 23:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:20:42 --> Input Class Initialized
INFO - 2016-07-05 23:20:43 --> Language Class Initialized
INFO - 2016-07-05 23:20:43 --> Loader Class Initialized
INFO - 2016-07-05 23:20:43 --> Helper loaded: url_helper
INFO - 2016-07-05 23:20:43 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:20:43 --> Helper loaded: html_helper
INFO - 2016-07-05 23:20:43 --> Helper loaded: form_helper
INFO - 2016-07-05 23:20:43 --> Helper loaded: file_helper
INFO - 2016-07-05 23:20:43 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:20:43 --> Database Driver Class Initialized
INFO - 2016-07-05 23:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:20:43 --> Form Validation Class Initialized
INFO - 2016-07-05 23:20:43 --> Email Class Initialized
INFO - 2016-07-05 23:20:43 --> Controller Class Initialized
DEBUG - 2016-07-05 23:20:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:20:43 --> Model Class Initialized
INFO - 2016-07-05 23:20:43 --> Model Class Initialized
INFO - 2016-07-05 23:20:43 --> Model Class Initialized
INFO - 2016-07-05 23:20:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:20:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:20:43 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:20:43 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:20:43 --> Final output sent to browser
DEBUG - 2016-07-05 23:20:43 --> Total execution time: 0.5265
INFO - 2016-07-05 23:20:46 --> Config Class Initialized
INFO - 2016-07-05 23:20:46 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:20:46 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:20:46 --> Utf8 Class Initialized
INFO - 2016-07-05 23:20:46 --> URI Class Initialized
INFO - 2016-07-05 23:20:46 --> Router Class Initialized
INFO - 2016-07-05 23:20:46 --> Output Class Initialized
INFO - 2016-07-05 23:20:47 --> Security Class Initialized
DEBUG - 2016-07-05 23:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:20:47 --> Input Class Initialized
INFO - 2016-07-05 23:20:47 --> Language Class Initialized
INFO - 2016-07-05 23:20:47 --> Loader Class Initialized
INFO - 2016-07-05 23:20:47 --> Helper loaded: url_helper
INFO - 2016-07-05 23:20:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:20:47 --> Helper loaded: html_helper
INFO - 2016-07-05 23:20:47 --> Helper loaded: form_helper
INFO - 2016-07-05 23:20:47 --> Helper loaded: file_helper
INFO - 2016-07-05 23:20:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:20:47 --> Database Driver Class Initialized
INFO - 2016-07-05 23:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:20:47 --> Form Validation Class Initialized
INFO - 2016-07-05 23:20:47 --> Email Class Initialized
INFO - 2016-07-05 23:20:47 --> Controller Class Initialized
DEBUG - 2016-07-05 23:20:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:20:47 --> Model Class Initialized
INFO - 2016-07-05 23:20:47 --> Model Class Initialized
INFO - 2016-07-05 23:20:47 --> Model Class Initialized
INFO - 2016-07-05 23:20:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:20:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:20:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:20:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:20:47 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: INSERT INTO `bookss` (`auther`, `auther_kh`, `barcode`, `category_id`, `comment`, `condition`, `isbn`, `keywords`, `lable`, `language`, `publisher`, `title`, `title_kh`, `year`) VALUES ('Jon Naunton ; Mark Tulip','','2016070195',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Jon Naunton ; Mark Tulip','','2016070237',15,'',2,'9780194575782','Business ; English ; Method','300 NAU','English','Oxford University Press','ProFile Pre-Intermediate','','2004'), ('Chheab Sakal','??? ????','2016070277',15,'',2,'No ISBN','Law','300 ???','Khmer','University of National Management','Contract Law','??????????????','2011'), ('Vicki Hollett','','2016070196',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('Vicki Hollett','','2016070182',15,'',2,'9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Oxford University Press','Business Opportunities','','1997'), ('American Academic Associates Ltd.','','',15,'',2,'','Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','300 AME','English','American Academic Associates Ltd.','Essential Business Communication Skills','','')
INFO - 2016-07-05 23:20:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:35:28 --> Config Class Initialized
INFO - 2016-07-05 23:35:28 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:35:28 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:35:28 --> Utf8 Class Initialized
INFO - 2016-07-05 23:35:28 --> URI Class Initialized
INFO - 2016-07-05 23:35:28 --> Router Class Initialized
INFO - 2016-07-05 23:35:28 --> Output Class Initialized
INFO - 2016-07-05 23:35:28 --> Security Class Initialized
DEBUG - 2016-07-05 23:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:35:28 --> Input Class Initialized
INFO - 2016-07-05 23:35:28 --> Language Class Initialized
INFO - 2016-07-05 23:35:28 --> Loader Class Initialized
INFO - 2016-07-05 23:35:28 --> Helper loaded: url_helper
INFO - 2016-07-05 23:35:28 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:35:28 --> Helper loaded: html_helper
INFO - 2016-07-05 23:35:28 --> Helper loaded: form_helper
INFO - 2016-07-05 23:35:28 --> Helper loaded: file_helper
INFO - 2016-07-05 23:35:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:35:28 --> Database Driver Class Initialized
INFO - 2016-07-05 23:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:35:28 --> Form Validation Class Initialized
INFO - 2016-07-05 23:35:28 --> Email Class Initialized
INFO - 2016-07-05 23:35:28 --> Controller Class Initialized
DEBUG - 2016-07-05 23:35:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:35:28 --> Model Class Initialized
INFO - 2016-07-05 23:35:28 --> Model Class Initialized
INFO - 2016-07-05 23:35:28 --> Model Class Initialized
INFO - 2016-07-05 23:35:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:35:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:35:29 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:35:29 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:35:29 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: INSERT INTO `bookss` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_lable`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `category_id`, `con_id`, `keywords`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'Law','University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','American Academic Associates Ltd.','','','','300 AME','English','Essential Business Communication Skills','','',15,2,'Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:35:29 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:36:06 --> Config Class Initialized
INFO - 2016-07-05 23:36:06 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:36:06 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:36:06 --> Utf8 Class Initialized
INFO - 2016-07-05 23:36:06 --> URI Class Initialized
INFO - 2016-07-05 23:36:06 --> Router Class Initialized
INFO - 2016-07-05 23:36:06 --> Output Class Initialized
INFO - 2016-07-05 23:36:06 --> Security Class Initialized
DEBUG - 2016-07-05 23:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:36:06 --> Input Class Initialized
INFO - 2016-07-05 23:36:06 --> Language Class Initialized
INFO - 2016-07-05 23:36:06 --> Loader Class Initialized
INFO - 2016-07-05 23:36:06 --> Helper loaded: url_helper
INFO - 2016-07-05 23:36:06 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:36:06 --> Helper loaded: html_helper
INFO - 2016-07-05 23:36:06 --> Helper loaded: form_helper
INFO - 2016-07-05 23:36:06 --> Helper loaded: file_helper
INFO - 2016-07-05 23:36:06 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:36:06 --> Database Driver Class Initialized
INFO - 2016-07-05 23:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:36:06 --> Form Validation Class Initialized
INFO - 2016-07-05 23:36:06 --> Email Class Initialized
INFO - 2016-07-05 23:36:06 --> Controller Class Initialized
DEBUG - 2016-07-05 23:36:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:36:06 --> Model Class Initialized
INFO - 2016-07-05 23:36:06 --> Model Class Initialized
INFO - 2016-07-05 23:36:06 --> Model Class Initialized
INFO - 2016-07-05 23:36:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:36:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:36:06 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:36:06 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:36:06 --> Query error: Unknown column 'b_lable' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_lable`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `category_id`, `con_id`, `keywords`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'Law','University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','American Academic Associates Ltd.','','','','300 AME','English','Essential Business Communication Skills','','',15,2,'Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:36:06 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:36:27 --> Config Class Initialized
INFO - 2016-07-05 23:36:27 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:36:27 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:36:27 --> Utf8 Class Initialized
INFO - 2016-07-05 23:36:27 --> URI Class Initialized
INFO - 2016-07-05 23:36:27 --> Router Class Initialized
INFO - 2016-07-05 23:36:27 --> Output Class Initialized
INFO - 2016-07-05 23:36:27 --> Security Class Initialized
DEBUG - 2016-07-05 23:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:36:27 --> Input Class Initialized
INFO - 2016-07-05 23:36:27 --> Language Class Initialized
INFO - 2016-07-05 23:36:28 --> Loader Class Initialized
INFO - 2016-07-05 23:36:28 --> Helper loaded: url_helper
INFO - 2016-07-05 23:36:28 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:36:28 --> Helper loaded: html_helper
INFO - 2016-07-05 23:36:28 --> Helper loaded: form_helper
INFO - 2016-07-05 23:36:28 --> Helper loaded: file_helper
INFO - 2016-07-05 23:36:28 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:36:28 --> Database Driver Class Initialized
INFO - 2016-07-05 23:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:36:28 --> Form Validation Class Initialized
INFO - 2016-07-05 23:36:28 --> Email Class Initialized
INFO - 2016-07-05 23:36:28 --> Controller Class Initialized
DEBUG - 2016-07-05 23:36:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:36:28 --> Model Class Initialized
INFO - 2016-07-05 23:36:28 --> Model Class Initialized
INFO - 2016-07-05 23:36:28 --> Model Class Initialized
INFO - 2016-07-05 23:36:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:36:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:36:28 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:36:28 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:36:28 --> Query error: Unknown column 'b_labl' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_labl`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `category_id`, `con_id`, `keywords`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'Law','University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','American Academic Associates Ltd.','','','','300 AME','English','Essential Business Communication Skills','','',15,2,'Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:36:28 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:36:45 --> Config Class Initialized
INFO - 2016-07-05 23:36:45 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:36:45 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:36:45 --> Utf8 Class Initialized
INFO - 2016-07-05 23:36:45 --> URI Class Initialized
INFO - 2016-07-05 23:36:45 --> Router Class Initialized
INFO - 2016-07-05 23:36:45 --> Output Class Initialized
INFO - 2016-07-05 23:36:45 --> Security Class Initialized
DEBUG - 2016-07-05 23:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:36:45 --> Input Class Initialized
INFO - 2016-07-05 23:36:45 --> Language Class Initialized
INFO - 2016-07-05 23:36:45 --> Loader Class Initialized
INFO - 2016-07-05 23:36:45 --> Helper loaded: url_helper
INFO - 2016-07-05 23:36:45 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:36:46 --> Helper loaded: html_helper
INFO - 2016-07-05 23:36:46 --> Helper loaded: form_helper
INFO - 2016-07-05 23:36:46 --> Helper loaded: file_helper
INFO - 2016-07-05 23:36:46 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:36:46 --> Database Driver Class Initialized
INFO - 2016-07-05 23:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:36:46 --> Form Validation Class Initialized
INFO - 2016-07-05 23:36:46 --> Email Class Initialized
INFO - 2016-07-05 23:36:46 --> Controller Class Initialized
DEBUG - 2016-07-05 23:36:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:36:46 --> Model Class Initialized
INFO - 2016-07-05 23:36:46 --> Model Class Initialized
INFO - 2016-07-05 23:36:46 --> Model Class Initialized
INFO - 2016-07-05 23:36:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:36:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:36:46 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:36:46 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:36:46 --> Query error: Unknown column 'category_id' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_label`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `category_id`, `con_id`, `keywords`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'Law','University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','American Academic Associates Ltd.','','','','300 AME','English','Essential Business Communication Skills','','',15,2,'Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:36:46 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:36:59 --> Config Class Initialized
INFO - 2016-07-05 23:36:59 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:36:59 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:36:59 --> Utf8 Class Initialized
INFO - 2016-07-05 23:36:59 --> URI Class Initialized
INFO - 2016-07-05 23:36:59 --> Router Class Initialized
INFO - 2016-07-05 23:36:59 --> Output Class Initialized
INFO - 2016-07-05 23:36:59 --> Security Class Initialized
DEBUG - 2016-07-05 23:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:36:59 --> Input Class Initialized
INFO - 2016-07-05 23:36:59 --> Language Class Initialized
INFO - 2016-07-05 23:36:59 --> Loader Class Initialized
INFO - 2016-07-05 23:36:59 --> Helper loaded: url_helper
INFO - 2016-07-05 23:36:59 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:36:59 --> Helper loaded: html_helper
INFO - 2016-07-05 23:36:59 --> Helper loaded: form_helper
INFO - 2016-07-05 23:36:59 --> Helper loaded: file_helper
INFO - 2016-07-05 23:36:59 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:36:59 --> Database Driver Class Initialized
INFO - 2016-07-05 23:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:36:59 --> Form Validation Class Initialized
INFO - 2016-07-05 23:36:59 --> Email Class Initialized
INFO - 2016-07-05 23:37:00 --> Controller Class Initialized
DEBUG - 2016-07-05 23:37:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:37:00 --> Model Class Initialized
INFO - 2016-07-05 23:37:00 --> Model Class Initialized
INFO - 2016-07-05 23:37:00 --> Model Class Initialized
INFO - 2016-07-05 23:37:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:37:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:37:00 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:37:00 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:37:00 --> Query error: Unknown column 'keywords' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_label`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `cat_id`, `con_id`, `keywords`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Business ; English ; Method','Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'Law','University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','300 HOL','English','Business Opportunities','','1997',15,2,'Business ; English ; Method ; Opportunities','Oxford University Press',1), ('','American Academic Associates Ltd.','','','','300 AME','English','Essential Business Communication Skills','','',15,2,'Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:37:00 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:37:21 --> Config Class Initialized
INFO - 2016-07-05 23:37:21 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:37:21 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:37:21 --> Utf8 Class Initialized
INFO - 2016-07-05 23:37:21 --> URI Class Initialized
INFO - 2016-07-05 23:37:21 --> Router Class Initialized
INFO - 2016-07-05 23:37:21 --> Output Class Initialized
INFO - 2016-07-05 23:37:21 --> Security Class Initialized
DEBUG - 2016-07-05 23:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:37:21 --> Input Class Initialized
INFO - 2016-07-05 23:37:21 --> Language Class Initialized
INFO - 2016-07-05 23:37:21 --> Loader Class Initialized
INFO - 2016-07-05 23:37:21 --> Helper loaded: url_helper
INFO - 2016-07-05 23:37:21 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:37:21 --> Helper loaded: html_helper
INFO - 2016-07-05 23:37:21 --> Helper loaded: form_helper
INFO - 2016-07-05 23:37:21 --> Helper loaded: file_helper
INFO - 2016-07-05 23:37:21 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:37:21 --> Database Driver Class Initialized
INFO - 2016-07-05 23:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:37:21 --> Form Validation Class Initialized
INFO - 2016-07-05 23:37:21 --> Email Class Initialized
INFO - 2016-07-05 23:37:21 --> Controller Class Initialized
DEBUG - 2016-07-05 23:37:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:37:21 --> Model Class Initialized
INFO - 2016-07-05 23:37:21 --> Model Class Initialized
INFO - 2016-07-05 23:37:21 --> Model Class Initialized
INFO - 2016-07-05 23:37:21 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:37:21 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:37:21 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:37:21 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
ERROR - 2016-07-05 23:37:21 --> Query error: Unknown column 'publisher' in 'field list' - Invalid query: INSERT INTO `books` (`b_auther_kh`, `b_author`, `b_barcode`, `b_comment`, `b_isbn`, `b_keyword`, `b_label`, `b_language`, `b_title_en`, `b_title_kh`, `b_year`, `cat_id`, `con_id`, `publisher`, `sta_id`) VALUES ('','Jon Naunton ; Mark Tulip','2016070195','','9780194575782','Business ; English ; Method','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Oxford University Press',1), ('','Jon Naunton ; Mark Tulip','2016070237','','9780194575782','Business ; English ; Method','300 NAU','English','ProFile Pre-Intermediate','','2004',15,2,'Oxford University Press',1), ('??? ????','Chheab Sakal','2016070277','','No ISBN','Law','300 ???','Khmer','Contract Law','??????????????','2011',15,2,'University of National Management',1), ('','Vicki Hollett','2016070196','','9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Business Opportunities','','1997',15,2,'Oxford University Press',1), ('','Vicki Hollett','2016070182','','9780194520285','Business ; English ; Method ; Opportunities','300 HOL','English','Business Opportunities','','1997',15,2,'Oxford University Press',1), ('','American Academic Associates Ltd.','','','','Business ; Communication ; Skills ; Presentation ; Telephone ; Negotiation ; Meeting','300 AME','English','Essential Business Communication Skills','','',15,2,'American Academic Associates Ltd.',1)
INFO - 2016-07-05 23:37:21 --> Language file loaded: language/english/db_lang.php
INFO - 2016-07-05 23:37:40 --> Config Class Initialized
INFO - 2016-07-05 23:37:40 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:37:40 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:37:40 --> Utf8 Class Initialized
INFO - 2016-07-05 23:37:40 --> URI Class Initialized
INFO - 2016-07-05 23:37:40 --> Router Class Initialized
INFO - 2016-07-05 23:37:40 --> Output Class Initialized
INFO - 2016-07-05 23:37:40 --> Security Class Initialized
DEBUG - 2016-07-05 23:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:37:40 --> Input Class Initialized
INFO - 2016-07-05 23:37:40 --> Language Class Initialized
INFO - 2016-07-05 23:37:40 --> Loader Class Initialized
INFO - 2016-07-05 23:37:40 --> Helper loaded: url_helper
INFO - 2016-07-05 23:37:40 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:37:40 --> Helper loaded: html_helper
INFO - 2016-07-05 23:37:40 --> Helper loaded: form_helper
INFO - 2016-07-05 23:37:40 --> Helper loaded: file_helper
INFO - 2016-07-05 23:37:40 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:37:40 --> Database Driver Class Initialized
INFO - 2016-07-05 23:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:37:40 --> Form Validation Class Initialized
INFO - 2016-07-05 23:37:40 --> Email Class Initialized
INFO - 2016-07-05 23:37:40 --> Controller Class Initialized
DEBUG - 2016-07-05 23:37:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:37:40 --> Model Class Initialized
INFO - 2016-07-05 23:37:40 --> Model Class Initialized
INFO - 2016-07-05 23:37:40 --> Model Class Initialized
INFO - 2016-07-05 23:37:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:37:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:37:40 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:37:40 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:37:40 --> Final output sent to browser
DEBUG - 2016-07-05 23:37:40 --> Total execution time: 0.6036
INFO - 2016-07-05 23:40:35 --> Config Class Initialized
INFO - 2016-07-05 23:40:35 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:40:35 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:40:35 --> Utf8 Class Initialized
INFO - 2016-07-05 23:40:35 --> URI Class Initialized
INFO - 2016-07-05 23:40:35 --> Router Class Initialized
INFO - 2016-07-05 23:40:35 --> Output Class Initialized
INFO - 2016-07-05 23:40:35 --> Security Class Initialized
DEBUG - 2016-07-05 23:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:40:35 --> Input Class Initialized
INFO - 2016-07-05 23:40:35 --> Language Class Initialized
INFO - 2016-07-05 23:40:35 --> Loader Class Initialized
INFO - 2016-07-05 23:40:35 --> Helper loaded: url_helper
INFO - 2016-07-05 23:40:35 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:40:35 --> Helper loaded: html_helper
INFO - 2016-07-05 23:40:35 --> Helper loaded: form_helper
INFO - 2016-07-05 23:40:35 --> Helper loaded: file_helper
INFO - 2016-07-05 23:40:35 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:40:35 --> Database Driver Class Initialized
INFO - 2016-07-05 23:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:40:35 --> Form Validation Class Initialized
INFO - 2016-07-05 23:40:35 --> Email Class Initialized
INFO - 2016-07-05 23:40:35 --> Controller Class Initialized
DEBUG - 2016-07-05 23:40:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:40:35 --> Model Class Initialized
INFO - 2016-07-05 23:40:35 --> Model Class Initialized
INFO - 2016-07-05 23:40:35 --> Model Class Initialized
INFO - 2016-07-05 23:40:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:40:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:40:35 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:40:35 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
INFO - 2016-07-05 23:40:36 --> Final output sent to browser
DEBUG - 2016-07-05 23:40:36 --> Total execution time: 1.2395
INFO - 2016-07-05 23:41:46 --> Config Class Initialized
INFO - 2016-07-05 23:41:46 --> Hooks Class Initialized
DEBUG - 2016-07-05 23:41:46 --> UTF-8 Support Enabled
INFO - 2016-07-05 23:41:46 --> Utf8 Class Initialized
INFO - 2016-07-05 23:41:46 --> URI Class Initialized
INFO - 2016-07-05 23:41:46 --> Router Class Initialized
INFO - 2016-07-05 23:41:46 --> Output Class Initialized
INFO - 2016-07-05 23:41:47 --> Security Class Initialized
DEBUG - 2016-07-05 23:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-05 23:41:47 --> Input Class Initialized
INFO - 2016-07-05 23:41:47 --> Language Class Initialized
INFO - 2016-07-05 23:41:47 --> Loader Class Initialized
INFO - 2016-07-05 23:41:47 --> Helper loaded: url_helper
INFO - 2016-07-05 23:41:47 --> Helper loaded: utils_helper
INFO - 2016-07-05 23:41:47 --> Helper loaded: html_helper
INFO - 2016-07-05 23:41:47 --> Helper loaded: form_helper
INFO - 2016-07-05 23:41:47 --> Helper loaded: file_helper
INFO - 2016-07-05 23:41:47 --> Helper loaded: myemail_helper
INFO - 2016-07-05 23:41:47 --> Database Driver Class Initialized
INFO - 2016-07-05 23:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-05 23:41:47 --> Form Validation Class Initialized
INFO - 2016-07-05 23:41:47 --> Email Class Initialized
INFO - 2016-07-05 23:41:47 --> Controller Class Initialized
DEBUG - 2016-07-05 23:41:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-05 23:41:47 --> Model Class Initialized
INFO - 2016-07-05 23:41:47 --> Model Class Initialized
INFO - 2016-07-05 23:41:47 --> Model Class Initialized
INFO - 2016-07-05 23:41:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/header.php
INFO - 2016-07-05 23:41:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/menu.php
INFO - 2016-07-05 23:41:47 --> File loaded: D:\wamp\www\pnc-library\application\views\books/import_book.php
INFO - 2016-07-05 23:41:47 --> File loaded: D:\wamp\www\pnc-library\application\views\templates/footer.php
