<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-30 01:56:45 --> Config Class Initialized
INFO - 2016-08-30 01:56:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 01:56:45 --> UTF-8 Support Enabled
INFO - 2016-08-30 01:56:45 --> Utf8 Class Initialized
INFO - 2016-08-30 01:56:45 --> URI Class Initialized
INFO - 2016-08-30 01:56:45 --> Router Class Initialized
INFO - 2016-08-30 01:56:45 --> Output Class Initialized
INFO - 2016-08-30 01:56:45 --> Security Class Initialized
DEBUG - 2016-08-30 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 01:56:45 --> Input Class Initialized
INFO - 2016-08-30 01:56:45 --> Language Class Initialized
INFO - 2016-08-30 01:56:46 --> Loader Class Initialized
INFO - 2016-08-30 01:56:46 --> Helper loaded: url_helper
INFO - 2016-08-30 01:56:46 --> Helper loaded: utils_helper
INFO - 2016-08-30 01:56:46 --> Helper loaded: html_helper
INFO - 2016-08-30 01:56:46 --> Helper loaded: form_helper
INFO - 2016-08-30 01:56:46 --> Helper loaded: file_helper
INFO - 2016-08-30 01:56:46 --> Helper loaded: myemail_helper
INFO - 2016-08-30 01:56:46 --> Database Driver Class Initialized
INFO - 2016-08-30 01:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 01:56:46 --> Form Validation Class Initialized
INFO - 2016-08-30 01:56:46 --> Email Class Initialized
INFO - 2016-08-30 01:56:46 --> Controller Class Initialized
INFO - 2016-08-30 01:56:48 --> Config Class Initialized
INFO - 2016-08-30 01:56:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 01:56:48 --> UTF-8 Support Enabled
INFO - 2016-08-30 01:56:48 --> Utf8 Class Initialized
INFO - 2016-08-30 01:56:48 --> URI Class Initialized
INFO - 2016-08-30 01:56:48 --> Router Class Initialized
INFO - 2016-08-30 01:56:48 --> Output Class Initialized
INFO - 2016-08-30 01:56:48 --> Security Class Initialized
DEBUG - 2016-08-30 01:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 01:56:48 --> Input Class Initialized
INFO - 2016-08-30 01:56:48 --> Language Class Initialized
INFO - 2016-08-30 01:56:48 --> Loader Class Initialized
INFO - 2016-08-30 01:56:48 --> Helper loaded: url_helper
INFO - 2016-08-30 01:56:48 --> Helper loaded: utils_helper
INFO - 2016-08-30 01:56:48 --> Helper loaded: html_helper
INFO - 2016-08-30 01:56:48 --> Helper loaded: form_helper
INFO - 2016-08-30 01:56:48 --> Helper loaded: file_helper
INFO - 2016-08-30 01:56:48 --> Helper loaded: myemail_helper
INFO - 2016-08-30 01:56:48 --> Database Driver Class Initialized
INFO - 2016-08-30 01:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 01:56:48 --> Form Validation Class Initialized
INFO - 2016-08-30 01:56:48 --> Email Class Initialized
INFO - 2016-08-30 01:56:48 --> Controller Class Initialized
INFO - 2016-08-30 01:56:48 --> Model Class Initialized
DEBUG - 2016-08-30 01:56:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 01:56:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 01:56:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 01:56:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 01:56:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 01:56:48 --> Final output sent to browser
DEBUG - 2016-08-30 01:56:48 --> Total execution time: 0.3712
INFO - 2016-08-30 03:04:12 --> Config Class Initialized
INFO - 2016-08-30 03:04:12 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:12 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:12 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:12 --> URI Class Initialized
DEBUG - 2016-08-30 03:04:12 --> No URI present. Default controller set.
INFO - 2016-08-30 03:04:12 --> Router Class Initialized
INFO - 2016-08-30 03:04:12 --> Output Class Initialized
INFO - 2016-08-30 03:04:12 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:12 --> Input Class Initialized
INFO - 2016-08-30 03:04:12 --> Language Class Initialized
INFO - 2016-08-30 03:04:12 --> Loader Class Initialized
INFO - 2016-08-30 03:04:12 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:12 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:12 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:12 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:12 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:12 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:12 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:12 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:12 --> Email Class Initialized
INFO - 2016-08-30 03:04:12 --> Controller Class Initialized
INFO - 2016-08-30 03:04:12 --> Config Class Initialized
INFO - 2016-08-30 03:04:12 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:12 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:12 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:12 --> URI Class Initialized
INFO - 2016-08-30 03:04:12 --> Router Class Initialized
INFO - 2016-08-30 03:04:12 --> Output Class Initialized
INFO - 2016-08-30 03:04:12 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:12 --> Input Class Initialized
INFO - 2016-08-30 03:04:12 --> Language Class Initialized
INFO - 2016-08-30 03:04:12 --> Loader Class Initialized
INFO - 2016-08-30 03:04:13 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:13 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:13 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:13 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:13 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:13 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:13 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:13 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:13 --> Email Class Initialized
INFO - 2016-08-30 03:04:13 --> Controller Class Initialized
INFO - 2016-08-30 03:04:13 --> Model Class Initialized
DEBUG - 2016-08-30 03:04:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 03:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 03:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:04:13 --> Final output sent to browser
DEBUG - 2016-08-30 03:04:13 --> Total execution time: 0.2042
INFO - 2016-08-30 03:04:14 --> Config Class Initialized
INFO - 2016-08-30 03:04:14 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:14 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:14 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:14 --> URI Class Initialized
INFO - 2016-08-30 03:04:14 --> Router Class Initialized
INFO - 2016-08-30 03:04:14 --> Output Class Initialized
INFO - 2016-08-30 03:04:14 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:14 --> Input Class Initialized
INFO - 2016-08-30 03:04:14 --> Language Class Initialized
ERROR - 2016-08-30 03:04:14 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-30 03:04:14 --> Config Class Initialized
INFO - 2016-08-30 03:04:14 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:14 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:14 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:14 --> URI Class Initialized
INFO - 2016-08-30 03:04:14 --> Router Class Initialized
INFO - 2016-08-30 03:04:14 --> Output Class Initialized
INFO - 2016-08-30 03:04:14 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:14 --> Input Class Initialized
INFO - 2016-08-30 03:04:14 --> Language Class Initialized
ERROR - 2016-08-30 03:04:14 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-30 03:04:20 --> Config Class Initialized
INFO - 2016-08-30 03:04:20 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:20 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:20 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:20 --> URI Class Initialized
INFO - 2016-08-30 03:04:20 --> Router Class Initialized
INFO - 2016-08-30 03:04:20 --> Output Class Initialized
INFO - 2016-08-30 03:04:20 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:20 --> Input Class Initialized
INFO - 2016-08-30 03:04:20 --> Language Class Initialized
INFO - 2016-08-30 03:04:20 --> Loader Class Initialized
INFO - 2016-08-30 03:04:20 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:20 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:20 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:20 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:20 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:20 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:20 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:20 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:20 --> Email Class Initialized
INFO - 2016-08-30 03:04:20 --> Controller Class Initialized
INFO - 2016-08-30 03:04:20 --> Model Class Initialized
DEBUG - 2016-08-30 03:04:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:04:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:04:21 --> Config Class Initialized
INFO - 2016-08-30 03:04:21 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:21 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:21 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:21 --> URI Class Initialized
DEBUG - 2016-08-30 03:04:21 --> No URI present. Default controller set.
INFO - 2016-08-30 03:04:21 --> Router Class Initialized
INFO - 2016-08-30 03:04:21 --> Output Class Initialized
INFO - 2016-08-30 03:04:21 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:21 --> Input Class Initialized
INFO - 2016-08-30 03:04:21 --> Language Class Initialized
INFO - 2016-08-30 03:04:21 --> Loader Class Initialized
INFO - 2016-08-30 03:04:21 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:21 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:21 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:21 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:21 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:21 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:21 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:21 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:21 --> Email Class Initialized
INFO - 2016-08-30 03:04:21 --> Controller Class Initialized
INFO - 2016-08-30 03:04:21 --> Model Class Initialized
INFO - 2016-08-30 03:04:21 --> Model Class Initialized
INFO - 2016-08-30 03:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-30 03:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:04:21 --> Final output sent to browser
DEBUG - 2016-08-30 03:04:21 --> Total execution time: 0.4345
INFO - 2016-08-30 03:04:26 --> Config Class Initialized
INFO - 2016-08-30 03:04:26 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:26 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:26 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:26 --> URI Class Initialized
INFO - 2016-08-30 03:04:26 --> Router Class Initialized
INFO - 2016-08-30 03:04:26 --> Output Class Initialized
INFO - 2016-08-30 03:04:26 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:26 --> Input Class Initialized
INFO - 2016-08-30 03:04:26 --> Language Class Initialized
INFO - 2016-08-30 03:04:26 --> Loader Class Initialized
INFO - 2016-08-30 03:04:26 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:26 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:26 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:26 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:26 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:26 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:26 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:26 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:26 --> Email Class Initialized
INFO - 2016-08-30 03:04:26 --> Controller Class Initialized
DEBUG - 2016-08-30 03:04:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:04:26 --> Model Class Initialized
INFO - 2016-08-30 03:04:26 --> Model Class Initialized
INFO - 2016-08-30 03:04:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:04:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:04:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:04:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:04:27 --> Final output sent to browser
DEBUG - 2016-08-30 03:04:27 --> Total execution time: 0.4031
INFO - 2016-08-30 03:04:29 --> Config Class Initialized
INFO - 2016-08-30 03:04:29 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:04:29 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:04:29 --> Utf8 Class Initialized
INFO - 2016-08-30 03:04:29 --> URI Class Initialized
INFO - 2016-08-30 03:04:29 --> Router Class Initialized
INFO - 2016-08-30 03:04:29 --> Output Class Initialized
INFO - 2016-08-30 03:04:29 --> Security Class Initialized
DEBUG - 2016-08-30 03:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:04:29 --> Input Class Initialized
INFO - 2016-08-30 03:04:29 --> Language Class Initialized
INFO - 2016-08-30 03:04:29 --> Loader Class Initialized
INFO - 2016-08-30 03:04:29 --> Helper loaded: url_helper
INFO - 2016-08-30 03:04:29 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:04:29 --> Helper loaded: html_helper
INFO - 2016-08-30 03:04:29 --> Helper loaded: form_helper
INFO - 2016-08-30 03:04:29 --> Helper loaded: file_helper
INFO - 2016-08-30 03:04:29 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:04:29 --> Database Driver Class Initialized
INFO - 2016-08-30 03:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:04:29 --> Form Validation Class Initialized
INFO - 2016-08-30 03:04:29 --> Email Class Initialized
INFO - 2016-08-30 03:04:29 --> Controller Class Initialized
DEBUG - 2016-08-30 03:04:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:04:29 --> Model Class Initialized
INFO - 2016-08-30 03:04:29 --> Model Class Initialized
INFO - 2016-08-30 03:04:29 --> Model Class Initialized
INFO - 2016-08-30 03:04:29 --> Final output sent to browser
DEBUG - 2016-08-30 03:04:29 --> Total execution time: 0.2485
INFO - 2016-08-30 03:07:04 --> Config Class Initialized
INFO - 2016-08-30 03:07:04 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:07:04 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:07:04 --> Utf8 Class Initialized
INFO - 2016-08-30 03:07:04 --> URI Class Initialized
INFO - 2016-08-30 03:07:04 --> Router Class Initialized
INFO - 2016-08-30 03:07:04 --> Output Class Initialized
INFO - 2016-08-30 03:07:04 --> Security Class Initialized
DEBUG - 2016-08-30 03:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:07:04 --> Input Class Initialized
INFO - 2016-08-30 03:07:04 --> Language Class Initialized
INFO - 2016-08-30 03:07:04 --> Loader Class Initialized
INFO - 2016-08-30 03:07:04 --> Helper loaded: url_helper
INFO - 2016-08-30 03:07:04 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:07:04 --> Helper loaded: html_helper
INFO - 2016-08-30 03:07:04 --> Helper loaded: form_helper
INFO - 2016-08-30 03:07:04 --> Helper loaded: file_helper
INFO - 2016-08-30 03:07:04 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:07:04 --> Database Driver Class Initialized
INFO - 2016-08-30 03:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:07:04 --> Form Validation Class Initialized
INFO - 2016-08-30 03:07:04 --> Email Class Initialized
INFO - 2016-08-30 03:07:04 --> Controller Class Initialized
DEBUG - 2016-08-30 03:07:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:07:04 --> Model Class Initialized
INFO - 2016-08-30 03:07:04 --> Model Class Initialized
INFO - 2016-08-30 03:07:04 --> Model Class Initialized
INFO - 2016-08-30 03:07:04 --> Model Class Initialized
INFO - 2016-08-30 03:07:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:07:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:07:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:07:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:07:04 --> Final output sent to browser
DEBUG - 2016-08-30 03:07:04 --> Total execution time: 0.2585
INFO - 2016-08-30 03:07:11 --> Config Class Initialized
INFO - 2016-08-30 03:07:11 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:07:11 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:07:11 --> Utf8 Class Initialized
INFO - 2016-08-30 03:07:11 --> URI Class Initialized
INFO - 2016-08-30 03:07:11 --> Router Class Initialized
INFO - 2016-08-30 03:07:11 --> Output Class Initialized
INFO - 2016-08-30 03:07:11 --> Security Class Initialized
DEBUG - 2016-08-30 03:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:07:11 --> Input Class Initialized
INFO - 2016-08-30 03:07:11 --> Language Class Initialized
INFO - 2016-08-30 03:07:11 --> Loader Class Initialized
INFO - 2016-08-30 03:07:11 --> Helper loaded: url_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: html_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: form_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: file_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:07:11 --> Database Driver Class Initialized
INFO - 2016-08-30 03:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:07:11 --> Form Validation Class Initialized
INFO - 2016-08-30 03:07:11 --> Email Class Initialized
INFO - 2016-08-30 03:07:11 --> Controller Class Initialized
DEBUG - 2016-08-30 03:07:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:07:11 --> Config Class Initialized
INFO - 2016-08-30 03:07:11 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:07:11 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:07:11 --> Utf8 Class Initialized
INFO - 2016-08-30 03:07:11 --> URI Class Initialized
INFO - 2016-08-30 03:07:11 --> Router Class Initialized
INFO - 2016-08-30 03:07:11 --> Output Class Initialized
INFO - 2016-08-30 03:07:11 --> Security Class Initialized
DEBUG - 2016-08-30 03:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:07:11 --> Input Class Initialized
INFO - 2016-08-30 03:07:11 --> Language Class Initialized
INFO - 2016-08-30 03:07:11 --> Loader Class Initialized
INFO - 2016-08-30 03:07:11 --> Helper loaded: url_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: html_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: form_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: file_helper
INFO - 2016-08-30 03:07:11 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:07:11 --> Database Driver Class Initialized
INFO - 2016-08-30 03:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:07:11 --> Form Validation Class Initialized
INFO - 2016-08-30 03:07:11 --> Email Class Initialized
INFO - 2016-08-30 03:07:11 --> Controller Class Initialized
DEBUG - 2016-08-30 03:07:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> Model Class Initialized
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:07:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:07:11 --> Final output sent to browser
DEBUG - 2016-08-30 03:07:11 --> Total execution time: 0.2490
INFO - 2016-08-30 03:08:44 --> Config Class Initialized
INFO - 2016-08-30 03:08:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:08:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:08:44 --> Utf8 Class Initialized
INFO - 2016-08-30 03:08:44 --> URI Class Initialized
INFO - 2016-08-30 03:08:44 --> Router Class Initialized
INFO - 2016-08-30 03:08:44 --> Output Class Initialized
INFO - 2016-08-30 03:08:44 --> Security Class Initialized
DEBUG - 2016-08-30 03:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:08:44 --> Input Class Initialized
INFO - 2016-08-30 03:08:44 --> Language Class Initialized
INFO - 2016-08-30 03:08:45 --> Loader Class Initialized
INFO - 2016-08-30 03:08:45 --> Helper loaded: url_helper
INFO - 2016-08-30 03:08:45 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:08:45 --> Helper loaded: html_helper
INFO - 2016-08-30 03:08:45 --> Helper loaded: form_helper
INFO - 2016-08-30 03:08:45 --> Helper loaded: file_helper
INFO - 2016-08-30 03:08:45 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:08:45 --> Database Driver Class Initialized
INFO - 2016-08-30 03:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:08:45 --> Form Validation Class Initialized
INFO - 2016-08-30 03:08:45 --> Email Class Initialized
INFO - 2016-08-30 03:08:45 --> Controller Class Initialized
DEBUG - 2016-08-30 03:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:08:45 --> Model Class Initialized
INFO - 2016-08-30 03:08:45 --> Model Class Initialized
INFO - 2016-08-30 03:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:08:45 --> Final output sent to browser
DEBUG - 2016-08-30 03:08:45 --> Total execution time: 0.2406
INFO - 2016-08-30 03:08:47 --> Config Class Initialized
INFO - 2016-08-30 03:08:47 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:08:47 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:08:47 --> Utf8 Class Initialized
INFO - 2016-08-30 03:08:47 --> URI Class Initialized
INFO - 2016-08-30 03:08:47 --> Router Class Initialized
INFO - 2016-08-30 03:08:47 --> Output Class Initialized
INFO - 2016-08-30 03:08:47 --> Security Class Initialized
DEBUG - 2016-08-30 03:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:08:47 --> Input Class Initialized
INFO - 2016-08-30 03:08:47 --> Language Class Initialized
INFO - 2016-08-30 03:08:47 --> Loader Class Initialized
INFO - 2016-08-30 03:08:47 --> Helper loaded: url_helper
INFO - 2016-08-30 03:08:47 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:08:47 --> Helper loaded: html_helper
INFO - 2016-08-30 03:08:47 --> Helper loaded: form_helper
INFO - 2016-08-30 03:08:47 --> Helper loaded: file_helper
INFO - 2016-08-30 03:08:47 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:08:47 --> Database Driver Class Initialized
INFO - 2016-08-30 03:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:08:47 --> Form Validation Class Initialized
INFO - 2016-08-30 03:08:47 --> Email Class Initialized
INFO - 2016-08-30 03:08:47 --> Controller Class Initialized
DEBUG - 2016-08-30 03:08:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:08:47 --> Model Class Initialized
INFO - 2016-08-30 03:08:48 --> Model Class Initialized
INFO - 2016-08-30 03:08:48 --> Model Class Initialized
INFO - 2016-08-30 03:08:48 --> Model Class Initialized
INFO - 2016-08-30 03:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:08:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:08:48 --> Final output sent to browser
DEBUG - 2016-08-30 03:08:48 --> Total execution time: 0.2722
INFO - 2016-08-30 03:08:52 --> Config Class Initialized
INFO - 2016-08-30 03:08:52 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:08:52 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:08:52 --> Utf8 Class Initialized
INFO - 2016-08-30 03:08:52 --> URI Class Initialized
INFO - 2016-08-30 03:08:52 --> Router Class Initialized
INFO - 2016-08-30 03:08:52 --> Output Class Initialized
INFO - 2016-08-30 03:08:52 --> Security Class Initialized
DEBUG - 2016-08-30 03:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:08:52 --> Input Class Initialized
INFO - 2016-08-30 03:08:52 --> Language Class Initialized
INFO - 2016-08-30 03:08:52 --> Loader Class Initialized
INFO - 2016-08-30 03:08:52 --> Helper loaded: url_helper
INFO - 2016-08-30 03:08:52 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:08:52 --> Helper loaded: html_helper
INFO - 2016-08-30 03:08:52 --> Helper loaded: form_helper
INFO - 2016-08-30 03:08:52 --> Helper loaded: file_helper
INFO - 2016-08-30 03:08:52 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:08:52 --> Database Driver Class Initialized
INFO - 2016-08-30 03:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:08:52 --> Form Validation Class Initialized
INFO - 2016-08-30 03:08:52 --> Email Class Initialized
INFO - 2016-08-30 03:08:52 --> Controller Class Initialized
DEBUG - 2016-08-30 03:08:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:08:52 --> Model Class Initialized
INFO - 2016-08-30 03:08:52 --> Model Class Initialized
INFO - 2016-08-30 03:08:52 --> Model Class Initialized
INFO - 2016-08-30 03:08:52 --> Model Class Initialized
INFO - 2016-08-30 03:08:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:08:53 --> Config Class Initialized
INFO - 2016-08-30 03:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:08:53 --> Utf8 Class Initialized
INFO - 2016-08-30 03:08:53 --> URI Class Initialized
INFO - 2016-08-30 03:08:53 --> Router Class Initialized
INFO - 2016-08-30 03:08:53 --> Output Class Initialized
INFO - 2016-08-30 03:08:53 --> Security Class Initialized
DEBUG - 2016-08-30 03:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:08:53 --> Input Class Initialized
INFO - 2016-08-30 03:08:53 --> Language Class Initialized
INFO - 2016-08-30 03:08:53 --> Loader Class Initialized
INFO - 2016-08-30 03:08:53 --> Helper loaded: url_helper
INFO - 2016-08-30 03:08:53 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:08:53 --> Helper loaded: html_helper
INFO - 2016-08-30 03:08:53 --> Helper loaded: form_helper
INFO - 2016-08-30 03:08:53 --> Helper loaded: file_helper
INFO - 2016-08-30 03:08:53 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:08:53 --> Database Driver Class Initialized
INFO - 2016-08-30 03:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:08:53 --> Form Validation Class Initialized
INFO - 2016-08-30 03:08:53 --> Email Class Initialized
INFO - 2016-08-30 03:08:53 --> Controller Class Initialized
DEBUG - 2016-08-30 03:08:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:08:53 --> Model Class Initialized
INFO - 2016-08-30 03:08:53 --> Model Class Initialized
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:08:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:08:53 --> Final output sent to browser
DEBUG - 2016-08-30 03:08:53 --> Total execution time: 0.4014
INFO - 2016-08-30 03:09:00 --> Config Class Initialized
INFO - 2016-08-30 03:09:00 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:09:00 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:09:00 --> Utf8 Class Initialized
INFO - 2016-08-30 03:09:00 --> URI Class Initialized
INFO - 2016-08-30 03:09:00 --> Router Class Initialized
INFO - 2016-08-30 03:09:00 --> Output Class Initialized
INFO - 2016-08-30 03:09:00 --> Security Class Initialized
DEBUG - 2016-08-30 03:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:09:00 --> Input Class Initialized
INFO - 2016-08-30 03:09:00 --> Language Class Initialized
INFO - 2016-08-30 03:09:00 --> Loader Class Initialized
INFO - 2016-08-30 03:09:00 --> Helper loaded: url_helper
INFO - 2016-08-30 03:09:00 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:09:00 --> Helper loaded: html_helper
INFO - 2016-08-30 03:09:00 --> Helper loaded: form_helper
INFO - 2016-08-30 03:09:00 --> Helper loaded: file_helper
INFO - 2016-08-30 03:09:00 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:09:00 --> Database Driver Class Initialized
INFO - 2016-08-30 03:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:09:00 --> Form Validation Class Initialized
INFO - 2016-08-30 03:09:00 --> Email Class Initialized
INFO - 2016-08-30 03:09:00 --> Controller Class Initialized
DEBUG - 2016-08-30 03:09:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:09:00 --> Model Class Initialized
INFO - 2016-08-30 03:09:00 --> Model Class Initialized
INFO - 2016-08-30 03:09:00 --> Model Class Initialized
INFO - 2016-08-30 03:09:00 --> Model Class Initialized
INFO - 2016-08-30 03:09:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:09:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:09:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:09:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:09:00 --> Final output sent to browser
DEBUG - 2016-08-30 03:09:00 --> Total execution time: 0.2677
INFO - 2016-08-30 03:09:02 --> Config Class Initialized
INFO - 2016-08-30 03:09:02 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:09:02 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:09:02 --> Utf8 Class Initialized
INFO - 2016-08-30 03:09:02 --> URI Class Initialized
INFO - 2016-08-30 03:09:02 --> Router Class Initialized
INFO - 2016-08-30 03:09:02 --> Output Class Initialized
INFO - 2016-08-30 03:09:03 --> Security Class Initialized
DEBUG - 2016-08-30 03:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:09:03 --> Input Class Initialized
INFO - 2016-08-30 03:09:03 --> Language Class Initialized
INFO - 2016-08-30 03:09:03 --> Loader Class Initialized
INFO - 2016-08-30 03:09:03 --> Helper loaded: url_helper
INFO - 2016-08-30 03:09:03 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:09:03 --> Helper loaded: html_helper
INFO - 2016-08-30 03:09:03 --> Helper loaded: form_helper
INFO - 2016-08-30 03:09:03 --> Helper loaded: file_helper
INFO - 2016-08-30 03:09:03 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:09:03 --> Database Driver Class Initialized
INFO - 2016-08-30 03:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:09:03 --> Form Validation Class Initialized
INFO - 2016-08-30 03:09:03 --> Email Class Initialized
INFO - 2016-08-30 03:09:03 --> Controller Class Initialized
DEBUG - 2016-08-30 03:09:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:09:03 --> Model Class Initialized
INFO - 2016-08-30 03:09:03 --> Model Class Initialized
INFO - 2016-08-30 03:09:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:09:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:09:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:09:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:09:03 --> Final output sent to browser
DEBUG - 2016-08-30 03:09:03 --> Total execution time: 0.3346
INFO - 2016-08-30 03:10:14 --> Config Class Initialized
INFO - 2016-08-30 03:10:14 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:10:14 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:10:14 --> Utf8 Class Initialized
INFO - 2016-08-30 03:10:14 --> URI Class Initialized
INFO - 2016-08-30 03:10:14 --> Router Class Initialized
INFO - 2016-08-30 03:10:14 --> Output Class Initialized
INFO - 2016-08-30 03:10:14 --> Security Class Initialized
DEBUG - 2016-08-30 03:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:10:14 --> Input Class Initialized
INFO - 2016-08-30 03:10:14 --> Language Class Initialized
INFO - 2016-08-30 03:10:14 --> Loader Class Initialized
INFO - 2016-08-30 03:10:14 --> Helper loaded: url_helper
INFO - 2016-08-30 03:10:14 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:10:14 --> Helper loaded: html_helper
INFO - 2016-08-30 03:10:14 --> Helper loaded: form_helper
INFO - 2016-08-30 03:10:14 --> Helper loaded: file_helper
INFO - 2016-08-30 03:10:14 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:10:14 --> Database Driver Class Initialized
INFO - 2016-08-30 03:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:10:14 --> Form Validation Class Initialized
INFO - 2016-08-30 03:10:14 --> Email Class Initialized
INFO - 2016-08-30 03:10:14 --> Controller Class Initialized
DEBUG - 2016-08-30 03:10:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:10:14 --> Model Class Initialized
INFO - 2016-08-30 03:10:14 --> Model Class Initialized
INFO - 2016-08-30 03:10:14 --> Model Class Initialized
INFO - 2016-08-30 03:10:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:10:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:10:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-30 03:10:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:10:14 --> Final output sent to browser
DEBUG - 2016-08-30 03:10:14 --> Total execution time: 0.2661
INFO - 2016-08-30 03:11:44 --> Config Class Initialized
INFO - 2016-08-30 03:11:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:11:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:11:44 --> Utf8 Class Initialized
INFO - 2016-08-30 03:11:44 --> URI Class Initialized
INFO - 2016-08-30 03:11:44 --> Router Class Initialized
INFO - 2016-08-30 03:11:44 --> Output Class Initialized
INFO - 2016-08-30 03:11:44 --> Security Class Initialized
DEBUG - 2016-08-30 03:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:11:44 --> Input Class Initialized
INFO - 2016-08-30 03:11:44 --> Language Class Initialized
INFO - 2016-08-30 03:11:44 --> Loader Class Initialized
INFO - 2016-08-30 03:11:44 --> Helper loaded: url_helper
INFO - 2016-08-30 03:11:44 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:11:44 --> Helper loaded: html_helper
INFO - 2016-08-30 03:11:44 --> Helper loaded: form_helper
INFO - 2016-08-30 03:11:44 --> Helper loaded: file_helper
INFO - 2016-08-30 03:11:44 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:11:44 --> Database Driver Class Initialized
INFO - 2016-08-30 03:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:11:44 --> Form Validation Class Initialized
INFO - 2016-08-30 03:11:44 --> Email Class Initialized
INFO - 2016-08-30 03:11:44 --> Controller Class Initialized
DEBUG - 2016-08-30 03:11:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:11:44 --> Model Class Initialized
INFO - 2016-08-30 03:11:44 --> Model Class Initialized
INFO - 2016-08-30 03:11:44 --> Model Class Initialized
INFO - 2016-08-30 03:11:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:11:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:11:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:11:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-30 03:11:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:11:45 --> Final output sent to browser
DEBUG - 2016-08-30 03:11:45 --> Total execution time: 0.4487
INFO - 2016-08-30 03:11:54 --> Config Class Initialized
INFO - 2016-08-30 03:11:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:11:54 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:11:54 --> Utf8 Class Initialized
INFO - 2016-08-30 03:11:54 --> URI Class Initialized
INFO - 2016-08-30 03:11:54 --> Router Class Initialized
INFO - 2016-08-30 03:11:54 --> Output Class Initialized
INFO - 2016-08-30 03:11:54 --> Security Class Initialized
DEBUG - 2016-08-30 03:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:11:54 --> Input Class Initialized
INFO - 2016-08-30 03:11:54 --> Language Class Initialized
INFO - 2016-08-30 03:11:54 --> Loader Class Initialized
INFO - 2016-08-30 03:11:54 --> Helper loaded: url_helper
INFO - 2016-08-30 03:11:54 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:11:54 --> Helper loaded: html_helper
INFO - 2016-08-30 03:11:54 --> Helper loaded: form_helper
INFO - 2016-08-30 03:11:54 --> Helper loaded: file_helper
INFO - 2016-08-30 03:11:54 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:11:54 --> Database Driver Class Initialized
INFO - 2016-08-30 03:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:11:54 --> Form Validation Class Initialized
INFO - 2016-08-30 03:11:54 --> Email Class Initialized
INFO - 2016-08-30 03:11:54 --> Controller Class Initialized
DEBUG - 2016-08-30 03:11:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:11:54 --> Model Class Initialized
INFO - 2016-08-30 03:11:54 --> Model Class Initialized
INFO - 2016-08-30 03:11:54 --> Model Class Initialized
INFO - 2016-08-30 03:11:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:11:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:11:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:11:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-30 03:11:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:11:54 --> Final output sent to browser
DEBUG - 2016-08-30 03:11:54 --> Total execution time: 0.3000
INFO - 2016-08-30 03:12:05 --> Config Class Initialized
INFO - 2016-08-30 03:12:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:12:05 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:12:05 --> Utf8 Class Initialized
INFO - 2016-08-30 03:12:05 --> URI Class Initialized
INFO - 2016-08-30 03:12:05 --> Router Class Initialized
INFO - 2016-08-30 03:12:05 --> Output Class Initialized
INFO - 2016-08-30 03:12:05 --> Security Class Initialized
DEBUG - 2016-08-30 03:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:12:05 --> Input Class Initialized
INFO - 2016-08-30 03:12:05 --> Language Class Initialized
INFO - 2016-08-30 03:12:05 --> Loader Class Initialized
INFO - 2016-08-30 03:12:05 --> Helper loaded: url_helper
INFO - 2016-08-30 03:12:05 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:12:05 --> Helper loaded: html_helper
INFO - 2016-08-30 03:12:05 --> Helper loaded: form_helper
INFO - 2016-08-30 03:12:05 --> Helper loaded: file_helper
INFO - 2016-08-30 03:12:05 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:12:05 --> Database Driver Class Initialized
INFO - 2016-08-30 03:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:12:05 --> Form Validation Class Initialized
INFO - 2016-08-30 03:12:05 --> Email Class Initialized
INFO - 2016-08-30 03:12:05 --> Controller Class Initialized
DEBUG - 2016-08-30 03:12:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:12:05 --> Model Class Initialized
INFO - 2016-08-30 03:12:05 --> Model Class Initialized
INFO - 2016-08-30 03:12:05 --> Model Class Initialized
INFO - 2016-08-30 03:12:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:12:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:12:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:12:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-30 03:12:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:12:05 --> Final output sent to browser
DEBUG - 2016-08-30 03:12:05 --> Total execution time: 0.2872
INFO - 2016-08-30 03:12:43 --> Config Class Initialized
INFO - 2016-08-30 03:12:43 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:12:43 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:12:43 --> Utf8 Class Initialized
INFO - 2016-08-30 03:12:43 --> URI Class Initialized
INFO - 2016-08-30 03:12:43 --> Router Class Initialized
INFO - 2016-08-30 03:12:43 --> Output Class Initialized
INFO - 2016-08-30 03:12:43 --> Security Class Initialized
DEBUG - 2016-08-30 03:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:12:43 --> Input Class Initialized
INFO - 2016-08-30 03:12:43 --> Language Class Initialized
INFO - 2016-08-30 03:12:43 --> Loader Class Initialized
INFO - 2016-08-30 03:12:43 --> Helper loaded: url_helper
INFO - 2016-08-30 03:12:43 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:12:43 --> Helper loaded: html_helper
INFO - 2016-08-30 03:12:43 --> Helper loaded: form_helper
INFO - 2016-08-30 03:12:43 --> Helper loaded: file_helper
INFO - 2016-08-30 03:12:43 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:12:43 --> Database Driver Class Initialized
INFO - 2016-08-30 03:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:12:43 --> Form Validation Class Initialized
INFO - 2016-08-30 03:12:43 --> Email Class Initialized
INFO - 2016-08-30 03:12:43 --> Controller Class Initialized
DEBUG - 2016-08-30 03:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:12:43 --> Model Class Initialized
INFO - 2016-08-30 03:12:43 --> Model Class Initialized
INFO - 2016-08-30 03:12:43 --> Model Class Initialized
INFO - 2016-08-30 03:12:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-30 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:12:43 --> Final output sent to browser
DEBUG - 2016-08-30 03:12:43 --> Total execution time: 0.2841
INFO - 2016-08-30 03:17:34 --> Config Class Initialized
INFO - 2016-08-30 03:17:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:17:34 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:17:34 --> Utf8 Class Initialized
INFO - 2016-08-30 03:17:34 --> URI Class Initialized
INFO - 2016-08-30 03:17:34 --> Router Class Initialized
INFO - 2016-08-30 03:17:34 --> Output Class Initialized
INFO - 2016-08-30 03:17:34 --> Security Class Initialized
DEBUG - 2016-08-30 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:17:34 --> Input Class Initialized
INFO - 2016-08-30 03:17:34 --> Language Class Initialized
INFO - 2016-08-30 03:17:34 --> Loader Class Initialized
INFO - 2016-08-30 03:17:34 --> Helper loaded: url_helper
INFO - 2016-08-30 03:17:34 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:17:34 --> Helper loaded: html_helper
INFO - 2016-08-30 03:17:34 --> Helper loaded: form_helper
INFO - 2016-08-30 03:17:34 --> Helper loaded: file_helper
INFO - 2016-08-30 03:17:34 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:17:34 --> Database Driver Class Initialized
INFO - 2016-08-30 03:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:17:34 --> Form Validation Class Initialized
INFO - 2016-08-30 03:17:34 --> Email Class Initialized
INFO - 2016-08-30 03:17:34 --> Controller Class Initialized
DEBUG - 2016-08-30 03:17:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:17:34 --> Model Class Initialized
INFO - 2016-08-30 03:17:34 --> Model Class Initialized
INFO - 2016-08-30 03:17:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:17:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:17:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:17:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:17:34 --> Final output sent to browser
DEBUG - 2016-08-30 03:17:34 --> Total execution time: 0.2697
INFO - 2016-08-30 03:17:36 --> Config Class Initialized
INFO - 2016-08-30 03:17:36 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:17:36 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:17:36 --> Utf8 Class Initialized
INFO - 2016-08-30 03:17:36 --> URI Class Initialized
INFO - 2016-08-30 03:17:36 --> Router Class Initialized
INFO - 2016-08-30 03:17:36 --> Output Class Initialized
INFO - 2016-08-30 03:17:36 --> Security Class Initialized
DEBUG - 2016-08-30 03:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:17:36 --> Input Class Initialized
INFO - 2016-08-30 03:17:36 --> Language Class Initialized
INFO - 2016-08-30 03:17:36 --> Loader Class Initialized
INFO - 2016-08-30 03:17:36 --> Helper loaded: url_helper
INFO - 2016-08-30 03:17:36 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:17:36 --> Helper loaded: html_helper
INFO - 2016-08-30 03:17:36 --> Helper loaded: form_helper
INFO - 2016-08-30 03:17:36 --> Helper loaded: file_helper
INFO - 2016-08-30 03:17:36 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:17:36 --> Database Driver Class Initialized
INFO - 2016-08-30 03:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:17:36 --> Form Validation Class Initialized
INFO - 2016-08-30 03:17:36 --> Email Class Initialized
INFO - 2016-08-30 03:17:36 --> Controller Class Initialized
DEBUG - 2016-08-30 03:17:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:17:36 --> Model Class Initialized
INFO - 2016-08-30 03:17:36 --> Model Class Initialized
INFO - 2016-08-30 03:17:36 --> Model Class Initialized
INFO - 2016-08-30 03:17:36 --> Model Class Initialized
INFO - 2016-08-30 03:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:17:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:17:36 --> Final output sent to browser
DEBUG - 2016-08-30 03:17:36 --> Total execution time: 0.2947
INFO - 2016-08-30 03:17:54 --> Config Class Initialized
INFO - 2016-08-30 03:17:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:17:54 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:17:54 --> Utf8 Class Initialized
INFO - 2016-08-30 03:17:54 --> URI Class Initialized
INFO - 2016-08-30 03:17:54 --> Router Class Initialized
INFO - 2016-08-30 03:17:54 --> Output Class Initialized
INFO - 2016-08-30 03:17:54 --> Security Class Initialized
DEBUG - 2016-08-30 03:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:17:54 --> Input Class Initialized
INFO - 2016-08-30 03:17:54 --> Language Class Initialized
INFO - 2016-08-30 03:17:54 --> Loader Class Initialized
INFO - 2016-08-30 03:17:54 --> Helper loaded: url_helper
INFO - 2016-08-30 03:17:54 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:17:54 --> Helper loaded: html_helper
INFO - 2016-08-30 03:17:54 --> Helper loaded: form_helper
INFO - 2016-08-30 03:17:54 --> Helper loaded: file_helper
INFO - 2016-08-30 03:17:54 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:17:54 --> Database Driver Class Initialized
INFO - 2016-08-30 03:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:17:54 --> Form Validation Class Initialized
INFO - 2016-08-30 03:17:54 --> Email Class Initialized
INFO - 2016-08-30 03:17:54 --> Controller Class Initialized
DEBUG - 2016-08-30 03:17:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:17:54 --> Model Class Initialized
INFO - 2016-08-30 03:17:54 --> Model Class Initialized
INFO - 2016-08-30 03:17:54 --> Model Class Initialized
INFO - 2016-08-30 03:17:54 --> Model Class Initialized
INFO - 2016-08-30 03:17:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:17:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:17:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:17:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:18:03 --> Config Class Initialized
INFO - 2016-08-30 03:18:03 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:18:03 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:18:03 --> Utf8 Class Initialized
INFO - 2016-08-30 03:18:03 --> URI Class Initialized
INFO - 2016-08-30 03:18:03 --> Router Class Initialized
INFO - 2016-08-30 03:18:03 --> Output Class Initialized
INFO - 2016-08-30 03:18:03 --> Security Class Initialized
DEBUG - 2016-08-30 03:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:18:03 --> Input Class Initialized
INFO - 2016-08-30 03:18:03 --> Language Class Initialized
INFO - 2016-08-30 03:18:03 --> Loader Class Initialized
INFO - 2016-08-30 03:18:03 --> Helper loaded: url_helper
INFO - 2016-08-30 03:18:03 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:18:03 --> Helper loaded: html_helper
INFO - 2016-08-30 03:18:03 --> Helper loaded: form_helper
INFO - 2016-08-30 03:18:03 --> Helper loaded: file_helper
INFO - 2016-08-30 03:18:03 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:18:03 --> Database Driver Class Initialized
INFO - 2016-08-30 03:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:18:03 --> Form Validation Class Initialized
INFO - 2016-08-30 03:18:03 --> Email Class Initialized
INFO - 2016-08-30 03:18:03 --> Controller Class Initialized
DEBUG - 2016-08-30 03:18:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:18:03 --> Model Class Initialized
INFO - 2016-08-30 03:18:03 --> Model Class Initialized
INFO - 2016-08-30 03:18:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:18:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:18:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:18:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:18:03 --> Final output sent to browser
DEBUG - 2016-08-30 03:18:04 --> Total execution time: 0.3278
INFO - 2016-08-30 03:18:57 --> Config Class Initialized
INFO - 2016-08-30 03:18:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:18:57 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:18:57 --> Utf8 Class Initialized
INFO - 2016-08-30 03:18:57 --> URI Class Initialized
INFO - 2016-08-30 03:18:57 --> Router Class Initialized
INFO - 2016-08-30 03:18:57 --> Output Class Initialized
INFO - 2016-08-30 03:18:57 --> Security Class Initialized
DEBUG - 2016-08-30 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:18:57 --> Input Class Initialized
INFO - 2016-08-30 03:18:57 --> Language Class Initialized
INFO - 2016-08-30 03:18:57 --> Loader Class Initialized
INFO - 2016-08-30 03:18:57 --> Helper loaded: url_helper
INFO - 2016-08-30 03:18:57 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:18:57 --> Helper loaded: html_helper
INFO - 2016-08-30 03:18:57 --> Helper loaded: form_helper
INFO - 2016-08-30 03:18:57 --> Helper loaded: file_helper
INFO - 2016-08-30 03:18:57 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:18:57 --> Database Driver Class Initialized
INFO - 2016-08-30 03:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:18:57 --> Form Validation Class Initialized
INFO - 2016-08-30 03:18:57 --> Email Class Initialized
INFO - 2016-08-30 03:18:58 --> Controller Class Initialized
DEBUG - 2016-08-30 03:18:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:18:58 --> Model Class Initialized
INFO - 2016-08-30 03:18:58 --> Model Class Initialized
INFO - 2016-08-30 03:18:58 --> Model Class Initialized
INFO - 2016-08-30 03:18:58 --> Model Class Initialized
INFO - 2016-08-30 03:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:18:58 --> Final output sent to browser
DEBUG - 2016-08-30 03:18:58 --> Total execution time: 0.3406
INFO - 2016-08-30 03:18:59 --> Config Class Initialized
INFO - 2016-08-30 03:18:59 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:18:59 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:18:59 --> Utf8 Class Initialized
INFO - 2016-08-30 03:18:59 --> URI Class Initialized
INFO - 2016-08-30 03:18:59 --> Router Class Initialized
INFO - 2016-08-30 03:18:59 --> Output Class Initialized
INFO - 2016-08-30 03:18:59 --> Security Class Initialized
DEBUG - 2016-08-30 03:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:18:59 --> Input Class Initialized
INFO - 2016-08-30 03:18:59 --> Language Class Initialized
INFO - 2016-08-30 03:19:00 --> Loader Class Initialized
INFO - 2016-08-30 03:19:00 --> Helper loaded: url_helper
INFO - 2016-08-30 03:19:00 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:19:00 --> Helper loaded: html_helper
INFO - 2016-08-30 03:19:00 --> Helper loaded: form_helper
INFO - 2016-08-30 03:19:00 --> Helper loaded: file_helper
INFO - 2016-08-30 03:19:00 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:19:00 --> Database Driver Class Initialized
INFO - 2016-08-30 03:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:19:00 --> Form Validation Class Initialized
INFO - 2016-08-30 03:19:00 --> Email Class Initialized
INFO - 2016-08-30 03:19:00 --> Controller Class Initialized
DEBUG - 2016-08-30 03:19:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:19:00 --> Model Class Initialized
INFO - 2016-08-30 03:19:00 --> Model Class Initialized
INFO - 2016-08-30 03:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:19:00 --> Final output sent to browser
DEBUG - 2016-08-30 03:19:00 --> Total execution time: 0.3454
INFO - 2016-08-30 03:19:07 --> Config Class Initialized
INFO - 2016-08-30 03:19:07 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:19:07 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:19:07 --> Utf8 Class Initialized
INFO - 2016-08-30 03:19:07 --> URI Class Initialized
INFO - 2016-08-30 03:19:08 --> Router Class Initialized
INFO - 2016-08-30 03:19:08 --> Output Class Initialized
INFO - 2016-08-30 03:19:08 --> Security Class Initialized
DEBUG - 2016-08-30 03:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:19:08 --> Input Class Initialized
INFO - 2016-08-30 03:19:08 --> Language Class Initialized
INFO - 2016-08-30 03:19:08 --> Loader Class Initialized
INFO - 2016-08-30 03:19:08 --> Helper loaded: url_helper
INFO - 2016-08-30 03:19:08 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:19:08 --> Helper loaded: html_helper
INFO - 2016-08-30 03:19:08 --> Helper loaded: form_helper
INFO - 2016-08-30 03:19:08 --> Helper loaded: file_helper
INFO - 2016-08-30 03:19:08 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:19:08 --> Database Driver Class Initialized
INFO - 2016-08-30 03:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:19:08 --> Form Validation Class Initialized
INFO - 2016-08-30 03:19:08 --> Email Class Initialized
INFO - 2016-08-30 03:19:08 --> Controller Class Initialized
DEBUG - 2016-08-30 03:19:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:19:08 --> Model Class Initialized
INFO - 2016-08-30 03:19:08 --> Model Class Initialized
INFO - 2016-08-30 03:19:08 --> Model Class Initialized
INFO - 2016-08-30 03:19:08 --> Model Class Initialized
INFO - 2016-08-30 03:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:19:08 --> Final output sent to browser
DEBUG - 2016-08-30 03:19:08 --> Total execution time: 0.3400
INFO - 2016-08-30 03:20:54 --> Config Class Initialized
INFO - 2016-08-30 03:20:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:20:54 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:20:54 --> Utf8 Class Initialized
INFO - 2016-08-30 03:20:54 --> URI Class Initialized
INFO - 2016-08-30 03:20:54 --> Router Class Initialized
INFO - 2016-08-30 03:20:54 --> Output Class Initialized
INFO - 2016-08-30 03:20:54 --> Security Class Initialized
DEBUG - 2016-08-30 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:20:54 --> Input Class Initialized
INFO - 2016-08-30 03:20:54 --> Language Class Initialized
INFO - 2016-08-30 03:20:54 --> Loader Class Initialized
INFO - 2016-08-30 03:20:54 --> Helper loaded: url_helper
INFO - 2016-08-30 03:20:54 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:20:54 --> Helper loaded: html_helper
INFO - 2016-08-30 03:20:54 --> Helper loaded: form_helper
INFO - 2016-08-30 03:20:54 --> Helper loaded: file_helper
INFO - 2016-08-30 03:20:54 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:20:54 --> Database Driver Class Initialized
INFO - 2016-08-30 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:20:54 --> Form Validation Class Initialized
INFO - 2016-08-30 03:20:54 --> Email Class Initialized
INFO - 2016-08-30 03:20:54 --> Controller Class Initialized
DEBUG - 2016-08-30 03:20:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:20:54 --> Model Class Initialized
INFO - 2016-08-30 03:20:54 --> Model Class Initialized
INFO - 2016-08-30 03:20:54 --> Model Class Initialized
INFO - 2016-08-30 03:20:54 --> Model Class Initialized
INFO - 2016-08-30 03:20:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:20:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:20:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:20:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:21:03 --> Config Class Initialized
INFO - 2016-08-30 03:21:03 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:21:03 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:21:03 --> Utf8 Class Initialized
INFO - 2016-08-30 03:21:03 --> URI Class Initialized
INFO - 2016-08-30 03:21:03 --> Router Class Initialized
INFO - 2016-08-30 03:21:03 --> Output Class Initialized
INFO - 2016-08-30 03:21:03 --> Security Class Initialized
DEBUG - 2016-08-30 03:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:21:03 --> Input Class Initialized
INFO - 2016-08-30 03:21:03 --> Language Class Initialized
INFO - 2016-08-30 03:21:03 --> Loader Class Initialized
INFO - 2016-08-30 03:21:03 --> Helper loaded: url_helper
INFO - 2016-08-30 03:21:03 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:21:03 --> Helper loaded: html_helper
INFO - 2016-08-30 03:21:03 --> Helper loaded: form_helper
INFO - 2016-08-30 03:21:03 --> Helper loaded: file_helper
INFO - 2016-08-30 03:21:03 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:21:03 --> Database Driver Class Initialized
INFO - 2016-08-30 03:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:21:03 --> Form Validation Class Initialized
INFO - 2016-08-30 03:21:03 --> Email Class Initialized
INFO - 2016-08-30 03:21:03 --> Controller Class Initialized
DEBUG - 2016-08-30 03:21:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:21:03 --> Model Class Initialized
INFO - 2016-08-30 03:21:03 --> Model Class Initialized
INFO - 2016-08-30 03:21:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:21:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:21:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:21:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:21:03 --> Final output sent to browser
DEBUG - 2016-08-30 03:21:03 --> Total execution time: 0.4379
INFO - 2016-08-30 03:21:16 --> Config Class Initialized
INFO - 2016-08-30 03:21:16 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:21:16 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:21:16 --> Utf8 Class Initialized
INFO - 2016-08-30 03:21:16 --> URI Class Initialized
INFO - 2016-08-30 03:21:16 --> Router Class Initialized
INFO - 2016-08-30 03:21:16 --> Output Class Initialized
INFO - 2016-08-30 03:21:16 --> Security Class Initialized
DEBUG - 2016-08-30 03:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:21:16 --> Input Class Initialized
INFO - 2016-08-30 03:21:16 --> Language Class Initialized
INFO - 2016-08-30 03:21:16 --> Loader Class Initialized
INFO - 2016-08-30 03:21:16 --> Helper loaded: url_helper
INFO - 2016-08-30 03:21:16 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:21:16 --> Helper loaded: html_helper
INFO - 2016-08-30 03:21:16 --> Helper loaded: form_helper
INFO - 2016-08-30 03:21:16 --> Helper loaded: file_helper
INFO - 2016-08-30 03:21:16 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:21:16 --> Database Driver Class Initialized
INFO - 2016-08-30 03:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:21:16 --> Form Validation Class Initialized
INFO - 2016-08-30 03:21:16 --> Email Class Initialized
INFO - 2016-08-30 03:21:16 --> Controller Class Initialized
DEBUG - 2016-08-30 03:21:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:21:16 --> Model Class Initialized
INFO - 2016-08-30 03:21:16 --> Model Class Initialized
INFO - 2016-08-30 03:21:16 --> Model Class Initialized
INFO - 2016-08-30 03:21:16 --> Model Class Initialized
INFO - 2016-08-30 03:21:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:21:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:21:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:21:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:21:16 --> Final output sent to browser
DEBUG - 2016-08-30 03:21:16 --> Total execution time: 0.2781
INFO - 2016-08-30 03:21:53 --> Config Class Initialized
INFO - 2016-08-30 03:21:53 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:21:53 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:21:53 --> Utf8 Class Initialized
INFO - 2016-08-30 03:21:53 --> URI Class Initialized
INFO - 2016-08-30 03:21:53 --> Router Class Initialized
INFO - 2016-08-30 03:21:53 --> Output Class Initialized
INFO - 2016-08-30 03:21:53 --> Security Class Initialized
DEBUG - 2016-08-30 03:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:21:53 --> Input Class Initialized
INFO - 2016-08-30 03:21:53 --> Language Class Initialized
INFO - 2016-08-30 03:21:53 --> Loader Class Initialized
INFO - 2016-08-30 03:21:53 --> Helper loaded: url_helper
INFO - 2016-08-30 03:21:53 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:21:53 --> Helper loaded: html_helper
INFO - 2016-08-30 03:21:53 --> Helper loaded: form_helper
INFO - 2016-08-30 03:21:53 --> Helper loaded: file_helper
INFO - 2016-08-30 03:21:53 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:21:53 --> Database Driver Class Initialized
INFO - 2016-08-30 03:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:21:53 --> Form Validation Class Initialized
INFO - 2016-08-30 03:21:53 --> Email Class Initialized
INFO - 2016-08-30 03:21:53 --> Controller Class Initialized
DEBUG - 2016-08-30 03:21:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:21:53 --> Model Class Initialized
INFO - 2016-08-30 03:21:53 --> Model Class Initialized
INFO - 2016-08-30 03:21:53 --> Model Class Initialized
INFO - 2016-08-30 03:21:53 --> Model Class Initialized
INFO - 2016-08-30 03:21:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:21:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:21:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-30 03:21:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:22:02 --> Config Class Initialized
INFO - 2016-08-30 03:22:02 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:22:02 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:22:02 --> Utf8 Class Initialized
INFO - 2016-08-30 03:22:02 --> URI Class Initialized
INFO - 2016-08-30 03:22:02 --> Router Class Initialized
INFO - 2016-08-30 03:22:02 --> Output Class Initialized
INFO - 2016-08-30 03:22:02 --> Security Class Initialized
DEBUG - 2016-08-30 03:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:22:02 --> Input Class Initialized
INFO - 2016-08-30 03:22:02 --> Language Class Initialized
INFO - 2016-08-30 03:22:02 --> Loader Class Initialized
INFO - 2016-08-30 03:22:02 --> Helper loaded: url_helper
INFO - 2016-08-30 03:22:02 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:22:02 --> Helper loaded: html_helper
INFO - 2016-08-30 03:22:02 --> Helper loaded: form_helper
INFO - 2016-08-30 03:22:02 --> Helper loaded: file_helper
INFO - 2016-08-30 03:22:02 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:22:02 --> Database Driver Class Initialized
INFO - 2016-08-30 03:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:22:02 --> Form Validation Class Initialized
INFO - 2016-08-30 03:22:02 --> Email Class Initialized
INFO - 2016-08-30 03:22:02 --> Controller Class Initialized
DEBUG - 2016-08-30 03:22:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:22:02 --> Model Class Initialized
INFO - 2016-08-30 03:22:02 --> Model Class Initialized
INFO - 2016-08-30 03:22:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:22:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:22:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-30 03:22:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:22:02 --> Final output sent to browser
DEBUG - 2016-08-30 03:22:02 --> Total execution time: 0.2751
INFO - 2016-08-30 03:25:45 --> Config Class Initialized
INFO - 2016-08-30 03:25:45 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:25:45 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:25:45 --> Utf8 Class Initialized
INFO - 2016-08-30 03:25:45 --> URI Class Initialized
INFO - 2016-08-30 03:25:45 --> Router Class Initialized
INFO - 2016-08-30 03:25:45 --> Output Class Initialized
INFO - 2016-08-30 03:25:45 --> Security Class Initialized
DEBUG - 2016-08-30 03:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:25:45 --> Input Class Initialized
INFO - 2016-08-30 03:25:45 --> Language Class Initialized
INFO - 2016-08-30 03:25:46 --> Loader Class Initialized
INFO - 2016-08-30 03:25:46 --> Helper loaded: url_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: html_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: form_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: file_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:25:46 --> Database Driver Class Initialized
INFO - 2016-08-30 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:25:46 --> Form Validation Class Initialized
INFO - 2016-08-30 03:25:46 --> Email Class Initialized
INFO - 2016-08-30 03:25:46 --> Controller Class Initialized
INFO - 2016-08-30 03:25:46 --> Model Class Initialized
INFO - 2016-08-30 03:25:46 --> Config Class Initialized
INFO - 2016-08-30 03:25:46 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:25:46 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:25:46 --> Utf8 Class Initialized
INFO - 2016-08-30 03:25:46 --> URI Class Initialized
INFO - 2016-08-30 03:25:46 --> Router Class Initialized
INFO - 2016-08-30 03:25:46 --> Output Class Initialized
INFO - 2016-08-30 03:25:46 --> Security Class Initialized
DEBUG - 2016-08-30 03:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:25:46 --> Input Class Initialized
INFO - 2016-08-30 03:25:46 --> Language Class Initialized
INFO - 2016-08-30 03:25:46 --> Loader Class Initialized
INFO - 2016-08-30 03:25:46 --> Helper loaded: url_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: html_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: form_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: file_helper
INFO - 2016-08-30 03:25:46 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:25:46 --> Database Driver Class Initialized
INFO - 2016-08-30 03:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:25:46 --> Form Validation Class Initialized
INFO - 2016-08-30 03:25:46 --> Email Class Initialized
INFO - 2016-08-30 03:25:46 --> Controller Class Initialized
INFO - 2016-08-30 03:25:46 --> Model Class Initialized
DEBUG - 2016-08-30 03:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 03:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 03:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:25:46 --> Final output sent to browser
DEBUG - 2016-08-30 03:25:46 --> Total execution time: 0.3661
INFO - 2016-08-30 03:25:48 --> Config Class Initialized
INFO - 2016-08-30 03:25:48 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:25:48 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:25:48 --> Utf8 Class Initialized
INFO - 2016-08-30 03:25:48 --> URI Class Initialized
INFO - 2016-08-30 03:25:48 --> Router Class Initialized
INFO - 2016-08-30 03:25:48 --> Output Class Initialized
INFO - 2016-08-30 03:25:48 --> Security Class Initialized
DEBUG - 2016-08-30 03:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:25:48 --> Input Class Initialized
INFO - 2016-08-30 03:25:48 --> Language Class Initialized
INFO - 2016-08-30 03:25:48 --> Loader Class Initialized
INFO - 2016-08-30 03:25:48 --> Helper loaded: url_helper
INFO - 2016-08-30 03:25:48 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:25:48 --> Helper loaded: html_helper
INFO - 2016-08-30 03:25:48 --> Helper loaded: form_helper
INFO - 2016-08-30 03:25:48 --> Helper loaded: file_helper
INFO - 2016-08-30 03:25:48 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:25:48 --> Database Driver Class Initialized
INFO - 2016-08-30 03:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:25:48 --> Form Validation Class Initialized
INFO - 2016-08-30 03:25:48 --> Email Class Initialized
INFO - 2016-08-30 03:25:48 --> Controller Class Initialized
INFO - 2016-08-30 03:25:48 --> Model Class Initialized
INFO - 2016-08-30 03:25:48 --> Final output sent to browser
DEBUG - 2016-08-30 03:25:48 --> Total execution time: 0.2492
INFO - 2016-08-30 03:28:02 --> Config Class Initialized
INFO - 2016-08-30 03:28:02 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:02 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:02 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:02 --> URI Class Initialized
INFO - 2016-08-30 03:28:02 --> Router Class Initialized
INFO - 2016-08-30 03:28:02 --> Output Class Initialized
INFO - 2016-08-30 03:28:02 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:02 --> Input Class Initialized
INFO - 2016-08-30 03:28:02 --> Language Class Initialized
INFO - 2016-08-30 03:28:02 --> Loader Class Initialized
INFO - 2016-08-30 03:28:02 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:02 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:02 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:02 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:02 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:02 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:02 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:02 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:02 --> Email Class Initialized
INFO - 2016-08-30 03:28:02 --> Controller Class Initialized
INFO - 2016-08-30 03:28:02 --> Model Class Initialized
INFO - 2016-08-30 03:28:05 --> Config Class Initialized
INFO - 2016-08-30 03:28:05 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:05 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:05 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:05 --> URI Class Initialized
INFO - 2016-08-30 03:28:05 --> Router Class Initialized
INFO - 2016-08-30 03:28:05 --> Output Class Initialized
INFO - 2016-08-30 03:28:05 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:05 --> Input Class Initialized
INFO - 2016-08-30 03:28:05 --> Language Class Initialized
INFO - 2016-08-30 03:28:05 --> Loader Class Initialized
INFO - 2016-08-30 03:28:05 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:05 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:05 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:05 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:05 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:05 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:05 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:05 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:05 --> Email Class Initialized
INFO - 2016-08-30 03:28:05 --> Controller Class Initialized
INFO - 2016-08-30 03:28:05 --> Model Class Initialized
INFO - 2016-08-30 03:28:05 --> Model Class Initialized
INFO - 2016-08-30 03:28:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:28:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:28:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-30 03:28:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:28:05 --> Final output sent to browser
DEBUG - 2016-08-30 03:28:05 --> Total execution time: 0.3522
INFO - 2016-08-30 03:28:31 --> Config Class Initialized
INFO - 2016-08-30 03:28:31 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:31 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:31 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:31 --> URI Class Initialized
DEBUG - 2016-08-30 03:28:31 --> No URI present. Default controller set.
INFO - 2016-08-30 03:28:31 --> Router Class Initialized
INFO - 2016-08-30 03:28:31 --> Output Class Initialized
INFO - 2016-08-30 03:28:31 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:31 --> Input Class Initialized
INFO - 2016-08-30 03:28:31 --> Language Class Initialized
INFO - 2016-08-30 03:28:31 --> Loader Class Initialized
INFO - 2016-08-30 03:28:31 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:31 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:31 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:31 --> Email Class Initialized
INFO - 2016-08-30 03:28:31 --> Controller Class Initialized
INFO - 2016-08-30 03:28:31 --> Config Class Initialized
INFO - 2016-08-30 03:28:31 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:31 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:31 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:31 --> URI Class Initialized
INFO - 2016-08-30 03:28:31 --> Router Class Initialized
INFO - 2016-08-30 03:28:31 --> Output Class Initialized
INFO - 2016-08-30 03:28:31 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:31 --> Input Class Initialized
INFO - 2016-08-30 03:28:31 --> Language Class Initialized
INFO - 2016-08-30 03:28:31 --> Loader Class Initialized
INFO - 2016-08-30 03:28:31 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:31 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:31 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:31 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:31 --> Email Class Initialized
INFO - 2016-08-30 03:28:31 --> Controller Class Initialized
INFO - 2016-08-30 03:28:31 --> Model Class Initialized
DEBUG - 2016-08-30 03:28:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 03:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 03:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:28:32 --> Final output sent to browser
DEBUG - 2016-08-30 03:28:32 --> Total execution time: 0.2830
INFO - 2016-08-30 03:28:34 --> Config Class Initialized
INFO - 2016-08-30 03:28:34 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:34 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:34 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:34 --> URI Class Initialized
INFO - 2016-08-30 03:28:34 --> Router Class Initialized
INFO - 2016-08-30 03:28:34 --> Output Class Initialized
INFO - 2016-08-30 03:28:34 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:34 --> Input Class Initialized
INFO - 2016-08-30 03:28:34 --> Language Class Initialized
ERROR - 2016-08-30 03:28:34 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-30 03:28:44 --> Config Class Initialized
INFO - 2016-08-30 03:28:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:44 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:44 --> URI Class Initialized
INFO - 2016-08-30 03:28:44 --> Router Class Initialized
INFO - 2016-08-30 03:28:44 --> Output Class Initialized
INFO - 2016-08-30 03:28:44 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:44 --> Input Class Initialized
INFO - 2016-08-30 03:28:44 --> Language Class Initialized
INFO - 2016-08-30 03:28:44 --> Loader Class Initialized
INFO - 2016-08-30 03:28:44 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:44 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:44 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:44 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:44 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:44 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:44 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:44 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:44 --> Email Class Initialized
INFO - 2016-08-30 03:28:44 --> Controller Class Initialized
INFO - 2016-08-30 03:28:44 --> Model Class Initialized
DEBUG - 2016-08-30 03:28:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:28:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:28:44 --> Config Class Initialized
INFO - 2016-08-30 03:28:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:44 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:44 --> URI Class Initialized
DEBUG - 2016-08-30 03:28:44 --> No URI present. Default controller set.
INFO - 2016-08-30 03:28:44 --> Router Class Initialized
INFO - 2016-08-30 03:28:45 --> Output Class Initialized
INFO - 2016-08-30 03:28:45 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:45 --> Input Class Initialized
INFO - 2016-08-30 03:28:45 --> Language Class Initialized
INFO - 2016-08-30 03:28:45 --> Loader Class Initialized
INFO - 2016-08-30 03:28:45 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:45 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:45 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:45 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:45 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:45 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:45 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:45 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:45 --> Email Class Initialized
INFO - 2016-08-30 03:28:45 --> Controller Class Initialized
INFO - 2016-08-30 03:28:45 --> Model Class Initialized
INFO - 2016-08-30 03:28:45 --> Model Class Initialized
INFO - 2016-08-30 03:28:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:28:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:28:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-30 03:28:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:28:45 --> Final output sent to browser
DEBUG - 2016-08-30 03:28:45 --> Total execution time: 0.3141
INFO - 2016-08-30 03:28:51 --> Config Class Initialized
INFO - 2016-08-30 03:28:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:51 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:51 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:51 --> URI Class Initialized
INFO - 2016-08-30 03:28:51 --> Router Class Initialized
INFO - 2016-08-30 03:28:51 --> Output Class Initialized
INFO - 2016-08-30 03:28:51 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:51 --> Input Class Initialized
INFO - 2016-08-30 03:28:51 --> Language Class Initialized
INFO - 2016-08-30 03:28:51 --> Loader Class Initialized
INFO - 2016-08-30 03:28:51 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:51 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:51 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:51 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:51 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:51 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:51 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:51 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:51 --> Email Class Initialized
INFO - 2016-08-30 03:28:51 --> Controller Class Initialized
INFO - 2016-08-30 03:28:51 --> Model Class Initialized
INFO - 2016-08-30 03:28:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:28:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:28:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-30 03:28:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:28:51 --> Final output sent to browser
DEBUG - 2016-08-30 03:28:51 --> Total execution time: 0.2684
INFO - 2016-08-30 03:28:56 --> Config Class Initialized
INFO - 2016-08-30 03:28:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:28:56 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:28:56 --> Utf8 Class Initialized
INFO - 2016-08-30 03:28:56 --> URI Class Initialized
INFO - 2016-08-30 03:28:56 --> Router Class Initialized
INFO - 2016-08-30 03:28:56 --> Output Class Initialized
INFO - 2016-08-30 03:28:56 --> Security Class Initialized
DEBUG - 2016-08-30 03:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:28:56 --> Input Class Initialized
INFO - 2016-08-30 03:28:56 --> Language Class Initialized
INFO - 2016-08-30 03:28:56 --> Loader Class Initialized
INFO - 2016-08-30 03:28:56 --> Helper loaded: url_helper
INFO - 2016-08-30 03:28:56 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:28:56 --> Helper loaded: html_helper
INFO - 2016-08-30 03:28:56 --> Helper loaded: form_helper
INFO - 2016-08-30 03:28:56 --> Helper loaded: file_helper
INFO - 2016-08-30 03:28:56 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:28:56 --> Database Driver Class Initialized
INFO - 2016-08-30 03:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:28:56 --> Form Validation Class Initialized
INFO - 2016-08-30 03:28:56 --> Email Class Initialized
INFO - 2016-08-30 03:28:56 --> Controller Class Initialized
INFO - 2016-08-30 03:28:57 --> Model Class Initialized
DEBUG - 2016-08-30 03:28:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:28:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:28:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:28:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-30 03:28:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:28:57 --> Final output sent to browser
DEBUG - 2016-08-30 03:28:57 --> Total execution time: 0.3016
INFO - 2016-08-30 03:29:00 --> Config Class Initialized
INFO - 2016-08-30 03:29:00 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:00 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:00 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:00 --> URI Class Initialized
INFO - 2016-08-30 03:29:00 --> Router Class Initialized
INFO - 2016-08-30 03:29:00 --> Output Class Initialized
INFO - 2016-08-30 03:29:00 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:00 --> Input Class Initialized
INFO - 2016-08-30 03:29:00 --> Language Class Initialized
INFO - 2016-08-30 03:29:00 --> Loader Class Initialized
INFO - 2016-08-30 03:29:00 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:00 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:00 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:00 --> Email Class Initialized
INFO - 2016-08-30 03:29:00 --> Controller Class Initialized
INFO - 2016-08-30 03:29:00 --> Model Class Initialized
DEBUG - 2016-08-30 03:29:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:29:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:29:00 --> Config Class Initialized
INFO - 2016-08-30 03:29:00 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:00 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:00 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:00 --> URI Class Initialized
DEBUG - 2016-08-30 03:29:00 --> No URI present. Default controller set.
INFO - 2016-08-30 03:29:00 --> Router Class Initialized
INFO - 2016-08-30 03:29:00 --> Output Class Initialized
INFO - 2016-08-30 03:29:00 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:00 --> Input Class Initialized
INFO - 2016-08-30 03:29:00 --> Language Class Initialized
INFO - 2016-08-30 03:29:00 --> Loader Class Initialized
INFO - 2016-08-30 03:29:00 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:00 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:00 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:01 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:01 --> Email Class Initialized
INFO - 2016-08-30 03:29:01 --> Controller Class Initialized
INFO - 2016-08-30 03:29:01 --> Model Class Initialized
INFO - 2016-08-30 03:29:01 --> Model Class Initialized
INFO - 2016-08-30 03:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-30 03:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:29:01 --> Final output sent to browser
DEBUG - 2016-08-30 03:29:01 --> Total execution time: 0.5684
INFO - 2016-08-30 03:29:09 --> Config Class Initialized
INFO - 2016-08-30 03:29:09 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:09 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:09 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:09 --> URI Class Initialized
INFO - 2016-08-30 03:29:09 --> Router Class Initialized
INFO - 2016-08-30 03:29:09 --> Output Class Initialized
INFO - 2016-08-30 03:29:09 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:09 --> Input Class Initialized
INFO - 2016-08-30 03:29:09 --> Language Class Initialized
INFO - 2016-08-30 03:29:09 --> Loader Class Initialized
INFO - 2016-08-30 03:29:09 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:09 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:09 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:09 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:09 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:09 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:09 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:09 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:09 --> Email Class Initialized
INFO - 2016-08-30 03:29:09 --> Controller Class Initialized
INFO - 2016-08-30 03:29:09 --> Model Class Initialized
INFO - 2016-08-30 03:29:09 --> Config Class Initialized
INFO - 2016-08-30 03:29:09 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:09 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:09 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:09 --> URI Class Initialized
INFO - 2016-08-30 03:29:09 --> Router Class Initialized
INFO - 2016-08-30 03:29:09 --> Output Class Initialized
INFO - 2016-08-30 03:29:09 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:09 --> Input Class Initialized
INFO - 2016-08-30 03:29:09 --> Language Class Initialized
INFO - 2016-08-30 03:29:09 --> Loader Class Initialized
INFO - 2016-08-30 03:29:09 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:10 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:10 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:10 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:10 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:10 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:10 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:10 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:10 --> Email Class Initialized
INFO - 2016-08-30 03:29:10 --> Controller Class Initialized
INFO - 2016-08-30 03:29:10 --> Model Class Initialized
DEBUG - 2016-08-30 03:29:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 03:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 03:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:29:10 --> Final output sent to browser
DEBUG - 2016-08-30 03:29:10 --> Total execution time: 0.2767
INFO - 2016-08-30 03:29:13 --> Config Class Initialized
INFO - 2016-08-30 03:29:13 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:13 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:13 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:13 --> URI Class Initialized
INFO - 2016-08-30 03:29:13 --> Router Class Initialized
INFO - 2016-08-30 03:29:13 --> Output Class Initialized
INFO - 2016-08-30 03:29:13 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:13 --> Input Class Initialized
INFO - 2016-08-30 03:29:13 --> Language Class Initialized
INFO - 2016-08-30 03:29:13 --> Loader Class Initialized
INFO - 2016-08-30 03:29:13 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:13 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:13 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:13 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:13 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:13 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:13 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:13 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:13 --> Email Class Initialized
INFO - 2016-08-30 03:29:13 --> Controller Class Initialized
INFO - 2016-08-30 03:29:13 --> Model Class Initialized
INFO - 2016-08-30 03:29:13 --> Final output sent to browser
DEBUG - 2016-08-30 03:29:13 --> Total execution time: 0.2523
INFO - 2016-08-30 03:29:17 --> Config Class Initialized
INFO - 2016-08-30 03:29:17 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:17 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:17 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:17 --> URI Class Initialized
INFO - 2016-08-30 03:29:17 --> Router Class Initialized
INFO - 2016-08-30 03:29:17 --> Output Class Initialized
INFO - 2016-08-30 03:29:17 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:17 --> Input Class Initialized
INFO - 2016-08-30 03:29:17 --> Language Class Initialized
INFO - 2016-08-30 03:29:17 --> Loader Class Initialized
INFO - 2016-08-30 03:29:17 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:17 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:17 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:17 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:17 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:17 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:17 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:17 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:17 --> Email Class Initialized
INFO - 2016-08-30 03:29:17 --> Controller Class Initialized
INFO - 2016-08-30 03:29:17 --> Model Class Initialized
INFO - 2016-08-30 03:29:19 --> Config Class Initialized
INFO - 2016-08-30 03:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:29:19 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:29:19 --> Utf8 Class Initialized
INFO - 2016-08-30 03:29:19 --> URI Class Initialized
INFO - 2016-08-30 03:29:19 --> Router Class Initialized
INFO - 2016-08-30 03:29:19 --> Output Class Initialized
INFO - 2016-08-30 03:29:19 --> Security Class Initialized
DEBUG - 2016-08-30 03:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:29:19 --> Input Class Initialized
INFO - 2016-08-30 03:29:19 --> Language Class Initialized
INFO - 2016-08-30 03:29:19 --> Loader Class Initialized
INFO - 2016-08-30 03:29:19 --> Helper loaded: url_helper
INFO - 2016-08-30 03:29:19 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:29:19 --> Helper loaded: html_helper
INFO - 2016-08-30 03:29:19 --> Helper loaded: form_helper
INFO - 2016-08-30 03:29:19 --> Helper loaded: file_helper
INFO - 2016-08-30 03:29:19 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:29:19 --> Database Driver Class Initialized
INFO - 2016-08-30 03:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:29:19 --> Form Validation Class Initialized
INFO - 2016-08-30 03:29:19 --> Email Class Initialized
INFO - 2016-08-30 03:29:19 --> Controller Class Initialized
DEBUG - 2016-08-30 03:29:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-30 03:29:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:29:19 --> Model Class Initialized
INFO - 2016-08-30 03:29:19 --> Model Class Initialized
INFO - 2016-08-30 03:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-30 03:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:29:19 --> Final output sent to browser
DEBUG - 2016-08-30 03:29:19 --> Total execution time: 0.6796
INFO - 2016-08-30 03:38:51 --> Config Class Initialized
INFO - 2016-08-30 03:38:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:38:51 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:38:51 --> Utf8 Class Initialized
INFO - 2016-08-30 03:38:51 --> URI Class Initialized
INFO - 2016-08-30 03:38:51 --> Router Class Initialized
INFO - 2016-08-30 03:38:51 --> Output Class Initialized
INFO - 2016-08-30 03:38:51 --> Security Class Initialized
DEBUG - 2016-08-30 03:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:38:51 --> Input Class Initialized
INFO - 2016-08-30 03:38:51 --> Language Class Initialized
INFO - 2016-08-30 03:38:51 --> Loader Class Initialized
INFO - 2016-08-30 03:38:51 --> Helper loaded: url_helper
INFO - 2016-08-30 03:38:51 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:38:51 --> Helper loaded: html_helper
INFO - 2016-08-30 03:38:51 --> Helper loaded: form_helper
INFO - 2016-08-30 03:38:51 --> Helper loaded: file_helper
INFO - 2016-08-30 03:38:51 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:38:51 --> Database Driver Class Initialized
INFO - 2016-08-30 03:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:38:51 --> Form Validation Class Initialized
INFO - 2016-08-30 03:38:51 --> Email Class Initialized
INFO - 2016-08-30 03:38:51 --> Controller Class Initialized
DEBUG - 2016-08-30 03:38:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:38:51 --> Model Class Initialized
INFO - 2016-08-30 03:38:51 --> Model Class Initialized
INFO - 2016-08-30 03:38:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:38:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:38:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:38:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:38:51 --> Final output sent to browser
DEBUG - 2016-08-30 03:38:51 --> Total execution time: 0.2945
INFO - 2016-08-30 03:38:56 --> Config Class Initialized
INFO - 2016-08-30 03:38:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:38:56 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:38:56 --> Utf8 Class Initialized
INFO - 2016-08-30 03:38:56 --> URI Class Initialized
INFO - 2016-08-30 03:38:56 --> Router Class Initialized
INFO - 2016-08-30 03:38:56 --> Output Class Initialized
INFO - 2016-08-30 03:38:56 --> Security Class Initialized
DEBUG - 2016-08-30 03:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:38:56 --> Input Class Initialized
INFO - 2016-08-30 03:38:56 --> Language Class Initialized
INFO - 2016-08-30 03:38:56 --> Loader Class Initialized
INFO - 2016-08-30 03:38:56 --> Helper loaded: url_helper
INFO - 2016-08-30 03:38:56 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:38:56 --> Helper loaded: html_helper
INFO - 2016-08-30 03:38:56 --> Helper loaded: form_helper
INFO - 2016-08-30 03:38:56 --> Helper loaded: file_helper
INFO - 2016-08-30 03:38:56 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:38:56 --> Database Driver Class Initialized
INFO - 2016-08-30 03:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:38:56 --> Form Validation Class Initialized
INFO - 2016-08-30 03:38:56 --> Email Class Initialized
INFO - 2016-08-30 03:38:56 --> Controller Class Initialized
DEBUG - 2016-08-30 03:38:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:38:56 --> Model Class Initialized
INFO - 2016-08-30 03:38:56 --> Model Class Initialized
INFO - 2016-08-30 03:38:57 --> Final output sent to browser
DEBUG - 2016-08-30 03:38:57 --> Total execution time: 0.6862
INFO - 2016-08-30 03:39:12 --> Config Class Initialized
INFO - 2016-08-30 03:39:12 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:39:12 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:39:12 --> Utf8 Class Initialized
INFO - 2016-08-30 03:39:12 --> URI Class Initialized
INFO - 2016-08-30 03:39:12 --> Router Class Initialized
INFO - 2016-08-30 03:39:12 --> Output Class Initialized
INFO - 2016-08-30 03:39:12 --> Security Class Initialized
DEBUG - 2016-08-30 03:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:39:12 --> Input Class Initialized
INFO - 2016-08-30 03:39:12 --> Language Class Initialized
INFO - 2016-08-30 03:39:12 --> Loader Class Initialized
INFO - 2016-08-30 03:39:12 --> Helper loaded: url_helper
INFO - 2016-08-30 03:39:12 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:39:12 --> Helper loaded: html_helper
INFO - 2016-08-30 03:39:12 --> Helper loaded: form_helper
INFO - 2016-08-30 03:39:12 --> Helper loaded: file_helper
INFO - 2016-08-30 03:39:12 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:39:12 --> Database Driver Class Initialized
INFO - 2016-08-30 03:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:39:12 --> Form Validation Class Initialized
INFO - 2016-08-30 03:39:12 --> Email Class Initialized
INFO - 2016-08-30 03:39:12 --> Controller Class Initialized
INFO - 2016-08-30 03:39:12 --> Model Class Initialized
INFO - 2016-08-30 03:39:12 --> Model Class Initialized
INFO - 2016-08-30 03:39:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:39:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:39:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-30 03:39:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:39:12 --> Final output sent to browser
DEBUG - 2016-08-30 03:39:12 --> Total execution time: 0.4470
INFO - 2016-08-30 03:39:14 --> Config Class Initialized
INFO - 2016-08-30 03:39:14 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:39:14 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:39:14 --> Utf8 Class Initialized
INFO - 2016-08-30 03:39:14 --> URI Class Initialized
INFO - 2016-08-30 03:39:14 --> Router Class Initialized
INFO - 2016-08-30 03:39:14 --> Output Class Initialized
INFO - 2016-08-30 03:39:14 --> Security Class Initialized
DEBUG - 2016-08-30 03:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:39:14 --> Input Class Initialized
INFO - 2016-08-30 03:39:14 --> Language Class Initialized
INFO - 2016-08-30 03:39:14 --> Loader Class Initialized
INFO - 2016-08-30 03:39:14 --> Helper loaded: url_helper
INFO - 2016-08-30 03:39:14 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:39:14 --> Helper loaded: html_helper
INFO - 2016-08-30 03:39:14 --> Helper loaded: form_helper
INFO - 2016-08-30 03:39:14 --> Helper loaded: file_helper
INFO - 2016-08-30 03:39:14 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:39:14 --> Database Driver Class Initialized
INFO - 2016-08-30 03:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:39:14 --> Form Validation Class Initialized
INFO - 2016-08-30 03:39:14 --> Email Class Initialized
INFO - 2016-08-30 03:39:14 --> Controller Class Initialized
INFO - 2016-08-30 03:39:14 --> Model Class Initialized
INFO - 2016-08-30 03:39:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:39:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-30 03:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:39:15 --> Final output sent to browser
DEBUG - 2016-08-30 03:39:15 --> Total execution time: 0.3043
INFO - 2016-08-30 03:39:16 --> Config Class Initialized
INFO - 2016-08-30 03:39:16 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:39:16 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:39:16 --> Utf8 Class Initialized
INFO - 2016-08-30 03:39:16 --> URI Class Initialized
INFO - 2016-08-30 03:39:16 --> Router Class Initialized
INFO - 2016-08-30 03:39:16 --> Output Class Initialized
INFO - 2016-08-30 03:39:16 --> Security Class Initialized
DEBUG - 2016-08-30 03:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:39:16 --> Input Class Initialized
INFO - 2016-08-30 03:39:16 --> Language Class Initialized
INFO - 2016-08-30 03:39:16 --> Loader Class Initialized
INFO - 2016-08-30 03:39:16 --> Helper loaded: url_helper
INFO - 2016-08-30 03:39:16 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:39:17 --> Helper loaded: html_helper
INFO - 2016-08-30 03:39:17 --> Helper loaded: form_helper
INFO - 2016-08-30 03:39:17 --> Helper loaded: file_helper
INFO - 2016-08-30 03:39:17 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:39:17 --> Database Driver Class Initialized
INFO - 2016-08-30 03:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:39:17 --> Form Validation Class Initialized
INFO - 2016-08-30 03:39:17 --> Email Class Initialized
INFO - 2016-08-30 03:39:17 --> Controller Class Initialized
DEBUG - 2016-08-30 03:39:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:39:17 --> Model Class Initialized
INFO - 2016-08-30 03:39:17 --> Model Class Initialized
INFO - 2016-08-30 03:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:39:17 --> Model Class Initialized
INFO - 2016-08-30 03:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-30 03:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:39:17 --> Final output sent to browser
DEBUG - 2016-08-30 03:39:17 --> Total execution time: 0.3092
INFO - 2016-08-30 03:39:21 --> Config Class Initialized
INFO - 2016-08-30 03:39:21 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:39:21 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:39:21 --> Utf8 Class Initialized
INFO - 2016-08-30 03:39:21 --> URI Class Initialized
INFO - 2016-08-30 03:39:21 --> Router Class Initialized
INFO - 2016-08-30 03:39:21 --> Output Class Initialized
INFO - 2016-08-30 03:39:21 --> Security Class Initialized
DEBUG - 2016-08-30 03:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:39:21 --> Input Class Initialized
INFO - 2016-08-30 03:39:22 --> Language Class Initialized
INFO - 2016-08-30 03:39:22 --> Loader Class Initialized
INFO - 2016-08-30 03:39:22 --> Helper loaded: url_helper
INFO - 2016-08-30 03:39:22 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:39:22 --> Helper loaded: html_helper
INFO - 2016-08-30 03:39:22 --> Helper loaded: form_helper
INFO - 2016-08-30 03:39:22 --> Helper loaded: file_helper
INFO - 2016-08-30 03:39:22 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:39:22 --> Database Driver Class Initialized
INFO - 2016-08-30 03:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:39:22 --> Form Validation Class Initialized
INFO - 2016-08-30 03:39:22 --> Email Class Initialized
INFO - 2016-08-30 03:39:22 --> Controller Class Initialized
INFO - 2016-08-30 03:39:22 --> Model Class Initialized
INFO - 2016-08-30 03:39:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:39:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:39:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-30 03:39:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:39:22 --> Final output sent to browser
DEBUG - 2016-08-30 03:39:22 --> Total execution time: 0.2956
INFO - 2016-08-30 03:40:03 --> Config Class Initialized
INFO - 2016-08-30 03:40:03 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:40:03 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:40:03 --> Utf8 Class Initialized
INFO - 2016-08-30 03:40:03 --> URI Class Initialized
INFO - 2016-08-30 03:40:03 --> Router Class Initialized
INFO - 2016-08-30 03:40:03 --> Output Class Initialized
INFO - 2016-08-30 03:40:03 --> Security Class Initialized
DEBUG - 2016-08-30 03:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:40:03 --> Input Class Initialized
INFO - 2016-08-30 03:40:03 --> Language Class Initialized
INFO - 2016-08-30 03:40:03 --> Loader Class Initialized
INFO - 2016-08-30 03:40:03 --> Helper loaded: url_helper
INFO - 2016-08-30 03:40:03 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:40:03 --> Helper loaded: html_helper
INFO - 2016-08-30 03:40:03 --> Helper loaded: form_helper
INFO - 2016-08-30 03:40:03 --> Helper loaded: file_helper
INFO - 2016-08-30 03:40:03 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:40:03 --> Database Driver Class Initialized
INFO - 2016-08-30 03:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:40:03 --> Form Validation Class Initialized
INFO - 2016-08-30 03:40:03 --> Email Class Initialized
INFO - 2016-08-30 03:40:03 --> Controller Class Initialized
DEBUG - 2016-08-30 03:40:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:40:04 --> Model Class Initialized
INFO - 2016-08-30 03:40:04 --> Model Class Initialized
INFO - 2016-08-30 03:40:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:40:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:40:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 03:40:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:40:04 --> Final output sent to browser
DEBUG - 2016-08-30 03:40:04 --> Total execution time: 0.3103
INFO - 2016-08-30 03:42:51 --> Config Class Initialized
INFO - 2016-08-30 03:42:51 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:42:51 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:42:51 --> Utf8 Class Initialized
INFO - 2016-08-30 03:42:51 --> URI Class Initialized
INFO - 2016-08-30 03:42:51 --> Router Class Initialized
INFO - 2016-08-30 03:42:51 --> Output Class Initialized
INFO - 2016-08-30 03:42:51 --> Security Class Initialized
DEBUG - 2016-08-30 03:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:42:51 --> Input Class Initialized
INFO - 2016-08-30 03:42:51 --> Language Class Initialized
INFO - 2016-08-30 03:42:51 --> Loader Class Initialized
INFO - 2016-08-30 03:42:51 --> Helper loaded: url_helper
INFO - 2016-08-30 03:42:51 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:42:51 --> Helper loaded: html_helper
INFO - 2016-08-30 03:42:51 --> Helper loaded: form_helper
INFO - 2016-08-30 03:42:51 --> Helper loaded: file_helper
INFO - 2016-08-30 03:42:51 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:42:51 --> Database Driver Class Initialized
INFO - 2016-08-30 03:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:42:52 --> Form Validation Class Initialized
INFO - 2016-08-30 03:42:52 --> Email Class Initialized
INFO - 2016-08-30 03:42:52 --> Controller Class Initialized
INFO - 2016-08-30 03:42:52 --> Model Class Initialized
INFO - 2016-08-30 03:42:52 --> Config Class Initialized
INFO - 2016-08-30 03:42:52 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:42:52 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:42:52 --> Utf8 Class Initialized
INFO - 2016-08-30 03:42:52 --> URI Class Initialized
INFO - 2016-08-30 03:42:52 --> Router Class Initialized
INFO - 2016-08-30 03:42:52 --> Output Class Initialized
INFO - 2016-08-30 03:42:52 --> Security Class Initialized
DEBUG - 2016-08-30 03:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:42:52 --> Input Class Initialized
INFO - 2016-08-30 03:42:52 --> Language Class Initialized
INFO - 2016-08-30 03:42:52 --> Loader Class Initialized
INFO - 2016-08-30 03:42:52 --> Helper loaded: url_helper
INFO - 2016-08-30 03:42:52 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:42:52 --> Helper loaded: html_helper
INFO - 2016-08-30 03:42:52 --> Helper loaded: form_helper
INFO - 2016-08-30 03:42:52 --> Helper loaded: file_helper
INFO - 2016-08-30 03:42:52 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:42:52 --> Database Driver Class Initialized
INFO - 2016-08-30 03:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:42:52 --> Form Validation Class Initialized
INFO - 2016-08-30 03:42:52 --> Email Class Initialized
INFO - 2016-08-30 03:42:52 --> Controller Class Initialized
INFO - 2016-08-30 03:42:52 --> Model Class Initialized
DEBUG - 2016-08-30 03:42:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:42:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 03:42:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:42:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 03:42:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:42:52 --> Final output sent to browser
DEBUG - 2016-08-30 03:42:52 --> Total execution time: 0.5418
INFO - 2016-08-30 03:42:57 --> Config Class Initialized
INFO - 2016-08-30 03:42:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:42:57 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:42:57 --> Utf8 Class Initialized
INFO - 2016-08-30 03:42:57 --> URI Class Initialized
INFO - 2016-08-30 03:42:57 --> Router Class Initialized
INFO - 2016-08-30 03:42:57 --> Output Class Initialized
INFO - 2016-08-30 03:42:57 --> Security Class Initialized
DEBUG - 2016-08-30 03:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:42:57 --> Input Class Initialized
INFO - 2016-08-30 03:42:57 --> Language Class Initialized
INFO - 2016-08-30 03:42:57 --> Loader Class Initialized
INFO - 2016-08-30 03:42:57 --> Helper loaded: url_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: html_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: form_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: file_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:42:57 --> Database Driver Class Initialized
INFO - 2016-08-30 03:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:42:57 --> Form Validation Class Initialized
INFO - 2016-08-30 03:42:57 --> Email Class Initialized
INFO - 2016-08-30 03:42:57 --> Controller Class Initialized
INFO - 2016-08-30 03:42:57 --> Model Class Initialized
DEBUG - 2016-08-30 03:42:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:42:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 03:42:57 --> Config Class Initialized
INFO - 2016-08-30 03:42:57 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:42:57 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:42:57 --> Utf8 Class Initialized
INFO - 2016-08-30 03:42:57 --> URI Class Initialized
INFO - 2016-08-30 03:42:57 --> Router Class Initialized
INFO - 2016-08-30 03:42:57 --> Output Class Initialized
INFO - 2016-08-30 03:42:57 --> Security Class Initialized
DEBUG - 2016-08-30 03:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:42:57 --> Input Class Initialized
INFO - 2016-08-30 03:42:57 --> Language Class Initialized
INFO - 2016-08-30 03:42:57 --> Loader Class Initialized
INFO - 2016-08-30 03:42:57 --> Helper loaded: url_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: html_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: form_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: file_helper
INFO - 2016-08-30 03:42:57 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:42:57 --> Database Driver Class Initialized
INFO - 2016-08-30 03:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:42:57 --> Form Validation Class Initialized
INFO - 2016-08-30 03:42:57 --> Email Class Initialized
INFO - 2016-08-30 03:42:57 --> Controller Class Initialized
INFO - 2016-08-30 03:42:57 --> Model Class Initialized
INFO - 2016-08-30 03:42:57 --> Model Class Initialized
INFO - 2016-08-30 03:42:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-30 03:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:42:58 --> Final output sent to browser
DEBUG - 2016-08-30 03:42:58 --> Total execution time: 0.4257
INFO - 2016-08-30 03:43:02 --> Config Class Initialized
INFO - 2016-08-30 03:43:02 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:43:02 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:43:02 --> Utf8 Class Initialized
INFO - 2016-08-30 03:43:02 --> URI Class Initialized
INFO - 2016-08-30 03:43:02 --> Router Class Initialized
INFO - 2016-08-30 03:43:02 --> Output Class Initialized
INFO - 2016-08-30 03:43:02 --> Security Class Initialized
DEBUG - 2016-08-30 03:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:43:02 --> Input Class Initialized
INFO - 2016-08-30 03:43:02 --> Language Class Initialized
INFO - 2016-08-30 03:43:02 --> Loader Class Initialized
INFO - 2016-08-30 03:43:02 --> Helper loaded: url_helper
INFO - 2016-08-30 03:43:02 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:43:02 --> Helper loaded: html_helper
INFO - 2016-08-30 03:43:02 --> Helper loaded: form_helper
INFO - 2016-08-30 03:43:02 --> Helper loaded: file_helper
INFO - 2016-08-30 03:43:02 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:43:02 --> Database Driver Class Initialized
INFO - 2016-08-30 03:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:43:02 --> Form Validation Class Initialized
INFO - 2016-08-30 03:43:02 --> Email Class Initialized
INFO - 2016-08-30 03:43:02 --> Controller Class Initialized
INFO - 2016-08-30 03:43:02 --> Model Class Initialized
INFO - 2016-08-30 03:43:02 --> Model Class Initialized
INFO - 2016-08-30 03:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-30 03:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:43:02 --> Final output sent to browser
DEBUG - 2016-08-30 03:43:02 --> Total execution time: 0.4692
INFO - 2016-08-30 03:43:06 --> Config Class Initialized
INFO - 2016-08-30 03:43:06 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:43:06 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:43:06 --> Utf8 Class Initialized
INFO - 2016-08-30 03:43:06 --> URI Class Initialized
INFO - 2016-08-30 03:43:06 --> Router Class Initialized
INFO - 2016-08-30 03:43:06 --> Output Class Initialized
INFO - 2016-08-30 03:43:06 --> Security Class Initialized
DEBUG - 2016-08-30 03:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:43:06 --> Input Class Initialized
INFO - 2016-08-30 03:43:06 --> Language Class Initialized
INFO - 2016-08-30 03:43:06 --> Loader Class Initialized
INFO - 2016-08-30 03:43:06 --> Helper loaded: url_helper
INFO - 2016-08-30 03:43:06 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:43:06 --> Helper loaded: html_helper
INFO - 2016-08-30 03:43:06 --> Helper loaded: form_helper
INFO - 2016-08-30 03:43:06 --> Helper loaded: file_helper
INFO - 2016-08-30 03:43:06 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:43:06 --> Database Driver Class Initialized
INFO - 2016-08-30 03:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:43:06 --> Form Validation Class Initialized
INFO - 2016-08-30 03:43:06 --> Email Class Initialized
INFO - 2016-08-30 03:43:06 --> Controller Class Initialized
INFO - 2016-08-30 03:43:06 --> Model Class Initialized
INFO - 2016-08-30 03:43:06 --> Model Class Initialized
INFO - 2016-08-30 03:43:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:43:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:43:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-30 03:43:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:43:06 --> Final output sent to browser
DEBUG - 2016-08-30 03:43:06 --> Total execution time: 0.2958
INFO - 2016-08-30 03:43:52 --> Config Class Initialized
INFO - 2016-08-30 03:43:52 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:43:52 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:43:52 --> Utf8 Class Initialized
INFO - 2016-08-30 03:43:52 --> URI Class Initialized
INFO - 2016-08-30 03:43:52 --> Router Class Initialized
INFO - 2016-08-30 03:43:52 --> Output Class Initialized
INFO - 2016-08-30 03:43:52 --> Security Class Initialized
DEBUG - 2016-08-30 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:43:52 --> Input Class Initialized
INFO - 2016-08-30 03:43:52 --> Language Class Initialized
INFO - 2016-08-30 03:43:52 --> Loader Class Initialized
INFO - 2016-08-30 03:43:52 --> Helper loaded: url_helper
INFO - 2016-08-30 03:43:52 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:43:52 --> Helper loaded: html_helper
INFO - 2016-08-30 03:43:52 --> Helper loaded: form_helper
INFO - 2016-08-30 03:43:52 --> Helper loaded: file_helper
INFO - 2016-08-30 03:43:52 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:43:52 --> Database Driver Class Initialized
INFO - 2016-08-30 03:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:43:52 --> Form Validation Class Initialized
INFO - 2016-08-30 03:43:52 --> Email Class Initialized
INFO - 2016-08-30 03:43:52 --> Controller Class Initialized
DEBUG - 2016-08-30 03:43:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 03:43:52 --> Model Class Initialized
INFO - 2016-08-30 03:43:52 --> Model Class Initialized
INFO - 2016-08-30 03:43:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:43:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:43:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-30 03:43:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:43:53 --> Final output sent to browser
DEBUG - 2016-08-30 03:43:53 --> Total execution time: 0.3064
INFO - 2016-08-30 03:43:56 --> Config Class Initialized
INFO - 2016-08-30 03:43:56 --> Hooks Class Initialized
DEBUG - 2016-08-30 03:43:56 --> UTF-8 Support Enabled
INFO - 2016-08-30 03:43:56 --> Utf8 Class Initialized
INFO - 2016-08-30 03:43:56 --> URI Class Initialized
INFO - 2016-08-30 03:43:56 --> Router Class Initialized
INFO - 2016-08-30 03:43:56 --> Output Class Initialized
INFO - 2016-08-30 03:43:56 --> Security Class Initialized
DEBUG - 2016-08-30 03:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 03:43:56 --> Input Class Initialized
INFO - 2016-08-30 03:43:56 --> Language Class Initialized
INFO - 2016-08-30 03:43:56 --> Loader Class Initialized
INFO - 2016-08-30 03:43:56 --> Helper loaded: url_helper
INFO - 2016-08-30 03:43:56 --> Helper loaded: utils_helper
INFO - 2016-08-30 03:43:56 --> Helper loaded: html_helper
INFO - 2016-08-30 03:43:56 --> Helper loaded: form_helper
INFO - 2016-08-30 03:43:56 --> Helper loaded: file_helper
INFO - 2016-08-30 03:43:56 --> Helper loaded: myemail_helper
INFO - 2016-08-30 03:43:56 --> Database Driver Class Initialized
INFO - 2016-08-30 03:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 03:43:56 --> Form Validation Class Initialized
INFO - 2016-08-30 03:43:56 --> Email Class Initialized
INFO - 2016-08-30 03:43:56 --> Controller Class Initialized
INFO - 2016-08-30 03:43:56 --> Model Class Initialized
INFO - 2016-08-30 03:43:56 --> Model Class Initialized
INFO - 2016-08-30 03:43:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 03:43:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 03:43:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-30 03:43:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 03:43:56 --> Final output sent to browser
DEBUG - 2016-08-30 03:43:56 --> Total execution time: 0.4943
INFO - 2016-08-30 06:22:43 --> Config Class Initialized
INFO - 2016-08-30 06:22:43 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:22:43 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:22:43 --> Utf8 Class Initialized
INFO - 2016-08-30 06:22:44 --> URI Class Initialized
DEBUG - 2016-08-30 06:22:44 --> No URI present. Default controller set.
INFO - 2016-08-30 06:22:44 --> Router Class Initialized
INFO - 2016-08-30 06:22:44 --> Output Class Initialized
INFO - 2016-08-30 06:22:44 --> Security Class Initialized
DEBUG - 2016-08-30 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:22:44 --> Input Class Initialized
INFO - 2016-08-30 06:22:44 --> Language Class Initialized
INFO - 2016-08-30 06:22:44 --> Loader Class Initialized
INFO - 2016-08-30 06:22:44 --> Helper loaded: url_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: html_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: form_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: file_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:22:44 --> Database Driver Class Initialized
INFO - 2016-08-30 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:22:44 --> Form Validation Class Initialized
INFO - 2016-08-30 06:22:44 --> Email Class Initialized
INFO - 2016-08-30 06:22:44 --> Controller Class Initialized
INFO - 2016-08-30 06:22:44 --> Config Class Initialized
INFO - 2016-08-30 06:22:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:22:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:22:44 --> Utf8 Class Initialized
INFO - 2016-08-30 06:22:44 --> URI Class Initialized
INFO - 2016-08-30 06:22:44 --> Router Class Initialized
INFO - 2016-08-30 06:22:44 --> Output Class Initialized
INFO - 2016-08-30 06:22:44 --> Security Class Initialized
DEBUG - 2016-08-30 06:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:22:44 --> Input Class Initialized
INFO - 2016-08-30 06:22:44 --> Language Class Initialized
INFO - 2016-08-30 06:22:44 --> Loader Class Initialized
INFO - 2016-08-30 06:22:44 --> Helper loaded: url_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: html_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: form_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: file_helper
INFO - 2016-08-30 06:22:44 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:22:44 --> Database Driver Class Initialized
INFO - 2016-08-30 06:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:22:44 --> Form Validation Class Initialized
INFO - 2016-08-30 06:22:44 --> Email Class Initialized
INFO - 2016-08-30 06:22:44 --> Controller Class Initialized
INFO - 2016-08-30 06:22:44 --> Model Class Initialized
DEBUG - 2016-08-30 06:22:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:22:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 06:22:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:22:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 06:22:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:22:45 --> Final output sent to browser
DEBUG - 2016-08-30 06:22:45 --> Total execution time: 0.3940
INFO - 2016-08-30 06:22:54 --> Config Class Initialized
INFO - 2016-08-30 06:22:54 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:22:54 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:22:54 --> Utf8 Class Initialized
INFO - 2016-08-30 06:22:54 --> URI Class Initialized
INFO - 2016-08-30 06:22:54 --> Router Class Initialized
INFO - 2016-08-30 06:22:54 --> Output Class Initialized
INFO - 2016-08-30 06:22:54 --> Security Class Initialized
DEBUG - 2016-08-30 06:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:22:54 --> Input Class Initialized
INFO - 2016-08-30 06:22:54 --> Language Class Initialized
INFO - 2016-08-30 06:22:54 --> Loader Class Initialized
INFO - 2016-08-30 06:22:54 --> Helper loaded: url_helper
INFO - 2016-08-30 06:22:54 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:22:54 --> Helper loaded: html_helper
INFO - 2016-08-30 06:22:54 --> Helper loaded: form_helper
INFO - 2016-08-30 06:22:54 --> Helper loaded: file_helper
INFO - 2016-08-30 06:22:54 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:22:54 --> Database Driver Class Initialized
INFO - 2016-08-30 06:22:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:22:54 --> Form Validation Class Initialized
INFO - 2016-08-30 06:22:54 --> Email Class Initialized
INFO - 2016-08-30 06:22:54 --> Controller Class Initialized
INFO - 2016-08-30 06:22:54 --> Model Class Initialized
DEBUG - 2016-08-30 06:22:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:22:54 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-30 06:22:55 --> Config Class Initialized
INFO - 2016-08-30 06:22:55 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:22:55 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:22:55 --> Utf8 Class Initialized
INFO - 2016-08-30 06:22:55 --> URI Class Initialized
DEBUG - 2016-08-30 06:22:55 --> No URI present. Default controller set.
INFO - 2016-08-30 06:22:55 --> Router Class Initialized
INFO - 2016-08-30 06:22:55 --> Output Class Initialized
INFO - 2016-08-30 06:22:55 --> Security Class Initialized
DEBUG - 2016-08-30 06:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:22:55 --> Input Class Initialized
INFO - 2016-08-30 06:22:55 --> Language Class Initialized
INFO - 2016-08-30 06:22:55 --> Loader Class Initialized
INFO - 2016-08-30 06:22:55 --> Helper loaded: url_helper
INFO - 2016-08-30 06:22:55 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:22:55 --> Helper loaded: html_helper
INFO - 2016-08-30 06:22:55 --> Helper loaded: form_helper
INFO - 2016-08-30 06:22:55 --> Helper loaded: file_helper
INFO - 2016-08-30 06:22:55 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:22:55 --> Database Driver Class Initialized
INFO - 2016-08-30 06:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:22:55 --> Form Validation Class Initialized
INFO - 2016-08-30 06:22:55 --> Email Class Initialized
INFO - 2016-08-30 06:22:55 --> Controller Class Initialized
INFO - 2016-08-30 06:22:55 --> Model Class Initialized
INFO - 2016-08-30 06:22:55 --> Model Class Initialized
INFO - 2016-08-30 06:22:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:22:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:22:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-30 06:22:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:22:55 --> Final output sent to browser
DEBUG - 2016-08-30 06:22:55 --> Total execution time: 0.3314
INFO - 2016-08-30 06:23:00 --> Config Class Initialized
INFO - 2016-08-30 06:23:00 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:23:00 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:23:00 --> Utf8 Class Initialized
INFO - 2016-08-30 06:23:00 --> URI Class Initialized
INFO - 2016-08-30 06:23:00 --> Router Class Initialized
INFO - 2016-08-30 06:23:00 --> Output Class Initialized
INFO - 2016-08-30 06:23:00 --> Security Class Initialized
DEBUG - 2016-08-30 06:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:23:00 --> Input Class Initialized
INFO - 2016-08-30 06:23:00 --> Language Class Initialized
INFO - 2016-08-30 06:23:00 --> Loader Class Initialized
INFO - 2016-08-30 06:23:00 --> Helper loaded: url_helper
INFO - 2016-08-30 06:23:00 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:23:00 --> Helper loaded: html_helper
INFO - 2016-08-30 06:23:00 --> Helper loaded: form_helper
INFO - 2016-08-30 06:23:00 --> Helper loaded: file_helper
INFO - 2016-08-30 06:23:00 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:23:00 --> Database Driver Class Initialized
INFO - 2016-08-30 06:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:23:00 --> Form Validation Class Initialized
INFO - 2016-08-30 06:23:00 --> Email Class Initialized
INFO - 2016-08-30 06:23:00 --> Controller Class Initialized
DEBUG - 2016-08-30 06:23:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:23:00 --> Model Class Initialized
INFO - 2016-08-30 06:23:00 --> Model Class Initialized
INFO - 2016-08-30 06:23:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:23:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:23:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-30 06:23:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:23:00 --> Final output sent to browser
DEBUG - 2016-08-30 06:23:00 --> Total execution time: 0.3522
INFO - 2016-08-30 06:23:16 --> Config Class Initialized
INFO - 2016-08-30 06:23:16 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:23:16 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:23:16 --> Utf8 Class Initialized
INFO - 2016-08-30 06:23:16 --> URI Class Initialized
INFO - 2016-08-30 06:23:16 --> Router Class Initialized
INFO - 2016-08-30 06:23:16 --> Output Class Initialized
INFO - 2016-08-30 06:23:16 --> Security Class Initialized
DEBUG - 2016-08-30 06:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:23:16 --> Input Class Initialized
INFO - 2016-08-30 06:23:16 --> Language Class Initialized
INFO - 2016-08-30 06:23:16 --> Loader Class Initialized
INFO - 2016-08-30 06:23:16 --> Helper loaded: url_helper
INFO - 2016-08-30 06:23:16 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:23:16 --> Helper loaded: html_helper
INFO - 2016-08-30 06:23:16 --> Helper loaded: form_helper
INFO - 2016-08-30 06:23:16 --> Helper loaded: file_helper
INFO - 2016-08-30 06:23:16 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:23:16 --> Database Driver Class Initialized
INFO - 2016-08-30 06:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:23:16 --> Form Validation Class Initialized
INFO - 2016-08-30 06:23:16 --> Email Class Initialized
INFO - 2016-08-30 06:23:16 --> Controller Class Initialized
DEBUG - 2016-08-30 06:23:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:23:16 --> Model Class Initialized
INFO - 2016-08-30 06:23:16 --> Model Class Initialized
INFO - 2016-08-30 06:23:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:23:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:23:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 06:23:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:23:17 --> Final output sent to browser
DEBUG - 2016-08-30 06:23:17 --> Total execution time: 0.3341
INFO - 2016-08-30 06:23:23 --> Config Class Initialized
INFO - 2016-08-30 06:23:23 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:23:23 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:23:23 --> Utf8 Class Initialized
INFO - 2016-08-30 06:23:23 --> URI Class Initialized
INFO - 2016-08-30 06:23:23 --> Router Class Initialized
INFO - 2016-08-30 06:23:23 --> Output Class Initialized
INFO - 2016-08-30 06:23:23 --> Security Class Initialized
DEBUG - 2016-08-30 06:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:23:23 --> Input Class Initialized
INFO - 2016-08-30 06:23:23 --> Language Class Initialized
INFO - 2016-08-30 06:23:23 --> Loader Class Initialized
INFO - 2016-08-30 06:23:23 --> Helper loaded: url_helper
INFO - 2016-08-30 06:23:23 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:23:23 --> Helper loaded: html_helper
INFO - 2016-08-30 06:23:23 --> Helper loaded: form_helper
INFO - 2016-08-30 06:23:23 --> Helper loaded: file_helper
INFO - 2016-08-30 06:23:23 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:23:23 --> Database Driver Class Initialized
INFO - 2016-08-30 06:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:23:23 --> Form Validation Class Initialized
INFO - 2016-08-30 06:23:23 --> Email Class Initialized
INFO - 2016-08-30 06:23:23 --> Controller Class Initialized
DEBUG - 2016-08-30 06:23:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:23:24 --> Model Class Initialized
INFO - 2016-08-30 06:23:24 --> Model Class Initialized
INFO - 2016-08-30 06:23:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:23:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:23:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-30 06:23:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:23:24 --> Final output sent to browser
DEBUG - 2016-08-30 06:23:24 --> Total execution time: 0.3294
INFO - 2016-08-30 06:23:35 --> Config Class Initialized
INFO - 2016-08-30 06:23:35 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:23:35 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:23:35 --> Utf8 Class Initialized
INFO - 2016-08-30 06:23:35 --> URI Class Initialized
INFO - 2016-08-30 06:23:35 --> Router Class Initialized
INFO - 2016-08-30 06:23:35 --> Output Class Initialized
INFO - 2016-08-30 06:23:35 --> Security Class Initialized
DEBUG - 2016-08-30 06:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:23:35 --> Input Class Initialized
INFO - 2016-08-30 06:23:35 --> Language Class Initialized
INFO - 2016-08-30 06:23:35 --> Loader Class Initialized
INFO - 2016-08-30 06:23:35 --> Helper loaded: url_helper
INFO - 2016-08-30 06:23:35 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:23:35 --> Helper loaded: html_helper
INFO - 2016-08-30 06:23:35 --> Helper loaded: form_helper
INFO - 2016-08-30 06:23:35 --> Helper loaded: file_helper
INFO - 2016-08-30 06:23:35 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:23:35 --> Database Driver Class Initialized
INFO - 2016-08-30 06:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:23:35 --> Form Validation Class Initialized
INFO - 2016-08-30 06:23:35 --> Email Class Initialized
INFO - 2016-08-30 06:23:35 --> Controller Class Initialized
DEBUG - 2016-08-30 06:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:23:35 --> Model Class Initialized
INFO - 2016-08-30 06:23:35 --> Model Class Initialized
INFO - 2016-08-30 06:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 06:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:23:35 --> Final output sent to browser
DEBUG - 2016-08-30 06:23:35 --> Total execution time: 0.3362
INFO - 2016-08-30 06:31:44 --> Config Class Initialized
INFO - 2016-08-30 06:31:44 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:31:44 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:31:44 --> Utf8 Class Initialized
INFO - 2016-08-30 06:31:44 --> URI Class Initialized
INFO - 2016-08-30 06:31:44 --> Router Class Initialized
INFO - 2016-08-30 06:31:44 --> Output Class Initialized
INFO - 2016-08-30 06:31:44 --> Security Class Initialized
DEBUG - 2016-08-30 06:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:31:44 --> Input Class Initialized
INFO - 2016-08-30 06:31:44 --> Language Class Initialized
INFO - 2016-08-30 06:31:44 --> Loader Class Initialized
INFO - 2016-08-30 06:31:44 --> Helper loaded: url_helper
INFO - 2016-08-30 06:31:44 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:31:44 --> Helper loaded: html_helper
INFO - 2016-08-30 06:31:44 --> Helper loaded: form_helper
INFO - 2016-08-30 06:31:44 --> Helper loaded: file_helper
INFO - 2016-08-30 06:31:44 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:31:44 --> Database Driver Class Initialized
INFO - 2016-08-30 06:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:31:44 --> Form Validation Class Initialized
INFO - 2016-08-30 06:31:44 --> Email Class Initialized
INFO - 2016-08-30 06:31:44 --> Controller Class Initialized
DEBUG - 2016-08-30 06:31:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:31:44 --> Model Class Initialized
INFO - 2016-08-30 06:31:44 --> Model Class Initialized
INFO - 2016-08-30 06:31:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:31:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-30 06:31:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-30 06:31:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:31:44 --> Final output sent to browser
DEBUG - 2016-08-30 06:31:44 --> Total execution time: 0.3312
INFO - 2016-08-30 06:32:36 --> Config Class Initialized
INFO - 2016-08-30 06:32:36 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:32:36 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:32:36 --> Utf8 Class Initialized
INFO - 2016-08-30 06:32:36 --> URI Class Initialized
INFO - 2016-08-30 06:32:36 --> Router Class Initialized
INFO - 2016-08-30 06:32:36 --> Output Class Initialized
INFO - 2016-08-30 06:32:36 --> Security Class Initialized
DEBUG - 2016-08-30 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:32:36 --> Input Class Initialized
INFO - 2016-08-30 06:32:36 --> Language Class Initialized
INFO - 2016-08-30 06:32:36 --> Loader Class Initialized
INFO - 2016-08-30 06:32:36 --> Helper loaded: url_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: html_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: form_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: file_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:32:36 --> Database Driver Class Initialized
INFO - 2016-08-30 06:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:32:36 --> Form Validation Class Initialized
INFO - 2016-08-30 06:32:36 --> Email Class Initialized
INFO - 2016-08-30 06:32:36 --> Controller Class Initialized
INFO - 2016-08-30 06:32:36 --> Config Class Initialized
INFO - 2016-08-30 06:32:36 --> Hooks Class Initialized
DEBUG - 2016-08-30 06:32:36 --> UTF-8 Support Enabled
INFO - 2016-08-30 06:32:36 --> Utf8 Class Initialized
INFO - 2016-08-30 06:32:36 --> URI Class Initialized
INFO - 2016-08-30 06:32:36 --> Router Class Initialized
INFO - 2016-08-30 06:32:36 --> Output Class Initialized
INFO - 2016-08-30 06:32:36 --> Security Class Initialized
DEBUG - 2016-08-30 06:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-30 06:32:36 --> Input Class Initialized
INFO - 2016-08-30 06:32:36 --> Language Class Initialized
INFO - 2016-08-30 06:32:36 --> Loader Class Initialized
INFO - 2016-08-30 06:32:36 --> Helper loaded: url_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: utils_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: html_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: form_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: file_helper
INFO - 2016-08-30 06:32:36 --> Helper loaded: myemail_helper
INFO - 2016-08-30 06:32:36 --> Database Driver Class Initialized
INFO - 2016-08-30 06:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-30 06:32:36 --> Form Validation Class Initialized
INFO - 2016-08-30 06:32:36 --> Email Class Initialized
INFO - 2016-08-30 06:32:36 --> Controller Class Initialized
INFO - 2016-08-30 06:32:36 --> Model Class Initialized
DEBUG - 2016-08-30 06:32:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-30 06:32:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-30 06:32:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-30 06:32:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-30 06:32:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-30 06:32:36 --> Final output sent to browser
DEBUG - 2016-08-30 06:32:36 --> Total execution time: 0.3050
