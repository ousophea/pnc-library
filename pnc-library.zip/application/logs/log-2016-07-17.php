<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-17 17:58:01 --> Config Class Initialized
INFO - 2016-07-17 17:58:01 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:01 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:01 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:01 --> URI Class Initialized
DEBUG - 2016-07-17 17:58:01 --> No URI present. Default controller set.
INFO - 2016-07-17 17:58:01 --> Router Class Initialized
INFO - 2016-07-17 17:58:01 --> Output Class Initialized
INFO - 2016-07-17 17:58:01 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:01 --> Input Class Initialized
INFO - 2016-07-17 17:58:01 --> Language Class Initialized
INFO - 2016-07-17 17:58:01 --> Loader Class Initialized
INFO - 2016-07-17 17:58:01 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:01 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:01 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:01 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:01 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:01 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:01 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:02 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:02 --> Email Class Initialized
INFO - 2016-07-17 17:58:02 --> Controller Class Initialized
INFO - 2016-07-17 17:58:02 --> Config Class Initialized
INFO - 2016-07-17 17:58:02 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:02 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:02 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:02 --> URI Class Initialized
INFO - 2016-07-17 17:58:02 --> Router Class Initialized
INFO - 2016-07-17 17:58:02 --> Output Class Initialized
INFO - 2016-07-17 17:58:02 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:02 --> Input Class Initialized
INFO - 2016-07-17 17:58:02 --> Language Class Initialized
INFO - 2016-07-17 17:58:02 --> Loader Class Initialized
INFO - 2016-07-17 17:58:02 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:02 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:02 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:02 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:02 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:02 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:02 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:02 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:02 --> Email Class Initialized
INFO - 2016-07-17 17:58:02 --> Controller Class Initialized
INFO - 2016-07-17 17:58:02 --> Model Class Initialized
DEBUG - 2016-07-17 17:58:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-17 17:58:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-17 17:58:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:02 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:02 --> Total execution time: 0.4727
INFO - 2016-07-17 17:58:03 --> Config Class Initialized
INFO - 2016-07-17 17:58:03 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:03 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:03 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:03 --> URI Class Initialized
INFO - 2016-07-17 17:58:03 --> Router Class Initialized
INFO - 2016-07-17 17:58:03 --> Output Class Initialized
INFO - 2016-07-17 17:58:03 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:03 --> Input Class Initialized
INFO - 2016-07-17 17:58:03 --> Language Class Initialized
ERROR - 2016-07-17 17:58:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:07 --> Config Class Initialized
INFO - 2016-07-17 17:58:07 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:07 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:07 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:07 --> URI Class Initialized
INFO - 2016-07-17 17:58:07 --> Router Class Initialized
INFO - 2016-07-17 17:58:07 --> Output Class Initialized
INFO - 2016-07-17 17:58:07 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:07 --> Input Class Initialized
INFO - 2016-07-17 17:58:07 --> Language Class Initialized
INFO - 2016-07-17 17:58:07 --> Loader Class Initialized
INFO - 2016-07-17 17:58:07 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:07 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:07 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:07 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:07 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:07 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:07 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:07 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:07 --> Email Class Initialized
INFO - 2016-07-17 17:58:07 --> Controller Class Initialized
INFO - 2016-07-17 17:58:07 --> Model Class Initialized
DEBUG - 2016-07-17 17:58:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-17 17:58:07 --> Config Class Initialized
INFO - 2016-07-17 17:58:07 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:07 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:07 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:07 --> URI Class Initialized
DEBUG - 2016-07-17 17:58:07 --> No URI present. Default controller set.
INFO - 2016-07-17 17:58:07 --> Router Class Initialized
INFO - 2016-07-17 17:58:07 --> Output Class Initialized
INFO - 2016-07-17 17:58:07 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:08 --> Input Class Initialized
INFO - 2016-07-17 17:58:08 --> Language Class Initialized
INFO - 2016-07-17 17:58:08 --> Loader Class Initialized
INFO - 2016-07-17 17:58:08 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:08 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:08 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:08 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:08 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:08 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:08 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:08 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:08 --> Email Class Initialized
INFO - 2016-07-17 17:58:08 --> Controller Class Initialized
INFO - 2016-07-17 17:58:08 --> Model Class Initialized
INFO - 2016-07-17 17:58:08 --> Model Class Initialized
INFO - 2016-07-17 17:58:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-17 17:58:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:08 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:08 --> Total execution time: 0.2495
INFO - 2016-07-17 17:58:08 --> Config Class Initialized
INFO - 2016-07-17 17:58:08 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:08 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:08 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:08 --> URI Class Initialized
INFO - 2016-07-17 17:58:08 --> Router Class Initialized
INFO - 2016-07-17 17:58:08 --> Output Class Initialized
INFO - 2016-07-17 17:58:08 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:08 --> Input Class Initialized
INFO - 2016-07-17 17:58:08 --> Language Class Initialized
ERROR - 2016-07-17 17:58:08 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:13 --> Config Class Initialized
INFO - 2016-07-17 17:58:13 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:13 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:13 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:13 --> URI Class Initialized
INFO - 2016-07-17 17:58:13 --> Router Class Initialized
INFO - 2016-07-17 17:58:13 --> Output Class Initialized
INFO - 2016-07-17 17:58:13 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:13 --> Input Class Initialized
INFO - 2016-07-17 17:58:13 --> Language Class Initialized
INFO - 2016-07-17 17:58:13 --> Loader Class Initialized
INFO - 2016-07-17 17:58:13 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:13 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:13 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:13 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:13 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:13 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:13 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:13 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:13 --> Email Class Initialized
INFO - 2016-07-17 17:58:13 --> Controller Class Initialized
DEBUG - 2016-07-17 17:58:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:13 --> Model Class Initialized
INFO - 2016-07-17 17:58:13 --> Model Class Initialized
INFO - 2016-07-17 17:58:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-17 17:58:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:14 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:14 --> Total execution time: 0.4534
INFO - 2016-07-17 17:58:14 --> Config Class Initialized
INFO - 2016-07-17 17:58:14 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:14 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:14 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:14 --> URI Class Initialized
INFO - 2016-07-17 17:58:14 --> Router Class Initialized
INFO - 2016-07-17 17:58:14 --> Output Class Initialized
INFO - 2016-07-17 17:58:14 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:14 --> Input Class Initialized
INFO - 2016-07-17 17:58:14 --> Language Class Initialized
ERROR - 2016-07-17 17:58:14 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:15 --> Config Class Initialized
INFO - 2016-07-17 17:58:15 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:15 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:15 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:15 --> URI Class Initialized
INFO - 2016-07-17 17:58:15 --> Router Class Initialized
INFO - 2016-07-17 17:58:15 --> Output Class Initialized
INFO - 2016-07-17 17:58:15 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:15 --> Input Class Initialized
INFO - 2016-07-17 17:58:15 --> Language Class Initialized
INFO - 2016-07-17 17:58:15 --> Loader Class Initialized
INFO - 2016-07-17 17:58:15 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:15 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:15 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:15 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:15 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:15 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:15 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:15 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:15 --> Email Class Initialized
INFO - 2016-07-17 17:58:15 --> Controller Class Initialized
DEBUG - 2016-07-17 17:58:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:15 --> Model Class Initialized
INFO - 2016-07-17 17:58:15 --> Model Class Initialized
INFO - 2016-07-17 17:58:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-07-17 17:58:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:15 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:15 --> Total execution time: 0.3575
INFO - 2016-07-17 17:58:15 --> Config Class Initialized
INFO - 2016-07-17 17:58:15 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:15 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:15 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:15 --> URI Class Initialized
INFO - 2016-07-17 17:58:15 --> Router Class Initialized
INFO - 2016-07-17 17:58:15 --> Output Class Initialized
INFO - 2016-07-17 17:58:15 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:15 --> Input Class Initialized
INFO - 2016-07-17 17:58:15 --> Language Class Initialized
ERROR - 2016-07-17 17:58:15 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:25 --> Config Class Initialized
INFO - 2016-07-17 17:58:25 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:25 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:25 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:25 --> URI Class Initialized
INFO - 2016-07-17 17:58:25 --> Router Class Initialized
INFO - 2016-07-17 17:58:25 --> Output Class Initialized
INFO - 2016-07-17 17:58:25 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:25 --> Input Class Initialized
INFO - 2016-07-17 17:58:25 --> Language Class Initialized
INFO - 2016-07-17 17:58:25 --> Loader Class Initialized
INFO - 2016-07-17 17:58:25 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:25 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:25 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:25 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:25 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:25 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:25 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:25 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:25 --> Email Class Initialized
INFO - 2016-07-17 17:58:25 --> Controller Class Initialized
DEBUG - 2016-07-17 17:58:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:25 --> Model Class Initialized
INFO - 2016-07-17 17:58:25 --> Model Class Initialized
INFO - 2016-07-17 17:58:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-07-17 17:58:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:25 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:25 --> Total execution time: 0.3779
INFO - 2016-07-17 17:58:26 --> Config Class Initialized
INFO - 2016-07-17 17:58:26 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:26 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:26 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:26 --> URI Class Initialized
INFO - 2016-07-17 17:58:26 --> Router Class Initialized
INFO - 2016-07-17 17:58:26 --> Output Class Initialized
INFO - 2016-07-17 17:58:26 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:26 --> Input Class Initialized
INFO - 2016-07-17 17:58:26 --> Language Class Initialized
ERROR - 2016-07-17 17:58:26 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:45 --> Config Class Initialized
INFO - 2016-07-17 17:58:45 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:45 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:45 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:45 --> URI Class Initialized
INFO - 2016-07-17 17:58:45 --> Router Class Initialized
INFO - 2016-07-17 17:58:45 --> Output Class Initialized
INFO - 2016-07-17 17:58:45 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:45 --> Input Class Initialized
INFO - 2016-07-17 17:58:45 --> Language Class Initialized
INFO - 2016-07-17 17:58:45 --> Loader Class Initialized
INFO - 2016-07-17 17:58:45 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:45 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:45 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:45 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:45 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:45 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:45 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:45 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:45 --> Email Class Initialized
INFO - 2016-07-17 17:58:45 --> Controller Class Initialized
INFO - 2016-07-17 17:58:45 --> Model Class Initialized
INFO - 2016-07-17 17:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-07-17 17:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:45 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:45 --> Total execution time: 0.3323
INFO - 2016-07-17 17:58:45 --> Config Class Initialized
INFO - 2016-07-17 17:58:45 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:45 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:45 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:45 --> URI Class Initialized
INFO - 2016-07-17 17:58:46 --> Router Class Initialized
INFO - 2016-07-17 17:58:46 --> Output Class Initialized
INFO - 2016-07-17 17:58:46 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:46 --> Input Class Initialized
INFO - 2016-07-17 17:58:46 --> Language Class Initialized
ERROR - 2016-07-17 17:58:46 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:48 --> Config Class Initialized
INFO - 2016-07-17 17:58:48 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:48 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:48 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:48 --> URI Class Initialized
INFO - 2016-07-17 17:58:48 --> Router Class Initialized
INFO - 2016-07-17 17:58:48 --> Output Class Initialized
INFO - 2016-07-17 17:58:48 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:48 --> Input Class Initialized
INFO - 2016-07-17 17:58:48 --> Language Class Initialized
INFO - 2016-07-17 17:58:48 --> Loader Class Initialized
INFO - 2016-07-17 17:58:48 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:48 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:48 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:48 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:48 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:48 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:48 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:48 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:48 --> Email Class Initialized
INFO - 2016-07-17 17:58:48 --> Controller Class Initialized
DEBUG - 2016-07-17 17:58:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:48 --> Model Class Initialized
INFO - 2016-07-17 17:58:48 --> Model Class Initialized
INFO - 2016-07-17 17:58:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-17 17:58:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:48 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:48 --> Total execution time: 0.3203
INFO - 2016-07-17 17:58:49 --> Config Class Initialized
INFO - 2016-07-17 17:58:49 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:49 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:49 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:49 --> URI Class Initialized
INFO - 2016-07-17 17:58:49 --> Router Class Initialized
INFO - 2016-07-17 17:58:49 --> Output Class Initialized
INFO - 2016-07-17 17:58:49 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:49 --> Input Class Initialized
INFO - 2016-07-17 17:58:49 --> Language Class Initialized
ERROR - 2016-07-17 17:58:49 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:58:52 --> Config Class Initialized
INFO - 2016-07-17 17:58:52 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:52 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:52 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:52 --> URI Class Initialized
INFO - 2016-07-17 17:58:52 --> Router Class Initialized
INFO - 2016-07-17 17:58:52 --> Output Class Initialized
INFO - 2016-07-17 17:58:52 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:52 --> Input Class Initialized
INFO - 2016-07-17 17:58:52 --> Language Class Initialized
INFO - 2016-07-17 17:58:52 --> Loader Class Initialized
INFO - 2016-07-17 17:58:52 --> Helper loaded: url_helper
INFO - 2016-07-17 17:58:52 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:58:52 --> Helper loaded: html_helper
INFO - 2016-07-17 17:58:52 --> Helper loaded: form_helper
INFO - 2016-07-17 17:58:52 --> Helper loaded: file_helper
INFO - 2016-07-17 17:58:52 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:58:52 --> Database Driver Class Initialized
INFO - 2016-07-17 17:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:58:52 --> Form Validation Class Initialized
INFO - 2016-07-17 17:58:52 --> Email Class Initialized
INFO - 2016-07-17 17:58:52 --> Controller Class Initialized
DEBUG - 2016-07-17 17:58:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:58:52 --> Model Class Initialized
INFO - 2016-07-17 17:58:52 --> Model Class Initialized
INFO - 2016-07-17 17:58:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:58:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:58:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-07-17 17:58:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:58:52 --> Final output sent to browser
DEBUG - 2016-07-17 17:58:52 --> Total execution time: 0.2465
INFO - 2016-07-17 17:58:52 --> Config Class Initialized
INFO - 2016-07-17 17:58:52 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:58:52 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:58:52 --> Utf8 Class Initialized
INFO - 2016-07-17 17:58:52 --> URI Class Initialized
INFO - 2016-07-17 17:58:52 --> Router Class Initialized
INFO - 2016-07-17 17:58:52 --> Output Class Initialized
INFO - 2016-07-17 17:58:52 --> Security Class Initialized
DEBUG - 2016-07-17 17:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:58:52 --> Input Class Initialized
INFO - 2016-07-17 17:58:52 --> Language Class Initialized
ERROR - 2016-07-17 17:58:52 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:59:02 --> Config Class Initialized
INFO - 2016-07-17 17:59:02 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:02 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:02 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:02 --> URI Class Initialized
INFO - 2016-07-17 17:59:02 --> Router Class Initialized
INFO - 2016-07-17 17:59:02 --> Output Class Initialized
INFO - 2016-07-17 17:59:03 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:03 --> Input Class Initialized
INFO - 2016-07-17 17:59:03 --> Language Class Initialized
INFO - 2016-07-17 17:59:03 --> Loader Class Initialized
INFO - 2016-07-17 17:59:03 --> Helper loaded: url_helper
INFO - 2016-07-17 17:59:03 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:59:03 --> Helper loaded: html_helper
INFO - 2016-07-17 17:59:03 --> Helper loaded: form_helper
INFO - 2016-07-17 17:59:03 --> Helper loaded: file_helper
INFO - 2016-07-17 17:59:03 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:59:03 --> Database Driver Class Initialized
INFO - 2016-07-17 17:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:59:03 --> Form Validation Class Initialized
INFO - 2016-07-17 17:59:03 --> Email Class Initialized
INFO - 2016-07-17 17:59:03 --> Controller Class Initialized
DEBUG - 2016-07-17 17:59:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 17:59:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:59:03 --> Model Class Initialized
INFO - 2016-07-17 17:59:03 --> Model Class Initialized
INFO - 2016-07-17 17:59:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:59:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:59:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-17 17:59:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:59:03 --> Final output sent to browser
DEBUG - 2016-07-17 17:59:03 --> Total execution time: 0.5864
INFO - 2016-07-17 17:59:03 --> Config Class Initialized
INFO - 2016-07-17 17:59:03 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:03 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:03 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:03 --> URI Class Initialized
INFO - 2016-07-17 17:59:03 --> Router Class Initialized
INFO - 2016-07-17 17:59:03 --> Output Class Initialized
INFO - 2016-07-17 17:59:03 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:03 --> Input Class Initialized
INFO - 2016-07-17 17:59:03 --> Language Class Initialized
ERROR - 2016-07-17 17:59:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:59:09 --> Config Class Initialized
INFO - 2016-07-17 17:59:09 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:09 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:09 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:09 --> URI Class Initialized
INFO - 2016-07-17 17:59:09 --> Router Class Initialized
INFO - 2016-07-17 17:59:09 --> Output Class Initialized
INFO - 2016-07-17 17:59:09 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:09 --> Input Class Initialized
INFO - 2016-07-17 17:59:09 --> Language Class Initialized
INFO - 2016-07-17 17:59:09 --> Loader Class Initialized
INFO - 2016-07-17 17:59:09 --> Helper loaded: url_helper
INFO - 2016-07-17 17:59:09 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:59:09 --> Helper loaded: html_helper
INFO - 2016-07-17 17:59:09 --> Helper loaded: form_helper
INFO - 2016-07-17 17:59:09 --> Helper loaded: file_helper
INFO - 2016-07-17 17:59:09 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:59:09 --> Database Driver Class Initialized
INFO - 2016-07-17 17:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:59:09 --> Form Validation Class Initialized
INFO - 2016-07-17 17:59:09 --> Email Class Initialized
INFO - 2016-07-17 17:59:09 --> Controller Class Initialized
DEBUG - 2016-07-17 17:59:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 17:59:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:59:09 --> Model Class Initialized
INFO - 2016-07-17 17:59:09 --> Model Class Initialized
INFO - 2016-07-17 17:59:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:59:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:59:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/borrowing.php
INFO - 2016-07-17 17:59:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:59:10 --> Final output sent to browser
DEBUG - 2016-07-17 17:59:10 --> Total execution time: 0.3146
INFO - 2016-07-17 17:59:10 --> Config Class Initialized
INFO - 2016-07-17 17:59:10 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:10 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:10 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:10 --> URI Class Initialized
INFO - 2016-07-17 17:59:10 --> Router Class Initialized
INFO - 2016-07-17 17:59:10 --> Output Class Initialized
INFO - 2016-07-17 17:59:10 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:10 --> Input Class Initialized
INFO - 2016-07-17 17:59:10 --> Language Class Initialized
ERROR - 2016-07-17 17:59:10 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:59:33 --> Config Class Initialized
INFO - 2016-07-17 17:59:33 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:33 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:33 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:33 --> URI Class Initialized
INFO - 2016-07-17 17:59:33 --> Router Class Initialized
INFO - 2016-07-17 17:59:33 --> Output Class Initialized
INFO - 2016-07-17 17:59:33 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:33 --> Input Class Initialized
INFO - 2016-07-17 17:59:33 --> Language Class Initialized
INFO - 2016-07-17 17:59:34 --> Loader Class Initialized
INFO - 2016-07-17 17:59:34 --> Helper loaded: url_helper
INFO - 2016-07-17 17:59:34 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:59:34 --> Helper loaded: html_helper
INFO - 2016-07-17 17:59:34 --> Helper loaded: form_helper
INFO - 2016-07-17 17:59:34 --> Helper loaded: file_helper
INFO - 2016-07-17 17:59:34 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:59:34 --> Database Driver Class Initialized
INFO - 2016-07-17 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:59:34 --> Form Validation Class Initialized
INFO - 2016-07-17 17:59:34 --> Email Class Initialized
INFO - 2016-07-17 17:59:34 --> Controller Class Initialized
DEBUG - 2016-07-17 17:59:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 17:59:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:59:34 --> Model Class Initialized
INFO - 2016-07-17 17:59:34 --> Model Class Initialized
INFO - 2016-07-17 17:59:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:59:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:59:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-17 17:59:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:59:34 --> Final output sent to browser
DEBUG - 2016-07-17 17:59:34 --> Total execution time: 0.3326
INFO - 2016-07-17 17:59:34 --> Config Class Initialized
INFO - 2016-07-17 17:59:34 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:34 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:34 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:34 --> URI Class Initialized
INFO - 2016-07-17 17:59:34 --> Router Class Initialized
INFO - 2016-07-17 17:59:34 --> Output Class Initialized
INFO - 2016-07-17 17:59:34 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:34 --> Input Class Initialized
INFO - 2016-07-17 17:59:34 --> Language Class Initialized
ERROR - 2016-07-17 17:59:34 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 17:59:45 --> Config Class Initialized
INFO - 2016-07-17 17:59:45 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:45 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:45 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:45 --> URI Class Initialized
INFO - 2016-07-17 17:59:45 --> Router Class Initialized
INFO - 2016-07-17 17:59:45 --> Output Class Initialized
INFO - 2016-07-17 17:59:45 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:45 --> Input Class Initialized
INFO - 2016-07-17 17:59:45 --> Language Class Initialized
INFO - 2016-07-17 17:59:45 --> Loader Class Initialized
INFO - 2016-07-17 17:59:45 --> Helper loaded: url_helper
INFO - 2016-07-17 17:59:45 --> Helper loaded: utils_helper
INFO - 2016-07-17 17:59:45 --> Helper loaded: html_helper
INFO - 2016-07-17 17:59:45 --> Helper loaded: form_helper
INFO - 2016-07-17 17:59:45 --> Helper loaded: file_helper
INFO - 2016-07-17 17:59:45 --> Helper loaded: myemail_helper
INFO - 2016-07-17 17:59:45 --> Database Driver Class Initialized
INFO - 2016-07-17 17:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 17:59:45 --> Form Validation Class Initialized
INFO - 2016-07-17 17:59:45 --> Email Class Initialized
INFO - 2016-07-17 17:59:45 --> Controller Class Initialized
DEBUG - 2016-07-17 17:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 17:59:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 17:59:45 --> Model Class Initialized
INFO - 2016-07-17 17:59:45 --> Model Class Initialized
INFO - 2016-07-17 17:59:45 --> Model Class Initialized
INFO - 2016-07-17 17:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 17:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 17:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/book_broken.php
INFO - 2016-07-17 17:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 17:59:45 --> Final output sent to browser
DEBUG - 2016-07-17 17:59:45 --> Total execution time: 0.4169
INFO - 2016-07-17 17:59:46 --> Config Class Initialized
INFO - 2016-07-17 17:59:46 --> Hooks Class Initialized
DEBUG - 2016-07-17 17:59:46 --> UTF-8 Support Enabled
INFO - 2016-07-17 17:59:46 --> Utf8 Class Initialized
INFO - 2016-07-17 17:59:46 --> URI Class Initialized
INFO - 2016-07-17 17:59:46 --> Router Class Initialized
INFO - 2016-07-17 17:59:46 --> Output Class Initialized
INFO - 2016-07-17 17:59:46 --> Security Class Initialized
DEBUG - 2016-07-17 17:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 17:59:46 --> Input Class Initialized
INFO - 2016-07-17 17:59:46 --> Language Class Initialized
ERROR - 2016-07-17 17:59:46 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 18:00:00 --> Config Class Initialized
INFO - 2016-07-17 18:00:00 --> Hooks Class Initialized
DEBUG - 2016-07-17 18:00:00 --> UTF-8 Support Enabled
INFO - 2016-07-17 18:00:00 --> Utf8 Class Initialized
INFO - 2016-07-17 18:00:00 --> URI Class Initialized
INFO - 2016-07-17 18:00:00 --> Router Class Initialized
INFO - 2016-07-17 18:00:00 --> Output Class Initialized
INFO - 2016-07-17 18:00:00 --> Security Class Initialized
DEBUG - 2016-07-17 18:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 18:00:00 --> Input Class Initialized
INFO - 2016-07-17 18:00:00 --> Language Class Initialized
INFO - 2016-07-17 18:00:00 --> Loader Class Initialized
INFO - 2016-07-17 18:00:00 --> Helper loaded: url_helper
INFO - 2016-07-17 18:00:00 --> Helper loaded: utils_helper
INFO - 2016-07-17 18:00:00 --> Helper loaded: html_helper
INFO - 2016-07-17 18:00:00 --> Helper loaded: form_helper
INFO - 2016-07-17 18:00:00 --> Helper loaded: file_helper
INFO - 2016-07-17 18:00:00 --> Helper loaded: myemail_helper
INFO - 2016-07-17 18:00:00 --> Database Driver Class Initialized
INFO - 2016-07-17 18:00:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 18:00:00 --> Form Validation Class Initialized
INFO - 2016-07-17 18:00:00 --> Email Class Initialized
INFO - 2016-07-17 18:00:00 --> Controller Class Initialized
DEBUG - 2016-07-17 18:00:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 18:00:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 18:00:00 --> Model Class Initialized
INFO - 2016-07-17 18:00:00 --> Model Class Initialized
INFO - 2016-07-17 18:00:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 18:00:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 18:00:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-17 18:00:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 18:00:00 --> Final output sent to browser
DEBUG - 2016-07-17 18:00:00 --> Total execution time: 0.3277
INFO - 2016-07-17 18:00:01 --> Config Class Initialized
INFO - 2016-07-17 18:00:01 --> Hooks Class Initialized
DEBUG - 2016-07-17 18:00:01 --> UTF-8 Support Enabled
INFO - 2016-07-17 18:00:01 --> Utf8 Class Initialized
INFO - 2016-07-17 18:00:01 --> URI Class Initialized
INFO - 2016-07-17 18:00:01 --> Router Class Initialized
INFO - 2016-07-17 18:00:01 --> Output Class Initialized
INFO - 2016-07-17 18:00:01 --> Security Class Initialized
DEBUG - 2016-07-17 18:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 18:00:01 --> Input Class Initialized
INFO - 2016-07-17 18:00:01 --> Language Class Initialized
ERROR - 2016-07-17 18:00:01 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-17 18:00:14 --> Config Class Initialized
INFO - 2016-07-17 18:00:14 --> Hooks Class Initialized
DEBUG - 2016-07-17 18:00:14 --> UTF-8 Support Enabled
INFO - 2016-07-17 18:00:14 --> Utf8 Class Initialized
INFO - 2016-07-17 18:00:14 --> URI Class Initialized
INFO - 2016-07-17 18:00:14 --> Router Class Initialized
INFO - 2016-07-17 18:00:14 --> Output Class Initialized
INFO - 2016-07-17 18:00:14 --> Security Class Initialized
DEBUG - 2016-07-17 18:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 18:00:14 --> Input Class Initialized
INFO - 2016-07-17 18:00:14 --> Language Class Initialized
INFO - 2016-07-17 18:00:14 --> Loader Class Initialized
INFO - 2016-07-17 18:00:14 --> Helper loaded: url_helper
INFO - 2016-07-17 18:00:14 --> Helper loaded: utils_helper
INFO - 2016-07-17 18:00:14 --> Helper loaded: html_helper
INFO - 2016-07-17 18:00:14 --> Helper loaded: form_helper
INFO - 2016-07-17 18:00:14 --> Helper loaded: file_helper
INFO - 2016-07-17 18:00:14 --> Helper loaded: myemail_helper
INFO - 2016-07-17 18:00:14 --> Database Driver Class Initialized
INFO - 2016-07-17 18:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-17 18:00:14 --> Form Validation Class Initialized
INFO - 2016-07-17 18:00:14 --> Email Class Initialized
INFO - 2016-07-17 18:00:14 --> Controller Class Initialized
DEBUG - 2016-07-17 18:00:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-17 18:00:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-17 18:00:14 --> Model Class Initialized
INFO - 2016-07-17 18:00:14 --> Model Class Initialized
INFO - 2016-07-17 18:00:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-17 18:00:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-17 18:00:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/book_vacant.php
INFO - 2016-07-17 18:00:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-17 18:00:15 --> Final output sent to browser
DEBUG - 2016-07-17 18:00:15 --> Total execution time: 0.2921
INFO - 2016-07-17 18:00:15 --> Config Class Initialized
INFO - 2016-07-17 18:00:15 --> Hooks Class Initialized
DEBUG - 2016-07-17 18:00:15 --> UTF-8 Support Enabled
INFO - 2016-07-17 18:00:15 --> Utf8 Class Initialized
INFO - 2016-07-17 18:00:15 --> URI Class Initialized
INFO - 2016-07-17 18:00:15 --> Router Class Initialized
INFO - 2016-07-17 18:00:15 --> Output Class Initialized
INFO - 2016-07-17 18:00:15 --> Security Class Initialized
DEBUG - 2016-07-17 18:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-17 18:00:15 --> Input Class Initialized
INFO - 2016-07-17 18:00:15 --> Language Class Initialized
ERROR - 2016-07-17 18:00:15 --> 404 Page Not Found: Faviconico/index
