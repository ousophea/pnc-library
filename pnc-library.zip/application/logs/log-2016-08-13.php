<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-13 06:38:22 --> Config Class Initialized
INFO - 2016-08-13 06:38:22 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:38:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:38:23 --> Utf8 Class Initialized
INFO - 2016-08-13 06:38:23 --> URI Class Initialized
INFO - 2016-08-13 06:38:23 --> Router Class Initialized
INFO - 2016-08-13 06:38:23 --> Output Class Initialized
INFO - 2016-08-13 06:38:23 --> Security Class Initialized
DEBUG - 2016-08-13 06:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:38:23 --> Input Class Initialized
INFO - 2016-08-13 06:38:23 --> Language Class Initialized
INFO - 2016-08-13 06:38:23 --> Loader Class Initialized
INFO - 2016-08-13 06:38:23 --> Helper loaded: url_helper
INFO - 2016-08-13 06:38:23 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:38:23 --> Helper loaded: html_helper
INFO - 2016-08-13 06:38:24 --> Helper loaded: form_helper
INFO - 2016-08-13 06:38:24 --> Helper loaded: file_helper
INFO - 2016-08-13 06:38:24 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:38:24 --> Database Driver Class Initialized
INFO - 2016-08-13 06:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:38:24 --> Form Validation Class Initialized
INFO - 2016-08-13 06:38:25 --> Email Class Initialized
INFO - 2016-08-13 06:38:25 --> Controller Class Initialized
INFO - 2016-08-13 06:38:30 --> Config Class Initialized
INFO - 2016-08-13 06:38:30 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:38:30 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:38:30 --> Utf8 Class Initialized
INFO - 2016-08-13 06:38:30 --> URI Class Initialized
INFO - 2016-08-13 06:38:30 --> Router Class Initialized
INFO - 2016-08-13 06:38:30 --> Output Class Initialized
INFO - 2016-08-13 06:38:30 --> Security Class Initialized
DEBUG - 2016-08-13 06:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:38:31 --> Input Class Initialized
INFO - 2016-08-13 06:38:31 --> Language Class Initialized
INFO - 2016-08-13 06:38:31 --> Loader Class Initialized
INFO - 2016-08-13 06:38:31 --> Helper loaded: url_helper
INFO - 2016-08-13 06:38:31 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:38:31 --> Helper loaded: html_helper
INFO - 2016-08-13 06:38:31 --> Helper loaded: form_helper
INFO - 2016-08-13 06:38:31 --> Helper loaded: file_helper
INFO - 2016-08-13 06:38:31 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:38:31 --> Database Driver Class Initialized
INFO - 2016-08-13 06:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:38:31 --> Form Validation Class Initialized
INFO - 2016-08-13 06:38:31 --> Email Class Initialized
INFO - 2016-08-13 06:38:31 --> Controller Class Initialized
INFO - 2016-08-13 06:38:31 --> Model Class Initialized
DEBUG - 2016-08-13 06:38:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:38:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 06:38:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:38:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 06:38:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:38:31 --> Final output sent to browser
DEBUG - 2016-08-13 06:38:31 --> Total execution time: 0.8698
INFO - 2016-08-13 06:38:35 --> Config Class Initialized
INFO - 2016-08-13 06:38:35 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:38:35 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:38:35 --> Utf8 Class Initialized
INFO - 2016-08-13 06:38:35 --> URI Class Initialized
INFO - 2016-08-13 06:38:35 --> Router Class Initialized
INFO - 2016-08-13 06:38:35 --> Output Class Initialized
INFO - 2016-08-13 06:38:35 --> Security Class Initialized
DEBUG - 2016-08-13 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:38:35 --> Input Class Initialized
INFO - 2016-08-13 06:38:36 --> Language Class Initialized
ERROR - 2016-08-13 06:38:36 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-13 06:38:36 --> Config Class Initialized
INFO - 2016-08-13 06:38:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:38:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:38:36 --> Utf8 Class Initialized
INFO - 2016-08-13 06:38:36 --> URI Class Initialized
INFO - 2016-08-13 06:38:36 --> Router Class Initialized
INFO - 2016-08-13 06:38:36 --> Output Class Initialized
INFO - 2016-08-13 06:38:36 --> Security Class Initialized
DEBUG - 2016-08-13 06:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:38:36 --> Input Class Initialized
INFO - 2016-08-13 06:38:36 --> Language Class Initialized
ERROR - 2016-08-13 06:38:36 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-13 06:38:59 --> Config Class Initialized
INFO - 2016-08-13 06:38:59 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:38:59 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:38:59 --> Utf8 Class Initialized
INFO - 2016-08-13 06:38:59 --> URI Class Initialized
INFO - 2016-08-13 06:38:59 --> Router Class Initialized
INFO - 2016-08-13 06:38:59 --> Output Class Initialized
INFO - 2016-08-13 06:38:59 --> Security Class Initialized
DEBUG - 2016-08-13 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:38:59 --> Input Class Initialized
INFO - 2016-08-13 06:38:59 --> Language Class Initialized
INFO - 2016-08-13 06:38:59 --> Loader Class Initialized
INFO - 2016-08-13 06:38:59 --> Helper loaded: url_helper
INFO - 2016-08-13 06:38:59 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:38:59 --> Helper loaded: html_helper
INFO - 2016-08-13 06:38:59 --> Helper loaded: form_helper
INFO - 2016-08-13 06:38:59 --> Helper loaded: file_helper
INFO - 2016-08-13 06:38:59 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:38:59 --> Database Driver Class Initialized
INFO - 2016-08-13 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:38:59 --> Form Validation Class Initialized
INFO - 2016-08-13 06:38:59 --> Email Class Initialized
INFO - 2016-08-13 06:38:59 --> Controller Class Initialized
INFO - 2016-08-13 06:38:59 --> Model Class Initialized
DEBUG - 2016-08-13 06:38:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:38:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 06:38:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 06:38:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:38:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 06:38:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:38:59 --> Final output sent to browser
DEBUG - 2016-08-13 06:38:59 --> Total execution time: 0.3666
INFO - 2016-08-13 06:39:02 --> Config Class Initialized
INFO - 2016-08-13 06:39:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:39:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:39:02 --> Utf8 Class Initialized
INFO - 2016-08-13 06:39:02 --> URI Class Initialized
INFO - 2016-08-13 06:39:02 --> Router Class Initialized
INFO - 2016-08-13 06:39:02 --> Output Class Initialized
INFO - 2016-08-13 06:39:02 --> Security Class Initialized
DEBUG - 2016-08-13 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:39:02 --> Input Class Initialized
INFO - 2016-08-13 06:39:02 --> Language Class Initialized
INFO - 2016-08-13 06:39:02 --> Loader Class Initialized
INFO - 2016-08-13 06:39:02 --> Helper loaded: url_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: html_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: form_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: file_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:39:02 --> Database Driver Class Initialized
INFO - 2016-08-13 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:39:02 --> Form Validation Class Initialized
INFO - 2016-08-13 06:39:02 --> Email Class Initialized
INFO - 2016-08-13 06:39:02 --> Controller Class Initialized
INFO - 2016-08-13 06:39:02 --> Model Class Initialized
DEBUG - 2016-08-13 06:39:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:39:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 06:39:02 --> Config Class Initialized
INFO - 2016-08-13 06:39:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:39:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:39:02 --> Utf8 Class Initialized
INFO - 2016-08-13 06:39:02 --> URI Class Initialized
INFO - 2016-08-13 06:39:02 --> Router Class Initialized
INFO - 2016-08-13 06:39:02 --> Output Class Initialized
INFO - 2016-08-13 06:39:02 --> Security Class Initialized
DEBUG - 2016-08-13 06:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:39:02 --> Input Class Initialized
INFO - 2016-08-13 06:39:02 --> Language Class Initialized
INFO - 2016-08-13 06:39:02 --> Loader Class Initialized
INFO - 2016-08-13 06:39:02 --> Helper loaded: url_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: html_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: form_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: file_helper
INFO - 2016-08-13 06:39:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:39:02 --> Database Driver Class Initialized
INFO - 2016-08-13 06:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:39:02 --> Form Validation Class Initialized
INFO - 2016-08-13 06:39:02 --> Email Class Initialized
INFO - 2016-08-13 06:39:02 --> Controller Class Initialized
DEBUG - 2016-08-13 06:39:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:39:02 --> Model Class Initialized
INFO - 2016-08-13 06:39:02 --> Model Class Initialized
INFO - 2016-08-13 06:39:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:39:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 06:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:39:03 --> Final output sent to browser
DEBUG - 2016-08-13 06:39:03 --> Total execution time: 0.5613
INFO - 2016-08-13 06:40:07 --> Config Class Initialized
INFO - 2016-08-13 06:40:07 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:40:07 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:40:07 --> Utf8 Class Initialized
INFO - 2016-08-13 06:40:07 --> URI Class Initialized
INFO - 2016-08-13 06:40:07 --> Router Class Initialized
INFO - 2016-08-13 06:40:07 --> Output Class Initialized
INFO - 2016-08-13 06:40:07 --> Security Class Initialized
DEBUG - 2016-08-13 06:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:40:07 --> Input Class Initialized
INFO - 2016-08-13 06:40:07 --> Language Class Initialized
INFO - 2016-08-13 06:40:07 --> Loader Class Initialized
INFO - 2016-08-13 06:40:07 --> Helper loaded: url_helper
INFO - 2016-08-13 06:40:07 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:40:07 --> Helper loaded: html_helper
INFO - 2016-08-13 06:40:07 --> Helper loaded: form_helper
INFO - 2016-08-13 06:40:07 --> Helper loaded: file_helper
INFO - 2016-08-13 06:40:07 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:40:07 --> Database Driver Class Initialized
INFO - 2016-08-13 06:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:40:07 --> Form Validation Class Initialized
INFO - 2016-08-13 06:40:07 --> Email Class Initialized
INFO - 2016-08-13 06:40:07 --> Controller Class Initialized
DEBUG - 2016-08-13 06:40:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:40:07 --> Model Class Initialized
INFO - 2016-08-13 06:40:07 --> Model Class Initialized
INFO - 2016-08-13 06:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 06:40:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:40:07 --> Final output sent to browser
DEBUG - 2016-08-13 06:40:07 --> Total execution time: 0.2708
INFO - 2016-08-13 06:41:04 --> Config Class Initialized
INFO - 2016-08-13 06:41:04 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:04 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:04 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:04 --> URI Class Initialized
INFO - 2016-08-13 06:41:04 --> Router Class Initialized
INFO - 2016-08-13 06:41:04 --> Output Class Initialized
INFO - 2016-08-13 06:41:04 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:05 --> Input Class Initialized
INFO - 2016-08-13 06:41:05 --> Language Class Initialized
INFO - 2016-08-13 06:41:05 --> Loader Class Initialized
INFO - 2016-08-13 06:41:05 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:05 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:05 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:05 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:05 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:05 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:05 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:05 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:05 --> Email Class Initialized
INFO - 2016-08-13 06:41:05 --> Controller Class Initialized
DEBUG - 2016-08-13 06:41:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:05 --> Model Class Initialized
INFO - 2016-08-13 06:41:05 --> Model Class Initialized
INFO - 2016-08-13 06:41:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 06:41:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:05 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:05 --> Total execution time: 0.2614
INFO - 2016-08-13 06:41:20 --> Config Class Initialized
INFO - 2016-08-13 06:41:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:20 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:20 --> URI Class Initialized
INFO - 2016-08-13 06:41:20 --> Router Class Initialized
INFO - 2016-08-13 06:41:20 --> Output Class Initialized
INFO - 2016-08-13 06:41:20 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:20 --> Input Class Initialized
INFO - 2016-08-13 06:41:20 --> Language Class Initialized
INFO - 2016-08-13 06:41:20 --> Loader Class Initialized
INFO - 2016-08-13 06:41:20 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:20 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:20 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:20 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:20 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:20 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:20 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:20 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:20 --> Email Class Initialized
INFO - 2016-08-13 06:41:20 --> Controller Class Initialized
DEBUG - 2016-08-13 06:41:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:20 --> Model Class Initialized
INFO - 2016-08-13 06:41:20 --> Model Class Initialized
INFO - 2016-08-13 06:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 06:41:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:21 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:21 --> Total execution time: 0.3103
INFO - 2016-08-13 06:41:23 --> Config Class Initialized
INFO - 2016-08-13 06:41:23 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:23 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:23 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:23 --> URI Class Initialized
INFO - 2016-08-13 06:41:23 --> Router Class Initialized
INFO - 2016-08-13 06:41:23 --> Output Class Initialized
INFO - 2016-08-13 06:41:23 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:23 --> Input Class Initialized
INFO - 2016-08-13 06:41:23 --> Language Class Initialized
INFO - 2016-08-13 06:41:23 --> Loader Class Initialized
INFO - 2016-08-13 06:41:23 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:23 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:23 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:23 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:23 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:23 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:23 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:24 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:24 --> Email Class Initialized
INFO - 2016-08-13 06:41:24 --> Controller Class Initialized
DEBUG - 2016-08-13 06:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:24 --> Model Class Initialized
INFO - 2016-08-13 06:41:24 --> Model Class Initialized
INFO - 2016-08-13 06:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 06:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:24 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:24 --> Total execution time: 0.3413
INFO - 2016-08-13 06:41:26 --> Config Class Initialized
INFO - 2016-08-13 06:41:26 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:26 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:26 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:26 --> URI Class Initialized
INFO - 2016-08-13 06:41:26 --> Router Class Initialized
INFO - 2016-08-13 06:41:26 --> Output Class Initialized
INFO - 2016-08-13 06:41:26 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:26 --> Input Class Initialized
INFO - 2016-08-13 06:41:26 --> Language Class Initialized
INFO - 2016-08-13 06:41:26 --> Loader Class Initialized
INFO - 2016-08-13 06:41:26 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:26 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:26 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:26 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:26 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:26 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:26 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:26 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:26 --> Email Class Initialized
INFO - 2016-08-13 06:41:26 --> Controller Class Initialized
INFO - 2016-08-13 06:41:26 --> Model Class Initialized
INFO - 2016-08-13 06:41:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 06:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:27 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:27 --> Total execution time: 0.3754
INFO - 2016-08-13 06:41:28 --> Config Class Initialized
INFO - 2016-08-13 06:41:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:28 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:28 --> URI Class Initialized
INFO - 2016-08-13 06:41:28 --> Router Class Initialized
INFO - 2016-08-13 06:41:28 --> Output Class Initialized
INFO - 2016-08-13 06:41:28 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:28 --> Input Class Initialized
INFO - 2016-08-13 06:41:28 --> Language Class Initialized
INFO - 2016-08-13 06:41:28 --> Loader Class Initialized
INFO - 2016-08-13 06:41:28 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:28 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:28 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:28 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:28 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:28 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:28 --> Email Class Initialized
INFO - 2016-08-13 06:41:28 --> Controller Class Initialized
INFO - 2016-08-13 06:41:28 --> Model Class Initialized
INFO - 2016-08-13 06:41:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 06:41:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:28 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:28 --> Total execution time: 0.2459
INFO - 2016-08-13 06:41:31 --> Config Class Initialized
INFO - 2016-08-13 06:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:31 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:31 --> URI Class Initialized
INFO - 2016-08-13 06:41:31 --> Router Class Initialized
INFO - 2016-08-13 06:41:31 --> Output Class Initialized
INFO - 2016-08-13 06:41:31 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:31 --> Input Class Initialized
INFO - 2016-08-13 06:41:31 --> Language Class Initialized
INFO - 2016-08-13 06:41:31 --> Loader Class Initialized
INFO - 2016-08-13 06:41:31 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:31 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:31 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:31 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:31 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:31 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:31 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:31 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:31 --> Email Class Initialized
INFO - 2016-08-13 06:41:31 --> Controller Class Initialized
INFO - 2016-08-13 06:41:31 --> Model Class Initialized
INFO - 2016-08-13 06:41:31 --> Config Class Initialized
INFO - 2016-08-13 06:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:31 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:31 --> URI Class Initialized
INFO - 2016-08-13 06:41:31 --> Router Class Initialized
INFO - 2016-08-13 06:41:31 --> Output Class Initialized
INFO - 2016-08-13 06:41:32 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:32 --> Input Class Initialized
INFO - 2016-08-13 06:41:32 --> Language Class Initialized
INFO - 2016-08-13 06:41:32 --> Loader Class Initialized
INFO - 2016-08-13 06:41:32 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:32 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:32 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:32 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:32 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:32 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:32 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:32 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:32 --> Email Class Initialized
INFO - 2016-08-13 06:41:32 --> Controller Class Initialized
INFO - 2016-08-13 06:41:32 --> Model Class Initialized
DEBUG - 2016-08-13 06:41:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 06:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 06:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:32 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:32 --> Total execution time: 0.2482
INFO - 2016-08-13 06:41:36 --> Config Class Initialized
INFO - 2016-08-13 06:41:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:36 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:36 --> URI Class Initialized
INFO - 2016-08-13 06:41:36 --> Router Class Initialized
INFO - 2016-08-13 06:41:36 --> Output Class Initialized
INFO - 2016-08-13 06:41:36 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:36 --> Input Class Initialized
INFO - 2016-08-13 06:41:36 --> Language Class Initialized
INFO - 2016-08-13 06:41:36 --> Loader Class Initialized
INFO - 2016-08-13 06:41:36 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:36 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:36 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:36 --> Email Class Initialized
INFO - 2016-08-13 06:41:36 --> Controller Class Initialized
INFO - 2016-08-13 06:41:36 --> Model Class Initialized
DEBUG - 2016-08-13 06:41:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 06:41:36 --> Config Class Initialized
INFO - 2016-08-13 06:41:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:36 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:36 --> URI Class Initialized
INFO - 2016-08-13 06:41:36 --> Router Class Initialized
INFO - 2016-08-13 06:41:36 --> Output Class Initialized
INFO - 2016-08-13 06:41:36 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:36 --> Input Class Initialized
INFO - 2016-08-13 06:41:36 --> Language Class Initialized
INFO - 2016-08-13 06:41:36 --> Loader Class Initialized
INFO - 2016-08-13 06:41:36 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:36 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:36 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:36 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:36 --> Email Class Initialized
INFO - 2016-08-13 06:41:36 --> Controller Class Initialized
INFO - 2016-08-13 06:41:36 --> Model Class Initialized
INFO - 2016-08-13 06:41:36 --> Model Class Initialized
INFO - 2016-08-13 06:41:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 06:41:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:36 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:36 --> Total execution time: 0.2621
INFO - 2016-08-13 06:41:40 --> Config Class Initialized
INFO - 2016-08-13 06:41:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:40 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:40 --> URI Class Initialized
INFO - 2016-08-13 06:41:40 --> Router Class Initialized
INFO - 2016-08-13 06:41:40 --> Output Class Initialized
INFO - 2016-08-13 06:41:40 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:40 --> Input Class Initialized
INFO - 2016-08-13 06:41:40 --> Language Class Initialized
INFO - 2016-08-13 06:41:40 --> Loader Class Initialized
INFO - 2016-08-13 06:41:40 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:40 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:40 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:40 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:40 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:40 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:40 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:40 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:40 --> Email Class Initialized
INFO - 2016-08-13 06:41:40 --> Controller Class Initialized
INFO - 2016-08-13 06:41:40 --> Model Class Initialized
INFO - 2016-08-13 06:41:40 --> Model Class Initialized
INFO - 2016-08-13 06:41:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 06:41:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:40 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:40 --> Total execution time: 0.2586
INFO - 2016-08-13 06:41:43 --> Config Class Initialized
INFO - 2016-08-13 06:41:43 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:43 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:43 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:43 --> URI Class Initialized
INFO - 2016-08-13 06:41:43 --> Router Class Initialized
INFO - 2016-08-13 06:41:43 --> Output Class Initialized
INFO - 2016-08-13 06:41:43 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:43 --> Input Class Initialized
INFO - 2016-08-13 06:41:43 --> Language Class Initialized
INFO - 2016-08-13 06:41:43 --> Loader Class Initialized
INFO - 2016-08-13 06:41:43 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:43 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:43 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:43 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:43 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:43 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:43 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:43 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:43 --> Email Class Initialized
INFO - 2016-08-13 06:41:43 --> Controller Class Initialized
DEBUG - 2016-08-13 06:41:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:43 --> Model Class Initialized
INFO - 2016-08-13 06:41:43 --> Model Class Initialized
INFO - 2016-08-13 06:41:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 06:41:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:43 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:43 --> Total execution time: 0.2647
INFO - 2016-08-13 06:41:45 --> Config Class Initialized
INFO - 2016-08-13 06:41:45 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:41:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:41:45 --> Utf8 Class Initialized
INFO - 2016-08-13 06:41:45 --> URI Class Initialized
INFO - 2016-08-13 06:41:45 --> Router Class Initialized
INFO - 2016-08-13 06:41:45 --> Output Class Initialized
INFO - 2016-08-13 06:41:45 --> Security Class Initialized
DEBUG - 2016-08-13 06:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:41:45 --> Input Class Initialized
INFO - 2016-08-13 06:41:46 --> Language Class Initialized
INFO - 2016-08-13 06:41:46 --> Loader Class Initialized
INFO - 2016-08-13 06:41:46 --> Helper loaded: url_helper
INFO - 2016-08-13 06:41:46 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:41:46 --> Helper loaded: html_helper
INFO - 2016-08-13 06:41:46 --> Helper loaded: form_helper
INFO - 2016-08-13 06:41:46 --> Helper loaded: file_helper
INFO - 2016-08-13 06:41:46 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:41:46 --> Database Driver Class Initialized
INFO - 2016-08-13 06:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:41:46 --> Form Validation Class Initialized
INFO - 2016-08-13 06:41:46 --> Email Class Initialized
INFO - 2016-08-13 06:41:46 --> Controller Class Initialized
DEBUG - 2016-08-13 06:41:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:41:46 --> Model Class Initialized
INFO - 2016-08-13 06:41:46 --> Model Class Initialized
INFO - 2016-08-13 06:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 06:41:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:41:46 --> Final output sent to browser
DEBUG - 2016-08-13 06:41:46 --> Total execution time: 0.2933
INFO - 2016-08-13 06:43:27 --> Config Class Initialized
INFO - 2016-08-13 06:43:27 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:43:27 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:43:27 --> Utf8 Class Initialized
INFO - 2016-08-13 06:43:27 --> URI Class Initialized
INFO - 2016-08-13 06:43:27 --> Router Class Initialized
INFO - 2016-08-13 06:43:27 --> Output Class Initialized
INFO - 2016-08-13 06:43:27 --> Security Class Initialized
DEBUG - 2016-08-13 06:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:43:27 --> Input Class Initialized
INFO - 2016-08-13 06:43:27 --> Language Class Initialized
INFO - 2016-08-13 06:43:27 --> Loader Class Initialized
INFO - 2016-08-13 06:43:27 --> Helper loaded: url_helper
INFO - 2016-08-13 06:43:27 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:43:27 --> Helper loaded: html_helper
INFO - 2016-08-13 06:43:27 --> Helper loaded: form_helper
INFO - 2016-08-13 06:43:27 --> Helper loaded: file_helper
INFO - 2016-08-13 06:43:27 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:43:28 --> Database Driver Class Initialized
INFO - 2016-08-13 06:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:43:28 --> Form Validation Class Initialized
INFO - 2016-08-13 06:43:28 --> Email Class Initialized
INFO - 2016-08-13 06:43:28 --> Controller Class Initialized
DEBUG - 2016-08-13 06:43:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:43:28 --> Model Class Initialized
INFO - 2016-08-13 06:43:28 --> Model Class Initialized
INFO - 2016-08-13 06:43:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:43:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:43:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 06:43:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:43:28 --> Final output sent to browser
DEBUG - 2016-08-13 06:43:28 --> Total execution time: 0.2657
INFO - 2016-08-13 06:43:39 --> Config Class Initialized
INFO - 2016-08-13 06:43:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:43:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:43:39 --> Utf8 Class Initialized
INFO - 2016-08-13 06:43:39 --> URI Class Initialized
INFO - 2016-08-13 06:43:39 --> Router Class Initialized
INFO - 2016-08-13 06:43:39 --> Output Class Initialized
INFO - 2016-08-13 06:43:39 --> Security Class Initialized
DEBUG - 2016-08-13 06:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:43:39 --> Input Class Initialized
INFO - 2016-08-13 06:43:39 --> Language Class Initialized
INFO - 2016-08-13 06:43:39 --> Loader Class Initialized
INFO - 2016-08-13 06:43:39 --> Helper loaded: url_helper
INFO - 2016-08-13 06:43:39 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:43:39 --> Helper loaded: html_helper
INFO - 2016-08-13 06:43:39 --> Helper loaded: form_helper
INFO - 2016-08-13 06:43:39 --> Helper loaded: file_helper
INFO - 2016-08-13 06:43:39 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:43:39 --> Database Driver Class Initialized
INFO - 2016-08-13 06:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:43:39 --> Form Validation Class Initialized
INFO - 2016-08-13 06:43:39 --> Email Class Initialized
INFO - 2016-08-13 06:43:39 --> Controller Class Initialized
DEBUG - 2016-08-13 06:43:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:43:39 --> Model Class Initialized
INFO - 2016-08-13 06:43:39 --> Model Class Initialized
INFO - 2016-08-13 06:43:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:43:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:43:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 06:43:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:43:39 --> Final output sent to browser
DEBUG - 2016-08-13 06:43:39 --> Total execution time: 0.2609
INFO - 2016-08-13 06:44:46 --> Config Class Initialized
INFO - 2016-08-13 06:44:46 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:44:46 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:44:46 --> Utf8 Class Initialized
INFO - 2016-08-13 06:44:46 --> URI Class Initialized
INFO - 2016-08-13 06:44:46 --> Router Class Initialized
INFO - 2016-08-13 06:44:46 --> Output Class Initialized
INFO - 2016-08-13 06:44:46 --> Security Class Initialized
DEBUG - 2016-08-13 06:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:44:46 --> Input Class Initialized
INFO - 2016-08-13 06:44:46 --> Language Class Initialized
INFO - 2016-08-13 06:44:46 --> Loader Class Initialized
INFO - 2016-08-13 06:44:46 --> Helper loaded: url_helper
INFO - 2016-08-13 06:44:46 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:44:46 --> Helper loaded: html_helper
INFO - 2016-08-13 06:44:46 --> Helper loaded: form_helper
INFO - 2016-08-13 06:44:46 --> Helper loaded: file_helper
INFO - 2016-08-13 06:44:46 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:44:46 --> Database Driver Class Initialized
INFO - 2016-08-13 06:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:44:46 --> Form Validation Class Initialized
INFO - 2016-08-13 06:44:46 --> Email Class Initialized
INFO - 2016-08-13 06:44:46 --> Controller Class Initialized
INFO - 2016-08-13 06:44:46 --> Model Class Initialized
INFO - 2016-08-13 06:44:46 --> Model Class Initialized
INFO - 2016-08-13 06:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 06:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:44:46 --> Final output sent to browser
DEBUG - 2016-08-13 06:44:46 --> Total execution time: 0.2863
INFO - 2016-08-13 06:44:50 --> Config Class Initialized
INFO - 2016-08-13 06:44:50 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:44:50 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:44:50 --> Utf8 Class Initialized
INFO - 2016-08-13 06:44:50 --> URI Class Initialized
INFO - 2016-08-13 06:44:50 --> Router Class Initialized
INFO - 2016-08-13 06:44:50 --> Output Class Initialized
INFO - 2016-08-13 06:44:50 --> Security Class Initialized
DEBUG - 2016-08-13 06:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:44:50 --> Input Class Initialized
INFO - 2016-08-13 06:44:50 --> Language Class Initialized
INFO - 2016-08-13 06:44:50 --> Loader Class Initialized
INFO - 2016-08-13 06:44:50 --> Helper loaded: url_helper
INFO - 2016-08-13 06:44:50 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:44:50 --> Helper loaded: html_helper
INFO - 2016-08-13 06:44:50 --> Helper loaded: form_helper
INFO - 2016-08-13 06:44:50 --> Helper loaded: file_helper
INFO - 2016-08-13 06:44:50 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:44:50 --> Database Driver Class Initialized
INFO - 2016-08-13 06:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:44:50 --> Form Validation Class Initialized
INFO - 2016-08-13 06:44:50 --> Email Class Initialized
INFO - 2016-08-13 06:44:50 --> Controller Class Initialized
INFO - 2016-08-13 06:44:50 --> Model Class Initialized
INFO - 2016-08-13 06:44:50 --> Model Class Initialized
INFO - 2016-08-13 06:44:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:44:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:44:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-13 06:44:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:44:50 --> Final output sent to browser
DEBUG - 2016-08-13 06:44:51 --> Total execution time: 0.2793
INFO - 2016-08-13 06:44:54 --> Config Class Initialized
INFO - 2016-08-13 06:44:54 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:44:54 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:44:54 --> Utf8 Class Initialized
INFO - 2016-08-13 06:44:54 --> URI Class Initialized
INFO - 2016-08-13 06:44:54 --> Router Class Initialized
INFO - 2016-08-13 06:44:54 --> Output Class Initialized
INFO - 2016-08-13 06:44:54 --> Security Class Initialized
DEBUG - 2016-08-13 06:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:44:54 --> Input Class Initialized
INFO - 2016-08-13 06:44:54 --> Language Class Initialized
INFO - 2016-08-13 06:44:54 --> Loader Class Initialized
INFO - 2016-08-13 06:44:54 --> Helper loaded: url_helper
INFO - 2016-08-13 06:44:54 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:44:54 --> Helper loaded: html_helper
INFO - 2016-08-13 06:44:54 --> Helper loaded: form_helper
INFO - 2016-08-13 06:44:54 --> Helper loaded: file_helper
INFO - 2016-08-13 06:44:54 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:44:54 --> Database Driver Class Initialized
INFO - 2016-08-13 06:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:44:54 --> Form Validation Class Initialized
INFO - 2016-08-13 06:44:54 --> Email Class Initialized
INFO - 2016-08-13 06:44:54 --> Controller Class Initialized
INFO - 2016-08-13 06:44:54 --> Model Class Initialized
INFO - 2016-08-13 06:44:54 --> Model Class Initialized
INFO - 2016-08-13 06:44:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:44:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:44:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 06:44:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:44:54 --> Final output sent to browser
DEBUG - 2016-08-13 06:44:54 --> Total execution time: 0.3107
INFO - 2016-08-13 06:44:57 --> Config Class Initialized
INFO - 2016-08-13 06:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:44:57 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:44:57 --> Utf8 Class Initialized
INFO - 2016-08-13 06:44:57 --> URI Class Initialized
INFO - 2016-08-13 06:44:57 --> Router Class Initialized
INFO - 2016-08-13 06:44:57 --> Output Class Initialized
INFO - 2016-08-13 06:44:57 --> Security Class Initialized
DEBUG - 2016-08-13 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:44:57 --> Input Class Initialized
INFO - 2016-08-13 06:44:57 --> Language Class Initialized
INFO - 2016-08-13 06:44:57 --> Loader Class Initialized
INFO - 2016-08-13 06:44:57 --> Helper loaded: url_helper
INFO - 2016-08-13 06:44:57 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:44:57 --> Helper loaded: html_helper
INFO - 2016-08-13 06:44:57 --> Helper loaded: form_helper
INFO - 2016-08-13 06:44:57 --> Helper loaded: file_helper
INFO - 2016-08-13 06:44:57 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:44:57 --> Database Driver Class Initialized
INFO - 2016-08-13 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:44:57 --> Form Validation Class Initialized
INFO - 2016-08-13 06:44:57 --> Email Class Initialized
INFO - 2016-08-13 06:44:57 --> Controller Class Initialized
INFO - 2016-08-13 06:44:57 --> Model Class Initialized
INFO - 2016-08-13 06:44:57 --> Model Class Initialized
INFO - 2016-08-13 06:44:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:44:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:44:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-13 06:44:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:44:57 --> Final output sent to browser
DEBUG - 2016-08-13 06:44:57 --> Total execution time: 0.2821
INFO - 2016-08-13 06:45:20 --> Config Class Initialized
INFO - 2016-08-13 06:45:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:45:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:45:20 --> Utf8 Class Initialized
INFO - 2016-08-13 06:45:20 --> URI Class Initialized
INFO - 2016-08-13 06:45:20 --> Router Class Initialized
INFO - 2016-08-13 06:45:20 --> Output Class Initialized
INFO - 2016-08-13 06:45:20 --> Security Class Initialized
DEBUG - 2016-08-13 06:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:45:20 --> Input Class Initialized
INFO - 2016-08-13 06:45:20 --> Language Class Initialized
INFO - 2016-08-13 06:45:20 --> Loader Class Initialized
INFO - 2016-08-13 06:45:20 --> Helper loaded: url_helper
INFO - 2016-08-13 06:45:20 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:45:20 --> Helper loaded: html_helper
INFO - 2016-08-13 06:45:20 --> Helper loaded: form_helper
INFO - 2016-08-13 06:45:20 --> Helper loaded: file_helper
INFO - 2016-08-13 06:45:20 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:45:20 --> Database Driver Class Initialized
INFO - 2016-08-13 06:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:45:20 --> Form Validation Class Initialized
INFO - 2016-08-13 06:45:20 --> Email Class Initialized
INFO - 2016-08-13 06:45:20 --> Controller Class Initialized
INFO - 2016-08-13 06:45:20 --> Model Class Initialized
INFO - 2016-08-13 06:45:20 --> Model Class Initialized
INFO - 2016-08-13 06:45:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:45:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:45:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 06:45:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:45:20 --> Final output sent to browser
DEBUG - 2016-08-13 06:45:20 --> Total execution time: 0.2576
INFO - 2016-08-13 06:46:15 --> Config Class Initialized
INFO - 2016-08-13 06:46:15 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:46:15 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:46:15 --> Utf8 Class Initialized
INFO - 2016-08-13 06:46:15 --> URI Class Initialized
INFO - 2016-08-13 06:46:15 --> Router Class Initialized
INFO - 2016-08-13 06:46:15 --> Output Class Initialized
INFO - 2016-08-13 06:46:15 --> Security Class Initialized
DEBUG - 2016-08-13 06:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:46:15 --> Input Class Initialized
INFO - 2016-08-13 06:46:15 --> Language Class Initialized
INFO - 2016-08-13 06:46:15 --> Loader Class Initialized
INFO - 2016-08-13 06:46:15 --> Helper loaded: url_helper
INFO - 2016-08-13 06:46:15 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:46:15 --> Helper loaded: html_helper
INFO - 2016-08-13 06:46:15 --> Helper loaded: form_helper
INFO - 2016-08-13 06:46:15 --> Helper loaded: file_helper
INFO - 2016-08-13 06:46:15 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:46:15 --> Database Driver Class Initialized
INFO - 2016-08-13 06:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:46:15 --> Form Validation Class Initialized
INFO - 2016-08-13 06:46:15 --> Email Class Initialized
INFO - 2016-08-13 06:46:15 --> Controller Class Initialized
INFO - 2016-08-13 06:46:15 --> Model Class Initialized
INFO - 2016-08-13 06:46:15 --> Model Class Initialized
INFO - 2016-08-13 06:46:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:46:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:46:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 06:46:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:46:15 --> Final output sent to browser
DEBUG - 2016-08-13 06:46:15 --> Total execution time: 0.2671
INFO - 2016-08-13 06:46:25 --> Config Class Initialized
INFO - 2016-08-13 06:46:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:46:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:46:25 --> Utf8 Class Initialized
INFO - 2016-08-13 06:46:25 --> URI Class Initialized
INFO - 2016-08-13 06:46:25 --> Router Class Initialized
INFO - 2016-08-13 06:46:25 --> Output Class Initialized
INFO - 2016-08-13 06:46:25 --> Security Class Initialized
DEBUG - 2016-08-13 06:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:46:25 --> Input Class Initialized
INFO - 2016-08-13 06:46:25 --> Language Class Initialized
INFO - 2016-08-13 06:46:25 --> Loader Class Initialized
INFO - 2016-08-13 06:46:25 --> Helper loaded: url_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: html_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: form_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: file_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:46:25 --> Database Driver Class Initialized
INFO - 2016-08-13 06:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:46:25 --> Form Validation Class Initialized
INFO - 2016-08-13 06:46:25 --> Email Class Initialized
INFO - 2016-08-13 06:46:25 --> Controller Class Initialized
INFO - 2016-08-13 06:46:25 --> Model Class Initialized
INFO - 2016-08-13 06:46:25 --> Config Class Initialized
INFO - 2016-08-13 06:46:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:46:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:46:25 --> Utf8 Class Initialized
INFO - 2016-08-13 06:46:25 --> URI Class Initialized
INFO - 2016-08-13 06:46:25 --> Router Class Initialized
INFO - 2016-08-13 06:46:25 --> Output Class Initialized
INFO - 2016-08-13 06:46:25 --> Security Class Initialized
DEBUG - 2016-08-13 06:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:46:25 --> Input Class Initialized
INFO - 2016-08-13 06:46:25 --> Language Class Initialized
INFO - 2016-08-13 06:46:25 --> Loader Class Initialized
INFO - 2016-08-13 06:46:25 --> Helper loaded: url_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: html_helper
INFO - 2016-08-13 06:46:25 --> Helper loaded: form_helper
INFO - 2016-08-13 06:46:26 --> Helper loaded: file_helper
INFO - 2016-08-13 06:46:26 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:46:26 --> Database Driver Class Initialized
INFO - 2016-08-13 06:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:46:26 --> Form Validation Class Initialized
INFO - 2016-08-13 06:46:26 --> Email Class Initialized
INFO - 2016-08-13 06:46:26 --> Controller Class Initialized
INFO - 2016-08-13 06:46:26 --> Model Class Initialized
DEBUG - 2016-08-13 06:46:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:46:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 06:46:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:46:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 06:46:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:46:26 --> Final output sent to browser
DEBUG - 2016-08-13 06:46:26 --> Total execution time: 0.2745
INFO - 2016-08-13 06:46:30 --> Config Class Initialized
INFO - 2016-08-13 06:46:30 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:46:30 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:46:30 --> Utf8 Class Initialized
INFO - 2016-08-13 06:46:30 --> URI Class Initialized
INFO - 2016-08-13 06:46:30 --> Router Class Initialized
INFO - 2016-08-13 06:46:30 --> Output Class Initialized
INFO - 2016-08-13 06:46:30 --> Security Class Initialized
DEBUG - 2016-08-13 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:46:30 --> Input Class Initialized
INFO - 2016-08-13 06:46:30 --> Language Class Initialized
INFO - 2016-08-13 06:46:30 --> Loader Class Initialized
INFO - 2016-08-13 06:46:30 --> Helper loaded: url_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: html_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: form_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: file_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:46:30 --> Database Driver Class Initialized
INFO - 2016-08-13 06:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:46:30 --> Form Validation Class Initialized
INFO - 2016-08-13 06:46:30 --> Email Class Initialized
INFO - 2016-08-13 06:46:30 --> Controller Class Initialized
INFO - 2016-08-13 06:46:30 --> Model Class Initialized
DEBUG - 2016-08-13 06:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:46:30 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 06:46:30 --> Config Class Initialized
INFO - 2016-08-13 06:46:30 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:46:30 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:46:30 --> Utf8 Class Initialized
INFO - 2016-08-13 06:46:30 --> URI Class Initialized
INFO - 2016-08-13 06:46:30 --> Router Class Initialized
INFO - 2016-08-13 06:46:30 --> Output Class Initialized
INFO - 2016-08-13 06:46:30 --> Security Class Initialized
DEBUG - 2016-08-13 06:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:46:30 --> Input Class Initialized
INFO - 2016-08-13 06:46:30 --> Language Class Initialized
INFO - 2016-08-13 06:46:30 --> Loader Class Initialized
INFO - 2016-08-13 06:46:30 --> Helper loaded: url_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: html_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: form_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: file_helper
INFO - 2016-08-13 06:46:30 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:46:30 --> Database Driver Class Initialized
INFO - 2016-08-13 06:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:46:30 --> Form Validation Class Initialized
INFO - 2016-08-13 06:46:30 --> Email Class Initialized
INFO - 2016-08-13 06:46:30 --> Controller Class Initialized
DEBUG - 2016-08-13 06:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 06:46:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:46:30 --> Model Class Initialized
INFO - 2016-08-13 06:46:30 --> Model Class Initialized
INFO - 2016-08-13 06:46:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:46:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:46:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 06:46:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:46:30 --> Final output sent to browser
DEBUG - 2016-08-13 06:46:30 --> Total execution time: 0.4332
INFO - 2016-08-13 06:48:05 --> Config Class Initialized
INFO - 2016-08-13 06:48:05 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:48:05 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:48:05 --> Utf8 Class Initialized
INFO - 2016-08-13 06:48:05 --> URI Class Initialized
INFO - 2016-08-13 06:48:05 --> Router Class Initialized
INFO - 2016-08-13 06:48:05 --> Output Class Initialized
INFO - 2016-08-13 06:48:05 --> Security Class Initialized
DEBUG - 2016-08-13 06:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:48:05 --> Input Class Initialized
INFO - 2016-08-13 06:48:05 --> Language Class Initialized
INFO - 2016-08-13 06:48:05 --> Loader Class Initialized
INFO - 2016-08-13 06:48:06 --> Helper loaded: url_helper
INFO - 2016-08-13 06:48:06 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:48:06 --> Helper loaded: html_helper
INFO - 2016-08-13 06:48:06 --> Helper loaded: form_helper
INFO - 2016-08-13 06:48:06 --> Helper loaded: file_helper
INFO - 2016-08-13 06:48:06 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:48:06 --> Database Driver Class Initialized
INFO - 2016-08-13 06:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:48:06 --> Form Validation Class Initialized
INFO - 2016-08-13 06:48:06 --> Email Class Initialized
INFO - 2016-08-13 06:48:06 --> Controller Class Initialized
DEBUG - 2016-08-13 06:48:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 06:48:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:48:06 --> Model Class Initialized
INFO - 2016-08-13 06:48:06 --> Model Class Initialized
INFO - 2016-08-13 06:48:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:48:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:48:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 06:48:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:48:06 --> Final output sent to browser
DEBUG - 2016-08-13 06:48:06 --> Total execution time: 0.3680
INFO - 2016-08-13 06:49:04 --> Config Class Initialized
INFO - 2016-08-13 06:49:04 --> Hooks Class Initialized
DEBUG - 2016-08-13 06:49:04 --> UTF-8 Support Enabled
INFO - 2016-08-13 06:49:04 --> Utf8 Class Initialized
INFO - 2016-08-13 06:49:04 --> URI Class Initialized
INFO - 2016-08-13 06:49:04 --> Router Class Initialized
INFO - 2016-08-13 06:49:04 --> Output Class Initialized
INFO - 2016-08-13 06:49:04 --> Security Class Initialized
DEBUG - 2016-08-13 06:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 06:49:04 --> Input Class Initialized
INFO - 2016-08-13 06:49:04 --> Language Class Initialized
INFO - 2016-08-13 06:49:04 --> Loader Class Initialized
INFO - 2016-08-13 06:49:04 --> Helper loaded: url_helper
INFO - 2016-08-13 06:49:04 --> Helper loaded: utils_helper
INFO - 2016-08-13 06:49:04 --> Helper loaded: html_helper
INFO - 2016-08-13 06:49:04 --> Helper loaded: form_helper
INFO - 2016-08-13 06:49:04 --> Helper loaded: file_helper
INFO - 2016-08-13 06:49:04 --> Helper loaded: myemail_helper
INFO - 2016-08-13 06:49:04 --> Database Driver Class Initialized
INFO - 2016-08-13 06:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 06:49:05 --> Form Validation Class Initialized
INFO - 2016-08-13 06:49:05 --> Email Class Initialized
INFO - 2016-08-13 06:49:05 --> Controller Class Initialized
DEBUG - 2016-08-13 06:49:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 06:49:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 06:49:05 --> Model Class Initialized
INFO - 2016-08-13 06:49:05 --> Model Class Initialized
INFO - 2016-08-13 06:49:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 06:49:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 06:49:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 06:49:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 06:49:05 --> Final output sent to browser
DEBUG - 2016-08-13 06:49:05 --> Total execution time: 0.3763
INFO - 2016-08-13 07:01:22 --> Config Class Initialized
INFO - 2016-08-13 07:01:22 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:01:22 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:01:22 --> Utf8 Class Initialized
INFO - 2016-08-13 07:01:22 --> URI Class Initialized
INFO - 2016-08-13 07:01:22 --> Router Class Initialized
INFO - 2016-08-13 07:01:22 --> Output Class Initialized
INFO - 2016-08-13 07:01:22 --> Security Class Initialized
DEBUG - 2016-08-13 07:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:01:22 --> Input Class Initialized
INFO - 2016-08-13 07:01:22 --> Language Class Initialized
INFO - 2016-08-13 07:01:22 --> Loader Class Initialized
INFO - 2016-08-13 07:01:22 --> Helper loaded: url_helper
INFO - 2016-08-13 07:01:22 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:01:22 --> Helper loaded: html_helper
INFO - 2016-08-13 07:01:22 --> Helper loaded: form_helper
INFO - 2016-08-13 07:01:22 --> Helper loaded: file_helper
INFO - 2016-08-13 07:01:22 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:01:23 --> Database Driver Class Initialized
INFO - 2016-08-13 07:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:01:23 --> Form Validation Class Initialized
INFO - 2016-08-13 07:01:23 --> Email Class Initialized
INFO - 2016-08-13 07:01:23 --> Controller Class Initialized
DEBUG - 2016-08-13 07:01:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:01:23 --> Model Class Initialized
INFO - 2016-08-13 07:01:23 --> Model Class Initialized
INFO - 2016-08-13 07:01:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:01:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:01:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 07:01:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:01:23 --> Final output sent to browser
DEBUG - 2016-08-13 07:01:23 --> Total execution time: 0.2859
INFO - 2016-08-13 07:01:25 --> Config Class Initialized
INFO - 2016-08-13 07:01:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:01:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:01:25 --> Utf8 Class Initialized
INFO - 2016-08-13 07:01:25 --> URI Class Initialized
INFO - 2016-08-13 07:01:25 --> Router Class Initialized
INFO - 2016-08-13 07:01:25 --> Output Class Initialized
INFO - 2016-08-13 07:01:25 --> Security Class Initialized
DEBUG - 2016-08-13 07:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:01:26 --> Input Class Initialized
INFO - 2016-08-13 07:01:26 --> Language Class Initialized
INFO - 2016-08-13 07:01:26 --> Loader Class Initialized
INFO - 2016-08-13 07:01:26 --> Helper loaded: url_helper
INFO - 2016-08-13 07:01:26 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:01:26 --> Helper loaded: html_helper
INFO - 2016-08-13 07:01:26 --> Helper loaded: form_helper
INFO - 2016-08-13 07:01:26 --> Helper loaded: file_helper
INFO - 2016-08-13 07:01:26 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:01:26 --> Database Driver Class Initialized
INFO - 2016-08-13 07:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:01:26 --> Form Validation Class Initialized
INFO - 2016-08-13 07:01:26 --> Email Class Initialized
INFO - 2016-08-13 07:01:26 --> Controller Class Initialized
INFO - 2016-08-13 07:01:26 --> Model Class Initialized
INFO - 2016-08-13 07:01:26 --> Model Class Initialized
INFO - 2016-08-13 07:01:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:01:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:01:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 07:01:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:01:26 --> Final output sent to browser
DEBUG - 2016-08-13 07:01:26 --> Total execution time: 0.2900
INFO - 2016-08-13 07:01:32 --> Config Class Initialized
INFO - 2016-08-13 07:01:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:01:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:01:32 --> Utf8 Class Initialized
INFO - 2016-08-13 07:01:32 --> URI Class Initialized
INFO - 2016-08-13 07:01:32 --> Router Class Initialized
INFO - 2016-08-13 07:01:32 --> Output Class Initialized
INFO - 2016-08-13 07:01:32 --> Security Class Initialized
DEBUG - 2016-08-13 07:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:01:32 --> Input Class Initialized
INFO - 2016-08-13 07:01:32 --> Language Class Initialized
INFO - 2016-08-13 07:01:32 --> Loader Class Initialized
INFO - 2016-08-13 07:01:32 --> Helper loaded: url_helper
INFO - 2016-08-13 07:01:32 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:01:32 --> Helper loaded: html_helper
INFO - 2016-08-13 07:01:32 --> Helper loaded: form_helper
INFO - 2016-08-13 07:01:32 --> Helper loaded: file_helper
INFO - 2016-08-13 07:01:32 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:01:32 --> Database Driver Class Initialized
INFO - 2016-08-13 07:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:01:32 --> Form Validation Class Initialized
INFO - 2016-08-13 07:01:32 --> Email Class Initialized
INFO - 2016-08-13 07:01:32 --> Controller Class Initialized
DEBUG - 2016-08-13 07:01:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:01:32 --> Model Class Initialized
INFO - 2016-08-13 07:01:32 --> Model Class Initialized
INFO - 2016-08-13 07:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:01:32 --> Final output sent to browser
DEBUG - 2016-08-13 07:01:32 --> Total execution time: 0.3019
INFO - 2016-08-13 07:02:02 --> Config Class Initialized
INFO - 2016-08-13 07:02:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:02:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:02:02 --> Utf8 Class Initialized
INFO - 2016-08-13 07:02:02 --> URI Class Initialized
INFO - 2016-08-13 07:02:02 --> Router Class Initialized
INFO - 2016-08-13 07:02:02 --> Output Class Initialized
INFO - 2016-08-13 07:02:02 --> Security Class Initialized
DEBUG - 2016-08-13 07:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:02:02 --> Input Class Initialized
INFO - 2016-08-13 07:02:02 --> Language Class Initialized
INFO - 2016-08-13 07:02:02 --> Loader Class Initialized
INFO - 2016-08-13 07:02:02 --> Helper loaded: url_helper
INFO - 2016-08-13 07:02:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:02:02 --> Helper loaded: html_helper
INFO - 2016-08-13 07:02:02 --> Helper loaded: form_helper
INFO - 2016-08-13 07:02:02 --> Helper loaded: file_helper
INFO - 2016-08-13 07:02:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:02:02 --> Database Driver Class Initialized
INFO - 2016-08-13 07:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:02:02 --> Form Validation Class Initialized
INFO - 2016-08-13 07:02:02 --> Email Class Initialized
INFO - 2016-08-13 07:02:02 --> Controller Class Initialized
DEBUG - 2016-08-13 07:02:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:02:02 --> Model Class Initialized
INFO - 2016-08-13 07:02:02 --> Model Class Initialized
INFO - 2016-08-13 07:02:02 --> Model Class Initialized
INFO - 2016-08-13 07:02:02 --> Final output sent to browser
DEBUG - 2016-08-13 07:02:02 --> Total execution time: 0.3033
INFO - 2016-08-13 07:02:17 --> Config Class Initialized
INFO - 2016-08-13 07:02:17 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:02:17 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:02:17 --> Utf8 Class Initialized
INFO - 2016-08-13 07:02:17 --> URI Class Initialized
INFO - 2016-08-13 07:02:17 --> Router Class Initialized
INFO - 2016-08-13 07:02:17 --> Output Class Initialized
INFO - 2016-08-13 07:02:17 --> Security Class Initialized
DEBUG - 2016-08-13 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:02:17 --> Input Class Initialized
INFO - 2016-08-13 07:02:17 --> Language Class Initialized
INFO - 2016-08-13 07:02:17 --> Loader Class Initialized
INFO - 2016-08-13 07:02:17 --> Helper loaded: url_helper
INFO - 2016-08-13 07:02:17 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:02:17 --> Helper loaded: html_helper
INFO - 2016-08-13 07:02:17 --> Helper loaded: form_helper
INFO - 2016-08-13 07:02:17 --> Helper loaded: file_helper
INFO - 2016-08-13 07:02:17 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:02:17 --> Database Driver Class Initialized
INFO - 2016-08-13 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:02:17 --> Form Validation Class Initialized
INFO - 2016-08-13 07:02:17 --> Email Class Initialized
INFO - 2016-08-13 07:02:17 --> Controller Class Initialized
DEBUG - 2016-08-13 07:02:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:02:17 --> Model Class Initialized
INFO - 2016-08-13 07:02:17 --> Model Class Initialized
INFO - 2016-08-13 07:02:17 --> Model Class Initialized
INFO - 2016-08-13 07:02:17 --> Final output sent to browser
DEBUG - 2016-08-13 07:02:17 --> Total execution time: 0.2853
INFO - 2016-08-13 07:02:29 --> Config Class Initialized
INFO - 2016-08-13 07:02:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:02:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:02:29 --> Utf8 Class Initialized
INFO - 2016-08-13 07:02:29 --> URI Class Initialized
INFO - 2016-08-13 07:02:29 --> Router Class Initialized
INFO - 2016-08-13 07:02:29 --> Output Class Initialized
INFO - 2016-08-13 07:02:29 --> Security Class Initialized
DEBUG - 2016-08-13 07:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:02:29 --> Input Class Initialized
INFO - 2016-08-13 07:02:29 --> Language Class Initialized
INFO - 2016-08-13 07:02:29 --> Loader Class Initialized
INFO - 2016-08-13 07:02:29 --> Helper loaded: url_helper
INFO - 2016-08-13 07:02:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:02:29 --> Helper loaded: html_helper
INFO - 2016-08-13 07:02:29 --> Helper loaded: form_helper
INFO - 2016-08-13 07:02:29 --> Helper loaded: file_helper
INFO - 2016-08-13 07:02:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:02:29 --> Database Driver Class Initialized
INFO - 2016-08-13 07:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:02:29 --> Form Validation Class Initialized
INFO - 2016-08-13 07:02:29 --> Email Class Initialized
INFO - 2016-08-13 07:02:29 --> Controller Class Initialized
INFO - 2016-08-13 07:02:29 --> Model Class Initialized
INFO - 2016-08-13 07:02:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:02:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:02:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 07:02:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:02:29 --> Final output sent to browser
DEBUG - 2016-08-13 07:02:29 --> Total execution time: 0.2869
INFO - 2016-08-13 07:02:32 --> Config Class Initialized
INFO - 2016-08-13 07:02:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:02:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:02:32 --> Utf8 Class Initialized
INFO - 2016-08-13 07:02:32 --> URI Class Initialized
INFO - 2016-08-13 07:02:32 --> Router Class Initialized
INFO - 2016-08-13 07:02:32 --> Output Class Initialized
INFO - 2016-08-13 07:02:32 --> Security Class Initialized
DEBUG - 2016-08-13 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:02:32 --> Input Class Initialized
INFO - 2016-08-13 07:02:32 --> Language Class Initialized
INFO - 2016-08-13 07:02:32 --> Loader Class Initialized
INFO - 2016-08-13 07:02:32 --> Helper loaded: url_helper
INFO - 2016-08-13 07:02:32 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:02:32 --> Helper loaded: html_helper
INFO - 2016-08-13 07:02:32 --> Helper loaded: form_helper
INFO - 2016-08-13 07:02:32 --> Helper loaded: file_helper
INFO - 2016-08-13 07:02:32 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:02:32 --> Database Driver Class Initialized
INFO - 2016-08-13 07:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:02:32 --> Form Validation Class Initialized
INFO - 2016-08-13 07:02:32 --> Email Class Initialized
INFO - 2016-08-13 07:02:32 --> Controller Class Initialized
INFO - 2016-08-13 07:02:32 --> Model Class Initialized
INFO - 2016-08-13 07:02:32 --> Config Class Initialized
INFO - 2016-08-13 07:02:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:02:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:02:32 --> Utf8 Class Initialized
INFO - 2016-08-13 07:02:32 --> URI Class Initialized
INFO - 2016-08-13 07:02:32 --> Router Class Initialized
INFO - 2016-08-13 07:02:32 --> Output Class Initialized
INFO - 2016-08-13 07:02:32 --> Security Class Initialized
DEBUG - 2016-08-13 07:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:02:32 --> Input Class Initialized
INFO - 2016-08-13 07:02:32 --> Language Class Initialized
INFO - 2016-08-13 07:02:32 --> Loader Class Initialized
INFO - 2016-08-13 07:02:33 --> Helper loaded: url_helper
INFO - 2016-08-13 07:02:33 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:02:33 --> Helper loaded: html_helper
INFO - 2016-08-13 07:02:33 --> Helper loaded: form_helper
INFO - 2016-08-13 07:02:33 --> Helper loaded: file_helper
INFO - 2016-08-13 07:02:33 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:02:33 --> Database Driver Class Initialized
INFO - 2016-08-13 07:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:02:33 --> Form Validation Class Initialized
INFO - 2016-08-13 07:02:33 --> Email Class Initialized
INFO - 2016-08-13 07:02:33 --> Controller Class Initialized
INFO - 2016-08-13 07:02:33 --> Model Class Initialized
DEBUG - 2016-08-13 07:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:02:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 07:02:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:02:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 07:02:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:02:33 --> Final output sent to browser
DEBUG - 2016-08-13 07:02:33 --> Total execution time: 0.2864
INFO - 2016-08-13 07:04:08 --> Config Class Initialized
INFO - 2016-08-13 07:04:08 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:08 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:08 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:08 --> URI Class Initialized
INFO - 2016-08-13 07:04:08 --> Router Class Initialized
INFO - 2016-08-13 07:04:08 --> Output Class Initialized
INFO - 2016-08-13 07:04:08 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:08 --> Input Class Initialized
INFO - 2016-08-13 07:04:08 --> Language Class Initialized
INFO - 2016-08-13 07:04:08 --> Loader Class Initialized
INFO - 2016-08-13 07:04:08 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:08 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:08 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:08 --> Email Class Initialized
INFO - 2016-08-13 07:04:08 --> Controller Class Initialized
INFO - 2016-08-13 07:04:08 --> Model Class Initialized
DEBUG - 2016-08-13 07:04:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:04:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 07:04:08 --> Config Class Initialized
INFO - 2016-08-13 07:04:08 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:08 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:08 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:08 --> URI Class Initialized
INFO - 2016-08-13 07:04:08 --> Router Class Initialized
INFO - 2016-08-13 07:04:08 --> Output Class Initialized
INFO - 2016-08-13 07:04:08 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:08 --> Input Class Initialized
INFO - 2016-08-13 07:04:08 --> Language Class Initialized
INFO - 2016-08-13 07:04:08 --> Loader Class Initialized
INFO - 2016-08-13 07:04:08 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:08 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:08 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:08 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:08 --> Email Class Initialized
INFO - 2016-08-13 07:04:08 --> Controller Class Initialized
INFO - 2016-08-13 07:04:08 --> Model Class Initialized
INFO - 2016-08-13 07:04:08 --> Model Class Initialized
INFO - 2016-08-13 07:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 07:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:04:08 --> Final output sent to browser
DEBUG - 2016-08-13 07:04:08 --> Total execution time: 0.3147
INFO - 2016-08-13 07:04:19 --> Config Class Initialized
INFO - 2016-08-13 07:04:19 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:19 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:19 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:19 --> URI Class Initialized
INFO - 2016-08-13 07:04:19 --> Router Class Initialized
INFO - 2016-08-13 07:04:19 --> Output Class Initialized
INFO - 2016-08-13 07:04:19 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:19 --> Input Class Initialized
INFO - 2016-08-13 07:04:19 --> Language Class Initialized
ERROR - 2016-08-13 07:04:19 --> 404 Page Not Found: Add/index
INFO - 2016-08-13 07:04:21 --> Config Class Initialized
INFO - 2016-08-13 07:04:21 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:21 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:21 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:21 --> URI Class Initialized
INFO - 2016-08-13 07:04:21 --> Router Class Initialized
INFO - 2016-08-13 07:04:21 --> Output Class Initialized
INFO - 2016-08-13 07:04:21 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:21 --> Input Class Initialized
INFO - 2016-08-13 07:04:21 --> Language Class Initialized
INFO - 2016-08-13 07:04:21 --> Loader Class Initialized
INFO - 2016-08-13 07:04:21 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:21 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:21 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:21 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:21 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:21 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:21 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:21 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:21 --> Email Class Initialized
INFO - 2016-08-13 07:04:21 --> Controller Class Initialized
INFO - 2016-08-13 07:04:21 --> Model Class Initialized
INFO - 2016-08-13 07:04:21 --> Model Class Initialized
INFO - 2016-08-13 07:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 07:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:04:21 --> Final output sent to browser
DEBUG - 2016-08-13 07:04:21 --> Total execution time: 0.3072
INFO - 2016-08-13 07:04:29 --> Config Class Initialized
INFO - 2016-08-13 07:04:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:29 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:29 --> URI Class Initialized
INFO - 2016-08-13 07:04:29 --> Router Class Initialized
INFO - 2016-08-13 07:04:29 --> Output Class Initialized
INFO - 2016-08-13 07:04:29 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:29 --> Input Class Initialized
INFO - 2016-08-13 07:04:29 --> Language Class Initialized
INFO - 2016-08-13 07:04:29 --> Loader Class Initialized
INFO - 2016-08-13 07:04:29 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:29 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:29 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:29 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:29 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:29 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:29 --> Email Class Initialized
INFO - 2016-08-13 07:04:29 --> Controller Class Initialized
DEBUG - 2016-08-13 07:04:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:04:30 --> Model Class Initialized
INFO - 2016-08-13 07:04:30 --> Model Class Initialized
INFO - 2016-08-13 07:04:30 --> Config Class Initialized
INFO - 2016-08-13 07:04:30 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:30 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:30 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:30 --> URI Class Initialized
INFO - 2016-08-13 07:04:30 --> Router Class Initialized
INFO - 2016-08-13 07:04:30 --> Output Class Initialized
INFO - 2016-08-13 07:04:30 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:30 --> Input Class Initialized
INFO - 2016-08-13 07:04:30 --> Language Class Initialized
INFO - 2016-08-13 07:04:30 --> Loader Class Initialized
INFO - 2016-08-13 07:04:30 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:30 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:30 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:30 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:30 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:30 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:30 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:30 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:30 --> Email Class Initialized
INFO - 2016-08-13 07:04:30 --> Controller Class Initialized
INFO - 2016-08-13 07:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:04:30 --> Final output sent to browser
DEBUG - 2016-08-13 07:04:30 --> Total execution time: 0.2767
INFO - 2016-08-13 07:04:40 --> Config Class Initialized
INFO - 2016-08-13 07:04:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:40 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:40 --> URI Class Initialized
INFO - 2016-08-13 07:04:40 --> Router Class Initialized
INFO - 2016-08-13 07:04:40 --> Output Class Initialized
INFO - 2016-08-13 07:04:40 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:40 --> Input Class Initialized
INFO - 2016-08-13 07:04:40 --> Language Class Initialized
ERROR - 2016-08-13 07:04:40 --> 404 Page Not Found: Books/edite
INFO - 2016-08-13 07:04:44 --> Config Class Initialized
INFO - 2016-08-13 07:04:44 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:44 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:44 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:44 --> URI Class Initialized
INFO - 2016-08-13 07:04:44 --> Router Class Initialized
INFO - 2016-08-13 07:04:44 --> Output Class Initialized
INFO - 2016-08-13 07:04:44 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:44 --> Input Class Initialized
INFO - 2016-08-13 07:04:44 --> Language Class Initialized
INFO - 2016-08-13 07:04:44 --> Loader Class Initialized
INFO - 2016-08-13 07:04:44 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:44 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:44 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:44 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:44 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:44 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:44 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:44 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:44 --> Email Class Initialized
INFO - 2016-08-13 07:04:44 --> Controller Class Initialized
DEBUG - 2016-08-13 07:04:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:04:44 --> Model Class Initialized
INFO - 2016-08-13 07:04:44 --> Model Class Initialized
INFO - 2016-08-13 07:04:44 --> Config Class Initialized
INFO - 2016-08-13 07:04:44 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:04:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:04:45 --> Utf8 Class Initialized
INFO - 2016-08-13 07:04:45 --> URI Class Initialized
INFO - 2016-08-13 07:04:45 --> Router Class Initialized
INFO - 2016-08-13 07:04:45 --> Output Class Initialized
INFO - 2016-08-13 07:04:45 --> Security Class Initialized
DEBUG - 2016-08-13 07:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:04:45 --> Input Class Initialized
INFO - 2016-08-13 07:04:45 --> Language Class Initialized
INFO - 2016-08-13 07:04:45 --> Loader Class Initialized
INFO - 2016-08-13 07:04:45 --> Helper loaded: url_helper
INFO - 2016-08-13 07:04:45 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:04:45 --> Helper loaded: html_helper
INFO - 2016-08-13 07:04:45 --> Helper loaded: form_helper
INFO - 2016-08-13 07:04:45 --> Helper loaded: file_helper
INFO - 2016-08-13 07:04:45 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:04:45 --> Database Driver Class Initialized
INFO - 2016-08-13 07:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:04:45 --> Form Validation Class Initialized
INFO - 2016-08-13 07:04:45 --> Email Class Initialized
INFO - 2016-08-13 07:04:45 --> Controller Class Initialized
INFO - 2016-08-13 07:04:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:04:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:04:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:04:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:04:45 --> Final output sent to browser
DEBUG - 2016-08-13 07:04:45 --> Total execution time: 0.2647
INFO - 2016-08-13 07:06:29 --> Config Class Initialized
INFO - 2016-08-13 07:06:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:29 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:29 --> URI Class Initialized
DEBUG - 2016-08-13 07:06:29 --> No URI present. Default controller set.
INFO - 2016-08-13 07:06:29 --> Router Class Initialized
INFO - 2016-08-13 07:06:29 --> Output Class Initialized
INFO - 2016-08-13 07:06:29 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:29 --> Input Class Initialized
INFO - 2016-08-13 07:06:29 --> Language Class Initialized
INFO - 2016-08-13 07:06:29 --> Loader Class Initialized
INFO - 2016-08-13 07:06:29 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:29 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:29 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:29 --> Email Class Initialized
INFO - 2016-08-13 07:06:29 --> Controller Class Initialized
INFO - 2016-08-13 07:06:29 --> Config Class Initialized
INFO - 2016-08-13 07:06:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:29 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:29 --> URI Class Initialized
INFO - 2016-08-13 07:06:29 --> Router Class Initialized
INFO - 2016-08-13 07:06:29 --> Output Class Initialized
INFO - 2016-08-13 07:06:29 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:29 --> Input Class Initialized
INFO - 2016-08-13 07:06:29 --> Language Class Initialized
INFO - 2016-08-13 07:06:29 --> Loader Class Initialized
INFO - 2016-08-13 07:06:29 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:29 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:29 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:29 --> Email Class Initialized
INFO - 2016-08-13 07:06:29 --> Controller Class Initialized
INFO - 2016-08-13 07:06:29 --> Model Class Initialized
DEBUG - 2016-08-13 07:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:06:29 --> Final output sent to browser
DEBUG - 2016-08-13 07:06:29 --> Total execution time: 0.3029
INFO - 2016-08-13 07:06:31 --> Config Class Initialized
INFO - 2016-08-13 07:06:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:31 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:31 --> URI Class Initialized
INFO - 2016-08-13 07:06:31 --> Router Class Initialized
INFO - 2016-08-13 07:06:31 --> Output Class Initialized
INFO - 2016-08-13 07:06:31 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:31 --> Input Class Initialized
INFO - 2016-08-13 07:06:31 --> Language Class Initialized
ERROR - 2016-08-13 07:06:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-13 07:06:37 --> Config Class Initialized
INFO - 2016-08-13 07:06:37 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:37 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:37 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:37 --> URI Class Initialized
INFO - 2016-08-13 07:06:37 --> Router Class Initialized
INFO - 2016-08-13 07:06:37 --> Output Class Initialized
INFO - 2016-08-13 07:06:37 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:37 --> Input Class Initialized
INFO - 2016-08-13 07:06:37 --> Language Class Initialized
INFO - 2016-08-13 07:06:37 --> Loader Class Initialized
INFO - 2016-08-13 07:06:37 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:37 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:37 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:37 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:37 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:37 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:37 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:37 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:37 --> Email Class Initialized
INFO - 2016-08-13 07:06:37 --> Controller Class Initialized
INFO - 2016-08-13 07:06:37 --> Model Class Initialized
DEBUG - 2016-08-13 07:06:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:06:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 07:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-13 07:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-13 07:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:06:37 --> Final output sent to browser
DEBUG - 2016-08-13 07:06:37 --> Total execution time: 0.2949
INFO - 2016-08-13 07:06:41 --> Config Class Initialized
INFO - 2016-08-13 07:06:41 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:41 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:41 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:41 --> URI Class Initialized
INFO - 2016-08-13 07:06:41 --> Router Class Initialized
INFO - 2016-08-13 07:06:42 --> Output Class Initialized
INFO - 2016-08-13 07:06:42 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:42 --> Input Class Initialized
INFO - 2016-08-13 07:06:42 --> Language Class Initialized
INFO - 2016-08-13 07:06:42 --> Loader Class Initialized
INFO - 2016-08-13 07:06:42 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:42 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:42 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:42 --> Email Class Initialized
INFO - 2016-08-13 07:06:42 --> Controller Class Initialized
INFO - 2016-08-13 07:06:42 --> Model Class Initialized
DEBUG - 2016-08-13 07:06:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:06:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-13 07:06:42 --> Config Class Initialized
INFO - 2016-08-13 07:06:42 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:42 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:42 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:42 --> URI Class Initialized
DEBUG - 2016-08-13 07:06:42 --> No URI present. Default controller set.
INFO - 2016-08-13 07:06:42 --> Router Class Initialized
INFO - 2016-08-13 07:06:42 --> Output Class Initialized
INFO - 2016-08-13 07:06:42 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:42 --> Input Class Initialized
INFO - 2016-08-13 07:06:42 --> Language Class Initialized
INFO - 2016-08-13 07:06:42 --> Loader Class Initialized
INFO - 2016-08-13 07:06:42 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:42 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:42 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:42 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:42 --> Email Class Initialized
INFO - 2016-08-13 07:06:42 --> Controller Class Initialized
INFO - 2016-08-13 07:06:42 --> Model Class Initialized
INFO - 2016-08-13 07:06:42 --> Model Class Initialized
INFO - 2016-08-13 07:06:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:06:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:06:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-13 07:06:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:06:42 --> Final output sent to browser
DEBUG - 2016-08-13 07:06:42 --> Total execution time: 0.2938
INFO - 2016-08-13 07:06:52 --> Config Class Initialized
INFO - 2016-08-13 07:06:52 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:06:52 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:06:52 --> Utf8 Class Initialized
INFO - 2016-08-13 07:06:52 --> URI Class Initialized
INFO - 2016-08-13 07:06:52 --> Router Class Initialized
INFO - 2016-08-13 07:06:52 --> Output Class Initialized
INFO - 2016-08-13 07:06:52 --> Security Class Initialized
DEBUG - 2016-08-13 07:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:06:52 --> Input Class Initialized
INFO - 2016-08-13 07:06:52 --> Language Class Initialized
INFO - 2016-08-13 07:06:52 --> Loader Class Initialized
INFO - 2016-08-13 07:06:52 --> Helper loaded: url_helper
INFO - 2016-08-13 07:06:52 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:06:52 --> Helper loaded: html_helper
INFO - 2016-08-13 07:06:52 --> Helper loaded: form_helper
INFO - 2016-08-13 07:06:52 --> Helper loaded: file_helper
INFO - 2016-08-13 07:06:52 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:06:52 --> Database Driver Class Initialized
INFO - 2016-08-13 07:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:06:52 --> Form Validation Class Initialized
INFO - 2016-08-13 07:06:52 --> Email Class Initialized
INFO - 2016-08-13 07:06:52 --> Controller Class Initialized
INFO - 2016-08-13 07:06:52 --> Model Class Initialized
INFO - 2016-08-13 07:06:52 --> Model Class Initialized
DEBUG - 2016-08-13 07:06:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:06:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:06:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:06:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-13 07:06:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:06:52 --> Final output sent to browser
DEBUG - 2016-08-13 07:06:52 --> Total execution time: 0.3017
INFO - 2016-08-13 07:07:08 --> Config Class Initialized
INFO - 2016-08-13 07:07:08 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:07:08 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:07:08 --> Utf8 Class Initialized
INFO - 2016-08-13 07:07:08 --> URI Class Initialized
INFO - 2016-08-13 07:07:08 --> Router Class Initialized
INFO - 2016-08-13 07:07:08 --> Output Class Initialized
INFO - 2016-08-13 07:07:08 --> Security Class Initialized
DEBUG - 2016-08-13 07:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:07:08 --> Input Class Initialized
INFO - 2016-08-13 07:07:08 --> Language Class Initialized
INFO - 2016-08-13 07:07:08 --> Loader Class Initialized
INFO - 2016-08-13 07:07:08 --> Helper loaded: url_helper
INFO - 2016-08-13 07:07:08 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:07:08 --> Helper loaded: html_helper
INFO - 2016-08-13 07:07:08 --> Helper loaded: form_helper
INFO - 2016-08-13 07:07:08 --> Helper loaded: file_helper
INFO - 2016-08-13 07:07:08 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:07:08 --> Database Driver Class Initialized
INFO - 2016-08-13 07:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:07:08 --> Form Validation Class Initialized
INFO - 2016-08-13 07:07:08 --> Email Class Initialized
INFO - 2016-08-13 07:07:08 --> Controller Class Initialized
INFO - 2016-08-13 07:07:08 --> Model Class Initialized
INFO - 2016-08-13 07:07:08 --> Model Class Initialized
DEBUG - 2016-08-13 07:07:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:07:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:07:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:07:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-13 07:07:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:07:08 --> Final output sent to browser
DEBUG - 2016-08-13 07:07:08 --> Total execution time: 0.3069
INFO - 2016-08-13 07:07:13 --> Config Class Initialized
INFO - 2016-08-13 07:07:13 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:07:13 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:07:13 --> Utf8 Class Initialized
INFO - 2016-08-13 07:07:13 --> URI Class Initialized
INFO - 2016-08-13 07:07:13 --> Router Class Initialized
INFO - 2016-08-13 07:07:13 --> Output Class Initialized
INFO - 2016-08-13 07:07:13 --> Security Class Initialized
DEBUG - 2016-08-13 07:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:07:13 --> Input Class Initialized
INFO - 2016-08-13 07:07:13 --> Language Class Initialized
INFO - 2016-08-13 07:07:13 --> Loader Class Initialized
INFO - 2016-08-13 07:07:13 --> Helper loaded: url_helper
INFO - 2016-08-13 07:07:13 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:07:13 --> Helper loaded: html_helper
INFO - 2016-08-13 07:07:13 --> Helper loaded: form_helper
INFO - 2016-08-13 07:07:13 --> Helper loaded: file_helper
INFO - 2016-08-13 07:07:13 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:07:13 --> Database Driver Class Initialized
INFO - 2016-08-13 07:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:07:13 --> Form Validation Class Initialized
INFO - 2016-08-13 07:07:13 --> Email Class Initialized
INFO - 2016-08-13 07:07:13 --> Controller Class Initialized
INFO - 2016-08-13 07:07:13 --> Model Class Initialized
INFO - 2016-08-13 07:07:13 --> Model Class Initialized
DEBUG - 2016-08-13 07:07:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:07:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:07:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:07:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-13 07:07:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:07:13 --> Final output sent to browser
DEBUG - 2016-08-13 07:07:13 --> Total execution time: 0.3114
INFO - 2016-08-13 07:08:20 --> Config Class Initialized
INFO - 2016-08-13 07:08:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:08:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:08:20 --> Utf8 Class Initialized
INFO - 2016-08-13 07:08:20 --> URI Class Initialized
INFO - 2016-08-13 07:08:20 --> Router Class Initialized
INFO - 2016-08-13 07:08:20 --> Output Class Initialized
INFO - 2016-08-13 07:08:20 --> Security Class Initialized
DEBUG - 2016-08-13 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:08:20 --> Input Class Initialized
INFO - 2016-08-13 07:08:20 --> Language Class Initialized
INFO - 2016-08-13 07:08:20 --> Loader Class Initialized
INFO - 2016-08-13 07:08:20 --> Helper loaded: url_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: html_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: form_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: file_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:08:20 --> Database Driver Class Initialized
INFO - 2016-08-13 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:08:20 --> Form Validation Class Initialized
INFO - 2016-08-13 07:08:20 --> Email Class Initialized
INFO - 2016-08-13 07:08:20 --> Controller Class Initialized
INFO - 2016-08-13 07:08:20 --> Config Class Initialized
INFO - 2016-08-13 07:08:20 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:08:20 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:08:20 --> Utf8 Class Initialized
INFO - 2016-08-13 07:08:20 --> URI Class Initialized
INFO - 2016-08-13 07:08:20 --> Router Class Initialized
INFO - 2016-08-13 07:08:20 --> Output Class Initialized
INFO - 2016-08-13 07:08:20 --> Security Class Initialized
DEBUG - 2016-08-13 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:08:20 --> Input Class Initialized
INFO - 2016-08-13 07:08:20 --> Language Class Initialized
INFO - 2016-08-13 07:08:20 --> Loader Class Initialized
INFO - 2016-08-13 07:08:20 --> Helper loaded: url_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: html_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: form_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: file_helper
INFO - 2016-08-13 07:08:20 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:08:20 --> Database Driver Class Initialized
INFO - 2016-08-13 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:08:20 --> Form Validation Class Initialized
INFO - 2016-08-13 07:08:20 --> Email Class Initialized
INFO - 2016-08-13 07:08:20 --> Controller Class Initialized
INFO - 2016-08-13 07:08:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:08:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:08:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:08:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:08:20 --> Final output sent to browser
DEBUG - 2016-08-13 07:08:20 --> Total execution time: 0.3073
INFO - 2016-08-13 07:09:18 --> Config Class Initialized
INFO - 2016-08-13 07:09:18 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:18 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:19 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:19 --> URI Class Initialized
INFO - 2016-08-13 07:09:19 --> Router Class Initialized
INFO - 2016-08-13 07:09:19 --> Output Class Initialized
INFO - 2016-08-13 07:09:19 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:19 --> Input Class Initialized
INFO - 2016-08-13 07:09:19 --> Language Class Initialized
INFO - 2016-08-13 07:09:19 --> Loader Class Initialized
INFO - 2016-08-13 07:09:19 --> Helper loaded: url_helper
INFO - 2016-08-13 07:09:19 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:09:19 --> Helper loaded: html_helper
INFO - 2016-08-13 07:09:19 --> Helper loaded: form_helper
INFO - 2016-08-13 07:09:19 --> Helper loaded: file_helper
INFO - 2016-08-13 07:09:19 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:09:19 --> Database Driver Class Initialized
INFO - 2016-08-13 07:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:09:19 --> Form Validation Class Initialized
INFO - 2016-08-13 07:09:19 --> Email Class Initialized
INFO - 2016-08-13 07:09:19 --> Controller Class Initialized
INFO - 2016-08-13 07:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:09:19 --> Final output sent to browser
DEBUG - 2016-08-13 07:09:19 --> Total execution time: 0.2893
INFO - 2016-08-13 07:09:24 --> Config Class Initialized
INFO - 2016-08-13 07:09:24 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:24 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:24 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:24 --> URI Class Initialized
INFO - 2016-08-13 07:09:24 --> Router Class Initialized
INFO - 2016-08-13 07:09:24 --> Output Class Initialized
INFO - 2016-08-13 07:09:24 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:24 --> Input Class Initialized
INFO - 2016-08-13 07:09:24 --> Language Class Initialized
ERROR - 2016-08-13 07:09:24 --> 404 Page Not Found: Authorize/add
INFO - 2016-08-13 07:09:28 --> Config Class Initialized
INFO - 2016-08-13 07:09:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:28 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:28 --> URI Class Initialized
INFO - 2016-08-13 07:09:28 --> Router Class Initialized
INFO - 2016-08-13 07:09:28 --> Output Class Initialized
INFO - 2016-08-13 07:09:28 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:28 --> Input Class Initialized
INFO - 2016-08-13 07:09:28 --> Language Class Initialized
INFO - 2016-08-13 07:09:28 --> Loader Class Initialized
INFO - 2016-08-13 07:09:28 --> Helper loaded: url_helper
INFO - 2016-08-13 07:09:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:09:28 --> Helper loaded: html_helper
INFO - 2016-08-13 07:09:28 --> Helper loaded: form_helper
INFO - 2016-08-13 07:09:28 --> Helper loaded: file_helper
INFO - 2016-08-13 07:09:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:09:28 --> Database Driver Class Initialized
INFO - 2016-08-13 07:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:09:28 --> Form Validation Class Initialized
INFO - 2016-08-13 07:09:28 --> Email Class Initialized
INFO - 2016-08-13 07:09:28 --> Controller Class Initialized
INFO - 2016-08-13 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:09:28 --> Final output sent to browser
DEBUG - 2016-08-13 07:09:28 --> Total execution time: 0.2841
INFO - 2016-08-13 07:09:32 --> Config Class Initialized
INFO - 2016-08-13 07:09:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:32 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:32 --> URI Class Initialized
INFO - 2016-08-13 07:09:32 --> Router Class Initialized
INFO - 2016-08-13 07:09:32 --> Output Class Initialized
INFO - 2016-08-13 07:09:32 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:32 --> Input Class Initialized
INFO - 2016-08-13 07:09:32 --> Language Class Initialized
INFO - 2016-08-13 07:09:32 --> Loader Class Initialized
INFO - 2016-08-13 07:09:32 --> Helper loaded: url_helper
INFO - 2016-08-13 07:09:32 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:09:32 --> Helper loaded: html_helper
INFO - 2016-08-13 07:09:32 --> Helper loaded: form_helper
INFO - 2016-08-13 07:09:32 --> Helper loaded: file_helper
INFO - 2016-08-13 07:09:32 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:09:32 --> Database Driver Class Initialized
INFO - 2016-08-13 07:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:09:32 --> Form Validation Class Initialized
INFO - 2016-08-13 07:09:32 --> Email Class Initialized
INFO - 2016-08-13 07:09:32 --> Controller Class Initialized
INFO - 2016-08-13 07:09:32 --> Model Class Initialized
INFO - 2016-08-13 07:09:33 --> Model Class Initialized
DEBUG - 2016-08-13 07:09:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:09:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:09:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:09:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-13 07:09:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:09:33 --> Final output sent to browser
DEBUG - 2016-08-13 07:09:33 --> Total execution time: 0.3123
INFO - 2016-08-13 07:09:43 --> Config Class Initialized
INFO - 2016-08-13 07:09:43 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:43 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:43 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:43 --> URI Class Initialized
INFO - 2016-08-13 07:09:43 --> Router Class Initialized
INFO - 2016-08-13 07:09:43 --> Output Class Initialized
INFO - 2016-08-13 07:09:43 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:43 --> Input Class Initialized
INFO - 2016-08-13 07:09:43 --> Language Class Initialized
INFO - 2016-08-13 07:09:43 --> Loader Class Initialized
INFO - 2016-08-13 07:09:43 --> Helper loaded: url_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: html_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: form_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: file_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:09:43 --> Database Driver Class Initialized
INFO - 2016-08-13 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:09:43 --> Form Validation Class Initialized
INFO - 2016-08-13 07:09:43 --> Email Class Initialized
INFO - 2016-08-13 07:09:43 --> Controller Class Initialized
INFO - 2016-08-13 07:09:43 --> Config Class Initialized
INFO - 2016-08-13 07:09:43 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:09:43 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:09:43 --> Utf8 Class Initialized
INFO - 2016-08-13 07:09:43 --> URI Class Initialized
INFO - 2016-08-13 07:09:43 --> Router Class Initialized
INFO - 2016-08-13 07:09:43 --> Output Class Initialized
INFO - 2016-08-13 07:09:43 --> Security Class Initialized
DEBUG - 2016-08-13 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:09:43 --> Input Class Initialized
INFO - 2016-08-13 07:09:43 --> Language Class Initialized
INFO - 2016-08-13 07:09:43 --> Loader Class Initialized
INFO - 2016-08-13 07:09:43 --> Helper loaded: url_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: html_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: form_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: file_helper
INFO - 2016-08-13 07:09:43 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:09:43 --> Database Driver Class Initialized
INFO - 2016-08-13 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:09:43 --> Form Validation Class Initialized
INFO - 2016-08-13 07:09:43 --> Email Class Initialized
INFO - 2016-08-13 07:09:43 --> Controller Class Initialized
INFO - 2016-08-13 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:09:43 --> Final output sent to browser
DEBUG - 2016-08-13 07:09:43 --> Total execution time: 0.3222
INFO - 2016-08-13 07:10:52 --> Config Class Initialized
INFO - 2016-08-13 07:10:52 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:10:52 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:10:52 --> Utf8 Class Initialized
INFO - 2016-08-13 07:10:52 --> URI Class Initialized
INFO - 2016-08-13 07:10:52 --> Router Class Initialized
INFO - 2016-08-13 07:10:52 --> Output Class Initialized
INFO - 2016-08-13 07:10:52 --> Security Class Initialized
DEBUG - 2016-08-13 07:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:10:52 --> Input Class Initialized
INFO - 2016-08-13 07:10:52 --> Language Class Initialized
INFO - 2016-08-13 07:10:52 --> Loader Class Initialized
INFO - 2016-08-13 07:10:52 --> Helper loaded: url_helper
INFO - 2016-08-13 07:10:52 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:10:52 --> Helper loaded: html_helper
INFO - 2016-08-13 07:10:52 --> Helper loaded: form_helper
INFO - 2016-08-13 07:10:52 --> Helper loaded: file_helper
INFO - 2016-08-13 07:10:52 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:10:52 --> Database Driver Class Initialized
INFO - 2016-08-13 07:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:10:52 --> Form Validation Class Initialized
INFO - 2016-08-13 07:10:52 --> Email Class Initialized
INFO - 2016-08-13 07:10:52 --> Controller Class Initialized
INFO - 2016-08-13 07:10:52 --> Model Class Initialized
INFO - 2016-08-13 07:10:52 --> Model Class Initialized
INFO - 2016-08-13 07:10:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:10:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:10:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 07:10:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:10:52 --> Final output sent to browser
DEBUG - 2016-08-13 07:10:52 --> Total execution time: 0.3154
INFO - 2016-08-13 07:12:27 --> Config Class Initialized
INFO - 2016-08-13 07:12:27 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:27 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:27 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:27 --> URI Class Initialized
INFO - 2016-08-13 07:12:27 --> Router Class Initialized
INFO - 2016-08-13 07:12:27 --> Output Class Initialized
INFO - 2016-08-13 07:12:27 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:28 --> Input Class Initialized
INFO - 2016-08-13 07:12:28 --> Language Class Initialized
INFO - 2016-08-13 07:12:28 --> Loader Class Initialized
INFO - 2016-08-13 07:12:28 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:28 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:28 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:28 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:28 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:28 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:28 --> Email Class Initialized
INFO - 2016-08-13 07:12:28 --> Controller Class Initialized
INFO - 2016-08-13 07:12:28 --> Model Class Initialized
INFO - 2016-08-13 07:12:28 --> Model Class Initialized
INFO - 2016-08-13 07:12:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 07:12:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:28 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:28 --> Total execution time: 0.3071
INFO - 2016-08-13 07:12:31 --> Config Class Initialized
INFO - 2016-08-13 07:12:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:31 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:31 --> URI Class Initialized
INFO - 2016-08-13 07:12:31 --> Router Class Initialized
INFO - 2016-08-13 07:12:31 --> Output Class Initialized
INFO - 2016-08-13 07:12:31 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:31 --> Input Class Initialized
INFO - 2016-08-13 07:12:31 --> Language Class Initialized
INFO - 2016-08-13 07:12:31 --> Loader Class Initialized
INFO - 2016-08-13 07:12:31 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:31 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:31 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:31 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:31 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:31 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:31 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:31 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:31 --> Email Class Initialized
INFO - 2016-08-13 07:12:31 --> Controller Class Initialized
INFO - 2016-08-13 07:12:31 --> Model Class Initialized
INFO - 2016-08-13 07:12:31 --> Model Class Initialized
INFO - 2016-08-13 07:12:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-13 07:12:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:31 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:31 --> Total execution time: 0.3017
INFO - 2016-08-13 07:12:36 --> Config Class Initialized
INFO - 2016-08-13 07:12:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:36 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:36 --> URI Class Initialized
DEBUG - 2016-08-13 07:12:36 --> No URI present. Default controller set.
INFO - 2016-08-13 07:12:36 --> Router Class Initialized
INFO - 2016-08-13 07:12:36 --> Output Class Initialized
INFO - 2016-08-13 07:12:36 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:37 --> Input Class Initialized
INFO - 2016-08-13 07:12:37 --> Language Class Initialized
INFO - 2016-08-13 07:12:37 --> Loader Class Initialized
INFO - 2016-08-13 07:12:37 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:37 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:37 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:37 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:37 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:37 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:37 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:37 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:37 --> Email Class Initialized
INFO - 2016-08-13 07:12:37 --> Controller Class Initialized
INFO - 2016-08-13 07:12:37 --> Model Class Initialized
INFO - 2016-08-13 07:12:37 --> Model Class Initialized
INFO - 2016-08-13 07:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-13 07:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:37 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:37 --> Total execution time: 0.3280
INFO - 2016-08-13 07:12:39 --> Config Class Initialized
INFO - 2016-08-13 07:12:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:40 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:40 --> URI Class Initialized
INFO - 2016-08-13 07:12:40 --> Router Class Initialized
INFO - 2016-08-13 07:12:40 --> Output Class Initialized
INFO - 2016-08-13 07:12:40 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:40 --> Input Class Initialized
INFO - 2016-08-13 07:12:40 --> Language Class Initialized
INFO - 2016-08-13 07:12:40 --> Loader Class Initialized
INFO - 2016-08-13 07:12:40 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:40 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:40 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:40 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:40 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:40 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:40 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:40 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:40 --> Email Class Initialized
INFO - 2016-08-13 07:12:40 --> Controller Class Initialized
INFO - 2016-08-13 07:12:40 --> Model Class Initialized
INFO - 2016-08-13 07:12:40 --> Model Class Initialized
INFO - 2016-08-13 07:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-13 07:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:40 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:40 --> Total execution time: 0.3177
INFO - 2016-08-13 07:12:41 --> Config Class Initialized
INFO - 2016-08-13 07:12:41 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:41 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:41 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:42 --> URI Class Initialized
DEBUG - 2016-08-13 07:12:42 --> No URI present. Default controller set.
INFO - 2016-08-13 07:12:42 --> Router Class Initialized
INFO - 2016-08-13 07:12:42 --> Output Class Initialized
INFO - 2016-08-13 07:12:42 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:42 --> Input Class Initialized
INFO - 2016-08-13 07:12:42 --> Language Class Initialized
INFO - 2016-08-13 07:12:42 --> Loader Class Initialized
INFO - 2016-08-13 07:12:42 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:42 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:42 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:42 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:42 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:42 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:42 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:42 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:42 --> Email Class Initialized
INFO - 2016-08-13 07:12:42 --> Controller Class Initialized
INFO - 2016-08-13 07:12:42 --> Model Class Initialized
INFO - 2016-08-13 07:12:42 --> Model Class Initialized
INFO - 2016-08-13 07:12:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-13 07:12:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:42 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:42 --> Total execution time: 0.3210
INFO - 2016-08-13 07:12:45 --> Config Class Initialized
INFO - 2016-08-13 07:12:45 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:45 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:45 --> URI Class Initialized
INFO - 2016-08-13 07:12:45 --> Router Class Initialized
INFO - 2016-08-13 07:12:45 --> Output Class Initialized
INFO - 2016-08-13 07:12:45 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:45 --> Input Class Initialized
INFO - 2016-08-13 07:12:45 --> Language Class Initialized
INFO - 2016-08-13 07:12:45 --> Loader Class Initialized
INFO - 2016-08-13 07:12:45 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:45 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:45 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:45 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:45 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:45 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:45 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:45 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:45 --> Email Class Initialized
INFO - 2016-08-13 07:12:45 --> Controller Class Initialized
INFO - 2016-08-13 07:12:45 --> Model Class Initialized
DEBUG - 2016-08-13 07:12:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:12:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-13 07:12:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:45 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:45 --> Total execution time: 0.3440
INFO - 2016-08-13 07:12:56 --> Config Class Initialized
INFO - 2016-08-13 07:12:56 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:12:56 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:12:56 --> Utf8 Class Initialized
INFO - 2016-08-13 07:12:56 --> URI Class Initialized
INFO - 2016-08-13 07:12:56 --> Router Class Initialized
INFO - 2016-08-13 07:12:56 --> Output Class Initialized
INFO - 2016-08-13 07:12:56 --> Security Class Initialized
DEBUG - 2016-08-13 07:12:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:12:56 --> Input Class Initialized
INFO - 2016-08-13 07:12:56 --> Language Class Initialized
INFO - 2016-08-13 07:12:56 --> Loader Class Initialized
INFO - 2016-08-13 07:12:56 --> Helper loaded: url_helper
INFO - 2016-08-13 07:12:56 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:12:56 --> Helper loaded: html_helper
INFO - 2016-08-13 07:12:56 --> Helper loaded: form_helper
INFO - 2016-08-13 07:12:57 --> Helper loaded: file_helper
INFO - 2016-08-13 07:12:57 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:12:57 --> Database Driver Class Initialized
INFO - 2016-08-13 07:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:12:57 --> Form Validation Class Initialized
INFO - 2016-08-13 07:12:57 --> Email Class Initialized
INFO - 2016-08-13 07:12:57 --> Controller Class Initialized
INFO - 2016-08-13 07:12:57 --> Model Class Initialized
DEBUG - 2016-08-13 07:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:12:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:12:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:12:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-13 07:12:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:12:57 --> Final output sent to browser
DEBUG - 2016-08-13 07:12:57 --> Total execution time: 0.3280
INFO - 2016-08-13 07:13:47 --> Config Class Initialized
INFO - 2016-08-13 07:13:47 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:13:47 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:13:47 --> Utf8 Class Initialized
INFO - 2016-08-13 07:13:47 --> URI Class Initialized
INFO - 2016-08-13 07:13:47 --> Router Class Initialized
INFO - 2016-08-13 07:13:47 --> Output Class Initialized
INFO - 2016-08-13 07:13:47 --> Security Class Initialized
DEBUG - 2016-08-13 07:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:13:48 --> Input Class Initialized
INFO - 2016-08-13 07:13:48 --> Language Class Initialized
INFO - 2016-08-13 07:13:48 --> Loader Class Initialized
INFO - 2016-08-13 07:13:48 --> Helper loaded: url_helper
INFO - 2016-08-13 07:13:48 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:13:48 --> Helper loaded: html_helper
INFO - 2016-08-13 07:13:48 --> Helper loaded: form_helper
INFO - 2016-08-13 07:13:48 --> Helper loaded: file_helper
INFO - 2016-08-13 07:13:48 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:13:48 --> Database Driver Class Initialized
INFO - 2016-08-13 07:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:13:48 --> Form Validation Class Initialized
INFO - 2016-08-13 07:13:48 --> Email Class Initialized
INFO - 2016-08-13 07:13:48 --> Controller Class Initialized
INFO - 2016-08-13 07:13:48 --> Model Class Initialized
INFO - 2016-08-13 07:13:48 --> Model Class Initialized
INFO - 2016-08-13 07:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-13 07:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:13:48 --> Final output sent to browser
DEBUG - 2016-08-13 07:13:48 --> Total execution time: 0.3506
INFO - 2016-08-13 07:13:56 --> Config Class Initialized
INFO - 2016-08-13 07:13:56 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:13:56 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:13:56 --> Utf8 Class Initialized
INFO - 2016-08-13 07:13:56 --> URI Class Initialized
INFO - 2016-08-13 07:13:56 --> Router Class Initialized
INFO - 2016-08-13 07:13:56 --> Output Class Initialized
INFO - 2016-08-13 07:13:56 --> Security Class Initialized
DEBUG - 2016-08-13 07:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:13:56 --> Input Class Initialized
INFO - 2016-08-13 07:13:56 --> Language Class Initialized
INFO - 2016-08-13 07:13:56 --> Loader Class Initialized
INFO - 2016-08-13 07:13:56 --> Helper loaded: url_helper
INFO - 2016-08-13 07:13:56 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:13:56 --> Helper loaded: html_helper
INFO - 2016-08-13 07:13:56 --> Helper loaded: form_helper
INFO - 2016-08-13 07:13:56 --> Helper loaded: file_helper
INFO - 2016-08-13 07:13:56 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:13:56 --> Database Driver Class Initialized
INFO - 2016-08-13 07:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:13:56 --> Form Validation Class Initialized
INFO - 2016-08-13 07:13:56 --> Email Class Initialized
INFO - 2016-08-13 07:13:56 --> Controller Class Initialized
INFO - 2016-08-13 07:13:56 --> Model Class Initialized
INFO - 2016-08-13 07:13:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:13:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:13:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 07:13:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:13:56 --> Final output sent to browser
DEBUG - 2016-08-13 07:13:56 --> Total execution time: 0.3134
INFO - 2016-08-13 07:13:57 --> Config Class Initialized
INFO - 2016-08-13 07:13:57 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:13:57 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:13:57 --> Utf8 Class Initialized
INFO - 2016-08-13 07:13:57 --> URI Class Initialized
INFO - 2016-08-13 07:13:57 --> Router Class Initialized
INFO - 2016-08-13 07:13:57 --> Output Class Initialized
INFO - 2016-08-13 07:13:57 --> Security Class Initialized
DEBUG - 2016-08-13 07:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:13:57 --> Input Class Initialized
INFO - 2016-08-13 07:13:57 --> Language Class Initialized
INFO - 2016-08-13 07:13:57 --> Loader Class Initialized
INFO - 2016-08-13 07:13:57 --> Helper loaded: url_helper
INFO - 2016-08-13 07:13:57 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:13:57 --> Helper loaded: html_helper
INFO - 2016-08-13 07:13:57 --> Helper loaded: form_helper
INFO - 2016-08-13 07:13:57 --> Helper loaded: file_helper
INFO - 2016-08-13 07:13:57 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:13:57 --> Database Driver Class Initialized
INFO - 2016-08-13 07:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:13:57 --> Form Validation Class Initialized
INFO - 2016-08-13 07:13:57 --> Email Class Initialized
INFO - 2016-08-13 07:13:57 --> Controller Class Initialized
INFO - 2016-08-13 07:13:57 --> Model Class Initialized
INFO - 2016-08-13 07:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 07:13:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:13:58 --> Final output sent to browser
DEBUG - 2016-08-13 07:13:58 --> Total execution time: 0.3193
INFO - 2016-08-13 07:15:13 --> Config Class Initialized
INFO - 2016-08-13 07:15:13 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:15:13 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:15:14 --> Utf8 Class Initialized
INFO - 2016-08-13 07:15:14 --> URI Class Initialized
INFO - 2016-08-13 07:15:14 --> Router Class Initialized
INFO - 2016-08-13 07:15:14 --> Output Class Initialized
INFO - 2016-08-13 07:15:14 --> Security Class Initialized
DEBUG - 2016-08-13 07:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:15:14 --> Input Class Initialized
INFO - 2016-08-13 07:15:14 --> Language Class Initialized
INFO - 2016-08-13 07:15:14 --> Loader Class Initialized
INFO - 2016-08-13 07:15:14 --> Helper loaded: url_helper
INFO - 2016-08-13 07:15:14 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:15:14 --> Helper loaded: html_helper
INFO - 2016-08-13 07:15:14 --> Helper loaded: form_helper
INFO - 2016-08-13 07:15:14 --> Helper loaded: file_helper
INFO - 2016-08-13 07:15:14 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:15:14 --> Database Driver Class Initialized
INFO - 2016-08-13 07:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:15:14 --> Form Validation Class Initialized
INFO - 2016-08-13 07:15:14 --> Email Class Initialized
INFO - 2016-08-13 07:15:14 --> Controller Class Initialized
INFO - 2016-08-13 07:15:14 --> Model Class Initialized
INFO - 2016-08-13 07:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 07:15:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:15:14 --> Final output sent to browser
DEBUG - 2016-08-13 07:15:14 --> Total execution time: 0.6737
INFO - 2016-08-13 07:15:43 --> Config Class Initialized
INFO - 2016-08-13 07:15:43 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:15:43 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:15:43 --> Utf8 Class Initialized
INFO - 2016-08-13 07:15:43 --> URI Class Initialized
INFO - 2016-08-13 07:15:43 --> Router Class Initialized
INFO - 2016-08-13 07:15:43 --> Output Class Initialized
INFO - 2016-08-13 07:15:43 --> Security Class Initialized
DEBUG - 2016-08-13 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:15:43 --> Input Class Initialized
INFO - 2016-08-13 07:15:43 --> Language Class Initialized
ERROR - 2016-08-13 07:15:43 --> 404 Page Not Found: Users/usrstate
INFO - 2016-08-13 07:15:55 --> Config Class Initialized
INFO - 2016-08-13 07:15:55 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:15:55 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:15:55 --> Utf8 Class Initialized
INFO - 2016-08-13 07:15:55 --> URI Class Initialized
INFO - 2016-08-13 07:15:55 --> Router Class Initialized
INFO - 2016-08-13 07:15:55 --> Output Class Initialized
INFO - 2016-08-13 07:15:55 --> Security Class Initialized
DEBUG - 2016-08-13 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:15:55 --> Input Class Initialized
INFO - 2016-08-13 07:15:55 --> Language Class Initialized
INFO - 2016-08-13 07:15:56 --> Loader Class Initialized
INFO - 2016-08-13 07:15:56 --> Helper loaded: url_helper
INFO - 2016-08-13 07:15:56 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:15:56 --> Helper loaded: html_helper
INFO - 2016-08-13 07:15:56 --> Helper loaded: form_helper
INFO - 2016-08-13 07:15:56 --> Helper loaded: file_helper
INFO - 2016-08-13 07:15:56 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:15:56 --> Database Driver Class Initialized
INFO - 2016-08-13 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:15:56 --> Form Validation Class Initialized
INFO - 2016-08-13 07:15:56 --> Email Class Initialized
INFO - 2016-08-13 07:15:56 --> Controller Class Initialized
INFO - 2016-08-13 07:15:56 --> Model Class Initialized
INFO - 2016-08-13 07:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 07:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:15:56 --> Final output sent to browser
DEBUG - 2016-08-13 07:15:56 --> Total execution time: 0.3177
INFO - 2016-08-13 07:16:06 --> Config Class Initialized
INFO - 2016-08-13 07:16:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:16:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:16:06 --> Utf8 Class Initialized
INFO - 2016-08-13 07:16:06 --> URI Class Initialized
INFO - 2016-08-13 07:16:06 --> Router Class Initialized
INFO - 2016-08-13 07:16:06 --> Output Class Initialized
INFO - 2016-08-13 07:16:06 --> Security Class Initialized
DEBUG - 2016-08-13 07:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:16:06 --> Input Class Initialized
INFO - 2016-08-13 07:16:06 --> Language Class Initialized
INFO - 2016-08-13 07:16:06 --> Loader Class Initialized
INFO - 2016-08-13 07:16:06 --> Helper loaded: url_helper
INFO - 2016-08-13 07:16:06 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:16:06 --> Helper loaded: html_helper
INFO - 2016-08-13 07:16:06 --> Helper loaded: form_helper
INFO - 2016-08-13 07:16:06 --> Helper loaded: file_helper
INFO - 2016-08-13 07:16:06 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:16:06 --> Database Driver Class Initialized
INFO - 2016-08-13 07:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:16:06 --> Form Validation Class Initialized
INFO - 2016-08-13 07:16:06 --> Email Class Initialized
INFO - 2016-08-13 07:16:06 --> Controller Class Initialized
DEBUG - 2016-08-13 07:16:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:16:06 --> Model Class Initialized
INFO - 2016-08-13 07:16:06 --> Model Class Initialized
INFO - 2016-08-13 07:16:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:16:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:16:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 07:16:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:16:07 --> Final output sent to browser
DEBUG - 2016-08-13 07:16:07 --> Total execution time: 0.5169
INFO - 2016-08-13 07:16:09 --> Config Class Initialized
INFO - 2016-08-13 07:16:09 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:16:09 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:16:09 --> Utf8 Class Initialized
INFO - 2016-08-13 07:16:09 --> URI Class Initialized
INFO - 2016-08-13 07:16:09 --> Router Class Initialized
INFO - 2016-08-13 07:16:09 --> Output Class Initialized
INFO - 2016-08-13 07:16:09 --> Security Class Initialized
DEBUG - 2016-08-13 07:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:16:09 --> Input Class Initialized
INFO - 2016-08-13 07:16:09 --> Language Class Initialized
INFO - 2016-08-13 07:16:09 --> Loader Class Initialized
INFO - 2016-08-13 07:16:09 --> Helper loaded: url_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: html_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: form_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: file_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:16:09 --> Database Driver Class Initialized
INFO - 2016-08-13 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:16:09 --> Form Validation Class Initialized
INFO - 2016-08-13 07:16:09 --> Email Class Initialized
INFO - 2016-08-13 07:16:09 --> Controller Class Initialized
INFO - 2016-08-13 07:16:09 --> Config Class Initialized
INFO - 2016-08-13 07:16:09 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:16:09 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:16:09 --> Utf8 Class Initialized
INFO - 2016-08-13 07:16:09 --> URI Class Initialized
INFO - 2016-08-13 07:16:09 --> Router Class Initialized
INFO - 2016-08-13 07:16:09 --> Output Class Initialized
INFO - 2016-08-13 07:16:09 --> Security Class Initialized
DEBUG - 2016-08-13 07:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:16:09 --> Input Class Initialized
INFO - 2016-08-13 07:16:09 --> Language Class Initialized
INFO - 2016-08-13 07:16:09 --> Loader Class Initialized
INFO - 2016-08-13 07:16:09 --> Helper loaded: url_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: html_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: form_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: file_helper
INFO - 2016-08-13 07:16:09 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:16:09 --> Database Driver Class Initialized
INFO - 2016-08-13 07:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:16:09 --> Form Validation Class Initialized
INFO - 2016-08-13 07:16:09 --> Email Class Initialized
INFO - 2016-08-13 07:16:09 --> Controller Class Initialized
INFO - 2016-08-13 07:16:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:16:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:16:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-13 07:16:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:16:09 --> Final output sent to browser
DEBUG - 2016-08-13 07:16:09 --> Total execution time: 0.3159
INFO - 2016-08-13 07:16:15 --> Config Class Initialized
INFO - 2016-08-13 07:16:15 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:16:15 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:16:15 --> Utf8 Class Initialized
INFO - 2016-08-13 07:16:15 --> URI Class Initialized
INFO - 2016-08-13 07:16:15 --> Router Class Initialized
INFO - 2016-08-13 07:16:15 --> Output Class Initialized
INFO - 2016-08-13 07:16:15 --> Security Class Initialized
DEBUG - 2016-08-13 07:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:16:15 --> Input Class Initialized
INFO - 2016-08-13 07:16:15 --> Language Class Initialized
INFO - 2016-08-13 07:16:15 --> Loader Class Initialized
INFO - 2016-08-13 07:16:15 --> Helper loaded: url_helper
INFO - 2016-08-13 07:16:15 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:16:15 --> Helper loaded: html_helper
INFO - 2016-08-13 07:16:15 --> Helper loaded: form_helper
INFO - 2016-08-13 07:16:15 --> Helper loaded: file_helper
INFO - 2016-08-13 07:16:15 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:16:15 --> Database Driver Class Initialized
INFO - 2016-08-13 07:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:16:15 --> Form Validation Class Initialized
INFO - 2016-08-13 07:16:15 --> Email Class Initialized
INFO - 2016-08-13 07:16:15 --> Controller Class Initialized
DEBUG - 2016-08-13 07:16:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:16:15 --> Model Class Initialized
INFO - 2016-08-13 07:16:15 --> Model Class Initialized
INFO - 2016-08-13 07:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 07:16:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:16:15 --> Final output sent to browser
DEBUG - 2016-08-13 07:16:15 --> Total execution time: 0.3706
INFO - 2016-08-13 07:17:07 --> Config Class Initialized
INFO - 2016-08-13 07:17:07 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:17:07 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:17:07 --> Utf8 Class Initialized
INFO - 2016-08-13 07:17:07 --> URI Class Initialized
INFO - 2016-08-13 07:17:07 --> Router Class Initialized
INFO - 2016-08-13 07:17:07 --> Output Class Initialized
INFO - 2016-08-13 07:17:07 --> Security Class Initialized
DEBUG - 2016-08-13 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:17:07 --> Input Class Initialized
INFO - 2016-08-13 07:17:08 --> Language Class Initialized
INFO - 2016-08-13 07:17:08 --> Loader Class Initialized
INFO - 2016-08-13 07:17:08 --> Helper loaded: url_helper
INFO - 2016-08-13 07:17:08 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:17:08 --> Helper loaded: html_helper
INFO - 2016-08-13 07:17:08 --> Helper loaded: form_helper
INFO - 2016-08-13 07:17:08 --> Helper loaded: file_helper
INFO - 2016-08-13 07:17:08 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:17:08 --> Database Driver Class Initialized
INFO - 2016-08-13 07:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:17:08 --> Form Validation Class Initialized
INFO - 2016-08-13 07:17:08 --> Email Class Initialized
INFO - 2016-08-13 07:17:08 --> Controller Class Initialized
INFO - 2016-08-13 07:17:08 --> Model Class Initialized
INFO - 2016-08-13 07:17:08 --> Model Class Initialized
DEBUG - 2016-08-13 07:17:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-13 07:17:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:17:08 --> Final output sent to browser
DEBUG - 2016-08-13 07:17:08 --> Total execution time: 0.7091
INFO - 2016-08-13 07:18:31 --> Config Class Initialized
INFO - 2016-08-13 07:18:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:18:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:18:31 --> Utf8 Class Initialized
INFO - 2016-08-13 07:18:31 --> URI Class Initialized
INFO - 2016-08-13 07:18:31 --> Router Class Initialized
INFO - 2016-08-13 07:18:31 --> Output Class Initialized
INFO - 2016-08-13 07:18:31 --> Security Class Initialized
DEBUG - 2016-08-13 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:18:31 --> Input Class Initialized
INFO - 2016-08-13 07:18:31 --> Language Class Initialized
INFO - 2016-08-13 07:18:31 --> Loader Class Initialized
INFO - 2016-08-13 07:18:31 --> Helper loaded: url_helper
INFO - 2016-08-13 07:18:31 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:18:31 --> Helper loaded: html_helper
INFO - 2016-08-13 07:18:31 --> Helper loaded: form_helper
INFO - 2016-08-13 07:18:31 --> Helper loaded: file_helper
INFO - 2016-08-13 07:18:31 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:18:31 --> Database Driver Class Initialized
INFO - 2016-08-13 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:18:31 --> Form Validation Class Initialized
INFO - 2016-08-13 07:18:31 --> Email Class Initialized
INFO - 2016-08-13 07:18:31 --> Controller Class Initialized
INFO - 2016-08-13 07:18:31 --> Model Class Initialized
INFO - 2016-08-13 07:18:31 --> Model Class Initialized
INFO - 2016-08-13 07:18:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:18:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:18:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 07:18:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:18:31 --> Final output sent to browser
DEBUG - 2016-08-13 07:18:31 --> Total execution time: 0.3290
INFO - 2016-08-13 07:18:35 --> Config Class Initialized
INFO - 2016-08-13 07:18:35 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:18:35 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:18:35 --> Utf8 Class Initialized
INFO - 2016-08-13 07:18:35 --> URI Class Initialized
INFO - 2016-08-13 07:18:35 --> Router Class Initialized
INFO - 2016-08-13 07:18:35 --> Output Class Initialized
INFO - 2016-08-13 07:18:35 --> Security Class Initialized
DEBUG - 2016-08-13 07:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:18:35 --> Input Class Initialized
INFO - 2016-08-13 07:18:35 --> Language Class Initialized
INFO - 2016-08-13 07:18:35 --> Loader Class Initialized
INFO - 2016-08-13 07:18:35 --> Helper loaded: url_helper
INFO - 2016-08-13 07:18:35 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:18:35 --> Helper loaded: html_helper
INFO - 2016-08-13 07:18:35 --> Helper loaded: form_helper
INFO - 2016-08-13 07:18:35 --> Helper loaded: file_helper
INFO - 2016-08-13 07:18:35 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:18:35 --> Database Driver Class Initialized
INFO - 2016-08-13 07:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:18:35 --> Form Validation Class Initialized
INFO - 2016-08-13 07:18:35 --> Email Class Initialized
INFO - 2016-08-13 07:18:35 --> Controller Class Initialized
INFO - 2016-08-13 07:18:35 --> Model Class Initialized
INFO - 2016-08-13 07:18:35 --> Model Class Initialized
INFO - 2016-08-13 07:18:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:18:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:18:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-13 07:18:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:18:36 --> Final output sent to browser
DEBUG - 2016-08-13 07:18:36 --> Total execution time: 0.3335
INFO - 2016-08-13 07:18:46 --> Config Class Initialized
INFO - 2016-08-13 07:18:46 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:18:46 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:18:46 --> Utf8 Class Initialized
INFO - 2016-08-13 07:18:46 --> URI Class Initialized
INFO - 2016-08-13 07:18:46 --> Router Class Initialized
INFO - 2016-08-13 07:18:46 --> Output Class Initialized
INFO - 2016-08-13 07:18:46 --> Security Class Initialized
DEBUG - 2016-08-13 07:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:18:46 --> Input Class Initialized
INFO - 2016-08-13 07:18:46 --> Language Class Initialized
INFO - 2016-08-13 07:18:46 --> Loader Class Initialized
INFO - 2016-08-13 07:18:46 --> Helper loaded: url_helper
INFO - 2016-08-13 07:18:47 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:18:47 --> Helper loaded: html_helper
INFO - 2016-08-13 07:18:47 --> Helper loaded: form_helper
INFO - 2016-08-13 07:18:47 --> Helper loaded: file_helper
INFO - 2016-08-13 07:18:47 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:18:47 --> Database Driver Class Initialized
INFO - 2016-08-13 07:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:18:47 --> Form Validation Class Initialized
INFO - 2016-08-13 07:18:47 --> Email Class Initialized
INFO - 2016-08-13 07:18:47 --> Controller Class Initialized
DEBUG - 2016-08-13 07:18:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:18:47 --> Model Class Initialized
INFO - 2016-08-13 07:18:47 --> Model Class Initialized
INFO - 2016-08-13 07:18:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:18:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:18:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 07:18:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:18:47 --> Final output sent to browser
DEBUG - 2016-08-13 07:18:47 --> Total execution time: 0.7283
INFO - 2016-08-13 07:18:59 --> Config Class Initialized
INFO - 2016-08-13 07:18:59 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:18:59 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:18:59 --> Utf8 Class Initialized
INFO - 2016-08-13 07:18:59 --> URI Class Initialized
INFO - 2016-08-13 07:18:59 --> Router Class Initialized
INFO - 2016-08-13 07:18:59 --> Output Class Initialized
INFO - 2016-08-13 07:18:59 --> Security Class Initialized
DEBUG - 2016-08-13 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:18:59 --> Input Class Initialized
INFO - 2016-08-13 07:18:59 --> Language Class Initialized
INFO - 2016-08-13 07:18:59 --> Loader Class Initialized
INFO - 2016-08-13 07:18:59 --> Helper loaded: url_helper
INFO - 2016-08-13 07:18:59 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:18:59 --> Helper loaded: html_helper
INFO - 2016-08-13 07:18:59 --> Helper loaded: form_helper
INFO - 2016-08-13 07:18:59 --> Helper loaded: file_helper
INFO - 2016-08-13 07:18:59 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:19:00 --> Database Driver Class Initialized
INFO - 2016-08-13 07:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:19:00 --> Form Validation Class Initialized
INFO - 2016-08-13 07:19:00 --> Email Class Initialized
INFO - 2016-08-13 07:19:00 --> Controller Class Initialized
INFO - 2016-08-13 07:19:00 --> Model Class Initialized
INFO - 2016-08-13 07:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 07:19:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:19:00 --> Final output sent to browser
DEBUG - 2016-08-13 07:19:00 --> Total execution time: 0.3307
INFO - 2016-08-13 07:19:02 --> Config Class Initialized
INFO - 2016-08-13 07:19:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:19:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:19:02 --> Utf8 Class Initialized
INFO - 2016-08-13 07:19:02 --> URI Class Initialized
INFO - 2016-08-13 07:19:02 --> Router Class Initialized
INFO - 2016-08-13 07:19:02 --> Output Class Initialized
INFO - 2016-08-13 07:19:02 --> Security Class Initialized
DEBUG - 2016-08-13 07:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:19:02 --> Input Class Initialized
INFO - 2016-08-13 07:19:02 --> Language Class Initialized
INFO - 2016-08-13 07:19:02 --> Loader Class Initialized
INFO - 2016-08-13 07:19:02 --> Helper loaded: url_helper
INFO - 2016-08-13 07:19:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:19:02 --> Helper loaded: html_helper
INFO - 2016-08-13 07:19:02 --> Helper loaded: form_helper
INFO - 2016-08-13 07:19:02 --> Helper loaded: file_helper
INFO - 2016-08-13 07:19:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:19:02 --> Database Driver Class Initialized
INFO - 2016-08-13 07:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:19:02 --> Form Validation Class Initialized
INFO - 2016-08-13 07:19:02 --> Email Class Initialized
INFO - 2016-08-13 07:19:02 --> Controller Class Initialized
INFO - 2016-08-13 07:19:02 --> Model Class Initialized
INFO - 2016-08-13 07:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 07:19:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:19:02 --> Final output sent to browser
DEBUG - 2016-08-13 07:19:02 --> Total execution time: 0.3588
INFO - 2016-08-13 07:19:04 --> Config Class Initialized
INFO - 2016-08-13 07:19:04 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:19:04 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:19:04 --> Utf8 Class Initialized
INFO - 2016-08-13 07:19:04 --> URI Class Initialized
INFO - 2016-08-13 07:19:04 --> Router Class Initialized
INFO - 2016-08-13 07:19:04 --> Output Class Initialized
INFO - 2016-08-13 07:19:04 --> Security Class Initialized
DEBUG - 2016-08-13 07:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:19:04 --> Input Class Initialized
INFO - 2016-08-13 07:19:04 --> Language Class Initialized
INFO - 2016-08-13 07:19:04 --> Loader Class Initialized
INFO - 2016-08-13 07:19:04 --> Helper loaded: url_helper
INFO - 2016-08-13 07:19:04 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:19:04 --> Helper loaded: html_helper
INFO - 2016-08-13 07:19:04 --> Helper loaded: form_helper
INFO - 2016-08-13 07:19:04 --> Helper loaded: file_helper
INFO - 2016-08-13 07:19:04 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:19:04 --> Database Driver Class Initialized
INFO - 2016-08-13 07:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:19:04 --> Form Validation Class Initialized
INFO - 2016-08-13 07:19:04 --> Email Class Initialized
INFO - 2016-08-13 07:19:04 --> Controller Class Initialized
DEBUG - 2016-08-13 07:19:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:19:04 --> Model Class Initialized
INFO - 2016-08-13 07:19:04 --> Model Class Initialized
INFO - 2016-08-13 07:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:19:05 --> Final output sent to browser
DEBUG - 2016-08-13 07:19:05 --> Total execution time: 0.3614
INFO - 2016-08-13 07:19:25 --> Config Class Initialized
INFO - 2016-08-13 07:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:19:25 --> Utf8 Class Initialized
INFO - 2016-08-13 07:19:25 --> URI Class Initialized
INFO - 2016-08-13 07:19:25 --> Router Class Initialized
INFO - 2016-08-13 07:19:25 --> Output Class Initialized
INFO - 2016-08-13 07:19:25 --> Security Class Initialized
DEBUG - 2016-08-13 07:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:19:25 --> Input Class Initialized
INFO - 2016-08-13 07:19:25 --> Language Class Initialized
INFO - 2016-08-13 07:19:25 --> Loader Class Initialized
INFO - 2016-08-13 07:19:25 --> Helper loaded: url_helper
INFO - 2016-08-13 07:19:25 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:19:25 --> Helper loaded: html_helper
INFO - 2016-08-13 07:19:25 --> Helper loaded: form_helper
INFO - 2016-08-13 07:19:25 --> Helper loaded: file_helper
INFO - 2016-08-13 07:19:25 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:19:25 --> Database Driver Class Initialized
INFO - 2016-08-13 07:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:19:25 --> Form Validation Class Initialized
INFO - 2016-08-13 07:19:25 --> Email Class Initialized
INFO - 2016-08-13 07:19:25 --> Controller Class Initialized
INFO - 2016-08-13 07:19:25 --> Model Class Initialized
INFO - 2016-08-13 07:19:25 --> Model Class Initialized
INFO - 2016-08-13 07:19:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:19:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:19:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 07:19:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:19:25 --> Final output sent to browser
DEBUG - 2016-08-13 07:19:25 --> Total execution time: 0.3471
INFO - 2016-08-13 07:19:28 --> Config Class Initialized
INFO - 2016-08-13 07:19:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:19:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:19:28 --> Utf8 Class Initialized
INFO - 2016-08-13 07:19:28 --> URI Class Initialized
INFO - 2016-08-13 07:19:28 --> Router Class Initialized
INFO - 2016-08-13 07:19:28 --> Output Class Initialized
INFO - 2016-08-13 07:19:28 --> Security Class Initialized
DEBUG - 2016-08-13 07:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:19:28 --> Input Class Initialized
INFO - 2016-08-13 07:19:28 --> Language Class Initialized
INFO - 2016-08-13 07:19:28 --> Loader Class Initialized
INFO - 2016-08-13 07:19:28 --> Helper loaded: url_helper
INFO - 2016-08-13 07:19:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:19:28 --> Helper loaded: html_helper
INFO - 2016-08-13 07:19:28 --> Helper loaded: form_helper
INFO - 2016-08-13 07:19:28 --> Helper loaded: file_helper
INFO - 2016-08-13 07:19:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:19:28 --> Database Driver Class Initialized
INFO - 2016-08-13 07:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:19:28 --> Form Validation Class Initialized
INFO - 2016-08-13 07:19:28 --> Email Class Initialized
INFO - 2016-08-13 07:19:28 --> Controller Class Initialized
INFO - 2016-08-13 07:19:28 --> Model Class Initialized
INFO - 2016-08-13 07:19:28 --> Model Class Initialized
INFO - 2016-08-13 07:19:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:19:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-13 07:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:19:29 --> Final output sent to browser
DEBUG - 2016-08-13 07:19:29 --> Total execution time: 0.3352
INFO - 2016-08-13 07:20:28 --> Config Class Initialized
INFO - 2016-08-13 07:20:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:20:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:20:28 --> Utf8 Class Initialized
INFO - 2016-08-13 07:20:28 --> URI Class Initialized
INFO - 2016-08-13 07:20:28 --> Router Class Initialized
INFO - 2016-08-13 07:20:28 --> Output Class Initialized
INFO - 2016-08-13 07:20:28 --> Security Class Initialized
DEBUG - 2016-08-13 07:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:20:28 --> Input Class Initialized
INFO - 2016-08-13 07:20:28 --> Language Class Initialized
INFO - 2016-08-13 07:20:28 --> Loader Class Initialized
INFO - 2016-08-13 07:20:28 --> Helper loaded: url_helper
INFO - 2016-08-13 07:20:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:20:28 --> Helper loaded: html_helper
INFO - 2016-08-13 07:20:28 --> Helper loaded: form_helper
INFO - 2016-08-13 07:20:28 --> Helper loaded: file_helper
INFO - 2016-08-13 07:20:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:20:28 --> Database Driver Class Initialized
INFO - 2016-08-13 07:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:20:28 --> Form Validation Class Initialized
INFO - 2016-08-13 07:20:28 --> Email Class Initialized
INFO - 2016-08-13 07:20:28 --> Controller Class Initialized
INFO - 2016-08-13 07:20:28 --> Model Class Initialized
INFO - 2016-08-13 07:20:28 --> Model Class Initialized
INFO - 2016-08-13 07:20:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:20:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:20:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 07:20:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:20:28 --> Final output sent to browser
DEBUG - 2016-08-13 07:20:28 --> Total execution time: 0.3695
INFO - 2016-08-13 07:20:31 --> Config Class Initialized
INFO - 2016-08-13 07:20:31 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:20:31 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:20:31 --> Utf8 Class Initialized
INFO - 2016-08-13 07:20:31 --> URI Class Initialized
INFO - 2016-08-13 07:20:31 --> Router Class Initialized
INFO - 2016-08-13 07:20:31 --> Output Class Initialized
INFO - 2016-08-13 07:20:31 --> Security Class Initialized
DEBUG - 2016-08-13 07:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:20:31 --> Input Class Initialized
INFO - 2016-08-13 07:20:31 --> Language Class Initialized
INFO - 2016-08-13 07:20:31 --> Loader Class Initialized
INFO - 2016-08-13 07:20:31 --> Helper loaded: url_helper
INFO - 2016-08-13 07:20:31 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:20:31 --> Helper loaded: html_helper
INFO - 2016-08-13 07:20:31 --> Helper loaded: form_helper
INFO - 2016-08-13 07:20:31 --> Helper loaded: file_helper
INFO - 2016-08-13 07:20:31 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:20:31 --> Database Driver Class Initialized
INFO - 2016-08-13 07:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:20:31 --> Form Validation Class Initialized
INFO - 2016-08-13 07:20:31 --> Email Class Initialized
INFO - 2016-08-13 07:20:31 --> Controller Class Initialized
INFO - 2016-08-13 07:20:31 --> Model Class Initialized
INFO - 2016-08-13 07:20:31 --> Model Class Initialized
INFO - 2016-08-13 07:20:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:20:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:20:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-13 07:20:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:20:31 --> Final output sent to browser
DEBUG - 2016-08-13 07:20:31 --> Total execution time: 0.3757
INFO - 2016-08-13 07:20:55 --> Config Class Initialized
INFO - 2016-08-13 07:20:55 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:20:55 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:20:55 --> Utf8 Class Initialized
INFO - 2016-08-13 07:20:55 --> URI Class Initialized
INFO - 2016-08-13 07:20:55 --> Router Class Initialized
INFO - 2016-08-13 07:20:55 --> Output Class Initialized
INFO - 2016-08-13 07:20:55 --> Security Class Initialized
DEBUG - 2016-08-13 07:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:20:55 --> Input Class Initialized
INFO - 2016-08-13 07:20:55 --> Language Class Initialized
INFO - 2016-08-13 07:20:55 --> Loader Class Initialized
INFO - 2016-08-13 07:20:55 --> Helper loaded: url_helper
INFO - 2016-08-13 07:20:55 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:20:55 --> Helper loaded: html_helper
INFO - 2016-08-13 07:20:55 --> Helper loaded: form_helper
INFO - 2016-08-13 07:20:55 --> Helper loaded: file_helper
INFO - 2016-08-13 07:20:55 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:20:55 --> Database Driver Class Initialized
INFO - 2016-08-13 07:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:20:55 --> Form Validation Class Initialized
INFO - 2016-08-13 07:20:55 --> Email Class Initialized
INFO - 2016-08-13 07:20:55 --> Controller Class Initialized
DEBUG - 2016-08-13 07:20:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:20:55 --> Model Class Initialized
INFO - 2016-08-13 07:20:55 --> Model Class Initialized
INFO - 2016-08-13 07:20:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:20:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:20:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 07:20:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:20:55 --> Final output sent to browser
DEBUG - 2016-08-13 07:20:55 --> Total execution time: 0.3869
INFO - 2016-08-13 07:26:19 --> Config Class Initialized
INFO - 2016-08-13 07:26:19 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:26:19 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:26:19 --> Utf8 Class Initialized
INFO - 2016-08-13 07:26:19 --> URI Class Initialized
INFO - 2016-08-13 07:26:19 --> Router Class Initialized
INFO - 2016-08-13 07:26:19 --> Output Class Initialized
INFO - 2016-08-13 07:26:19 --> Security Class Initialized
DEBUG - 2016-08-13 07:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:26:19 --> Input Class Initialized
INFO - 2016-08-13 07:26:20 --> Language Class Initialized
INFO - 2016-08-13 07:26:20 --> Loader Class Initialized
INFO - 2016-08-13 07:26:20 --> Helper loaded: url_helper
INFO - 2016-08-13 07:26:20 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:26:20 --> Helper loaded: html_helper
INFO - 2016-08-13 07:26:20 --> Helper loaded: form_helper
INFO - 2016-08-13 07:26:20 --> Helper loaded: file_helper
INFO - 2016-08-13 07:26:20 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:26:20 --> Database Driver Class Initialized
INFO - 2016-08-13 07:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:26:20 --> Form Validation Class Initialized
INFO - 2016-08-13 07:26:20 --> Email Class Initialized
INFO - 2016-08-13 07:26:20 --> Controller Class Initialized
DEBUG - 2016-08-13 07:26:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:26:20 --> Model Class Initialized
INFO - 2016-08-13 07:26:20 --> Model Class Initialized
INFO - 2016-08-13 07:26:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:26:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:26:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:26:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:26:20 --> Final output sent to browser
DEBUG - 2016-08-13 07:26:20 --> Total execution time: 0.3964
INFO - 2016-08-13 07:26:22 --> Config Class Initialized
INFO - 2016-08-13 07:26:22 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:26:22 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:26:22 --> Utf8 Class Initialized
INFO - 2016-08-13 07:26:22 --> URI Class Initialized
INFO - 2016-08-13 07:26:22 --> Router Class Initialized
INFO - 2016-08-13 07:26:22 --> Output Class Initialized
INFO - 2016-08-13 07:26:22 --> Security Class Initialized
DEBUG - 2016-08-13 07:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:26:22 --> Input Class Initialized
INFO - 2016-08-13 07:26:22 --> Language Class Initialized
INFO - 2016-08-13 07:26:22 --> Loader Class Initialized
INFO - 2016-08-13 07:26:22 --> Helper loaded: url_helper
INFO - 2016-08-13 07:26:22 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:26:22 --> Helper loaded: html_helper
INFO - 2016-08-13 07:26:22 --> Helper loaded: form_helper
INFO - 2016-08-13 07:26:22 --> Helper loaded: file_helper
INFO - 2016-08-13 07:26:22 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:26:22 --> Database Driver Class Initialized
INFO - 2016-08-13 07:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:26:22 --> Form Validation Class Initialized
INFO - 2016-08-13 07:26:22 --> Email Class Initialized
INFO - 2016-08-13 07:26:22 --> Controller Class Initialized
DEBUG - 2016-08-13 07:26:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:26:22 --> Model Class Initialized
INFO - 2016-08-13 07:26:22 --> Model Class Initialized
INFO - 2016-08-13 07:26:22 --> Model Class Initialized
INFO - 2016-08-13 07:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-13 07:26:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:26:22 --> Final output sent to browser
DEBUG - 2016-08-13 07:26:22 --> Total execution time: 0.3960
INFO - 2016-08-13 07:26:25 --> Config Class Initialized
INFO - 2016-08-13 07:26:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:26:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:26:25 --> Utf8 Class Initialized
INFO - 2016-08-13 07:26:25 --> URI Class Initialized
INFO - 2016-08-13 07:26:25 --> Router Class Initialized
INFO - 2016-08-13 07:26:25 --> Output Class Initialized
INFO - 2016-08-13 07:26:25 --> Security Class Initialized
DEBUG - 2016-08-13 07:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:26:26 --> Input Class Initialized
INFO - 2016-08-13 07:26:26 --> Language Class Initialized
INFO - 2016-08-13 07:26:26 --> Loader Class Initialized
INFO - 2016-08-13 07:26:26 --> Helper loaded: url_helper
INFO - 2016-08-13 07:26:26 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:26:26 --> Helper loaded: html_helper
INFO - 2016-08-13 07:26:26 --> Helper loaded: form_helper
INFO - 2016-08-13 07:26:26 --> Helper loaded: file_helper
INFO - 2016-08-13 07:26:26 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:26:26 --> Database Driver Class Initialized
INFO - 2016-08-13 07:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:26:26 --> Form Validation Class Initialized
INFO - 2016-08-13 07:26:26 --> Email Class Initialized
INFO - 2016-08-13 07:26:26 --> Controller Class Initialized
DEBUG - 2016-08-13 07:26:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:26:26 --> Model Class Initialized
INFO - 2016-08-13 07:26:26 --> Model Class Initialized
INFO - 2016-08-13 07:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:26:26 --> Final output sent to browser
DEBUG - 2016-08-13 07:26:26 --> Total execution time: 0.3617
INFO - 2016-08-13 07:28:32 --> Config Class Initialized
INFO - 2016-08-13 07:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:28:32 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:28:32 --> Utf8 Class Initialized
INFO - 2016-08-13 07:28:32 --> URI Class Initialized
INFO - 2016-08-13 07:28:32 --> Router Class Initialized
INFO - 2016-08-13 07:28:32 --> Output Class Initialized
INFO - 2016-08-13 07:28:32 --> Security Class Initialized
DEBUG - 2016-08-13 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:28:32 --> Input Class Initialized
INFO - 2016-08-13 07:28:32 --> Language Class Initialized
INFO - 2016-08-13 07:28:32 --> Loader Class Initialized
INFO - 2016-08-13 07:28:32 --> Helper loaded: url_helper
INFO - 2016-08-13 07:28:32 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:28:32 --> Helper loaded: html_helper
INFO - 2016-08-13 07:28:32 --> Helper loaded: form_helper
INFO - 2016-08-13 07:28:32 --> Helper loaded: file_helper
INFO - 2016-08-13 07:28:32 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:28:32 --> Database Driver Class Initialized
INFO - 2016-08-13 07:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:28:32 --> Form Validation Class Initialized
INFO - 2016-08-13 07:28:32 --> Email Class Initialized
INFO - 2016-08-13 07:28:32 --> Controller Class Initialized
DEBUG - 2016-08-13 07:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:28:32 --> Model Class Initialized
INFO - 2016-08-13 07:28:32 --> Model Class Initialized
INFO - 2016-08-13 07:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:28:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:28:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:28:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:28:33 --> Final output sent to browser
DEBUG - 2016-08-13 07:28:33 --> Total execution time: 0.3986
INFO - 2016-08-13 07:28:40 --> Config Class Initialized
INFO - 2016-08-13 07:28:40 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:28:40 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:28:40 --> Utf8 Class Initialized
INFO - 2016-08-13 07:28:40 --> URI Class Initialized
INFO - 2016-08-13 07:28:40 --> Router Class Initialized
INFO - 2016-08-13 07:28:40 --> Output Class Initialized
INFO - 2016-08-13 07:28:40 --> Security Class Initialized
DEBUG - 2016-08-13 07:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:28:40 --> Input Class Initialized
INFO - 2016-08-13 07:28:40 --> Language Class Initialized
INFO - 2016-08-13 07:28:40 --> Loader Class Initialized
INFO - 2016-08-13 07:28:40 --> Helper loaded: url_helper
INFO - 2016-08-13 07:28:40 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:28:40 --> Helper loaded: html_helper
INFO - 2016-08-13 07:28:40 --> Helper loaded: form_helper
INFO - 2016-08-13 07:28:40 --> Helper loaded: file_helper
INFO - 2016-08-13 07:28:40 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:28:40 --> Database Driver Class Initialized
INFO - 2016-08-13 07:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:28:40 --> Form Validation Class Initialized
INFO - 2016-08-13 07:28:40 --> Email Class Initialized
INFO - 2016-08-13 07:28:40 --> Controller Class Initialized
DEBUG - 2016-08-13 07:28:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:28:40 --> Model Class Initialized
INFO - 2016-08-13 07:28:40 --> Model Class Initialized
INFO - 2016-08-13 07:28:40 --> Model Class Initialized
INFO - 2016-08-13 07:28:40 --> Model Class Initialized
INFO - 2016-08-13 07:28:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:28:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:28:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:28:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:28:40 --> Final output sent to browser
DEBUG - 2016-08-13 07:28:40 --> Total execution time: 0.3855
INFO - 2016-08-13 07:29:16 --> Config Class Initialized
INFO - 2016-08-13 07:29:16 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:16 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:16 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:16 --> URI Class Initialized
INFO - 2016-08-13 07:29:16 --> Router Class Initialized
INFO - 2016-08-13 07:29:16 --> Output Class Initialized
INFO - 2016-08-13 07:29:16 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:16 --> Input Class Initialized
INFO - 2016-08-13 07:29:16 --> Language Class Initialized
INFO - 2016-08-13 07:29:16 --> Loader Class Initialized
INFO - 2016-08-13 07:29:16 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:16 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:16 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:16 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:16 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:16 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:16 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:16 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:17 --> Email Class Initialized
INFO - 2016-08-13 07:29:17 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:17 --> Config Class Initialized
INFO - 2016-08-13 07:29:17 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:17 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:17 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:17 --> URI Class Initialized
INFO - 2016-08-13 07:29:17 --> Router Class Initialized
INFO - 2016-08-13 07:29:17 --> Output Class Initialized
INFO - 2016-08-13 07:29:17 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:17 --> Input Class Initialized
INFO - 2016-08-13 07:29:17 --> Language Class Initialized
INFO - 2016-08-13 07:29:17 --> Loader Class Initialized
INFO - 2016-08-13 07:29:17 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:17 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:17 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:17 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:17 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:17 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:17 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:17 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:17 --> Email Class Initialized
INFO - 2016-08-13 07:29:17 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> Model Class Initialized
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:29:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:17 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:17 --> Total execution time: 0.3806
INFO - 2016-08-13 07:29:27 --> Config Class Initialized
INFO - 2016-08-13 07:29:27 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:27 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:27 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:27 --> URI Class Initialized
INFO - 2016-08-13 07:29:27 --> Router Class Initialized
INFO - 2016-08-13 07:29:27 --> Output Class Initialized
INFO - 2016-08-13 07:29:27 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:27 --> Input Class Initialized
INFO - 2016-08-13 07:29:27 --> Language Class Initialized
INFO - 2016-08-13 07:29:27 --> Loader Class Initialized
INFO - 2016-08-13 07:29:27 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:27 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:27 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:27 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:27 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:27 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:27 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:27 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:27 --> Email Class Initialized
INFO - 2016-08-13 07:29:27 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:27 --> Model Class Initialized
INFO - 2016-08-13 07:29:27 --> Model Class Initialized
INFO - 2016-08-13 07:29:27 --> Model Class Initialized
INFO - 2016-08-13 07:29:27 --> Model Class Initialized
INFO - 2016-08-13 07:29:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:29:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:28 --> Config Class Initialized
INFO - 2016-08-13 07:29:28 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:28 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:28 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:28 --> URI Class Initialized
INFO - 2016-08-13 07:29:28 --> Router Class Initialized
INFO - 2016-08-13 07:29:28 --> Output Class Initialized
INFO - 2016-08-13 07:29:28 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:28 --> Input Class Initialized
INFO - 2016-08-13 07:29:28 --> Language Class Initialized
INFO - 2016-08-13 07:29:28 --> Loader Class Initialized
INFO - 2016-08-13 07:29:28 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:28 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:28 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:28 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:28 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:28 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:28 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:28 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:28 --> Email Class Initialized
INFO - 2016-08-13 07:29:28 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:28 --> Model Class Initialized
INFO - 2016-08-13 07:29:28 --> Model Class Initialized
INFO - 2016-08-13 07:29:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-13 07:29:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:28 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:28 --> Total execution time: 0.4695
INFO - 2016-08-13 07:29:44 --> Config Class Initialized
INFO - 2016-08-13 07:29:44 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:44 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:44 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:44 --> URI Class Initialized
INFO - 2016-08-13 07:29:44 --> Router Class Initialized
INFO - 2016-08-13 07:29:45 --> Output Class Initialized
INFO - 2016-08-13 07:29:45 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:45 --> Input Class Initialized
INFO - 2016-08-13 07:29:45 --> Language Class Initialized
INFO - 2016-08-13 07:29:45 --> Loader Class Initialized
INFO - 2016-08-13 07:29:45 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:45 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:45 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:45 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:45 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:45 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:45 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:45 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:45 --> Email Class Initialized
INFO - 2016-08-13 07:29:45 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:45 --> Model Class Initialized
INFO - 2016-08-13 07:29:45 --> Model Class Initialized
INFO - 2016-08-13 07:29:45 --> Model Class Initialized
INFO - 2016-08-13 07:29:45 --> Model Class Initialized
INFO - 2016-08-13 07:29:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:29:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:45 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:45 --> Total execution time: 0.3921
INFO - 2016-08-13 07:29:48 --> Config Class Initialized
INFO - 2016-08-13 07:29:48 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:48 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:48 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:48 --> URI Class Initialized
INFO - 2016-08-13 07:29:48 --> Router Class Initialized
INFO - 2016-08-13 07:29:48 --> Output Class Initialized
INFO - 2016-08-13 07:29:48 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:48 --> Input Class Initialized
INFO - 2016-08-13 07:29:48 --> Language Class Initialized
INFO - 2016-08-13 07:29:48 --> Loader Class Initialized
INFO - 2016-08-13 07:29:48 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:48 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:48 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:48 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:48 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:48 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:48 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:48 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:48 --> Email Class Initialized
INFO - 2016-08-13 07:29:48 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:48 --> Model Class Initialized
INFO - 2016-08-13 07:29:48 --> Model Class Initialized
INFO - 2016-08-13 07:29:48 --> Model Class Initialized
INFO - 2016-08-13 07:29:48 --> Model Class Initialized
INFO - 2016-08-13 07:29:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-13 07:29:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:48 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:48 --> Total execution time: 0.4012
INFO - 2016-08-13 07:29:51 --> Config Class Initialized
INFO - 2016-08-13 07:29:51 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:51 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:51 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:51 --> URI Class Initialized
INFO - 2016-08-13 07:29:51 --> Router Class Initialized
INFO - 2016-08-13 07:29:51 --> Output Class Initialized
INFO - 2016-08-13 07:29:51 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:51 --> Input Class Initialized
INFO - 2016-08-13 07:29:51 --> Language Class Initialized
INFO - 2016-08-13 07:29:51 --> Loader Class Initialized
INFO - 2016-08-13 07:29:52 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:52 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:52 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:52 --> Email Class Initialized
INFO - 2016-08-13 07:29:52 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:52 --> Model Class Initialized
INFO - 2016-08-13 07:29:52 --> Model Class Initialized
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:52 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:52 --> Total execution time: 0.3781
INFO - 2016-08-13 07:29:52 --> Config Class Initialized
INFO - 2016-08-13 07:29:52 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:52 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:52 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:52 --> URI Class Initialized
INFO - 2016-08-13 07:29:52 --> Router Class Initialized
INFO - 2016-08-13 07:29:52 --> Output Class Initialized
INFO - 2016-08-13 07:29:52 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:52 --> Input Class Initialized
INFO - 2016-08-13 07:29:52 --> Language Class Initialized
INFO - 2016-08-13 07:29:52 --> Loader Class Initialized
INFO - 2016-08-13 07:29:52 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:52 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:52 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:52 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:52 --> Email Class Initialized
INFO - 2016-08-13 07:29:52 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:52 --> Model Class Initialized
INFO - 2016-08-13 07:29:52 --> Model Class Initialized
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 07:29:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 07:29:52 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:52 --> Total execution time: 0.3749
INFO - 2016-08-13 07:29:55 --> Config Class Initialized
INFO - 2016-08-13 07:29:56 --> Hooks Class Initialized
DEBUG - 2016-08-13 07:29:56 --> UTF-8 Support Enabled
INFO - 2016-08-13 07:29:56 --> Utf8 Class Initialized
INFO - 2016-08-13 07:29:56 --> URI Class Initialized
INFO - 2016-08-13 07:29:56 --> Router Class Initialized
INFO - 2016-08-13 07:29:56 --> Output Class Initialized
INFO - 2016-08-13 07:29:56 --> Security Class Initialized
DEBUG - 2016-08-13 07:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 07:29:56 --> Input Class Initialized
INFO - 2016-08-13 07:29:56 --> Language Class Initialized
INFO - 2016-08-13 07:29:56 --> Loader Class Initialized
INFO - 2016-08-13 07:29:56 --> Helper loaded: url_helper
INFO - 2016-08-13 07:29:56 --> Helper loaded: utils_helper
INFO - 2016-08-13 07:29:56 --> Helper loaded: html_helper
INFO - 2016-08-13 07:29:56 --> Helper loaded: form_helper
INFO - 2016-08-13 07:29:56 --> Helper loaded: file_helper
INFO - 2016-08-13 07:29:56 --> Helper loaded: myemail_helper
INFO - 2016-08-13 07:29:56 --> Database Driver Class Initialized
INFO - 2016-08-13 07:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 07:29:56 --> Form Validation Class Initialized
INFO - 2016-08-13 07:29:56 --> Email Class Initialized
INFO - 2016-08-13 07:29:56 --> Controller Class Initialized
DEBUG - 2016-08-13 07:29:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 07:29:56 --> Model Class Initialized
INFO - 2016-08-13 07:29:56 --> Model Class Initialized
INFO - 2016-08-13 07:29:56 --> Final output sent to browser
DEBUG - 2016-08-13 07:29:56 --> Total execution time: 0.6818
INFO - 2016-08-13 08:04:33 --> Config Class Initialized
INFO - 2016-08-13 08:04:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:04:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:04:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:04:33 --> URI Class Initialized
INFO - 2016-08-13 08:04:33 --> Router Class Initialized
INFO - 2016-08-13 08:04:33 --> Output Class Initialized
INFO - 2016-08-13 08:04:33 --> Security Class Initialized
DEBUG - 2016-08-13 08:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:04:33 --> Input Class Initialized
INFO - 2016-08-13 08:04:33 --> Language Class Initialized
INFO - 2016-08-13 08:04:33 --> Loader Class Initialized
INFO - 2016-08-13 08:04:33 --> Helper loaded: url_helper
INFO - 2016-08-13 08:04:34 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:04:34 --> Helper loaded: html_helper
INFO - 2016-08-13 08:04:34 --> Helper loaded: form_helper
INFO - 2016-08-13 08:04:34 --> Helper loaded: file_helper
INFO - 2016-08-13 08:04:34 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:04:34 --> Database Driver Class Initialized
INFO - 2016-08-13 08:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:04:34 --> Form Validation Class Initialized
INFO - 2016-08-13 08:04:34 --> Email Class Initialized
INFO - 2016-08-13 08:04:34 --> Controller Class Initialized
INFO - 2016-08-13 08:04:34 --> Model Class Initialized
DEBUG - 2016-08-13 08:04:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-13 08:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:04:34 --> Final output sent to browser
DEBUG - 2016-08-13 08:04:34 --> Total execution time: 0.3624
INFO - 2016-08-13 08:04:38 --> Config Class Initialized
INFO - 2016-08-13 08:04:38 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:04:38 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:04:38 --> Utf8 Class Initialized
INFO - 2016-08-13 08:04:38 --> URI Class Initialized
INFO - 2016-08-13 08:04:38 --> Router Class Initialized
INFO - 2016-08-13 08:04:38 --> Output Class Initialized
INFO - 2016-08-13 08:04:38 --> Security Class Initialized
DEBUG - 2016-08-13 08:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:04:38 --> Input Class Initialized
INFO - 2016-08-13 08:04:38 --> Language Class Initialized
INFO - 2016-08-13 08:04:38 --> Loader Class Initialized
INFO - 2016-08-13 08:04:38 --> Helper loaded: url_helper
INFO - 2016-08-13 08:04:38 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:04:38 --> Helper loaded: html_helper
INFO - 2016-08-13 08:04:38 --> Helper loaded: form_helper
INFO - 2016-08-13 08:04:38 --> Helper loaded: file_helper
INFO - 2016-08-13 08:04:38 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:04:38 --> Database Driver Class Initialized
INFO - 2016-08-13 08:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:04:38 --> Form Validation Class Initialized
INFO - 2016-08-13 08:04:38 --> Email Class Initialized
INFO - 2016-08-13 08:04:38 --> Controller Class Initialized
INFO - 2016-08-13 08:04:38 --> Model Class Initialized
DEBUG - 2016-08-13 08:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-13 08:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:04:38 --> Final output sent to browser
DEBUG - 2016-08-13 08:04:38 --> Total execution time: 0.3754
INFO - 2016-08-13 08:05:06 --> Config Class Initialized
INFO - 2016-08-13 08:05:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:06 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:06 --> URI Class Initialized
INFO - 2016-08-13 08:05:06 --> Router Class Initialized
INFO - 2016-08-13 08:05:06 --> Output Class Initialized
INFO - 2016-08-13 08:05:06 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:06 --> Input Class Initialized
INFO - 2016-08-13 08:05:06 --> Language Class Initialized
INFO - 2016-08-13 08:05:06 --> Loader Class Initialized
INFO - 2016-08-13 08:05:06 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:06 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:06 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:06 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:06 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:06 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:06 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:06 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:06 --> Email Class Initialized
INFO - 2016-08-13 08:05:06 --> Controller Class Initialized
INFO - 2016-08-13 08:05:06 --> Model Class Initialized
INFO - 2016-08-13 08:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 08:05:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:06 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:06 --> Total execution time: 0.3589
INFO - 2016-08-13 08:05:07 --> Config Class Initialized
INFO - 2016-08-13 08:05:07 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:07 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:07 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:07 --> URI Class Initialized
INFO - 2016-08-13 08:05:07 --> Router Class Initialized
INFO - 2016-08-13 08:05:07 --> Output Class Initialized
INFO - 2016-08-13 08:05:07 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:07 --> Input Class Initialized
INFO - 2016-08-13 08:05:07 --> Language Class Initialized
INFO - 2016-08-13 08:05:07 --> Loader Class Initialized
INFO - 2016-08-13 08:05:07 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:07 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:07 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:07 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:07 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:07 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:07 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:07 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:07 --> Email Class Initialized
INFO - 2016-08-13 08:05:07 --> Controller Class Initialized
INFO - 2016-08-13 08:05:07 --> Model Class Initialized
INFO - 2016-08-13 08:05:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 08:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:08 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:08 --> Total execution time: 0.3858
INFO - 2016-08-13 08:05:13 --> Config Class Initialized
INFO - 2016-08-13 08:05:13 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:13 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:13 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:13 --> URI Class Initialized
INFO - 2016-08-13 08:05:13 --> Router Class Initialized
INFO - 2016-08-13 08:05:13 --> Output Class Initialized
INFO - 2016-08-13 08:05:13 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:13 --> Input Class Initialized
INFO - 2016-08-13 08:05:14 --> Language Class Initialized
INFO - 2016-08-13 08:05:14 --> Loader Class Initialized
INFO - 2016-08-13 08:05:14 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:14 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:14 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:14 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:14 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:14 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:14 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:14 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:14 --> Email Class Initialized
INFO - 2016-08-13 08:05:14 --> Controller Class Initialized
INFO - 2016-08-13 08:05:14 --> Model Class Initialized
INFO - 2016-08-13 08:05:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 08:05:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:14 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:14 --> Total execution time: 0.3584
INFO - 2016-08-13 08:05:29 --> Config Class Initialized
INFO - 2016-08-13 08:05:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:29 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:29 --> URI Class Initialized
INFO - 2016-08-13 08:05:29 --> Router Class Initialized
INFO - 2016-08-13 08:05:29 --> Output Class Initialized
INFO - 2016-08-13 08:05:29 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:29 --> Input Class Initialized
INFO - 2016-08-13 08:05:29 --> Language Class Initialized
INFO - 2016-08-13 08:05:29 --> Loader Class Initialized
INFO - 2016-08-13 08:05:29 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:29 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:29 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:29 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:29 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:29 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:29 --> Email Class Initialized
INFO - 2016-08-13 08:05:29 --> Controller Class Initialized
INFO - 2016-08-13 08:05:29 --> Model Class Initialized
DEBUG - 2016-08-13 08:05:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:05:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-13 08:05:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:29 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:29 --> Total execution time: 0.3694
INFO - 2016-08-13 08:05:42 --> Config Class Initialized
INFO - 2016-08-13 08:05:42 --> Config Class Initialized
INFO - 2016-08-13 08:05:42 --> Hooks Class Initialized
INFO - 2016-08-13 08:05:42 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:42 --> UTF-8 Support Enabled
DEBUG - 2016-08-13 08:05:42 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:42 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:42 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:42 --> URI Class Initialized
INFO - 2016-08-13 08:05:42 --> URI Class Initialized
INFO - 2016-08-13 08:05:42 --> Router Class Initialized
INFO - 2016-08-13 08:05:42 --> Router Class Initialized
INFO - 2016-08-13 08:05:42 --> Output Class Initialized
INFO - 2016-08-13 08:05:42 --> Output Class Initialized
INFO - 2016-08-13 08:05:42 --> Security Class Initialized
INFO - 2016-08-13 08:05:42 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-13 08:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:43 --> Input Class Initialized
INFO - 2016-08-13 08:05:43 --> Input Class Initialized
INFO - 2016-08-13 08:05:43 --> Language Class Initialized
INFO - 2016-08-13 08:05:43 --> Language Class Initialized
INFO - 2016-08-13 08:05:43 --> Loader Class Initialized
INFO - 2016-08-13 08:05:43 --> Loader Class Initialized
INFO - 2016-08-13 08:05:43 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:43 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:43 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:43 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:43 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:43 --> Email Class Initialized
INFO - 2016-08-13 08:05:43 --> Controller Class Initialized
INFO - 2016-08-13 08:05:43 --> Model Class Initialized
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:43 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:43 --> Total execution time: 0.7598
INFO - 2016-08-13 08:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:43 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:43 --> Email Class Initialized
INFO - 2016-08-13 08:05:43 --> Controller Class Initialized
INFO - 2016-08-13 08:05:43 --> Model Class Initialized
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 08:05:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:43 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:43 --> Total execution time: 1.0352
INFO - 2016-08-13 08:05:45 --> Config Class Initialized
INFO - 2016-08-13 08:05:45 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:05:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:05:45 --> Utf8 Class Initialized
INFO - 2016-08-13 08:05:45 --> URI Class Initialized
INFO - 2016-08-13 08:05:45 --> Router Class Initialized
INFO - 2016-08-13 08:05:45 --> Output Class Initialized
INFO - 2016-08-13 08:05:46 --> Security Class Initialized
DEBUG - 2016-08-13 08:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:05:46 --> Input Class Initialized
INFO - 2016-08-13 08:05:46 --> Language Class Initialized
INFO - 2016-08-13 08:05:46 --> Loader Class Initialized
INFO - 2016-08-13 08:05:46 --> Helper loaded: url_helper
INFO - 2016-08-13 08:05:46 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:05:46 --> Helper loaded: html_helper
INFO - 2016-08-13 08:05:46 --> Helper loaded: form_helper
INFO - 2016-08-13 08:05:46 --> Helper loaded: file_helper
INFO - 2016-08-13 08:05:46 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:05:46 --> Database Driver Class Initialized
INFO - 2016-08-13 08:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:05:46 --> Form Validation Class Initialized
INFO - 2016-08-13 08:05:46 --> Email Class Initialized
INFO - 2016-08-13 08:05:46 --> Controller Class Initialized
INFO - 2016-08-13 08:05:46 --> Model Class Initialized
INFO - 2016-08-13 08:05:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:05:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:05:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-13 08:05:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:05:46 --> Final output sent to browser
DEBUG - 2016-08-13 08:05:46 --> Total execution time: 0.4021
INFO - 2016-08-13 08:06:33 --> Config Class Initialized
INFO - 2016-08-13 08:06:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:33 --> URI Class Initialized
INFO - 2016-08-13 08:06:33 --> Router Class Initialized
INFO - 2016-08-13 08:06:33 --> Output Class Initialized
INFO - 2016-08-13 08:06:33 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:33 --> Input Class Initialized
INFO - 2016-08-13 08:06:33 --> Language Class Initialized
INFO - 2016-08-13 08:06:33 --> Loader Class Initialized
INFO - 2016-08-13 08:06:33 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:33 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:33 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:33 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:33 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:33 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:33 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:33 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:33 --> Email Class Initialized
INFO - 2016-08-13 08:06:33 --> Controller Class Initialized
INFO - 2016-08-13 08:06:33 --> Model Class Initialized
INFO - 2016-08-13 08:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 08:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:33 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:33 --> Total execution time: 0.3751
INFO - 2016-08-13 08:06:36 --> Config Class Initialized
INFO - 2016-08-13 08:06:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:36 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:36 --> URI Class Initialized
INFO - 2016-08-13 08:06:36 --> Router Class Initialized
INFO - 2016-08-13 08:06:36 --> Output Class Initialized
INFO - 2016-08-13 08:06:36 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:36 --> Input Class Initialized
INFO - 2016-08-13 08:06:36 --> Language Class Initialized
INFO - 2016-08-13 08:06:36 --> Loader Class Initialized
INFO - 2016-08-13 08:06:36 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:36 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:36 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:36 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:36 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:36 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:36 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:36 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:36 --> Email Class Initialized
INFO - 2016-08-13 08:06:36 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:36 --> Model Class Initialized
INFO - 2016-08-13 08:06:36 --> Model Class Initialized
INFO - 2016-08-13 08:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:36 --> Model Class Initialized
INFO - 2016-08-13 08:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-13 08:06:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:37 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:37 --> Total execution time: 0.4005
INFO - 2016-08-13 08:06:39 --> Config Class Initialized
INFO - 2016-08-13 08:06:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:39 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:39 --> URI Class Initialized
INFO - 2016-08-13 08:06:39 --> Router Class Initialized
INFO - 2016-08-13 08:06:39 --> Output Class Initialized
INFO - 2016-08-13 08:06:39 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:39 --> Input Class Initialized
INFO - 2016-08-13 08:06:39 --> Language Class Initialized
INFO - 2016-08-13 08:06:39 --> Loader Class Initialized
INFO - 2016-08-13 08:06:39 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:39 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:39 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:39 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:39 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:39 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:39 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:39 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:39 --> Email Class Initialized
INFO - 2016-08-13 08:06:39 --> Controller Class Initialized
INFO - 2016-08-13 08:06:39 --> Model Class Initialized
INFO - 2016-08-13 08:06:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-13 08:06:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:39 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:39 --> Total execution time: 0.3785
INFO - 2016-08-13 08:06:45 --> Config Class Initialized
INFO - 2016-08-13 08:06:45 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:45 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:45 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:45 --> URI Class Initialized
INFO - 2016-08-13 08:06:45 --> Router Class Initialized
INFO - 2016-08-13 08:06:45 --> Output Class Initialized
INFO - 2016-08-13 08:06:45 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:45 --> Input Class Initialized
INFO - 2016-08-13 08:06:45 --> Language Class Initialized
INFO - 2016-08-13 08:06:45 --> Loader Class Initialized
INFO - 2016-08-13 08:06:45 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:45 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:45 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:45 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:45 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:45 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:45 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:45 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:45 --> Email Class Initialized
INFO - 2016-08-13 08:06:45 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 08:06:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:46 --> Model Class Initialized
INFO - 2016-08-13 08:06:46 --> Model Class Initialized
INFO - 2016-08-13 08:06:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 08:06:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:46 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:46 --> Total execution time: 0.4627
INFO - 2016-08-13 08:06:47 --> Config Class Initialized
INFO - 2016-08-13 08:06:47 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:47 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:47 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:47 --> URI Class Initialized
INFO - 2016-08-13 08:06:47 --> Router Class Initialized
INFO - 2016-08-13 08:06:47 --> Output Class Initialized
INFO - 2016-08-13 08:06:47 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:47 --> Input Class Initialized
INFO - 2016-08-13 08:06:47 --> Language Class Initialized
INFO - 2016-08-13 08:06:47 --> Loader Class Initialized
INFO - 2016-08-13 08:06:47 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:47 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:47 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:47 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:47 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:47 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:48 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:48 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:48 --> Email Class Initialized
INFO - 2016-08-13 08:06:48 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 08:06:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:48 --> Model Class Initialized
INFO - 2016-08-13 08:06:48 --> Model Class Initialized
INFO - 2016-08-13 08:06:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/users.php
INFO - 2016-08-13 08:06:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:48 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:48 --> Total execution time: 0.4271
INFO - 2016-08-13 08:06:53 --> Config Class Initialized
INFO - 2016-08-13 08:06:53 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:53 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:53 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:53 --> URI Class Initialized
INFO - 2016-08-13 08:06:53 --> Router Class Initialized
INFO - 2016-08-13 08:06:53 --> Output Class Initialized
INFO - 2016-08-13 08:06:53 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:53 --> Input Class Initialized
INFO - 2016-08-13 08:06:53 --> Language Class Initialized
INFO - 2016-08-13 08:06:53 --> Loader Class Initialized
INFO - 2016-08-13 08:06:53 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:53 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:53 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:53 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:53 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:53 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:53 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:53 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:53 --> Email Class Initialized
INFO - 2016-08-13 08:06:53 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 08:06:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:53 --> Model Class Initialized
INFO - 2016-08-13 08:06:53 --> Model Class Initialized
INFO - 2016-08-13 08:06:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 08:06:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:53 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:53 --> Total execution time: 0.4701
INFO - 2016-08-13 08:06:57 --> Config Class Initialized
INFO - 2016-08-13 08:06:57 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:57 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:57 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:57 --> URI Class Initialized
INFO - 2016-08-13 08:06:57 --> Router Class Initialized
INFO - 2016-08-13 08:06:57 --> Output Class Initialized
INFO - 2016-08-13 08:06:57 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:57 --> Input Class Initialized
INFO - 2016-08-13 08:06:57 --> Language Class Initialized
INFO - 2016-08-13 08:06:57 --> Loader Class Initialized
INFO - 2016-08-13 08:06:57 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:57 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:57 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:57 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:57 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:57 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:57 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:57 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:57 --> Email Class Initialized
INFO - 2016-08-13 08:06:57 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 08:06:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:57 --> Model Class Initialized
INFO - 2016-08-13 08:06:57 --> Model Class Initialized
INFO - 2016-08-13 08:06:57 --> Model Class Initialized
INFO - 2016-08-13 08:06:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/book_broken.php
INFO - 2016-08-13 08:06:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:57 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:57 --> Total execution time: 0.4145
INFO - 2016-08-13 08:06:59 --> Config Class Initialized
INFO - 2016-08-13 08:06:59 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:06:59 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:06:59 --> Utf8 Class Initialized
INFO - 2016-08-13 08:06:59 --> URI Class Initialized
INFO - 2016-08-13 08:06:59 --> Router Class Initialized
INFO - 2016-08-13 08:06:59 --> Output Class Initialized
INFO - 2016-08-13 08:06:59 --> Security Class Initialized
DEBUG - 2016-08-13 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:06:59 --> Input Class Initialized
INFO - 2016-08-13 08:06:59 --> Language Class Initialized
INFO - 2016-08-13 08:06:59 --> Loader Class Initialized
INFO - 2016-08-13 08:06:59 --> Helper loaded: url_helper
INFO - 2016-08-13 08:06:59 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:06:59 --> Helper loaded: html_helper
INFO - 2016-08-13 08:06:59 --> Helper loaded: form_helper
INFO - 2016-08-13 08:06:59 --> Helper loaded: file_helper
INFO - 2016-08-13 08:06:59 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:06:59 --> Database Driver Class Initialized
INFO - 2016-08-13 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:06:59 --> Form Validation Class Initialized
INFO - 2016-08-13 08:06:59 --> Email Class Initialized
INFO - 2016-08-13 08:06:59 --> Controller Class Initialized
DEBUG - 2016-08-13 08:06:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-13 08:06:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:06:59 --> Model Class Initialized
INFO - 2016-08-13 08:06:59 --> Model Class Initialized
INFO - 2016-08-13 08:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-13 08:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:06:59 --> Final output sent to browser
DEBUG - 2016-08-13 08:06:59 --> Total execution time: 0.4521
INFO - 2016-08-13 08:14:37 --> Config Class Initialized
INFO - 2016-08-13 08:14:37 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:14:37 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:14:37 --> Utf8 Class Initialized
INFO - 2016-08-13 08:14:37 --> URI Class Initialized
INFO - 2016-08-13 08:14:37 --> Router Class Initialized
INFO - 2016-08-13 08:14:37 --> Output Class Initialized
INFO - 2016-08-13 08:14:37 --> Security Class Initialized
DEBUG - 2016-08-13 08:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:14:38 --> Input Class Initialized
INFO - 2016-08-13 08:14:38 --> Language Class Initialized
INFO - 2016-08-13 08:14:38 --> Loader Class Initialized
INFO - 2016-08-13 08:14:38 --> Helper loaded: url_helper
INFO - 2016-08-13 08:14:38 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:14:38 --> Helper loaded: html_helper
INFO - 2016-08-13 08:14:38 --> Helper loaded: form_helper
INFO - 2016-08-13 08:14:38 --> Helper loaded: file_helper
INFO - 2016-08-13 08:14:38 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:14:38 --> Database Driver Class Initialized
INFO - 2016-08-13 08:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:14:38 --> Form Validation Class Initialized
INFO - 2016-08-13 08:14:38 --> Email Class Initialized
INFO - 2016-08-13 08:14:38 --> Controller Class Initialized
INFO - 2016-08-13 08:14:38 --> Model Class Initialized
INFO - 2016-08-13 08:14:38 --> Model Class Initialized
INFO - 2016-08-13 08:14:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:14:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:14:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-13 08:14:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:14:38 --> Final output sent to browser
DEBUG - 2016-08-13 08:14:38 --> Total execution time: 0.4366
INFO - 2016-08-13 08:14:39 --> Config Class Initialized
INFO - 2016-08-13 08:14:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:14:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:14:39 --> Utf8 Class Initialized
INFO - 2016-08-13 08:14:39 --> URI Class Initialized
INFO - 2016-08-13 08:14:39 --> Router Class Initialized
INFO - 2016-08-13 08:14:39 --> Output Class Initialized
INFO - 2016-08-13 08:14:39 --> Security Class Initialized
DEBUG - 2016-08-13 08:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:14:39 --> Input Class Initialized
INFO - 2016-08-13 08:14:39 --> Language Class Initialized
INFO - 2016-08-13 08:14:39 --> Loader Class Initialized
INFO - 2016-08-13 08:14:39 --> Helper loaded: url_helper
INFO - 2016-08-13 08:14:39 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:14:39 --> Helper loaded: html_helper
INFO - 2016-08-13 08:14:39 --> Helper loaded: form_helper
INFO - 2016-08-13 08:14:39 --> Helper loaded: file_helper
INFO - 2016-08-13 08:14:39 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:14:39 --> Database Driver Class Initialized
INFO - 2016-08-13 08:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:14:39 --> Form Validation Class Initialized
INFO - 2016-08-13 08:14:39 --> Email Class Initialized
INFO - 2016-08-13 08:14:39 --> Controller Class Initialized
DEBUG - 2016-08-13 08:14:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:14:39 --> Model Class Initialized
INFO - 2016-08-13 08:14:39 --> Model Class Initialized
INFO - 2016-08-13 08:14:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:14:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:14:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:14:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:14:39 --> Final output sent to browser
DEBUG - 2016-08-13 08:14:39 --> Total execution time: 0.4465
INFO - 2016-08-13 08:14:42 --> Config Class Initialized
INFO - 2016-08-13 08:14:42 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:14:42 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:14:42 --> Utf8 Class Initialized
INFO - 2016-08-13 08:14:42 --> URI Class Initialized
INFO - 2016-08-13 08:14:42 --> Router Class Initialized
INFO - 2016-08-13 08:14:42 --> Output Class Initialized
INFO - 2016-08-13 08:14:42 --> Security Class Initialized
DEBUG - 2016-08-13 08:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:14:42 --> Input Class Initialized
INFO - 2016-08-13 08:14:42 --> Language Class Initialized
INFO - 2016-08-13 08:14:42 --> Loader Class Initialized
INFO - 2016-08-13 08:14:42 --> Helper loaded: url_helper
INFO - 2016-08-13 08:14:42 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:14:42 --> Helper loaded: html_helper
INFO - 2016-08-13 08:14:42 --> Helper loaded: form_helper
INFO - 2016-08-13 08:14:42 --> Helper loaded: file_helper
INFO - 2016-08-13 08:14:42 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:14:42 --> Database Driver Class Initialized
INFO - 2016-08-13 08:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:14:42 --> Form Validation Class Initialized
INFO - 2016-08-13 08:14:42 --> Email Class Initialized
INFO - 2016-08-13 08:14:42 --> Controller Class Initialized
DEBUG - 2016-08-13 08:14:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:14:42 --> Model Class Initialized
INFO - 2016-08-13 08:14:42 --> Model Class Initialized
INFO - 2016-08-13 08:14:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:14:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:14:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 08:14:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:14:42 --> Final output sent to browser
DEBUG - 2016-08-13 08:14:42 --> Total execution time: 0.3991
INFO - 2016-08-13 08:16:02 --> Config Class Initialized
INFO - 2016-08-13 08:16:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:02 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:02 --> URI Class Initialized
INFO - 2016-08-13 08:16:02 --> Router Class Initialized
INFO - 2016-08-13 08:16:02 --> Output Class Initialized
INFO - 2016-08-13 08:16:02 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:02 --> Input Class Initialized
INFO - 2016-08-13 08:16:02 --> Language Class Initialized
INFO - 2016-08-13 08:16:02 --> Loader Class Initialized
INFO - 2016-08-13 08:16:02 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:02 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:02 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:02 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:02 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:02 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:02 --> Email Class Initialized
INFO - 2016-08-13 08:16:02 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:02 --> Model Class Initialized
INFO - 2016-08-13 08:16:02 --> Model Class Initialized
INFO - 2016-08-13 08:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 08:16:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:16:02 --> Final output sent to browser
DEBUG - 2016-08-13 08:16:02 --> Total execution time: 0.3967
INFO - 2016-08-13 08:16:25 --> Config Class Initialized
INFO - 2016-08-13 08:16:25 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:25 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:25 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:25 --> URI Class Initialized
INFO - 2016-08-13 08:16:25 --> Router Class Initialized
INFO - 2016-08-13 08:16:25 --> Output Class Initialized
INFO - 2016-08-13 08:16:25 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:25 --> Input Class Initialized
INFO - 2016-08-13 08:16:25 --> Language Class Initialized
INFO - 2016-08-13 08:16:25 --> Loader Class Initialized
INFO - 2016-08-13 08:16:25 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:25 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:25 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:25 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:25 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:25 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:25 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:25 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:25 --> Email Class Initialized
INFO - 2016-08-13 08:16:25 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:25 --> Model Class Initialized
INFO - 2016-08-13 08:16:25 --> Model Class Initialized
INFO - 2016-08-13 08:16:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:16:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:16:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 08:16:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:16:25 --> Final output sent to browser
DEBUG - 2016-08-13 08:16:25 --> Total execution time: 0.3911
INFO - 2016-08-13 08:16:41 --> Config Class Initialized
INFO - 2016-08-13 08:16:41 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:41 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:41 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:41 --> URI Class Initialized
INFO - 2016-08-13 08:16:41 --> Router Class Initialized
INFO - 2016-08-13 08:16:41 --> Output Class Initialized
INFO - 2016-08-13 08:16:41 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:41 --> Input Class Initialized
INFO - 2016-08-13 08:16:41 --> Language Class Initialized
INFO - 2016-08-13 08:16:41 --> Loader Class Initialized
INFO - 2016-08-13 08:16:41 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:41 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:41 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:41 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:41 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:41 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:41 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:41 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:41 --> Email Class Initialized
INFO - 2016-08-13 08:16:41 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:41 --> Model Class Initialized
INFO - 2016-08-13 08:16:41 --> Model Class Initialized
INFO - 2016-08-13 08:16:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:16:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:16:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:16:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:16:41 --> Final output sent to browser
DEBUG - 2016-08-13 08:16:41 --> Total execution time: 0.6729
INFO - 2016-08-13 08:16:47 --> Config Class Initialized
INFO - 2016-08-13 08:16:47 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:47 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:47 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:47 --> URI Class Initialized
INFO - 2016-08-13 08:16:47 --> Router Class Initialized
INFO - 2016-08-13 08:16:47 --> Output Class Initialized
INFO - 2016-08-13 08:16:47 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:47 --> Input Class Initialized
INFO - 2016-08-13 08:16:47 --> Language Class Initialized
INFO - 2016-08-13 08:16:47 --> Loader Class Initialized
INFO - 2016-08-13 08:16:47 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:47 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:47 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:47 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:47 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:47 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:47 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:47 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:47 --> Email Class Initialized
INFO - 2016-08-13 08:16:47 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:47 --> Model Class Initialized
INFO - 2016-08-13 08:16:47 --> Model Class Initialized
INFO - 2016-08-13 08:16:47 --> Config Class Initialized
INFO - 2016-08-13 08:16:47 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:47 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:47 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:47 --> URI Class Initialized
INFO - 2016-08-13 08:16:47 --> Router Class Initialized
INFO - 2016-08-13 08:16:47 --> Output Class Initialized
INFO - 2016-08-13 08:16:47 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:47 --> Input Class Initialized
INFO - 2016-08-13 08:16:47 --> Language Class Initialized
INFO - 2016-08-13 08:16:48 --> Loader Class Initialized
INFO - 2016-08-13 08:16:48 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:48 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:48 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:48 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:48 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:48 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:48 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:48 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:48 --> Email Class Initialized
INFO - 2016-08-13 08:16:48 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:48 --> Model Class Initialized
INFO - 2016-08-13 08:16:48 --> Model Class Initialized
INFO - 2016-08-13 08:16:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:16:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:16:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:16:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:16:48 --> Final output sent to browser
DEBUG - 2016-08-13 08:16:48 --> Total execution time: 0.4686
INFO - 2016-08-13 08:16:55 --> Config Class Initialized
INFO - 2016-08-13 08:16:55 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:16:55 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:16:55 --> Utf8 Class Initialized
INFO - 2016-08-13 08:16:55 --> URI Class Initialized
INFO - 2016-08-13 08:16:55 --> Router Class Initialized
INFO - 2016-08-13 08:16:55 --> Output Class Initialized
INFO - 2016-08-13 08:16:55 --> Security Class Initialized
DEBUG - 2016-08-13 08:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:16:55 --> Input Class Initialized
INFO - 2016-08-13 08:16:55 --> Language Class Initialized
INFO - 2016-08-13 08:16:55 --> Loader Class Initialized
INFO - 2016-08-13 08:16:55 --> Helper loaded: url_helper
INFO - 2016-08-13 08:16:55 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:16:55 --> Helper loaded: html_helper
INFO - 2016-08-13 08:16:55 --> Helper loaded: form_helper
INFO - 2016-08-13 08:16:55 --> Helper loaded: file_helper
INFO - 2016-08-13 08:16:55 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:16:55 --> Database Driver Class Initialized
INFO - 2016-08-13 08:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:16:55 --> Form Validation Class Initialized
INFO - 2016-08-13 08:16:55 --> Email Class Initialized
INFO - 2016-08-13 08:16:55 --> Controller Class Initialized
DEBUG - 2016-08-13 08:16:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:16:55 --> Model Class Initialized
INFO - 2016-08-13 08:16:55 --> Model Class Initialized
INFO - 2016-08-13 08:16:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:16:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:16:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:16:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:16:55 --> Final output sent to browser
DEBUG - 2016-08-13 08:16:55 --> Total execution time: 0.3984
INFO - 2016-08-13 08:18:00 --> Config Class Initialized
INFO - 2016-08-13 08:18:00 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:00 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:00 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:00 --> URI Class Initialized
INFO - 2016-08-13 08:18:00 --> Router Class Initialized
INFO - 2016-08-13 08:18:00 --> Output Class Initialized
INFO - 2016-08-13 08:18:00 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:00 --> Input Class Initialized
INFO - 2016-08-13 08:18:00 --> Language Class Initialized
INFO - 2016-08-13 08:18:00 --> Loader Class Initialized
INFO - 2016-08-13 08:18:00 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:00 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:00 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:00 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:00 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:00 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:00 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:00 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:00 --> Email Class Initialized
INFO - 2016-08-13 08:18:00 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:00 --> Model Class Initialized
INFO - 2016-08-13 08:18:00 --> Model Class Initialized
INFO - 2016-08-13 08:18:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:18:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:00 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:00 --> Total execution time: 0.4164
INFO - 2016-08-13 08:18:05 --> Config Class Initialized
INFO - 2016-08-13 08:18:05 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:06 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:06 --> URI Class Initialized
INFO - 2016-08-13 08:18:06 --> Router Class Initialized
INFO - 2016-08-13 08:18:06 --> Output Class Initialized
INFO - 2016-08-13 08:18:06 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:06 --> Input Class Initialized
INFO - 2016-08-13 08:18:06 --> Language Class Initialized
INFO - 2016-08-13 08:18:06 --> Loader Class Initialized
INFO - 2016-08-13 08:18:06 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:06 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:06 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:06 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:06 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:06 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:06 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:06 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:06 --> Email Class Initialized
INFO - 2016-08-13 08:18:06 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:06 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:06 --> Total execution time: 0.5283
INFO - 2016-08-13 08:18:16 --> Config Class Initialized
INFO - 2016-08-13 08:18:16 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:16 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:16 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:16 --> URI Class Initialized
INFO - 2016-08-13 08:18:16 --> Router Class Initialized
INFO - 2016-08-13 08:18:16 --> Output Class Initialized
INFO - 2016-08-13 08:18:16 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:16 --> Input Class Initialized
INFO - 2016-08-13 08:18:16 --> Language Class Initialized
INFO - 2016-08-13 08:18:16 --> Loader Class Initialized
INFO - 2016-08-13 08:18:16 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:16 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:16 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:16 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:16 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:16 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:16 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:16 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:16 --> Email Class Initialized
INFO - 2016-08-13 08:18:16 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:16 --> Config Class Initialized
INFO - 2016-08-13 08:18:16 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:16 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:16 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:16 --> URI Class Initialized
INFO - 2016-08-13 08:18:17 --> Router Class Initialized
INFO - 2016-08-13 08:18:17 --> Output Class Initialized
INFO - 2016-08-13 08:18:17 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:17 --> Input Class Initialized
INFO - 2016-08-13 08:18:17 --> Language Class Initialized
INFO - 2016-08-13 08:18:17 --> Loader Class Initialized
INFO - 2016-08-13 08:18:17 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:17 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:17 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:17 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:17 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:17 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:17 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:17 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:17 --> Email Class Initialized
INFO - 2016-08-13 08:18:17 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:17 --> Model Class Initialized
INFO - 2016-08-13 08:18:17 --> Model Class Initialized
INFO - 2016-08-13 08:18:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:18:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:17 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:17 --> Total execution time: 0.6387
INFO - 2016-08-13 08:18:26 --> Config Class Initialized
INFO - 2016-08-13 08:18:26 --> Config Class Initialized
INFO - 2016-08-13 08:18:26 --> Hooks Class Initialized
INFO - 2016-08-13 08:18:26 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-13 08:18:26 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:26 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:26 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:26 --> URI Class Initialized
INFO - 2016-08-13 08:18:26 --> URI Class Initialized
INFO - 2016-08-13 08:18:26 --> Router Class Initialized
INFO - 2016-08-13 08:18:26 --> Router Class Initialized
INFO - 2016-08-13 08:18:26 --> Output Class Initialized
INFO - 2016-08-13 08:18:26 --> Output Class Initialized
INFO - 2016-08-13 08:18:26 --> Security Class Initialized
INFO - 2016-08-13 08:18:26 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-13 08:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:26 --> Input Class Initialized
INFO - 2016-08-13 08:18:26 --> Input Class Initialized
INFO - 2016-08-13 08:18:26 --> Language Class Initialized
INFO - 2016-08-13 08:18:26 --> Language Class Initialized
INFO - 2016-08-13 08:18:27 --> Loader Class Initialized
INFO - 2016-08-13 08:18:27 --> Loader Class Initialized
INFO - 2016-08-13 08:18:27 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:27 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:27 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:27 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:27 --> Email Class Initialized
INFO - 2016-08-13 08:18:27 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:27 --> Config Class Initialized
INFO - 2016-08-13 08:18:27 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:27 --> Hooks Class Initialized
INFO - 2016-08-13 08:18:27 --> Email Class Initialized
INFO - 2016-08-13 08:18:27 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:27 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:27 --> Utf8 Class Initialized
DEBUG - 2016-08-13 08:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:27 --> URI Class Initialized
INFO - 2016-08-13 08:18:27 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:27 --> Total execution time: 0.7270
INFO - 2016-08-13 08:18:27 --> Router Class Initialized
INFO - 2016-08-13 08:18:27 --> Output Class Initialized
INFO - 2016-08-13 08:18:27 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:27 --> Input Class Initialized
INFO - 2016-08-13 08:18:27 --> Language Class Initialized
INFO - 2016-08-13 08:18:27 --> Loader Class Initialized
INFO - 2016-08-13 08:18:27 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:27 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:27 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:27 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:27 --> Email Class Initialized
INFO - 2016-08-13 08:18:27 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:27 --> Model Class Initialized
INFO - 2016-08-13 08:18:27 --> Model Class Initialized
INFO - 2016-08-13 08:18:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:18:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:27 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:27 --> Total execution time: 0.5542
INFO - 2016-08-13 08:18:29 --> Config Class Initialized
INFO - 2016-08-13 08:18:29 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:29 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:29 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:29 --> URI Class Initialized
INFO - 2016-08-13 08:18:29 --> Router Class Initialized
INFO - 2016-08-13 08:18:29 --> Output Class Initialized
INFO - 2016-08-13 08:18:29 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:29 --> Input Class Initialized
INFO - 2016-08-13 08:18:29 --> Language Class Initialized
INFO - 2016-08-13 08:18:29 --> Loader Class Initialized
INFO - 2016-08-13 08:18:29 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:29 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:29 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:29 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:29 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:29 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:29 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:29 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:29 --> Email Class Initialized
INFO - 2016-08-13 08:18:29 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:29 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:29 --> Total execution time: 0.3740
INFO - 2016-08-13 08:18:33 --> Config Class Initialized
INFO - 2016-08-13 08:18:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:33 --> URI Class Initialized
INFO - 2016-08-13 08:18:33 --> Router Class Initialized
INFO - 2016-08-13 08:18:33 --> Output Class Initialized
INFO - 2016-08-13 08:18:33 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:33 --> Input Class Initialized
INFO - 2016-08-13 08:18:33 --> Language Class Initialized
INFO - 2016-08-13 08:18:33 --> Loader Class Initialized
INFO - 2016-08-13 08:18:33 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:33 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:33 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:33 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:33 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:33 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:33 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:33 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:33 --> Email Class Initialized
INFO - 2016-08-13 08:18:33 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:33 --> Config Class Initialized
INFO - 2016-08-13 08:18:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:33 --> URI Class Initialized
INFO - 2016-08-13 08:18:33 --> Router Class Initialized
INFO - 2016-08-13 08:18:33 --> Output Class Initialized
INFO - 2016-08-13 08:18:34 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:34 --> Input Class Initialized
INFO - 2016-08-13 08:18:34 --> Language Class Initialized
INFO - 2016-08-13 08:18:34 --> Loader Class Initialized
INFO - 2016-08-13 08:18:34 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:34 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:34 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:34 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:34 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:34 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:34 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:34 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:34 --> Email Class Initialized
INFO - 2016-08-13 08:18:34 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:34 --> Model Class Initialized
INFO - 2016-08-13 08:18:34 --> Model Class Initialized
INFO - 2016-08-13 08:18:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:18:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:34 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:34 --> Total execution time: 0.8437
INFO - 2016-08-13 08:18:36 --> Config Class Initialized
INFO - 2016-08-13 08:18:36 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:36 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:36 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:36 --> URI Class Initialized
INFO - 2016-08-13 08:18:36 --> Router Class Initialized
INFO - 2016-08-13 08:18:36 --> Output Class Initialized
INFO - 2016-08-13 08:18:36 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:36 --> Input Class Initialized
INFO - 2016-08-13 08:18:36 --> Language Class Initialized
INFO - 2016-08-13 08:18:36 --> Loader Class Initialized
INFO - 2016-08-13 08:18:36 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:36 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:36 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:36 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:36 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:37 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:37 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:37 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:37 --> Email Class Initialized
INFO - 2016-08-13 08:18:37 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:37 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:37 --> Total execution time: 0.3563
INFO - 2016-08-13 08:18:38 --> Config Class Initialized
INFO - 2016-08-13 08:18:38 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:38 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:38 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:38 --> URI Class Initialized
INFO - 2016-08-13 08:18:38 --> Router Class Initialized
INFO - 2016-08-13 08:18:38 --> Output Class Initialized
INFO - 2016-08-13 08:18:38 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:38 --> Input Class Initialized
INFO - 2016-08-13 08:18:38 --> Language Class Initialized
INFO - 2016-08-13 08:18:38 --> Loader Class Initialized
INFO - 2016-08-13 08:18:39 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:39 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:39 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:39 --> Email Class Initialized
INFO - 2016-08-13 08:18:39 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:39 --> Config Class Initialized
INFO - 2016-08-13 08:18:39 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:39 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:39 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:39 --> URI Class Initialized
INFO - 2016-08-13 08:18:39 --> Router Class Initialized
INFO - 2016-08-13 08:18:39 --> Output Class Initialized
INFO - 2016-08-13 08:18:39 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:39 --> Input Class Initialized
INFO - 2016-08-13 08:18:39 --> Language Class Initialized
INFO - 2016-08-13 08:18:39 --> Loader Class Initialized
INFO - 2016-08-13 08:18:39 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:39 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:39 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:39 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:39 --> Email Class Initialized
INFO - 2016-08-13 08:18:39 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:39 --> Model Class Initialized
INFO - 2016-08-13 08:18:39 --> Model Class Initialized
INFO - 2016-08-13 08:18:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:18:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:39 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:39 --> Total execution time: 0.6294
INFO - 2016-08-13 08:18:44 --> Config Class Initialized
INFO - 2016-08-13 08:18:44 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:44 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:44 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:44 --> URI Class Initialized
INFO - 2016-08-13 08:18:44 --> Router Class Initialized
INFO - 2016-08-13 08:18:44 --> Output Class Initialized
INFO - 2016-08-13 08:18:44 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:44 --> Input Class Initialized
INFO - 2016-08-13 08:18:44 --> Language Class Initialized
INFO - 2016-08-13 08:18:44 --> Loader Class Initialized
INFO - 2016-08-13 08:18:44 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:44 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:44 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:44 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:44 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:44 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:44 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:44 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:44 --> Email Class Initialized
INFO - 2016-08-13 08:18:44 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:44 --> Model Class Initialized
INFO - 2016-08-13 08:18:44 --> Model Class Initialized
INFO - 2016-08-13 08:18:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:18:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:44 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:44 --> Total execution time: 0.4627
INFO - 2016-08-13 08:18:48 --> Config Class Initialized
INFO - 2016-08-13 08:18:48 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:48 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:48 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:48 --> URI Class Initialized
INFO - 2016-08-13 08:18:48 --> Router Class Initialized
INFO - 2016-08-13 08:18:48 --> Output Class Initialized
INFO - 2016-08-13 08:18:48 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:48 --> Input Class Initialized
INFO - 2016-08-13 08:18:48 --> Language Class Initialized
INFO - 2016-08-13 08:18:48 --> Loader Class Initialized
INFO - 2016-08-13 08:18:48 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:48 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:48 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:48 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:48 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:48 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:48 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:48 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:48 --> Email Class Initialized
INFO - 2016-08-13 08:18:48 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:48 --> Model Class Initialized
INFO - 2016-08-13 08:18:48 --> Model Class Initialized
INFO - 2016-08-13 08:18:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:18:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:48 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:48 --> Total execution time: 0.4199
INFO - 2016-08-13 08:18:50 --> Config Class Initialized
INFO - 2016-08-13 08:18:50 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:50 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:50 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:50 --> URI Class Initialized
INFO - 2016-08-13 08:18:50 --> Router Class Initialized
INFO - 2016-08-13 08:18:50 --> Output Class Initialized
INFO - 2016-08-13 08:18:50 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:50 --> Input Class Initialized
INFO - 2016-08-13 08:18:50 --> Language Class Initialized
INFO - 2016-08-13 08:18:50 --> Loader Class Initialized
INFO - 2016-08-13 08:18:50 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:50 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:50 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:50 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:50 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:50 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:50 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:50 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:50 --> Email Class Initialized
INFO - 2016-08-13 08:18:50 --> Controller Class Initialized
DEBUG - 2016-08-13 08:18:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:18:50 --> Model Class Initialized
INFO - 2016-08-13 08:18:50 --> Model Class Initialized
INFO - 2016-08-13 08:18:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 08:18:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:50 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:50 --> Total execution time: 0.4460
INFO - 2016-08-13 08:18:55 --> Config Class Initialized
INFO - 2016-08-13 08:18:55 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:55 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:55 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:56 --> URI Class Initialized
INFO - 2016-08-13 08:18:56 --> Router Class Initialized
INFO - 2016-08-13 08:18:56 --> Output Class Initialized
INFO - 2016-08-13 08:18:56 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:56 --> Input Class Initialized
INFO - 2016-08-13 08:18:56 --> Language Class Initialized
INFO - 2016-08-13 08:18:56 --> Loader Class Initialized
INFO - 2016-08-13 08:18:56 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:56 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:56 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:56 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:56 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:56 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:56 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:56 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:56 --> Email Class Initialized
INFO - 2016-08-13 08:18:56 --> Controller Class Initialized
INFO - 2016-08-13 08:18:56 --> Model Class Initialized
INFO - 2016-08-13 08:18:56 --> Model Class Initialized
INFO - 2016-08-13 08:18:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-13 08:18:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:56 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:56 --> Total execution time: 0.4213
INFO - 2016-08-13 08:18:59 --> Config Class Initialized
INFO - 2016-08-13 08:18:59 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:18:59 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:18:59 --> Utf8 Class Initialized
INFO - 2016-08-13 08:18:59 --> URI Class Initialized
INFO - 2016-08-13 08:18:59 --> Router Class Initialized
INFO - 2016-08-13 08:18:59 --> Output Class Initialized
INFO - 2016-08-13 08:18:59 --> Security Class Initialized
DEBUG - 2016-08-13 08:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:18:59 --> Input Class Initialized
INFO - 2016-08-13 08:18:59 --> Language Class Initialized
INFO - 2016-08-13 08:18:59 --> Loader Class Initialized
INFO - 2016-08-13 08:18:59 --> Helper loaded: url_helper
INFO - 2016-08-13 08:18:59 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:18:59 --> Helper loaded: html_helper
INFO - 2016-08-13 08:18:59 --> Helper loaded: form_helper
INFO - 2016-08-13 08:18:59 --> Helper loaded: file_helper
INFO - 2016-08-13 08:18:59 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:18:59 --> Database Driver Class Initialized
INFO - 2016-08-13 08:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:18:59 --> Form Validation Class Initialized
INFO - 2016-08-13 08:18:59 --> Email Class Initialized
INFO - 2016-08-13 08:18:59 --> Controller Class Initialized
INFO - 2016-08-13 08:18:59 --> Model Class Initialized
INFO - 2016-08-13 08:18:59 --> Model Class Initialized
INFO - 2016-08-13 08:18:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:18:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:18:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-13 08:18:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:18:59 --> Final output sent to browser
DEBUG - 2016-08-13 08:18:59 --> Total execution time: 0.4183
INFO - 2016-08-13 08:19:03 --> Config Class Initialized
INFO - 2016-08-13 08:19:03 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:19:03 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:19:03 --> Utf8 Class Initialized
INFO - 2016-08-13 08:19:03 --> URI Class Initialized
INFO - 2016-08-13 08:19:03 --> Router Class Initialized
INFO - 2016-08-13 08:19:03 --> Output Class Initialized
INFO - 2016-08-13 08:19:03 --> Security Class Initialized
DEBUG - 2016-08-13 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:19:03 --> Input Class Initialized
INFO - 2016-08-13 08:19:03 --> Language Class Initialized
INFO - 2016-08-13 08:19:03 --> Loader Class Initialized
INFO - 2016-08-13 08:19:03 --> Helper loaded: url_helper
INFO - 2016-08-13 08:19:03 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:19:03 --> Helper loaded: html_helper
INFO - 2016-08-13 08:19:03 --> Helper loaded: form_helper
INFO - 2016-08-13 08:19:03 --> Helper loaded: file_helper
INFO - 2016-08-13 08:19:03 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:19:03 --> Database Driver Class Initialized
INFO - 2016-08-13 08:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:19:03 --> Form Validation Class Initialized
INFO - 2016-08-13 08:19:03 --> Email Class Initialized
INFO - 2016-08-13 08:19:03 --> Controller Class Initialized
DEBUG - 2016-08-13 08:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:19:03 --> Model Class Initialized
INFO - 2016-08-13 08:19:03 --> Model Class Initialized
INFO - 2016-08-13 08:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:19:03 --> Final output sent to browser
DEBUG - 2016-08-13 08:19:03 --> Total execution time: 0.4299
INFO - 2016-08-13 08:19:06 --> Config Class Initialized
INFO - 2016-08-13 08:19:06 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:19:06 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:19:06 --> Utf8 Class Initialized
INFO - 2016-08-13 08:19:07 --> URI Class Initialized
INFO - 2016-08-13 08:19:07 --> Router Class Initialized
INFO - 2016-08-13 08:19:07 --> Output Class Initialized
INFO - 2016-08-13 08:19:07 --> Security Class Initialized
DEBUG - 2016-08-13 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:19:07 --> Input Class Initialized
INFO - 2016-08-13 08:19:07 --> Language Class Initialized
INFO - 2016-08-13 08:19:07 --> Loader Class Initialized
INFO - 2016-08-13 08:19:07 --> Helper loaded: url_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: html_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: form_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: file_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:19:07 --> Database Driver Class Initialized
INFO - 2016-08-13 08:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:19:07 --> Form Validation Class Initialized
INFO - 2016-08-13 08:19:07 --> Email Class Initialized
INFO - 2016-08-13 08:19:07 --> Controller Class Initialized
DEBUG - 2016-08-13 08:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:19:07 --> Model Class Initialized
INFO - 2016-08-13 08:19:07 --> Model Class Initialized
INFO - 2016-08-13 08:19:07 --> Config Class Initialized
INFO - 2016-08-13 08:19:07 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:19:07 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:19:07 --> Utf8 Class Initialized
INFO - 2016-08-13 08:19:07 --> URI Class Initialized
INFO - 2016-08-13 08:19:07 --> Router Class Initialized
INFO - 2016-08-13 08:19:07 --> Output Class Initialized
INFO - 2016-08-13 08:19:07 --> Security Class Initialized
DEBUG - 2016-08-13 08:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:19:07 --> Input Class Initialized
INFO - 2016-08-13 08:19:07 --> Language Class Initialized
INFO - 2016-08-13 08:19:07 --> Loader Class Initialized
INFO - 2016-08-13 08:19:07 --> Helper loaded: url_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: html_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: form_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: file_helper
INFO - 2016-08-13 08:19:07 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:19:07 --> Database Driver Class Initialized
INFO - 2016-08-13 08:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:19:07 --> Form Validation Class Initialized
INFO - 2016-08-13 08:19:07 --> Email Class Initialized
INFO - 2016-08-13 08:19:07 --> Controller Class Initialized
DEBUG - 2016-08-13 08:19:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:19:07 --> Model Class Initialized
INFO - 2016-08-13 08:19:07 --> Model Class Initialized
INFO - 2016-08-13 08:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:19:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:19:08 --> Final output sent to browser
DEBUG - 2016-08-13 08:19:08 --> Total execution time: 0.6493
INFO - 2016-08-13 08:19:17 --> Config Class Initialized
INFO - 2016-08-13 08:19:17 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:19:17 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:19:17 --> Utf8 Class Initialized
INFO - 2016-08-13 08:19:17 --> URI Class Initialized
INFO - 2016-08-13 08:19:17 --> Router Class Initialized
INFO - 2016-08-13 08:19:17 --> Output Class Initialized
INFO - 2016-08-13 08:19:17 --> Security Class Initialized
DEBUG - 2016-08-13 08:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:19:17 --> Input Class Initialized
INFO - 2016-08-13 08:19:17 --> Language Class Initialized
INFO - 2016-08-13 08:19:17 --> Loader Class Initialized
INFO - 2016-08-13 08:19:17 --> Helper loaded: url_helper
INFO - 2016-08-13 08:19:17 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:19:17 --> Helper loaded: html_helper
INFO - 2016-08-13 08:19:17 --> Helper loaded: form_helper
INFO - 2016-08-13 08:19:17 --> Helper loaded: file_helper
INFO - 2016-08-13 08:19:17 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:19:17 --> Database Driver Class Initialized
INFO - 2016-08-13 08:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:19:17 --> Form Validation Class Initialized
INFO - 2016-08-13 08:19:17 --> Email Class Initialized
INFO - 2016-08-13 08:19:17 --> Controller Class Initialized
DEBUG - 2016-08-13 08:19:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:19:17 --> Model Class Initialized
INFO - 2016-08-13 08:19:17 --> Model Class Initialized
INFO - 2016-08-13 08:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:19:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:19:17 --> Final output sent to browser
DEBUG - 2016-08-13 08:19:17 --> Total execution time: 0.4308
INFO - 2016-08-13 08:19:33 --> Config Class Initialized
INFO - 2016-08-13 08:19:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:19:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:19:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:19:33 --> URI Class Initialized
INFO - 2016-08-13 08:19:33 --> Router Class Initialized
INFO - 2016-08-13 08:19:33 --> Output Class Initialized
INFO - 2016-08-13 08:19:33 --> Security Class Initialized
DEBUG - 2016-08-13 08:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:19:33 --> Input Class Initialized
INFO - 2016-08-13 08:19:33 --> Language Class Initialized
INFO - 2016-08-13 08:19:33 --> Loader Class Initialized
INFO - 2016-08-13 08:19:33 --> Helper loaded: url_helper
INFO - 2016-08-13 08:19:33 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:19:33 --> Helper loaded: html_helper
INFO - 2016-08-13 08:19:33 --> Helper loaded: form_helper
INFO - 2016-08-13 08:19:33 --> Helper loaded: file_helper
INFO - 2016-08-13 08:19:33 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:19:33 --> Database Driver Class Initialized
INFO - 2016-08-13 08:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:19:33 --> Form Validation Class Initialized
INFO - 2016-08-13 08:19:33 --> Email Class Initialized
INFO - 2016-08-13 08:19:33 --> Controller Class Initialized
DEBUG - 2016-08-13 08:19:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:19:33 --> Model Class Initialized
INFO - 2016-08-13 08:19:33 --> Model Class Initialized
INFO - 2016-08-13 08:19:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:19:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:19:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:19:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:19:33 --> Final output sent to browser
DEBUG - 2016-08-13 08:19:33 --> Total execution time: 0.5817
INFO - 2016-08-13 08:22:15 --> Config Class Initialized
INFO - 2016-08-13 08:22:15 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:22:15 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:22:15 --> Utf8 Class Initialized
INFO - 2016-08-13 08:22:15 --> URI Class Initialized
INFO - 2016-08-13 08:22:15 --> Router Class Initialized
INFO - 2016-08-13 08:22:15 --> Output Class Initialized
INFO - 2016-08-13 08:22:15 --> Security Class Initialized
DEBUG - 2016-08-13 08:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:22:15 --> Input Class Initialized
INFO - 2016-08-13 08:22:15 --> Language Class Initialized
INFO - 2016-08-13 08:22:15 --> Loader Class Initialized
INFO - 2016-08-13 08:22:15 --> Helper loaded: url_helper
INFO - 2016-08-13 08:22:15 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:22:15 --> Helper loaded: html_helper
INFO - 2016-08-13 08:22:15 --> Helper loaded: form_helper
INFO - 2016-08-13 08:22:15 --> Helper loaded: file_helper
INFO - 2016-08-13 08:22:15 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:22:15 --> Database Driver Class Initialized
INFO - 2016-08-13 08:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:22:15 --> Form Validation Class Initialized
INFO - 2016-08-13 08:22:15 --> Email Class Initialized
INFO - 2016-08-13 08:22:15 --> Controller Class Initialized
DEBUG - 2016-08-13 08:22:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:22:15 --> Model Class Initialized
INFO - 2016-08-13 08:22:15 --> Model Class Initialized
INFO - 2016-08-13 08:22:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:22:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:22:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 08:22:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:22:15 --> Final output sent to browser
DEBUG - 2016-08-13 08:22:15 --> Total execution time: 0.4413
INFO - 2016-08-13 08:22:21 --> Config Class Initialized
INFO - 2016-08-13 08:22:21 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:22:21 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:22:21 --> Utf8 Class Initialized
INFO - 2016-08-13 08:22:21 --> URI Class Initialized
INFO - 2016-08-13 08:22:21 --> Router Class Initialized
INFO - 2016-08-13 08:22:21 --> Output Class Initialized
INFO - 2016-08-13 08:22:21 --> Security Class Initialized
DEBUG - 2016-08-13 08:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:22:21 --> Input Class Initialized
INFO - 2016-08-13 08:22:21 --> Language Class Initialized
INFO - 2016-08-13 08:22:21 --> Loader Class Initialized
INFO - 2016-08-13 08:22:21 --> Helper loaded: url_helper
INFO - 2016-08-13 08:22:21 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:22:21 --> Helper loaded: html_helper
INFO - 2016-08-13 08:22:21 --> Helper loaded: form_helper
INFO - 2016-08-13 08:22:21 --> Helper loaded: file_helper
INFO - 2016-08-13 08:22:21 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:22:21 --> Database Driver Class Initialized
INFO - 2016-08-13 08:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:22:21 --> Form Validation Class Initialized
INFO - 2016-08-13 08:22:21 --> Email Class Initialized
INFO - 2016-08-13 08:22:21 --> Controller Class Initialized
DEBUG - 2016-08-13 08:22:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:22:21 --> Model Class Initialized
INFO - 2016-08-13 08:22:21 --> Model Class Initialized
INFO - 2016-08-13 08:22:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:22:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:22:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-13 08:22:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:22:21 --> Final output sent to browser
DEBUG - 2016-08-13 08:22:21 --> Total execution time: 0.6563
INFO - 2016-08-13 08:23:51 --> Config Class Initialized
INFO - 2016-08-13 08:23:51 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:23:51 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:23:51 --> Utf8 Class Initialized
INFO - 2016-08-13 08:23:51 --> URI Class Initialized
INFO - 2016-08-13 08:23:51 --> Router Class Initialized
INFO - 2016-08-13 08:23:51 --> Output Class Initialized
INFO - 2016-08-13 08:23:51 --> Security Class Initialized
DEBUG - 2016-08-13 08:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:23:51 --> Input Class Initialized
INFO - 2016-08-13 08:23:51 --> Language Class Initialized
INFO - 2016-08-13 08:23:51 --> Loader Class Initialized
INFO - 2016-08-13 08:23:51 --> Helper loaded: url_helper
INFO - 2016-08-13 08:23:51 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:23:51 --> Helper loaded: html_helper
INFO - 2016-08-13 08:23:51 --> Helper loaded: form_helper
INFO - 2016-08-13 08:23:51 --> Helper loaded: file_helper
INFO - 2016-08-13 08:23:51 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:23:51 --> Database Driver Class Initialized
INFO - 2016-08-13 08:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:23:51 --> Form Validation Class Initialized
INFO - 2016-08-13 08:23:51 --> Email Class Initialized
INFO - 2016-08-13 08:23:51 --> Controller Class Initialized
INFO - 2016-08-13 08:23:51 --> Model Class Initialized
INFO - 2016-08-13 08:23:51 --> Model Class Initialized
INFO - 2016-08-13 08:23:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:23:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:23:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-13 08:23:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:23:52 --> Final output sent to browser
DEBUG - 2016-08-13 08:23:52 --> Total execution time: 0.4263
INFO - 2016-08-13 08:24:02 --> Config Class Initialized
INFO - 2016-08-13 08:24:02 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:24:02 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:24:02 --> Utf8 Class Initialized
INFO - 2016-08-13 08:24:02 --> URI Class Initialized
INFO - 2016-08-13 08:24:02 --> Router Class Initialized
INFO - 2016-08-13 08:24:02 --> Output Class Initialized
INFO - 2016-08-13 08:24:02 --> Security Class Initialized
DEBUG - 2016-08-13 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:24:02 --> Input Class Initialized
INFO - 2016-08-13 08:24:02 --> Language Class Initialized
INFO - 2016-08-13 08:24:02 --> Loader Class Initialized
INFO - 2016-08-13 08:24:02 --> Helper loaded: url_helper
INFO - 2016-08-13 08:24:02 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:24:02 --> Helper loaded: html_helper
INFO - 2016-08-13 08:24:02 --> Helper loaded: form_helper
INFO - 2016-08-13 08:24:02 --> Helper loaded: file_helper
INFO - 2016-08-13 08:24:02 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:24:02 --> Database Driver Class Initialized
INFO - 2016-08-13 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:24:02 --> Form Validation Class Initialized
INFO - 2016-08-13 08:24:02 --> Email Class Initialized
INFO - 2016-08-13 08:24:02 --> Controller Class Initialized
DEBUG - 2016-08-13 08:24:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:24:02 --> Model Class Initialized
INFO - 2016-08-13 08:24:02 --> Model Class Initialized
INFO - 2016-08-13 08:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:24:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:24:02 --> Final output sent to browser
DEBUG - 2016-08-13 08:24:02 --> Total execution time: 0.4520
INFO - 2016-08-13 08:27:14 --> Config Class Initialized
INFO - 2016-08-13 08:27:14 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:27:14 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:27:14 --> Utf8 Class Initialized
INFO - 2016-08-13 08:27:14 --> URI Class Initialized
INFO - 2016-08-13 08:27:14 --> Router Class Initialized
INFO - 2016-08-13 08:27:14 --> Output Class Initialized
INFO - 2016-08-13 08:27:14 --> Security Class Initialized
DEBUG - 2016-08-13 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:27:14 --> Input Class Initialized
INFO - 2016-08-13 08:27:15 --> Language Class Initialized
INFO - 2016-08-13 08:27:15 --> Loader Class Initialized
INFO - 2016-08-13 08:27:15 --> Helper loaded: url_helper
INFO - 2016-08-13 08:27:15 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:27:15 --> Helper loaded: html_helper
INFO - 2016-08-13 08:27:15 --> Helper loaded: form_helper
INFO - 2016-08-13 08:27:15 --> Helper loaded: file_helper
INFO - 2016-08-13 08:27:15 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:27:15 --> Database Driver Class Initialized
INFO - 2016-08-13 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:27:15 --> Form Validation Class Initialized
INFO - 2016-08-13 08:27:15 --> Email Class Initialized
INFO - 2016-08-13 08:27:15 --> Controller Class Initialized
DEBUG - 2016-08-13 08:27:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:27:15 --> Model Class Initialized
INFO - 2016-08-13 08:27:15 --> Model Class Initialized
INFO - 2016-08-13 08:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-13 08:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:27:15 --> Final output sent to browser
DEBUG - 2016-08-13 08:27:15 --> Total execution time: 0.9181
INFO - 2016-08-13 08:29:26 --> Config Class Initialized
INFO - 2016-08-13 08:29:26 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:29:26 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:29:26 --> Utf8 Class Initialized
INFO - 2016-08-13 08:29:26 --> URI Class Initialized
INFO - 2016-08-13 08:29:26 --> Router Class Initialized
INFO - 2016-08-13 08:29:26 --> Output Class Initialized
INFO - 2016-08-13 08:29:26 --> Security Class Initialized
DEBUG - 2016-08-13 08:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:29:26 --> Input Class Initialized
INFO - 2016-08-13 08:29:26 --> Language Class Initialized
INFO - 2016-08-13 08:29:26 --> Loader Class Initialized
INFO - 2016-08-13 08:29:26 --> Helper loaded: url_helper
INFO - 2016-08-13 08:29:26 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:29:26 --> Helper loaded: html_helper
INFO - 2016-08-13 08:29:26 --> Helper loaded: form_helper
INFO - 2016-08-13 08:29:26 --> Helper loaded: file_helper
INFO - 2016-08-13 08:29:26 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:29:26 --> Database Driver Class Initialized
INFO - 2016-08-13 08:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:29:26 --> Form Validation Class Initialized
INFO - 2016-08-13 08:29:26 --> Email Class Initialized
INFO - 2016-08-13 08:29:26 --> Controller Class Initialized
DEBUG - 2016-08-13 08:29:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:29:26 --> Model Class Initialized
INFO - 2016-08-13 08:29:26 --> Model Class Initialized
INFO - 2016-08-13 08:29:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:29:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:29:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-13 08:29:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:29:26 --> Final output sent to browser
DEBUG - 2016-08-13 08:29:26 --> Total execution time: 0.4521
INFO - 2016-08-13 08:29:33 --> Config Class Initialized
INFO - 2016-08-13 08:29:33 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:29:33 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:29:33 --> Utf8 Class Initialized
INFO - 2016-08-13 08:29:33 --> URI Class Initialized
INFO - 2016-08-13 08:29:33 --> Router Class Initialized
INFO - 2016-08-13 08:29:33 --> Output Class Initialized
INFO - 2016-08-13 08:29:33 --> Security Class Initialized
DEBUG - 2016-08-13 08:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:29:33 --> Input Class Initialized
INFO - 2016-08-13 08:29:33 --> Language Class Initialized
INFO - 2016-08-13 08:29:33 --> Loader Class Initialized
INFO - 2016-08-13 08:29:34 --> Helper loaded: url_helper
INFO - 2016-08-13 08:29:34 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:29:34 --> Helper loaded: html_helper
INFO - 2016-08-13 08:29:34 --> Helper loaded: form_helper
INFO - 2016-08-13 08:29:34 --> Helper loaded: file_helper
INFO - 2016-08-13 08:29:34 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:29:34 --> Database Driver Class Initialized
INFO - 2016-08-13 08:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:29:34 --> Form Validation Class Initialized
INFO - 2016-08-13 08:29:34 --> Email Class Initialized
INFO - 2016-08-13 08:29:34 --> Controller Class Initialized
DEBUG - 2016-08-13 08:29:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:29:34 --> Model Class Initialized
INFO - 2016-08-13 08:29:34 --> Model Class Initialized
INFO - 2016-08-13 08:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-13 08:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:29:34 --> Final output sent to browser
DEBUG - 2016-08-13 08:29:34 --> Total execution time: 0.4616
INFO - 2016-08-13 08:31:10 --> Config Class Initialized
INFO - 2016-08-13 08:31:10 --> Hooks Class Initialized
DEBUG - 2016-08-13 08:31:10 --> UTF-8 Support Enabled
INFO - 2016-08-13 08:31:10 --> Utf8 Class Initialized
INFO - 2016-08-13 08:31:10 --> URI Class Initialized
INFO - 2016-08-13 08:31:10 --> Router Class Initialized
INFO - 2016-08-13 08:31:10 --> Output Class Initialized
INFO - 2016-08-13 08:31:10 --> Security Class Initialized
DEBUG - 2016-08-13 08:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-13 08:31:10 --> Input Class Initialized
INFO - 2016-08-13 08:31:10 --> Language Class Initialized
INFO - 2016-08-13 08:31:10 --> Loader Class Initialized
INFO - 2016-08-13 08:31:10 --> Helper loaded: url_helper
INFO - 2016-08-13 08:31:10 --> Helper loaded: utils_helper
INFO - 2016-08-13 08:31:10 --> Helper loaded: html_helper
INFO - 2016-08-13 08:31:10 --> Helper loaded: form_helper
INFO - 2016-08-13 08:31:10 --> Helper loaded: file_helper
INFO - 2016-08-13 08:31:10 --> Helper loaded: myemail_helper
INFO - 2016-08-13 08:31:10 --> Database Driver Class Initialized
INFO - 2016-08-13 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-13 08:31:10 --> Form Validation Class Initialized
INFO - 2016-08-13 08:31:10 --> Email Class Initialized
INFO - 2016-08-13 08:31:10 --> Controller Class Initialized
INFO - 2016-08-13 08:31:10 --> Model Class Initialized
INFO - 2016-08-13 08:31:10 --> Model Class Initialized
DEBUG - 2016-08-13 08:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-13 08:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-13 08:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-13 08:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-13 08:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-13 08:31:10 --> Final output sent to browser
DEBUG - 2016-08-13 08:31:10 --> Total execution time: 0.4408
