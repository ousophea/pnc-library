<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-24 02:09:02 --> Config Class Initialized
INFO - 2016-08-24 02:09:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 02:09:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 02:09:02 --> Utf8 Class Initialized
INFO - 2016-08-24 02:09:02 --> URI Class Initialized
INFO - 2016-08-24 02:09:02 --> Router Class Initialized
INFO - 2016-08-24 02:09:02 --> Output Class Initialized
INFO - 2016-08-24 02:09:02 --> Security Class Initialized
DEBUG - 2016-08-24 02:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 02:09:02 --> Input Class Initialized
INFO - 2016-08-24 02:09:02 --> Language Class Initialized
INFO - 2016-08-24 02:09:02 --> Loader Class Initialized
INFO - 2016-08-24 02:09:02 --> Helper loaded: url_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: html_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: form_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: file_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 02:09:02 --> Database Driver Class Initialized
INFO - 2016-08-24 02:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 02:09:02 --> Form Validation Class Initialized
INFO - 2016-08-24 02:09:02 --> Email Class Initialized
INFO - 2016-08-24 02:09:02 --> Controller Class Initialized
INFO - 2016-08-24 02:09:02 --> Config Class Initialized
INFO - 2016-08-24 02:09:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 02:09:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 02:09:02 --> Utf8 Class Initialized
INFO - 2016-08-24 02:09:02 --> URI Class Initialized
INFO - 2016-08-24 02:09:02 --> Router Class Initialized
INFO - 2016-08-24 02:09:02 --> Output Class Initialized
INFO - 2016-08-24 02:09:02 --> Security Class Initialized
DEBUG - 2016-08-24 02:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 02:09:02 --> Input Class Initialized
INFO - 2016-08-24 02:09:02 --> Language Class Initialized
INFO - 2016-08-24 02:09:02 --> Loader Class Initialized
INFO - 2016-08-24 02:09:02 --> Helper loaded: url_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: html_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: form_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: file_helper
INFO - 2016-08-24 02:09:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 02:09:02 --> Database Driver Class Initialized
INFO - 2016-08-24 02:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 02:09:02 --> Form Validation Class Initialized
INFO - 2016-08-24 02:09:02 --> Email Class Initialized
INFO - 2016-08-24 02:09:02 --> Controller Class Initialized
INFO - 2016-08-24 02:09:02 --> Model Class Initialized
DEBUG - 2016-08-24 02:09:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 02:09:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 02:09:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 02:09:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 02:09:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 02:09:02 --> Final output sent to browser
DEBUG - 2016-08-24 02:09:02 --> Total execution time: 0.2158
INFO - 2016-08-24 02:09:10 --> Config Class Initialized
INFO - 2016-08-24 02:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 02:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 02:09:10 --> Utf8 Class Initialized
INFO - 2016-08-24 02:09:10 --> URI Class Initialized
INFO - 2016-08-24 02:09:10 --> Router Class Initialized
INFO - 2016-08-24 02:09:10 --> Output Class Initialized
INFO - 2016-08-24 02:09:10 --> Security Class Initialized
DEBUG - 2016-08-24 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 02:09:10 --> Input Class Initialized
INFO - 2016-08-24 02:09:10 --> Language Class Initialized
INFO - 2016-08-24 02:09:10 --> Loader Class Initialized
INFO - 2016-08-24 02:09:10 --> Helper loaded: url_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: html_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: form_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: file_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 02:09:10 --> Database Driver Class Initialized
INFO - 2016-08-24 02:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 02:09:10 --> Form Validation Class Initialized
INFO - 2016-08-24 02:09:10 --> Email Class Initialized
INFO - 2016-08-24 02:09:10 --> Controller Class Initialized
INFO - 2016-08-24 02:09:10 --> Model Class Initialized
DEBUG - 2016-08-24 02:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 02:09:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 02:09:10 --> Config Class Initialized
INFO - 2016-08-24 02:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 02:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 02:09:10 --> Utf8 Class Initialized
INFO - 2016-08-24 02:09:10 --> URI Class Initialized
INFO - 2016-08-24 02:09:10 --> Router Class Initialized
INFO - 2016-08-24 02:09:10 --> Output Class Initialized
INFO - 2016-08-24 02:09:10 --> Security Class Initialized
DEBUG - 2016-08-24 02:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 02:09:10 --> Input Class Initialized
INFO - 2016-08-24 02:09:10 --> Language Class Initialized
INFO - 2016-08-24 02:09:10 --> Loader Class Initialized
INFO - 2016-08-24 02:09:10 --> Helper loaded: url_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: html_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: form_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: file_helper
INFO - 2016-08-24 02:09:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 02:09:10 --> Database Driver Class Initialized
INFO - 2016-08-24 02:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 02:09:10 --> Form Validation Class Initialized
INFO - 2016-08-24 02:09:10 --> Email Class Initialized
INFO - 2016-08-24 02:09:10 --> Controller Class Initialized
DEBUG - 2016-08-24 02:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 02:09:10 --> Model Class Initialized
INFO - 2016-08-24 02:09:10 --> Model Class Initialized
INFO - 2016-08-24 02:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 02:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 02:09:10 --> Model Class Initialized
ERROR - 2016-08-24 02:09:10 --> Severity: Notice --> Undefined index: name D:\wamp\www\library.pnc.lan\application\views\users\borrow_list.php 10
INFO - 2016-08-24 02:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-24 02:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 02:09:10 --> Final output sent to browser
DEBUG - 2016-08-24 02:09:10 --> Total execution time: 0.2924
INFO - 2016-08-24 02:24:47 --> Config Class Initialized
INFO - 2016-08-24 02:24:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 02:24:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 02:24:47 --> Utf8 Class Initialized
INFO - 2016-08-24 02:24:47 --> URI Class Initialized
DEBUG - 2016-08-24 02:24:47 --> No URI present. Default controller set.
INFO - 2016-08-24 02:24:47 --> Router Class Initialized
INFO - 2016-08-24 02:24:47 --> Output Class Initialized
INFO - 2016-08-24 02:24:47 --> Security Class Initialized
DEBUG - 2016-08-24 02:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 02:24:47 --> Input Class Initialized
INFO - 2016-08-24 02:24:47 --> Language Class Initialized
INFO - 2016-08-24 02:24:47 --> Loader Class Initialized
INFO - 2016-08-24 02:24:47 --> Helper loaded: url_helper
INFO - 2016-08-24 02:24:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 02:24:47 --> Helper loaded: html_helper
INFO - 2016-08-24 02:24:47 --> Helper loaded: form_helper
INFO - 2016-08-24 02:24:47 --> Helper loaded: file_helper
INFO - 2016-08-24 02:24:47 --> Helper loaded: myemail_helper
INFO - 2016-08-24 02:24:47 --> Database Driver Class Initialized
INFO - 2016-08-24 02:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 02:24:47 --> Form Validation Class Initialized
INFO - 2016-08-24 02:24:47 --> Email Class Initialized
INFO - 2016-08-24 02:24:47 --> Controller Class Initialized
INFO - 2016-08-24 02:24:47 --> Model Class Initialized
INFO - 2016-08-24 02:24:47 --> Model Class Initialized
INFO - 2016-08-24 02:24:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 02:24:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 02:24:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 02:24:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 02:24:47 --> Final output sent to browser
DEBUG - 2016-08-24 02:24:47 --> Total execution time: 0.2143
INFO - 2016-08-24 03:39:29 --> Config Class Initialized
INFO - 2016-08-24 03:39:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:39:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:39:29 --> Utf8 Class Initialized
INFO - 2016-08-24 03:39:29 --> URI Class Initialized
DEBUG - 2016-08-24 03:39:29 --> No URI present. Default controller set.
INFO - 2016-08-24 03:39:29 --> Router Class Initialized
INFO - 2016-08-24 03:39:29 --> Output Class Initialized
INFO - 2016-08-24 03:39:29 --> Security Class Initialized
DEBUG - 2016-08-24 03:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:39:29 --> Input Class Initialized
INFO - 2016-08-24 03:39:29 --> Language Class Initialized
INFO - 2016-08-24 03:39:29 --> Loader Class Initialized
INFO - 2016-08-24 03:39:29 --> Helper loaded: url_helper
INFO - 2016-08-24 03:39:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:39:29 --> Helper loaded: html_helper
INFO - 2016-08-24 03:39:29 --> Helper loaded: form_helper
INFO - 2016-08-24 03:39:29 --> Helper loaded: file_helper
INFO - 2016-08-24 03:39:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:39:29 --> Database Driver Class Initialized
INFO - 2016-08-24 03:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:39:29 --> Form Validation Class Initialized
INFO - 2016-08-24 03:39:29 --> Email Class Initialized
INFO - 2016-08-24 03:39:29 --> Controller Class Initialized
INFO - 2016-08-24 03:40:00 --> Config Class Initialized
INFO - 2016-08-24 03:40:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:00 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:00 --> URI Class Initialized
DEBUG - 2016-08-24 03:40:00 --> No URI present. Default controller set.
INFO - 2016-08-24 03:40:00 --> Router Class Initialized
INFO - 2016-08-24 03:40:00 --> Output Class Initialized
INFO - 2016-08-24 03:40:00 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:00 --> Input Class Initialized
INFO - 2016-08-24 03:40:00 --> Language Class Initialized
INFO - 2016-08-24 03:40:00 --> Loader Class Initialized
INFO - 2016-08-24 03:40:00 --> Helper loaded: url_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: html_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: form_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: file_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:40:00 --> Database Driver Class Initialized
INFO - 2016-08-24 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:40:00 --> Form Validation Class Initialized
INFO - 2016-08-24 03:40:00 --> Email Class Initialized
INFO - 2016-08-24 03:40:00 --> Controller Class Initialized
INFO - 2016-08-24 03:40:00 --> Config Class Initialized
INFO - 2016-08-24 03:40:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:00 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:00 --> URI Class Initialized
INFO - 2016-08-24 03:40:00 --> Router Class Initialized
INFO - 2016-08-24 03:40:00 --> Output Class Initialized
INFO - 2016-08-24 03:40:00 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:00 --> Input Class Initialized
INFO - 2016-08-24 03:40:00 --> Language Class Initialized
INFO - 2016-08-24 03:40:00 --> Loader Class Initialized
INFO - 2016-08-24 03:40:00 --> Helper loaded: url_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: html_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: form_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: file_helper
INFO - 2016-08-24 03:40:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:40:00 --> Database Driver Class Initialized
INFO - 2016-08-24 03:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:40:00 --> Form Validation Class Initialized
INFO - 2016-08-24 03:40:00 --> Email Class Initialized
INFO - 2016-08-24 03:40:00 --> Controller Class Initialized
INFO - 2016-08-24 03:40:00 --> Model Class Initialized
DEBUG - 2016-08-24 03:40:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 03:40:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 03:40:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 03:40:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 03:40:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 03:40:00 --> Final output sent to browser
DEBUG - 2016-08-24 03:40:00 --> Total execution time: 0.2061
INFO - 2016-08-24 03:40:01 --> Config Class Initialized
INFO - 2016-08-24 03:40:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:01 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:01 --> URI Class Initialized
INFO - 2016-08-24 03:40:01 --> Router Class Initialized
INFO - 2016-08-24 03:40:01 --> Output Class Initialized
INFO - 2016-08-24 03:40:01 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:01 --> Input Class Initialized
INFO - 2016-08-24 03:40:01 --> Language Class Initialized
ERROR - 2016-08-24 03:40:01 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-24 03:40:01 --> Config Class Initialized
INFO - 2016-08-24 03:40:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:01 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:01 --> URI Class Initialized
INFO - 2016-08-24 03:40:01 --> Router Class Initialized
INFO - 2016-08-24 03:40:01 --> Output Class Initialized
INFO - 2016-08-24 03:40:01 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:01 --> Input Class Initialized
INFO - 2016-08-24 03:40:01 --> Language Class Initialized
ERROR - 2016-08-24 03:40:01 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-24 03:40:08 --> Config Class Initialized
INFO - 2016-08-24 03:40:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:08 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:08 --> URI Class Initialized
INFO - 2016-08-24 03:40:08 --> Router Class Initialized
INFO - 2016-08-24 03:40:08 --> Output Class Initialized
INFO - 2016-08-24 03:40:08 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:08 --> Input Class Initialized
INFO - 2016-08-24 03:40:08 --> Language Class Initialized
INFO - 2016-08-24 03:40:08 --> Loader Class Initialized
INFO - 2016-08-24 03:40:08 --> Helper loaded: url_helper
INFO - 2016-08-24 03:40:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:40:08 --> Helper loaded: html_helper
INFO - 2016-08-24 03:40:08 --> Helper loaded: form_helper
INFO - 2016-08-24 03:40:08 --> Helper loaded: file_helper
INFO - 2016-08-24 03:40:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:40:08 --> Database Driver Class Initialized
INFO - 2016-08-24 03:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:40:08 --> Form Validation Class Initialized
INFO - 2016-08-24 03:40:08 --> Email Class Initialized
INFO - 2016-08-24 03:40:08 --> Controller Class Initialized
INFO - 2016-08-24 03:40:08 --> Model Class Initialized
DEBUG - 2016-08-24 03:40:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 03:40:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 03:40:08 --> Config Class Initialized
INFO - 2016-08-24 03:40:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:40:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:40:08 --> Utf8 Class Initialized
INFO - 2016-08-24 03:40:08 --> URI Class Initialized
DEBUG - 2016-08-24 03:40:08 --> No URI present. Default controller set.
INFO - 2016-08-24 03:40:08 --> Router Class Initialized
INFO - 2016-08-24 03:40:08 --> Output Class Initialized
INFO - 2016-08-24 03:40:08 --> Security Class Initialized
DEBUG - 2016-08-24 03:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:40:08 --> Input Class Initialized
INFO - 2016-08-24 03:40:08 --> Language Class Initialized
INFO - 2016-08-24 03:40:08 --> Loader Class Initialized
INFO - 2016-08-24 03:40:09 --> Helper loaded: url_helper
INFO - 2016-08-24 03:40:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:40:09 --> Helper loaded: html_helper
INFO - 2016-08-24 03:40:09 --> Helper loaded: form_helper
INFO - 2016-08-24 03:40:09 --> Helper loaded: file_helper
INFO - 2016-08-24 03:40:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:40:09 --> Database Driver Class Initialized
INFO - 2016-08-24 03:40:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:40:09 --> Form Validation Class Initialized
INFO - 2016-08-24 03:40:09 --> Email Class Initialized
INFO - 2016-08-24 03:40:09 --> Controller Class Initialized
INFO - 2016-08-24 03:40:09 --> Model Class Initialized
INFO - 2016-08-24 03:40:09 --> Model Class Initialized
INFO - 2016-08-24 03:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 03:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 03:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 03:40:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 03:40:09 --> Final output sent to browser
DEBUG - 2016-08-24 03:40:09 --> Total execution time: 0.2194
INFO - 2016-08-24 03:41:00 --> Config Class Initialized
INFO - 2016-08-24 03:41:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:41:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:41:00 --> Utf8 Class Initialized
INFO - 2016-08-24 03:41:00 --> URI Class Initialized
DEBUG - 2016-08-24 03:41:00 --> No URI present. Default controller set.
INFO - 2016-08-24 03:41:00 --> Router Class Initialized
INFO - 2016-08-24 03:41:00 --> Output Class Initialized
INFO - 2016-08-24 03:41:00 --> Security Class Initialized
DEBUG - 2016-08-24 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:41:00 --> Input Class Initialized
INFO - 2016-08-24 03:41:00 --> Language Class Initialized
INFO - 2016-08-24 03:41:00 --> Loader Class Initialized
INFO - 2016-08-24 03:41:00 --> Helper loaded: url_helper
INFO - 2016-08-24 03:41:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:41:00 --> Helper loaded: html_helper
INFO - 2016-08-24 03:41:00 --> Helper loaded: form_helper
INFO - 2016-08-24 03:41:00 --> Helper loaded: file_helper
INFO - 2016-08-24 03:41:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:41:00 --> Database Driver Class Initialized
INFO - 2016-08-24 03:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:41:00 --> Form Validation Class Initialized
INFO - 2016-08-24 03:41:00 --> Email Class Initialized
INFO - 2016-08-24 03:41:00 --> Controller Class Initialized
INFO - 2016-08-24 03:41:00 --> Model Class Initialized
INFO - 2016-08-24 03:41:00 --> Model Class Initialized
INFO - 2016-08-24 03:41:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 03:41:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 03:41:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 03:41:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 03:41:00 --> Final output sent to browser
DEBUG - 2016-08-24 03:41:00 --> Total execution time: 0.2205
INFO - 2016-08-24 03:41:08 --> Config Class Initialized
INFO - 2016-08-24 03:41:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:41:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:41:08 --> Utf8 Class Initialized
INFO - 2016-08-24 03:41:08 --> URI Class Initialized
INFO - 2016-08-24 03:41:08 --> Router Class Initialized
INFO - 2016-08-24 03:41:08 --> Output Class Initialized
INFO - 2016-08-24 03:41:08 --> Security Class Initialized
DEBUG - 2016-08-24 03:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:41:08 --> Input Class Initialized
INFO - 2016-08-24 03:41:08 --> Language Class Initialized
INFO - 2016-08-24 03:41:08 --> Loader Class Initialized
INFO - 2016-08-24 03:41:08 --> Helper loaded: url_helper
INFO - 2016-08-24 03:41:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:41:08 --> Helper loaded: html_helper
INFO - 2016-08-24 03:41:08 --> Helper loaded: form_helper
INFO - 2016-08-24 03:41:08 --> Helper loaded: file_helper
INFO - 2016-08-24 03:41:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:41:08 --> Database Driver Class Initialized
INFO - 2016-08-24 03:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:41:08 --> Form Validation Class Initialized
INFO - 2016-08-24 03:41:08 --> Email Class Initialized
INFO - 2016-08-24 03:41:08 --> Controller Class Initialized
INFO - 2016-08-24 03:41:08 --> Model Class Initialized
INFO - 2016-08-24 03:41:08 --> Config Class Initialized
INFO - 2016-08-24 03:41:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:41:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:41:08 --> Utf8 Class Initialized
INFO - 2016-08-24 03:41:08 --> URI Class Initialized
INFO - 2016-08-24 03:41:08 --> Router Class Initialized
INFO - 2016-08-24 03:41:08 --> Output Class Initialized
INFO - 2016-08-24 03:41:09 --> Security Class Initialized
DEBUG - 2016-08-24 03:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:41:09 --> Input Class Initialized
INFO - 2016-08-24 03:41:09 --> Language Class Initialized
INFO - 2016-08-24 03:41:09 --> Loader Class Initialized
INFO - 2016-08-24 03:41:09 --> Helper loaded: url_helper
INFO - 2016-08-24 03:41:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:41:09 --> Helper loaded: html_helper
INFO - 2016-08-24 03:41:09 --> Helper loaded: form_helper
INFO - 2016-08-24 03:41:09 --> Helper loaded: file_helper
INFO - 2016-08-24 03:41:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:41:09 --> Database Driver Class Initialized
INFO - 2016-08-24 03:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:41:09 --> Form Validation Class Initialized
INFO - 2016-08-24 03:41:09 --> Email Class Initialized
INFO - 2016-08-24 03:41:09 --> Controller Class Initialized
INFO - 2016-08-24 03:41:09 --> Model Class Initialized
DEBUG - 2016-08-24 03:41:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 03:41:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 03:41:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 03:41:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 03:41:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 03:41:09 --> Final output sent to browser
DEBUG - 2016-08-24 03:41:09 --> Total execution time: 0.2149
INFO - 2016-08-24 03:42:51 --> Config Class Initialized
INFO - 2016-08-24 03:42:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:42:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:42:51 --> Utf8 Class Initialized
INFO - 2016-08-24 03:42:51 --> URI Class Initialized
INFO - 2016-08-24 03:42:51 --> Router Class Initialized
INFO - 2016-08-24 03:42:51 --> Output Class Initialized
INFO - 2016-08-24 03:42:51 --> Security Class Initialized
DEBUG - 2016-08-24 03:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:42:51 --> Input Class Initialized
INFO - 2016-08-24 03:42:51 --> Language Class Initialized
INFO - 2016-08-24 03:42:51 --> Loader Class Initialized
INFO - 2016-08-24 03:42:51 --> Helper loaded: url_helper
INFO - 2016-08-24 03:42:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:42:51 --> Helper loaded: html_helper
INFO - 2016-08-24 03:42:51 --> Helper loaded: form_helper
INFO - 2016-08-24 03:42:51 --> Helper loaded: file_helper
INFO - 2016-08-24 03:42:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:42:51 --> Database Driver Class Initialized
INFO - 2016-08-24 03:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:42:51 --> Form Validation Class Initialized
INFO - 2016-08-24 03:42:51 --> Email Class Initialized
INFO - 2016-08-24 03:42:51 --> Controller Class Initialized
INFO - 2016-08-24 03:42:51 --> Model Class Initialized
DEBUG - 2016-08-24 03:42:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 03:42:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 03:42:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 03:42:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 03:42:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 03:42:51 --> Final output sent to browser
DEBUG - 2016-08-24 03:42:51 --> Total execution time: 0.2309
INFO - 2016-08-24 03:42:54 --> Config Class Initialized
INFO - 2016-08-24 03:42:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:42:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:42:54 --> Utf8 Class Initialized
INFO - 2016-08-24 03:42:54 --> URI Class Initialized
INFO - 2016-08-24 03:42:54 --> Router Class Initialized
INFO - 2016-08-24 03:42:54 --> Output Class Initialized
INFO - 2016-08-24 03:42:54 --> Security Class Initialized
DEBUG - 2016-08-24 03:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:42:54 --> Input Class Initialized
INFO - 2016-08-24 03:42:54 --> Language Class Initialized
INFO - 2016-08-24 03:42:54 --> Loader Class Initialized
INFO - 2016-08-24 03:42:54 --> Helper loaded: url_helper
INFO - 2016-08-24 03:42:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:42:54 --> Helper loaded: html_helper
INFO - 2016-08-24 03:42:54 --> Helper loaded: form_helper
INFO - 2016-08-24 03:42:54 --> Helper loaded: file_helper
INFO - 2016-08-24 03:42:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:42:54 --> Database Driver Class Initialized
INFO - 2016-08-24 03:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:42:54 --> Form Validation Class Initialized
INFO - 2016-08-24 03:42:54 --> Email Class Initialized
INFO - 2016-08-24 03:42:54 --> Controller Class Initialized
INFO - 2016-08-24 03:42:54 --> Model Class Initialized
ERROR - 2016-08-24 03:42:54 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 03:42:54 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 03:46:12 --> Config Class Initialized
INFO - 2016-08-24 03:46:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:46:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:46:12 --> Utf8 Class Initialized
INFO - 2016-08-24 03:46:12 --> URI Class Initialized
INFO - 2016-08-24 03:46:12 --> Router Class Initialized
INFO - 2016-08-24 03:46:12 --> Output Class Initialized
INFO - 2016-08-24 03:46:12 --> Security Class Initialized
DEBUG - 2016-08-24 03:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:46:12 --> Input Class Initialized
INFO - 2016-08-24 03:46:12 --> Language Class Initialized
INFO - 2016-08-24 03:46:12 --> Loader Class Initialized
INFO - 2016-08-24 03:46:12 --> Helper loaded: url_helper
INFO - 2016-08-24 03:46:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:46:12 --> Helper loaded: html_helper
INFO - 2016-08-24 03:46:12 --> Helper loaded: form_helper
INFO - 2016-08-24 03:46:12 --> Helper loaded: file_helper
INFO - 2016-08-24 03:46:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:46:12 --> Database Driver Class Initialized
INFO - 2016-08-24 03:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:46:12 --> Form Validation Class Initialized
INFO - 2016-08-24 03:46:12 --> Email Class Initialized
INFO - 2016-08-24 03:46:12 --> Controller Class Initialized
INFO - 2016-08-24 03:46:12 --> Model Class Initialized
ERROR - 2016-08-24 03:46:12 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 03:46:12 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 03:46:13 --> Config Class Initialized
INFO - 2016-08-24 03:46:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 03:46:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 03:46:14 --> Utf8 Class Initialized
INFO - 2016-08-24 03:46:14 --> URI Class Initialized
INFO - 2016-08-24 03:46:14 --> Router Class Initialized
INFO - 2016-08-24 03:46:14 --> Output Class Initialized
INFO - 2016-08-24 03:46:14 --> Security Class Initialized
DEBUG - 2016-08-24 03:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 03:46:14 --> Input Class Initialized
INFO - 2016-08-24 03:46:14 --> Language Class Initialized
INFO - 2016-08-24 03:46:14 --> Loader Class Initialized
INFO - 2016-08-24 03:46:14 --> Helper loaded: url_helper
INFO - 2016-08-24 03:46:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 03:46:14 --> Helper loaded: html_helper
INFO - 2016-08-24 03:46:14 --> Helper loaded: form_helper
INFO - 2016-08-24 03:46:14 --> Helper loaded: file_helper
INFO - 2016-08-24 03:46:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 03:46:14 --> Database Driver Class Initialized
INFO - 2016-08-24 03:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 03:46:14 --> Form Validation Class Initialized
INFO - 2016-08-24 03:46:14 --> Email Class Initialized
INFO - 2016-08-24 03:46:14 --> Controller Class Initialized
INFO - 2016-08-24 03:46:14 --> Model Class Initialized
ERROR - 2016-08-24 03:46:14 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 03:46:14 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 04:39:15 --> Config Class Initialized
INFO - 2016-08-24 04:39:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:39:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:39:15 --> Utf8 Class Initialized
INFO - 2016-08-24 04:39:15 --> URI Class Initialized
INFO - 2016-08-24 04:39:15 --> Router Class Initialized
INFO - 2016-08-24 04:39:15 --> Output Class Initialized
INFO - 2016-08-24 04:39:15 --> Security Class Initialized
DEBUG - 2016-08-24 04:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:39:15 --> Input Class Initialized
INFO - 2016-08-24 04:39:15 --> Language Class Initialized
INFO - 2016-08-24 04:39:15 --> Loader Class Initialized
INFO - 2016-08-24 04:39:15 --> Helper loaded: url_helper
INFO - 2016-08-24 04:39:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:39:15 --> Helper loaded: html_helper
INFO - 2016-08-24 04:39:15 --> Helper loaded: form_helper
INFO - 2016-08-24 04:39:15 --> Helper loaded: file_helper
INFO - 2016-08-24 04:39:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:39:15 --> Database Driver Class Initialized
INFO - 2016-08-24 04:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:39:15 --> Form Validation Class Initialized
INFO - 2016-08-24 04:39:15 --> Email Class Initialized
INFO - 2016-08-24 04:39:15 --> Controller Class Initialized
INFO - 2016-08-24 04:39:15 --> Model Class Initialized
ERROR - 2016-08-24 04:39:15 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 04:39:15 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 04:39:17 --> Config Class Initialized
INFO - 2016-08-24 04:39:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:39:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:39:17 --> Utf8 Class Initialized
INFO - 2016-08-24 04:39:17 --> URI Class Initialized
INFO - 2016-08-24 04:39:17 --> Router Class Initialized
INFO - 2016-08-24 04:39:17 --> Output Class Initialized
INFO - 2016-08-24 04:39:17 --> Security Class Initialized
DEBUG - 2016-08-24 04:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:39:17 --> Input Class Initialized
INFO - 2016-08-24 04:39:17 --> Language Class Initialized
INFO - 2016-08-24 04:39:17 --> Loader Class Initialized
INFO - 2016-08-24 04:39:17 --> Helper loaded: url_helper
INFO - 2016-08-24 04:39:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:39:17 --> Helper loaded: html_helper
INFO - 2016-08-24 04:39:17 --> Helper loaded: form_helper
INFO - 2016-08-24 04:39:17 --> Helper loaded: file_helper
INFO - 2016-08-24 04:39:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:39:17 --> Database Driver Class Initialized
INFO - 2016-08-24 04:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:39:17 --> Form Validation Class Initialized
INFO - 2016-08-24 04:39:17 --> Email Class Initialized
INFO - 2016-08-24 04:39:17 --> Controller Class Initialized
INFO - 2016-08-24 04:39:17 --> Model Class Initialized
ERROR - 2016-08-24 04:39:17 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 04:39:17 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 04:44:14 --> Config Class Initialized
INFO - 2016-08-24 04:44:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:14 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:14 --> URI Class Initialized
INFO - 2016-08-24 04:44:14 --> Router Class Initialized
INFO - 2016-08-24 04:44:14 --> Output Class Initialized
INFO - 2016-08-24 04:44:14 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:14 --> Input Class Initialized
INFO - 2016-08-24 04:44:14 --> Language Class Initialized
INFO - 2016-08-24 04:44:14 --> Loader Class Initialized
INFO - 2016-08-24 04:44:14 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:14 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:14 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:14 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:14 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:14 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:14 --> Email Class Initialized
INFO - 2016-08-24 04:44:14 --> Controller Class Initialized
INFO - 2016-08-24 04:44:14 --> Model Class Initialized
DEBUG - 2016-08-24 04:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 04:44:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 04:44:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:14 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:14 --> Total execution time: 0.2717
INFO - 2016-08-24 04:44:22 --> Config Class Initialized
INFO - 2016-08-24 04:44:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:22 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:22 --> URI Class Initialized
INFO - 2016-08-24 04:44:22 --> Router Class Initialized
INFO - 2016-08-24 04:44:22 --> Output Class Initialized
INFO - 2016-08-24 04:44:22 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:22 --> Input Class Initialized
INFO - 2016-08-24 04:44:22 --> Language Class Initialized
INFO - 2016-08-24 04:44:22 --> Loader Class Initialized
INFO - 2016-08-24 04:44:22 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:22 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:22 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:22 --> Email Class Initialized
INFO - 2016-08-24 04:44:22 --> Controller Class Initialized
INFO - 2016-08-24 04:44:22 --> Model Class Initialized
DEBUG - 2016-08-24 04:44:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 04:44:22 --> Config Class Initialized
INFO - 2016-08-24 04:44:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:22 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:22 --> URI Class Initialized
INFO - 2016-08-24 04:44:22 --> Router Class Initialized
INFO - 2016-08-24 04:44:22 --> Output Class Initialized
INFO - 2016-08-24 04:44:22 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:22 --> Input Class Initialized
INFO - 2016-08-24 04:44:22 --> Language Class Initialized
INFO - 2016-08-24 04:44:22 --> Loader Class Initialized
INFO - 2016-08-24 04:44:22 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:22 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:22 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:22 --> Email Class Initialized
INFO - 2016-08-24 04:44:22 --> Controller Class Initialized
DEBUG - 2016-08-24 04:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 04:44:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:22 --> Model Class Initialized
INFO - 2016-08-24 04:44:23 --> Model Class Initialized
INFO - 2016-08-24 04:44:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 04:44:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:23 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:23 --> Total execution time: 0.4385
INFO - 2016-08-24 04:44:25 --> Config Class Initialized
INFO - 2016-08-24 04:44:25 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:25 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:25 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:25 --> URI Class Initialized
INFO - 2016-08-24 04:44:25 --> Router Class Initialized
INFO - 2016-08-24 04:44:26 --> Output Class Initialized
INFO - 2016-08-24 04:44:26 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:26 --> Input Class Initialized
INFO - 2016-08-24 04:44:26 --> Language Class Initialized
INFO - 2016-08-24 04:44:26 --> Loader Class Initialized
INFO - 2016-08-24 04:44:26 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:26 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:26 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:26 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:26 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:26 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:26 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:26 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:26 --> Email Class Initialized
INFO - 2016-08-24 04:44:26 --> Controller Class Initialized
DEBUG - 2016-08-24 04:44:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:26 --> Model Class Initialized
INFO - 2016-08-24 04:44:26 --> Model Class Initialized
INFO - 2016-08-24 04:44:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-24 04:44:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:26 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:26 --> Total execution time: 0.3623
INFO - 2016-08-24 04:44:29 --> Config Class Initialized
INFO - 2016-08-24 04:44:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:29 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:29 --> URI Class Initialized
INFO - 2016-08-24 04:44:29 --> Router Class Initialized
INFO - 2016-08-24 04:44:29 --> Output Class Initialized
INFO - 2016-08-24 04:44:29 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:29 --> Input Class Initialized
INFO - 2016-08-24 04:44:29 --> Language Class Initialized
INFO - 2016-08-24 04:44:29 --> Loader Class Initialized
INFO - 2016-08-24 04:44:29 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:29 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:29 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:29 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:29 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:29 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:29 --> Email Class Initialized
INFO - 2016-08-24 04:44:29 --> Controller Class Initialized
DEBUG - 2016-08-24 04:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:29 --> Model Class Initialized
INFO - 2016-08-24 04:44:29 --> Model Class Initialized
INFO - 2016-08-24 04:44:29 --> Model Class Initialized
INFO - 2016-08-24 04:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-24 04:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:29 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:29 --> Total execution time: 0.2636
INFO - 2016-08-24 04:44:35 --> Config Class Initialized
INFO - 2016-08-24 04:44:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:35 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:35 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:35 --> URI Class Initialized
INFO - 2016-08-24 04:44:35 --> Router Class Initialized
INFO - 2016-08-24 04:44:35 --> Output Class Initialized
INFO - 2016-08-24 04:44:35 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:35 --> Input Class Initialized
INFO - 2016-08-24 04:44:35 --> Language Class Initialized
INFO - 2016-08-24 04:44:35 --> Loader Class Initialized
INFO - 2016-08-24 04:44:35 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:36 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:36 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:36 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:36 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:36 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:36 --> Email Class Initialized
INFO - 2016-08-24 04:44:36 --> Controller Class Initialized
INFO - 2016-08-24 04:44:36 --> Model Class Initialized
INFO - 2016-08-24 04:44:36 --> Model Class Initialized
DEBUG - 2016-08-24 04:44:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-24 04:44:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:36 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:36 --> Total execution time: 0.2965
INFO - 2016-08-24 04:44:39 --> Config Class Initialized
INFO - 2016-08-24 04:44:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:39 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:39 --> URI Class Initialized
INFO - 2016-08-24 04:44:39 --> Router Class Initialized
INFO - 2016-08-24 04:44:39 --> Output Class Initialized
INFO - 2016-08-24 04:44:39 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:39 --> Input Class Initialized
INFO - 2016-08-24 04:44:39 --> Language Class Initialized
INFO - 2016-08-24 04:44:39 --> Loader Class Initialized
INFO - 2016-08-24 04:44:39 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:39 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:39 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:39 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:39 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:39 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:39 --> Email Class Initialized
INFO - 2016-08-24 04:44:39 --> Controller Class Initialized
INFO - 2016-08-24 04:44:39 --> Model Class Initialized
INFO - 2016-08-24 04:44:39 --> Model Class Initialized
DEBUG - 2016-08-24 04:44:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-24 04:44:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:39 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:39 --> Total execution time: 0.2579
INFO - 2016-08-24 04:44:43 --> Config Class Initialized
INFO - 2016-08-24 04:44:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:43 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:43 --> URI Class Initialized
INFO - 2016-08-24 04:44:43 --> Router Class Initialized
INFO - 2016-08-24 04:44:43 --> Output Class Initialized
INFO - 2016-08-24 04:44:43 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:44 --> Input Class Initialized
INFO - 2016-08-24 04:44:44 --> Language Class Initialized
INFO - 2016-08-24 04:44:44 --> Loader Class Initialized
INFO - 2016-08-24 04:44:44 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:44 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:44 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:44 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:44 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:44 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:44 --> Email Class Initialized
INFO - 2016-08-24 04:44:44 --> Controller Class Initialized
INFO - 2016-08-24 04:44:44 --> Model Class Initialized
INFO - 2016-08-24 04:44:44 --> Model Class Initialized
DEBUG - 2016-08-24 04:44:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-24 04:44:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:44 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:44 --> Total execution time: 0.2658
INFO - 2016-08-24 04:44:46 --> Config Class Initialized
INFO - 2016-08-24 04:44:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:46 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:46 --> URI Class Initialized
INFO - 2016-08-24 04:44:46 --> Router Class Initialized
INFO - 2016-08-24 04:44:46 --> Output Class Initialized
INFO - 2016-08-24 04:44:46 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:46 --> Input Class Initialized
INFO - 2016-08-24 04:44:46 --> Language Class Initialized
INFO - 2016-08-24 04:44:46 --> Loader Class Initialized
INFO - 2016-08-24 04:44:46 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:46 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:46 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:46 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:46 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:46 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:46 --> Email Class Initialized
INFO - 2016-08-24 04:44:46 --> Controller Class Initialized
DEBUG - 2016-08-24 04:44:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:46 --> Model Class Initialized
INFO - 2016-08-24 04:44:46 --> Model Class Initialized
INFO - 2016-08-24 04:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-24 04:44:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:46 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:46 --> Total execution time: 0.2666
INFO - 2016-08-24 04:44:49 --> Config Class Initialized
INFO - 2016-08-24 04:44:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:44:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:44:49 --> Utf8 Class Initialized
INFO - 2016-08-24 04:44:49 --> URI Class Initialized
INFO - 2016-08-24 04:44:49 --> Router Class Initialized
INFO - 2016-08-24 04:44:49 --> Output Class Initialized
INFO - 2016-08-24 04:44:49 --> Security Class Initialized
DEBUG - 2016-08-24 04:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:44:49 --> Input Class Initialized
INFO - 2016-08-24 04:44:49 --> Language Class Initialized
INFO - 2016-08-24 04:44:49 --> Loader Class Initialized
INFO - 2016-08-24 04:44:49 --> Helper loaded: url_helper
INFO - 2016-08-24 04:44:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:44:49 --> Helper loaded: html_helper
INFO - 2016-08-24 04:44:49 --> Helper loaded: form_helper
INFO - 2016-08-24 04:44:49 --> Helper loaded: file_helper
INFO - 2016-08-24 04:44:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:44:49 --> Database Driver Class Initialized
INFO - 2016-08-24 04:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:44:49 --> Form Validation Class Initialized
INFO - 2016-08-24 04:44:49 --> Email Class Initialized
INFO - 2016-08-24 04:44:49 --> Controller Class Initialized
DEBUG - 2016-08-24 04:44:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:44:49 --> Model Class Initialized
INFO - 2016-08-24 04:44:49 --> Model Class Initialized
INFO - 2016-08-24 04:44:49 --> Model Class Initialized
INFO - 2016-08-24 04:44:49 --> Model Class Initialized
INFO - 2016-08-24 04:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-24 04:44:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:44:49 --> Final output sent to browser
DEBUG - 2016-08-24 04:44:49 --> Total execution time: 0.2750
INFO - 2016-08-24 04:45:43 --> Config Class Initialized
INFO - 2016-08-24 04:45:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:45:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:45:43 --> Utf8 Class Initialized
INFO - 2016-08-24 04:45:43 --> URI Class Initialized
INFO - 2016-08-24 04:45:43 --> Router Class Initialized
INFO - 2016-08-24 04:45:43 --> Output Class Initialized
INFO - 2016-08-24 04:45:43 --> Security Class Initialized
DEBUG - 2016-08-24 04:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:45:43 --> Input Class Initialized
INFO - 2016-08-24 04:45:43 --> Language Class Initialized
INFO - 2016-08-24 04:45:43 --> Loader Class Initialized
INFO - 2016-08-24 04:45:43 --> Helper loaded: url_helper
INFO - 2016-08-24 04:45:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:45:43 --> Helper loaded: html_helper
INFO - 2016-08-24 04:45:43 --> Helper loaded: form_helper
INFO - 2016-08-24 04:45:43 --> Helper loaded: file_helper
INFO - 2016-08-24 04:45:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:45:43 --> Database Driver Class Initialized
INFO - 2016-08-24 04:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:45:43 --> Form Validation Class Initialized
INFO - 2016-08-24 04:45:43 --> Email Class Initialized
INFO - 2016-08-24 04:45:43 --> Controller Class Initialized
DEBUG - 2016-08-24 04:45:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:45:43 --> Model Class Initialized
INFO - 2016-08-24 04:45:43 --> Model Class Initialized
INFO - 2016-08-24 04:45:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:45:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:45:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 04:45:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:45:43 --> Final output sent to browser
DEBUG - 2016-08-24 04:45:43 --> Total execution time: 0.2787
INFO - 2016-08-24 04:48:01 --> Config Class Initialized
INFO - 2016-08-24 04:48:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:48:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:48:01 --> Utf8 Class Initialized
INFO - 2016-08-24 04:48:01 --> URI Class Initialized
DEBUG - 2016-08-24 04:48:01 --> No URI present. Default controller set.
INFO - 2016-08-24 04:48:01 --> Router Class Initialized
INFO - 2016-08-24 04:48:01 --> Output Class Initialized
INFO - 2016-08-24 04:48:01 --> Security Class Initialized
DEBUG - 2016-08-24 04:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:48:01 --> Input Class Initialized
INFO - 2016-08-24 04:48:01 --> Language Class Initialized
INFO - 2016-08-24 04:48:01 --> Loader Class Initialized
INFO - 2016-08-24 04:48:01 --> Helper loaded: url_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: html_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: form_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: file_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:48:01 --> Database Driver Class Initialized
INFO - 2016-08-24 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:48:01 --> Form Validation Class Initialized
INFO - 2016-08-24 04:48:01 --> Email Class Initialized
INFO - 2016-08-24 04:48:01 --> Controller Class Initialized
INFO - 2016-08-24 04:48:01 --> Config Class Initialized
INFO - 2016-08-24 04:48:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:48:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:48:01 --> Utf8 Class Initialized
INFO - 2016-08-24 04:48:01 --> URI Class Initialized
INFO - 2016-08-24 04:48:01 --> Router Class Initialized
INFO - 2016-08-24 04:48:01 --> Output Class Initialized
INFO - 2016-08-24 04:48:01 --> Security Class Initialized
DEBUG - 2016-08-24 04:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:48:01 --> Input Class Initialized
INFO - 2016-08-24 04:48:01 --> Language Class Initialized
INFO - 2016-08-24 04:48:01 --> Loader Class Initialized
INFO - 2016-08-24 04:48:01 --> Helper loaded: url_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: html_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: form_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: file_helper
INFO - 2016-08-24 04:48:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:48:01 --> Database Driver Class Initialized
INFO - 2016-08-24 04:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:48:01 --> Form Validation Class Initialized
INFO - 2016-08-24 04:48:01 --> Email Class Initialized
INFO - 2016-08-24 04:48:01 --> Controller Class Initialized
INFO - 2016-08-24 04:48:02 --> Model Class Initialized
DEBUG - 2016-08-24 04:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 04:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 04:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:48:02 --> Final output sent to browser
DEBUG - 2016-08-24 04:48:02 --> Total execution time: 0.2508
INFO - 2016-08-24 04:48:04 --> Config Class Initialized
INFO - 2016-08-24 04:48:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:48:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:48:04 --> Utf8 Class Initialized
INFO - 2016-08-24 04:48:04 --> URI Class Initialized
INFO - 2016-08-24 04:48:04 --> Router Class Initialized
INFO - 2016-08-24 04:48:04 --> Output Class Initialized
INFO - 2016-08-24 04:48:04 --> Security Class Initialized
DEBUG - 2016-08-24 04:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:48:04 --> Input Class Initialized
INFO - 2016-08-24 04:48:04 --> Language Class Initialized
ERROR - 2016-08-24 04:48:04 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-24 04:48:07 --> Config Class Initialized
INFO - 2016-08-24 04:48:07 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:48:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:48:07 --> Utf8 Class Initialized
INFO - 2016-08-24 04:48:07 --> URI Class Initialized
INFO - 2016-08-24 04:48:07 --> Router Class Initialized
INFO - 2016-08-24 04:48:07 --> Output Class Initialized
INFO - 2016-08-24 04:48:07 --> Security Class Initialized
DEBUG - 2016-08-24 04:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:48:07 --> Input Class Initialized
INFO - 2016-08-24 04:48:07 --> Language Class Initialized
INFO - 2016-08-24 04:48:07 --> Loader Class Initialized
INFO - 2016-08-24 04:48:07 --> Helper loaded: url_helper
INFO - 2016-08-24 04:48:07 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:48:07 --> Helper loaded: html_helper
INFO - 2016-08-24 04:48:07 --> Helper loaded: form_helper
INFO - 2016-08-24 04:48:07 --> Helper loaded: file_helper
INFO - 2016-08-24 04:48:07 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:48:07 --> Database Driver Class Initialized
INFO - 2016-08-24 04:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:48:07 --> Form Validation Class Initialized
INFO - 2016-08-24 04:48:07 --> Email Class Initialized
INFO - 2016-08-24 04:48:07 --> Controller Class Initialized
INFO - 2016-08-24 04:48:07 --> Model Class Initialized
ERROR - 2016-08-24 04:48:07 --> Severity: Warning --> require_once(D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
ERROR - 2016-08-24 04:48:07 --> Severity: Compile Error --> require_once(): Failed opening required 'D:\wamp\www\library.pnc.lan\application\third_party/OAuthClient/vendor/autoload.php' (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\libraries\OAuthC.php 6
INFO - 2016-08-24 04:53:36 --> Config Class Initialized
INFO - 2016-08-24 04:53:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:53:36 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:53:36 --> Utf8 Class Initialized
INFO - 2016-08-24 04:53:36 --> URI Class Initialized
INFO - 2016-08-24 04:53:36 --> Router Class Initialized
INFO - 2016-08-24 04:53:36 --> Output Class Initialized
INFO - 2016-08-24 04:53:36 --> Security Class Initialized
DEBUG - 2016-08-24 04:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:53:36 --> Input Class Initialized
INFO - 2016-08-24 04:53:36 --> Language Class Initialized
INFO - 2016-08-24 04:53:36 --> Loader Class Initialized
INFO - 2016-08-24 04:53:36 --> Helper loaded: url_helper
INFO - 2016-08-24 04:53:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:53:36 --> Helper loaded: html_helper
INFO - 2016-08-24 04:53:36 --> Helper loaded: form_helper
INFO - 2016-08-24 04:53:36 --> Helper loaded: file_helper
INFO - 2016-08-24 04:53:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:53:36 --> Database Driver Class Initialized
INFO - 2016-08-24 04:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:53:36 --> Form Validation Class Initialized
INFO - 2016-08-24 04:53:36 --> Email Class Initialized
INFO - 2016-08-24 04:53:36 --> Controller Class Initialized
INFO - 2016-08-24 04:53:36 --> Model Class Initialized
INFO - 2016-08-24 04:53:44 --> Config Class Initialized
INFO - 2016-08-24 04:53:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:53:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:53:44 --> Utf8 Class Initialized
INFO - 2016-08-24 04:53:44 --> URI Class Initialized
INFO - 2016-08-24 04:53:44 --> Router Class Initialized
INFO - 2016-08-24 04:53:44 --> Output Class Initialized
INFO - 2016-08-24 04:53:44 --> Security Class Initialized
DEBUG - 2016-08-24 04:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:53:44 --> Input Class Initialized
INFO - 2016-08-24 04:53:44 --> Language Class Initialized
INFO - 2016-08-24 04:53:44 --> Loader Class Initialized
INFO - 2016-08-24 04:53:44 --> Helper loaded: url_helper
INFO - 2016-08-24 04:53:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:53:44 --> Helper loaded: html_helper
INFO - 2016-08-24 04:53:44 --> Helper loaded: form_helper
INFO - 2016-08-24 04:53:44 --> Helper loaded: file_helper
INFO - 2016-08-24 04:53:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:53:44 --> Database Driver Class Initialized
INFO - 2016-08-24 04:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:53:44 --> Form Validation Class Initialized
INFO - 2016-08-24 04:53:45 --> Email Class Initialized
INFO - 2016-08-24 04:53:45 --> Controller Class Initialized
INFO - 2016-08-24 04:53:45 --> Model Class Initialized
DEBUG - 2016-08-24 04:53:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 04:53:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 04:53:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:53:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 04:53:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:53:45 --> Final output sent to browser
DEBUG - 2016-08-24 04:53:45 --> Total execution time: 0.2599
INFO - 2016-08-24 04:53:47 --> Config Class Initialized
INFO - 2016-08-24 04:53:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:53:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:53:47 --> Utf8 Class Initialized
INFO - 2016-08-24 04:53:47 --> URI Class Initialized
INFO - 2016-08-24 04:53:47 --> Router Class Initialized
INFO - 2016-08-24 04:53:47 --> Output Class Initialized
INFO - 2016-08-24 04:53:47 --> Security Class Initialized
DEBUG - 2016-08-24 04:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:53:47 --> Input Class Initialized
INFO - 2016-08-24 04:53:47 --> Language Class Initialized
INFO - 2016-08-24 04:53:47 --> Loader Class Initialized
INFO - 2016-08-24 04:53:47 --> Helper loaded: url_helper
INFO - 2016-08-24 04:53:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:53:47 --> Helper loaded: html_helper
INFO - 2016-08-24 04:53:47 --> Helper loaded: form_helper
INFO - 2016-08-24 04:53:47 --> Helper loaded: file_helper
INFO - 2016-08-24 04:53:47 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:53:47 --> Database Driver Class Initialized
INFO - 2016-08-24 04:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:53:47 --> Form Validation Class Initialized
INFO - 2016-08-24 04:53:47 --> Email Class Initialized
INFO - 2016-08-24 04:53:47 --> Controller Class Initialized
INFO - 2016-08-24 04:53:47 --> Model Class Initialized
INFO - 2016-08-24 04:56:56 --> Config Class Initialized
INFO - 2016-08-24 04:56:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:56:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:56:56 --> Utf8 Class Initialized
INFO - 2016-08-24 04:56:56 --> URI Class Initialized
INFO - 2016-08-24 04:56:56 --> Router Class Initialized
INFO - 2016-08-24 04:56:56 --> Output Class Initialized
INFO - 2016-08-24 04:56:56 --> Security Class Initialized
DEBUG - 2016-08-24 04:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:56:56 --> Input Class Initialized
INFO - 2016-08-24 04:56:56 --> Language Class Initialized
INFO - 2016-08-24 04:56:56 --> Loader Class Initialized
INFO - 2016-08-24 04:56:56 --> Helper loaded: url_helper
INFO - 2016-08-24 04:56:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:56:56 --> Helper loaded: html_helper
INFO - 2016-08-24 04:56:56 --> Helper loaded: form_helper
INFO - 2016-08-24 04:56:56 --> Helper loaded: file_helper
INFO - 2016-08-24 04:56:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:56:56 --> Database Driver Class Initialized
INFO - 2016-08-24 04:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:56:56 --> Form Validation Class Initialized
INFO - 2016-08-24 04:56:56 --> Email Class Initialized
INFO - 2016-08-24 04:56:56 --> Controller Class Initialized
INFO - 2016-08-24 04:56:56 --> Model Class Initialized
ERROR - 2016-08-24 04:56:56 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-08-24 04:59:45 --> Config Class Initialized
INFO - 2016-08-24 04:59:45 --> Config Class Initialized
INFO - 2016-08-24 04:59:45 --> Config Class Initialized
INFO - 2016-08-24 04:59:45 --> Hooks Class Initialized
INFO - 2016-08-24 04:59:45 --> Hooks Class Initialized
INFO - 2016-08-24 04:59:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 04:59:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 04:59:45 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 04:59:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 04:59:45 --> Utf8 Class Initialized
INFO - 2016-08-24 04:59:45 --> Utf8 Class Initialized
INFO - 2016-08-24 04:59:45 --> Utf8 Class Initialized
INFO - 2016-08-24 04:59:45 --> URI Class Initialized
INFO - 2016-08-24 04:59:45 --> URI Class Initialized
INFO - 2016-08-24 04:59:45 --> URI Class Initialized
INFO - 2016-08-24 04:59:45 --> Router Class Initialized
DEBUG - 2016-08-24 04:59:45 --> No URI present. Default controller set.
INFO - 2016-08-24 04:59:45 --> Router Class Initialized
INFO - 2016-08-24 04:59:45 --> Router Class Initialized
INFO - 2016-08-24 04:59:45 --> Output Class Initialized
INFO - 2016-08-24 04:59:45 --> Output Class Initialized
INFO - 2016-08-24 04:59:45 --> Security Class Initialized
INFO - 2016-08-24 04:59:45 --> Security Class Initialized
INFO - 2016-08-24 04:59:45 --> Output Class Initialized
INFO - 2016-08-24 04:59:45 --> Security Class Initialized
DEBUG - 2016-08-24 04:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:59:45 --> Input Class Initialized
INFO - 2016-08-24 04:59:45 --> Input Class Initialized
DEBUG - 2016-08-24 04:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 04:59:45 --> Input Class Initialized
INFO - 2016-08-24 04:59:45 --> Language Class Initialized
INFO - 2016-08-24 04:59:45 --> Language Class Initialized
INFO - 2016-08-24 04:59:45 --> Language Class Initialized
INFO - 2016-08-24 04:59:45 --> Loader Class Initialized
INFO - 2016-08-24 04:59:45 --> Loader Class Initialized
INFO - 2016-08-24 04:59:45 --> Helper loaded: url_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: url_helper
INFO - 2016-08-24 04:59:45 --> Loader Class Initialized
INFO - 2016-08-24 04:59:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: url_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: html_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: html_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: html_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: form_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: form_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: file_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: file_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: form_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: file_helper
INFO - 2016-08-24 04:59:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 04:59:45 --> Database Driver Class Initialized
INFO - 2016-08-24 04:59:45 --> Database Driver Class Initialized
INFO - 2016-08-24 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:59:45 --> Database Driver Class Initialized
INFO - 2016-08-24 04:59:45 --> Form Validation Class Initialized
INFO - 2016-08-24 04:59:45 --> Email Class Initialized
INFO - 2016-08-24 04:59:45 --> Controller Class Initialized
INFO - 2016-08-24 04:59:45 --> Model Class Initialized
INFO - 2016-08-24 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:59:45 --> Form Validation Class Initialized
INFO - 2016-08-24 04:59:45 --> Email Class Initialized
INFO - 2016-08-24 04:59:45 --> Controller Class Initialized
INFO - 2016-08-24 04:59:45 --> Model Class Initialized
INFO - 2016-08-24 04:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 04:59:45 --> Form Validation Class Initialized
INFO - 2016-08-24 04:59:45 --> Email Class Initialized
INFO - 2016-08-24 04:59:45 --> Controller Class Initialized
INFO - 2016-08-24 04:59:45 --> Model Class Initialized
INFO - 2016-08-24 04:59:45 --> Model Class Initialized
INFO - 2016-08-24 04:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 04:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 04:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 04:59:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 04:59:45 --> Final output sent to browser
DEBUG - 2016-08-24 04:59:45 --> Total execution time: 0.3614
INFO - 2016-08-24 05:00:48 --> Config Class Initialized
INFO - 2016-08-24 05:00:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:00:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:00:48 --> Utf8 Class Initialized
INFO - 2016-08-24 05:00:48 --> URI Class Initialized
DEBUG - 2016-08-24 05:00:48 --> No URI present. Default controller set.
INFO - 2016-08-24 05:00:48 --> Router Class Initialized
INFO - 2016-08-24 05:00:48 --> Output Class Initialized
INFO - 2016-08-24 05:00:48 --> Security Class Initialized
DEBUG - 2016-08-24 05:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:00:48 --> Input Class Initialized
INFO - 2016-08-24 05:00:48 --> Language Class Initialized
INFO - 2016-08-24 05:00:48 --> Loader Class Initialized
INFO - 2016-08-24 05:00:48 --> Helper loaded: url_helper
INFO - 2016-08-24 05:00:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:00:48 --> Helper loaded: html_helper
INFO - 2016-08-24 05:00:48 --> Helper loaded: form_helper
INFO - 2016-08-24 05:00:48 --> Helper loaded: file_helper
INFO - 2016-08-24 05:00:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:00:48 --> Database Driver Class Initialized
INFO - 2016-08-24 05:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:00:48 --> Form Validation Class Initialized
INFO - 2016-08-24 05:00:48 --> Email Class Initialized
INFO - 2016-08-24 05:00:48 --> Controller Class Initialized
INFO - 2016-08-24 05:00:48 --> Model Class Initialized
INFO - 2016-08-24 05:00:48 --> Model Class Initialized
INFO - 2016-08-24 05:00:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:00:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:00:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 05:00:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:00:48 --> Final output sent to browser
DEBUG - 2016-08-24 05:00:48 --> Total execution time: 0.3610
INFO - 2016-08-24 05:00:49 --> Config Class Initialized
INFO - 2016-08-24 05:00:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:00:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:00:49 --> Utf8 Class Initialized
INFO - 2016-08-24 05:00:49 --> URI Class Initialized
INFO - 2016-08-24 05:00:49 --> Router Class Initialized
INFO - 2016-08-24 05:00:49 --> Output Class Initialized
INFO - 2016-08-24 05:00:49 --> Security Class Initialized
DEBUG - 2016-08-24 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:00:49 --> Input Class Initialized
INFO - 2016-08-24 05:00:49 --> Language Class Initialized
ERROR - 2016-08-24 05:00:49 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-24 05:00:50 --> Config Class Initialized
INFO - 2016-08-24 05:00:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:00:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:00:50 --> Utf8 Class Initialized
INFO - 2016-08-24 05:00:50 --> URI Class Initialized
INFO - 2016-08-24 05:00:50 --> Router Class Initialized
INFO - 2016-08-24 05:00:50 --> Output Class Initialized
INFO - 2016-08-24 05:00:50 --> Security Class Initialized
DEBUG - 2016-08-24 05:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:00:50 --> Input Class Initialized
INFO - 2016-08-24 05:00:50 --> Language Class Initialized
ERROR - 2016-08-24 05:00:50 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-24 05:00:53 --> Config Class Initialized
INFO - 2016-08-24 05:00:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:00:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:00:53 --> Utf8 Class Initialized
INFO - 2016-08-24 05:00:53 --> URI Class Initialized
INFO - 2016-08-24 05:00:53 --> Router Class Initialized
INFO - 2016-08-24 05:00:53 --> Output Class Initialized
INFO - 2016-08-24 05:00:53 --> Security Class Initialized
DEBUG - 2016-08-24 05:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:00:53 --> Input Class Initialized
INFO - 2016-08-24 05:00:53 --> Language Class Initialized
INFO - 2016-08-24 05:00:53 --> Loader Class Initialized
INFO - 2016-08-24 05:00:53 --> Helper loaded: url_helper
INFO - 2016-08-24 05:00:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: html_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: form_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: file_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:00:54 --> Database Driver Class Initialized
INFO - 2016-08-24 05:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:00:54 --> Form Validation Class Initialized
INFO - 2016-08-24 05:00:54 --> Email Class Initialized
INFO - 2016-08-24 05:00:54 --> Controller Class Initialized
INFO - 2016-08-24 05:00:54 --> Model Class Initialized
INFO - 2016-08-24 05:00:54 --> Config Class Initialized
INFO - 2016-08-24 05:00:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:00:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:00:54 --> Utf8 Class Initialized
INFO - 2016-08-24 05:00:54 --> URI Class Initialized
INFO - 2016-08-24 05:00:54 --> Router Class Initialized
INFO - 2016-08-24 05:00:54 --> Output Class Initialized
INFO - 2016-08-24 05:00:54 --> Security Class Initialized
DEBUG - 2016-08-24 05:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:00:54 --> Input Class Initialized
INFO - 2016-08-24 05:00:54 --> Language Class Initialized
INFO - 2016-08-24 05:00:54 --> Loader Class Initialized
INFO - 2016-08-24 05:00:54 --> Helper loaded: url_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: html_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: form_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: file_helper
INFO - 2016-08-24 05:00:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:00:54 --> Database Driver Class Initialized
INFO - 2016-08-24 05:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:00:54 --> Form Validation Class Initialized
INFO - 2016-08-24 05:00:54 --> Email Class Initialized
INFO - 2016-08-24 05:00:54 --> Controller Class Initialized
INFO - 2016-08-24 05:00:54 --> Model Class Initialized
DEBUG - 2016-08-24 05:00:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:00:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 05:00:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:00:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 05:00:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:00:54 --> Final output sent to browser
DEBUG - 2016-08-24 05:00:54 --> Total execution time: 0.2721
INFO - 2016-08-24 05:01:06 --> Config Class Initialized
INFO - 2016-08-24 05:01:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:01:06 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:06 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:06 --> URI Class Initialized
INFO - 2016-08-24 05:01:06 --> Router Class Initialized
INFO - 2016-08-24 05:01:06 --> Output Class Initialized
INFO - 2016-08-24 05:01:06 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:06 --> Input Class Initialized
INFO - 2016-08-24 05:01:06 --> Language Class Initialized
INFO - 2016-08-24 05:01:06 --> Loader Class Initialized
INFO - 2016-08-24 05:01:06 --> Helper loaded: url_helper
INFO - 2016-08-24 05:01:06 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:01:06 --> Helper loaded: html_helper
INFO - 2016-08-24 05:01:06 --> Helper loaded: form_helper
INFO - 2016-08-24 05:01:06 --> Helper loaded: file_helper
INFO - 2016-08-24 05:01:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:01:06 --> Database Driver Class Initialized
INFO - 2016-08-24 05:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:01:06 --> Form Validation Class Initialized
INFO - 2016-08-24 05:01:06 --> Email Class Initialized
INFO - 2016-08-24 05:01:06 --> Controller Class Initialized
INFO - 2016-08-24 05:01:06 --> Model Class Initialized
DEBUG - 2016-08-24 05:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:01:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 05:01:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:01:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 05:01:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:01:06 --> Final output sent to browser
DEBUG - 2016-08-24 05:01:06 --> Total execution time: 0.2665
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Config Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> URI Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Router Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Output Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
INFO - 2016-08-24 05:01:15 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Input Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
INFO - 2016-08-24 05:01:15 --> Language Class Initialized
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:15 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:01:18 --> Config Class Initialized
INFO - 2016-08-24 05:01:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:01:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:18 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:18 --> URI Class Initialized
INFO - 2016-08-24 05:01:18 --> Router Class Initialized
INFO - 2016-08-24 05:01:18 --> Output Class Initialized
INFO - 2016-08-24 05:01:18 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:18 --> Input Class Initialized
INFO - 2016-08-24 05:01:18 --> Language Class Initialized
INFO - 2016-08-24 05:01:18 --> Loader Class Initialized
INFO - 2016-08-24 05:01:18 --> Helper loaded: url_helper
INFO - 2016-08-24 05:01:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:01:18 --> Helper loaded: html_helper
INFO - 2016-08-24 05:01:18 --> Helper loaded: form_helper
INFO - 2016-08-24 05:01:18 --> Helper loaded: file_helper
INFO - 2016-08-24 05:01:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:01:18 --> Database Driver Class Initialized
INFO - 2016-08-24 05:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:01:18 --> Form Validation Class Initialized
INFO - 2016-08-24 05:01:18 --> Email Class Initialized
INFO - 2016-08-24 05:01:18 --> Controller Class Initialized
INFO - 2016-08-24 05:01:18 --> Model Class Initialized
DEBUG - 2016-08-24 05:01:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:01:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 05:01:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:01:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 05:01:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:01:18 --> Final output sent to browser
DEBUG - 2016-08-24 05:01:18 --> Total execution time: 0.2897
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Config Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
INFO - 2016-08-24 05:01:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:01:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> Utf8 Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> URI Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Router Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Output Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
INFO - 2016-08-24 05:01:22 --> Security Class Initialized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Input Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
INFO - 2016-08-24 05:01:22 --> Language Class Initialized
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:01:22 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:02:23 --> Config Class Initialized
INFO - 2016-08-24 05:02:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:02:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:02:23 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:23 --> URI Class Initialized
INFO - 2016-08-24 05:02:23 --> Router Class Initialized
INFO - 2016-08-24 05:02:23 --> Output Class Initialized
INFO - 2016-08-24 05:02:23 --> Security Class Initialized
DEBUG - 2016-08-24 05:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:02:23 --> Input Class Initialized
INFO - 2016-08-24 05:02:23 --> Language Class Initialized
INFO - 2016-08-24 05:02:23 --> Loader Class Initialized
INFO - 2016-08-24 05:02:23 --> Helper loaded: url_helper
INFO - 2016-08-24 05:02:23 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:02:23 --> Helper loaded: html_helper
INFO - 2016-08-24 05:02:23 --> Helper loaded: form_helper
INFO - 2016-08-24 05:02:23 --> Helper loaded: file_helper
INFO - 2016-08-24 05:02:23 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:02:23 --> Database Driver Class Initialized
INFO - 2016-08-24 05:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:02:23 --> Form Validation Class Initialized
INFO - 2016-08-24 05:02:23 --> Email Class Initialized
INFO - 2016-08-24 05:02:23 --> Controller Class Initialized
INFO - 2016-08-24 05:02:23 --> Model Class Initialized
DEBUG - 2016-08-24 05:02:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:02:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 05:02:23 --> Config Class Initialized
INFO - 2016-08-24 05:02:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:02:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:02:23 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:23 --> URI Class Initialized
INFO - 2016-08-24 05:02:23 --> Router Class Initialized
INFO - 2016-08-24 05:02:24 --> Output Class Initialized
INFO - 2016-08-24 05:02:24 --> Security Class Initialized
DEBUG - 2016-08-24 05:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:02:24 --> Input Class Initialized
INFO - 2016-08-24 05:02:24 --> Language Class Initialized
INFO - 2016-08-24 05:02:24 --> Loader Class Initialized
INFO - 2016-08-24 05:02:24 --> Helper loaded: url_helper
INFO - 2016-08-24 05:02:24 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:02:24 --> Helper loaded: html_helper
INFO - 2016-08-24 05:02:24 --> Helper loaded: form_helper
INFO - 2016-08-24 05:02:24 --> Helper loaded: file_helper
INFO - 2016-08-24 05:02:24 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:02:24 --> Database Driver Class Initialized
INFO - 2016-08-24 05:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:02:24 --> Form Validation Class Initialized
INFO - 2016-08-24 05:02:24 --> Email Class Initialized
INFO - 2016-08-24 05:02:24 --> Controller Class Initialized
DEBUG - 2016-08-24 05:02:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 05:02:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:02:24 --> Model Class Initialized
INFO - 2016-08-24 05:02:24 --> Model Class Initialized
INFO - 2016-08-24 05:02:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:02:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:02:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 05:02:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:02:24 --> Final output sent to browser
DEBUG - 2016-08-24 05:02:24 --> Total execution time: 0.3592
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Config Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
INFO - 2016-08-24 05:02:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
DEBUG - 2016-08-24 05:02:26 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> Utf8 Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> URI Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Router Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Output Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
INFO - 2016-08-24 05:02:26 --> Security Class Initialized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2016-08-24 05:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Input Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
INFO - 2016-08-24 05:02:26 --> Language Class Initialized
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
ERROR - 2016-08-24 05:02:26 --> 404 Page Not Found: Assets/bootstrap
INFO - 2016-08-24 05:03:11 --> Config Class Initialized
INFO - 2016-08-24 05:03:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:03:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:11 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:11 --> URI Class Initialized
INFO - 2016-08-24 05:03:11 --> Router Class Initialized
INFO - 2016-08-24 05:03:11 --> Output Class Initialized
INFO - 2016-08-24 05:03:11 --> Security Class Initialized
DEBUG - 2016-08-24 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:11 --> Input Class Initialized
INFO - 2016-08-24 05:03:11 --> Language Class Initialized
INFO - 2016-08-24 05:03:11 --> Loader Class Initialized
INFO - 2016-08-24 05:03:11 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:11 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:11 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:11 --> Email Class Initialized
INFO - 2016-08-24 05:03:11 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 05:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:11 --> Model Class Initialized
INFO - 2016-08-24 05:03:11 --> Config Class Initialized
INFO - 2016-08-24 05:03:11 --> Hooks Class Initialized
INFO - 2016-08-24 05:03:11 --> Model Class Initialized
DEBUG - 2016-08-24 05:03:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:11 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:11 --> URI Class Initialized
INFO - 2016-08-24 05:03:11 --> Router Class Initialized
INFO - 2016-08-24 05:03:11 --> Output Class Initialized
INFO - 2016-08-24 05:03:11 --> Security Class Initialized
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
DEBUG - 2016-08-24 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:11 --> Input Class Initialized
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:11 --> Language Class Initialized
INFO - 2016-08-24 05:03:11 --> Final output sent to browser
INFO - 2016-08-24 05:03:11 --> Loader Class Initialized
DEBUG - 2016-08-24 05:03:11 --> Total execution time: 0.4779
INFO - 2016-08-24 05:03:11 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:11 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:11 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:11 --> Email Class Initialized
INFO - 2016-08-24 05:03:11 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 05:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:11 --> Model Class Initialized
INFO - 2016-08-24 05:03:11 --> Model Class Initialized
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:11 --> Final output sent to browser
DEBUG - 2016-08-24 05:03:11 --> Total execution time: 0.4059
INFO - 2016-08-24 05:03:25 --> Config Class Initialized
INFO - 2016-08-24 05:03:25 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:03:25 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:25 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:25 --> URI Class Initialized
INFO - 2016-08-24 05:03:25 --> Router Class Initialized
INFO - 2016-08-24 05:03:25 --> Output Class Initialized
INFO - 2016-08-24 05:03:25 --> Security Class Initialized
DEBUG - 2016-08-24 05:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:25 --> Input Class Initialized
INFO - 2016-08-24 05:03:25 --> Language Class Initialized
INFO - 2016-08-24 05:03:25 --> Loader Class Initialized
INFO - 2016-08-24 05:03:25 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:25 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:25 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:25 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:25 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:25 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:25 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:25 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:25 --> Email Class Initialized
INFO - 2016-08-24 05:03:25 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:25 --> Model Class Initialized
INFO - 2016-08-24 05:03:25 --> Model Class Initialized
INFO - 2016-08-24 05:03:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:03:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-24 05:03:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:25 --> Final output sent to browser
DEBUG - 2016-08-24 05:03:25 --> Total execution time: 0.3301
INFO - 2016-08-24 05:03:32 --> Config Class Initialized
INFO - 2016-08-24 05:03:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:03:32 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:32 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:32 --> URI Class Initialized
INFO - 2016-08-24 05:03:32 --> Router Class Initialized
INFO - 2016-08-24 05:03:32 --> Output Class Initialized
INFO - 2016-08-24 05:03:32 --> Security Class Initialized
DEBUG - 2016-08-24 05:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:32 --> Input Class Initialized
INFO - 2016-08-24 05:03:32 --> Language Class Initialized
INFO - 2016-08-24 05:03:32 --> Loader Class Initialized
INFO - 2016-08-24 05:03:32 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:32 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:32 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:32 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:32 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:32 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:32 --> Email Class Initialized
INFO - 2016-08-24 05:03:32 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:32 --> Model Class Initialized
INFO - 2016-08-24 05:03:33 --> Model Class Initialized
INFO - 2016-08-24 05:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 05:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:33 --> Final output sent to browser
DEBUG - 2016-08-24 05:03:33 --> Total execution time: 0.3158
INFO - 2016-08-24 05:03:44 --> Config Class Initialized
INFO - 2016-08-24 05:03:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:03:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:44 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:44 --> URI Class Initialized
INFO - 2016-08-24 05:03:44 --> Router Class Initialized
INFO - 2016-08-24 05:03:44 --> Output Class Initialized
INFO - 2016-08-24 05:03:44 --> Security Class Initialized
DEBUG - 2016-08-24 05:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:44 --> Input Class Initialized
INFO - 2016-08-24 05:03:44 --> Language Class Initialized
INFO - 2016-08-24 05:03:44 --> Loader Class Initialized
INFO - 2016-08-24 05:03:44 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:44 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:44 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:44 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:44 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:44 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:44 --> Email Class Initialized
INFO - 2016-08-24 05:03:44 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 05:03:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:44 --> Model Class Initialized
INFO - 2016-08-24 05:03:44 --> Model Class Initialized
INFO - 2016-08-24 05:03:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:03:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 05:03:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:44 --> Final output sent to browser
DEBUG - 2016-08-24 05:03:44 --> Total execution time: 0.3769
INFO - 2016-08-24 05:03:59 --> Config Class Initialized
INFO - 2016-08-24 05:03:59 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:03:59 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:03:59 --> Utf8 Class Initialized
INFO - 2016-08-24 05:03:59 --> URI Class Initialized
INFO - 2016-08-24 05:03:59 --> Router Class Initialized
INFO - 2016-08-24 05:03:59 --> Output Class Initialized
INFO - 2016-08-24 05:03:59 --> Security Class Initialized
DEBUG - 2016-08-24 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:03:59 --> Input Class Initialized
INFO - 2016-08-24 05:03:59 --> Language Class Initialized
INFO - 2016-08-24 05:03:59 --> Loader Class Initialized
INFO - 2016-08-24 05:03:59 --> Helper loaded: url_helper
INFO - 2016-08-24 05:03:59 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:03:59 --> Helper loaded: html_helper
INFO - 2016-08-24 05:03:59 --> Helper loaded: form_helper
INFO - 2016-08-24 05:03:59 --> Helper loaded: file_helper
INFO - 2016-08-24 05:03:59 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:03:59 --> Database Driver Class Initialized
INFO - 2016-08-24 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:03:59 --> Form Validation Class Initialized
INFO - 2016-08-24 05:03:59 --> Email Class Initialized
INFO - 2016-08-24 05:03:59 --> Controller Class Initialized
DEBUG - 2016-08-24 05:03:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 05:03:59 --> Model Class Initialized
INFO - 2016-08-24 05:03:59 --> Model Class Initialized
INFO - 2016-08-24 05:03:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:03:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:03:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 05:03:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:03:59 --> Final output sent to browser
DEBUG - 2016-08-24 05:03:59 --> Total execution time: 0.3266
INFO - 2016-08-24 05:34:28 --> Config Class Initialized
INFO - 2016-08-24 05:34:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:34:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:34:28 --> Utf8 Class Initialized
INFO - 2016-08-24 05:34:28 --> URI Class Initialized
INFO - 2016-08-24 05:34:28 --> Router Class Initialized
INFO - 2016-08-24 05:34:28 --> Output Class Initialized
INFO - 2016-08-24 05:34:28 --> Security Class Initialized
DEBUG - 2016-08-24 05:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:34:28 --> Input Class Initialized
INFO - 2016-08-24 05:34:28 --> Language Class Initialized
INFO - 2016-08-24 05:34:28 --> Loader Class Initialized
INFO - 2016-08-24 05:34:28 --> Helper loaded: url_helper
INFO - 2016-08-24 05:34:28 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:34:28 --> Helper loaded: html_helper
INFO - 2016-08-24 05:34:28 --> Helper loaded: form_helper
INFO - 2016-08-24 05:34:28 --> Helper loaded: file_helper
INFO - 2016-08-24 05:34:28 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:34:28 --> Database Driver Class Initialized
INFO - 2016-08-24 05:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:34:28 --> Form Validation Class Initialized
INFO - 2016-08-24 05:34:28 --> Email Class Initialized
INFO - 2016-08-24 05:34:28 --> Controller Class Initialized
INFO - 2016-08-24 05:34:28 --> Model Class Initialized
INFO - 2016-08-24 05:34:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 05:34:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 05:34:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-24 05:34:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 05:34:28 --> Final output sent to browser
DEBUG - 2016-08-24 05:34:28 --> Total execution time: 0.3200
INFO - 2016-08-24 05:37:17 --> Config Class Initialized
INFO - 2016-08-24 05:37:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:37:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:37:17 --> Utf8 Class Initialized
INFO - 2016-08-24 05:37:17 --> URI Class Initialized
INFO - 2016-08-24 05:37:17 --> Router Class Initialized
INFO - 2016-08-24 05:37:17 --> Output Class Initialized
INFO - 2016-08-24 05:37:17 --> Security Class Initialized
DEBUG - 2016-08-24 05:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:37:17 --> Input Class Initialized
INFO - 2016-08-24 05:37:17 --> Language Class Initialized
ERROR - 2016-08-24 05:37:17 --> 404 Page Not Found: User_authenticationphp/index
INFO - 2016-08-24 05:38:12 --> Config Class Initialized
INFO - 2016-08-24 05:38:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:38:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:38:12 --> Utf8 Class Initialized
INFO - 2016-08-24 05:38:12 --> URI Class Initialized
INFO - 2016-08-24 05:38:12 --> Router Class Initialized
INFO - 2016-08-24 05:38:12 --> Output Class Initialized
INFO - 2016-08-24 05:38:12 --> Security Class Initialized
DEBUG - 2016-08-24 05:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:38:12 --> Input Class Initialized
INFO - 2016-08-24 05:38:12 --> Language Class Initialized
INFO - 2016-08-24 05:38:12 --> Loader Class Initialized
INFO - 2016-08-24 05:38:12 --> Helper loaded: url_helper
INFO - 2016-08-24 05:38:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:38:12 --> Helper loaded: html_helper
INFO - 2016-08-24 05:38:12 --> Helper loaded: form_helper
INFO - 2016-08-24 05:38:12 --> Helper loaded: file_helper
INFO - 2016-08-24 05:38:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:38:12 --> Database Driver Class Initialized
INFO - 2016-08-24 05:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:38:12 --> Form Validation Class Initialized
INFO - 2016-08-24 05:38:12 --> Email Class Initialized
INFO - 2016-08-24 05:38:12 --> Controller Class Initialized
INFO - 2016-08-24 05:38:12 --> Model Class Initialized
INFO - 2016-08-24 05:38:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 05:38:12 --> Final output sent to browser
DEBUG - 2016-08-24 05:38:12 --> Total execution time: 0.6890
INFO - 2016-08-24 05:38:25 --> Config Class Initialized
INFO - 2016-08-24 05:38:25 --> Hooks Class Initialized
DEBUG - 2016-08-24 05:38:25 --> UTF-8 Support Enabled
INFO - 2016-08-24 05:38:25 --> Utf8 Class Initialized
INFO - 2016-08-24 05:38:25 --> URI Class Initialized
INFO - 2016-08-24 05:38:25 --> Router Class Initialized
INFO - 2016-08-24 05:38:25 --> Output Class Initialized
INFO - 2016-08-24 05:38:25 --> Security Class Initialized
DEBUG - 2016-08-24 05:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 05:38:25 --> Input Class Initialized
INFO - 2016-08-24 05:38:25 --> Language Class Initialized
INFO - 2016-08-24 05:38:25 --> Loader Class Initialized
INFO - 2016-08-24 05:38:25 --> Helper loaded: url_helper
INFO - 2016-08-24 05:38:25 --> Helper loaded: utils_helper
INFO - 2016-08-24 05:38:25 --> Helper loaded: html_helper
INFO - 2016-08-24 05:38:25 --> Helper loaded: form_helper
INFO - 2016-08-24 05:38:25 --> Helper loaded: file_helper
INFO - 2016-08-24 05:38:25 --> Helper loaded: myemail_helper
INFO - 2016-08-24 05:38:25 --> Database Driver Class Initialized
INFO - 2016-08-24 05:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 05:38:25 --> Form Validation Class Initialized
INFO - 2016-08-24 05:38:25 --> Email Class Initialized
INFO - 2016-08-24 05:38:25 --> Controller Class Initialized
INFO - 2016-08-24 05:38:25 --> Model Class Initialized
INFO - 2016-08-24 05:38:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 05:38:25 --> Final output sent to browser
DEBUG - 2016-08-24 05:38:25 --> Total execution time: 0.2844
INFO - 2016-08-24 06:02:03 --> Config Class Initialized
INFO - 2016-08-24 06:02:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:02:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:02:03 --> Utf8 Class Initialized
INFO - 2016-08-24 06:02:03 --> URI Class Initialized
INFO - 2016-08-24 06:02:03 --> Router Class Initialized
INFO - 2016-08-24 06:02:03 --> Output Class Initialized
INFO - 2016-08-24 06:02:03 --> Security Class Initialized
DEBUG - 2016-08-24 06:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:02:03 --> Input Class Initialized
INFO - 2016-08-24 06:02:03 --> Language Class Initialized
INFO - 2016-08-24 06:02:03 --> Loader Class Initialized
INFO - 2016-08-24 06:02:03 --> Helper loaded: url_helper
INFO - 2016-08-24 06:02:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:02:03 --> Helper loaded: html_helper
INFO - 2016-08-24 06:02:03 --> Helper loaded: form_helper
INFO - 2016-08-24 06:02:03 --> Helper loaded: file_helper
INFO - 2016-08-24 06:02:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:02:03 --> Database Driver Class Initialized
ERROR - 2016-08-24 06:02:03 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 313
ERROR - 2016-08-24 06:02:03 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 140
INFO - 2016-08-24 06:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:02:03 --> Form Validation Class Initialized
INFO - 2016-08-24 06:02:03 --> Email Class Initialized
INFO - 2016-08-24 06:02:03 --> Controller Class Initialized
ERROR - 2016-08-24 06:02:03 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:02:03 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:02:03 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:02:03 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:02:03 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:02:58 --> Config Class Initialized
INFO - 2016-08-24 06:02:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:02:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:02:58 --> Utf8 Class Initialized
INFO - 2016-08-24 06:02:58 --> URI Class Initialized
DEBUG - 2016-08-24 06:02:58 --> No URI present. Default controller set.
INFO - 2016-08-24 06:02:58 --> Router Class Initialized
INFO - 2016-08-24 06:02:58 --> Output Class Initialized
INFO - 2016-08-24 06:02:58 --> Security Class Initialized
DEBUG - 2016-08-24 06:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:02:58 --> Input Class Initialized
INFO - 2016-08-24 06:02:58 --> Language Class Initialized
INFO - 2016-08-24 06:02:58 --> Loader Class Initialized
INFO - 2016-08-24 06:02:58 --> Helper loaded: url_helper
INFO - 2016-08-24 06:02:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:02:58 --> Helper loaded: html_helper
INFO - 2016-08-24 06:02:58 --> Helper loaded: form_helper
INFO - 2016-08-24 06:02:58 --> Helper loaded: file_helper
INFO - 2016-08-24 06:02:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:02:58 --> Database Driver Class Initialized
INFO - 2016-08-24 06:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:02:58 --> Form Validation Class Initialized
INFO - 2016-08-24 06:02:58 --> Email Class Initialized
INFO - 2016-08-24 06:02:58 --> Controller Class Initialized
INFO - 2016-08-24 06:02:58 --> Model Class Initialized
INFO - 2016-08-24 06:02:58 --> Model Class Initialized
INFO - 2016-08-24 06:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 06:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 06:02:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 06:02:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 06:02:59 --> Final output sent to browser
DEBUG - 2016-08-24 06:02:59 --> Total execution time: 0.3666
INFO - 2016-08-24 06:03:03 --> Config Class Initialized
INFO - 2016-08-24 06:03:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:03:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:03:04 --> Utf8 Class Initialized
INFO - 2016-08-24 06:03:04 --> URI Class Initialized
INFO - 2016-08-24 06:03:04 --> Router Class Initialized
INFO - 2016-08-24 06:03:04 --> Output Class Initialized
INFO - 2016-08-24 06:03:04 --> Security Class Initialized
DEBUG - 2016-08-24 06:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:03:04 --> Input Class Initialized
INFO - 2016-08-24 06:03:04 --> Language Class Initialized
INFO - 2016-08-24 06:03:04 --> Loader Class Initialized
INFO - 2016-08-24 06:03:04 --> Helper loaded: url_helper
INFO - 2016-08-24 06:03:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:03:04 --> Helper loaded: html_helper
INFO - 2016-08-24 06:03:04 --> Helper loaded: form_helper
INFO - 2016-08-24 06:03:04 --> Helper loaded: file_helper
INFO - 2016-08-24 06:03:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:03:04 --> Database Driver Class Initialized
ERROR - 2016-08-24 06:03:04 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 313
ERROR - 2016-08-24 06:03:04 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 140
INFO - 2016-08-24 06:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:03:04 --> Form Validation Class Initialized
INFO - 2016-08-24 06:03:04 --> Email Class Initialized
INFO - 2016-08-24 06:03:04 --> Controller Class Initialized
ERROR - 2016-08-24 06:03:04 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:03:04 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:03:04 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:03:04 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:03:04 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:04:17 --> Config Class Initialized
INFO - 2016-08-24 06:04:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:04:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:04:17 --> Utf8 Class Initialized
INFO - 2016-08-24 06:04:17 --> URI Class Initialized
INFO - 2016-08-24 06:04:17 --> Router Class Initialized
INFO - 2016-08-24 06:04:18 --> Output Class Initialized
INFO - 2016-08-24 06:04:18 --> Security Class Initialized
DEBUG - 2016-08-24 06:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:04:18 --> Input Class Initialized
INFO - 2016-08-24 06:04:18 --> Language Class Initialized
INFO - 2016-08-24 06:04:18 --> Loader Class Initialized
INFO - 2016-08-24 06:04:18 --> Helper loaded: url_helper
INFO - 2016-08-24 06:04:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:04:18 --> Helper loaded: html_helper
INFO - 2016-08-24 06:04:18 --> Helper loaded: form_helper
INFO - 2016-08-24 06:04:18 --> Helper loaded: file_helper
INFO - 2016-08-24 06:04:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:04:18 --> Database Driver Class Initialized
INFO - 2016-08-24 06:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:04:18 --> Form Validation Class Initialized
INFO - 2016-08-24 06:04:18 --> Email Class Initialized
INFO - 2016-08-24 06:04:18 --> Controller Class Initialized
ERROR - 2016-08-24 06:04:18 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:04:18 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:04:18 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:04:18 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:04:18 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:04:30 --> Config Class Initialized
INFO - 2016-08-24 06:04:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:04:30 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:04:30 --> Utf8 Class Initialized
INFO - 2016-08-24 06:04:30 --> URI Class Initialized
INFO - 2016-08-24 06:04:30 --> Router Class Initialized
INFO - 2016-08-24 06:04:30 --> Output Class Initialized
INFO - 2016-08-24 06:04:30 --> Security Class Initialized
DEBUG - 2016-08-24 06:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:04:30 --> Input Class Initialized
INFO - 2016-08-24 06:04:30 --> Language Class Initialized
INFO - 2016-08-24 06:04:30 --> Loader Class Initialized
INFO - 2016-08-24 06:04:30 --> Helper loaded: url_helper
INFO - 2016-08-24 06:04:30 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:04:30 --> Helper loaded: html_helper
INFO - 2016-08-24 06:04:30 --> Helper loaded: form_helper
INFO - 2016-08-24 06:04:30 --> Helper loaded: file_helper
INFO - 2016-08-24 06:04:30 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:04:30 --> Database Driver Class Initialized
ERROR - 2016-08-24 06:04:30 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 313
ERROR - 2016-08-24 06:04:30 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 140
INFO - 2016-08-24 06:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:04:30 --> Form Validation Class Initialized
INFO - 2016-08-24 06:04:30 --> Email Class Initialized
INFO - 2016-08-24 06:04:31 --> Controller Class Initialized
ERROR - 2016-08-24 06:04:31 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:04:31 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:04:31 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:04:31 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:04:31 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:07:23 --> Config Class Initialized
INFO - 2016-08-24 06:07:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:23 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:23 --> URI Class Initialized
INFO - 2016-08-24 06:07:23 --> Router Class Initialized
INFO - 2016-08-24 06:07:23 --> Output Class Initialized
INFO - 2016-08-24 06:07:23 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:23 --> Input Class Initialized
INFO - 2016-08-24 06:07:23 --> Language Class Initialized
INFO - 2016-08-24 06:07:23 --> Loader Class Initialized
INFO - 2016-08-24 06:07:23 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:23 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:23 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:23 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:23 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:23 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:23 --> Database Driver Class Initialized
ERROR - 2016-08-24 06:07:23 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 313
ERROR - 2016-08-24 06:07:23 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 140
INFO - 2016-08-24 06:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:23 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:23 --> Email Class Initialized
INFO - 2016-08-24 06:07:23 --> Controller Class Initialized
ERROR - 2016-08-24 06:07:23 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:07:23 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:07:23 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:07:23 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:07:23 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:07:30 --> Config Class Initialized
INFO - 2016-08-24 06:07:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:30 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:30 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:30 --> URI Class Initialized
DEBUG - 2016-08-24 06:07:30 --> No URI present. Default controller set.
INFO - 2016-08-24 06:07:30 --> Router Class Initialized
INFO - 2016-08-24 06:07:30 --> Output Class Initialized
INFO - 2016-08-24 06:07:30 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:30 --> Input Class Initialized
INFO - 2016-08-24 06:07:30 --> Language Class Initialized
INFO - 2016-08-24 06:07:30 --> Loader Class Initialized
INFO - 2016-08-24 06:07:30 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:30 --> Database Driver Class Initialized
INFO - 2016-08-24 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:30 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:30 --> Email Class Initialized
INFO - 2016-08-24 06:07:30 --> Controller Class Initialized
INFO - 2016-08-24 06:07:30 --> Config Class Initialized
INFO - 2016-08-24 06:07:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:30 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:30 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:30 --> URI Class Initialized
INFO - 2016-08-24 06:07:30 --> Router Class Initialized
INFO - 2016-08-24 06:07:30 --> Output Class Initialized
INFO - 2016-08-24 06:07:30 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:30 --> Input Class Initialized
INFO - 2016-08-24 06:07:30 --> Language Class Initialized
INFO - 2016-08-24 06:07:30 --> Loader Class Initialized
INFO - 2016-08-24 06:07:30 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:30 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:30 --> Database Driver Class Initialized
INFO - 2016-08-24 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:30 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:30 --> Email Class Initialized
INFO - 2016-08-24 06:07:30 --> Controller Class Initialized
INFO - 2016-08-24 06:07:30 --> Model Class Initialized
DEBUG - 2016-08-24 06:07:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 06:07:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 06:07:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 06:07:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 06:07:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 06:07:30 --> Final output sent to browser
DEBUG - 2016-08-24 06:07:30 --> Total execution time: 0.3661
INFO - 2016-08-24 06:07:33 --> Config Class Initialized
INFO - 2016-08-24 06:07:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:33 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:33 --> URI Class Initialized
INFO - 2016-08-24 06:07:33 --> Router Class Initialized
INFO - 2016-08-24 06:07:33 --> Output Class Initialized
INFO - 2016-08-24 06:07:33 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:33 --> Input Class Initialized
INFO - 2016-08-24 06:07:33 --> Language Class Initialized
INFO - 2016-08-24 06:07:33 --> Loader Class Initialized
INFO - 2016-08-24 06:07:33 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:33 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:33 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:33 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:33 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:33 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:33 --> Database Driver Class Initialized
INFO - 2016-08-24 06:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:33 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:33 --> Email Class Initialized
INFO - 2016-08-24 06:07:33 --> Controller Class Initialized
INFO - 2016-08-24 06:07:33 --> Model Class Initialized
INFO - 2016-08-24 06:07:38 --> Config Class Initialized
INFO - 2016-08-24 06:07:38 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:38 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:38 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:38 --> URI Class Initialized
INFO - 2016-08-24 06:07:38 --> Router Class Initialized
INFO - 2016-08-24 06:07:38 --> Output Class Initialized
INFO - 2016-08-24 06:07:38 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:38 --> Input Class Initialized
INFO - 2016-08-24 06:07:38 --> Language Class Initialized
INFO - 2016-08-24 06:07:38 --> Loader Class Initialized
INFO - 2016-08-24 06:07:38 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:38 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:38 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:38 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:38 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:38 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:38 --> Database Driver Class Initialized
INFO - 2016-08-24 06:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:38 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:38 --> Email Class Initialized
INFO - 2016-08-24 06:07:38 --> Controller Class Initialized
INFO - 2016-08-24 06:07:38 --> Model Class Initialized
ERROR - 2016-08-24 06:07:39 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-08-24 06:07:46 --> Config Class Initialized
INFO - 2016-08-24 06:07:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:46 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:46 --> URI Class Initialized
INFO - 2016-08-24 06:07:46 --> Router Class Initialized
INFO - 2016-08-24 06:07:46 --> Output Class Initialized
INFO - 2016-08-24 06:07:46 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:46 --> Input Class Initialized
INFO - 2016-08-24 06:07:47 --> Language Class Initialized
INFO - 2016-08-24 06:07:47 --> Loader Class Initialized
INFO - 2016-08-24 06:07:47 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:47 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:47 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:47 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:47 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:47 --> Database Driver Class Initialized
INFO - 2016-08-24 06:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:47 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:47 --> Email Class Initialized
INFO - 2016-08-24 06:07:47 --> Controller Class Initialized
INFO - 2016-08-24 06:07:47 --> Model Class Initialized
DEBUG - 2016-08-24 06:07:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 06:07:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 06:07:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 06:07:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 06:07:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 06:07:47 --> Final output sent to browser
DEBUG - 2016-08-24 06:07:47 --> Total execution time: 0.3797
INFO - 2016-08-24 06:07:52 --> Config Class Initialized
INFO - 2016-08-24 06:07:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:07:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:07:53 --> Utf8 Class Initialized
INFO - 2016-08-24 06:07:53 --> URI Class Initialized
INFO - 2016-08-24 06:07:53 --> Router Class Initialized
INFO - 2016-08-24 06:07:53 --> Output Class Initialized
INFO - 2016-08-24 06:07:53 --> Security Class Initialized
DEBUG - 2016-08-24 06:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:07:53 --> Input Class Initialized
INFO - 2016-08-24 06:07:53 --> Language Class Initialized
INFO - 2016-08-24 06:07:53 --> Loader Class Initialized
INFO - 2016-08-24 06:07:53 --> Helper loaded: url_helper
INFO - 2016-08-24 06:07:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:07:53 --> Helper loaded: html_helper
INFO - 2016-08-24 06:07:53 --> Helper loaded: form_helper
INFO - 2016-08-24 06:07:53 --> Helper loaded: file_helper
INFO - 2016-08-24 06:07:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:07:53 --> Database Driver Class Initialized
ERROR - 2016-08-24 06:07:53 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 313
ERROR - 2016-08-24 06:07:53 --> Severity: Notice --> A session had already been started - ignoring session_start() D:\wamp\www\library.pnc.lan\system\libraries\Session\Session.php 140
INFO - 2016-08-24 06:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:07:53 --> Form Validation Class Initialized
INFO - 2016-08-24 06:07:53 --> Email Class Initialized
INFO - 2016-08-24 06:07:53 --> Controller Class Initialized
ERROR - 2016-08-24 06:07:53 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:07:53 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 16
ERROR - 2016-08-24 06:07:53 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:07:53 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 17
ERROR - 2016-08-24 06:07:53 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 26
INFO - 2016-08-24 06:10:55 --> Config Class Initialized
INFO - 2016-08-24 06:10:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:10:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:10:55 --> Utf8 Class Initialized
INFO - 2016-08-24 06:10:55 --> URI Class Initialized
INFO - 2016-08-24 06:10:55 --> Router Class Initialized
INFO - 2016-08-24 06:10:55 --> Output Class Initialized
INFO - 2016-08-24 06:10:55 --> Security Class Initialized
DEBUG - 2016-08-24 06:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:10:55 --> Input Class Initialized
INFO - 2016-08-24 06:10:55 --> Language Class Initialized
INFO - 2016-08-24 06:10:55 --> Loader Class Initialized
INFO - 2016-08-24 06:10:55 --> Helper loaded: url_helper
INFO - 2016-08-24 06:10:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:10:55 --> Helper loaded: html_helper
INFO - 2016-08-24 06:10:55 --> Helper loaded: form_helper
INFO - 2016-08-24 06:10:55 --> Helper loaded: file_helper
INFO - 2016-08-24 06:10:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:10:55 --> Database Driver Class Initialized
INFO - 2016-08-24 06:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:10:55 --> Form Validation Class Initialized
INFO - 2016-08-24 06:10:55 --> Email Class Initialized
INFO - 2016-08-24 06:10:55 --> Controller Class Initialized
INFO - 2016-08-24 06:10:55 --> Model Class Initialized
INFO - 2016-08-24 06:10:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:10:55 --> Final output sent to browser
DEBUG - 2016-08-24 06:10:55 --> Total execution time: 0.3197
INFO - 2016-08-24 06:10:55 --> Config Class Initialized
INFO - 2016-08-24 06:10:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:10:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:10:55 --> Utf8 Class Initialized
INFO - 2016-08-24 06:10:55 --> URI Class Initialized
INFO - 2016-08-24 06:10:55 --> Router Class Initialized
INFO - 2016-08-24 06:10:55 --> Output Class Initialized
INFO - 2016-08-24 06:10:55 --> Security Class Initialized
DEBUG - 2016-08-24 06:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:10:55 --> Input Class Initialized
INFO - 2016-08-24 06:10:55 --> Language Class Initialized
ERROR - 2016-08-24 06:10:56 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:11:39 --> Config Class Initialized
INFO - 2016-08-24 06:11:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:11:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:11:39 --> Utf8 Class Initialized
INFO - 2016-08-24 06:11:39 --> URI Class Initialized
INFO - 2016-08-24 06:11:39 --> Router Class Initialized
INFO - 2016-08-24 06:11:39 --> Output Class Initialized
INFO - 2016-08-24 06:11:39 --> Security Class Initialized
DEBUG - 2016-08-24 06:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:11:39 --> Input Class Initialized
INFO - 2016-08-24 06:11:39 --> Language Class Initialized
INFO - 2016-08-24 06:11:39 --> Loader Class Initialized
INFO - 2016-08-24 06:11:39 --> Helper loaded: url_helper
INFO - 2016-08-24 06:11:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:11:39 --> Helper loaded: html_helper
INFO - 2016-08-24 06:11:39 --> Helper loaded: form_helper
INFO - 2016-08-24 06:11:39 --> Helper loaded: file_helper
INFO - 2016-08-24 06:11:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:11:39 --> Database Driver Class Initialized
INFO - 2016-08-24 06:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:11:39 --> Form Validation Class Initialized
INFO - 2016-08-24 06:11:39 --> Email Class Initialized
INFO - 2016-08-24 06:11:39 --> Controller Class Initialized
INFO - 2016-08-24 06:11:39 --> Model Class Initialized
INFO - 2016-08-24 06:11:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:11:39 --> Final output sent to browser
DEBUG - 2016-08-24 06:11:39 --> Total execution time: 0.3138
INFO - 2016-08-24 06:11:40 --> Config Class Initialized
INFO - 2016-08-24 06:11:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:11:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:11:40 --> Utf8 Class Initialized
INFO - 2016-08-24 06:11:40 --> URI Class Initialized
INFO - 2016-08-24 06:11:40 --> Router Class Initialized
INFO - 2016-08-24 06:11:40 --> Output Class Initialized
INFO - 2016-08-24 06:11:40 --> Security Class Initialized
DEBUG - 2016-08-24 06:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:11:40 --> Input Class Initialized
INFO - 2016-08-24 06:11:40 --> Language Class Initialized
ERROR - 2016-08-24 06:11:40 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:14:21 --> Config Class Initialized
INFO - 2016-08-24 06:14:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:14:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:14:21 --> Utf8 Class Initialized
INFO - 2016-08-24 06:14:21 --> URI Class Initialized
INFO - 2016-08-24 06:14:21 --> Router Class Initialized
INFO - 2016-08-24 06:14:21 --> Output Class Initialized
INFO - 2016-08-24 06:14:21 --> Security Class Initialized
DEBUG - 2016-08-24 06:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:14:21 --> Input Class Initialized
INFO - 2016-08-24 06:14:21 --> Language Class Initialized
INFO - 2016-08-24 06:14:21 --> Loader Class Initialized
INFO - 2016-08-24 06:14:21 --> Helper loaded: url_helper
INFO - 2016-08-24 06:14:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:14:21 --> Helper loaded: html_helper
INFO - 2016-08-24 06:14:21 --> Helper loaded: form_helper
INFO - 2016-08-24 06:14:21 --> Helper loaded: file_helper
INFO - 2016-08-24 06:14:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:14:21 --> Database Driver Class Initialized
INFO - 2016-08-24 06:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:14:21 --> Form Validation Class Initialized
INFO - 2016-08-24 06:14:21 --> Email Class Initialized
INFO - 2016-08-24 06:14:21 --> Controller Class Initialized
INFO - 2016-08-24 06:14:21 --> Model Class Initialized
INFO - 2016-08-24 06:14:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:14:21 --> Final output sent to browser
DEBUG - 2016-08-24 06:14:21 --> Total execution time: 0.3125
INFO - 2016-08-24 06:14:22 --> Config Class Initialized
INFO - 2016-08-24 06:14:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:14:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:14:22 --> Utf8 Class Initialized
INFO - 2016-08-24 06:14:22 --> URI Class Initialized
INFO - 2016-08-24 06:14:22 --> Router Class Initialized
INFO - 2016-08-24 06:14:22 --> Output Class Initialized
INFO - 2016-08-24 06:14:22 --> Security Class Initialized
DEBUG - 2016-08-24 06:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:14:22 --> Input Class Initialized
INFO - 2016-08-24 06:14:22 --> Language Class Initialized
ERROR - 2016-08-24 06:14:22 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:15:19 --> Config Class Initialized
INFO - 2016-08-24 06:15:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:15:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:15:19 --> Utf8 Class Initialized
INFO - 2016-08-24 06:15:19 --> URI Class Initialized
INFO - 2016-08-24 06:15:19 --> Router Class Initialized
INFO - 2016-08-24 06:15:19 --> Output Class Initialized
INFO - 2016-08-24 06:15:19 --> Security Class Initialized
DEBUG - 2016-08-24 06:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:15:19 --> Input Class Initialized
INFO - 2016-08-24 06:15:19 --> Language Class Initialized
INFO - 2016-08-24 06:15:19 --> Loader Class Initialized
INFO - 2016-08-24 06:15:19 --> Helper loaded: url_helper
INFO - 2016-08-24 06:15:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:15:19 --> Helper loaded: html_helper
INFO - 2016-08-24 06:15:19 --> Helper loaded: form_helper
INFO - 2016-08-24 06:15:19 --> Helper loaded: file_helper
INFO - 2016-08-24 06:15:19 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:15:19 --> Database Driver Class Initialized
INFO - 2016-08-24 06:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:15:19 --> Form Validation Class Initialized
INFO - 2016-08-24 06:15:19 --> Email Class Initialized
INFO - 2016-08-24 06:15:19 --> Controller Class Initialized
INFO - 2016-08-24 06:15:19 --> Model Class Initialized
INFO - 2016-08-24 06:15:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:15:19 --> Final output sent to browser
DEBUG - 2016-08-24 06:15:19 --> Total execution time: 0.3292
INFO - 2016-08-24 06:15:19 --> Config Class Initialized
INFO - 2016-08-24 06:15:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:15:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:15:19 --> Utf8 Class Initialized
INFO - 2016-08-24 06:15:19 --> URI Class Initialized
INFO - 2016-08-24 06:15:19 --> Router Class Initialized
INFO - 2016-08-24 06:15:19 --> Output Class Initialized
INFO - 2016-08-24 06:15:19 --> Security Class Initialized
DEBUG - 2016-08-24 06:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:15:19 --> Input Class Initialized
INFO - 2016-08-24 06:15:19 --> Language Class Initialized
ERROR - 2016-08-24 06:15:19 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:18:02 --> Config Class Initialized
INFO - 2016-08-24 06:18:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:18:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:18:02 --> Utf8 Class Initialized
INFO - 2016-08-24 06:18:02 --> URI Class Initialized
INFO - 2016-08-24 06:18:02 --> Router Class Initialized
INFO - 2016-08-24 06:18:02 --> Output Class Initialized
INFO - 2016-08-24 06:18:02 --> Security Class Initialized
DEBUG - 2016-08-24 06:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:18:02 --> Input Class Initialized
INFO - 2016-08-24 06:18:02 --> Language Class Initialized
INFO - 2016-08-24 06:18:02 --> Loader Class Initialized
INFO - 2016-08-24 06:18:02 --> Helper loaded: url_helper
INFO - 2016-08-24 06:18:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:18:02 --> Helper loaded: html_helper
INFO - 2016-08-24 06:18:02 --> Helper loaded: form_helper
INFO - 2016-08-24 06:18:02 --> Helper loaded: file_helper
INFO - 2016-08-24 06:18:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:18:02 --> Database Driver Class Initialized
INFO - 2016-08-24 06:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:18:02 --> Form Validation Class Initialized
INFO - 2016-08-24 06:18:02 --> Email Class Initialized
INFO - 2016-08-24 06:18:02 --> Controller Class Initialized
INFO - 2016-08-24 06:18:02 --> Model Class Initialized
INFO - 2016-08-24 06:18:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:18:02 --> Final output sent to browser
DEBUG - 2016-08-24 06:18:02 --> Total execution time: 0.3134
INFO - 2016-08-24 06:18:03 --> Config Class Initialized
INFO - 2016-08-24 06:18:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:18:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:18:03 --> Utf8 Class Initialized
INFO - 2016-08-24 06:18:03 --> URI Class Initialized
INFO - 2016-08-24 06:18:03 --> Router Class Initialized
INFO - 2016-08-24 06:18:03 --> Output Class Initialized
INFO - 2016-08-24 06:18:03 --> Security Class Initialized
DEBUG - 2016-08-24 06:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:18:03 --> Input Class Initialized
INFO - 2016-08-24 06:18:03 --> Language Class Initialized
ERROR - 2016-08-24 06:18:03 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:18:05 --> Config Class Initialized
INFO - 2016-08-24 06:18:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:18:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:18:05 --> Utf8 Class Initialized
INFO - 2016-08-24 06:18:05 --> URI Class Initialized
INFO - 2016-08-24 06:18:05 --> Router Class Initialized
INFO - 2016-08-24 06:18:05 --> Output Class Initialized
INFO - 2016-08-24 06:18:05 --> Security Class Initialized
DEBUG - 2016-08-24 06:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:18:05 --> Input Class Initialized
INFO - 2016-08-24 06:18:05 --> Language Class Initialized
INFO - 2016-08-24 06:18:05 --> Loader Class Initialized
INFO - 2016-08-24 06:18:05 --> Helper loaded: url_helper
INFO - 2016-08-24 06:18:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:18:05 --> Helper loaded: html_helper
INFO - 2016-08-24 06:18:05 --> Helper loaded: form_helper
INFO - 2016-08-24 06:18:05 --> Helper loaded: file_helper
INFO - 2016-08-24 06:18:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:18:05 --> Database Driver Class Initialized
INFO - 2016-08-24 06:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:18:05 --> Form Validation Class Initialized
INFO - 2016-08-24 06:18:05 --> Email Class Initialized
INFO - 2016-08-24 06:18:05 --> Controller Class Initialized
INFO - 2016-08-24 06:18:05 --> Model Class Initialized
INFO - 2016-08-24 06:18:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:18:05 --> Final output sent to browser
DEBUG - 2016-08-24 06:18:05 --> Total execution time: 0.3092
INFO - 2016-08-24 06:18:05 --> Config Class Initialized
INFO - 2016-08-24 06:18:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:18:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:18:05 --> Utf8 Class Initialized
INFO - 2016-08-24 06:18:05 --> URI Class Initialized
INFO - 2016-08-24 06:18:05 --> Router Class Initialized
INFO - 2016-08-24 06:18:05 --> Output Class Initialized
INFO - 2016-08-24 06:18:05 --> Security Class Initialized
DEBUG - 2016-08-24 06:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:18:05 --> Input Class Initialized
INFO - 2016-08-24 06:18:05 --> Language Class Initialized
ERROR - 2016-08-24 06:18:05 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:19:26 --> Config Class Initialized
INFO - 2016-08-24 06:19:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:26 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:26 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:26 --> URI Class Initialized
INFO - 2016-08-24 06:19:26 --> Router Class Initialized
INFO - 2016-08-24 06:19:26 --> Output Class Initialized
INFO - 2016-08-24 06:19:26 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:26 --> Input Class Initialized
INFO - 2016-08-24 06:19:26 --> Language Class Initialized
INFO - 2016-08-24 06:19:26 --> Loader Class Initialized
INFO - 2016-08-24 06:19:26 --> Helper loaded: url_helper
INFO - 2016-08-24 06:19:26 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:19:26 --> Helper loaded: html_helper
INFO - 2016-08-24 06:19:27 --> Helper loaded: form_helper
INFO - 2016-08-24 06:19:27 --> Helper loaded: file_helper
INFO - 2016-08-24 06:19:27 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:19:27 --> Database Driver Class Initialized
INFO - 2016-08-24 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:19:27 --> Form Validation Class Initialized
INFO - 2016-08-24 06:19:27 --> Email Class Initialized
INFO - 2016-08-24 06:19:27 --> Controller Class Initialized
INFO - 2016-08-24 06:19:27 --> Model Class Initialized
INFO - 2016-08-24 06:19:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:19:27 --> Final output sent to browser
DEBUG - 2016-08-24 06:19:27 --> Total execution time: 0.3214
INFO - 2016-08-24 06:19:27 --> Config Class Initialized
INFO - 2016-08-24 06:19:27 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:27 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:27 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:27 --> URI Class Initialized
INFO - 2016-08-24 06:19:27 --> Router Class Initialized
INFO - 2016-08-24 06:19:27 --> Output Class Initialized
INFO - 2016-08-24 06:19:27 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:27 --> Input Class Initialized
INFO - 2016-08-24 06:19:27 --> Language Class Initialized
ERROR - 2016-08-24 06:19:27 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:19:28 --> Config Class Initialized
INFO - 2016-08-24 06:19:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:28 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:28 --> URI Class Initialized
INFO - 2016-08-24 06:19:28 --> Router Class Initialized
INFO - 2016-08-24 06:19:28 --> Output Class Initialized
INFO - 2016-08-24 06:19:28 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:29 --> Input Class Initialized
INFO - 2016-08-24 06:19:29 --> Language Class Initialized
INFO - 2016-08-24 06:19:29 --> Loader Class Initialized
INFO - 2016-08-24 06:19:29 --> Helper loaded: url_helper
INFO - 2016-08-24 06:19:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:19:29 --> Helper loaded: html_helper
INFO - 2016-08-24 06:19:29 --> Helper loaded: form_helper
INFO - 2016-08-24 06:19:29 --> Helper loaded: file_helper
INFO - 2016-08-24 06:19:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:19:29 --> Database Driver Class Initialized
INFO - 2016-08-24 06:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:19:29 --> Form Validation Class Initialized
INFO - 2016-08-24 06:19:29 --> Email Class Initialized
INFO - 2016-08-24 06:19:29 --> Controller Class Initialized
INFO - 2016-08-24 06:19:29 --> Model Class Initialized
INFO - 2016-08-24 06:19:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:19:29 --> Final output sent to browser
DEBUG - 2016-08-24 06:19:29 --> Total execution time: 0.2948
INFO - 2016-08-24 06:19:29 --> Config Class Initialized
INFO - 2016-08-24 06:19:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:29 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:29 --> URI Class Initialized
INFO - 2016-08-24 06:19:29 --> Router Class Initialized
INFO - 2016-08-24 06:19:29 --> Output Class Initialized
INFO - 2016-08-24 06:19:29 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:29 --> Input Class Initialized
INFO - 2016-08-24 06:19:29 --> Language Class Initialized
ERROR - 2016-08-24 06:19:29 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 06:19:35 --> Config Class Initialized
INFO - 2016-08-24 06:19:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:35 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:35 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:35 --> URI Class Initialized
INFO - 2016-08-24 06:19:35 --> Router Class Initialized
INFO - 2016-08-24 06:19:35 --> Output Class Initialized
INFO - 2016-08-24 06:19:35 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:35 --> Input Class Initialized
INFO - 2016-08-24 06:19:35 --> Language Class Initialized
INFO - 2016-08-24 06:19:35 --> Loader Class Initialized
INFO - 2016-08-24 06:19:35 --> Helper loaded: url_helper
INFO - 2016-08-24 06:19:35 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:19:35 --> Helper loaded: html_helper
INFO - 2016-08-24 06:19:35 --> Helper loaded: form_helper
INFO - 2016-08-24 06:19:35 --> Helper loaded: file_helper
INFO - 2016-08-24 06:19:35 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:19:35 --> Database Driver Class Initialized
INFO - 2016-08-24 06:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:19:35 --> Form Validation Class Initialized
INFO - 2016-08-24 06:19:35 --> Email Class Initialized
INFO - 2016-08-24 06:19:35 --> Controller Class Initialized
INFO - 2016-08-24 06:19:35 --> Model Class Initialized
INFO - 2016-08-24 06:19:37 --> Config Class Initialized
INFO - 2016-08-24 06:19:37 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:19:37 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:19:37 --> Utf8 Class Initialized
INFO - 2016-08-24 06:19:37 --> URI Class Initialized
INFO - 2016-08-24 06:19:37 --> Router Class Initialized
INFO - 2016-08-24 06:19:37 --> Output Class Initialized
INFO - 2016-08-24 06:19:37 --> Security Class Initialized
DEBUG - 2016-08-24 06:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:19:37 --> Input Class Initialized
INFO - 2016-08-24 06:19:37 --> Language Class Initialized
INFO - 2016-08-24 06:19:37 --> Loader Class Initialized
INFO - 2016-08-24 06:19:37 --> Helper loaded: url_helper
INFO - 2016-08-24 06:19:37 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:19:37 --> Helper loaded: html_helper
INFO - 2016-08-24 06:19:37 --> Helper loaded: form_helper
INFO - 2016-08-24 06:19:37 --> Helper loaded: file_helper
INFO - 2016-08-24 06:19:37 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:19:38 --> Database Driver Class Initialized
INFO - 2016-08-24 06:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:19:38 --> Form Validation Class Initialized
INFO - 2016-08-24 06:19:38 --> Email Class Initialized
INFO - 2016-08-24 06:19:38 --> Controller Class Initialized
INFO - 2016-08-24 06:19:38 --> Model Class Initialized
ERROR - 2016-08-24 06:19:38 --> Query error: Unknown column 'first_name' in 'field list' - Invalid query: INSERT INTO `users` (`oauth_provider`, `oauth_uid`, `first_name`, `last_name`, `email`, `gender`, `locale`, `profile_url`, `picture_url`, `created`, `modified`) VALUES ('google', '117790144900062576188', 'Ou', 'Sophea', 'ousophea@gmail.com', 'male', 'en', 'https://plus.google.com/+OuSophea', 'https://lh6.googleusercontent.com/-OjehdSSfkR0/AAAAAAAAAAI/AAAAAAAAKmI/ODO_qGr3tBU/photo.jpg', '2016-08-24 06:19:38', '2016-08-24 06:19:38')
INFO - 2016-08-24 06:19:38 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-24 06:24:13 --> Config Class Initialized
INFO - 2016-08-24 06:24:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:24:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:24:13 --> Utf8 Class Initialized
INFO - 2016-08-24 06:24:13 --> URI Class Initialized
INFO - 2016-08-24 06:24:13 --> Router Class Initialized
INFO - 2016-08-24 06:24:13 --> Output Class Initialized
INFO - 2016-08-24 06:24:13 --> Security Class Initialized
DEBUG - 2016-08-24 06:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:24:13 --> Input Class Initialized
INFO - 2016-08-24 06:24:13 --> Language Class Initialized
INFO - 2016-08-24 06:24:13 --> Loader Class Initialized
INFO - 2016-08-24 06:24:13 --> Helper loaded: url_helper
INFO - 2016-08-24 06:24:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:24:13 --> Helper loaded: html_helper
INFO - 2016-08-24 06:24:13 --> Helper loaded: form_helper
INFO - 2016-08-24 06:24:13 --> Helper loaded: file_helper
INFO - 2016-08-24 06:24:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:24:13 --> Database Driver Class Initialized
INFO - 2016-08-24 06:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:24:13 --> Form Validation Class Initialized
INFO - 2016-08-24 06:24:13 --> Email Class Initialized
INFO - 2016-08-24 06:24:13 --> Controller Class Initialized
INFO - 2016-08-24 06:24:13 --> Model Class Initialized
ERROR - 2016-08-24 06:24:14 --> Severity: Notice --> Undefined index: first_name D:\wamp\www\library.pnc.lan\application\views\user_authentication\index.php 43
ERROR - 2016-08-24 06:24:14 --> Severity: Notice --> Undefined index: first_name D:\wamp\www\library.pnc.lan\application\views\user_authentication\index.php 47
ERROR - 2016-08-24 06:24:14 --> Severity: Notice --> Undefined index: last_name D:\wamp\www\library.pnc.lan\application\views\user_authentication\index.php 47
INFO - 2016-08-24 06:24:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:24:14 --> Final output sent to browser
DEBUG - 2016-08-24 06:24:14 --> Total execution time: 1.2718
INFO - 2016-08-24 06:24:52 --> Config Class Initialized
INFO - 2016-08-24 06:24:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:24:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:24:52 --> Utf8 Class Initialized
INFO - 2016-08-24 06:24:52 --> URI Class Initialized
INFO - 2016-08-24 06:24:52 --> Router Class Initialized
INFO - 2016-08-24 06:24:52 --> Output Class Initialized
INFO - 2016-08-24 06:24:52 --> Security Class Initialized
DEBUG - 2016-08-24 06:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:24:52 --> Input Class Initialized
INFO - 2016-08-24 06:24:52 --> Language Class Initialized
INFO - 2016-08-24 06:24:52 --> Loader Class Initialized
INFO - 2016-08-24 06:24:52 --> Helper loaded: url_helper
INFO - 2016-08-24 06:24:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:24:52 --> Helper loaded: html_helper
INFO - 2016-08-24 06:24:52 --> Helper loaded: form_helper
INFO - 2016-08-24 06:24:52 --> Helper loaded: file_helper
INFO - 2016-08-24 06:24:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:24:52 --> Database Driver Class Initialized
INFO - 2016-08-24 06:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:24:52 --> Form Validation Class Initialized
INFO - 2016-08-24 06:24:52 --> Email Class Initialized
INFO - 2016-08-24 06:24:52 --> Controller Class Initialized
INFO - 2016-08-24 06:24:52 --> Model Class Initialized
INFO - 2016-08-24 06:24:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:24:53 --> Final output sent to browser
DEBUG - 2016-08-24 06:24:53 --> Total execution time: 1.1563
INFO - 2016-08-24 06:25:28 --> Config Class Initialized
INFO - 2016-08-24 06:25:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:25:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:25:28 --> Utf8 Class Initialized
INFO - 2016-08-24 06:25:28 --> URI Class Initialized
INFO - 2016-08-24 06:25:28 --> Router Class Initialized
INFO - 2016-08-24 06:25:28 --> Output Class Initialized
INFO - 2016-08-24 06:25:28 --> Security Class Initialized
DEBUG - 2016-08-24 06:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:25:28 --> Input Class Initialized
INFO - 2016-08-24 06:25:28 --> Language Class Initialized
INFO - 2016-08-24 06:25:28 --> Loader Class Initialized
INFO - 2016-08-24 06:25:28 --> Helper loaded: url_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: html_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: form_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: file_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:25:28 --> Database Driver Class Initialized
INFO - 2016-08-24 06:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:25:28 --> Form Validation Class Initialized
INFO - 2016-08-24 06:25:28 --> Email Class Initialized
INFO - 2016-08-24 06:25:28 --> Controller Class Initialized
INFO - 2016-08-24 06:25:28 --> Model Class Initialized
INFO - 2016-08-24 06:25:28 --> Config Class Initialized
INFO - 2016-08-24 06:25:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:25:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:25:28 --> Utf8 Class Initialized
INFO - 2016-08-24 06:25:28 --> URI Class Initialized
INFO - 2016-08-24 06:25:28 --> Router Class Initialized
INFO - 2016-08-24 06:25:28 --> Output Class Initialized
INFO - 2016-08-24 06:25:28 --> Security Class Initialized
DEBUG - 2016-08-24 06:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:25:28 --> Input Class Initialized
INFO - 2016-08-24 06:25:28 --> Language Class Initialized
INFO - 2016-08-24 06:25:28 --> Loader Class Initialized
INFO - 2016-08-24 06:25:28 --> Helper loaded: url_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: utils_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: html_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: form_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: file_helper
INFO - 2016-08-24 06:25:28 --> Helper loaded: myemail_helper
INFO - 2016-08-24 06:25:28 --> Database Driver Class Initialized
INFO - 2016-08-24 06:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 06:25:28 --> Form Validation Class Initialized
INFO - 2016-08-24 06:25:28 --> Email Class Initialized
INFO - 2016-08-24 06:25:28 --> Controller Class Initialized
INFO - 2016-08-24 06:25:28 --> Model Class Initialized
INFO - 2016-08-24 06:25:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 06:25:28 --> Final output sent to browser
DEBUG - 2016-08-24 06:25:28 --> Total execution time: 0.2947
INFO - 2016-08-24 06:25:29 --> Config Class Initialized
INFO - 2016-08-24 06:25:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 06:25:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 06:25:29 --> Utf8 Class Initialized
INFO - 2016-08-24 06:25:29 --> URI Class Initialized
INFO - 2016-08-24 06:25:29 --> Router Class Initialized
INFO - 2016-08-24 06:25:29 --> Output Class Initialized
INFO - 2016-08-24 06:25:29 --> Security Class Initialized
DEBUG - 2016-08-24 06:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 06:25:29 --> Input Class Initialized
INFO - 2016-08-24 06:25:29 --> Language Class Initialized
ERROR - 2016-08-24 06:25:29 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:17:47 --> Config Class Initialized
INFO - 2016-08-24 07:17:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:17:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:17:47 --> Utf8 Class Initialized
INFO - 2016-08-24 07:17:47 --> URI Class Initialized
INFO - 2016-08-24 07:17:47 --> Router Class Initialized
INFO - 2016-08-24 07:17:47 --> Output Class Initialized
INFO - 2016-08-24 07:17:47 --> Security Class Initialized
DEBUG - 2016-08-24 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:17:48 --> Input Class Initialized
INFO - 2016-08-24 07:17:48 --> Language Class Initialized
INFO - 2016-08-24 07:17:48 --> Loader Class Initialized
INFO - 2016-08-24 07:17:48 --> Helper loaded: url_helper
INFO - 2016-08-24 07:17:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:17:48 --> Helper loaded: html_helper
INFO - 2016-08-24 07:17:48 --> Helper loaded: form_helper
INFO - 2016-08-24 07:17:48 --> Helper loaded: file_helper
INFO - 2016-08-24 07:17:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:17:48 --> Database Driver Class Initialized
INFO - 2016-08-24 07:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:17:48 --> Form Validation Class Initialized
INFO - 2016-08-24 07:17:48 --> Email Class Initialized
INFO - 2016-08-24 07:17:48 --> Controller Class Initialized
INFO - 2016-08-24 07:17:48 --> Model Class Initialized
INFO - 2016-08-24 07:17:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:17:48 --> Final output sent to browser
DEBUG - 2016-08-24 07:17:48 --> Total execution time: 1.0218
INFO - 2016-08-24 07:18:21 --> Config Class Initialized
INFO - 2016-08-24 07:18:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:18:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:18:21 --> Utf8 Class Initialized
INFO - 2016-08-24 07:18:21 --> URI Class Initialized
INFO - 2016-08-24 07:18:21 --> Router Class Initialized
INFO - 2016-08-24 07:18:21 --> Output Class Initialized
INFO - 2016-08-24 07:18:21 --> Security Class Initialized
DEBUG - 2016-08-24 07:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:18:21 --> Input Class Initialized
INFO - 2016-08-24 07:18:21 --> Language Class Initialized
INFO - 2016-08-24 07:18:21 --> Loader Class Initialized
INFO - 2016-08-24 07:18:21 --> Helper loaded: url_helper
INFO - 2016-08-24 07:18:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:18:21 --> Helper loaded: html_helper
INFO - 2016-08-24 07:18:21 --> Helper loaded: form_helper
INFO - 2016-08-24 07:18:21 --> Helper loaded: file_helper
INFO - 2016-08-24 07:18:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:18:21 --> Database Driver Class Initialized
INFO - 2016-08-24 07:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:18:22 --> Form Validation Class Initialized
INFO - 2016-08-24 07:18:22 --> Email Class Initialized
INFO - 2016-08-24 07:18:22 --> Controller Class Initialized
INFO - 2016-08-24 07:18:22 --> Model Class Initialized
INFO - 2016-08-24 07:18:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:18:22 --> Final output sent to browser
DEBUG - 2016-08-24 07:18:22 --> Total execution time: 0.3061
INFO - 2016-08-24 07:19:22 --> Config Class Initialized
INFO - 2016-08-24 07:19:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:22 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:22 --> URI Class Initialized
INFO - 2016-08-24 07:19:22 --> Router Class Initialized
INFO - 2016-08-24 07:19:22 --> Output Class Initialized
INFO - 2016-08-24 07:19:22 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:22 --> Input Class Initialized
INFO - 2016-08-24 07:19:22 --> Language Class Initialized
INFO - 2016-08-24 07:19:22 --> Loader Class Initialized
INFO - 2016-08-24 07:19:22 --> Helper loaded: url_helper
INFO - 2016-08-24 07:19:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:19:22 --> Helper loaded: html_helper
INFO - 2016-08-24 07:19:22 --> Helper loaded: form_helper
INFO - 2016-08-24 07:19:22 --> Helper loaded: file_helper
INFO - 2016-08-24 07:19:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:19:22 --> Database Driver Class Initialized
INFO - 2016-08-24 07:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:19:22 --> Form Validation Class Initialized
INFO - 2016-08-24 07:19:22 --> Email Class Initialized
INFO - 2016-08-24 07:19:22 --> Controller Class Initialized
INFO - 2016-08-24 07:19:22 --> Model Class Initialized
INFO - 2016-08-24 07:19:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:19:22 --> Final output sent to browser
DEBUG - 2016-08-24 07:19:22 --> Total execution time: 0.3303
INFO - 2016-08-24 07:19:23 --> Config Class Initialized
INFO - 2016-08-24 07:19:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:23 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:23 --> URI Class Initialized
INFO - 2016-08-24 07:19:23 --> Router Class Initialized
INFO - 2016-08-24 07:19:23 --> Output Class Initialized
INFO - 2016-08-24 07:19:23 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:23 --> Input Class Initialized
INFO - 2016-08-24 07:19:23 --> Language Class Initialized
ERROR - 2016-08-24 07:19:23 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:19:25 --> Config Class Initialized
INFO - 2016-08-24 07:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:25 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:25 --> URI Class Initialized
INFO - 2016-08-24 07:19:25 --> Router Class Initialized
INFO - 2016-08-24 07:19:25 --> Output Class Initialized
INFO - 2016-08-24 07:19:25 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:25 --> Input Class Initialized
INFO - 2016-08-24 07:19:25 --> Language Class Initialized
INFO - 2016-08-24 07:19:25 --> Loader Class Initialized
INFO - 2016-08-24 07:19:25 --> Helper loaded: url_helper
INFO - 2016-08-24 07:19:25 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:19:25 --> Helper loaded: html_helper
INFO - 2016-08-24 07:19:25 --> Helper loaded: form_helper
INFO - 2016-08-24 07:19:25 --> Helper loaded: file_helper
INFO - 2016-08-24 07:19:25 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:19:25 --> Database Driver Class Initialized
INFO - 2016-08-24 07:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:19:25 --> Form Validation Class Initialized
INFO - 2016-08-24 07:19:25 --> Email Class Initialized
INFO - 2016-08-24 07:19:25 --> Controller Class Initialized
INFO - 2016-08-24 07:19:25 --> Model Class Initialized
INFO - 2016-08-24 07:19:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:19:25 --> Final output sent to browser
DEBUG - 2016-08-24 07:19:25 --> Total execution time: 0.3026
INFO - 2016-08-24 07:19:26 --> Config Class Initialized
INFO - 2016-08-24 07:19:26 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:26 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:26 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:26 --> URI Class Initialized
INFO - 2016-08-24 07:19:26 --> Router Class Initialized
INFO - 2016-08-24 07:19:26 --> Output Class Initialized
INFO - 2016-08-24 07:19:26 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:26 --> Input Class Initialized
INFO - 2016-08-24 07:19:26 --> Language Class Initialized
ERROR - 2016-08-24 07:19:26 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:19:31 --> Config Class Initialized
INFO - 2016-08-24 07:19:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:31 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:31 --> URI Class Initialized
INFO - 2016-08-24 07:19:31 --> Router Class Initialized
INFO - 2016-08-24 07:19:31 --> Output Class Initialized
INFO - 2016-08-24 07:19:31 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:31 --> Input Class Initialized
INFO - 2016-08-24 07:19:31 --> Language Class Initialized
INFO - 2016-08-24 07:19:31 --> Loader Class Initialized
INFO - 2016-08-24 07:19:31 --> Helper loaded: url_helper
INFO - 2016-08-24 07:19:31 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:19:31 --> Helper loaded: html_helper
INFO - 2016-08-24 07:19:31 --> Helper loaded: form_helper
INFO - 2016-08-24 07:19:31 --> Helper loaded: file_helper
INFO - 2016-08-24 07:19:31 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:19:31 --> Database Driver Class Initialized
INFO - 2016-08-24 07:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:19:31 --> Form Validation Class Initialized
INFO - 2016-08-24 07:19:31 --> Email Class Initialized
INFO - 2016-08-24 07:19:31 --> Controller Class Initialized
INFO - 2016-08-24 07:19:32 --> Model Class Initialized
INFO - 2016-08-24 07:19:32 --> Config Class Initialized
INFO - 2016-08-24 07:19:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:19:32 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:19:32 --> Utf8 Class Initialized
INFO - 2016-08-24 07:19:32 --> URI Class Initialized
INFO - 2016-08-24 07:19:32 --> Router Class Initialized
INFO - 2016-08-24 07:19:32 --> Output Class Initialized
INFO - 2016-08-24 07:19:32 --> Security Class Initialized
DEBUG - 2016-08-24 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:19:32 --> Input Class Initialized
INFO - 2016-08-24 07:19:32 --> Language Class Initialized
INFO - 2016-08-24 07:19:32 --> Loader Class Initialized
INFO - 2016-08-24 07:19:32 --> Helper loaded: url_helper
INFO - 2016-08-24 07:19:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:19:32 --> Helper loaded: html_helper
INFO - 2016-08-24 07:19:32 --> Helper loaded: form_helper
INFO - 2016-08-24 07:19:32 --> Helper loaded: file_helper
INFO - 2016-08-24 07:19:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:19:32 --> Database Driver Class Initialized
INFO - 2016-08-24 07:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:19:32 --> Form Validation Class Initialized
INFO - 2016-08-24 07:19:32 --> Email Class Initialized
INFO - 2016-08-24 07:19:32 --> Controller Class Initialized
INFO - 2016-08-24 07:19:32 --> Model Class Initialized
INFO - 2016-08-24 07:19:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:19:33 --> Final output sent to browser
DEBUG - 2016-08-24 07:19:33 --> Total execution time: 1.3035
INFO - 2016-08-24 07:22:21 --> Config Class Initialized
INFO - 2016-08-24 07:22:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:22:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:22:21 --> Utf8 Class Initialized
INFO - 2016-08-24 07:22:21 --> URI Class Initialized
INFO - 2016-08-24 07:22:21 --> Router Class Initialized
INFO - 2016-08-24 07:22:21 --> Output Class Initialized
INFO - 2016-08-24 07:22:21 --> Security Class Initialized
DEBUG - 2016-08-24 07:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:22:21 --> Input Class Initialized
INFO - 2016-08-24 07:22:21 --> Language Class Initialized
INFO - 2016-08-24 07:22:21 --> Loader Class Initialized
INFO - 2016-08-24 07:22:21 --> Helper loaded: url_helper
INFO - 2016-08-24 07:22:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:22:21 --> Helper loaded: html_helper
INFO - 2016-08-24 07:22:21 --> Helper loaded: form_helper
INFO - 2016-08-24 07:22:21 --> Helper loaded: file_helper
INFO - 2016-08-24 07:22:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:22:21 --> Database Driver Class Initialized
INFO - 2016-08-24 07:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:22:21 --> Form Validation Class Initialized
INFO - 2016-08-24 07:22:21 --> Email Class Initialized
INFO - 2016-08-24 07:22:21 --> Controller Class Initialized
INFO - 2016-08-24 07:22:21 --> Model Class Initialized
INFO - 2016-08-24 07:22:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:22:22 --> Final output sent to browser
DEBUG - 2016-08-24 07:22:22 --> Total execution time: 1.2138
INFO - 2016-08-24 07:44:11 --> Config Class Initialized
INFO - 2016-08-24 07:44:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:11 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:11 --> URI Class Initialized
INFO - 2016-08-24 07:44:11 --> Router Class Initialized
INFO - 2016-08-24 07:44:11 --> Output Class Initialized
INFO - 2016-08-24 07:44:11 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:11 --> Input Class Initialized
INFO - 2016-08-24 07:44:11 --> Language Class Initialized
INFO - 2016-08-24 07:44:11 --> Loader Class Initialized
INFO - 2016-08-24 07:44:11 --> Helper loaded: url_helper
INFO - 2016-08-24 07:44:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:44:11 --> Helper loaded: html_helper
INFO - 2016-08-24 07:44:11 --> Helper loaded: form_helper
INFO - 2016-08-24 07:44:11 --> Helper loaded: file_helper
INFO - 2016-08-24 07:44:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:44:11 --> Database Driver Class Initialized
INFO - 2016-08-24 07:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:44:11 --> Form Validation Class Initialized
INFO - 2016-08-24 07:44:11 --> Email Class Initialized
INFO - 2016-08-24 07:44:11 --> Controller Class Initialized
INFO - 2016-08-24 07:44:12 --> Model Class Initialized
INFO - 2016-08-24 07:44:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:44:12 --> Final output sent to browser
DEBUG - 2016-08-24 07:44:12 --> Total execution time: 1.2142
INFO - 2016-08-24 07:44:16 --> Config Class Initialized
INFO - 2016-08-24 07:44:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:16 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:16 --> URI Class Initialized
INFO - 2016-08-24 07:44:16 --> Router Class Initialized
INFO - 2016-08-24 07:44:17 --> Output Class Initialized
INFO - 2016-08-24 07:44:17 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:17 --> Input Class Initialized
INFO - 2016-08-24 07:44:17 --> Language Class Initialized
INFO - 2016-08-24 07:44:17 --> Loader Class Initialized
INFO - 2016-08-24 07:44:17 --> Helper loaded: url_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: html_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: form_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: file_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:44:17 --> Database Driver Class Initialized
INFO - 2016-08-24 07:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:44:17 --> Form Validation Class Initialized
INFO - 2016-08-24 07:44:17 --> Email Class Initialized
INFO - 2016-08-24 07:44:17 --> Controller Class Initialized
INFO - 2016-08-24 07:44:17 --> Model Class Initialized
INFO - 2016-08-24 07:44:17 --> Config Class Initialized
INFO - 2016-08-24 07:44:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:17 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:17 --> URI Class Initialized
INFO - 2016-08-24 07:44:17 --> Router Class Initialized
INFO - 2016-08-24 07:44:17 --> Output Class Initialized
INFO - 2016-08-24 07:44:17 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:17 --> Input Class Initialized
INFO - 2016-08-24 07:44:17 --> Language Class Initialized
INFO - 2016-08-24 07:44:17 --> Loader Class Initialized
INFO - 2016-08-24 07:44:17 --> Helper loaded: url_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: html_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: form_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: file_helper
INFO - 2016-08-24 07:44:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:44:17 --> Database Driver Class Initialized
INFO - 2016-08-24 07:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:44:17 --> Form Validation Class Initialized
INFO - 2016-08-24 07:44:17 --> Email Class Initialized
INFO - 2016-08-24 07:44:17 --> Controller Class Initialized
INFO - 2016-08-24 07:44:17 --> Model Class Initialized
INFO - 2016-08-24 07:44:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:44:17 --> Final output sent to browser
DEBUG - 2016-08-24 07:44:17 --> Total execution time: 0.3151
INFO - 2016-08-24 07:44:18 --> Config Class Initialized
INFO - 2016-08-24 07:44:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:18 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:18 --> URI Class Initialized
INFO - 2016-08-24 07:44:18 --> Router Class Initialized
INFO - 2016-08-24 07:44:18 --> Output Class Initialized
INFO - 2016-08-24 07:44:18 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:18 --> Input Class Initialized
INFO - 2016-08-24 07:44:18 --> Language Class Initialized
ERROR - 2016-08-24 07:44:18 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:44:19 --> Config Class Initialized
INFO - 2016-08-24 07:44:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:19 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:19 --> URI Class Initialized
INFO - 2016-08-24 07:44:19 --> Router Class Initialized
INFO - 2016-08-24 07:44:19 --> Output Class Initialized
INFO - 2016-08-24 07:44:19 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:20 --> Input Class Initialized
INFO - 2016-08-24 07:44:20 --> Language Class Initialized
INFO - 2016-08-24 07:44:20 --> Loader Class Initialized
INFO - 2016-08-24 07:44:20 --> Helper loaded: url_helper
INFO - 2016-08-24 07:44:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:44:20 --> Helper loaded: html_helper
INFO - 2016-08-24 07:44:20 --> Helper loaded: form_helper
INFO - 2016-08-24 07:44:20 --> Helper loaded: file_helper
INFO - 2016-08-24 07:44:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:44:20 --> Database Driver Class Initialized
INFO - 2016-08-24 07:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:44:20 --> Form Validation Class Initialized
INFO - 2016-08-24 07:44:20 --> Email Class Initialized
INFO - 2016-08-24 07:44:20 --> Controller Class Initialized
INFO - 2016-08-24 07:44:20 --> Model Class Initialized
INFO - 2016-08-24 07:44:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:44:20 --> Final output sent to browser
DEBUG - 2016-08-24 07:44:20 --> Total execution time: 0.3397
INFO - 2016-08-24 07:44:20 --> Config Class Initialized
INFO - 2016-08-24 07:44:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:20 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:20 --> URI Class Initialized
INFO - 2016-08-24 07:44:20 --> Router Class Initialized
INFO - 2016-08-24 07:44:20 --> Output Class Initialized
INFO - 2016-08-24 07:44:20 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:20 --> Input Class Initialized
INFO - 2016-08-24 07:44:20 --> Language Class Initialized
ERROR - 2016-08-24 07:44:20 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:44:34 --> Config Class Initialized
INFO - 2016-08-24 07:44:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:34 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:34 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:34 --> URI Class Initialized
DEBUG - 2016-08-24 07:44:34 --> No URI present. Default controller set.
INFO - 2016-08-24 07:44:34 --> Router Class Initialized
INFO - 2016-08-24 07:44:34 --> Output Class Initialized
INFO - 2016-08-24 07:44:34 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:34 --> Input Class Initialized
INFO - 2016-08-24 07:44:34 --> Language Class Initialized
INFO - 2016-08-24 07:44:34 --> Loader Class Initialized
INFO - 2016-08-24 07:44:34 --> Helper loaded: url_helper
INFO - 2016-08-24 07:44:34 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:44:34 --> Helper loaded: html_helper
INFO - 2016-08-24 07:44:34 --> Helper loaded: form_helper
INFO - 2016-08-24 07:44:34 --> Helper loaded: file_helper
INFO - 2016-08-24 07:44:34 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:44:34 --> Database Driver Class Initialized
INFO - 2016-08-24 07:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:44:34 --> Form Validation Class Initialized
INFO - 2016-08-24 07:44:34 --> Email Class Initialized
INFO - 2016-08-24 07:44:34 --> Controller Class Initialized
INFO - 2016-08-24 07:44:34 --> Config Class Initialized
INFO - 2016-08-24 07:44:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:44:34 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:44:34 --> Utf8 Class Initialized
INFO - 2016-08-24 07:44:34 --> URI Class Initialized
INFO - 2016-08-24 07:44:34 --> Router Class Initialized
INFO - 2016-08-24 07:44:34 --> Output Class Initialized
INFO - 2016-08-24 07:44:34 --> Security Class Initialized
DEBUG - 2016-08-24 07:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:44:34 --> Input Class Initialized
INFO - 2016-08-24 07:44:34 --> Language Class Initialized
ERROR - 2016-08-24 07:44:35 --> Severity: Parsing Error --> syntax error, unexpected '​​​' (T_STRING), expecting function (T_FUNCTION) D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 159
INFO - 2016-08-24 07:45:36 --> Config Class Initialized
INFO - 2016-08-24 07:45:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:45:36 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:45:36 --> Utf8 Class Initialized
INFO - 2016-08-24 07:45:36 --> URI Class Initialized
INFO - 2016-08-24 07:45:36 --> Router Class Initialized
INFO - 2016-08-24 07:45:36 --> Output Class Initialized
INFO - 2016-08-24 07:45:36 --> Security Class Initialized
DEBUG - 2016-08-24 07:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:45:36 --> Input Class Initialized
INFO - 2016-08-24 07:45:36 --> Language Class Initialized
INFO - 2016-08-24 07:45:36 --> Loader Class Initialized
INFO - 2016-08-24 07:45:36 --> Helper loaded: url_helper
INFO - 2016-08-24 07:45:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:45:36 --> Helper loaded: html_helper
INFO - 2016-08-24 07:45:36 --> Helper loaded: form_helper
INFO - 2016-08-24 07:45:36 --> Helper loaded: file_helper
INFO - 2016-08-24 07:45:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:45:36 --> Database Driver Class Initialized
INFO - 2016-08-24 07:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:45:36 --> Form Validation Class Initialized
INFO - 2016-08-24 07:45:36 --> Email Class Initialized
INFO - 2016-08-24 07:45:36 --> Controller Class Initialized
INFO - 2016-08-24 07:45:36 --> Model Class Initialized
DEBUG - 2016-08-24 07:45:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:45:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:45:36 --> Final output sent to browser
DEBUG - 2016-08-24 07:45:36 --> Total execution time: 0.3548
INFO - 2016-08-24 07:45:45 --> Config Class Initialized
INFO - 2016-08-24 07:45:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:45:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:45:45 --> Utf8 Class Initialized
INFO - 2016-08-24 07:45:45 --> URI Class Initialized
INFO - 2016-08-24 07:45:45 --> Router Class Initialized
INFO - 2016-08-24 07:45:45 --> Output Class Initialized
INFO - 2016-08-24 07:45:45 --> Security Class Initialized
DEBUG - 2016-08-24 07:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:45:45 --> Input Class Initialized
INFO - 2016-08-24 07:45:45 --> Language Class Initialized
INFO - 2016-08-24 07:45:45 --> Loader Class Initialized
INFO - 2016-08-24 07:45:45 --> Helper loaded: url_helper
INFO - 2016-08-24 07:45:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:45:45 --> Helper loaded: html_helper
INFO - 2016-08-24 07:45:45 --> Helper loaded: form_helper
INFO - 2016-08-24 07:45:45 --> Helper loaded: file_helper
INFO - 2016-08-24 07:45:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:45:46 --> Database Driver Class Initialized
INFO - 2016-08-24 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:45:46 --> Form Validation Class Initialized
INFO - 2016-08-24 07:45:46 --> Email Class Initialized
INFO - 2016-08-24 07:45:46 --> Controller Class Initialized
INFO - 2016-08-24 07:45:46 --> Model Class Initialized
DEBUG - 2016-08-24 07:45:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:45:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 07:45:46 --> Config Class Initialized
INFO - 2016-08-24 07:45:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:45:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:45:46 --> Utf8 Class Initialized
INFO - 2016-08-24 07:45:46 --> URI Class Initialized
DEBUG - 2016-08-24 07:45:46 --> No URI present. Default controller set.
INFO - 2016-08-24 07:45:46 --> Router Class Initialized
INFO - 2016-08-24 07:45:46 --> Output Class Initialized
INFO - 2016-08-24 07:45:46 --> Security Class Initialized
DEBUG - 2016-08-24 07:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:45:46 --> Input Class Initialized
INFO - 2016-08-24 07:45:46 --> Language Class Initialized
INFO - 2016-08-24 07:45:46 --> Loader Class Initialized
INFO - 2016-08-24 07:45:46 --> Helper loaded: url_helper
INFO - 2016-08-24 07:45:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:45:46 --> Helper loaded: html_helper
INFO - 2016-08-24 07:45:46 --> Helper loaded: form_helper
INFO - 2016-08-24 07:45:46 --> Helper loaded: file_helper
INFO - 2016-08-24 07:45:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:45:46 --> Database Driver Class Initialized
INFO - 2016-08-24 07:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:45:46 --> Form Validation Class Initialized
INFO - 2016-08-24 07:45:46 --> Email Class Initialized
INFO - 2016-08-24 07:45:46 --> Controller Class Initialized
INFO - 2016-08-24 07:45:46 --> Model Class Initialized
INFO - 2016-08-24 07:45:46 --> Model Class Initialized
INFO - 2016-08-24 07:45:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:45:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 07:45:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-24 07:45:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:45:46 --> Final output sent to browser
DEBUG - 2016-08-24 07:45:46 --> Total execution time: 0.3707
INFO - 2016-08-24 07:45:50 --> Config Class Initialized
INFO - 2016-08-24 07:45:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:45:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:45:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:45:50 --> URI Class Initialized
INFO - 2016-08-24 07:45:50 --> Router Class Initialized
INFO - 2016-08-24 07:45:50 --> Output Class Initialized
INFO - 2016-08-24 07:45:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:45:50 --> Input Class Initialized
INFO - 2016-08-24 07:45:50 --> Language Class Initialized
INFO - 2016-08-24 07:45:51 --> Loader Class Initialized
INFO - 2016-08-24 07:45:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:45:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:45:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:45:51 --> Email Class Initialized
INFO - 2016-08-24 07:45:51 --> Controller Class Initialized
INFO - 2016-08-24 07:45:51 --> Model Class Initialized
INFO - 2016-08-24 07:45:51 --> Config Class Initialized
INFO - 2016-08-24 07:45:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:45:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:45:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:45:51 --> URI Class Initialized
INFO - 2016-08-24 07:45:51 --> Router Class Initialized
INFO - 2016-08-24 07:45:51 --> Output Class Initialized
INFO - 2016-08-24 07:45:51 --> Security Class Initialized
DEBUG - 2016-08-24 07:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:45:51 --> Input Class Initialized
INFO - 2016-08-24 07:45:51 --> Language Class Initialized
INFO - 2016-08-24 07:45:51 --> Loader Class Initialized
INFO - 2016-08-24 07:45:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:45:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:45:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:45:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:45:51 --> Email Class Initialized
INFO - 2016-08-24 07:45:51 --> Controller Class Initialized
INFO - 2016-08-24 07:45:51 --> Model Class Initialized
DEBUG - 2016-08-24 07:45:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:45:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:45:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:45:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:45:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:45:51 --> Final output sent to browser
DEBUG - 2016-08-24 07:45:51 --> Total execution time: 0.3503
INFO - 2016-08-24 07:48:01 --> Config Class Initialized
INFO - 2016-08-24 07:48:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:48:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:48:01 --> Utf8 Class Initialized
INFO - 2016-08-24 07:48:01 --> URI Class Initialized
INFO - 2016-08-24 07:48:01 --> Router Class Initialized
INFO - 2016-08-24 07:48:01 --> Output Class Initialized
INFO - 2016-08-24 07:48:01 --> Security Class Initialized
DEBUG - 2016-08-24 07:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:48:01 --> Input Class Initialized
INFO - 2016-08-24 07:48:01 --> Language Class Initialized
INFO - 2016-08-24 07:48:01 --> Loader Class Initialized
INFO - 2016-08-24 07:48:01 --> Helper loaded: url_helper
INFO - 2016-08-24 07:48:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:48:01 --> Helper loaded: html_helper
INFO - 2016-08-24 07:48:01 --> Helper loaded: form_helper
INFO - 2016-08-24 07:48:01 --> Helper loaded: file_helper
INFO - 2016-08-24 07:48:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:48:01 --> Database Driver Class Initialized
INFO - 2016-08-24 07:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:48:01 --> Form Validation Class Initialized
INFO - 2016-08-24 07:48:01 --> Email Class Initialized
INFO - 2016-08-24 07:48:01 --> Controller Class Initialized
INFO - 2016-08-24 07:48:01 --> Model Class Initialized
DEBUG - 2016-08-24 07:48:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:48:01 --> Final output sent to browser
DEBUG - 2016-08-24 07:48:01 --> Total execution time: 0.3519
INFO - 2016-08-24 07:48:04 --> Config Class Initialized
INFO - 2016-08-24 07:48:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:48:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:48:04 --> Utf8 Class Initialized
INFO - 2016-08-24 07:48:04 --> URI Class Initialized
INFO - 2016-08-24 07:48:04 --> Router Class Initialized
INFO - 2016-08-24 07:48:04 --> Output Class Initialized
INFO - 2016-08-24 07:48:04 --> Security Class Initialized
DEBUG - 2016-08-24 07:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:48:04 --> Input Class Initialized
INFO - 2016-08-24 07:48:04 --> Language Class Initialized
INFO - 2016-08-24 07:48:04 --> Loader Class Initialized
INFO - 2016-08-24 07:48:04 --> Helper loaded: url_helper
INFO - 2016-08-24 07:48:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:48:04 --> Helper loaded: html_helper
INFO - 2016-08-24 07:48:04 --> Helper loaded: form_helper
INFO - 2016-08-24 07:48:04 --> Helper loaded: file_helper
INFO - 2016-08-24 07:48:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:48:05 --> Database Driver Class Initialized
INFO - 2016-08-24 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:48:05 --> Form Validation Class Initialized
INFO - 2016-08-24 07:48:05 --> Email Class Initialized
INFO - 2016-08-24 07:48:05 --> Controller Class Initialized
INFO - 2016-08-24 07:48:05 --> Model Class Initialized
INFO - 2016-08-24 07:48:39 --> Config Class Initialized
INFO - 2016-08-24 07:48:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:48:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:48:39 --> Utf8 Class Initialized
INFO - 2016-08-24 07:48:39 --> URI Class Initialized
INFO - 2016-08-24 07:48:39 --> Router Class Initialized
INFO - 2016-08-24 07:48:39 --> Output Class Initialized
INFO - 2016-08-24 07:48:39 --> Security Class Initialized
DEBUG - 2016-08-24 07:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:48:39 --> Input Class Initialized
INFO - 2016-08-24 07:48:39 --> Language Class Initialized
INFO - 2016-08-24 07:48:39 --> Loader Class Initialized
INFO - 2016-08-24 07:48:39 --> Helper loaded: url_helper
INFO - 2016-08-24 07:48:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:48:39 --> Helper loaded: html_helper
INFO - 2016-08-24 07:48:39 --> Helper loaded: form_helper
INFO - 2016-08-24 07:48:39 --> Helper loaded: file_helper
INFO - 2016-08-24 07:48:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:48:39 --> Database Driver Class Initialized
INFO - 2016-08-24 07:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:48:39 --> Form Validation Class Initialized
INFO - 2016-08-24 07:48:39 --> Email Class Initialized
INFO - 2016-08-24 07:48:39 --> Controller Class Initialized
INFO - 2016-08-24 07:48:39 --> Model Class Initialized
DEBUG - 2016-08-24 07:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:48:39 --> Final output sent to browser
DEBUG - 2016-08-24 07:48:39 --> Total execution time: 0.3753
INFO - 2016-08-24 07:48:42 --> Config Class Initialized
INFO - 2016-08-24 07:48:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:48:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:48:42 --> Utf8 Class Initialized
INFO - 2016-08-24 07:48:42 --> URI Class Initialized
INFO - 2016-08-24 07:48:42 --> Router Class Initialized
INFO - 2016-08-24 07:48:42 --> Output Class Initialized
INFO - 2016-08-24 07:48:42 --> Security Class Initialized
DEBUG - 2016-08-24 07:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:48:42 --> Input Class Initialized
INFO - 2016-08-24 07:48:42 --> Language Class Initialized
INFO - 2016-08-24 07:48:42 --> Loader Class Initialized
INFO - 2016-08-24 07:48:42 --> Helper loaded: url_helper
INFO - 2016-08-24 07:48:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:48:42 --> Helper loaded: html_helper
INFO - 2016-08-24 07:48:42 --> Helper loaded: form_helper
INFO - 2016-08-24 07:48:42 --> Helper loaded: file_helper
INFO - 2016-08-24 07:48:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:48:42 --> Database Driver Class Initialized
INFO - 2016-08-24 07:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:48:42 --> Form Validation Class Initialized
INFO - 2016-08-24 07:48:42 --> Email Class Initialized
INFO - 2016-08-24 07:48:42 --> Controller Class Initialized
INFO - 2016-08-24 07:48:42 --> Model Class Initialized
INFO - 2016-08-24 07:48:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 07:48:42 --> Final output sent to browser
DEBUG - 2016-08-24 07:48:42 --> Total execution time: 0.3265
INFO - 2016-08-24 07:48:42 --> Config Class Initialized
INFO - 2016-08-24 07:48:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:48:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:48:43 --> Utf8 Class Initialized
INFO - 2016-08-24 07:48:43 --> URI Class Initialized
INFO - 2016-08-24 07:48:43 --> Router Class Initialized
INFO - 2016-08-24 07:48:43 --> Output Class Initialized
INFO - 2016-08-24 07:48:43 --> Security Class Initialized
DEBUG - 2016-08-24 07:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:48:43 --> Input Class Initialized
INFO - 2016-08-24 07:48:43 --> Language Class Initialized
ERROR - 2016-08-24 07:48:43 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 07:49:42 --> Config Class Initialized
INFO - 2016-08-24 07:49:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:43 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:43 --> URI Class Initialized
INFO - 2016-08-24 07:49:43 --> Router Class Initialized
INFO - 2016-08-24 07:49:43 --> Output Class Initialized
INFO - 2016-08-24 07:49:43 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:43 --> Input Class Initialized
INFO - 2016-08-24 07:49:43 --> Language Class Initialized
INFO - 2016-08-24 07:49:43 --> Loader Class Initialized
INFO - 2016-08-24 07:49:43 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:43 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:43 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:43 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:43 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:43 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:43 --> Email Class Initialized
INFO - 2016-08-24 07:49:43 --> Controller Class Initialized
INFO - 2016-08-24 07:49:43 --> Model Class Initialized
DEBUG - 2016-08-24 07:49:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:49:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:49:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:49:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:49:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:49:43 --> Final output sent to browser
DEBUG - 2016-08-24 07:49:43 --> Total execution time: 0.3828
INFO - 2016-08-24 07:49:45 --> Config Class Initialized
INFO - 2016-08-24 07:49:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:45 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:45 --> URI Class Initialized
INFO - 2016-08-24 07:49:45 --> Router Class Initialized
INFO - 2016-08-24 07:49:45 --> Output Class Initialized
INFO - 2016-08-24 07:49:45 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:45 --> Input Class Initialized
INFO - 2016-08-24 07:49:45 --> Language Class Initialized
INFO - 2016-08-24 07:49:45 --> Loader Class Initialized
INFO - 2016-08-24 07:49:45 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:45 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:45 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:45 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:45 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:45 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:45 --> Email Class Initialized
INFO - 2016-08-24 07:49:45 --> Controller Class Initialized
INFO - 2016-08-24 07:49:45 --> Model Class Initialized
DEBUG - 2016-08-24 07:49:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:49:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:49:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:49:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:49:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:49:45 --> Final output sent to browser
DEBUG - 2016-08-24 07:49:46 --> Total execution time: 0.3710
INFO - 2016-08-24 07:49:48 --> Config Class Initialized
INFO - 2016-08-24 07:49:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:48 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:48 --> URI Class Initialized
INFO - 2016-08-24 07:49:48 --> Router Class Initialized
INFO - 2016-08-24 07:49:48 --> Output Class Initialized
INFO - 2016-08-24 07:49:48 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:48 --> Input Class Initialized
INFO - 2016-08-24 07:49:48 --> Language Class Initialized
INFO - 2016-08-24 07:49:48 --> Loader Class Initialized
INFO - 2016-08-24 07:49:48 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:48 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:48 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:48 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:48 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:48 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:48 --> Email Class Initialized
INFO - 2016-08-24 07:49:48 --> Controller Class Initialized
INFO - 2016-08-24 07:49:49 --> Model Class Initialized
INFO - 2016-08-24 07:49:49 --> Config Class Initialized
INFO - 2016-08-24 07:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:49 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:49 --> URI Class Initialized
INFO - 2016-08-24 07:49:49 --> Router Class Initialized
INFO - 2016-08-24 07:49:49 --> Output Class Initialized
INFO - 2016-08-24 07:49:49 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:49 --> Input Class Initialized
INFO - 2016-08-24 07:49:49 --> Language Class Initialized
INFO - 2016-08-24 07:49:49 --> Loader Class Initialized
INFO - 2016-08-24 07:49:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:49 --> Email Class Initialized
INFO - 2016-08-24 07:49:49 --> Controller Class Initialized
INFO - 2016-08-24 07:49:49 --> Model Class Initialized
INFO - 2016-08-24 07:49:49 --> Config Class Initialized
INFO - 2016-08-24 07:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:49 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:49 --> URI Class Initialized
INFO - 2016-08-24 07:49:49 --> Router Class Initialized
INFO - 2016-08-24 07:49:49 --> Output Class Initialized
INFO - 2016-08-24 07:49:49 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:49 --> Input Class Initialized
INFO - 2016-08-24 07:49:49 --> Language Class Initialized
INFO - 2016-08-24 07:49:49 --> Loader Class Initialized
INFO - 2016-08-24 07:49:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:49 --> Email Class Initialized
INFO - 2016-08-24 07:49:49 --> Controller Class Initialized
INFO - 2016-08-24 07:49:49 --> Model Class Initialized
INFO - 2016-08-24 07:49:49 --> Config Class Initialized
INFO - 2016-08-24 07:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:49 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:49 --> URI Class Initialized
INFO - 2016-08-24 07:49:49 --> Router Class Initialized
INFO - 2016-08-24 07:49:49 --> Output Class Initialized
INFO - 2016-08-24 07:49:49 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:49 --> Input Class Initialized
INFO - 2016-08-24 07:49:49 --> Language Class Initialized
INFO - 2016-08-24 07:49:49 --> Loader Class Initialized
INFO - 2016-08-24 07:49:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:50 --> Email Class Initialized
INFO - 2016-08-24 07:49:50 --> Controller Class Initialized
INFO - 2016-08-24 07:49:50 --> Model Class Initialized
INFO - 2016-08-24 07:49:50 --> Config Class Initialized
INFO - 2016-08-24 07:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:50 --> URI Class Initialized
INFO - 2016-08-24 07:49:50 --> Router Class Initialized
INFO - 2016-08-24 07:49:50 --> Output Class Initialized
INFO - 2016-08-24 07:49:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:50 --> Input Class Initialized
INFO - 2016-08-24 07:49:50 --> Language Class Initialized
INFO - 2016-08-24 07:49:50 --> Loader Class Initialized
INFO - 2016-08-24 07:49:50 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:50 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:50 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:50 --> Email Class Initialized
INFO - 2016-08-24 07:49:50 --> Controller Class Initialized
INFO - 2016-08-24 07:49:50 --> Model Class Initialized
INFO - 2016-08-24 07:49:50 --> Config Class Initialized
INFO - 2016-08-24 07:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:50 --> URI Class Initialized
INFO - 2016-08-24 07:49:50 --> Router Class Initialized
INFO - 2016-08-24 07:49:50 --> Output Class Initialized
INFO - 2016-08-24 07:49:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:50 --> Input Class Initialized
INFO - 2016-08-24 07:49:50 --> Language Class Initialized
INFO - 2016-08-24 07:49:50 --> Loader Class Initialized
INFO - 2016-08-24 07:49:50 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:50 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:50 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:50 --> Email Class Initialized
INFO - 2016-08-24 07:49:50 --> Controller Class Initialized
INFO - 2016-08-24 07:49:50 --> Model Class Initialized
INFO - 2016-08-24 07:49:50 --> Config Class Initialized
INFO - 2016-08-24 07:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:50 --> URI Class Initialized
INFO - 2016-08-24 07:49:50 --> Router Class Initialized
INFO - 2016-08-24 07:49:50 --> Output Class Initialized
INFO - 2016-08-24 07:49:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:50 --> Input Class Initialized
INFO - 2016-08-24 07:49:51 --> Language Class Initialized
INFO - 2016-08-24 07:49:51 --> Loader Class Initialized
INFO - 2016-08-24 07:49:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:51 --> Email Class Initialized
INFO - 2016-08-24 07:49:51 --> Controller Class Initialized
INFO - 2016-08-24 07:49:51 --> Model Class Initialized
INFO - 2016-08-24 07:49:51 --> Config Class Initialized
INFO - 2016-08-24 07:49:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:51 --> URI Class Initialized
INFO - 2016-08-24 07:49:51 --> Router Class Initialized
INFO - 2016-08-24 07:49:51 --> Output Class Initialized
INFO - 2016-08-24 07:49:51 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:51 --> Input Class Initialized
INFO - 2016-08-24 07:49:51 --> Language Class Initialized
INFO - 2016-08-24 07:49:51 --> Loader Class Initialized
INFO - 2016-08-24 07:49:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:51 --> Email Class Initialized
INFO - 2016-08-24 07:49:51 --> Controller Class Initialized
INFO - 2016-08-24 07:49:51 --> Model Class Initialized
INFO - 2016-08-24 07:49:51 --> Config Class Initialized
INFO - 2016-08-24 07:49:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:51 --> URI Class Initialized
INFO - 2016-08-24 07:49:51 --> Router Class Initialized
INFO - 2016-08-24 07:49:51 --> Output Class Initialized
INFO - 2016-08-24 07:49:51 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:51 --> Input Class Initialized
INFO - 2016-08-24 07:49:51 --> Language Class Initialized
INFO - 2016-08-24 07:49:51 --> Loader Class Initialized
INFO - 2016-08-24 07:49:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:51 --> Email Class Initialized
INFO - 2016-08-24 07:49:51 --> Controller Class Initialized
INFO - 2016-08-24 07:49:51 --> Model Class Initialized
INFO - 2016-08-24 07:49:51 --> Config Class Initialized
INFO - 2016-08-24 07:49:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:51 --> URI Class Initialized
INFO - 2016-08-24 07:49:51 --> Router Class Initialized
INFO - 2016-08-24 07:49:52 --> Output Class Initialized
INFO - 2016-08-24 07:49:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:52 --> Input Class Initialized
INFO - 2016-08-24 07:49:52 --> Language Class Initialized
INFO - 2016-08-24 07:49:52 --> Loader Class Initialized
INFO - 2016-08-24 07:49:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:52 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:52 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:52 --> Email Class Initialized
INFO - 2016-08-24 07:49:52 --> Controller Class Initialized
INFO - 2016-08-24 07:49:52 --> Model Class Initialized
INFO - 2016-08-24 07:49:52 --> Config Class Initialized
INFO - 2016-08-24 07:49:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:52 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:52 --> URI Class Initialized
INFO - 2016-08-24 07:49:52 --> Router Class Initialized
INFO - 2016-08-24 07:49:52 --> Output Class Initialized
INFO - 2016-08-24 07:49:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:52 --> Input Class Initialized
INFO - 2016-08-24 07:49:52 --> Language Class Initialized
INFO - 2016-08-24 07:49:52 --> Loader Class Initialized
INFO - 2016-08-24 07:49:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:52 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:52 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:52 --> Email Class Initialized
INFO - 2016-08-24 07:49:52 --> Controller Class Initialized
INFO - 2016-08-24 07:49:52 --> Model Class Initialized
INFO - 2016-08-24 07:49:52 --> Config Class Initialized
INFO - 2016-08-24 07:49:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:52 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:52 --> URI Class Initialized
INFO - 2016-08-24 07:49:52 --> Router Class Initialized
INFO - 2016-08-24 07:49:52 --> Output Class Initialized
INFO - 2016-08-24 07:49:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:52 --> Input Class Initialized
INFO - 2016-08-24 07:49:52 --> Language Class Initialized
INFO - 2016-08-24 07:49:52 --> Loader Class Initialized
INFO - 2016-08-24 07:49:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:52 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:52 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:52 --> Email Class Initialized
INFO - 2016-08-24 07:49:52 --> Controller Class Initialized
INFO - 2016-08-24 07:49:52 --> Model Class Initialized
INFO - 2016-08-24 07:49:52 --> Config Class Initialized
INFO - 2016-08-24 07:49:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:53 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:53 --> URI Class Initialized
INFO - 2016-08-24 07:49:53 --> Router Class Initialized
INFO - 2016-08-24 07:49:53 --> Output Class Initialized
INFO - 2016-08-24 07:49:53 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:53 --> Input Class Initialized
INFO - 2016-08-24 07:49:53 --> Language Class Initialized
INFO - 2016-08-24 07:49:53 --> Loader Class Initialized
INFO - 2016-08-24 07:49:53 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:53 --> Email Class Initialized
INFO - 2016-08-24 07:49:53 --> Controller Class Initialized
INFO - 2016-08-24 07:49:53 --> Model Class Initialized
INFO - 2016-08-24 07:49:53 --> Config Class Initialized
INFO - 2016-08-24 07:49:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:53 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:53 --> URI Class Initialized
INFO - 2016-08-24 07:49:53 --> Router Class Initialized
INFO - 2016-08-24 07:49:53 --> Output Class Initialized
INFO - 2016-08-24 07:49:53 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:53 --> Input Class Initialized
INFO - 2016-08-24 07:49:53 --> Language Class Initialized
INFO - 2016-08-24 07:49:53 --> Loader Class Initialized
INFO - 2016-08-24 07:49:53 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:53 --> Email Class Initialized
INFO - 2016-08-24 07:49:53 --> Controller Class Initialized
INFO - 2016-08-24 07:49:53 --> Model Class Initialized
INFO - 2016-08-24 07:49:53 --> Config Class Initialized
INFO - 2016-08-24 07:49:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:53 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:53 --> URI Class Initialized
INFO - 2016-08-24 07:49:53 --> Router Class Initialized
INFO - 2016-08-24 07:49:53 --> Output Class Initialized
INFO - 2016-08-24 07:49:53 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:53 --> Input Class Initialized
INFO - 2016-08-24 07:49:53 --> Language Class Initialized
INFO - 2016-08-24 07:49:53 --> Loader Class Initialized
INFO - 2016-08-24 07:49:53 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:53 --> Email Class Initialized
INFO - 2016-08-24 07:49:53 --> Controller Class Initialized
INFO - 2016-08-24 07:49:53 --> Model Class Initialized
INFO - 2016-08-24 07:49:54 --> Config Class Initialized
INFO - 2016-08-24 07:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:54 --> URI Class Initialized
INFO - 2016-08-24 07:49:54 --> Router Class Initialized
INFO - 2016-08-24 07:49:54 --> Output Class Initialized
INFO - 2016-08-24 07:49:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:54 --> Input Class Initialized
INFO - 2016-08-24 07:49:54 --> Language Class Initialized
INFO - 2016-08-24 07:49:54 --> Loader Class Initialized
INFO - 2016-08-24 07:49:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:54 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:54 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:54 --> Email Class Initialized
INFO - 2016-08-24 07:49:54 --> Controller Class Initialized
INFO - 2016-08-24 07:49:54 --> Model Class Initialized
INFO - 2016-08-24 07:49:54 --> Config Class Initialized
INFO - 2016-08-24 07:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:54 --> URI Class Initialized
INFO - 2016-08-24 07:49:54 --> Router Class Initialized
INFO - 2016-08-24 07:49:54 --> Output Class Initialized
INFO - 2016-08-24 07:49:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:54 --> Input Class Initialized
INFO - 2016-08-24 07:49:54 --> Language Class Initialized
INFO - 2016-08-24 07:49:54 --> Loader Class Initialized
INFO - 2016-08-24 07:49:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:54 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:54 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:54 --> Email Class Initialized
INFO - 2016-08-24 07:49:54 --> Controller Class Initialized
INFO - 2016-08-24 07:49:54 --> Model Class Initialized
INFO - 2016-08-24 07:49:54 --> Config Class Initialized
INFO - 2016-08-24 07:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:54 --> URI Class Initialized
INFO - 2016-08-24 07:49:54 --> Router Class Initialized
INFO - 2016-08-24 07:49:54 --> Output Class Initialized
INFO - 2016-08-24 07:49:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:54 --> Input Class Initialized
INFO - 2016-08-24 07:49:54 --> Language Class Initialized
INFO - 2016-08-24 07:49:54 --> Loader Class Initialized
INFO - 2016-08-24 07:49:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:54 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:55 --> Email Class Initialized
INFO - 2016-08-24 07:49:55 --> Controller Class Initialized
INFO - 2016-08-24 07:49:55 --> Model Class Initialized
INFO - 2016-08-24 07:49:55 --> Config Class Initialized
INFO - 2016-08-24 07:49:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:55 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:55 --> URI Class Initialized
INFO - 2016-08-24 07:49:55 --> Router Class Initialized
INFO - 2016-08-24 07:49:55 --> Output Class Initialized
INFO - 2016-08-24 07:49:55 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:55 --> Input Class Initialized
INFO - 2016-08-24 07:49:55 --> Language Class Initialized
INFO - 2016-08-24 07:49:55 --> Loader Class Initialized
INFO - 2016-08-24 07:49:55 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:55 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:55 --> Email Class Initialized
INFO - 2016-08-24 07:49:55 --> Controller Class Initialized
INFO - 2016-08-24 07:49:55 --> Model Class Initialized
INFO - 2016-08-24 07:49:55 --> Config Class Initialized
INFO - 2016-08-24 07:49:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:55 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:55 --> URI Class Initialized
INFO - 2016-08-24 07:49:55 --> Router Class Initialized
INFO - 2016-08-24 07:49:55 --> Output Class Initialized
INFO - 2016-08-24 07:49:55 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:55 --> Input Class Initialized
INFO - 2016-08-24 07:49:55 --> Language Class Initialized
INFO - 2016-08-24 07:49:55 --> Loader Class Initialized
INFO - 2016-08-24 07:49:55 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:55 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:55 --> Email Class Initialized
INFO - 2016-08-24 07:49:55 --> Controller Class Initialized
INFO - 2016-08-24 07:49:55 --> Model Class Initialized
INFO - 2016-08-24 07:49:55 --> Config Class Initialized
INFO - 2016-08-24 07:49:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:49:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:49:55 --> Utf8 Class Initialized
INFO - 2016-08-24 07:49:55 --> URI Class Initialized
INFO - 2016-08-24 07:49:55 --> Router Class Initialized
INFO - 2016-08-24 07:49:55 --> Output Class Initialized
INFO - 2016-08-24 07:49:55 --> Security Class Initialized
DEBUG - 2016-08-24 07:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:49:55 --> Input Class Initialized
INFO - 2016-08-24 07:49:55 --> Language Class Initialized
INFO - 2016-08-24 07:49:55 --> Loader Class Initialized
INFO - 2016-08-24 07:49:55 --> Helper loaded: url_helper
INFO - 2016-08-24 07:49:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:49:56 --> Helper loaded: html_helper
INFO - 2016-08-24 07:49:56 --> Helper loaded: form_helper
INFO - 2016-08-24 07:49:56 --> Helper loaded: file_helper
INFO - 2016-08-24 07:49:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:49:56 --> Database Driver Class Initialized
INFO - 2016-08-24 07:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:49:56 --> Form Validation Class Initialized
INFO - 2016-08-24 07:49:56 --> Email Class Initialized
INFO - 2016-08-24 07:49:56 --> Controller Class Initialized
INFO - 2016-08-24 07:49:56 --> Model Class Initialized
INFO - 2016-08-24 07:53:38 --> Config Class Initialized
INFO - 2016-08-24 07:53:38 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:38 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:38 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:38 --> URI Class Initialized
INFO - 2016-08-24 07:53:38 --> Router Class Initialized
INFO - 2016-08-24 07:53:38 --> Output Class Initialized
INFO - 2016-08-24 07:53:38 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:38 --> Input Class Initialized
INFO - 2016-08-24 07:53:39 --> Language Class Initialized
INFO - 2016-08-24 07:53:39 --> Loader Class Initialized
INFO - 2016-08-24 07:53:39 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:39 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:39 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:39 --> Email Class Initialized
INFO - 2016-08-24 07:53:39 --> Controller Class Initialized
INFO - 2016-08-24 07:53:39 --> Model Class Initialized
INFO - 2016-08-24 07:53:39 --> Config Class Initialized
INFO - 2016-08-24 07:53:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:39 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:39 --> URI Class Initialized
INFO - 2016-08-24 07:53:39 --> Router Class Initialized
INFO - 2016-08-24 07:53:39 --> Output Class Initialized
INFO - 2016-08-24 07:53:39 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:39 --> Input Class Initialized
INFO - 2016-08-24 07:53:39 --> Language Class Initialized
INFO - 2016-08-24 07:53:39 --> Loader Class Initialized
INFO - 2016-08-24 07:53:39 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:39 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:39 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:39 --> Email Class Initialized
INFO - 2016-08-24 07:53:39 --> Controller Class Initialized
INFO - 2016-08-24 07:53:39 --> Model Class Initialized
INFO - 2016-08-24 07:53:39 --> Config Class Initialized
INFO - 2016-08-24 07:53:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:39 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:39 --> URI Class Initialized
INFO - 2016-08-24 07:53:39 --> Router Class Initialized
INFO - 2016-08-24 07:53:39 --> Output Class Initialized
INFO - 2016-08-24 07:53:39 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:39 --> Input Class Initialized
INFO - 2016-08-24 07:53:39 --> Language Class Initialized
INFO - 2016-08-24 07:53:39 --> Loader Class Initialized
INFO - 2016-08-24 07:53:39 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:39 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:39 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:39 --> Email Class Initialized
INFO - 2016-08-24 07:53:39 --> Controller Class Initialized
INFO - 2016-08-24 07:53:39 --> Model Class Initialized
INFO - 2016-08-24 07:53:39 --> Config Class Initialized
INFO - 2016-08-24 07:53:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:39 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:39 --> URI Class Initialized
INFO - 2016-08-24 07:53:39 --> Router Class Initialized
INFO - 2016-08-24 07:53:40 --> Output Class Initialized
INFO - 2016-08-24 07:53:40 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:40 --> Input Class Initialized
INFO - 2016-08-24 07:53:40 --> Language Class Initialized
INFO - 2016-08-24 07:53:40 --> Loader Class Initialized
INFO - 2016-08-24 07:53:40 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:40 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:40 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:40 --> Email Class Initialized
INFO - 2016-08-24 07:53:40 --> Controller Class Initialized
INFO - 2016-08-24 07:53:40 --> Model Class Initialized
INFO - 2016-08-24 07:53:40 --> Config Class Initialized
INFO - 2016-08-24 07:53:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:40 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:40 --> URI Class Initialized
INFO - 2016-08-24 07:53:40 --> Router Class Initialized
INFO - 2016-08-24 07:53:40 --> Output Class Initialized
INFO - 2016-08-24 07:53:40 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:40 --> Input Class Initialized
INFO - 2016-08-24 07:53:40 --> Language Class Initialized
INFO - 2016-08-24 07:53:40 --> Loader Class Initialized
INFO - 2016-08-24 07:53:40 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:40 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:40 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:40 --> Email Class Initialized
INFO - 2016-08-24 07:53:40 --> Controller Class Initialized
INFO - 2016-08-24 07:53:40 --> Model Class Initialized
INFO - 2016-08-24 07:53:40 --> Config Class Initialized
INFO - 2016-08-24 07:53:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:40 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:40 --> URI Class Initialized
INFO - 2016-08-24 07:53:40 --> Router Class Initialized
INFO - 2016-08-24 07:53:40 --> Output Class Initialized
INFO - 2016-08-24 07:53:40 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:40 --> Input Class Initialized
INFO - 2016-08-24 07:53:40 --> Language Class Initialized
INFO - 2016-08-24 07:53:40 --> Loader Class Initialized
INFO - 2016-08-24 07:53:40 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:40 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:40 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:40 --> Email Class Initialized
INFO - 2016-08-24 07:53:40 --> Controller Class Initialized
INFO - 2016-08-24 07:53:40 --> Model Class Initialized
INFO - 2016-08-24 07:53:40 --> Config Class Initialized
INFO - 2016-08-24 07:53:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:41 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:41 --> URI Class Initialized
INFO - 2016-08-24 07:53:41 --> Router Class Initialized
INFO - 2016-08-24 07:53:41 --> Output Class Initialized
INFO - 2016-08-24 07:53:41 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:41 --> Input Class Initialized
INFO - 2016-08-24 07:53:41 --> Language Class Initialized
INFO - 2016-08-24 07:53:41 --> Loader Class Initialized
INFO - 2016-08-24 07:53:41 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:41 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:41 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:41 --> Email Class Initialized
INFO - 2016-08-24 07:53:41 --> Controller Class Initialized
INFO - 2016-08-24 07:53:41 --> Model Class Initialized
INFO - 2016-08-24 07:53:41 --> Config Class Initialized
INFO - 2016-08-24 07:53:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:41 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:41 --> URI Class Initialized
INFO - 2016-08-24 07:53:41 --> Router Class Initialized
INFO - 2016-08-24 07:53:41 --> Output Class Initialized
INFO - 2016-08-24 07:53:41 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:41 --> Input Class Initialized
INFO - 2016-08-24 07:53:41 --> Language Class Initialized
INFO - 2016-08-24 07:53:41 --> Loader Class Initialized
INFO - 2016-08-24 07:53:41 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:41 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:41 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:41 --> Email Class Initialized
INFO - 2016-08-24 07:53:41 --> Controller Class Initialized
INFO - 2016-08-24 07:53:41 --> Model Class Initialized
INFO - 2016-08-24 07:53:41 --> Config Class Initialized
INFO - 2016-08-24 07:53:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:41 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:41 --> URI Class Initialized
INFO - 2016-08-24 07:53:41 --> Router Class Initialized
INFO - 2016-08-24 07:53:41 --> Output Class Initialized
INFO - 2016-08-24 07:53:41 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:41 --> Input Class Initialized
INFO - 2016-08-24 07:53:41 --> Language Class Initialized
INFO - 2016-08-24 07:53:41 --> Loader Class Initialized
INFO - 2016-08-24 07:53:41 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:41 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:41 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:41 --> Email Class Initialized
INFO - 2016-08-24 07:53:41 --> Controller Class Initialized
INFO - 2016-08-24 07:53:41 --> Model Class Initialized
INFO - 2016-08-24 07:53:42 --> Config Class Initialized
INFO - 2016-08-24 07:53:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:42 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:42 --> URI Class Initialized
INFO - 2016-08-24 07:53:42 --> Router Class Initialized
INFO - 2016-08-24 07:53:42 --> Output Class Initialized
INFO - 2016-08-24 07:53:42 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:42 --> Input Class Initialized
INFO - 2016-08-24 07:53:42 --> Language Class Initialized
INFO - 2016-08-24 07:53:42 --> Loader Class Initialized
INFO - 2016-08-24 07:53:42 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:42 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:42 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:42 --> Email Class Initialized
INFO - 2016-08-24 07:53:42 --> Controller Class Initialized
INFO - 2016-08-24 07:53:42 --> Model Class Initialized
INFO - 2016-08-24 07:53:42 --> Config Class Initialized
INFO - 2016-08-24 07:53:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:42 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:42 --> URI Class Initialized
INFO - 2016-08-24 07:53:42 --> Router Class Initialized
INFO - 2016-08-24 07:53:42 --> Output Class Initialized
INFO - 2016-08-24 07:53:42 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:42 --> Input Class Initialized
INFO - 2016-08-24 07:53:42 --> Language Class Initialized
INFO - 2016-08-24 07:53:42 --> Loader Class Initialized
INFO - 2016-08-24 07:53:42 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:42 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:42 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:42 --> Email Class Initialized
INFO - 2016-08-24 07:53:42 --> Controller Class Initialized
INFO - 2016-08-24 07:53:42 --> Model Class Initialized
INFO - 2016-08-24 07:53:42 --> Config Class Initialized
INFO - 2016-08-24 07:53:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:42 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:42 --> URI Class Initialized
INFO - 2016-08-24 07:53:42 --> Router Class Initialized
INFO - 2016-08-24 07:53:42 --> Output Class Initialized
INFO - 2016-08-24 07:53:42 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:42 --> Input Class Initialized
INFO - 2016-08-24 07:53:42 --> Language Class Initialized
INFO - 2016-08-24 07:53:42 --> Loader Class Initialized
INFO - 2016-08-24 07:53:42 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:42 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:42 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:43 --> Email Class Initialized
INFO - 2016-08-24 07:53:43 --> Controller Class Initialized
INFO - 2016-08-24 07:53:43 --> Model Class Initialized
INFO - 2016-08-24 07:53:43 --> Config Class Initialized
INFO - 2016-08-24 07:53:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:43 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:43 --> URI Class Initialized
INFO - 2016-08-24 07:53:43 --> Router Class Initialized
INFO - 2016-08-24 07:53:43 --> Output Class Initialized
INFO - 2016-08-24 07:53:43 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:43 --> Input Class Initialized
INFO - 2016-08-24 07:53:43 --> Language Class Initialized
INFO - 2016-08-24 07:53:43 --> Loader Class Initialized
INFO - 2016-08-24 07:53:43 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:43 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:43 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:43 --> Email Class Initialized
INFO - 2016-08-24 07:53:43 --> Controller Class Initialized
INFO - 2016-08-24 07:53:43 --> Model Class Initialized
INFO - 2016-08-24 07:53:43 --> Config Class Initialized
INFO - 2016-08-24 07:53:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:43 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:43 --> URI Class Initialized
INFO - 2016-08-24 07:53:43 --> Router Class Initialized
INFO - 2016-08-24 07:53:43 --> Output Class Initialized
INFO - 2016-08-24 07:53:43 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:43 --> Input Class Initialized
INFO - 2016-08-24 07:53:43 --> Language Class Initialized
INFO - 2016-08-24 07:53:43 --> Loader Class Initialized
INFO - 2016-08-24 07:53:43 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:43 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:43 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:43 --> Email Class Initialized
INFO - 2016-08-24 07:53:43 --> Controller Class Initialized
INFO - 2016-08-24 07:53:43 --> Model Class Initialized
INFO - 2016-08-24 07:53:43 --> Config Class Initialized
INFO - 2016-08-24 07:53:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:43 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:43 --> URI Class Initialized
INFO - 2016-08-24 07:53:43 --> Router Class Initialized
INFO - 2016-08-24 07:53:43 --> Output Class Initialized
INFO - 2016-08-24 07:53:43 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:44 --> Input Class Initialized
INFO - 2016-08-24 07:53:44 --> Language Class Initialized
INFO - 2016-08-24 07:53:44 --> Loader Class Initialized
INFO - 2016-08-24 07:53:44 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:44 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:44 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:44 --> Email Class Initialized
INFO - 2016-08-24 07:53:44 --> Controller Class Initialized
INFO - 2016-08-24 07:53:44 --> Model Class Initialized
INFO - 2016-08-24 07:53:44 --> Config Class Initialized
INFO - 2016-08-24 07:53:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:44 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:44 --> URI Class Initialized
INFO - 2016-08-24 07:53:44 --> Router Class Initialized
INFO - 2016-08-24 07:53:44 --> Output Class Initialized
INFO - 2016-08-24 07:53:44 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:44 --> Input Class Initialized
INFO - 2016-08-24 07:53:44 --> Language Class Initialized
INFO - 2016-08-24 07:53:44 --> Loader Class Initialized
INFO - 2016-08-24 07:53:44 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:44 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:44 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:44 --> Email Class Initialized
INFO - 2016-08-24 07:53:44 --> Controller Class Initialized
INFO - 2016-08-24 07:53:44 --> Model Class Initialized
INFO - 2016-08-24 07:53:44 --> Config Class Initialized
INFO - 2016-08-24 07:53:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:44 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:44 --> URI Class Initialized
INFO - 2016-08-24 07:53:44 --> Router Class Initialized
INFO - 2016-08-24 07:53:44 --> Output Class Initialized
INFO - 2016-08-24 07:53:44 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:44 --> Input Class Initialized
INFO - 2016-08-24 07:53:44 --> Language Class Initialized
INFO - 2016-08-24 07:53:44 --> Loader Class Initialized
INFO - 2016-08-24 07:53:44 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:44 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:44 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:44 --> Email Class Initialized
INFO - 2016-08-24 07:53:44 --> Controller Class Initialized
INFO - 2016-08-24 07:53:44 --> Model Class Initialized
INFO - 2016-08-24 07:53:44 --> Config Class Initialized
INFO - 2016-08-24 07:53:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:45 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:45 --> URI Class Initialized
INFO - 2016-08-24 07:53:45 --> Router Class Initialized
INFO - 2016-08-24 07:53:45 --> Output Class Initialized
INFO - 2016-08-24 07:53:45 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:45 --> Input Class Initialized
INFO - 2016-08-24 07:53:45 --> Language Class Initialized
INFO - 2016-08-24 07:53:45 --> Loader Class Initialized
INFO - 2016-08-24 07:53:45 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:45 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:45 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:45 --> Email Class Initialized
INFO - 2016-08-24 07:53:45 --> Controller Class Initialized
INFO - 2016-08-24 07:53:45 --> Model Class Initialized
INFO - 2016-08-24 07:53:45 --> Config Class Initialized
INFO - 2016-08-24 07:53:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:45 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:45 --> URI Class Initialized
INFO - 2016-08-24 07:53:45 --> Router Class Initialized
INFO - 2016-08-24 07:53:45 --> Output Class Initialized
INFO - 2016-08-24 07:53:45 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:45 --> Input Class Initialized
INFO - 2016-08-24 07:53:45 --> Language Class Initialized
INFO - 2016-08-24 07:53:45 --> Loader Class Initialized
INFO - 2016-08-24 07:53:45 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:45 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:45 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:45 --> Email Class Initialized
INFO - 2016-08-24 07:53:46 --> Controller Class Initialized
INFO - 2016-08-24 07:53:46 --> Model Class Initialized
INFO - 2016-08-24 07:53:46 --> Config Class Initialized
INFO - 2016-08-24 07:53:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:46 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:46 --> URI Class Initialized
INFO - 2016-08-24 07:53:46 --> Router Class Initialized
INFO - 2016-08-24 07:53:46 --> Output Class Initialized
INFO - 2016-08-24 07:53:46 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:46 --> Input Class Initialized
INFO - 2016-08-24 07:53:46 --> Language Class Initialized
INFO - 2016-08-24 07:53:46 --> Loader Class Initialized
INFO - 2016-08-24 07:53:46 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:46 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:46 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:46 --> Email Class Initialized
INFO - 2016-08-24 07:53:46 --> Controller Class Initialized
INFO - 2016-08-24 07:53:46 --> Model Class Initialized
INFO - 2016-08-24 07:53:46 --> Config Class Initialized
INFO - 2016-08-24 07:53:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:53:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:53:46 --> Utf8 Class Initialized
INFO - 2016-08-24 07:53:46 --> URI Class Initialized
INFO - 2016-08-24 07:53:46 --> Router Class Initialized
INFO - 2016-08-24 07:53:46 --> Output Class Initialized
INFO - 2016-08-24 07:53:46 --> Security Class Initialized
DEBUG - 2016-08-24 07:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:53:46 --> Input Class Initialized
INFO - 2016-08-24 07:53:46 --> Language Class Initialized
INFO - 2016-08-24 07:53:46 --> Loader Class Initialized
INFO - 2016-08-24 07:53:46 --> Helper loaded: url_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: html_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: form_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: file_helper
INFO - 2016-08-24 07:53:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:53:46 --> Database Driver Class Initialized
INFO - 2016-08-24 07:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:53:46 --> Form Validation Class Initialized
INFO - 2016-08-24 07:53:46 --> Email Class Initialized
INFO - 2016-08-24 07:53:46 --> Controller Class Initialized
INFO - 2016-08-24 07:53:46 --> Model Class Initialized
INFO - 2016-08-24 07:56:07 --> Config Class Initialized
INFO - 2016-08-24 07:56:07 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:07 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:07 --> URI Class Initialized
INFO - 2016-08-24 07:56:07 --> Router Class Initialized
INFO - 2016-08-24 07:56:07 --> Output Class Initialized
INFO - 2016-08-24 07:56:07 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:07 --> Input Class Initialized
INFO - 2016-08-24 07:56:08 --> Language Class Initialized
INFO - 2016-08-24 07:56:08 --> Loader Class Initialized
INFO - 2016-08-24 07:56:08 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:08 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:08 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:08 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:08 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:08 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:08 --> Email Class Initialized
INFO - 2016-08-24 07:56:08 --> Controller Class Initialized
INFO - 2016-08-24 07:56:08 --> Model Class Initialized
DEBUG - 2016-08-24 07:56:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:56:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:56:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:56:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:56:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:56:08 --> Final output sent to browser
DEBUG - 2016-08-24 07:56:08 --> Total execution time: 0.4262
INFO - 2016-08-24 07:56:10 --> Config Class Initialized
INFO - 2016-08-24 07:56:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:10 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:10 --> URI Class Initialized
INFO - 2016-08-24 07:56:10 --> Router Class Initialized
INFO - 2016-08-24 07:56:10 --> Output Class Initialized
INFO - 2016-08-24 07:56:10 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:11 --> Input Class Initialized
INFO - 2016-08-24 07:56:11 --> Language Class Initialized
INFO - 2016-08-24 07:56:11 --> Loader Class Initialized
INFO - 2016-08-24 07:56:11 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:11 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:11 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:11 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:11 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:11 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:11 --> Email Class Initialized
INFO - 2016-08-24 07:56:11 --> Controller Class Initialized
INFO - 2016-08-24 07:56:11 --> Model Class Initialized
DEBUG - 2016-08-24 07:56:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 07:56:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 07:56:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 07:56:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 07:56:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 07:56:11 --> Final output sent to browser
DEBUG - 2016-08-24 07:56:11 --> Total execution time: 0.4189
INFO - 2016-08-24 07:56:13 --> Config Class Initialized
INFO - 2016-08-24 07:56:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:13 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:13 --> URI Class Initialized
INFO - 2016-08-24 07:56:13 --> Router Class Initialized
INFO - 2016-08-24 07:56:13 --> Output Class Initialized
INFO - 2016-08-24 07:56:13 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:13 --> Input Class Initialized
INFO - 2016-08-24 07:56:13 --> Language Class Initialized
INFO - 2016-08-24 07:56:13 --> Loader Class Initialized
INFO - 2016-08-24 07:56:13 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:13 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:13 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:13 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:13 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:13 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:13 --> Email Class Initialized
INFO - 2016-08-24 07:56:13 --> Controller Class Initialized
INFO - 2016-08-24 07:56:13 --> Model Class Initialized
INFO - 2016-08-24 07:56:14 --> Config Class Initialized
INFO - 2016-08-24 07:56:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:14 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:14 --> URI Class Initialized
INFO - 2016-08-24 07:56:14 --> Router Class Initialized
INFO - 2016-08-24 07:56:14 --> Output Class Initialized
INFO - 2016-08-24 07:56:14 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:14 --> Input Class Initialized
INFO - 2016-08-24 07:56:14 --> Language Class Initialized
INFO - 2016-08-24 07:56:14 --> Loader Class Initialized
INFO - 2016-08-24 07:56:14 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:14 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:14 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:14 --> Email Class Initialized
INFO - 2016-08-24 07:56:14 --> Controller Class Initialized
INFO - 2016-08-24 07:56:14 --> Model Class Initialized
INFO - 2016-08-24 07:56:14 --> Config Class Initialized
INFO - 2016-08-24 07:56:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:14 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:14 --> URI Class Initialized
INFO - 2016-08-24 07:56:14 --> Router Class Initialized
INFO - 2016-08-24 07:56:14 --> Output Class Initialized
INFO - 2016-08-24 07:56:14 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:14 --> Input Class Initialized
INFO - 2016-08-24 07:56:14 --> Language Class Initialized
INFO - 2016-08-24 07:56:14 --> Loader Class Initialized
INFO - 2016-08-24 07:56:14 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:14 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:14 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:14 --> Email Class Initialized
INFO - 2016-08-24 07:56:14 --> Controller Class Initialized
INFO - 2016-08-24 07:56:14 --> Model Class Initialized
INFO - 2016-08-24 07:56:14 --> Config Class Initialized
INFO - 2016-08-24 07:56:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:14 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:14 --> URI Class Initialized
INFO - 2016-08-24 07:56:14 --> Router Class Initialized
INFO - 2016-08-24 07:56:14 --> Output Class Initialized
INFO - 2016-08-24 07:56:14 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:14 --> Input Class Initialized
INFO - 2016-08-24 07:56:14 --> Language Class Initialized
INFO - 2016-08-24 07:56:14 --> Loader Class Initialized
INFO - 2016-08-24 07:56:14 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:14 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:15 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:15 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:15 --> Email Class Initialized
INFO - 2016-08-24 07:56:15 --> Controller Class Initialized
INFO - 2016-08-24 07:56:15 --> Model Class Initialized
INFO - 2016-08-24 07:56:15 --> Config Class Initialized
INFO - 2016-08-24 07:56:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:15 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:15 --> URI Class Initialized
INFO - 2016-08-24 07:56:15 --> Router Class Initialized
INFO - 2016-08-24 07:56:15 --> Output Class Initialized
INFO - 2016-08-24 07:56:15 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:15 --> Input Class Initialized
INFO - 2016-08-24 07:56:15 --> Language Class Initialized
INFO - 2016-08-24 07:56:15 --> Loader Class Initialized
INFO - 2016-08-24 07:56:15 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:15 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:15 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:15 --> Email Class Initialized
INFO - 2016-08-24 07:56:15 --> Controller Class Initialized
INFO - 2016-08-24 07:56:15 --> Model Class Initialized
INFO - 2016-08-24 07:56:15 --> Config Class Initialized
INFO - 2016-08-24 07:56:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:15 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:15 --> URI Class Initialized
INFO - 2016-08-24 07:56:15 --> Router Class Initialized
INFO - 2016-08-24 07:56:15 --> Output Class Initialized
INFO - 2016-08-24 07:56:15 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:15 --> Input Class Initialized
INFO - 2016-08-24 07:56:15 --> Language Class Initialized
INFO - 2016-08-24 07:56:15 --> Loader Class Initialized
INFO - 2016-08-24 07:56:15 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:15 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:15 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:15 --> Email Class Initialized
INFO - 2016-08-24 07:56:15 --> Controller Class Initialized
INFO - 2016-08-24 07:56:15 --> Model Class Initialized
INFO - 2016-08-24 07:56:15 --> Config Class Initialized
INFO - 2016-08-24 07:56:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:15 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:15 --> URI Class Initialized
INFO - 2016-08-24 07:56:16 --> Router Class Initialized
INFO - 2016-08-24 07:56:16 --> Output Class Initialized
INFO - 2016-08-24 07:56:16 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:16 --> Input Class Initialized
INFO - 2016-08-24 07:56:16 --> Language Class Initialized
INFO - 2016-08-24 07:56:16 --> Loader Class Initialized
INFO - 2016-08-24 07:56:16 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:16 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:16 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:16 --> Email Class Initialized
INFO - 2016-08-24 07:56:16 --> Controller Class Initialized
INFO - 2016-08-24 07:56:16 --> Model Class Initialized
INFO - 2016-08-24 07:56:16 --> Config Class Initialized
INFO - 2016-08-24 07:56:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:16 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:16 --> URI Class Initialized
INFO - 2016-08-24 07:56:16 --> Router Class Initialized
INFO - 2016-08-24 07:56:16 --> Output Class Initialized
INFO - 2016-08-24 07:56:16 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:16 --> Input Class Initialized
INFO - 2016-08-24 07:56:16 --> Language Class Initialized
INFO - 2016-08-24 07:56:16 --> Loader Class Initialized
INFO - 2016-08-24 07:56:16 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:16 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:16 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:16 --> Email Class Initialized
INFO - 2016-08-24 07:56:16 --> Controller Class Initialized
INFO - 2016-08-24 07:56:16 --> Model Class Initialized
INFO - 2016-08-24 07:56:16 --> Config Class Initialized
INFO - 2016-08-24 07:56:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:16 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:16 --> URI Class Initialized
INFO - 2016-08-24 07:56:16 --> Router Class Initialized
INFO - 2016-08-24 07:56:16 --> Output Class Initialized
INFO - 2016-08-24 07:56:16 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:16 --> Input Class Initialized
INFO - 2016-08-24 07:56:16 --> Language Class Initialized
INFO - 2016-08-24 07:56:16 --> Loader Class Initialized
INFO - 2016-08-24 07:56:16 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:16 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:16 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:17 --> Email Class Initialized
INFO - 2016-08-24 07:56:17 --> Controller Class Initialized
INFO - 2016-08-24 07:56:17 --> Model Class Initialized
INFO - 2016-08-24 07:56:17 --> Config Class Initialized
INFO - 2016-08-24 07:56:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:17 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:17 --> URI Class Initialized
INFO - 2016-08-24 07:56:17 --> Router Class Initialized
INFO - 2016-08-24 07:56:17 --> Output Class Initialized
INFO - 2016-08-24 07:56:17 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:17 --> Input Class Initialized
INFO - 2016-08-24 07:56:17 --> Language Class Initialized
INFO - 2016-08-24 07:56:17 --> Loader Class Initialized
INFO - 2016-08-24 07:56:17 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:17 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:17 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:17 --> Email Class Initialized
INFO - 2016-08-24 07:56:17 --> Controller Class Initialized
INFO - 2016-08-24 07:56:17 --> Model Class Initialized
INFO - 2016-08-24 07:56:17 --> Config Class Initialized
INFO - 2016-08-24 07:56:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:17 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:17 --> URI Class Initialized
INFO - 2016-08-24 07:56:17 --> Router Class Initialized
INFO - 2016-08-24 07:56:17 --> Output Class Initialized
INFO - 2016-08-24 07:56:17 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:17 --> Input Class Initialized
INFO - 2016-08-24 07:56:17 --> Language Class Initialized
INFO - 2016-08-24 07:56:17 --> Loader Class Initialized
INFO - 2016-08-24 07:56:17 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:17 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:17 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:17 --> Email Class Initialized
INFO - 2016-08-24 07:56:17 --> Controller Class Initialized
INFO - 2016-08-24 07:56:17 --> Model Class Initialized
INFO - 2016-08-24 07:56:17 --> Config Class Initialized
INFO - 2016-08-24 07:56:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:17 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:17 --> URI Class Initialized
INFO - 2016-08-24 07:56:17 --> Router Class Initialized
INFO - 2016-08-24 07:56:17 --> Output Class Initialized
INFO - 2016-08-24 07:56:17 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:17 --> Input Class Initialized
INFO - 2016-08-24 07:56:17 --> Language Class Initialized
INFO - 2016-08-24 07:56:18 --> Loader Class Initialized
INFO - 2016-08-24 07:56:18 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:18 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:18 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:18 --> Email Class Initialized
INFO - 2016-08-24 07:56:18 --> Controller Class Initialized
INFO - 2016-08-24 07:56:18 --> Model Class Initialized
INFO - 2016-08-24 07:56:18 --> Config Class Initialized
INFO - 2016-08-24 07:56:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:18 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:18 --> URI Class Initialized
INFO - 2016-08-24 07:56:18 --> Router Class Initialized
INFO - 2016-08-24 07:56:18 --> Output Class Initialized
INFO - 2016-08-24 07:56:18 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:18 --> Input Class Initialized
INFO - 2016-08-24 07:56:18 --> Language Class Initialized
INFO - 2016-08-24 07:56:18 --> Loader Class Initialized
INFO - 2016-08-24 07:56:18 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:18 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:18 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:18 --> Email Class Initialized
INFO - 2016-08-24 07:56:18 --> Controller Class Initialized
INFO - 2016-08-24 07:56:18 --> Model Class Initialized
INFO - 2016-08-24 07:56:18 --> Config Class Initialized
INFO - 2016-08-24 07:56:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:18 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:18 --> URI Class Initialized
INFO - 2016-08-24 07:56:18 --> Router Class Initialized
INFO - 2016-08-24 07:56:18 --> Output Class Initialized
INFO - 2016-08-24 07:56:18 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:18 --> Input Class Initialized
INFO - 2016-08-24 07:56:18 --> Language Class Initialized
INFO - 2016-08-24 07:56:18 --> Loader Class Initialized
INFO - 2016-08-24 07:56:18 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:18 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:19 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:19 --> Email Class Initialized
INFO - 2016-08-24 07:56:19 --> Controller Class Initialized
INFO - 2016-08-24 07:56:19 --> Model Class Initialized
INFO - 2016-08-24 07:56:19 --> Config Class Initialized
INFO - 2016-08-24 07:56:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:19 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:19 --> URI Class Initialized
INFO - 2016-08-24 07:56:19 --> Router Class Initialized
INFO - 2016-08-24 07:56:19 --> Output Class Initialized
INFO - 2016-08-24 07:56:19 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:19 --> Input Class Initialized
INFO - 2016-08-24 07:56:19 --> Language Class Initialized
INFO - 2016-08-24 07:56:19 --> Loader Class Initialized
INFO - 2016-08-24 07:56:19 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:19 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:19 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:19 --> Email Class Initialized
INFO - 2016-08-24 07:56:19 --> Controller Class Initialized
INFO - 2016-08-24 07:56:19 --> Model Class Initialized
INFO - 2016-08-24 07:56:19 --> Config Class Initialized
INFO - 2016-08-24 07:56:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:19 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:19 --> URI Class Initialized
INFO - 2016-08-24 07:56:19 --> Router Class Initialized
INFO - 2016-08-24 07:56:19 --> Output Class Initialized
INFO - 2016-08-24 07:56:19 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:19 --> Input Class Initialized
INFO - 2016-08-24 07:56:19 --> Language Class Initialized
INFO - 2016-08-24 07:56:19 --> Loader Class Initialized
INFO - 2016-08-24 07:56:19 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:19 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:19 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:19 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:19 --> Email Class Initialized
INFO - 2016-08-24 07:56:19 --> Controller Class Initialized
INFO - 2016-08-24 07:56:19 --> Model Class Initialized
INFO - 2016-08-24 07:56:19 --> Config Class Initialized
INFO - 2016-08-24 07:56:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:19 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:19 --> URI Class Initialized
INFO - 2016-08-24 07:56:19 --> Router Class Initialized
INFO - 2016-08-24 07:56:19 --> Output Class Initialized
INFO - 2016-08-24 07:56:19 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:20 --> Input Class Initialized
INFO - 2016-08-24 07:56:20 --> Language Class Initialized
INFO - 2016-08-24 07:56:20 --> Loader Class Initialized
INFO - 2016-08-24 07:56:20 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:20 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:20 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:20 --> Email Class Initialized
INFO - 2016-08-24 07:56:20 --> Controller Class Initialized
INFO - 2016-08-24 07:56:20 --> Model Class Initialized
INFO - 2016-08-24 07:56:20 --> Config Class Initialized
INFO - 2016-08-24 07:56:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:20 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:20 --> URI Class Initialized
INFO - 2016-08-24 07:56:20 --> Router Class Initialized
INFO - 2016-08-24 07:56:20 --> Output Class Initialized
INFO - 2016-08-24 07:56:20 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:20 --> Input Class Initialized
INFO - 2016-08-24 07:56:20 --> Language Class Initialized
INFO - 2016-08-24 07:56:20 --> Loader Class Initialized
INFO - 2016-08-24 07:56:20 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:20 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:20 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:20 --> Email Class Initialized
INFO - 2016-08-24 07:56:20 --> Controller Class Initialized
INFO - 2016-08-24 07:56:20 --> Model Class Initialized
INFO - 2016-08-24 07:56:20 --> Config Class Initialized
INFO - 2016-08-24 07:56:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:20 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:20 --> URI Class Initialized
INFO - 2016-08-24 07:56:20 --> Router Class Initialized
INFO - 2016-08-24 07:56:20 --> Output Class Initialized
INFO - 2016-08-24 07:56:20 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:20 --> Input Class Initialized
INFO - 2016-08-24 07:56:20 --> Language Class Initialized
INFO - 2016-08-24 07:56:20 --> Loader Class Initialized
INFO - 2016-08-24 07:56:20 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:20 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:20 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:20 --> Email Class Initialized
INFO - 2016-08-24 07:56:20 --> Controller Class Initialized
INFO - 2016-08-24 07:56:20 --> Model Class Initialized
INFO - 2016-08-24 07:56:21 --> Config Class Initialized
INFO - 2016-08-24 07:56:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:21 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:21 --> URI Class Initialized
INFO - 2016-08-24 07:56:21 --> Router Class Initialized
INFO - 2016-08-24 07:56:21 --> Output Class Initialized
INFO - 2016-08-24 07:56:21 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:21 --> Input Class Initialized
INFO - 2016-08-24 07:56:21 --> Language Class Initialized
INFO - 2016-08-24 07:56:21 --> Loader Class Initialized
INFO - 2016-08-24 07:56:21 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:21 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:21 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:21 --> Email Class Initialized
INFO - 2016-08-24 07:56:21 --> Controller Class Initialized
INFO - 2016-08-24 07:56:21 --> Model Class Initialized
INFO - 2016-08-24 07:56:21 --> Config Class Initialized
INFO - 2016-08-24 07:56:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:21 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:21 --> URI Class Initialized
INFO - 2016-08-24 07:56:21 --> Router Class Initialized
INFO - 2016-08-24 07:56:21 --> Output Class Initialized
INFO - 2016-08-24 07:56:21 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:21 --> Input Class Initialized
INFO - 2016-08-24 07:56:21 --> Language Class Initialized
INFO - 2016-08-24 07:56:21 --> Loader Class Initialized
INFO - 2016-08-24 07:56:21 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:21 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:21 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:21 --> Email Class Initialized
INFO - 2016-08-24 07:56:21 --> Controller Class Initialized
INFO - 2016-08-24 07:56:21 --> Model Class Initialized
INFO - 2016-08-24 07:56:57 --> Config Class Initialized
INFO - 2016-08-24 07:56:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:57 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:57 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:57 --> URI Class Initialized
INFO - 2016-08-24 07:56:57 --> Router Class Initialized
INFO - 2016-08-24 07:56:57 --> Output Class Initialized
INFO - 2016-08-24 07:56:57 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:57 --> Input Class Initialized
INFO - 2016-08-24 07:56:57 --> Language Class Initialized
INFO - 2016-08-24 07:56:57 --> Loader Class Initialized
INFO - 2016-08-24 07:56:57 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:57 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:57 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:57 --> Email Class Initialized
INFO - 2016-08-24 07:56:57 --> Controller Class Initialized
INFO - 2016-08-24 07:56:57 --> Model Class Initialized
INFO - 2016-08-24 07:56:57 --> Config Class Initialized
INFO - 2016-08-24 07:56:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:57 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:57 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:57 --> URI Class Initialized
INFO - 2016-08-24 07:56:57 --> Router Class Initialized
INFO - 2016-08-24 07:56:57 --> Output Class Initialized
INFO - 2016-08-24 07:56:57 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:57 --> Input Class Initialized
INFO - 2016-08-24 07:56:57 --> Language Class Initialized
INFO - 2016-08-24 07:56:57 --> Loader Class Initialized
INFO - 2016-08-24 07:56:57 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:57 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:57 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:57 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:57 --> Email Class Initialized
INFO - 2016-08-24 07:56:57 --> Controller Class Initialized
INFO - 2016-08-24 07:56:57 --> Model Class Initialized
INFO - 2016-08-24 07:56:57 --> Config Class Initialized
INFO - 2016-08-24 07:56:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:58 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:58 --> URI Class Initialized
INFO - 2016-08-24 07:56:58 --> Router Class Initialized
INFO - 2016-08-24 07:56:58 --> Output Class Initialized
INFO - 2016-08-24 07:56:58 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:58 --> Input Class Initialized
INFO - 2016-08-24 07:56:58 --> Language Class Initialized
INFO - 2016-08-24 07:56:58 --> Loader Class Initialized
INFO - 2016-08-24 07:56:58 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:58 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:58 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:58 --> Email Class Initialized
INFO - 2016-08-24 07:56:58 --> Controller Class Initialized
INFO - 2016-08-24 07:56:58 --> Model Class Initialized
INFO - 2016-08-24 07:56:58 --> Config Class Initialized
INFO - 2016-08-24 07:56:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:58 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:58 --> URI Class Initialized
INFO - 2016-08-24 07:56:58 --> Router Class Initialized
INFO - 2016-08-24 07:56:58 --> Output Class Initialized
INFO - 2016-08-24 07:56:58 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:58 --> Input Class Initialized
INFO - 2016-08-24 07:56:58 --> Language Class Initialized
INFO - 2016-08-24 07:56:58 --> Loader Class Initialized
INFO - 2016-08-24 07:56:58 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:58 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:58 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:58 --> Email Class Initialized
INFO - 2016-08-24 07:56:58 --> Controller Class Initialized
INFO - 2016-08-24 07:56:58 --> Model Class Initialized
INFO - 2016-08-24 07:56:58 --> Config Class Initialized
INFO - 2016-08-24 07:56:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:58 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:58 --> URI Class Initialized
INFO - 2016-08-24 07:56:58 --> Router Class Initialized
INFO - 2016-08-24 07:56:58 --> Output Class Initialized
INFO - 2016-08-24 07:56:58 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:58 --> Input Class Initialized
INFO - 2016-08-24 07:56:58 --> Language Class Initialized
INFO - 2016-08-24 07:56:58 --> Loader Class Initialized
INFO - 2016-08-24 07:56:58 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:58 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:59 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:59 --> Email Class Initialized
INFO - 2016-08-24 07:56:59 --> Controller Class Initialized
INFO - 2016-08-24 07:56:59 --> Model Class Initialized
INFO - 2016-08-24 07:56:59 --> Config Class Initialized
INFO - 2016-08-24 07:56:59 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:59 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:59 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:59 --> URI Class Initialized
INFO - 2016-08-24 07:56:59 --> Router Class Initialized
INFO - 2016-08-24 07:56:59 --> Output Class Initialized
INFO - 2016-08-24 07:56:59 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:59 --> Input Class Initialized
INFO - 2016-08-24 07:56:59 --> Language Class Initialized
INFO - 2016-08-24 07:56:59 --> Loader Class Initialized
INFO - 2016-08-24 07:56:59 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:59 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:59 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:59 --> Email Class Initialized
INFO - 2016-08-24 07:56:59 --> Controller Class Initialized
INFO - 2016-08-24 07:56:59 --> Model Class Initialized
INFO - 2016-08-24 07:56:59 --> Config Class Initialized
INFO - 2016-08-24 07:56:59 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:59 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:59 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:59 --> URI Class Initialized
INFO - 2016-08-24 07:56:59 --> Router Class Initialized
INFO - 2016-08-24 07:56:59 --> Output Class Initialized
INFO - 2016-08-24 07:56:59 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:56:59 --> Input Class Initialized
INFO - 2016-08-24 07:56:59 --> Language Class Initialized
INFO - 2016-08-24 07:56:59 --> Loader Class Initialized
INFO - 2016-08-24 07:56:59 --> Helper loaded: url_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: html_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: form_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: file_helper
INFO - 2016-08-24 07:56:59 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:56:59 --> Database Driver Class Initialized
INFO - 2016-08-24 07:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:56:59 --> Form Validation Class Initialized
INFO - 2016-08-24 07:56:59 --> Email Class Initialized
INFO - 2016-08-24 07:56:59 --> Controller Class Initialized
INFO - 2016-08-24 07:56:59 --> Model Class Initialized
INFO - 2016-08-24 07:56:59 --> Config Class Initialized
INFO - 2016-08-24 07:56:59 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:56:59 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:56:59 --> Utf8 Class Initialized
INFO - 2016-08-24 07:56:59 --> URI Class Initialized
INFO - 2016-08-24 07:56:59 --> Router Class Initialized
INFO - 2016-08-24 07:56:59 --> Output Class Initialized
INFO - 2016-08-24 07:56:59 --> Security Class Initialized
DEBUG - 2016-08-24 07:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:00 --> Input Class Initialized
INFO - 2016-08-24 07:57:00 --> Language Class Initialized
INFO - 2016-08-24 07:57:00 --> Loader Class Initialized
INFO - 2016-08-24 07:57:00 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:00 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:00 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:00 --> Email Class Initialized
INFO - 2016-08-24 07:57:00 --> Controller Class Initialized
INFO - 2016-08-24 07:57:00 --> Model Class Initialized
INFO - 2016-08-24 07:57:00 --> Config Class Initialized
INFO - 2016-08-24 07:57:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:00 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:00 --> URI Class Initialized
INFO - 2016-08-24 07:57:00 --> Router Class Initialized
INFO - 2016-08-24 07:57:00 --> Output Class Initialized
INFO - 2016-08-24 07:57:00 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:00 --> Input Class Initialized
INFO - 2016-08-24 07:57:00 --> Language Class Initialized
INFO - 2016-08-24 07:57:00 --> Loader Class Initialized
INFO - 2016-08-24 07:57:00 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:00 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:00 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:00 --> Email Class Initialized
INFO - 2016-08-24 07:57:00 --> Controller Class Initialized
INFO - 2016-08-24 07:57:00 --> Model Class Initialized
INFO - 2016-08-24 07:57:00 --> Config Class Initialized
INFO - 2016-08-24 07:57:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:00 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:00 --> URI Class Initialized
INFO - 2016-08-24 07:57:00 --> Router Class Initialized
INFO - 2016-08-24 07:57:00 --> Output Class Initialized
INFO - 2016-08-24 07:57:00 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:00 --> Input Class Initialized
INFO - 2016-08-24 07:57:00 --> Language Class Initialized
INFO - 2016-08-24 07:57:00 --> Loader Class Initialized
INFO - 2016-08-24 07:57:00 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:00 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:00 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:00 --> Email Class Initialized
INFO - 2016-08-24 07:57:00 --> Controller Class Initialized
INFO - 2016-08-24 07:57:00 --> Model Class Initialized
INFO - 2016-08-24 07:57:01 --> Config Class Initialized
INFO - 2016-08-24 07:57:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:01 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:01 --> URI Class Initialized
INFO - 2016-08-24 07:57:01 --> Router Class Initialized
INFO - 2016-08-24 07:57:01 --> Output Class Initialized
INFO - 2016-08-24 07:57:01 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:01 --> Input Class Initialized
INFO - 2016-08-24 07:57:01 --> Language Class Initialized
INFO - 2016-08-24 07:57:01 --> Loader Class Initialized
INFO - 2016-08-24 07:57:01 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:01 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:01 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:01 --> Email Class Initialized
INFO - 2016-08-24 07:57:01 --> Controller Class Initialized
INFO - 2016-08-24 07:57:01 --> Model Class Initialized
INFO - 2016-08-24 07:57:01 --> Config Class Initialized
INFO - 2016-08-24 07:57:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:01 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:01 --> URI Class Initialized
INFO - 2016-08-24 07:57:01 --> Router Class Initialized
INFO - 2016-08-24 07:57:01 --> Output Class Initialized
INFO - 2016-08-24 07:57:01 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:01 --> Input Class Initialized
INFO - 2016-08-24 07:57:01 --> Language Class Initialized
INFO - 2016-08-24 07:57:01 --> Loader Class Initialized
INFO - 2016-08-24 07:57:01 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:01 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:01 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:01 --> Email Class Initialized
INFO - 2016-08-24 07:57:01 --> Controller Class Initialized
INFO - 2016-08-24 07:57:01 --> Model Class Initialized
INFO - 2016-08-24 07:57:01 --> Config Class Initialized
INFO - 2016-08-24 07:57:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:01 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:01 --> URI Class Initialized
INFO - 2016-08-24 07:57:01 --> Router Class Initialized
INFO - 2016-08-24 07:57:01 --> Output Class Initialized
INFO - 2016-08-24 07:57:01 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:01 --> Input Class Initialized
INFO - 2016-08-24 07:57:01 --> Language Class Initialized
INFO - 2016-08-24 07:57:01 --> Loader Class Initialized
INFO - 2016-08-24 07:57:01 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:01 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:02 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:02 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:02 --> Email Class Initialized
INFO - 2016-08-24 07:57:02 --> Controller Class Initialized
INFO - 2016-08-24 07:57:02 --> Model Class Initialized
INFO - 2016-08-24 07:57:02 --> Config Class Initialized
INFO - 2016-08-24 07:57:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:02 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:02 --> URI Class Initialized
INFO - 2016-08-24 07:57:02 --> Router Class Initialized
INFO - 2016-08-24 07:57:02 --> Output Class Initialized
INFO - 2016-08-24 07:57:02 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:02 --> Input Class Initialized
INFO - 2016-08-24 07:57:02 --> Language Class Initialized
INFO - 2016-08-24 07:57:02 --> Loader Class Initialized
INFO - 2016-08-24 07:57:02 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:02 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:02 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:02 --> Email Class Initialized
INFO - 2016-08-24 07:57:02 --> Controller Class Initialized
INFO - 2016-08-24 07:57:02 --> Model Class Initialized
INFO - 2016-08-24 07:57:02 --> Config Class Initialized
INFO - 2016-08-24 07:57:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:02 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:02 --> URI Class Initialized
INFO - 2016-08-24 07:57:02 --> Router Class Initialized
INFO - 2016-08-24 07:57:02 --> Output Class Initialized
INFO - 2016-08-24 07:57:02 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:02 --> Input Class Initialized
INFO - 2016-08-24 07:57:02 --> Language Class Initialized
INFO - 2016-08-24 07:57:02 --> Loader Class Initialized
INFO - 2016-08-24 07:57:02 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:02 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:02 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:02 --> Email Class Initialized
INFO - 2016-08-24 07:57:02 --> Controller Class Initialized
INFO - 2016-08-24 07:57:02 --> Model Class Initialized
INFO - 2016-08-24 07:57:02 --> Config Class Initialized
INFO - 2016-08-24 07:57:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:02 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:02 --> URI Class Initialized
INFO - 2016-08-24 07:57:03 --> Router Class Initialized
INFO - 2016-08-24 07:57:03 --> Output Class Initialized
INFO - 2016-08-24 07:57:03 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:03 --> Input Class Initialized
INFO - 2016-08-24 07:57:03 --> Language Class Initialized
INFO - 2016-08-24 07:57:03 --> Loader Class Initialized
INFO - 2016-08-24 07:57:03 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:03 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:03 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:03 --> Email Class Initialized
INFO - 2016-08-24 07:57:03 --> Controller Class Initialized
INFO - 2016-08-24 07:57:03 --> Model Class Initialized
INFO - 2016-08-24 07:57:03 --> Config Class Initialized
INFO - 2016-08-24 07:57:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:03 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:03 --> URI Class Initialized
INFO - 2016-08-24 07:57:03 --> Router Class Initialized
INFO - 2016-08-24 07:57:03 --> Output Class Initialized
INFO - 2016-08-24 07:57:03 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:03 --> Input Class Initialized
INFO - 2016-08-24 07:57:03 --> Language Class Initialized
INFO - 2016-08-24 07:57:03 --> Loader Class Initialized
INFO - 2016-08-24 07:57:03 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:03 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:03 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:03 --> Email Class Initialized
INFO - 2016-08-24 07:57:03 --> Controller Class Initialized
INFO - 2016-08-24 07:57:03 --> Model Class Initialized
INFO - 2016-08-24 07:57:03 --> Config Class Initialized
INFO - 2016-08-24 07:57:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:03 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:03 --> URI Class Initialized
INFO - 2016-08-24 07:57:03 --> Router Class Initialized
INFO - 2016-08-24 07:57:03 --> Output Class Initialized
INFO - 2016-08-24 07:57:03 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:03 --> Input Class Initialized
INFO - 2016-08-24 07:57:03 --> Language Class Initialized
INFO - 2016-08-24 07:57:03 --> Loader Class Initialized
INFO - 2016-08-24 07:57:03 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:03 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:03 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:04 --> Email Class Initialized
INFO - 2016-08-24 07:57:04 --> Controller Class Initialized
INFO - 2016-08-24 07:57:04 --> Model Class Initialized
INFO - 2016-08-24 07:57:04 --> Config Class Initialized
INFO - 2016-08-24 07:57:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:04 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:04 --> URI Class Initialized
INFO - 2016-08-24 07:57:04 --> Router Class Initialized
INFO - 2016-08-24 07:57:04 --> Output Class Initialized
INFO - 2016-08-24 07:57:04 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:04 --> Input Class Initialized
INFO - 2016-08-24 07:57:04 --> Language Class Initialized
INFO - 2016-08-24 07:57:04 --> Loader Class Initialized
INFO - 2016-08-24 07:57:04 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:04 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:04 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:04 --> Email Class Initialized
INFO - 2016-08-24 07:57:04 --> Controller Class Initialized
INFO - 2016-08-24 07:57:04 --> Model Class Initialized
INFO - 2016-08-24 07:57:04 --> Config Class Initialized
INFO - 2016-08-24 07:57:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:04 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:04 --> URI Class Initialized
INFO - 2016-08-24 07:57:04 --> Router Class Initialized
INFO - 2016-08-24 07:57:04 --> Output Class Initialized
INFO - 2016-08-24 07:57:04 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:04 --> Input Class Initialized
INFO - 2016-08-24 07:57:04 --> Language Class Initialized
INFO - 2016-08-24 07:57:04 --> Loader Class Initialized
INFO - 2016-08-24 07:57:04 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:04 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:04 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:04 --> Email Class Initialized
INFO - 2016-08-24 07:57:04 --> Controller Class Initialized
INFO - 2016-08-24 07:57:04 --> Model Class Initialized
INFO - 2016-08-24 07:57:04 --> Config Class Initialized
INFO - 2016-08-24 07:57:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:04 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:04 --> URI Class Initialized
INFO - 2016-08-24 07:57:04 --> Router Class Initialized
INFO - 2016-08-24 07:57:04 --> Output Class Initialized
INFO - 2016-08-24 07:57:04 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:04 --> Input Class Initialized
INFO - 2016-08-24 07:57:04 --> Language Class Initialized
INFO - 2016-08-24 07:57:05 --> Loader Class Initialized
INFO - 2016-08-24 07:57:05 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:05 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:05 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:05 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:05 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:05 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:05 --> Email Class Initialized
INFO - 2016-08-24 07:57:05 --> Controller Class Initialized
INFO - 2016-08-24 07:57:05 --> Model Class Initialized
INFO - 2016-08-24 07:57:48 --> Config Class Initialized
INFO - 2016-08-24 07:57:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:48 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:48 --> URI Class Initialized
INFO - 2016-08-24 07:57:48 --> Router Class Initialized
INFO - 2016-08-24 07:57:48 --> Output Class Initialized
INFO - 2016-08-24 07:57:48 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:48 --> Input Class Initialized
INFO - 2016-08-24 07:57:48 --> Language Class Initialized
INFO - 2016-08-24 07:57:49 --> Loader Class Initialized
INFO - 2016-08-24 07:57:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:49 --> Email Class Initialized
INFO - 2016-08-24 07:57:49 --> Controller Class Initialized
INFO - 2016-08-24 07:57:49 --> Model Class Initialized
INFO - 2016-08-24 07:57:49 --> Config Class Initialized
INFO - 2016-08-24 07:57:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:49 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:49 --> URI Class Initialized
INFO - 2016-08-24 07:57:49 --> Router Class Initialized
INFO - 2016-08-24 07:57:49 --> Output Class Initialized
INFO - 2016-08-24 07:57:49 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:49 --> Input Class Initialized
INFO - 2016-08-24 07:57:49 --> Language Class Initialized
INFO - 2016-08-24 07:57:49 --> Loader Class Initialized
INFO - 2016-08-24 07:57:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:49 --> Email Class Initialized
INFO - 2016-08-24 07:57:49 --> Controller Class Initialized
INFO - 2016-08-24 07:57:49 --> Model Class Initialized
INFO - 2016-08-24 07:57:49 --> Config Class Initialized
INFO - 2016-08-24 07:57:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:49 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:49 --> URI Class Initialized
INFO - 2016-08-24 07:57:49 --> Router Class Initialized
INFO - 2016-08-24 07:57:49 --> Output Class Initialized
INFO - 2016-08-24 07:57:49 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:49 --> Input Class Initialized
INFO - 2016-08-24 07:57:49 --> Language Class Initialized
INFO - 2016-08-24 07:57:49 --> Loader Class Initialized
INFO - 2016-08-24 07:57:49 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:49 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:49 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:49 --> Email Class Initialized
INFO - 2016-08-24 07:57:49 --> Controller Class Initialized
INFO - 2016-08-24 07:57:49 --> Model Class Initialized
INFO - 2016-08-24 07:57:50 --> Config Class Initialized
INFO - 2016-08-24 07:57:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:50 --> URI Class Initialized
INFO - 2016-08-24 07:57:50 --> Router Class Initialized
INFO - 2016-08-24 07:57:50 --> Output Class Initialized
INFO - 2016-08-24 07:57:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:50 --> Input Class Initialized
INFO - 2016-08-24 07:57:50 --> Language Class Initialized
INFO - 2016-08-24 07:57:50 --> Loader Class Initialized
INFO - 2016-08-24 07:57:50 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:50 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:50 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:50 --> Email Class Initialized
INFO - 2016-08-24 07:57:50 --> Controller Class Initialized
INFO - 2016-08-24 07:57:50 --> Model Class Initialized
INFO - 2016-08-24 07:57:50 --> Config Class Initialized
INFO - 2016-08-24 07:57:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:50 --> URI Class Initialized
INFO - 2016-08-24 07:57:50 --> Router Class Initialized
INFO - 2016-08-24 07:57:50 --> Output Class Initialized
INFO - 2016-08-24 07:57:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:50 --> Input Class Initialized
INFO - 2016-08-24 07:57:50 --> Language Class Initialized
INFO - 2016-08-24 07:57:50 --> Loader Class Initialized
INFO - 2016-08-24 07:57:50 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:50 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:50 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:50 --> Email Class Initialized
INFO - 2016-08-24 07:57:50 --> Controller Class Initialized
INFO - 2016-08-24 07:57:50 --> Model Class Initialized
INFO - 2016-08-24 07:57:50 --> Config Class Initialized
INFO - 2016-08-24 07:57:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:50 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:50 --> URI Class Initialized
INFO - 2016-08-24 07:57:50 --> Router Class Initialized
INFO - 2016-08-24 07:57:50 --> Output Class Initialized
INFO - 2016-08-24 07:57:50 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:50 --> Input Class Initialized
INFO - 2016-08-24 07:57:50 --> Language Class Initialized
INFO - 2016-08-24 07:57:50 --> Loader Class Initialized
INFO - 2016-08-24 07:57:50 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:51 --> Email Class Initialized
INFO - 2016-08-24 07:57:51 --> Controller Class Initialized
INFO - 2016-08-24 07:57:51 --> Model Class Initialized
INFO - 2016-08-24 07:57:51 --> Config Class Initialized
INFO - 2016-08-24 07:57:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:51 --> URI Class Initialized
INFO - 2016-08-24 07:57:51 --> Router Class Initialized
INFO - 2016-08-24 07:57:51 --> Output Class Initialized
INFO - 2016-08-24 07:57:51 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:51 --> Input Class Initialized
INFO - 2016-08-24 07:57:51 --> Language Class Initialized
INFO - 2016-08-24 07:57:51 --> Loader Class Initialized
INFO - 2016-08-24 07:57:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:51 --> Email Class Initialized
INFO - 2016-08-24 07:57:51 --> Controller Class Initialized
INFO - 2016-08-24 07:57:51 --> Model Class Initialized
INFO - 2016-08-24 07:57:51 --> Config Class Initialized
INFO - 2016-08-24 07:57:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:51 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:51 --> URI Class Initialized
INFO - 2016-08-24 07:57:51 --> Router Class Initialized
INFO - 2016-08-24 07:57:51 --> Output Class Initialized
INFO - 2016-08-24 07:57:51 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:51 --> Input Class Initialized
INFO - 2016-08-24 07:57:51 --> Language Class Initialized
INFO - 2016-08-24 07:57:51 --> Loader Class Initialized
INFO - 2016-08-24 07:57:51 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:51 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:51 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:51 --> Email Class Initialized
INFO - 2016-08-24 07:57:51 --> Controller Class Initialized
INFO - 2016-08-24 07:57:51 --> Model Class Initialized
INFO - 2016-08-24 07:57:51 --> Config Class Initialized
INFO - 2016-08-24 07:57:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:52 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:52 --> URI Class Initialized
INFO - 2016-08-24 07:57:52 --> Router Class Initialized
INFO - 2016-08-24 07:57:52 --> Output Class Initialized
INFO - 2016-08-24 07:57:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:52 --> Input Class Initialized
INFO - 2016-08-24 07:57:52 --> Language Class Initialized
INFO - 2016-08-24 07:57:52 --> Loader Class Initialized
INFO - 2016-08-24 07:57:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:52 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:52 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:52 --> Email Class Initialized
INFO - 2016-08-24 07:57:52 --> Controller Class Initialized
INFO - 2016-08-24 07:57:52 --> Model Class Initialized
INFO - 2016-08-24 07:57:52 --> Config Class Initialized
INFO - 2016-08-24 07:57:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:52 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:52 --> URI Class Initialized
INFO - 2016-08-24 07:57:52 --> Router Class Initialized
INFO - 2016-08-24 07:57:52 --> Output Class Initialized
INFO - 2016-08-24 07:57:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:52 --> Input Class Initialized
INFO - 2016-08-24 07:57:52 --> Language Class Initialized
INFO - 2016-08-24 07:57:52 --> Loader Class Initialized
INFO - 2016-08-24 07:57:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:52 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:52 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:52 --> Email Class Initialized
INFO - 2016-08-24 07:57:52 --> Controller Class Initialized
INFO - 2016-08-24 07:57:52 --> Model Class Initialized
INFO - 2016-08-24 07:57:52 --> Config Class Initialized
INFO - 2016-08-24 07:57:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:52 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:52 --> URI Class Initialized
INFO - 2016-08-24 07:57:52 --> Router Class Initialized
INFO - 2016-08-24 07:57:52 --> Output Class Initialized
INFO - 2016-08-24 07:57:52 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:52 --> Input Class Initialized
INFO - 2016-08-24 07:57:52 --> Language Class Initialized
INFO - 2016-08-24 07:57:52 --> Loader Class Initialized
INFO - 2016-08-24 07:57:52 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:52 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:53 --> Email Class Initialized
INFO - 2016-08-24 07:57:53 --> Controller Class Initialized
INFO - 2016-08-24 07:57:53 --> Model Class Initialized
INFO - 2016-08-24 07:57:53 --> Config Class Initialized
INFO - 2016-08-24 07:57:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:53 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:53 --> URI Class Initialized
INFO - 2016-08-24 07:57:53 --> Router Class Initialized
INFO - 2016-08-24 07:57:53 --> Output Class Initialized
INFO - 2016-08-24 07:57:53 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:53 --> Input Class Initialized
INFO - 2016-08-24 07:57:53 --> Language Class Initialized
INFO - 2016-08-24 07:57:53 --> Loader Class Initialized
INFO - 2016-08-24 07:57:53 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:53 --> Email Class Initialized
INFO - 2016-08-24 07:57:53 --> Controller Class Initialized
INFO - 2016-08-24 07:57:53 --> Model Class Initialized
INFO - 2016-08-24 07:57:53 --> Config Class Initialized
INFO - 2016-08-24 07:57:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:53 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:53 --> URI Class Initialized
INFO - 2016-08-24 07:57:53 --> Router Class Initialized
INFO - 2016-08-24 07:57:53 --> Output Class Initialized
INFO - 2016-08-24 07:57:53 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:53 --> Input Class Initialized
INFO - 2016-08-24 07:57:53 --> Language Class Initialized
INFO - 2016-08-24 07:57:53 --> Loader Class Initialized
INFO - 2016-08-24 07:57:53 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:53 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:53 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:53 --> Email Class Initialized
INFO - 2016-08-24 07:57:53 --> Controller Class Initialized
INFO - 2016-08-24 07:57:53 --> Model Class Initialized
INFO - 2016-08-24 07:57:53 --> Config Class Initialized
INFO - 2016-08-24 07:57:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:54 --> URI Class Initialized
INFO - 2016-08-24 07:57:54 --> Router Class Initialized
INFO - 2016-08-24 07:57:54 --> Output Class Initialized
INFO - 2016-08-24 07:57:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:54 --> Input Class Initialized
INFO - 2016-08-24 07:57:54 --> Language Class Initialized
INFO - 2016-08-24 07:57:54 --> Loader Class Initialized
INFO - 2016-08-24 07:57:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:54 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:54 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:54 --> Email Class Initialized
INFO - 2016-08-24 07:57:54 --> Controller Class Initialized
INFO - 2016-08-24 07:57:54 --> Model Class Initialized
INFO - 2016-08-24 07:57:54 --> Config Class Initialized
INFO - 2016-08-24 07:57:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:54 --> URI Class Initialized
INFO - 2016-08-24 07:57:54 --> Router Class Initialized
INFO - 2016-08-24 07:57:54 --> Output Class Initialized
INFO - 2016-08-24 07:57:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:54 --> Input Class Initialized
INFO - 2016-08-24 07:57:54 --> Language Class Initialized
INFO - 2016-08-24 07:57:54 --> Loader Class Initialized
INFO - 2016-08-24 07:57:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:54 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:54 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:54 --> Email Class Initialized
INFO - 2016-08-24 07:57:54 --> Controller Class Initialized
INFO - 2016-08-24 07:57:54 --> Model Class Initialized
INFO - 2016-08-24 07:57:54 --> Config Class Initialized
INFO - 2016-08-24 07:57:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:54 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:54 --> URI Class Initialized
INFO - 2016-08-24 07:57:54 --> Router Class Initialized
INFO - 2016-08-24 07:57:54 --> Output Class Initialized
INFO - 2016-08-24 07:57:54 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:54 --> Input Class Initialized
INFO - 2016-08-24 07:57:54 --> Language Class Initialized
INFO - 2016-08-24 07:57:54 --> Loader Class Initialized
INFO - 2016-08-24 07:57:54 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:55 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:55 --> Email Class Initialized
INFO - 2016-08-24 07:57:55 --> Controller Class Initialized
INFO - 2016-08-24 07:57:55 --> Model Class Initialized
INFO - 2016-08-24 07:57:55 --> Config Class Initialized
INFO - 2016-08-24 07:57:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:55 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:55 --> URI Class Initialized
INFO - 2016-08-24 07:57:55 --> Router Class Initialized
INFO - 2016-08-24 07:57:55 --> Output Class Initialized
INFO - 2016-08-24 07:57:55 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:55 --> Input Class Initialized
INFO - 2016-08-24 07:57:55 --> Language Class Initialized
INFO - 2016-08-24 07:57:55 --> Loader Class Initialized
INFO - 2016-08-24 07:57:55 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:55 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:55 --> Email Class Initialized
INFO - 2016-08-24 07:57:55 --> Controller Class Initialized
INFO - 2016-08-24 07:57:55 --> Model Class Initialized
INFO - 2016-08-24 07:57:55 --> Config Class Initialized
INFO - 2016-08-24 07:57:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:55 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:55 --> URI Class Initialized
INFO - 2016-08-24 07:57:55 --> Router Class Initialized
INFO - 2016-08-24 07:57:55 --> Output Class Initialized
INFO - 2016-08-24 07:57:55 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:55 --> Input Class Initialized
INFO - 2016-08-24 07:57:55 --> Language Class Initialized
INFO - 2016-08-24 07:57:55 --> Loader Class Initialized
INFO - 2016-08-24 07:57:55 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:55 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:55 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:55 --> Email Class Initialized
INFO - 2016-08-24 07:57:55 --> Controller Class Initialized
INFO - 2016-08-24 07:57:55 --> Model Class Initialized
INFO - 2016-08-24 07:57:55 --> Config Class Initialized
INFO - 2016-08-24 07:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:56 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:56 --> URI Class Initialized
INFO - 2016-08-24 07:57:56 --> Router Class Initialized
INFO - 2016-08-24 07:57:56 --> Output Class Initialized
INFO - 2016-08-24 07:57:56 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:56 --> Input Class Initialized
INFO - 2016-08-24 07:57:56 --> Language Class Initialized
INFO - 2016-08-24 07:57:56 --> Loader Class Initialized
INFO - 2016-08-24 07:57:56 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:56 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:56 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:56 --> Email Class Initialized
INFO - 2016-08-24 07:57:56 --> Controller Class Initialized
INFO - 2016-08-24 07:57:56 --> Model Class Initialized
INFO - 2016-08-24 07:57:56 --> Config Class Initialized
INFO - 2016-08-24 07:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:56 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:56 --> URI Class Initialized
INFO - 2016-08-24 07:57:56 --> Router Class Initialized
INFO - 2016-08-24 07:57:56 --> Output Class Initialized
INFO - 2016-08-24 07:57:56 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:56 --> Input Class Initialized
INFO - 2016-08-24 07:57:56 --> Language Class Initialized
INFO - 2016-08-24 07:57:56 --> Loader Class Initialized
INFO - 2016-08-24 07:57:56 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:56 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:56 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:56 --> Email Class Initialized
INFO - 2016-08-24 07:57:56 --> Controller Class Initialized
INFO - 2016-08-24 07:57:56 --> Model Class Initialized
INFO - 2016-08-24 07:57:56 --> Config Class Initialized
INFO - 2016-08-24 07:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 07:57:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 07:57:56 --> Utf8 Class Initialized
INFO - 2016-08-24 07:57:56 --> URI Class Initialized
INFO - 2016-08-24 07:57:56 --> Router Class Initialized
INFO - 2016-08-24 07:57:56 --> Output Class Initialized
INFO - 2016-08-24 07:57:56 --> Security Class Initialized
DEBUG - 2016-08-24 07:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 07:57:56 --> Input Class Initialized
INFO - 2016-08-24 07:57:56 --> Language Class Initialized
INFO - 2016-08-24 07:57:56 --> Loader Class Initialized
INFO - 2016-08-24 07:57:56 --> Helper loaded: url_helper
INFO - 2016-08-24 07:57:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 07:57:57 --> Helper loaded: html_helper
INFO - 2016-08-24 07:57:57 --> Helper loaded: form_helper
INFO - 2016-08-24 07:57:57 --> Helper loaded: file_helper
INFO - 2016-08-24 07:57:57 --> Helper loaded: myemail_helper
INFO - 2016-08-24 07:57:57 --> Database Driver Class Initialized
INFO - 2016-08-24 07:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 07:57:57 --> Form Validation Class Initialized
INFO - 2016-08-24 07:57:57 --> Email Class Initialized
INFO - 2016-08-24 07:57:57 --> Controller Class Initialized
INFO - 2016-08-24 07:57:57 --> Model Class Initialized
INFO - 2016-08-24 08:03:52 --> Config Class Initialized
INFO - 2016-08-24 08:03:52 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:03:52 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:03:52 --> Utf8 Class Initialized
INFO - 2016-08-24 08:03:52 --> URI Class Initialized
INFO - 2016-08-24 08:03:52 --> Router Class Initialized
INFO - 2016-08-24 08:03:52 --> Output Class Initialized
INFO - 2016-08-24 08:03:52 --> Security Class Initialized
DEBUG - 2016-08-24 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:03:53 --> Input Class Initialized
INFO - 2016-08-24 08:03:53 --> Language Class Initialized
INFO - 2016-08-24 08:03:53 --> Loader Class Initialized
INFO - 2016-08-24 08:03:53 --> Helper loaded: url_helper
INFO - 2016-08-24 08:03:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:03:53 --> Helper loaded: html_helper
INFO - 2016-08-24 08:03:53 --> Helper loaded: form_helper
INFO - 2016-08-24 08:03:53 --> Helper loaded: file_helper
INFO - 2016-08-24 08:03:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:03:53 --> Database Driver Class Initialized
INFO - 2016-08-24 08:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:03:53 --> Form Validation Class Initialized
INFO - 2016-08-24 08:03:53 --> Email Class Initialized
INFO - 2016-08-24 08:03:53 --> Controller Class Initialized
INFO - 2016-08-24 08:03:53 --> Model Class Initialized
INFO - 2016-08-24 08:03:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:03:53 --> Final output sent to browser
DEBUG - 2016-08-24 08:03:53 --> Total execution time: 0.4918
INFO - 2016-08-24 08:03:58 --> Config Class Initialized
INFO - 2016-08-24 08:03:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:03:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:03:58 --> Utf8 Class Initialized
INFO - 2016-08-24 08:03:58 --> URI Class Initialized
INFO - 2016-08-24 08:03:58 --> Router Class Initialized
INFO - 2016-08-24 08:03:58 --> Output Class Initialized
INFO - 2016-08-24 08:03:58 --> Security Class Initialized
DEBUG - 2016-08-24 08:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:03:58 --> Input Class Initialized
INFO - 2016-08-24 08:03:58 --> Language Class Initialized
INFO - 2016-08-24 08:03:58 --> Loader Class Initialized
INFO - 2016-08-24 08:03:58 --> Helper loaded: url_helper
INFO - 2016-08-24 08:03:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:03:58 --> Helper loaded: html_helper
INFO - 2016-08-24 08:03:58 --> Helper loaded: form_helper
INFO - 2016-08-24 08:03:58 --> Helper loaded: file_helper
INFO - 2016-08-24 08:03:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:03:58 --> Database Driver Class Initialized
INFO - 2016-08-24 08:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:03:58 --> Form Validation Class Initialized
INFO - 2016-08-24 08:03:58 --> Email Class Initialized
INFO - 2016-08-24 08:03:58 --> Controller Class Initialized
INFO - 2016-08-24 08:03:58 --> Model Class Initialized
ERROR - 2016-08-24 08:03:59 --> Severity: Notice --> Undefined property: Connection::$user D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 200
ERROR - 2016-08-24 08:03:59 --> Severity: Error --> Call to a member function checkUser() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 200
INFO - 2016-08-24 08:33:00 --> Config Class Initialized
INFO - 2016-08-24 08:33:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:00 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:00 --> URI Class Initialized
INFO - 2016-08-24 08:33:00 --> Router Class Initialized
INFO - 2016-08-24 08:33:00 --> Output Class Initialized
INFO - 2016-08-24 08:33:00 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:00 --> Input Class Initialized
INFO - 2016-08-24 08:33:00 --> Language Class Initialized
INFO - 2016-08-24 08:33:00 --> Loader Class Initialized
INFO - 2016-08-24 08:33:00 --> Helper loaded: url_helper
INFO - 2016-08-24 08:33:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:33:00 --> Helper loaded: html_helper
INFO - 2016-08-24 08:33:00 --> Helper loaded: form_helper
INFO - 2016-08-24 08:33:00 --> Helper loaded: file_helper
INFO - 2016-08-24 08:33:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:33:00 --> Database Driver Class Initialized
INFO - 2016-08-24 08:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:33:00 --> Form Validation Class Initialized
INFO - 2016-08-24 08:33:00 --> Email Class Initialized
INFO - 2016-08-24 08:33:00 --> Controller Class Initialized
INFO - 2016-08-24 08:33:00 --> Model Class Initialized
INFO - 2016-08-24 08:33:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:33:00 --> Final output sent to browser
DEBUG - 2016-08-24 08:33:01 --> Total execution time: 0.4982
INFO - 2016-08-24 08:33:01 --> Config Class Initialized
INFO - 2016-08-24 08:33:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:01 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:01 --> URI Class Initialized
INFO - 2016-08-24 08:33:01 --> Router Class Initialized
INFO - 2016-08-24 08:33:01 --> Output Class Initialized
INFO - 2016-08-24 08:33:01 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:01 --> Input Class Initialized
INFO - 2016-08-24 08:33:01 --> Language Class Initialized
ERROR - 2016-08-24 08:33:01 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:33:05 --> Config Class Initialized
INFO - 2016-08-24 08:33:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:05 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:05 --> URI Class Initialized
INFO - 2016-08-24 08:33:05 --> Router Class Initialized
INFO - 2016-08-24 08:33:05 --> Output Class Initialized
INFO - 2016-08-24 08:33:05 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:05 --> Input Class Initialized
INFO - 2016-08-24 08:33:05 --> Language Class Initialized
INFO - 2016-08-24 08:33:05 --> Loader Class Initialized
INFO - 2016-08-24 08:33:05 --> Helper loaded: url_helper
INFO - 2016-08-24 08:33:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:33:05 --> Helper loaded: html_helper
INFO - 2016-08-24 08:33:05 --> Helper loaded: form_helper
INFO - 2016-08-24 08:33:05 --> Helper loaded: file_helper
INFO - 2016-08-24 08:33:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:33:05 --> Database Driver Class Initialized
INFO - 2016-08-24 08:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:33:05 --> Form Validation Class Initialized
INFO - 2016-08-24 08:33:05 --> Email Class Initialized
INFO - 2016-08-24 08:33:05 --> Controller Class Initialized
INFO - 2016-08-24 08:33:05 --> Model Class Initialized
INFO - 2016-08-24 08:33:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:33:06 --> Final output sent to browser
DEBUG - 2016-08-24 08:33:06 --> Total execution time: 0.4264
INFO - 2016-08-24 08:33:06 --> Config Class Initialized
INFO - 2016-08-24 08:33:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:06 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:06 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:06 --> URI Class Initialized
INFO - 2016-08-24 08:33:06 --> Router Class Initialized
INFO - 2016-08-24 08:33:06 --> Output Class Initialized
INFO - 2016-08-24 08:33:06 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:06 --> Input Class Initialized
INFO - 2016-08-24 08:33:06 --> Language Class Initialized
ERROR - 2016-08-24 08:33:06 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:33:33 --> Config Class Initialized
INFO - 2016-08-24 08:33:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:33 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:33 --> URI Class Initialized
INFO - 2016-08-24 08:33:33 --> Router Class Initialized
INFO - 2016-08-24 08:33:33 --> Output Class Initialized
INFO - 2016-08-24 08:33:33 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:34 --> Input Class Initialized
INFO - 2016-08-24 08:33:34 --> Language Class Initialized
INFO - 2016-08-24 08:33:34 --> Loader Class Initialized
INFO - 2016-08-24 08:33:34 --> Helper loaded: url_helper
INFO - 2016-08-24 08:33:34 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:33:34 --> Helper loaded: html_helper
INFO - 2016-08-24 08:33:34 --> Helper loaded: form_helper
INFO - 2016-08-24 08:33:34 --> Helper loaded: file_helper
INFO - 2016-08-24 08:33:34 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:33:34 --> Database Driver Class Initialized
INFO - 2016-08-24 08:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:33:34 --> Form Validation Class Initialized
INFO - 2016-08-24 08:33:34 --> Email Class Initialized
INFO - 2016-08-24 08:33:34 --> Controller Class Initialized
INFO - 2016-08-24 08:33:34 --> Model Class Initialized
INFO - 2016-08-24 08:33:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:33:34 --> Final output sent to browser
DEBUG - 2016-08-24 08:33:34 --> Total execution time: 0.4429
INFO - 2016-08-24 08:33:34 --> Config Class Initialized
INFO - 2016-08-24 08:33:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:34 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:34 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:34 --> URI Class Initialized
INFO - 2016-08-24 08:33:34 --> Router Class Initialized
INFO - 2016-08-24 08:33:34 --> Output Class Initialized
INFO - 2016-08-24 08:33:34 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:34 --> Input Class Initialized
INFO - 2016-08-24 08:33:34 --> Language Class Initialized
ERROR - 2016-08-24 08:33:34 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:33:48 --> Config Class Initialized
INFO - 2016-08-24 08:33:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:48 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:48 --> URI Class Initialized
INFO - 2016-08-24 08:33:48 --> Router Class Initialized
INFO - 2016-08-24 08:33:48 --> Output Class Initialized
INFO - 2016-08-24 08:33:48 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:48 --> Input Class Initialized
INFO - 2016-08-24 08:33:48 --> Language Class Initialized
INFO - 2016-08-24 08:33:48 --> Loader Class Initialized
INFO - 2016-08-24 08:33:48 --> Helper loaded: url_helper
INFO - 2016-08-24 08:33:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:33:48 --> Helper loaded: html_helper
INFO - 2016-08-24 08:33:48 --> Helper loaded: form_helper
INFO - 2016-08-24 08:33:48 --> Helper loaded: file_helper
INFO - 2016-08-24 08:33:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:33:48 --> Database Driver Class Initialized
INFO - 2016-08-24 08:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:33:48 --> Form Validation Class Initialized
INFO - 2016-08-24 08:33:48 --> Email Class Initialized
INFO - 2016-08-24 08:33:48 --> Controller Class Initialized
INFO - 2016-08-24 08:33:48 --> Model Class Initialized
INFO - 2016-08-24 08:33:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:33:48 --> Final output sent to browser
DEBUG - 2016-08-24 08:33:48 --> Total execution time: 0.4352
INFO - 2016-08-24 08:33:49 --> Config Class Initialized
INFO - 2016-08-24 08:33:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:33:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:33:49 --> Utf8 Class Initialized
INFO - 2016-08-24 08:33:49 --> URI Class Initialized
INFO - 2016-08-24 08:33:49 --> Router Class Initialized
INFO - 2016-08-24 08:33:49 --> Output Class Initialized
INFO - 2016-08-24 08:33:49 --> Security Class Initialized
DEBUG - 2016-08-24 08:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:33:49 --> Input Class Initialized
INFO - 2016-08-24 08:33:49 --> Language Class Initialized
ERROR - 2016-08-24 08:33:49 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:35:34 --> Config Class Initialized
INFO - 2016-08-24 08:35:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:34 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:34 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:34 --> URI Class Initialized
INFO - 2016-08-24 08:35:34 --> Router Class Initialized
INFO - 2016-08-24 08:35:34 --> Output Class Initialized
INFO - 2016-08-24 08:35:34 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:34 --> Input Class Initialized
INFO - 2016-08-24 08:35:34 --> Language Class Initialized
INFO - 2016-08-24 08:35:34 --> Loader Class Initialized
INFO - 2016-08-24 08:35:34 --> Helper loaded: url_helper
INFO - 2016-08-24 08:35:34 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:35:34 --> Helper loaded: html_helper
INFO - 2016-08-24 08:35:34 --> Helper loaded: form_helper
INFO - 2016-08-24 08:35:34 --> Helper loaded: file_helper
INFO - 2016-08-24 08:35:34 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:35:34 --> Database Driver Class Initialized
INFO - 2016-08-24 08:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:35:34 --> Form Validation Class Initialized
INFO - 2016-08-24 08:35:34 --> Email Class Initialized
INFO - 2016-08-24 08:35:34 --> Controller Class Initialized
INFO - 2016-08-24 08:35:34 --> Model Class Initialized
INFO - 2016-08-24 08:35:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:35:34 --> Final output sent to browser
DEBUG - 2016-08-24 08:35:34 --> Total execution time: 0.4448
INFO - 2016-08-24 08:35:35 --> Config Class Initialized
INFO - 2016-08-24 08:35:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:35 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:35 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:35 --> URI Class Initialized
INFO - 2016-08-24 08:35:35 --> Router Class Initialized
INFO - 2016-08-24 08:35:35 --> Output Class Initialized
INFO - 2016-08-24 08:35:35 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:35 --> Input Class Initialized
INFO - 2016-08-24 08:35:35 --> Language Class Initialized
ERROR - 2016-08-24 08:35:35 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:35:42 --> Config Class Initialized
INFO - 2016-08-24 08:35:42 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:42 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:42 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:42 --> URI Class Initialized
INFO - 2016-08-24 08:35:42 --> Router Class Initialized
INFO - 2016-08-24 08:35:42 --> Output Class Initialized
INFO - 2016-08-24 08:35:42 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:42 --> Input Class Initialized
INFO - 2016-08-24 08:35:42 --> Language Class Initialized
INFO - 2016-08-24 08:35:42 --> Loader Class Initialized
INFO - 2016-08-24 08:35:42 --> Helper loaded: url_helper
INFO - 2016-08-24 08:35:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:35:42 --> Helper loaded: html_helper
INFO - 2016-08-24 08:35:42 --> Helper loaded: form_helper
INFO - 2016-08-24 08:35:42 --> Helper loaded: file_helper
INFO - 2016-08-24 08:35:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:35:42 --> Database Driver Class Initialized
INFO - 2016-08-24 08:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:35:42 --> Form Validation Class Initialized
INFO - 2016-08-24 08:35:42 --> Email Class Initialized
INFO - 2016-08-24 08:35:42 --> Controller Class Initialized
INFO - 2016-08-24 08:35:42 --> Model Class Initialized
INFO - 2016-08-24 08:35:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:35:42 --> Final output sent to browser
DEBUG - 2016-08-24 08:35:42 --> Total execution time: 0.4565
INFO - 2016-08-24 08:35:43 --> Config Class Initialized
INFO - 2016-08-24 08:35:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:43 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:43 --> URI Class Initialized
INFO - 2016-08-24 08:35:43 --> Router Class Initialized
INFO - 2016-08-24 08:35:43 --> Output Class Initialized
INFO - 2016-08-24 08:35:43 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:43 --> Input Class Initialized
INFO - 2016-08-24 08:35:43 --> Language Class Initialized
ERROR - 2016-08-24 08:35:43 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:35:49 --> Config Class Initialized
INFO - 2016-08-24 08:35:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:49 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:49 --> URI Class Initialized
DEBUG - 2016-08-24 08:35:49 --> No URI present. Default controller set.
INFO - 2016-08-24 08:35:49 --> Router Class Initialized
INFO - 2016-08-24 08:35:49 --> Output Class Initialized
INFO - 2016-08-24 08:35:49 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:49 --> Input Class Initialized
INFO - 2016-08-24 08:35:49 --> Language Class Initialized
INFO - 2016-08-24 08:35:49 --> Loader Class Initialized
INFO - 2016-08-24 08:35:49 --> Helper loaded: url_helper
INFO - 2016-08-24 08:35:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: html_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: form_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: file_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:35:50 --> Database Driver Class Initialized
INFO - 2016-08-24 08:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:35:50 --> Form Validation Class Initialized
INFO - 2016-08-24 08:35:50 --> Email Class Initialized
INFO - 2016-08-24 08:35:50 --> Controller Class Initialized
INFO - 2016-08-24 08:35:50 --> Config Class Initialized
INFO - 2016-08-24 08:35:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:50 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:50 --> URI Class Initialized
INFO - 2016-08-24 08:35:50 --> Router Class Initialized
INFO - 2016-08-24 08:35:50 --> Output Class Initialized
INFO - 2016-08-24 08:35:50 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:50 --> Input Class Initialized
INFO - 2016-08-24 08:35:50 --> Language Class Initialized
INFO - 2016-08-24 08:35:50 --> Loader Class Initialized
INFO - 2016-08-24 08:35:50 --> Helper loaded: url_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: html_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: form_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: file_helper
INFO - 2016-08-24 08:35:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:35:50 --> Database Driver Class Initialized
INFO - 2016-08-24 08:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:35:50 --> Form Validation Class Initialized
INFO - 2016-08-24 08:35:50 --> Email Class Initialized
INFO - 2016-08-24 08:35:50 --> Controller Class Initialized
INFO - 2016-08-24 08:35:50 --> Model Class Initialized
DEBUG - 2016-08-24 08:35:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 08:35:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 08:35:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 08:35:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 08:35:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 08:35:50 --> Final output sent to browser
DEBUG - 2016-08-24 08:35:50 --> Total execution time: 0.5185
INFO - 2016-08-24 08:35:54 --> Config Class Initialized
INFO - 2016-08-24 08:35:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:54 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:54 --> URI Class Initialized
INFO - 2016-08-24 08:35:54 --> Router Class Initialized
INFO - 2016-08-24 08:35:54 --> Output Class Initialized
INFO - 2016-08-24 08:35:54 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:54 --> Input Class Initialized
INFO - 2016-08-24 08:35:54 --> Language Class Initialized
INFO - 2016-08-24 08:35:54 --> Loader Class Initialized
INFO - 2016-08-24 08:35:54 --> Helper loaded: url_helper
INFO - 2016-08-24 08:35:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:35:54 --> Helper loaded: html_helper
INFO - 2016-08-24 08:35:54 --> Helper loaded: form_helper
INFO - 2016-08-24 08:35:54 --> Helper loaded: file_helper
INFO - 2016-08-24 08:35:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:35:54 --> Database Driver Class Initialized
INFO - 2016-08-24 08:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:35:54 --> Form Validation Class Initialized
INFO - 2016-08-24 08:35:54 --> Email Class Initialized
INFO - 2016-08-24 08:35:54 --> Controller Class Initialized
INFO - 2016-08-24 08:35:54 --> Model Class Initialized
INFO - 2016-08-24 08:35:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:35:54 --> Final output sent to browser
DEBUG - 2016-08-24 08:35:54 --> Total execution time: 0.4350
INFO - 2016-08-24 08:35:55 --> Config Class Initialized
INFO - 2016-08-24 08:35:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:35:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:35:55 --> Utf8 Class Initialized
INFO - 2016-08-24 08:35:55 --> URI Class Initialized
INFO - 2016-08-24 08:35:55 --> Router Class Initialized
INFO - 2016-08-24 08:35:55 --> Output Class Initialized
INFO - 2016-08-24 08:35:55 --> Security Class Initialized
DEBUG - 2016-08-24 08:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:35:55 --> Input Class Initialized
INFO - 2016-08-24 08:35:55 --> Language Class Initialized
ERROR - 2016-08-24 08:35:55 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:36:19 --> Config Class Initialized
INFO - 2016-08-24 08:36:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:36:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:36:20 --> Utf8 Class Initialized
INFO - 2016-08-24 08:36:20 --> URI Class Initialized
INFO - 2016-08-24 08:36:20 --> Router Class Initialized
INFO - 2016-08-24 08:36:20 --> Output Class Initialized
INFO - 2016-08-24 08:36:20 --> Security Class Initialized
DEBUG - 2016-08-24 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:36:20 --> Input Class Initialized
INFO - 2016-08-24 08:36:20 --> Language Class Initialized
INFO - 2016-08-24 08:36:20 --> Loader Class Initialized
INFO - 2016-08-24 08:36:20 --> Helper loaded: url_helper
INFO - 2016-08-24 08:36:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:36:20 --> Helper loaded: html_helper
INFO - 2016-08-24 08:36:20 --> Helper loaded: form_helper
INFO - 2016-08-24 08:36:20 --> Helper loaded: file_helper
INFO - 2016-08-24 08:36:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:36:20 --> Database Driver Class Initialized
INFO - 2016-08-24 08:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:36:20 --> Form Validation Class Initialized
INFO - 2016-08-24 08:36:20 --> Email Class Initialized
INFO - 2016-08-24 08:36:20 --> Controller Class Initialized
INFO - 2016-08-24 08:36:20 --> Model Class Initialized
INFO - 2016-08-24 08:36:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:36:20 --> Final output sent to browser
DEBUG - 2016-08-24 08:36:20 --> Total execution time: 0.4480
INFO - 2016-08-24 08:36:20 --> Config Class Initialized
INFO - 2016-08-24 08:36:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:36:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:36:20 --> Utf8 Class Initialized
INFO - 2016-08-24 08:36:20 --> URI Class Initialized
INFO - 2016-08-24 08:36:20 --> Router Class Initialized
INFO - 2016-08-24 08:36:20 --> Output Class Initialized
INFO - 2016-08-24 08:36:20 --> Security Class Initialized
DEBUG - 2016-08-24 08:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:36:21 --> Input Class Initialized
INFO - 2016-08-24 08:36:21 --> Language Class Initialized
ERROR - 2016-08-24 08:36:21 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:37:29 --> Config Class Initialized
INFO - 2016-08-24 08:37:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:37:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:37:29 --> Utf8 Class Initialized
INFO - 2016-08-24 08:37:29 --> URI Class Initialized
INFO - 2016-08-24 08:37:29 --> Router Class Initialized
INFO - 2016-08-24 08:37:29 --> Output Class Initialized
INFO - 2016-08-24 08:37:29 --> Security Class Initialized
DEBUG - 2016-08-24 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:37:29 --> Input Class Initialized
INFO - 2016-08-24 08:37:29 --> Language Class Initialized
INFO - 2016-08-24 08:37:29 --> Loader Class Initialized
INFO - 2016-08-24 08:37:29 --> Helper loaded: url_helper
INFO - 2016-08-24 08:37:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:37:29 --> Helper loaded: html_helper
INFO - 2016-08-24 08:37:29 --> Helper loaded: form_helper
INFO - 2016-08-24 08:37:29 --> Helper loaded: file_helper
INFO - 2016-08-24 08:37:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:37:29 --> Database Driver Class Initialized
INFO - 2016-08-24 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:37:29 --> Form Validation Class Initialized
INFO - 2016-08-24 08:37:29 --> Email Class Initialized
INFO - 2016-08-24 08:37:29 --> Controller Class Initialized
INFO - 2016-08-24 08:37:29 --> Model Class Initialized
INFO - 2016-08-24 08:37:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:37:29 --> Final output sent to browser
DEBUG - 2016-08-24 08:37:29 --> Total execution time: 0.4624
INFO - 2016-08-24 08:37:29 --> Config Class Initialized
INFO - 2016-08-24 08:37:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:37:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:37:29 --> Utf8 Class Initialized
INFO - 2016-08-24 08:37:29 --> URI Class Initialized
INFO - 2016-08-24 08:37:30 --> Router Class Initialized
INFO - 2016-08-24 08:37:30 --> Output Class Initialized
INFO - 2016-08-24 08:37:30 --> Security Class Initialized
DEBUG - 2016-08-24 08:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:37:30 --> Input Class Initialized
INFO - 2016-08-24 08:37:30 --> Language Class Initialized
ERROR - 2016-08-24 08:37:30 --> 404 Page Not Found: Assets/images
INFO - 2016-08-24 08:40:10 --> Config Class Initialized
INFO - 2016-08-24 08:40:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:40:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:40:10 --> Utf8 Class Initialized
INFO - 2016-08-24 08:40:10 --> URI Class Initialized
INFO - 2016-08-24 08:40:10 --> Router Class Initialized
INFO - 2016-08-24 08:40:10 --> Output Class Initialized
INFO - 2016-08-24 08:40:10 --> Security Class Initialized
DEBUG - 2016-08-24 08:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:40:10 --> Input Class Initialized
INFO - 2016-08-24 08:40:10 --> Language Class Initialized
INFO - 2016-08-24 08:40:10 --> Loader Class Initialized
INFO - 2016-08-24 08:40:10 --> Helper loaded: url_helper
INFO - 2016-08-24 08:40:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:40:10 --> Helper loaded: html_helper
INFO - 2016-08-24 08:40:10 --> Helper loaded: form_helper
INFO - 2016-08-24 08:40:10 --> Helper loaded: file_helper
INFO - 2016-08-24 08:40:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:40:10 --> Database Driver Class Initialized
INFO - 2016-08-24 08:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:40:10 --> Form Validation Class Initialized
INFO - 2016-08-24 08:40:10 --> Email Class Initialized
INFO - 2016-08-24 08:40:10 --> Controller Class Initialized
INFO - 2016-08-24 08:40:10 --> Model Class Initialized
INFO - 2016-08-24 08:40:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-24 08:40:11 --> Final output sent to browser
DEBUG - 2016-08-24 08:40:11 --> Total execution time: 1.3639
INFO - 2016-08-24 08:40:14 --> Config Class Initialized
INFO - 2016-08-24 08:40:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:40:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:40:14 --> Utf8 Class Initialized
INFO - 2016-08-24 08:40:14 --> URI Class Initialized
DEBUG - 2016-08-24 08:40:14 --> No URI present. Default controller set.
INFO - 2016-08-24 08:40:14 --> Router Class Initialized
INFO - 2016-08-24 08:40:14 --> Output Class Initialized
INFO - 2016-08-24 08:40:14 --> Security Class Initialized
DEBUG - 2016-08-24 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:40:14 --> Input Class Initialized
INFO - 2016-08-24 08:40:14 --> Language Class Initialized
INFO - 2016-08-24 08:40:14 --> Loader Class Initialized
INFO - 2016-08-24 08:40:14 --> Helper loaded: url_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: html_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: form_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: file_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:40:14 --> Database Driver Class Initialized
INFO - 2016-08-24 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:40:14 --> Form Validation Class Initialized
INFO - 2016-08-24 08:40:14 --> Email Class Initialized
INFO - 2016-08-24 08:40:14 --> Controller Class Initialized
INFO - 2016-08-24 08:40:14 --> Config Class Initialized
INFO - 2016-08-24 08:40:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:40:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:40:14 --> Utf8 Class Initialized
INFO - 2016-08-24 08:40:14 --> URI Class Initialized
INFO - 2016-08-24 08:40:14 --> Router Class Initialized
INFO - 2016-08-24 08:40:14 --> Output Class Initialized
INFO - 2016-08-24 08:40:14 --> Security Class Initialized
DEBUG - 2016-08-24 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:40:14 --> Input Class Initialized
INFO - 2016-08-24 08:40:14 --> Language Class Initialized
INFO - 2016-08-24 08:40:14 --> Loader Class Initialized
INFO - 2016-08-24 08:40:14 --> Helper loaded: url_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: html_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: form_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: file_helper
INFO - 2016-08-24 08:40:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:40:14 --> Database Driver Class Initialized
INFO - 2016-08-24 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:40:14 --> Form Validation Class Initialized
INFO - 2016-08-24 08:40:14 --> Email Class Initialized
INFO - 2016-08-24 08:40:14 --> Controller Class Initialized
INFO - 2016-08-24 08:40:14 --> Model Class Initialized
DEBUG - 2016-08-24 08:40:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 08:40:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 08:40:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 08:40:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 08:40:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 08:40:15 --> Final output sent to browser
DEBUG - 2016-08-24 08:40:15 --> Total execution time: 0.4912
INFO - 2016-08-24 08:40:17 --> Config Class Initialized
INFO - 2016-08-24 08:40:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:40:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:40:17 --> Utf8 Class Initialized
INFO - 2016-08-24 08:40:17 --> URI Class Initialized
INFO - 2016-08-24 08:40:17 --> Router Class Initialized
INFO - 2016-08-24 08:40:17 --> Output Class Initialized
INFO - 2016-08-24 08:40:17 --> Security Class Initialized
DEBUG - 2016-08-24 08:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:40:17 --> Input Class Initialized
INFO - 2016-08-24 08:40:17 --> Language Class Initialized
INFO - 2016-08-24 08:40:17 --> Loader Class Initialized
INFO - 2016-08-24 08:40:17 --> Helper loaded: url_helper
INFO - 2016-08-24 08:40:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:40:17 --> Helper loaded: html_helper
INFO - 2016-08-24 08:40:17 --> Helper loaded: form_helper
INFO - 2016-08-24 08:40:17 --> Helper loaded: file_helper
INFO - 2016-08-24 08:40:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:40:17 --> Database Driver Class Initialized
INFO - 2016-08-24 08:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:40:17 --> Form Validation Class Initialized
INFO - 2016-08-24 08:40:17 --> Email Class Initialized
INFO - 2016-08-24 08:40:17 --> Controller Class Initialized
INFO - 2016-08-24 08:40:17 --> Model Class Initialized
INFO - 2016-08-24 08:40:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:40:17 --> Final output sent to browser
DEBUG - 2016-08-24 08:40:17 --> Total execution time: 0.4593
INFO - 2016-08-24 08:40:21 --> Config Class Initialized
INFO - 2016-08-24 08:40:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:40:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:40:21 --> Utf8 Class Initialized
INFO - 2016-08-24 08:40:21 --> URI Class Initialized
INFO - 2016-08-24 08:40:21 --> Router Class Initialized
INFO - 2016-08-24 08:40:21 --> Output Class Initialized
INFO - 2016-08-24 08:40:21 --> Security Class Initialized
DEBUG - 2016-08-24 08:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:40:21 --> Input Class Initialized
INFO - 2016-08-24 08:40:21 --> Language Class Initialized
INFO - 2016-08-24 08:40:21 --> Loader Class Initialized
INFO - 2016-08-24 08:40:21 --> Helper loaded: url_helper
INFO - 2016-08-24 08:40:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:40:21 --> Helper loaded: html_helper
INFO - 2016-08-24 08:40:21 --> Helper loaded: form_helper
INFO - 2016-08-24 08:40:21 --> Helper loaded: file_helper
INFO - 2016-08-24 08:40:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:40:21 --> Database Driver Class Initialized
INFO - 2016-08-24 08:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:40:21 --> Form Validation Class Initialized
INFO - 2016-08-24 08:40:21 --> Email Class Initialized
INFO - 2016-08-24 08:40:21 --> Controller Class Initialized
INFO - 2016-08-24 08:40:21 --> Model Class Initialized
INFO - 2016-08-24 08:43:03 --> Config Class Initialized
INFO - 2016-08-24 08:43:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:43:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:43:03 --> Utf8 Class Initialized
INFO - 2016-08-24 08:43:03 --> URI Class Initialized
INFO - 2016-08-24 08:43:03 --> Router Class Initialized
INFO - 2016-08-24 08:43:03 --> Output Class Initialized
INFO - 2016-08-24 08:43:03 --> Security Class Initialized
DEBUG - 2016-08-24 08:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:43:03 --> Input Class Initialized
INFO - 2016-08-24 08:43:03 --> Language Class Initialized
INFO - 2016-08-24 08:43:03 --> Loader Class Initialized
INFO - 2016-08-24 08:43:03 --> Helper loaded: url_helper
INFO - 2016-08-24 08:43:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:43:03 --> Helper loaded: html_helper
INFO - 2016-08-24 08:43:03 --> Helper loaded: form_helper
INFO - 2016-08-24 08:43:03 --> Helper loaded: file_helper
INFO - 2016-08-24 08:43:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:43:03 --> Database Driver Class Initialized
INFO - 2016-08-24 08:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:43:03 --> Form Validation Class Initialized
INFO - 2016-08-24 08:43:03 --> Email Class Initialized
INFO - 2016-08-24 08:43:03 --> Controller Class Initialized
INFO - 2016-08-24 08:43:03 --> Model Class Initialized
ERROR - 2016-08-24 08:43:04 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 08:43:58 --> Config Class Initialized
INFO - 2016-08-24 08:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:43:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:43:58 --> Utf8 Class Initialized
INFO - 2016-08-24 08:43:58 --> URI Class Initialized
DEBUG - 2016-08-24 08:43:58 --> No URI present. Default controller set.
INFO - 2016-08-24 08:43:58 --> Router Class Initialized
INFO - 2016-08-24 08:43:58 --> Output Class Initialized
INFO - 2016-08-24 08:43:58 --> Security Class Initialized
DEBUG - 2016-08-24 08:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:43:58 --> Input Class Initialized
INFO - 2016-08-24 08:43:58 --> Language Class Initialized
INFO - 2016-08-24 08:43:58 --> Loader Class Initialized
INFO - 2016-08-24 08:43:58 --> Helper loaded: url_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: html_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: form_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: file_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:43:58 --> Database Driver Class Initialized
INFO - 2016-08-24 08:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:43:58 --> Form Validation Class Initialized
INFO - 2016-08-24 08:43:58 --> Email Class Initialized
INFO - 2016-08-24 08:43:58 --> Controller Class Initialized
INFO - 2016-08-24 08:43:58 --> Config Class Initialized
INFO - 2016-08-24 08:43:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:43:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:43:58 --> Utf8 Class Initialized
INFO - 2016-08-24 08:43:58 --> URI Class Initialized
INFO - 2016-08-24 08:43:58 --> Router Class Initialized
INFO - 2016-08-24 08:43:58 --> Output Class Initialized
INFO - 2016-08-24 08:43:58 --> Security Class Initialized
DEBUG - 2016-08-24 08:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:43:58 --> Input Class Initialized
INFO - 2016-08-24 08:43:58 --> Language Class Initialized
INFO - 2016-08-24 08:43:58 --> Loader Class Initialized
INFO - 2016-08-24 08:43:58 --> Helper loaded: url_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: html_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: form_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: file_helper
INFO - 2016-08-24 08:43:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:43:58 --> Database Driver Class Initialized
INFO - 2016-08-24 08:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:43:58 --> Form Validation Class Initialized
INFO - 2016-08-24 08:43:58 --> Email Class Initialized
INFO - 2016-08-24 08:43:58 --> Controller Class Initialized
INFO - 2016-08-24 08:43:58 --> Model Class Initialized
DEBUG - 2016-08-24 08:43:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 08:43:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 08:43:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 08:43:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 08:43:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 08:43:59 --> Final output sent to browser
DEBUG - 2016-08-24 08:43:59 --> Total execution time: 0.4824
INFO - 2016-08-24 08:44:15 --> Config Class Initialized
INFO - 2016-08-24 08:44:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:44:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:44:15 --> Utf8 Class Initialized
INFO - 2016-08-24 08:44:15 --> URI Class Initialized
INFO - 2016-08-24 08:44:15 --> Router Class Initialized
INFO - 2016-08-24 08:44:15 --> Output Class Initialized
INFO - 2016-08-24 08:44:15 --> Security Class Initialized
DEBUG - 2016-08-24 08:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:44:15 --> Input Class Initialized
INFO - 2016-08-24 08:44:15 --> Language Class Initialized
INFO - 2016-08-24 08:44:15 --> Loader Class Initialized
INFO - 2016-08-24 08:44:15 --> Helper loaded: url_helper
INFO - 2016-08-24 08:44:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:44:15 --> Helper loaded: html_helper
INFO - 2016-08-24 08:44:15 --> Helper loaded: form_helper
INFO - 2016-08-24 08:44:15 --> Helper loaded: file_helper
INFO - 2016-08-24 08:44:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:44:15 --> Database Driver Class Initialized
INFO - 2016-08-24 08:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:44:15 --> Form Validation Class Initialized
INFO - 2016-08-24 08:44:15 --> Email Class Initialized
INFO - 2016-08-24 08:44:15 --> Controller Class Initialized
INFO - 2016-08-24 08:44:15 --> Model Class Initialized
INFO - 2016-08-24 08:44:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:44:15 --> Final output sent to browser
DEBUG - 2016-08-24 08:44:15 --> Total execution time: 0.4454
INFO - 2016-08-24 08:44:20 --> Config Class Initialized
INFO - 2016-08-24 08:44:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:44:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:44:20 --> Utf8 Class Initialized
INFO - 2016-08-24 08:44:20 --> URI Class Initialized
INFO - 2016-08-24 08:44:20 --> Router Class Initialized
INFO - 2016-08-24 08:44:20 --> Output Class Initialized
INFO - 2016-08-24 08:44:20 --> Security Class Initialized
DEBUG - 2016-08-24 08:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:44:20 --> Input Class Initialized
INFO - 2016-08-24 08:44:20 --> Language Class Initialized
INFO - 2016-08-24 08:44:20 --> Loader Class Initialized
INFO - 2016-08-24 08:44:20 --> Helper loaded: url_helper
INFO - 2016-08-24 08:44:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:44:20 --> Helper loaded: html_helper
INFO - 2016-08-24 08:44:20 --> Helper loaded: form_helper
INFO - 2016-08-24 08:44:20 --> Helper loaded: file_helper
INFO - 2016-08-24 08:44:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:44:20 --> Database Driver Class Initialized
INFO - 2016-08-24 08:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:44:20 --> Form Validation Class Initialized
INFO - 2016-08-24 08:44:20 --> Email Class Initialized
INFO - 2016-08-24 08:44:20 --> Controller Class Initialized
INFO - 2016-08-24 08:44:20 --> Model Class Initialized
INFO - 2016-08-24 08:44:43 --> Config Class Initialized
INFO - 2016-08-24 08:44:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:44:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:44:43 --> Utf8 Class Initialized
INFO - 2016-08-24 08:44:43 --> URI Class Initialized
INFO - 2016-08-24 08:44:43 --> Router Class Initialized
INFO - 2016-08-24 08:44:43 --> Output Class Initialized
INFO - 2016-08-24 08:44:43 --> Security Class Initialized
DEBUG - 2016-08-24 08:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:44:43 --> Input Class Initialized
INFO - 2016-08-24 08:44:43 --> Language Class Initialized
INFO - 2016-08-24 08:44:44 --> Loader Class Initialized
INFO - 2016-08-24 08:44:44 --> Helper loaded: url_helper
INFO - 2016-08-24 08:44:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:44:44 --> Helper loaded: html_helper
INFO - 2016-08-24 08:44:44 --> Helper loaded: form_helper
INFO - 2016-08-24 08:44:44 --> Helper loaded: file_helper
INFO - 2016-08-24 08:44:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:44:44 --> Database Driver Class Initialized
INFO - 2016-08-24 08:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:44:44 --> Form Validation Class Initialized
INFO - 2016-08-24 08:44:44 --> Email Class Initialized
INFO - 2016-08-24 08:44:44 --> Controller Class Initialized
INFO - 2016-08-24 08:44:44 --> Model Class Initialized
ERROR - 2016-08-24 08:44:44 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 08:44:50 --> Config Class Initialized
INFO - 2016-08-24 08:44:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:44:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:44:51 --> Utf8 Class Initialized
INFO - 2016-08-24 08:44:51 --> URI Class Initialized
INFO - 2016-08-24 08:44:51 --> Router Class Initialized
INFO - 2016-08-24 08:44:51 --> Output Class Initialized
INFO - 2016-08-24 08:44:51 --> Security Class Initialized
DEBUG - 2016-08-24 08:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:44:51 --> Input Class Initialized
INFO - 2016-08-24 08:44:51 --> Language Class Initialized
INFO - 2016-08-24 08:44:51 --> Loader Class Initialized
INFO - 2016-08-24 08:44:51 --> Helper loaded: url_helper
INFO - 2016-08-24 08:44:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:44:51 --> Helper loaded: html_helper
INFO - 2016-08-24 08:44:51 --> Helper loaded: form_helper
INFO - 2016-08-24 08:44:51 --> Helper loaded: file_helper
INFO - 2016-08-24 08:44:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:44:51 --> Database Driver Class Initialized
INFO - 2016-08-24 08:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:44:51 --> Form Validation Class Initialized
INFO - 2016-08-24 08:44:51 --> Email Class Initialized
INFO - 2016-08-24 08:44:51 --> Controller Class Initialized
INFO - 2016-08-24 08:44:51 --> Model Class Initialized
ERROR - 2016-08-24 08:44:52 --> Severity: Notice --> Undefined property: Connection::$user D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 200
ERROR - 2016-08-24 08:44:52 --> Severity: Error --> Call to a member function checkUser() on a non-object D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 200
INFO - 2016-08-24 08:47:58 --> Config Class Initialized
INFO - 2016-08-24 08:47:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:47:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:47:58 --> Utf8 Class Initialized
INFO - 2016-08-24 08:47:58 --> URI Class Initialized
INFO - 2016-08-24 08:47:58 --> Router Class Initialized
INFO - 2016-08-24 08:47:58 --> Output Class Initialized
INFO - 2016-08-24 08:47:58 --> Security Class Initialized
DEBUG - 2016-08-24 08:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:47:58 --> Input Class Initialized
INFO - 2016-08-24 08:47:58 --> Language Class Initialized
INFO - 2016-08-24 08:47:58 --> Loader Class Initialized
INFO - 2016-08-24 08:47:58 --> Helper loaded: url_helper
INFO - 2016-08-24 08:47:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:47:58 --> Helper loaded: html_helper
INFO - 2016-08-24 08:47:58 --> Helper loaded: form_helper
INFO - 2016-08-24 08:47:58 --> Helper loaded: file_helper
INFO - 2016-08-24 08:47:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:47:59 --> Database Driver Class Initialized
INFO - 2016-08-24 08:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:47:59 --> Form Validation Class Initialized
INFO - 2016-08-24 08:47:59 --> Email Class Initialized
INFO - 2016-08-24 08:47:59 --> Controller Class Initialized
INFO - 2016-08-24 08:47:59 --> Model Class Initialized
ERROR - 2016-08-24 08:47:59 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 08:48:09 --> Config Class Initialized
INFO - 2016-08-24 08:48:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:48:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:48:09 --> Utf8 Class Initialized
INFO - 2016-08-24 08:48:09 --> URI Class Initialized
INFO - 2016-08-24 08:48:09 --> Router Class Initialized
INFO - 2016-08-24 08:48:09 --> Output Class Initialized
INFO - 2016-08-24 08:48:09 --> Security Class Initialized
DEBUG - 2016-08-24 08:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:48:09 --> Input Class Initialized
INFO - 2016-08-24 08:48:09 --> Language Class Initialized
INFO - 2016-08-24 08:48:09 --> Loader Class Initialized
INFO - 2016-08-24 08:48:09 --> Helper loaded: url_helper
INFO - 2016-08-24 08:48:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:48:09 --> Helper loaded: html_helper
INFO - 2016-08-24 08:48:09 --> Helper loaded: form_helper
INFO - 2016-08-24 08:48:09 --> Helper loaded: file_helper
INFO - 2016-08-24 08:48:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:48:09 --> Database Driver Class Initialized
INFO - 2016-08-24 08:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:48:09 --> Form Validation Class Initialized
INFO - 2016-08-24 08:48:09 --> Email Class Initialized
INFO - 2016-08-24 08:48:09 --> Controller Class Initialized
INFO - 2016-08-24 08:48:09 --> Model Class Initialized
ERROR - 2016-08-24 08:48:10 --> Severity: Error --> Call to undefined method Users_model::checkUser() D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 200
INFO - 2016-08-24 08:49:24 --> Config Class Initialized
INFO - 2016-08-24 08:49:24 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:49:24 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:49:24 --> Utf8 Class Initialized
INFO - 2016-08-24 08:49:24 --> URI Class Initialized
INFO - 2016-08-24 08:49:24 --> Router Class Initialized
INFO - 2016-08-24 08:49:25 --> Output Class Initialized
INFO - 2016-08-24 08:49:25 --> Security Class Initialized
DEBUG - 2016-08-24 08:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:49:25 --> Input Class Initialized
INFO - 2016-08-24 08:49:25 --> Language Class Initialized
INFO - 2016-08-24 08:49:25 --> Loader Class Initialized
INFO - 2016-08-24 08:49:25 --> Helper loaded: url_helper
INFO - 2016-08-24 08:49:25 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:49:25 --> Helper loaded: html_helper
INFO - 2016-08-24 08:49:25 --> Helper loaded: form_helper
INFO - 2016-08-24 08:49:25 --> Helper loaded: file_helper
INFO - 2016-08-24 08:49:25 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:49:25 --> Database Driver Class Initialized
INFO - 2016-08-24 08:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:49:25 --> Form Validation Class Initialized
INFO - 2016-08-24 08:49:25 --> Email Class Initialized
INFO - 2016-08-24 08:49:25 --> Controller Class Initialized
INFO - 2016-08-24 08:49:25 --> Model Class Initialized
INFO - 2016-08-24 08:51:02 --> Config Class Initialized
INFO - 2016-08-24 08:51:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:02 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:02 --> URI Class Initialized
INFO - 2016-08-24 08:51:02 --> Router Class Initialized
INFO - 2016-08-24 08:51:02 --> Output Class Initialized
INFO - 2016-08-24 08:51:02 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:02 --> Input Class Initialized
INFO - 2016-08-24 08:51:02 --> Language Class Initialized
INFO - 2016-08-24 08:51:02 --> Loader Class Initialized
INFO - 2016-08-24 08:51:02 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:02 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:02 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:02 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:02 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:02 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:02 --> Email Class Initialized
INFO - 2016-08-24 08:51:02 --> Controller Class Initialized
INFO - 2016-08-24 08:51:02 --> Model Class Initialized
ERROR - 2016-08-24 08:51:03 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 08:51:09 --> Config Class Initialized
INFO - 2016-08-24 08:51:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:09 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:09 --> URI Class Initialized
INFO - 2016-08-24 08:51:09 --> Router Class Initialized
INFO - 2016-08-24 08:51:09 --> Output Class Initialized
INFO - 2016-08-24 08:51:09 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:09 --> Input Class Initialized
INFO - 2016-08-24 08:51:09 --> Language Class Initialized
INFO - 2016-08-24 08:51:09 --> Loader Class Initialized
INFO - 2016-08-24 08:51:09 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:09 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:09 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:09 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:09 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:09 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:09 --> Email Class Initialized
INFO - 2016-08-24 08:51:09 --> Controller Class Initialized
INFO - 2016-08-24 08:51:09 --> Model Class Initialized
INFO - 2016-08-24 08:51:10 --> Config Class Initialized
INFO - 2016-08-24 08:51:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:10 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:10 --> URI Class Initialized
INFO - 2016-08-24 08:51:10 --> Router Class Initialized
INFO - 2016-08-24 08:51:10 --> Output Class Initialized
INFO - 2016-08-24 08:51:11 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:11 --> Input Class Initialized
INFO - 2016-08-24 08:51:11 --> Language Class Initialized
INFO - 2016-08-24 08:51:11 --> Loader Class Initialized
INFO - 2016-08-24 08:51:11 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:11 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:11 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:11 --> Email Class Initialized
INFO - 2016-08-24 08:51:11 --> Controller Class Initialized
INFO - 2016-08-24 08:51:11 --> Config Class Initialized
INFO - 2016-08-24 08:51:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:11 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:11 --> URI Class Initialized
INFO - 2016-08-24 08:51:11 --> Router Class Initialized
INFO - 2016-08-24 08:51:11 --> Output Class Initialized
INFO - 2016-08-24 08:51:11 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:11 --> Input Class Initialized
INFO - 2016-08-24 08:51:11 --> Language Class Initialized
INFO - 2016-08-24 08:51:11 --> Loader Class Initialized
INFO - 2016-08-24 08:51:11 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:11 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:11 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:11 --> Email Class Initialized
INFO - 2016-08-24 08:51:11 --> Controller Class Initialized
INFO - 2016-08-24 08:51:11 --> Model Class Initialized
DEBUG - 2016-08-24 08:51:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 08:51:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 08:51:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 08:51:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 08:51:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 08:51:11 --> Final output sent to browser
DEBUG - 2016-08-24 08:51:11 --> Total execution time: 0.4947
INFO - 2016-08-24 08:51:23 --> Config Class Initialized
INFO - 2016-08-24 08:51:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:23 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:23 --> URI Class Initialized
INFO - 2016-08-24 08:51:23 --> Router Class Initialized
INFO - 2016-08-24 08:51:23 --> Output Class Initialized
INFO - 2016-08-24 08:51:23 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:23 --> Input Class Initialized
INFO - 2016-08-24 08:51:23 --> Language Class Initialized
INFO - 2016-08-24 08:51:23 --> Loader Class Initialized
INFO - 2016-08-24 08:51:23 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:23 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:23 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:23 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:23 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:23 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:23 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:23 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:23 --> Email Class Initialized
INFO - 2016-08-24 08:51:23 --> Controller Class Initialized
INFO - 2016-08-24 08:51:23 --> Model Class Initialized
INFO - 2016-08-24 08:51:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:51:23 --> Final output sent to browser
DEBUG - 2016-08-24 08:51:23 --> Total execution time: 0.4993
INFO - 2016-08-24 08:51:27 --> Config Class Initialized
INFO - 2016-08-24 08:51:27 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:27 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:27 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:27 --> URI Class Initialized
INFO - 2016-08-24 08:51:27 --> Router Class Initialized
INFO - 2016-08-24 08:51:27 --> Output Class Initialized
INFO - 2016-08-24 08:51:27 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:27 --> Input Class Initialized
INFO - 2016-08-24 08:51:27 --> Language Class Initialized
INFO - 2016-08-24 08:51:27 --> Loader Class Initialized
INFO - 2016-08-24 08:51:27 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:27 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:27 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:27 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:27 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:27 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:27 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:27 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:27 --> Email Class Initialized
INFO - 2016-08-24 08:51:27 --> Controller Class Initialized
INFO - 2016-08-24 08:51:27 --> Model Class Initialized
INFO - 2016-08-24 08:51:28 --> Config Class Initialized
INFO - 2016-08-24 08:51:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:29 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:29 --> URI Class Initialized
INFO - 2016-08-24 08:51:29 --> Router Class Initialized
INFO - 2016-08-24 08:51:29 --> Output Class Initialized
INFO - 2016-08-24 08:51:29 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:29 --> Input Class Initialized
INFO - 2016-08-24 08:51:29 --> Language Class Initialized
INFO - 2016-08-24 08:51:29 --> Loader Class Initialized
INFO - 2016-08-24 08:51:29 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:29 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:29 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:29 --> Email Class Initialized
INFO - 2016-08-24 08:51:29 --> Controller Class Initialized
INFO - 2016-08-24 08:51:29 --> Config Class Initialized
INFO - 2016-08-24 08:51:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:51:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:51:29 --> Utf8 Class Initialized
INFO - 2016-08-24 08:51:29 --> URI Class Initialized
INFO - 2016-08-24 08:51:29 --> Router Class Initialized
INFO - 2016-08-24 08:51:29 --> Output Class Initialized
INFO - 2016-08-24 08:51:29 --> Security Class Initialized
DEBUG - 2016-08-24 08:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:51:29 --> Input Class Initialized
INFO - 2016-08-24 08:51:29 --> Language Class Initialized
INFO - 2016-08-24 08:51:29 --> Loader Class Initialized
INFO - 2016-08-24 08:51:29 --> Helper loaded: url_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: html_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: form_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: file_helper
INFO - 2016-08-24 08:51:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:51:29 --> Database Driver Class Initialized
INFO - 2016-08-24 08:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:51:29 --> Form Validation Class Initialized
INFO - 2016-08-24 08:51:29 --> Email Class Initialized
INFO - 2016-08-24 08:51:29 --> Controller Class Initialized
INFO - 2016-08-24 08:51:29 --> Model Class Initialized
DEBUG - 2016-08-24 08:51:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 08:51:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 08:51:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 08:51:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 08:51:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 08:51:29 --> Final output sent to browser
DEBUG - 2016-08-24 08:51:29 --> Total execution time: 0.5099
INFO - 2016-08-24 08:52:16 --> Config Class Initialized
INFO - 2016-08-24 08:52:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:52:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:52:17 --> Utf8 Class Initialized
INFO - 2016-08-24 08:52:17 --> URI Class Initialized
INFO - 2016-08-24 08:52:17 --> Router Class Initialized
INFO - 2016-08-24 08:52:17 --> Output Class Initialized
INFO - 2016-08-24 08:52:17 --> Security Class Initialized
DEBUG - 2016-08-24 08:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:52:17 --> Input Class Initialized
INFO - 2016-08-24 08:52:17 --> Language Class Initialized
INFO - 2016-08-24 08:52:17 --> Loader Class Initialized
INFO - 2016-08-24 08:52:17 --> Helper loaded: url_helper
INFO - 2016-08-24 08:52:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:52:17 --> Helper loaded: html_helper
INFO - 2016-08-24 08:52:17 --> Helper loaded: form_helper
INFO - 2016-08-24 08:52:17 --> Helper loaded: file_helper
INFO - 2016-08-24 08:52:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:52:17 --> Database Driver Class Initialized
INFO - 2016-08-24 08:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:52:17 --> Form Validation Class Initialized
INFO - 2016-08-24 08:52:17 --> Email Class Initialized
INFO - 2016-08-24 08:52:17 --> Controller Class Initialized
INFO - 2016-08-24 08:52:17 --> Model Class Initialized
INFO - 2016-08-24 08:52:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:52:17 --> Final output sent to browser
DEBUG - 2016-08-24 08:52:17 --> Total execution time: 0.4493
INFO - 2016-08-24 08:52:21 --> Config Class Initialized
INFO - 2016-08-24 08:52:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:52:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:52:21 --> Utf8 Class Initialized
INFO - 2016-08-24 08:52:21 --> URI Class Initialized
INFO - 2016-08-24 08:52:21 --> Router Class Initialized
INFO - 2016-08-24 08:52:21 --> Output Class Initialized
INFO - 2016-08-24 08:52:21 --> Security Class Initialized
DEBUG - 2016-08-24 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:52:21 --> Input Class Initialized
INFO - 2016-08-24 08:52:21 --> Language Class Initialized
INFO - 2016-08-24 08:52:21 --> Loader Class Initialized
INFO - 2016-08-24 08:52:21 --> Helper loaded: url_helper
INFO - 2016-08-24 08:52:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:52:21 --> Helper loaded: html_helper
INFO - 2016-08-24 08:52:21 --> Helper loaded: form_helper
INFO - 2016-08-24 08:52:21 --> Helper loaded: file_helper
INFO - 2016-08-24 08:52:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:52:21 --> Database Driver Class Initialized
INFO - 2016-08-24 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:52:21 --> Form Validation Class Initialized
INFO - 2016-08-24 08:52:21 --> Email Class Initialized
INFO - 2016-08-24 08:52:21 --> Controller Class Initialized
INFO - 2016-08-24 08:52:21 --> Model Class Initialized
INFO - 2016-08-24 08:52:23 --> Config Class Initialized
INFO - 2016-08-24 08:52:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:52:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:52:23 --> Utf8 Class Initialized
INFO - 2016-08-24 08:52:23 --> URI Class Initialized
INFO - 2016-08-24 08:52:23 --> Router Class Initialized
INFO - 2016-08-24 08:52:23 --> Output Class Initialized
INFO - 2016-08-24 08:52:23 --> Security Class Initialized
DEBUG - 2016-08-24 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:52:23 --> Input Class Initialized
INFO - 2016-08-24 08:52:23 --> Language Class Initialized
INFO - 2016-08-24 08:52:23 --> Loader Class Initialized
INFO - 2016-08-24 08:52:23 --> Helper loaded: url_helper
INFO - 2016-08-24 08:52:23 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:52:23 --> Helper loaded: html_helper
INFO - 2016-08-24 08:52:23 --> Helper loaded: form_helper
INFO - 2016-08-24 08:52:23 --> Helper loaded: file_helper
INFO - 2016-08-24 08:52:23 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:52:23 --> Database Driver Class Initialized
INFO - 2016-08-24 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:52:23 --> Form Validation Class Initialized
INFO - 2016-08-24 08:52:23 --> Email Class Initialized
INFO - 2016-08-24 08:52:23 --> Controller Class Initialized
INFO - 2016-08-24 08:52:23 --> Model Class Initialized
INFO - 2016-08-24 08:52:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:52:23 --> Final output sent to browser
DEBUG - 2016-08-24 08:52:23 --> Total execution time: 0.4581
INFO - 2016-08-24 08:52:27 --> Config Class Initialized
INFO - 2016-08-24 08:52:27 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:52:27 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:52:27 --> Utf8 Class Initialized
INFO - 2016-08-24 08:52:27 --> URI Class Initialized
INFO - 2016-08-24 08:52:27 --> Router Class Initialized
INFO - 2016-08-24 08:52:27 --> Output Class Initialized
INFO - 2016-08-24 08:52:27 --> Security Class Initialized
DEBUG - 2016-08-24 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:52:27 --> Input Class Initialized
INFO - 2016-08-24 08:52:27 --> Language Class Initialized
INFO - 2016-08-24 08:52:27 --> Loader Class Initialized
INFO - 2016-08-24 08:52:27 --> Helper loaded: url_helper
INFO - 2016-08-24 08:52:27 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:52:27 --> Helper loaded: html_helper
INFO - 2016-08-24 08:52:27 --> Helper loaded: form_helper
INFO - 2016-08-24 08:52:27 --> Helper loaded: file_helper
INFO - 2016-08-24 08:52:27 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:52:27 --> Database Driver Class Initialized
INFO - 2016-08-24 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:52:27 --> Form Validation Class Initialized
INFO - 2016-08-24 08:52:27 --> Email Class Initialized
INFO - 2016-08-24 08:52:27 --> Controller Class Initialized
INFO - 2016-08-24 08:52:27 --> Model Class Initialized
INFO - 2016-08-24 08:52:28 --> Config Class Initialized
INFO - 2016-08-24 08:52:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 08:52:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 08:52:28 --> Utf8 Class Initialized
INFO - 2016-08-24 08:52:28 --> URI Class Initialized
INFO - 2016-08-24 08:52:28 --> Router Class Initialized
INFO - 2016-08-24 08:52:29 --> Output Class Initialized
INFO - 2016-08-24 08:52:29 --> Security Class Initialized
DEBUG - 2016-08-24 08:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 08:52:29 --> Input Class Initialized
INFO - 2016-08-24 08:52:29 --> Language Class Initialized
INFO - 2016-08-24 08:52:29 --> Loader Class Initialized
INFO - 2016-08-24 08:52:29 --> Helper loaded: url_helper
INFO - 2016-08-24 08:52:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 08:52:29 --> Helper loaded: html_helper
INFO - 2016-08-24 08:52:29 --> Helper loaded: form_helper
INFO - 2016-08-24 08:52:29 --> Helper loaded: file_helper
INFO - 2016-08-24 08:52:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 08:52:29 --> Database Driver Class Initialized
INFO - 2016-08-24 08:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 08:52:29 --> Form Validation Class Initialized
INFO - 2016-08-24 08:52:29 --> Email Class Initialized
INFO - 2016-08-24 08:52:29 --> Controller Class Initialized
INFO - 2016-08-24 08:52:29 --> Model Class Initialized
INFO - 2016-08-24 08:52:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 08:52:29 --> Final output sent to browser
DEBUG - 2016-08-24 08:52:29 --> Total execution time: 0.4566
INFO - 2016-08-24 09:01:08 --> Config Class Initialized
INFO - 2016-08-24 09:01:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:01:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:01:09 --> Utf8 Class Initialized
INFO - 2016-08-24 09:01:09 --> URI Class Initialized
INFO - 2016-08-24 09:01:09 --> Router Class Initialized
INFO - 2016-08-24 09:01:09 --> Output Class Initialized
INFO - 2016-08-24 09:01:09 --> Security Class Initialized
DEBUG - 2016-08-24 09:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:01:09 --> Input Class Initialized
INFO - 2016-08-24 09:01:09 --> Language Class Initialized
INFO - 2016-08-24 09:01:09 --> Loader Class Initialized
INFO - 2016-08-24 09:01:09 --> Helper loaded: url_helper
INFO - 2016-08-24 09:01:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:01:09 --> Helper loaded: html_helper
INFO - 2016-08-24 09:01:09 --> Helper loaded: form_helper
INFO - 2016-08-24 09:01:09 --> Helper loaded: file_helper
INFO - 2016-08-24 09:01:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:01:09 --> Database Driver Class Initialized
INFO - 2016-08-24 09:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:01:09 --> Form Validation Class Initialized
INFO - 2016-08-24 09:01:09 --> Email Class Initialized
INFO - 2016-08-24 09:01:09 --> Controller Class Initialized
INFO - 2016-08-24 09:01:09 --> Model Class Initialized
DEBUG - 2016-08-24 09:01:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:01:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:01:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:01:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:01:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:01:09 --> Final output sent to browser
DEBUG - 2016-08-24 09:01:09 --> Total execution time: 0.6036
INFO - 2016-08-24 09:01:12 --> Config Class Initialized
INFO - 2016-08-24 09:01:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:01:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:01:12 --> Utf8 Class Initialized
INFO - 2016-08-24 09:01:12 --> URI Class Initialized
INFO - 2016-08-24 09:01:12 --> Router Class Initialized
INFO - 2016-08-24 09:01:12 --> Output Class Initialized
INFO - 2016-08-24 09:01:12 --> Security Class Initialized
DEBUG - 2016-08-24 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:01:12 --> Input Class Initialized
INFO - 2016-08-24 09:01:12 --> Language Class Initialized
INFO - 2016-08-24 09:01:12 --> Loader Class Initialized
INFO - 2016-08-24 09:01:12 --> Helper loaded: url_helper
INFO - 2016-08-24 09:01:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:01:12 --> Helper loaded: html_helper
INFO - 2016-08-24 09:01:12 --> Helper loaded: form_helper
INFO - 2016-08-24 09:01:12 --> Helper loaded: file_helper
INFO - 2016-08-24 09:01:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:01:13 --> Database Driver Class Initialized
INFO - 2016-08-24 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:01:13 --> Form Validation Class Initialized
INFO - 2016-08-24 09:01:13 --> Email Class Initialized
INFO - 2016-08-24 09:01:13 --> Controller Class Initialized
INFO - 2016-08-24 09:01:13 --> Model Class Initialized
INFO - 2016-08-24 09:01:17 --> Config Class Initialized
INFO - 2016-08-24 09:01:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:01:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:01:17 --> Utf8 Class Initialized
INFO - 2016-08-24 09:01:17 --> URI Class Initialized
INFO - 2016-08-24 09:01:17 --> Router Class Initialized
INFO - 2016-08-24 09:01:17 --> Output Class Initialized
INFO - 2016-08-24 09:01:17 --> Security Class Initialized
DEBUG - 2016-08-24 09:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:01:17 --> Input Class Initialized
INFO - 2016-08-24 09:01:17 --> Language Class Initialized
INFO - 2016-08-24 09:01:17 --> Loader Class Initialized
INFO - 2016-08-24 09:01:17 --> Helper loaded: url_helper
INFO - 2016-08-24 09:01:17 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:01:17 --> Helper loaded: html_helper
INFO - 2016-08-24 09:01:17 --> Helper loaded: form_helper
INFO - 2016-08-24 09:01:17 --> Helper loaded: file_helper
INFO - 2016-08-24 09:01:17 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:01:17 --> Database Driver Class Initialized
INFO - 2016-08-24 09:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:01:17 --> Form Validation Class Initialized
INFO - 2016-08-24 09:01:17 --> Email Class Initialized
INFO - 2016-08-24 09:01:17 --> Controller Class Initialized
INFO - 2016-08-24 09:01:17 --> Model Class Initialized
ERROR - 2016-08-24 09:01:17 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-08-24 09:02:58 --> Config Class Initialized
INFO - 2016-08-24 09:02:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:02:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:02:58 --> Utf8 Class Initialized
INFO - 2016-08-24 09:02:58 --> URI Class Initialized
INFO - 2016-08-24 09:02:58 --> Router Class Initialized
INFO - 2016-08-24 09:02:58 --> Output Class Initialized
INFO - 2016-08-24 09:02:58 --> Security Class Initialized
DEBUG - 2016-08-24 09:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:02:58 --> Input Class Initialized
INFO - 2016-08-24 09:02:58 --> Language Class Initialized
INFO - 2016-08-24 09:02:58 --> Loader Class Initialized
INFO - 2016-08-24 09:02:58 --> Helper loaded: url_helper
INFO - 2016-08-24 09:02:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:02:58 --> Helper loaded: html_helper
INFO - 2016-08-24 09:02:58 --> Helper loaded: form_helper
INFO - 2016-08-24 09:02:58 --> Helper loaded: file_helper
INFO - 2016-08-24 09:02:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:02:58 --> Database Driver Class Initialized
INFO - 2016-08-24 09:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:02:58 --> Form Validation Class Initialized
INFO - 2016-08-24 09:02:58 --> Email Class Initialized
INFO - 2016-08-24 09:02:58 --> Controller Class Initialized
INFO - 2016-08-24 09:02:58 --> Model Class Initialized
ERROR - 2016-08-24 09:02:58 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:03:44 --> Config Class Initialized
INFO - 2016-08-24 09:03:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:03:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:03:44 --> Utf8 Class Initialized
INFO - 2016-08-24 09:03:44 --> URI Class Initialized
INFO - 2016-08-24 09:03:44 --> Router Class Initialized
INFO - 2016-08-24 09:03:44 --> Output Class Initialized
INFO - 2016-08-24 09:03:44 --> Security Class Initialized
DEBUG - 2016-08-24 09:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:03:44 --> Input Class Initialized
INFO - 2016-08-24 09:03:44 --> Language Class Initialized
INFO - 2016-08-24 09:03:44 --> Loader Class Initialized
INFO - 2016-08-24 09:03:44 --> Helper loaded: url_helper
INFO - 2016-08-24 09:03:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:03:44 --> Helper loaded: html_helper
INFO - 2016-08-24 09:03:44 --> Helper loaded: form_helper
INFO - 2016-08-24 09:03:44 --> Helper loaded: file_helper
INFO - 2016-08-24 09:03:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:03:44 --> Database Driver Class Initialized
INFO - 2016-08-24 09:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:03:44 --> Form Validation Class Initialized
INFO - 2016-08-24 09:03:44 --> Email Class Initialized
INFO - 2016-08-24 09:03:45 --> Controller Class Initialized
INFO - 2016-08-24 09:03:45 --> Model Class Initialized
ERROR - 2016-08-24 09:03:45 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:07:08 --> Config Class Initialized
INFO - 2016-08-24 09:07:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:07:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:07:08 --> Utf8 Class Initialized
INFO - 2016-08-24 09:07:08 --> URI Class Initialized
INFO - 2016-08-24 09:07:08 --> Router Class Initialized
INFO - 2016-08-24 09:07:08 --> Output Class Initialized
INFO - 2016-08-24 09:07:08 --> Security Class Initialized
DEBUG - 2016-08-24 09:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:07:08 --> Input Class Initialized
INFO - 2016-08-24 09:07:08 --> Language Class Initialized
INFO - 2016-08-24 09:07:08 --> Loader Class Initialized
INFO - 2016-08-24 09:07:08 --> Helper loaded: url_helper
INFO - 2016-08-24 09:07:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:07:08 --> Helper loaded: html_helper
INFO - 2016-08-24 09:07:08 --> Helper loaded: form_helper
INFO - 2016-08-24 09:07:08 --> Helper loaded: file_helper
INFO - 2016-08-24 09:07:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:07:08 --> Database Driver Class Initialized
INFO - 2016-08-24 09:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:07:08 --> Form Validation Class Initialized
INFO - 2016-08-24 09:07:08 --> Email Class Initialized
INFO - 2016-08-24 09:07:08 --> Controller Class Initialized
INFO - 2016-08-24 09:07:08 --> Model Class Initialized
ERROR - 2016-08-24 09:07:09 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:07:51 --> Config Class Initialized
INFO - 2016-08-24 09:07:51 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:07:51 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:07:51 --> Utf8 Class Initialized
INFO - 2016-08-24 09:07:51 --> URI Class Initialized
INFO - 2016-08-24 09:07:51 --> Router Class Initialized
INFO - 2016-08-24 09:07:51 --> Output Class Initialized
INFO - 2016-08-24 09:07:51 --> Security Class Initialized
DEBUG - 2016-08-24 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:07:51 --> Input Class Initialized
INFO - 2016-08-24 09:07:51 --> Language Class Initialized
INFO - 2016-08-24 09:07:51 --> Loader Class Initialized
INFO - 2016-08-24 09:07:51 --> Helper loaded: url_helper
INFO - 2016-08-24 09:07:51 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:07:51 --> Helper loaded: html_helper
INFO - 2016-08-24 09:07:51 --> Helper loaded: form_helper
INFO - 2016-08-24 09:07:51 --> Helper loaded: file_helper
INFO - 2016-08-24 09:07:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:07:51 --> Database Driver Class Initialized
INFO - 2016-08-24 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:07:51 --> Form Validation Class Initialized
INFO - 2016-08-24 09:07:51 --> Email Class Initialized
INFO - 2016-08-24 09:07:51 --> Controller Class Initialized
INFO - 2016-08-24 09:07:51 --> Model Class Initialized
ERROR - 2016-08-24 09:07:52 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:08:04 --> Config Class Initialized
INFO - 2016-08-24 09:08:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:04 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:04 --> URI Class Initialized
INFO - 2016-08-24 09:08:04 --> Router Class Initialized
INFO - 2016-08-24 09:08:05 --> Output Class Initialized
INFO - 2016-08-24 09:08:05 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:05 --> Input Class Initialized
INFO - 2016-08-24 09:08:05 --> Language Class Initialized
INFO - 2016-08-24 09:08:05 --> Loader Class Initialized
INFO - 2016-08-24 09:08:05 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:05 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:05 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:05 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:05 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:05 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:05 --> Email Class Initialized
INFO - 2016-08-24 09:08:05 --> Controller Class Initialized
INFO - 2016-08-24 09:08:05 --> Model Class Initialized
ERROR - 2016-08-24 09:08:05 --> Severity: error --> Exception: Error creating resource: [message] fopen(): Unable to find the wrapper &quot;https&quot; - did you forget to enable it when you configured PHP?
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282
[message] fopen(https://accounts.google.com/o/oauth2/token): failed to open stream: Invalid argument
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282 D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Exception\RequestException.php 51
INFO - 2016-08-24 09:08:07 --> Config Class Initialized
INFO - 2016-08-24 09:08:07 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:07 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:07 --> URI Class Initialized
INFO - 2016-08-24 09:08:07 --> Router Class Initialized
INFO - 2016-08-24 09:08:07 --> Output Class Initialized
INFO - 2016-08-24 09:08:07 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:07 --> Input Class Initialized
INFO - 2016-08-24 09:08:07 --> Language Class Initialized
INFO - 2016-08-24 09:08:07 --> Loader Class Initialized
INFO - 2016-08-24 09:08:07 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:07 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:07 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:07 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:07 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:07 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:07 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:07 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:07 --> Email Class Initialized
INFO - 2016-08-24 09:08:07 --> Controller Class Initialized
INFO - 2016-08-24 09:08:07 --> Model Class Initialized
DEBUG - 2016-08-24 09:08:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:08:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:08:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:08:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:08:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:08:08 --> Final output sent to browser
DEBUG - 2016-08-24 09:08:08 --> Total execution time: 0.5232
INFO - 2016-08-24 09:08:16 --> Config Class Initialized
INFO - 2016-08-24 09:08:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:16 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:16 --> URI Class Initialized
INFO - 2016-08-24 09:08:16 --> Router Class Initialized
INFO - 2016-08-24 09:08:16 --> Output Class Initialized
INFO - 2016-08-24 09:08:16 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:16 --> Input Class Initialized
INFO - 2016-08-24 09:08:16 --> Language Class Initialized
INFO - 2016-08-24 09:08:16 --> Loader Class Initialized
INFO - 2016-08-24 09:08:16 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:16 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:16 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:16 --> Email Class Initialized
INFO - 2016-08-24 09:08:16 --> Controller Class Initialized
INFO - 2016-08-24 09:08:16 --> Model Class Initialized
DEBUG - 2016-08-24 09:08:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:08:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 09:08:16 --> Config Class Initialized
INFO - 2016-08-24 09:08:16 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:16 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:16 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:16 --> URI Class Initialized
INFO - 2016-08-24 09:08:16 --> Router Class Initialized
INFO - 2016-08-24 09:08:16 --> Output Class Initialized
INFO - 2016-08-24 09:08:16 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:16 --> Input Class Initialized
INFO - 2016-08-24 09:08:16 --> Language Class Initialized
INFO - 2016-08-24 09:08:16 --> Loader Class Initialized
INFO - 2016-08-24 09:08:16 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:17 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:17 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:17 --> Email Class Initialized
INFO - 2016-08-24 09:08:17 --> Controller Class Initialized
DEBUG - 2016-08-24 09:08:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 09:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:08:17 --> Model Class Initialized
INFO - 2016-08-24 09:08:17 --> Model Class Initialized
INFO - 2016-08-24 09:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 09:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 09:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:08:17 --> Final output sent to browser
DEBUG - 2016-08-24 09:08:17 --> Total execution time: 0.6139
INFO - 2016-08-24 09:08:22 --> Config Class Initialized
INFO - 2016-08-24 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:22 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:22 --> URI Class Initialized
INFO - 2016-08-24 09:08:22 --> Router Class Initialized
INFO - 2016-08-24 09:08:22 --> Output Class Initialized
INFO - 2016-08-24 09:08:22 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:22 --> Input Class Initialized
INFO - 2016-08-24 09:08:22 --> Language Class Initialized
INFO - 2016-08-24 09:08:22 --> Loader Class Initialized
INFO - 2016-08-24 09:08:22 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:22 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:22 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:22 --> Email Class Initialized
INFO - 2016-08-24 09:08:22 --> Controller Class Initialized
INFO - 2016-08-24 09:08:22 --> Model Class Initialized
INFO - 2016-08-24 09:08:22 --> Config Class Initialized
INFO - 2016-08-24 09:08:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:22 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:22 --> URI Class Initialized
INFO - 2016-08-24 09:08:22 --> Router Class Initialized
INFO - 2016-08-24 09:08:22 --> Output Class Initialized
INFO - 2016-08-24 09:08:22 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:22 --> Input Class Initialized
INFO - 2016-08-24 09:08:22 --> Language Class Initialized
INFO - 2016-08-24 09:08:22 --> Loader Class Initialized
INFO - 2016-08-24 09:08:22 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:22 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:22 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:22 --> Email Class Initialized
INFO - 2016-08-24 09:08:22 --> Controller Class Initialized
INFO - 2016-08-24 09:08:22 --> Model Class Initialized
DEBUG - 2016-08-24 09:08:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:08:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:08:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:08:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:08:23 --> Final output sent to browser
DEBUG - 2016-08-24 09:08:23 --> Total execution time: 0.5567
INFO - 2016-08-24 09:08:34 --> Config Class Initialized
INFO - 2016-08-24 09:08:34 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:34 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:35 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:35 --> URI Class Initialized
INFO - 2016-08-24 09:08:35 --> Router Class Initialized
INFO - 2016-08-24 09:08:35 --> Output Class Initialized
INFO - 2016-08-24 09:08:35 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:35 --> Input Class Initialized
INFO - 2016-08-24 09:08:35 --> Language Class Initialized
INFO - 2016-08-24 09:08:35 --> Loader Class Initialized
INFO - 2016-08-24 09:08:35 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:35 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:35 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:35 --> Email Class Initialized
INFO - 2016-08-24 09:08:35 --> Controller Class Initialized
INFO - 2016-08-24 09:08:35 --> Model Class Initialized
INFO - 2016-08-24 09:08:35 --> Config Class Initialized
INFO - 2016-08-24 09:08:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:08:35 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:08:35 --> Utf8 Class Initialized
INFO - 2016-08-24 09:08:35 --> URI Class Initialized
INFO - 2016-08-24 09:08:35 --> Router Class Initialized
INFO - 2016-08-24 09:08:35 --> Output Class Initialized
INFO - 2016-08-24 09:08:35 --> Security Class Initialized
DEBUG - 2016-08-24 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:08:35 --> Input Class Initialized
INFO - 2016-08-24 09:08:35 --> Language Class Initialized
INFO - 2016-08-24 09:08:35 --> Loader Class Initialized
INFO - 2016-08-24 09:08:35 --> Helper loaded: url_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: html_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: form_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: file_helper
INFO - 2016-08-24 09:08:35 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:08:35 --> Database Driver Class Initialized
INFO - 2016-08-24 09:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:08:36 --> Form Validation Class Initialized
INFO - 2016-08-24 09:08:36 --> Email Class Initialized
INFO - 2016-08-24 09:08:36 --> Controller Class Initialized
INFO - 2016-08-24 09:08:36 --> Model Class Initialized
ERROR - 2016-08-24 09:08:36 --> Severity: error --> Exception: Error creating resource: [message] fopen(): Unable to find the wrapper &quot;https&quot; - did you forget to enable it when you configured PHP?
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282
[message] fopen(https://accounts.google.com/o/oauth2/token): failed to open stream: Invalid argument
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282 D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Exception\RequestException.php 51
INFO - 2016-08-24 09:09:03 --> Config Class Initialized
INFO - 2016-08-24 09:09:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:03 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:03 --> URI Class Initialized
INFO - 2016-08-24 09:09:03 --> Router Class Initialized
INFO - 2016-08-24 09:09:03 --> Output Class Initialized
INFO - 2016-08-24 09:09:03 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:03 --> Input Class Initialized
INFO - 2016-08-24 09:09:03 --> Language Class Initialized
INFO - 2016-08-24 09:09:03 --> Loader Class Initialized
INFO - 2016-08-24 09:09:03 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:03 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:03 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:03 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:03 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:03 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:03 --> Email Class Initialized
INFO - 2016-08-24 09:09:03 --> Controller Class Initialized
INFO - 2016-08-24 09:09:03 --> Model Class Initialized
ERROR - 2016-08-24 09:09:03 --> Severity: error --> Exception: No system CA bundle could be found in any of the the common system locations.
PHP versions earlier than 5.6 are not properly configured to use the system's
CA bundle by default. In order to verify peer certificates, you will need to
supply the path on disk to a certificate bundle to the 'verify' request
option: http://docs.guzzlephp.org/en/latest/clients.html#verify. If you do not
need a specific certificate bundle, then Mozilla provides a commonly used CA
bundle which can be downloaded here (provided by the maintainer of cURL):
https://raw.githubusercontent.com/bagder/ca-bundle/master/ca-bundle.crt. Once
you have a CA bundle available on disk, you can set the 'openssl.cafile' PHP
ini setting to point to the path to the file, allowing you to omit the 'verify'
request option. See http://curl.haxx.se/docs/sslcerts.html for more
information. D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Exception\RequestException.php 51
INFO - 2016-08-24 09:09:06 --> Config Class Initialized
INFO - 2016-08-24 09:09:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:06 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:06 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:06 --> URI Class Initialized
INFO - 2016-08-24 09:09:06 --> Router Class Initialized
INFO - 2016-08-24 09:09:06 --> Output Class Initialized
INFO - 2016-08-24 09:09:06 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:06 --> Input Class Initialized
INFO - 2016-08-24 09:09:06 --> Language Class Initialized
INFO - 2016-08-24 09:09:06 --> Loader Class Initialized
INFO - 2016-08-24 09:09:06 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:06 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:06 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:06 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:06 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:06 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:06 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:07 --> Email Class Initialized
INFO - 2016-08-24 09:09:07 --> Controller Class Initialized
INFO - 2016-08-24 09:09:07 --> Model Class Initialized
DEBUG - 2016-08-24 09:09:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:09:07 --> Final output sent to browser
DEBUG - 2016-08-24 09:09:07 --> Total execution time: 0.5427
INFO - 2016-08-24 09:09:10 --> Config Class Initialized
INFO - 2016-08-24 09:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:10 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:10 --> URI Class Initialized
INFO - 2016-08-24 09:09:10 --> Router Class Initialized
INFO - 2016-08-24 09:09:10 --> Output Class Initialized
INFO - 2016-08-24 09:09:10 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:10 --> Input Class Initialized
INFO - 2016-08-24 09:09:10 --> Language Class Initialized
INFO - 2016-08-24 09:09:10 --> Loader Class Initialized
INFO - 2016-08-24 09:09:10 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:10 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:10 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:10 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:10 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:10 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:10 --> Email Class Initialized
INFO - 2016-08-24 09:09:10 --> Controller Class Initialized
INFO - 2016-08-24 09:09:10 --> Model Class Initialized
DEBUG - 2016-08-24 09:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:09:10 --> Final output sent to browser
DEBUG - 2016-08-24 09:09:10 --> Total execution time: 0.5696
INFO - 2016-08-24 09:09:15 --> Config Class Initialized
INFO - 2016-08-24 09:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:15 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:15 --> URI Class Initialized
INFO - 2016-08-24 09:09:15 --> Router Class Initialized
INFO - 2016-08-24 09:09:15 --> Output Class Initialized
INFO - 2016-08-24 09:09:15 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:15 --> Input Class Initialized
INFO - 2016-08-24 09:09:15 --> Language Class Initialized
INFO - 2016-08-24 09:09:15 --> Loader Class Initialized
INFO - 2016-08-24 09:09:15 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:15 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:15 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:15 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:15 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:15 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:15 --> Email Class Initialized
INFO - 2016-08-24 09:09:15 --> Controller Class Initialized
INFO - 2016-08-24 09:09:15 --> Model Class Initialized
INFO - 2016-08-24 09:09:15 --> Config Class Initialized
INFO - 2016-08-24 09:09:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:15 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:15 --> URI Class Initialized
INFO - 2016-08-24 09:09:15 --> Router Class Initialized
INFO - 2016-08-24 09:09:15 --> Output Class Initialized
INFO - 2016-08-24 09:09:15 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:15 --> Input Class Initialized
INFO - 2016-08-24 09:09:15 --> Language Class Initialized
INFO - 2016-08-24 09:09:15 --> Loader Class Initialized
INFO - 2016-08-24 09:09:15 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:16 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:16 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:16 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:16 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:16 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:16 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:16 --> Email Class Initialized
INFO - 2016-08-24 09:09:16 --> Controller Class Initialized
INFO - 2016-08-24 09:09:16 --> Model Class Initialized
ERROR - 2016-08-24 09:09:16 --> Severity: error --> Exception: No system CA bundle could be found in any of the the common system locations.
PHP versions earlier than 5.6 are not properly configured to use the system's
CA bundle by default. In order to verify peer certificates, you will need to
supply the path on disk to a certificate bundle to the 'verify' request
option: http://docs.guzzlephp.org/en/latest/clients.html#verify. If you do not
need a specific certificate bundle, then Mozilla provides a commonly used CA
bundle which can be downloaded here (provided by the maintainer of cURL):
https://raw.githubusercontent.com/bagder/ca-bundle/master/ca-bundle.crt. Once
you have a CA bundle available on disk, you can set the 'openssl.cafile' PHP
ini setting to point to the path to the file, allowing you to omit the 'verify'
request option. See http://curl.haxx.se/docs/sslcerts.html for more
information. D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Exception\RequestException.php 51
INFO - 2016-08-24 09:09:58 --> Config Class Initialized
INFO - 2016-08-24 09:09:58 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:09:58 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:09:58 --> Utf8 Class Initialized
INFO - 2016-08-24 09:09:58 --> URI Class Initialized
INFO - 2016-08-24 09:09:58 --> Router Class Initialized
INFO - 2016-08-24 09:09:58 --> Output Class Initialized
INFO - 2016-08-24 09:09:58 --> Security Class Initialized
DEBUG - 2016-08-24 09:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:09:58 --> Input Class Initialized
INFO - 2016-08-24 09:09:58 --> Language Class Initialized
INFO - 2016-08-24 09:09:58 --> Loader Class Initialized
INFO - 2016-08-24 09:09:58 --> Helper loaded: url_helper
INFO - 2016-08-24 09:09:58 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:09:58 --> Helper loaded: html_helper
INFO - 2016-08-24 09:09:58 --> Helper loaded: form_helper
INFO - 2016-08-24 09:09:58 --> Helper loaded: file_helper
INFO - 2016-08-24 09:09:58 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:09:58 --> Database Driver Class Initialized
INFO - 2016-08-24 09:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:09:58 --> Form Validation Class Initialized
INFO - 2016-08-24 09:09:58 --> Email Class Initialized
INFO - 2016-08-24 09:09:58 --> Controller Class Initialized
INFO - 2016-08-24 09:09:58 --> Model Class Initialized
DEBUG - 2016-08-24 09:09:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:09:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:09:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:09:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:09:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:09:58 --> Final output sent to browser
DEBUG - 2016-08-24 09:09:58 --> Total execution time: 0.5598
INFO - 2016-08-24 09:10:01 --> Config Class Initialized
INFO - 2016-08-24 09:10:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:10:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:10:01 --> Utf8 Class Initialized
INFO - 2016-08-24 09:10:01 --> URI Class Initialized
INFO - 2016-08-24 09:10:01 --> Router Class Initialized
INFO - 2016-08-24 09:10:01 --> Output Class Initialized
INFO - 2016-08-24 09:10:01 --> Security Class Initialized
DEBUG - 2016-08-24 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:10:01 --> Input Class Initialized
INFO - 2016-08-24 09:10:01 --> Language Class Initialized
INFO - 2016-08-24 09:10:01 --> Loader Class Initialized
INFO - 2016-08-24 09:10:01 --> Helper loaded: url_helper
INFO - 2016-08-24 09:10:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:10:01 --> Helper loaded: html_helper
INFO - 2016-08-24 09:10:01 --> Helper loaded: form_helper
INFO - 2016-08-24 09:10:01 --> Helper loaded: file_helper
INFO - 2016-08-24 09:10:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:10:01 --> Database Driver Class Initialized
INFO - 2016-08-24 09:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:10:01 --> Form Validation Class Initialized
INFO - 2016-08-24 09:10:01 --> Email Class Initialized
INFO - 2016-08-24 09:10:01 --> Controller Class Initialized
INFO - 2016-08-24 09:10:01 --> Model Class Initialized
INFO - 2016-08-24 09:10:01 --> Config Class Initialized
INFO - 2016-08-24 09:10:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:10:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:10:01 --> Utf8 Class Initialized
INFO - 2016-08-24 09:10:01 --> URI Class Initialized
INFO - 2016-08-24 09:10:01 --> Router Class Initialized
INFO - 2016-08-24 09:10:01 --> Output Class Initialized
INFO - 2016-08-24 09:10:01 --> Security Class Initialized
DEBUG - 2016-08-24 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:10:01 --> Input Class Initialized
INFO - 2016-08-24 09:10:02 --> Language Class Initialized
INFO - 2016-08-24 09:10:02 --> Loader Class Initialized
INFO - 2016-08-24 09:10:02 --> Helper loaded: url_helper
INFO - 2016-08-24 09:10:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:10:02 --> Helper loaded: html_helper
INFO - 2016-08-24 09:10:02 --> Helper loaded: form_helper
INFO - 2016-08-24 09:10:02 --> Helper loaded: file_helper
INFO - 2016-08-24 09:10:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:10:02 --> Database Driver Class Initialized
INFO - 2016-08-24 09:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:10:02 --> Form Validation Class Initialized
INFO - 2016-08-24 09:10:02 --> Email Class Initialized
INFO - 2016-08-24 09:10:02 --> Controller Class Initialized
INFO - 2016-08-24 09:10:02 --> Model Class Initialized
ERROR - 2016-08-24 09:10:02 --> Severity: error --> Exception: Error creating resource: [message] fopen(): Unable to find the wrapper &quot;https&quot; - did you forget to enable it when you configured PHP?
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282
[message] fopen(https://accounts.google.com/o/oauth2/token): failed to open stream: Invalid argument
[file] D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\StreamHandler.php
[line] 282 D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Exception\RequestException.php 51
INFO - 2016-08-24 09:10:15 --> Config Class Initialized
INFO - 2016-08-24 09:10:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:10:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:10:15 --> Utf8 Class Initialized
INFO - 2016-08-24 09:10:15 --> URI Class Initialized
INFO - 2016-08-24 09:10:15 --> Router Class Initialized
INFO - 2016-08-24 09:10:15 --> Output Class Initialized
INFO - 2016-08-24 09:10:15 --> Security Class Initialized
DEBUG - 2016-08-24 09:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:10:15 --> Input Class Initialized
INFO - 2016-08-24 09:10:15 --> Language Class Initialized
INFO - 2016-08-24 09:10:15 --> Loader Class Initialized
INFO - 2016-08-24 09:10:15 --> Helper loaded: url_helper
INFO - 2016-08-24 09:10:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:10:15 --> Helper loaded: html_helper
INFO - 2016-08-24 09:10:15 --> Helper loaded: form_helper
INFO - 2016-08-24 09:10:15 --> Helper loaded: file_helper
INFO - 2016-08-24 09:10:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:10:15 --> Database Driver Class Initialized
INFO - 2016-08-24 09:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:10:15 --> Form Validation Class Initialized
INFO - 2016-08-24 09:10:15 --> Email Class Initialized
INFO - 2016-08-24 09:10:15 --> Controller Class Initialized
INFO - 2016-08-24 09:10:15 --> Model Class Initialized
ERROR - 2016-08-24 09:10:17 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:17:47 --> Config Class Initialized
INFO - 2016-08-24 09:17:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:17:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:17:47 --> Utf8 Class Initialized
INFO - 2016-08-24 09:17:47 --> URI Class Initialized
INFO - 2016-08-24 09:17:47 --> Router Class Initialized
INFO - 2016-08-24 09:17:47 --> Output Class Initialized
INFO - 2016-08-24 09:17:47 --> Security Class Initialized
DEBUG - 2016-08-24 09:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:17:47 --> Input Class Initialized
INFO - 2016-08-24 09:17:47 --> Language Class Initialized
INFO - 2016-08-24 09:17:47 --> Loader Class Initialized
INFO - 2016-08-24 09:17:47 --> Helper loaded: url_helper
INFO - 2016-08-24 09:17:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:17:47 --> Helper loaded: html_helper
INFO - 2016-08-24 09:17:47 --> Helper loaded: form_helper
INFO - 2016-08-24 09:17:47 --> Helper loaded: file_helper
INFO - 2016-08-24 09:17:47 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:17:47 --> Database Driver Class Initialized
INFO - 2016-08-24 09:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:17:47 --> Form Validation Class Initialized
INFO - 2016-08-24 09:17:47 --> Email Class Initialized
INFO - 2016-08-24 09:17:47 --> Controller Class Initialized
INFO - 2016-08-24 09:17:47 --> Model Class Initialized
ERROR - 2016-08-24 09:17:48 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:18:06 --> Config Class Initialized
INFO - 2016-08-24 09:18:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:18:06 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:18:06 --> Utf8 Class Initialized
INFO - 2016-08-24 09:18:06 --> URI Class Initialized
INFO - 2016-08-24 09:18:06 --> Router Class Initialized
INFO - 2016-08-24 09:18:06 --> Output Class Initialized
INFO - 2016-08-24 09:18:06 --> Security Class Initialized
DEBUG - 2016-08-24 09:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:18:06 --> Input Class Initialized
INFO - 2016-08-24 09:18:06 --> Language Class Initialized
INFO - 2016-08-24 09:18:06 --> Loader Class Initialized
INFO - 2016-08-24 09:18:06 --> Helper loaded: url_helper
INFO - 2016-08-24 09:18:06 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:18:06 --> Helper loaded: html_helper
INFO - 2016-08-24 09:18:06 --> Helper loaded: form_helper
INFO - 2016-08-24 09:18:06 --> Helper loaded: file_helper
INFO - 2016-08-24 09:18:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:18:06 --> Database Driver Class Initialized
INFO - 2016-08-24 09:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:18:06 --> Form Validation Class Initialized
INFO - 2016-08-24 09:18:06 --> Email Class Initialized
INFO - 2016-08-24 09:18:06 --> Controller Class Initialized
INFO - 2016-08-24 09:18:06 --> Model Class Initialized
ERROR - 2016-08-24 09:18:07 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:18:09 --> Config Class Initialized
INFO - 2016-08-24 09:18:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:18:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:18:09 --> Utf8 Class Initialized
INFO - 2016-08-24 09:18:09 --> URI Class Initialized
INFO - 2016-08-24 09:18:09 --> Router Class Initialized
INFO - 2016-08-24 09:18:09 --> Output Class Initialized
INFO - 2016-08-24 09:18:09 --> Security Class Initialized
DEBUG - 2016-08-24 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:18:09 --> Input Class Initialized
INFO - 2016-08-24 09:18:09 --> Language Class Initialized
INFO - 2016-08-24 09:18:09 --> Loader Class Initialized
INFO - 2016-08-24 09:18:09 --> Helper loaded: url_helper
INFO - 2016-08-24 09:18:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:18:09 --> Helper loaded: html_helper
INFO - 2016-08-24 09:18:09 --> Helper loaded: form_helper
INFO - 2016-08-24 09:18:09 --> Helper loaded: file_helper
INFO - 2016-08-24 09:18:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:18:09 --> Database Driver Class Initialized
INFO - 2016-08-24 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:18:09 --> Form Validation Class Initialized
INFO - 2016-08-24 09:18:09 --> Email Class Initialized
INFO - 2016-08-24 09:18:09 --> Controller Class Initialized
INFO - 2016-08-24 09:18:10 --> Model Class Initialized
ERROR - 2016-08-24 09:18:10 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:19:29 --> Config Class Initialized
INFO - 2016-08-24 09:19:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:19:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:19:29 --> Utf8 Class Initialized
INFO - 2016-08-24 09:19:29 --> URI Class Initialized
INFO - 2016-08-24 09:19:29 --> Router Class Initialized
INFO - 2016-08-24 09:19:29 --> Output Class Initialized
INFO - 2016-08-24 09:19:29 --> Security Class Initialized
DEBUG - 2016-08-24 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:19:29 --> Input Class Initialized
INFO - 2016-08-24 09:19:29 --> Language Class Initialized
INFO - 2016-08-24 09:19:29 --> Loader Class Initialized
INFO - 2016-08-24 09:19:29 --> Helper loaded: url_helper
INFO - 2016-08-24 09:19:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:19:29 --> Helper loaded: html_helper
INFO - 2016-08-24 09:19:29 --> Helper loaded: form_helper
INFO - 2016-08-24 09:19:29 --> Helper loaded: file_helper
INFO - 2016-08-24 09:19:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:19:29 --> Database Driver Class Initialized
INFO - 2016-08-24 09:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:19:29 --> Form Validation Class Initialized
INFO - 2016-08-24 09:19:29 --> Email Class Initialized
INFO - 2016-08-24 09:19:29 --> Controller Class Initialized
INFO - 2016-08-24 09:19:30 --> Model Class Initialized
DEBUG - 2016-08-24 09:19:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:19:30 --> Final output sent to browser
DEBUG - 2016-08-24 09:19:30 --> Total execution time: 0.5196
INFO - 2016-08-24 09:19:45 --> Config Class Initialized
INFO - 2016-08-24 09:19:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:19:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:19:45 --> Utf8 Class Initialized
INFO - 2016-08-24 09:19:45 --> URI Class Initialized
INFO - 2016-08-24 09:19:45 --> Router Class Initialized
INFO - 2016-08-24 09:19:45 --> Output Class Initialized
INFO - 2016-08-24 09:19:45 --> Security Class Initialized
DEBUG - 2016-08-24 09:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:19:45 --> Input Class Initialized
INFO - 2016-08-24 09:19:45 --> Language Class Initialized
INFO - 2016-08-24 09:19:45 --> Loader Class Initialized
INFO - 2016-08-24 09:19:45 --> Helper loaded: url_helper
INFO - 2016-08-24 09:19:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:19:46 --> Helper loaded: html_helper
INFO - 2016-08-24 09:19:46 --> Helper loaded: form_helper
INFO - 2016-08-24 09:19:46 --> Helper loaded: file_helper
INFO - 2016-08-24 09:19:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:19:46 --> Database Driver Class Initialized
INFO - 2016-08-24 09:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:19:46 --> Form Validation Class Initialized
INFO - 2016-08-24 09:19:46 --> Email Class Initialized
INFO - 2016-08-24 09:19:46 --> Controller Class Initialized
INFO - 2016-08-24 09:19:46 --> Model Class Initialized
DEBUG - 2016-08-24 09:19:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:19:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:19:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:19:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:19:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:19:46 --> Final output sent to browser
DEBUG - 2016-08-24 09:19:46 --> Total execution time: 0.5306
INFO - 2016-08-24 09:19:48 --> Config Class Initialized
INFO - 2016-08-24 09:19:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:19:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:19:48 --> Utf8 Class Initialized
INFO - 2016-08-24 09:19:48 --> URI Class Initialized
INFO - 2016-08-24 09:19:48 --> Router Class Initialized
INFO - 2016-08-24 09:19:48 --> Output Class Initialized
INFO - 2016-08-24 09:19:49 --> Security Class Initialized
DEBUG - 2016-08-24 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:19:49 --> Input Class Initialized
INFO - 2016-08-24 09:19:49 --> Language Class Initialized
INFO - 2016-08-24 09:19:49 --> Loader Class Initialized
INFO - 2016-08-24 09:19:49 --> Helper loaded: url_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: html_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: form_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: file_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:19:49 --> Database Driver Class Initialized
INFO - 2016-08-24 09:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:19:49 --> Form Validation Class Initialized
INFO - 2016-08-24 09:19:49 --> Email Class Initialized
INFO - 2016-08-24 09:19:49 --> Controller Class Initialized
INFO - 2016-08-24 09:19:49 --> Model Class Initialized
INFO - 2016-08-24 09:19:49 --> Config Class Initialized
INFO - 2016-08-24 09:19:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:19:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:19:49 --> Utf8 Class Initialized
INFO - 2016-08-24 09:19:49 --> URI Class Initialized
INFO - 2016-08-24 09:19:49 --> Router Class Initialized
INFO - 2016-08-24 09:19:49 --> Output Class Initialized
INFO - 2016-08-24 09:19:49 --> Security Class Initialized
DEBUG - 2016-08-24 09:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:19:49 --> Input Class Initialized
INFO - 2016-08-24 09:19:49 --> Language Class Initialized
INFO - 2016-08-24 09:19:49 --> Loader Class Initialized
INFO - 2016-08-24 09:19:49 --> Helper loaded: url_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: html_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: form_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: file_helper
INFO - 2016-08-24 09:19:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:19:49 --> Database Driver Class Initialized
INFO - 2016-08-24 09:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:19:49 --> Form Validation Class Initialized
INFO - 2016-08-24 09:19:49 --> Email Class Initialized
INFO - 2016-08-24 09:19:49 --> Controller Class Initialized
INFO - 2016-08-24 09:19:50 --> Model Class Initialized
ERROR - 2016-08-24 09:19:50 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:21:46 --> Config Class Initialized
INFO - 2016-08-24 09:21:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:21:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:21:46 --> Utf8 Class Initialized
INFO - 2016-08-24 09:21:46 --> URI Class Initialized
DEBUG - 2016-08-24 09:21:46 --> No URI present. Default controller set.
INFO - 2016-08-24 09:21:46 --> Router Class Initialized
INFO - 2016-08-24 09:21:46 --> Output Class Initialized
INFO - 2016-08-24 09:21:46 --> Security Class Initialized
DEBUG - 2016-08-24 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:21:46 --> Input Class Initialized
INFO - 2016-08-24 09:21:46 --> Language Class Initialized
INFO - 2016-08-24 09:21:46 --> Loader Class Initialized
INFO - 2016-08-24 09:21:46 --> Helper loaded: url_helper
INFO - 2016-08-24 09:21:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:21:46 --> Helper loaded: html_helper
INFO - 2016-08-24 09:21:46 --> Helper loaded: form_helper
INFO - 2016-08-24 09:21:46 --> Helper loaded: file_helper
INFO - 2016-08-24 09:21:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:21:46 --> Database Driver Class Initialized
INFO - 2016-08-24 09:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:21:46 --> Form Validation Class Initialized
INFO - 2016-08-24 09:21:47 --> Email Class Initialized
INFO - 2016-08-24 09:21:47 --> Controller Class Initialized
INFO - 2016-08-24 09:21:47 --> Config Class Initialized
INFO - 2016-08-24 09:21:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:21:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:21:47 --> Utf8 Class Initialized
INFO - 2016-08-24 09:21:47 --> URI Class Initialized
INFO - 2016-08-24 09:21:47 --> Router Class Initialized
INFO - 2016-08-24 09:21:47 --> Output Class Initialized
INFO - 2016-08-24 09:21:47 --> Security Class Initialized
DEBUG - 2016-08-24 09:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:21:47 --> Input Class Initialized
INFO - 2016-08-24 09:21:47 --> Language Class Initialized
INFO - 2016-08-24 09:21:47 --> Loader Class Initialized
INFO - 2016-08-24 09:21:47 --> Helper loaded: url_helper
INFO - 2016-08-24 09:21:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:21:47 --> Helper loaded: html_helper
INFO - 2016-08-24 09:21:47 --> Helper loaded: form_helper
INFO - 2016-08-24 09:21:47 --> Helper loaded: file_helper
INFO - 2016-08-24 09:21:47 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:21:47 --> Database Driver Class Initialized
INFO - 2016-08-24 09:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:21:47 --> Form Validation Class Initialized
INFO - 2016-08-24 09:21:47 --> Email Class Initialized
INFO - 2016-08-24 09:21:47 --> Controller Class Initialized
INFO - 2016-08-24 09:21:47 --> Model Class Initialized
DEBUG - 2016-08-24 09:21:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:21:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:21:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:21:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:21:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:21:47 --> Final output sent to browser
DEBUG - 2016-08-24 09:21:47 --> Total execution time: 0.5214
INFO - 2016-08-24 09:21:49 --> Config Class Initialized
INFO - 2016-08-24 09:21:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:21:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:21:49 --> Utf8 Class Initialized
INFO - 2016-08-24 09:21:49 --> URI Class Initialized
INFO - 2016-08-24 09:21:49 --> Router Class Initialized
INFO - 2016-08-24 09:21:49 --> Output Class Initialized
INFO - 2016-08-24 09:21:49 --> Security Class Initialized
DEBUG - 2016-08-24 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:21:49 --> Input Class Initialized
INFO - 2016-08-24 09:21:49 --> Language Class Initialized
INFO - 2016-08-24 09:21:49 --> Loader Class Initialized
INFO - 2016-08-24 09:21:49 --> Helper loaded: url_helper
INFO - 2016-08-24 09:21:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:21:49 --> Helper loaded: html_helper
INFO - 2016-08-24 09:21:49 --> Helper loaded: form_helper
INFO - 2016-08-24 09:21:49 --> Helper loaded: file_helper
INFO - 2016-08-24 09:21:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:21:49 --> Database Driver Class Initialized
INFO - 2016-08-24 09:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:21:49 --> Form Validation Class Initialized
INFO - 2016-08-24 09:21:49 --> Email Class Initialized
INFO - 2016-08-24 09:21:49 --> Controller Class Initialized
INFO - 2016-08-24 09:21:49 --> Model Class Initialized
INFO - 2016-08-24 09:21:54 --> Config Class Initialized
INFO - 2016-08-24 09:21:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:21:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:21:54 --> Utf8 Class Initialized
INFO - 2016-08-24 09:21:54 --> URI Class Initialized
INFO - 2016-08-24 09:21:54 --> Router Class Initialized
INFO - 2016-08-24 09:21:54 --> Output Class Initialized
INFO - 2016-08-24 09:21:54 --> Security Class Initialized
DEBUG - 2016-08-24 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:21:54 --> Input Class Initialized
INFO - 2016-08-24 09:21:54 --> Language Class Initialized
INFO - 2016-08-24 09:21:54 --> Loader Class Initialized
INFO - 2016-08-24 09:21:54 --> Helper loaded: url_helper
INFO - 2016-08-24 09:21:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:21:54 --> Helper loaded: html_helper
INFO - 2016-08-24 09:21:54 --> Helper loaded: form_helper
INFO - 2016-08-24 09:21:54 --> Helper loaded: file_helper
INFO - 2016-08-24 09:21:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:21:54 --> Database Driver Class Initialized
INFO - 2016-08-24 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:21:54 --> Form Validation Class Initialized
INFO - 2016-08-24 09:21:54 --> Email Class Initialized
INFO - 2016-08-24 09:21:54 --> Controller Class Initialized
INFO - 2016-08-24 09:21:54 --> Model Class Initialized
ERROR - 2016-08-24 09:21:55 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 09:42:32 --> Config Class Initialized
INFO - 2016-08-24 09:42:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:42:32 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:42:32 --> Utf8 Class Initialized
INFO - 2016-08-24 09:42:32 --> URI Class Initialized
INFO - 2016-08-24 09:42:32 --> Router Class Initialized
INFO - 2016-08-24 09:42:32 --> Output Class Initialized
INFO - 2016-08-24 09:42:32 --> Security Class Initialized
DEBUG - 2016-08-24 09:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:42:32 --> Input Class Initialized
INFO - 2016-08-24 09:42:32 --> Language Class Initialized
INFO - 2016-08-24 09:42:32 --> Loader Class Initialized
INFO - 2016-08-24 09:42:32 --> Helper loaded: url_helper
INFO - 2016-08-24 09:42:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:42:32 --> Helper loaded: html_helper
INFO - 2016-08-24 09:42:32 --> Helper loaded: form_helper
INFO - 2016-08-24 09:42:32 --> Helper loaded: file_helper
INFO - 2016-08-24 09:42:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:42:32 --> Database Driver Class Initialized
INFO - 2016-08-24 09:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:42:32 --> Form Validation Class Initialized
INFO - 2016-08-24 09:42:32 --> Email Class Initialized
INFO - 2016-08-24 09:42:32 --> Controller Class Initialized
INFO - 2016-08-24 09:42:32 --> Model Class Initialized
DEBUG - 2016-08-24 09:42:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:42:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:42:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:42:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:42:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:42:32 --> Final output sent to browser
DEBUG - 2016-08-24 09:42:32 --> Total execution time: 0.6367
INFO - 2016-08-24 09:42:36 --> Config Class Initialized
INFO - 2016-08-24 09:42:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:42:36 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:42:36 --> Utf8 Class Initialized
INFO - 2016-08-24 09:42:36 --> URI Class Initialized
INFO - 2016-08-24 09:42:36 --> Router Class Initialized
INFO - 2016-08-24 09:42:36 --> Output Class Initialized
INFO - 2016-08-24 09:42:36 --> Security Class Initialized
DEBUG - 2016-08-24 09:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:42:36 --> Input Class Initialized
INFO - 2016-08-24 09:42:36 --> Language Class Initialized
INFO - 2016-08-24 09:42:36 --> Loader Class Initialized
INFO - 2016-08-24 09:42:36 --> Helper loaded: url_helper
INFO - 2016-08-24 09:42:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:42:36 --> Helper loaded: html_helper
INFO - 2016-08-24 09:42:36 --> Helper loaded: form_helper
INFO - 2016-08-24 09:42:37 --> Helper loaded: file_helper
INFO - 2016-08-24 09:42:37 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:42:37 --> Database Driver Class Initialized
INFO - 2016-08-24 09:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:42:37 --> Form Validation Class Initialized
INFO - 2016-08-24 09:42:37 --> Email Class Initialized
INFO - 2016-08-24 09:42:37 --> Controller Class Initialized
INFO - 2016-08-24 09:42:37 --> Model Class Initialized
INFO - 2016-08-24 09:42:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:42:37 --> Final output sent to browser
DEBUG - 2016-08-24 09:42:37 --> Total execution time: 0.5353
INFO - 2016-08-24 09:42:41 --> Config Class Initialized
INFO - 2016-08-24 09:42:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:42:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:42:41 --> Utf8 Class Initialized
INFO - 2016-08-24 09:42:41 --> URI Class Initialized
INFO - 2016-08-24 09:42:41 --> Router Class Initialized
INFO - 2016-08-24 09:42:41 --> Output Class Initialized
INFO - 2016-08-24 09:42:41 --> Security Class Initialized
DEBUG - 2016-08-24 09:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:42:41 --> Input Class Initialized
INFO - 2016-08-24 09:42:41 --> Language Class Initialized
INFO - 2016-08-24 09:42:41 --> Loader Class Initialized
INFO - 2016-08-24 09:42:41 --> Helper loaded: url_helper
INFO - 2016-08-24 09:42:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:42:41 --> Helper loaded: html_helper
INFO - 2016-08-24 09:42:41 --> Helper loaded: form_helper
INFO - 2016-08-24 09:42:41 --> Helper loaded: file_helper
INFO - 2016-08-24 09:42:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:42:41 --> Database Driver Class Initialized
INFO - 2016-08-24 09:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:42:42 --> Form Validation Class Initialized
INFO - 2016-08-24 09:42:42 --> Email Class Initialized
INFO - 2016-08-24 09:42:42 --> Controller Class Initialized
INFO - 2016-08-24 09:42:42 --> Model Class Initialized
INFO - 2016-08-24 09:42:43 --> Config Class Initialized
INFO - 2016-08-24 09:42:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:42:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:42:43 --> Utf8 Class Initialized
INFO - 2016-08-24 09:42:43 --> URI Class Initialized
INFO - 2016-08-24 09:42:43 --> Router Class Initialized
INFO - 2016-08-24 09:42:43 --> Output Class Initialized
INFO - 2016-08-24 09:42:43 --> Security Class Initialized
DEBUG - 2016-08-24 09:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:42:43 --> Input Class Initialized
INFO - 2016-08-24 09:42:43 --> Language Class Initialized
INFO - 2016-08-24 09:42:43 --> Loader Class Initialized
INFO - 2016-08-24 09:42:43 --> Helper loaded: url_helper
INFO - 2016-08-24 09:42:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:42:43 --> Helper loaded: html_helper
INFO - 2016-08-24 09:42:43 --> Helper loaded: form_helper
INFO - 2016-08-24 09:42:43 --> Helper loaded: file_helper
INFO - 2016-08-24 09:42:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:42:43 --> Database Driver Class Initialized
INFO - 2016-08-24 09:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:42:43 --> Form Validation Class Initialized
INFO - 2016-08-24 09:42:43 --> Email Class Initialized
INFO - 2016-08-24 09:42:43 --> Controller Class Initialized
INFO - 2016-08-24 09:42:43 --> Model Class Initialized
INFO - 2016-08-24 09:42:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:42:43 --> Final output sent to browser
DEBUG - 2016-08-24 09:42:43 --> Total execution time: 0.4950
INFO - 2016-08-24 09:48:00 --> Config Class Initialized
INFO - 2016-08-24 09:48:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:48:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:48:00 --> Utf8 Class Initialized
INFO - 2016-08-24 09:48:00 --> URI Class Initialized
INFO - 2016-08-24 09:48:00 --> Router Class Initialized
INFO - 2016-08-24 09:48:00 --> Output Class Initialized
INFO - 2016-08-24 09:48:00 --> Security Class Initialized
DEBUG - 2016-08-24 09:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:48:00 --> Input Class Initialized
INFO - 2016-08-24 09:48:00 --> Language Class Initialized
INFO - 2016-08-24 09:48:00 --> Loader Class Initialized
INFO - 2016-08-24 09:48:00 --> Helper loaded: url_helper
INFO - 2016-08-24 09:48:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:48:00 --> Helper loaded: html_helper
INFO - 2016-08-24 09:48:00 --> Helper loaded: form_helper
INFO - 2016-08-24 09:48:00 --> Helper loaded: file_helper
INFO - 2016-08-24 09:48:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:48:00 --> Database Driver Class Initialized
INFO - 2016-08-24 09:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:48:00 --> Form Validation Class Initialized
INFO - 2016-08-24 09:48:00 --> Email Class Initialized
INFO - 2016-08-24 09:48:00 --> Controller Class Initialized
INFO - 2016-08-24 09:48:00 --> Model Class Initialized
INFO - 2016-08-24 09:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:48:02 --> Final output sent to browser
DEBUG - 2016-08-24 09:48:02 --> Total execution time: 2.1500
INFO - 2016-08-24 09:48:20 --> Config Class Initialized
INFO - 2016-08-24 09:48:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:48:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:48:20 --> Utf8 Class Initialized
INFO - 2016-08-24 09:48:20 --> URI Class Initialized
INFO - 2016-08-24 09:48:20 --> Router Class Initialized
INFO - 2016-08-24 09:48:20 --> Output Class Initialized
INFO - 2016-08-24 09:48:20 --> Security Class Initialized
DEBUG - 2016-08-24 09:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:48:20 --> Input Class Initialized
INFO - 2016-08-24 09:48:21 --> Language Class Initialized
INFO - 2016-08-24 09:48:21 --> Loader Class Initialized
INFO - 2016-08-24 09:48:21 --> Helper loaded: url_helper
INFO - 2016-08-24 09:48:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:48:21 --> Helper loaded: html_helper
INFO - 2016-08-24 09:48:21 --> Helper loaded: form_helper
INFO - 2016-08-24 09:48:21 --> Helper loaded: file_helper
INFO - 2016-08-24 09:48:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:48:21 --> Database Driver Class Initialized
INFO - 2016-08-24 09:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:48:21 --> Form Validation Class Initialized
INFO - 2016-08-24 09:48:21 --> Email Class Initialized
INFO - 2016-08-24 09:48:21 --> Controller Class Initialized
INFO - 2016-08-24 09:48:21 --> Model Class Initialized
DEBUG - 2016-08-24 09:48:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:48:21 --> Final output sent to browser
DEBUG - 2016-08-24 09:48:21 --> Total execution time: 0.5402
INFO - 2016-08-24 09:48:24 --> Config Class Initialized
INFO - 2016-08-24 09:48:24 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:48:24 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:48:24 --> Utf8 Class Initialized
INFO - 2016-08-24 09:48:24 --> URI Class Initialized
INFO - 2016-08-24 09:48:24 --> Router Class Initialized
INFO - 2016-08-24 09:48:24 --> Output Class Initialized
INFO - 2016-08-24 09:48:24 --> Security Class Initialized
DEBUG - 2016-08-24 09:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:48:24 --> Input Class Initialized
INFO - 2016-08-24 09:48:24 --> Language Class Initialized
INFO - 2016-08-24 09:48:24 --> Loader Class Initialized
INFO - 2016-08-24 09:48:24 --> Helper loaded: url_helper
INFO - 2016-08-24 09:48:24 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:48:24 --> Helper loaded: html_helper
INFO - 2016-08-24 09:48:24 --> Helper loaded: form_helper
INFO - 2016-08-24 09:48:24 --> Helper loaded: file_helper
INFO - 2016-08-24 09:48:24 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:48:24 --> Database Driver Class Initialized
INFO - 2016-08-24 09:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:48:24 --> Form Validation Class Initialized
INFO - 2016-08-24 09:48:24 --> Email Class Initialized
INFO - 2016-08-24 09:48:24 --> Controller Class Initialized
INFO - 2016-08-24 09:48:24 --> Model Class Initialized
INFO - 2016-08-24 09:48:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:48:24 --> Final output sent to browser
DEBUG - 2016-08-24 09:48:24 --> Total execution time: 0.4689
INFO - 2016-08-24 09:48:30 --> Config Class Initialized
INFO - 2016-08-24 09:48:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:48:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:48:31 --> Utf8 Class Initialized
INFO - 2016-08-24 09:48:31 --> URI Class Initialized
INFO - 2016-08-24 09:48:31 --> Router Class Initialized
INFO - 2016-08-24 09:48:31 --> Output Class Initialized
INFO - 2016-08-24 09:48:31 --> Security Class Initialized
DEBUG - 2016-08-24 09:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:48:31 --> Input Class Initialized
INFO - 2016-08-24 09:48:31 --> Language Class Initialized
INFO - 2016-08-24 09:48:31 --> Loader Class Initialized
INFO - 2016-08-24 09:48:31 --> Helper loaded: url_helper
INFO - 2016-08-24 09:48:31 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:48:31 --> Helper loaded: html_helper
INFO - 2016-08-24 09:48:31 --> Helper loaded: form_helper
INFO - 2016-08-24 09:48:31 --> Helper loaded: file_helper
INFO - 2016-08-24 09:48:31 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:48:31 --> Database Driver Class Initialized
INFO - 2016-08-24 09:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:48:31 --> Form Validation Class Initialized
INFO - 2016-08-24 09:48:31 --> Email Class Initialized
INFO - 2016-08-24 09:48:31 --> Controller Class Initialized
INFO - 2016-08-24 09:48:31 --> Model Class Initialized
INFO - 2016-08-24 09:48:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:48:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 09:48:33 --> Final output sent to browser
DEBUG - 2016-08-24 09:48:33 --> Total execution time: 2.5482
INFO - 2016-08-24 09:50:43 --> Config Class Initialized
INFO - 2016-08-24 09:50:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:50:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:50:43 --> Utf8 Class Initialized
INFO - 2016-08-24 09:50:43 --> URI Class Initialized
INFO - 2016-08-24 09:50:43 --> Router Class Initialized
INFO - 2016-08-24 09:50:43 --> Output Class Initialized
INFO - 2016-08-24 09:50:43 --> Security Class Initialized
DEBUG - 2016-08-24 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:50:43 --> Input Class Initialized
INFO - 2016-08-24 09:50:43 --> Language Class Initialized
INFO - 2016-08-24 09:50:43 --> Loader Class Initialized
INFO - 2016-08-24 09:50:43 --> Helper loaded: url_helper
INFO - 2016-08-24 09:50:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:50:43 --> Helper loaded: html_helper
INFO - 2016-08-24 09:50:43 --> Helper loaded: form_helper
INFO - 2016-08-24 09:50:43 --> Helper loaded: file_helper
INFO - 2016-08-24 09:50:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:50:43 --> Database Driver Class Initialized
INFO - 2016-08-24 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:50:43 --> Form Validation Class Initialized
INFO - 2016-08-24 09:50:43 --> Email Class Initialized
INFO - 2016-08-24 09:50:43 --> Controller Class Initialized
INFO - 2016-08-24 09:50:43 --> Model Class Initialized
DEBUG - 2016-08-24 09:50:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 09:50:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 09:50:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 09:50:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 09:50:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 09:50:43 --> Final output sent to browser
DEBUG - 2016-08-24 09:50:43 --> Total execution time: 0.5208
INFO - 2016-08-24 09:50:48 --> Config Class Initialized
INFO - 2016-08-24 09:50:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:50:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:50:48 --> Utf8 Class Initialized
INFO - 2016-08-24 09:50:48 --> URI Class Initialized
INFO - 2016-08-24 09:50:48 --> Router Class Initialized
INFO - 2016-08-24 09:50:48 --> Output Class Initialized
INFO - 2016-08-24 09:50:48 --> Security Class Initialized
DEBUG - 2016-08-24 09:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:50:48 --> Input Class Initialized
INFO - 2016-08-24 09:50:48 --> Language Class Initialized
INFO - 2016-08-24 09:50:48 --> Loader Class Initialized
INFO - 2016-08-24 09:50:48 --> Helper loaded: url_helper
INFO - 2016-08-24 09:50:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:50:48 --> Helper loaded: html_helper
INFO - 2016-08-24 09:50:48 --> Helper loaded: form_helper
INFO - 2016-08-24 09:50:48 --> Helper loaded: file_helper
INFO - 2016-08-24 09:50:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:50:49 --> Database Driver Class Initialized
INFO - 2016-08-24 09:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:50:49 --> Form Validation Class Initialized
INFO - 2016-08-24 09:50:49 --> Email Class Initialized
INFO - 2016-08-24 09:50:49 --> Controller Class Initialized
INFO - 2016-08-24 09:50:49 --> Model Class Initialized
INFO - 2016-08-24 09:50:49 --> Config Class Initialized
INFO - 2016-08-24 09:50:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 09:50:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 09:50:49 --> Utf8 Class Initialized
INFO - 2016-08-24 09:50:49 --> URI Class Initialized
INFO - 2016-08-24 09:50:49 --> Router Class Initialized
INFO - 2016-08-24 09:50:49 --> Output Class Initialized
INFO - 2016-08-24 09:50:49 --> Security Class Initialized
DEBUG - 2016-08-24 09:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 09:50:49 --> Input Class Initialized
INFO - 2016-08-24 09:50:49 --> Language Class Initialized
INFO - 2016-08-24 09:50:49 --> Loader Class Initialized
INFO - 2016-08-24 09:50:49 --> Helper loaded: url_helper
INFO - 2016-08-24 09:50:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 09:50:50 --> Helper loaded: html_helper
INFO - 2016-08-24 09:50:50 --> Helper loaded: form_helper
INFO - 2016-08-24 09:50:50 --> Helper loaded: file_helper
INFO - 2016-08-24 09:50:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 09:50:50 --> Database Driver Class Initialized
INFO - 2016-08-24 09:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 09:50:50 --> Form Validation Class Initialized
INFO - 2016-08-24 09:50:50 --> Email Class Initialized
INFO - 2016-08-24 09:50:50 --> Controller Class Initialized
INFO - 2016-08-24 09:50:50 --> Model Class Initialized
ERROR - 2016-08-24 09:50:50 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:00:23 --> Config Class Initialized
INFO - 2016-08-24 10:00:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:00:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:00:23 --> Utf8 Class Initialized
INFO - 2016-08-24 10:00:23 --> URI Class Initialized
INFO - 2016-08-24 10:00:24 --> Router Class Initialized
INFO - 2016-08-24 10:00:24 --> Output Class Initialized
INFO - 2016-08-24 10:00:24 --> Security Class Initialized
DEBUG - 2016-08-24 10:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:00:24 --> Input Class Initialized
INFO - 2016-08-24 10:00:24 --> Language Class Initialized
INFO - 2016-08-24 10:00:24 --> Loader Class Initialized
INFO - 2016-08-24 10:00:24 --> Helper loaded: url_helper
INFO - 2016-08-24 10:00:24 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:00:24 --> Helper loaded: html_helper
INFO - 2016-08-24 10:00:24 --> Helper loaded: form_helper
INFO - 2016-08-24 10:00:24 --> Helper loaded: file_helper
INFO - 2016-08-24 10:00:24 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:00:24 --> Database Driver Class Initialized
INFO - 2016-08-24 10:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:00:24 --> Form Validation Class Initialized
INFO - 2016-08-24 10:00:24 --> Email Class Initialized
INFO - 2016-08-24 10:00:24 --> Controller Class Initialized
INFO - 2016-08-24 10:00:24 --> Model Class Initialized
ERROR - 2016-08-24 10:00:25 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:01:07 --> Config Class Initialized
INFO - 2016-08-24 10:01:07 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:07 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:07 --> URI Class Initialized
INFO - 2016-08-24 10:01:07 --> Router Class Initialized
INFO - 2016-08-24 10:01:07 --> Output Class Initialized
INFO - 2016-08-24 10:01:07 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:07 --> Input Class Initialized
INFO - 2016-08-24 10:01:07 --> Language Class Initialized
INFO - 2016-08-24 10:01:07 --> Loader Class Initialized
INFO - 2016-08-24 10:01:07 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:07 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:07 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:07 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:07 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:07 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:07 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:07 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:07 --> Email Class Initialized
INFO - 2016-08-24 10:01:07 --> Controller Class Initialized
INFO - 2016-08-24 10:01:07 --> Model Class Initialized
ERROR - 2016-08-24 10:01:08 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:01:10 --> Config Class Initialized
INFO - 2016-08-24 10:01:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:10 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:10 --> URI Class Initialized
INFO - 2016-08-24 10:01:10 --> Router Class Initialized
INFO - 2016-08-24 10:01:10 --> Output Class Initialized
INFO - 2016-08-24 10:01:10 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:10 --> Input Class Initialized
INFO - 2016-08-24 10:01:10 --> Language Class Initialized
INFO - 2016-08-24 10:01:10 --> Loader Class Initialized
INFO - 2016-08-24 10:01:10 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:10 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:10 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:10 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:10 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:10 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:10 --> Email Class Initialized
INFO - 2016-08-24 10:01:10 --> Controller Class Initialized
INFO - 2016-08-24 10:01:10 --> Model Class Initialized
ERROR - 2016-08-24 10:01:11 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:01:13 --> Config Class Initialized
INFO - 2016-08-24 10:01:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:13 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:13 --> URI Class Initialized
INFO - 2016-08-24 10:01:13 --> Router Class Initialized
INFO - 2016-08-24 10:01:13 --> Output Class Initialized
INFO - 2016-08-24 10:01:13 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:13 --> Input Class Initialized
INFO - 2016-08-24 10:01:13 --> Language Class Initialized
INFO - 2016-08-24 10:01:13 --> Loader Class Initialized
INFO - 2016-08-24 10:01:13 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:13 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:13 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:13 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:13 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:13 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:13 --> Email Class Initialized
INFO - 2016-08-24 10:01:13 --> Controller Class Initialized
INFO - 2016-08-24 10:01:13 --> Model Class Initialized
ERROR - 2016-08-24 10:01:13 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:01:15 --> Config Class Initialized
INFO - 2016-08-24 10:01:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:15 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:15 --> URI Class Initialized
INFO - 2016-08-24 10:01:15 --> Router Class Initialized
INFO - 2016-08-24 10:01:15 --> Output Class Initialized
INFO - 2016-08-24 10:01:15 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:15 --> Input Class Initialized
INFO - 2016-08-24 10:01:15 --> Language Class Initialized
INFO - 2016-08-24 10:01:15 --> Loader Class Initialized
INFO - 2016-08-24 10:01:15 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:15 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:15 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:15 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:15 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:15 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:15 --> Email Class Initialized
INFO - 2016-08-24 10:01:15 --> Controller Class Initialized
INFO - 2016-08-24 10:01:15 --> Model Class Initialized
DEBUG - 2016-08-24 10:01:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:01:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 10:01:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 10:01:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 10:01:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 10:01:15 --> Final output sent to browser
DEBUG - 2016-08-24 10:01:15 --> Total execution time: 0.5446
INFO - 2016-08-24 10:01:23 --> Config Class Initialized
INFO - 2016-08-24 10:01:23 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:23 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:23 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:23 --> URI Class Initialized
INFO - 2016-08-24 10:01:24 --> Router Class Initialized
INFO - 2016-08-24 10:01:24 --> Output Class Initialized
INFO - 2016-08-24 10:01:24 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:24 --> Input Class Initialized
INFO - 2016-08-24 10:01:24 --> Language Class Initialized
INFO - 2016-08-24 10:01:24 --> Loader Class Initialized
INFO - 2016-08-24 10:01:24 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:24 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:24 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:24 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:24 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:24 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:24 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:24 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:24 --> Email Class Initialized
INFO - 2016-08-24 10:01:24 --> Controller Class Initialized
INFO - 2016-08-24 10:01:24 --> Model Class Initialized
DEBUG - 2016-08-24 10:01:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:01:24 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-24 10:01:24 --> {controllers/session/login} Invalid login id or password for user=admin
INFO - 2016-08-24 10:01:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 10:01:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 10:01:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 10:01:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 10:01:24 --> Final output sent to browser
DEBUG - 2016-08-24 10:01:24 --> Total execution time: 0.6275
INFO - 2016-08-24 10:01:31 --> Config Class Initialized
INFO - 2016-08-24 10:01:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:31 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:31 --> URI Class Initialized
INFO - 2016-08-24 10:01:31 --> Router Class Initialized
INFO - 2016-08-24 10:01:31 --> Output Class Initialized
INFO - 2016-08-24 10:01:31 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:31 --> Input Class Initialized
INFO - 2016-08-24 10:01:31 --> Language Class Initialized
INFO - 2016-08-24 10:01:32 --> Loader Class Initialized
INFO - 2016-08-24 10:01:32 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:32 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:32 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:32 --> Email Class Initialized
INFO - 2016-08-24 10:01:32 --> Controller Class Initialized
INFO - 2016-08-24 10:01:32 --> Model Class Initialized
DEBUG - 2016-08-24 10:01:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:01:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 10:01:32 --> Config Class Initialized
INFO - 2016-08-24 10:01:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:32 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:32 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:32 --> URI Class Initialized
INFO - 2016-08-24 10:01:32 --> Router Class Initialized
INFO - 2016-08-24 10:01:32 --> Output Class Initialized
INFO - 2016-08-24 10:01:32 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:32 --> Input Class Initialized
INFO - 2016-08-24 10:01:32 --> Language Class Initialized
INFO - 2016-08-24 10:01:32 --> Loader Class Initialized
INFO - 2016-08-24 10:01:32 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:32 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:32 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:32 --> Email Class Initialized
INFO - 2016-08-24 10:01:32 --> Controller Class Initialized
DEBUG - 2016-08-24 10:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 10:01:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:01:32 --> Model Class Initialized
INFO - 2016-08-24 10:01:32 --> Model Class Initialized
INFO - 2016-08-24 10:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 10:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 10:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 10:01:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 10:01:33 --> Final output sent to browser
DEBUG - 2016-08-24 10:01:33 --> Total execution time: 0.6254
INFO - 2016-08-24 10:01:36 --> Config Class Initialized
INFO - 2016-08-24 10:01:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:36 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:36 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:36 --> URI Class Initialized
INFO - 2016-08-24 10:01:36 --> Router Class Initialized
INFO - 2016-08-24 10:01:36 --> Output Class Initialized
INFO - 2016-08-24 10:01:36 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:36 --> Input Class Initialized
INFO - 2016-08-24 10:01:36 --> Language Class Initialized
INFO - 2016-08-24 10:01:36 --> Loader Class Initialized
INFO - 2016-08-24 10:01:36 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:36 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:36 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:36 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:37 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:37 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:37 --> Email Class Initialized
INFO - 2016-08-24 10:01:37 --> Controller Class Initialized
INFO - 2016-08-24 10:01:37 --> Model Class Initialized
INFO - 2016-08-24 10:01:37 --> Config Class Initialized
INFO - 2016-08-24 10:01:37 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:37 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:37 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:37 --> URI Class Initialized
INFO - 2016-08-24 10:01:37 --> Router Class Initialized
INFO - 2016-08-24 10:01:37 --> Output Class Initialized
INFO - 2016-08-24 10:01:37 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:37 --> Input Class Initialized
INFO - 2016-08-24 10:01:37 --> Language Class Initialized
INFO - 2016-08-24 10:01:37 --> Loader Class Initialized
INFO - 2016-08-24 10:01:37 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:37 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:37 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:37 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:37 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:37 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:37 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:37 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:37 --> Email Class Initialized
INFO - 2016-08-24 10:01:37 --> Controller Class Initialized
INFO - 2016-08-24 10:01:37 --> Model Class Initialized
DEBUG - 2016-08-24 10:01:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:01:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 10:01:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 10:01:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 10:01:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 10:01:37 --> Final output sent to browser
DEBUG - 2016-08-24 10:01:37 --> Total execution time: 0.7106
INFO - 2016-08-24 10:01:40 --> Config Class Initialized
INFO - 2016-08-24 10:01:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:40 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:40 --> URI Class Initialized
INFO - 2016-08-24 10:01:40 --> Router Class Initialized
INFO - 2016-08-24 10:01:40 --> Output Class Initialized
INFO - 2016-08-24 10:01:40 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:40 --> Input Class Initialized
INFO - 2016-08-24 10:01:40 --> Language Class Initialized
INFO - 2016-08-24 10:01:40 --> Loader Class Initialized
INFO - 2016-08-24 10:01:40 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:40 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:40 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:40 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:40 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:40 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:40 --> Email Class Initialized
INFO - 2016-08-24 10:01:40 --> Controller Class Initialized
INFO - 2016-08-24 10:01:40 --> Model Class Initialized
INFO - 2016-08-24 10:01:41 --> Config Class Initialized
INFO - 2016-08-24 10:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:01:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:01:41 --> Utf8 Class Initialized
INFO - 2016-08-24 10:01:41 --> URI Class Initialized
INFO - 2016-08-24 10:01:41 --> Router Class Initialized
INFO - 2016-08-24 10:01:41 --> Output Class Initialized
INFO - 2016-08-24 10:01:41 --> Security Class Initialized
DEBUG - 2016-08-24 10:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:01:41 --> Input Class Initialized
INFO - 2016-08-24 10:01:41 --> Language Class Initialized
INFO - 2016-08-24 10:01:41 --> Loader Class Initialized
INFO - 2016-08-24 10:01:41 --> Helper loaded: url_helper
INFO - 2016-08-24 10:01:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:01:41 --> Helper loaded: html_helper
INFO - 2016-08-24 10:01:41 --> Helper loaded: form_helper
INFO - 2016-08-24 10:01:41 --> Helper loaded: file_helper
INFO - 2016-08-24 10:01:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:01:41 --> Database Driver Class Initialized
INFO - 2016-08-24 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:01:41 --> Form Validation Class Initialized
INFO - 2016-08-24 10:01:41 --> Email Class Initialized
INFO - 2016-08-24 10:01:41 --> Controller Class Initialized
INFO - 2016-08-24 10:01:41 --> Model Class Initialized
ERROR - 2016-08-24 10:01:41 --> Severity: Error --> Call to undefined function GuzzleHttp\Handler\curl_reset() D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\guzzlehttp\guzzle\src\Handler\CurlFactory.php 78
INFO - 2016-08-24 10:02:14 --> Config Class Initialized
INFO - 2016-08-24 10:02:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:02:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:02:14 --> Utf8 Class Initialized
INFO - 2016-08-24 10:02:14 --> URI Class Initialized
DEBUG - 2016-08-24 10:02:14 --> No URI present. Default controller set.
INFO - 2016-08-24 10:02:14 --> Router Class Initialized
INFO - 2016-08-24 10:02:14 --> Output Class Initialized
INFO - 2016-08-24 10:02:14 --> Security Class Initialized
DEBUG - 2016-08-24 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:02:14 --> Input Class Initialized
INFO - 2016-08-24 10:02:14 --> Language Class Initialized
INFO - 2016-08-24 10:02:14 --> Loader Class Initialized
INFO - 2016-08-24 10:02:14 --> Helper loaded: url_helper
INFO - 2016-08-24 10:02:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:02:14 --> Helper loaded: html_helper
INFO - 2016-08-24 10:02:14 --> Helper loaded: form_helper
INFO - 2016-08-24 10:02:14 --> Helper loaded: file_helper
INFO - 2016-08-24 10:02:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:02:14 --> Database Driver Class Initialized
INFO - 2016-08-24 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:02:14 --> Form Validation Class Initialized
INFO - 2016-08-24 10:02:14 --> Email Class Initialized
INFO - 2016-08-24 10:02:14 --> Controller Class Initialized
INFO - 2016-08-24 10:02:14 --> Config Class Initialized
INFO - 2016-08-24 10:02:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 10:02:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 10:02:14 --> Utf8 Class Initialized
INFO - 2016-08-24 10:02:14 --> URI Class Initialized
INFO - 2016-08-24 10:02:14 --> Router Class Initialized
INFO - 2016-08-24 10:02:14 --> Output Class Initialized
INFO - 2016-08-24 10:02:14 --> Security Class Initialized
DEBUG - 2016-08-24 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 10:02:15 --> Input Class Initialized
INFO - 2016-08-24 10:02:15 --> Language Class Initialized
INFO - 2016-08-24 10:02:15 --> Loader Class Initialized
INFO - 2016-08-24 10:02:15 --> Helper loaded: url_helper
INFO - 2016-08-24 10:02:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 10:02:15 --> Helper loaded: html_helper
INFO - 2016-08-24 10:02:15 --> Helper loaded: form_helper
INFO - 2016-08-24 10:02:15 --> Helper loaded: file_helper
INFO - 2016-08-24 10:02:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 10:02:15 --> Database Driver Class Initialized
INFO - 2016-08-24 10:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 10:02:15 --> Form Validation Class Initialized
INFO - 2016-08-24 10:02:15 --> Email Class Initialized
INFO - 2016-08-24 10:02:15 --> Controller Class Initialized
INFO - 2016-08-24 10:02:15 --> Model Class Initialized
DEBUG - 2016-08-24 10:02:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 10:02:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 10:02:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 10:02:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 10:02:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 10:02:15 --> Final output sent to browser
DEBUG - 2016-08-24 10:02:15 --> Total execution time: 0.5778
INFO - 2016-08-24 15:55:45 --> Config Class Initialized
INFO - 2016-08-24 15:55:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:55:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:55:46 --> Utf8 Class Initialized
INFO - 2016-08-24 15:55:46 --> URI Class Initialized
INFO - 2016-08-24 15:55:46 --> Router Class Initialized
INFO - 2016-08-24 15:55:46 --> Output Class Initialized
INFO - 2016-08-24 15:55:46 --> Security Class Initialized
DEBUG - 2016-08-24 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:55:46 --> Input Class Initialized
INFO - 2016-08-24 15:55:46 --> Language Class Initialized
INFO - 2016-08-24 15:55:46 --> Loader Class Initialized
INFO - 2016-08-24 15:55:46 --> Helper loaded: url_helper
INFO - 2016-08-24 15:55:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:55:46 --> Helper loaded: html_helper
INFO - 2016-08-24 15:55:46 --> Helper loaded: form_helper
INFO - 2016-08-24 15:55:46 --> Helper loaded: file_helper
INFO - 2016-08-24 15:55:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:55:46 --> Database Driver Class Initialized
INFO - 2016-08-24 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:55:46 --> Form Validation Class Initialized
INFO - 2016-08-24 15:55:46 --> Email Class Initialized
INFO - 2016-08-24 15:55:46 --> Controller Class Initialized
INFO - 2016-08-24 15:55:47 --> Model Class Initialized
DEBUG - 2016-08-24 15:55:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 15:55:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 15:55:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 15:55:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 15:55:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 15:55:47 --> Final output sent to browser
DEBUG - 2016-08-24 15:55:47 --> Total execution time: 1.6794
INFO - 2016-08-24 15:55:49 --> Config Class Initialized
INFO - 2016-08-24 15:55:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:55:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:55:49 --> Utf8 Class Initialized
INFO - 2016-08-24 15:55:50 --> URI Class Initialized
INFO - 2016-08-24 15:55:50 --> Router Class Initialized
INFO - 2016-08-24 15:55:50 --> Output Class Initialized
INFO - 2016-08-24 15:55:50 --> Security Class Initialized
DEBUG - 2016-08-24 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:55:50 --> Input Class Initialized
INFO - 2016-08-24 15:55:50 --> Language Class Initialized
INFO - 2016-08-24 15:55:50 --> Loader Class Initialized
INFO - 2016-08-24 15:55:50 --> Helper loaded: url_helper
INFO - 2016-08-24 15:55:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:55:50 --> Helper loaded: html_helper
INFO - 2016-08-24 15:55:50 --> Helper loaded: form_helper
INFO - 2016-08-24 15:55:50 --> Helper loaded: file_helper
INFO - 2016-08-24 15:55:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:55:50 --> Database Driver Class Initialized
INFO - 2016-08-24 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:55:50 --> Form Validation Class Initialized
INFO - 2016-08-24 15:55:50 --> Email Class Initialized
INFO - 2016-08-24 15:55:50 --> Controller Class Initialized
INFO - 2016-08-24 15:55:50 --> Model Class Initialized
INFO - 2016-08-24 15:55:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 15:55:50 --> Final output sent to browser
DEBUG - 2016-08-24 15:55:50 --> Total execution time: 0.9162
INFO - 2016-08-24 15:55:54 --> Config Class Initialized
INFO - 2016-08-24 15:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:55:54 --> Utf8 Class Initialized
INFO - 2016-08-24 15:55:54 --> URI Class Initialized
INFO - 2016-08-24 15:55:54 --> Router Class Initialized
INFO - 2016-08-24 15:55:54 --> Output Class Initialized
INFO - 2016-08-24 15:55:54 --> Security Class Initialized
DEBUG - 2016-08-24 15:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:55:54 --> Input Class Initialized
INFO - 2016-08-24 15:55:54 --> Language Class Initialized
INFO - 2016-08-24 15:55:55 --> Loader Class Initialized
INFO - 2016-08-24 15:55:55 --> Helper loaded: url_helper
INFO - 2016-08-24 15:55:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:55:55 --> Helper loaded: html_helper
INFO - 2016-08-24 15:55:55 --> Helper loaded: form_helper
INFO - 2016-08-24 15:55:55 --> Helper loaded: file_helper
INFO - 2016-08-24 15:55:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:55:55 --> Database Driver Class Initialized
INFO - 2016-08-24 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:55:55 --> Form Validation Class Initialized
INFO - 2016-08-24 15:55:55 --> Email Class Initialized
INFO - 2016-08-24 15:55:55 --> Controller Class Initialized
INFO - 2016-08-24 15:55:55 --> Model Class Initialized
INFO - 2016-08-24 15:56:36 --> Config Class Initialized
INFO - 2016-08-24 15:56:36 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:56:36 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:56:36 --> Utf8 Class Initialized
INFO - 2016-08-24 15:56:36 --> URI Class Initialized
INFO - 2016-08-24 15:56:36 --> Router Class Initialized
INFO - 2016-08-24 15:56:36 --> Output Class Initialized
INFO - 2016-08-24 15:56:36 --> Security Class Initialized
DEBUG - 2016-08-24 15:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:56:36 --> Input Class Initialized
INFO - 2016-08-24 15:56:36 --> Language Class Initialized
INFO - 2016-08-24 15:56:36 --> Loader Class Initialized
INFO - 2016-08-24 15:56:36 --> Helper loaded: url_helper
INFO - 2016-08-24 15:56:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:56:36 --> Helper loaded: html_helper
INFO - 2016-08-24 15:56:36 --> Helper loaded: form_helper
INFO - 2016-08-24 15:56:36 --> Helper loaded: file_helper
INFO - 2016-08-24 15:56:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:56:36 --> Database Driver Class Initialized
INFO - 2016-08-24 15:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:56:36 --> Form Validation Class Initialized
INFO - 2016-08-24 15:56:36 --> Email Class Initialized
INFO - 2016-08-24 15:56:36 --> Controller Class Initialized
INFO - 2016-08-24 15:56:36 --> Model Class Initialized
ERROR - 2016-08-24 15:56:37 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 15:56:41 --> Config Class Initialized
INFO - 2016-08-24 15:56:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:56:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:56:41 --> Utf8 Class Initialized
INFO - 2016-08-24 15:56:41 --> URI Class Initialized
INFO - 2016-08-24 15:56:41 --> Router Class Initialized
INFO - 2016-08-24 15:56:41 --> Output Class Initialized
INFO - 2016-08-24 15:56:41 --> Security Class Initialized
DEBUG - 2016-08-24 15:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:56:41 --> Input Class Initialized
INFO - 2016-08-24 15:56:41 --> Language Class Initialized
INFO - 2016-08-24 15:56:41 --> Loader Class Initialized
INFO - 2016-08-24 15:56:41 --> Helper loaded: url_helper
INFO - 2016-08-24 15:56:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:56:41 --> Helper loaded: html_helper
INFO - 2016-08-24 15:56:41 --> Helper loaded: form_helper
INFO - 2016-08-24 15:56:41 --> Helper loaded: file_helper
INFO - 2016-08-24 15:56:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:56:41 --> Database Driver Class Initialized
INFO - 2016-08-24 15:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:56:41 --> Form Validation Class Initialized
INFO - 2016-08-24 15:56:41 --> Email Class Initialized
INFO - 2016-08-24 15:56:41 --> Controller Class Initialized
INFO - 2016-08-24 15:56:42 --> Model Class Initialized
INFO - 2016-08-24 15:56:43 --> Config Class Initialized
INFO - 2016-08-24 15:56:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:56:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:56:43 --> Utf8 Class Initialized
INFO - 2016-08-24 15:56:43 --> URI Class Initialized
INFO - 2016-08-24 15:56:43 --> Router Class Initialized
INFO - 2016-08-24 15:56:43 --> Output Class Initialized
INFO - 2016-08-24 15:56:43 --> Security Class Initialized
DEBUG - 2016-08-24 15:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:56:43 --> Input Class Initialized
INFO - 2016-08-24 15:56:43 --> Language Class Initialized
INFO - 2016-08-24 15:56:43 --> Loader Class Initialized
INFO - 2016-08-24 15:56:43 --> Helper loaded: url_helper
INFO - 2016-08-24 15:56:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:56:43 --> Helper loaded: html_helper
INFO - 2016-08-24 15:56:43 --> Helper loaded: form_helper
INFO - 2016-08-24 15:56:43 --> Helper loaded: file_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:56:44 --> Database Driver Class Initialized
INFO - 2016-08-24 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:56:44 --> Form Validation Class Initialized
INFO - 2016-08-24 15:56:44 --> Email Class Initialized
INFO - 2016-08-24 15:56:44 --> Controller Class Initialized
INFO - 2016-08-24 15:56:44 --> Config Class Initialized
INFO - 2016-08-24 15:56:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:56:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:56:44 --> Utf8 Class Initialized
INFO - 2016-08-24 15:56:44 --> URI Class Initialized
INFO - 2016-08-24 15:56:44 --> Router Class Initialized
INFO - 2016-08-24 15:56:44 --> Output Class Initialized
INFO - 2016-08-24 15:56:44 --> Security Class Initialized
DEBUG - 2016-08-24 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:56:44 --> Input Class Initialized
INFO - 2016-08-24 15:56:44 --> Language Class Initialized
INFO - 2016-08-24 15:56:44 --> Loader Class Initialized
INFO - 2016-08-24 15:56:44 --> Helper loaded: url_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: html_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: form_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: file_helper
INFO - 2016-08-24 15:56:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:56:44 --> Database Driver Class Initialized
INFO - 2016-08-24 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:56:44 --> Form Validation Class Initialized
INFO - 2016-08-24 15:56:44 --> Email Class Initialized
INFO - 2016-08-24 15:56:44 --> Controller Class Initialized
INFO - 2016-08-24 15:56:44 --> Model Class Initialized
DEBUG - 2016-08-24 15:56:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 15:56:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 15:56:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 15:56:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 15:56:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 15:56:44 --> Final output sent to browser
DEBUG - 2016-08-24 15:56:44 --> Total execution time: 0.5328
INFO - 2016-08-24 15:59:05 --> Config Class Initialized
INFO - 2016-08-24 15:59:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:59:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:59:05 --> Utf8 Class Initialized
INFO - 2016-08-24 15:59:05 --> URI Class Initialized
INFO - 2016-08-24 15:59:05 --> Router Class Initialized
INFO - 2016-08-24 15:59:05 --> Output Class Initialized
INFO - 2016-08-24 15:59:05 --> Security Class Initialized
DEBUG - 2016-08-24 15:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:59:05 --> Input Class Initialized
INFO - 2016-08-24 15:59:05 --> Language Class Initialized
INFO - 2016-08-24 15:59:05 --> Loader Class Initialized
INFO - 2016-08-24 15:59:05 --> Helper loaded: url_helper
INFO - 2016-08-24 15:59:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:59:05 --> Helper loaded: html_helper
INFO - 2016-08-24 15:59:06 --> Helper loaded: form_helper
INFO - 2016-08-24 15:59:06 --> Helper loaded: file_helper
INFO - 2016-08-24 15:59:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:59:06 --> Database Driver Class Initialized
INFO - 2016-08-24 15:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:59:06 --> Form Validation Class Initialized
INFO - 2016-08-24 15:59:06 --> Email Class Initialized
INFO - 2016-08-24 15:59:06 --> Controller Class Initialized
INFO - 2016-08-24 15:59:06 --> Model Class Initialized
DEBUG - 2016-08-24 15:59:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 15:59:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 15:59:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 15:59:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 15:59:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 15:59:06 --> Final output sent to browser
DEBUG - 2016-08-24 15:59:06 --> Total execution time: 0.5700
INFO - 2016-08-24 15:59:09 --> Config Class Initialized
INFO - 2016-08-24 15:59:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:59:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:59:09 --> Utf8 Class Initialized
INFO - 2016-08-24 15:59:09 --> URI Class Initialized
INFO - 2016-08-24 15:59:09 --> Router Class Initialized
INFO - 2016-08-24 15:59:09 --> Output Class Initialized
INFO - 2016-08-24 15:59:09 --> Security Class Initialized
DEBUG - 2016-08-24 15:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:59:09 --> Input Class Initialized
INFO - 2016-08-24 15:59:09 --> Language Class Initialized
INFO - 2016-08-24 15:59:09 --> Loader Class Initialized
INFO - 2016-08-24 15:59:10 --> Helper loaded: url_helper
INFO - 2016-08-24 15:59:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:59:10 --> Helper loaded: html_helper
INFO - 2016-08-24 15:59:10 --> Helper loaded: form_helper
INFO - 2016-08-24 15:59:10 --> Helper loaded: file_helper
INFO - 2016-08-24 15:59:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:59:10 --> Database Driver Class Initialized
INFO - 2016-08-24 15:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:59:10 --> Form Validation Class Initialized
INFO - 2016-08-24 15:59:10 --> Email Class Initialized
INFO - 2016-08-24 15:59:10 --> Controller Class Initialized
INFO - 2016-08-24 15:59:10 --> Model Class Initialized
INFO - 2016-08-24 15:59:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 15:59:10 --> Final output sent to browser
DEBUG - 2016-08-24 15:59:10 --> Total execution time: 0.5360
INFO - 2016-08-24 15:59:13 --> Config Class Initialized
INFO - 2016-08-24 15:59:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 15:59:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 15:59:13 --> Utf8 Class Initialized
INFO - 2016-08-24 15:59:13 --> URI Class Initialized
INFO - 2016-08-24 15:59:13 --> Router Class Initialized
INFO - 2016-08-24 15:59:13 --> Output Class Initialized
INFO - 2016-08-24 15:59:13 --> Security Class Initialized
DEBUG - 2016-08-24 15:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 15:59:13 --> Input Class Initialized
INFO - 2016-08-24 15:59:13 --> Language Class Initialized
INFO - 2016-08-24 15:59:13 --> Loader Class Initialized
INFO - 2016-08-24 15:59:13 --> Helper loaded: url_helper
INFO - 2016-08-24 15:59:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 15:59:13 --> Helper loaded: html_helper
INFO - 2016-08-24 15:59:13 --> Helper loaded: form_helper
INFO - 2016-08-24 15:59:13 --> Helper loaded: file_helper
INFO - 2016-08-24 15:59:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 15:59:13 --> Database Driver Class Initialized
INFO - 2016-08-24 15:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 15:59:14 --> Form Validation Class Initialized
INFO - 2016-08-24 15:59:14 --> Email Class Initialized
INFO - 2016-08-24 15:59:14 --> Controller Class Initialized
INFO - 2016-08-24 15:59:14 --> Model Class Initialized
ERROR - 2016-08-24 15:59:15 --> Query error: Unknown column 'logged_in' in 'field list' - Invalid query: UPDATE `users` SET `oauth_provider` = 'google', `oauth_uid` = '117790144900062576188', `firstname` = 'Ou', `lastname` = 'Sophea', `email` = 'ousophea@gmail.com', `gender` = 'male', `locale` = 'en', `profile_url` = 'https://plus.google.com/+OuSophea', `picture_url` = 'https://lh6.googleusercontent.com/-OjehdSSfkR0/AAAAAAAAAAI/AAAAAAAAKmI/ODO_qGr3tBU/photo.jpg', `logged_in` = 1, `modified` = '2016-08-24 15:59:15'
WHERE `id` = '10'
INFO - 2016-08-24 15:59:15 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-24 16:00:22 --> Config Class Initialized
INFO - 2016-08-24 16:00:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:22 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:22 --> URI Class Initialized
INFO - 2016-08-24 16:00:22 --> Router Class Initialized
INFO - 2016-08-24 16:00:22 --> Output Class Initialized
INFO - 2016-08-24 16:00:22 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:23 --> Input Class Initialized
INFO - 2016-08-24 16:00:23 --> Language Class Initialized
INFO - 2016-08-24 16:00:23 --> Loader Class Initialized
INFO - 2016-08-24 16:00:23 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:23 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:23 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:23 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:23 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:23 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:23 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:23 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:23 --> Email Class Initialized
INFO - 2016-08-24 16:00:23 --> Controller Class Initialized
INFO - 2016-08-24 16:00:23 --> Model Class Initialized
ERROR - 2016-08-24 16:00:23 --> Severity: error --> Exception: Error fetching OAuth2 access token, message: 'invalid_grant' D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\auth\Google_OAuth2.php 113
INFO - 2016-08-24 16:00:29 --> Config Class Initialized
INFO - 2016-08-24 16:00:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:29 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:29 --> URI Class Initialized
INFO - 2016-08-24 16:00:29 --> Router Class Initialized
INFO - 2016-08-24 16:00:29 --> Output Class Initialized
INFO - 2016-08-24 16:00:29 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:29 --> Input Class Initialized
INFO - 2016-08-24 16:00:29 --> Language Class Initialized
INFO - 2016-08-24 16:00:29 --> Loader Class Initialized
INFO - 2016-08-24 16:00:29 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:29 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:29 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:29 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:29 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:29 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:29 --> Email Class Initialized
INFO - 2016-08-24 16:00:29 --> Controller Class Initialized
INFO - 2016-08-24 16:00:29 --> Model Class Initialized
INFO - 2016-08-24 16:00:31 --> Config Class Initialized
INFO - 2016-08-24 16:00:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:31 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:31 --> URI Class Initialized
INFO - 2016-08-24 16:00:31 --> Router Class Initialized
INFO - 2016-08-24 16:00:31 --> Output Class Initialized
INFO - 2016-08-24 16:00:31 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:31 --> Input Class Initialized
INFO - 2016-08-24 16:00:31 --> Language Class Initialized
INFO - 2016-08-24 16:00:31 --> Loader Class Initialized
INFO - 2016-08-24 16:00:31 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:31 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:31 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:31 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:31 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:31 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:31 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:31 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:31 --> Email Class Initialized
INFO - 2016-08-24 16:00:31 --> Controller Class Initialized
INFO - 2016-08-24 16:00:31 --> Config Class Initialized
INFO - 2016-08-24 16:00:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:31 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:31 --> URI Class Initialized
INFO - 2016-08-24 16:00:31 --> Router Class Initialized
INFO - 2016-08-24 16:00:31 --> Output Class Initialized
INFO - 2016-08-24 16:00:31 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:32 --> Input Class Initialized
INFO - 2016-08-24 16:00:32 --> Language Class Initialized
INFO - 2016-08-24 16:00:32 --> Loader Class Initialized
INFO - 2016-08-24 16:00:32 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:32 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:32 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:32 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:32 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:32 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:32 --> Email Class Initialized
INFO - 2016-08-24 16:00:32 --> Controller Class Initialized
INFO - 2016-08-24 16:00:32 --> Model Class Initialized
DEBUG - 2016-08-24 16:00:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:00:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:00:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:00:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:00:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:00:32 --> Final output sent to browser
DEBUG - 2016-08-24 16:00:32 --> Total execution time: 0.6690
INFO - 2016-08-24 16:00:35 --> Config Class Initialized
INFO - 2016-08-24 16:00:35 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:35 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:35 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:35 --> URI Class Initialized
INFO - 2016-08-24 16:00:35 --> Router Class Initialized
INFO - 2016-08-24 16:00:35 --> Output Class Initialized
INFO - 2016-08-24 16:00:35 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:36 --> Input Class Initialized
INFO - 2016-08-24 16:00:36 --> Language Class Initialized
INFO - 2016-08-24 16:00:36 --> Loader Class Initialized
INFO - 2016-08-24 16:00:36 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:36 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:36 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:36 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:36 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:36 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:36 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:36 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:36 --> Email Class Initialized
INFO - 2016-08-24 16:00:36 --> Controller Class Initialized
INFO - 2016-08-24 16:00:36 --> Model Class Initialized
INFO - 2016-08-24 16:00:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:00:36 --> Final output sent to browser
DEBUG - 2016-08-24 16:00:36 --> Total execution time: 0.4953
INFO - 2016-08-24 16:00:39 --> Config Class Initialized
INFO - 2016-08-24 16:00:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:39 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:39 --> URI Class Initialized
INFO - 2016-08-24 16:00:39 --> Router Class Initialized
INFO - 2016-08-24 16:00:39 --> Output Class Initialized
INFO - 2016-08-24 16:00:39 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:39 --> Input Class Initialized
INFO - 2016-08-24 16:00:39 --> Language Class Initialized
INFO - 2016-08-24 16:00:39 --> Loader Class Initialized
INFO - 2016-08-24 16:00:39 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:39 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:39 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:39 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:39 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:39 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:39 --> Email Class Initialized
INFO - 2016-08-24 16:00:39 --> Controller Class Initialized
INFO - 2016-08-24 16:00:39 --> Model Class Initialized
INFO - 2016-08-24 16:00:41 --> Config Class Initialized
INFO - 2016-08-24 16:00:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:41 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:41 --> URI Class Initialized
INFO - 2016-08-24 16:00:41 --> Router Class Initialized
INFO - 2016-08-24 16:00:41 --> Output Class Initialized
INFO - 2016-08-24 16:00:41 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:41 --> Input Class Initialized
INFO - 2016-08-24 16:00:41 --> Language Class Initialized
INFO - 2016-08-24 16:00:41 --> Loader Class Initialized
INFO - 2016-08-24 16:00:41 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:41 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:41 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:41 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:41 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:41 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:41 --> Email Class Initialized
INFO - 2016-08-24 16:00:41 --> Controller Class Initialized
INFO - 2016-08-24 16:00:41 --> Config Class Initialized
INFO - 2016-08-24 16:00:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:00:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:00:42 --> Utf8 Class Initialized
INFO - 2016-08-24 16:00:42 --> URI Class Initialized
INFO - 2016-08-24 16:00:42 --> Router Class Initialized
INFO - 2016-08-24 16:00:42 --> Output Class Initialized
INFO - 2016-08-24 16:00:42 --> Security Class Initialized
DEBUG - 2016-08-24 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:00:42 --> Input Class Initialized
INFO - 2016-08-24 16:00:42 --> Language Class Initialized
INFO - 2016-08-24 16:00:42 --> Loader Class Initialized
INFO - 2016-08-24 16:00:42 --> Helper loaded: url_helper
INFO - 2016-08-24 16:00:42 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:00:42 --> Helper loaded: html_helper
INFO - 2016-08-24 16:00:42 --> Helper loaded: form_helper
INFO - 2016-08-24 16:00:42 --> Helper loaded: file_helper
INFO - 2016-08-24 16:00:42 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:00:42 --> Database Driver Class Initialized
INFO - 2016-08-24 16:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:00:42 --> Form Validation Class Initialized
INFO - 2016-08-24 16:00:42 --> Email Class Initialized
INFO - 2016-08-24 16:00:42 --> Controller Class Initialized
INFO - 2016-08-24 16:00:42 --> Model Class Initialized
DEBUG - 2016-08-24 16:00:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:00:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:00:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:00:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:00:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:00:42 --> Final output sent to browser
DEBUG - 2016-08-24 16:00:42 --> Total execution time: 0.5476
INFO - 2016-08-24 16:01:30 --> Config Class Initialized
INFO - 2016-08-24 16:01:30 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:01:30 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:01:30 --> Utf8 Class Initialized
INFO - 2016-08-24 16:01:30 --> URI Class Initialized
INFO - 2016-08-24 16:01:30 --> Router Class Initialized
INFO - 2016-08-24 16:01:30 --> Output Class Initialized
INFO - 2016-08-24 16:01:30 --> Security Class Initialized
DEBUG - 2016-08-24 16:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:01:30 --> Input Class Initialized
INFO - 2016-08-24 16:01:30 --> Language Class Initialized
INFO - 2016-08-24 16:01:31 --> Loader Class Initialized
INFO - 2016-08-24 16:01:31 --> Helper loaded: url_helper
INFO - 2016-08-24 16:01:31 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:01:31 --> Helper loaded: html_helper
INFO - 2016-08-24 16:01:31 --> Helper loaded: form_helper
INFO - 2016-08-24 16:01:31 --> Helper loaded: file_helper
INFO - 2016-08-24 16:01:31 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:01:31 --> Database Driver Class Initialized
INFO - 2016-08-24 16:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:01:31 --> Form Validation Class Initialized
INFO - 2016-08-24 16:01:31 --> Email Class Initialized
INFO - 2016-08-24 16:01:31 --> Controller Class Initialized
INFO - 2016-08-24 16:01:31 --> Model Class Initialized
DEBUG - 2016-08-24 16:01:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:01:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:01:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:01:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:01:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:01:31 --> Final output sent to browser
DEBUG - 2016-08-24 16:01:31 --> Total execution time: 0.5693
INFO - 2016-08-24 16:01:33 --> Config Class Initialized
INFO - 2016-08-24 16:01:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:01:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:01:34 --> Utf8 Class Initialized
INFO - 2016-08-24 16:01:34 --> URI Class Initialized
INFO - 2016-08-24 16:01:34 --> Router Class Initialized
INFO - 2016-08-24 16:01:34 --> Output Class Initialized
INFO - 2016-08-24 16:01:34 --> Security Class Initialized
DEBUG - 2016-08-24 16:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:01:34 --> Input Class Initialized
INFO - 2016-08-24 16:01:34 --> Language Class Initialized
INFO - 2016-08-24 16:01:34 --> Loader Class Initialized
INFO - 2016-08-24 16:01:34 --> Helper loaded: url_helper
INFO - 2016-08-24 16:01:34 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:01:34 --> Helper loaded: html_helper
INFO - 2016-08-24 16:01:34 --> Helper loaded: form_helper
INFO - 2016-08-24 16:01:34 --> Helper loaded: file_helper
INFO - 2016-08-24 16:01:34 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:01:34 --> Database Driver Class Initialized
INFO - 2016-08-24 16:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:01:34 --> Form Validation Class Initialized
INFO - 2016-08-24 16:01:34 --> Email Class Initialized
INFO - 2016-08-24 16:01:34 --> Controller Class Initialized
INFO - 2016-08-24 16:01:34 --> Model Class Initialized
INFO - 2016-08-24 16:01:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:01:34 --> Final output sent to browser
DEBUG - 2016-08-24 16:01:34 --> Total execution time: 0.6510
INFO - 2016-08-24 16:01:37 --> Config Class Initialized
INFO - 2016-08-24 16:01:37 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:01:37 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:01:37 --> Utf8 Class Initialized
INFO - 2016-08-24 16:01:37 --> URI Class Initialized
INFO - 2016-08-24 16:01:37 --> Router Class Initialized
INFO - 2016-08-24 16:01:37 --> Output Class Initialized
INFO - 2016-08-24 16:01:37 --> Security Class Initialized
DEBUG - 2016-08-24 16:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:01:37 --> Input Class Initialized
INFO - 2016-08-24 16:01:37 --> Language Class Initialized
INFO - 2016-08-24 16:01:37 --> Loader Class Initialized
INFO - 2016-08-24 16:01:37 --> Helper loaded: url_helper
INFO - 2016-08-24 16:01:37 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:01:37 --> Helper loaded: html_helper
INFO - 2016-08-24 16:01:37 --> Helper loaded: form_helper
INFO - 2016-08-24 16:01:37 --> Helper loaded: file_helper
INFO - 2016-08-24 16:01:37 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:01:37 --> Database Driver Class Initialized
INFO - 2016-08-24 16:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:01:37 --> Form Validation Class Initialized
INFO - 2016-08-24 16:01:37 --> Email Class Initialized
INFO - 2016-08-24 16:01:37 --> Controller Class Initialized
INFO - 2016-08-24 16:01:37 --> Model Class Initialized
INFO - 2016-08-24 16:01:39 --> Config Class Initialized
INFO - 2016-08-24 16:01:39 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:01:39 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:01:39 --> Utf8 Class Initialized
INFO - 2016-08-24 16:01:39 --> URI Class Initialized
INFO - 2016-08-24 16:01:39 --> Router Class Initialized
INFO - 2016-08-24 16:01:39 --> Output Class Initialized
INFO - 2016-08-24 16:01:39 --> Security Class Initialized
DEBUG - 2016-08-24 16:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:01:39 --> Input Class Initialized
INFO - 2016-08-24 16:01:39 --> Language Class Initialized
INFO - 2016-08-24 16:01:39 --> Loader Class Initialized
INFO - 2016-08-24 16:01:39 --> Helper loaded: url_helper
INFO - 2016-08-24 16:01:39 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:01:39 --> Helper loaded: html_helper
INFO - 2016-08-24 16:01:39 --> Helper loaded: form_helper
INFO - 2016-08-24 16:01:39 --> Helper loaded: file_helper
INFO - 2016-08-24 16:01:39 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:01:39 --> Database Driver Class Initialized
INFO - 2016-08-24 16:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:01:39 --> Form Validation Class Initialized
INFO - 2016-08-24 16:01:39 --> Email Class Initialized
INFO - 2016-08-24 16:01:39 --> Controller Class Initialized
DEBUG - 2016-08-24 16:01:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 16:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:01:39 --> Model Class Initialized
INFO - 2016-08-24 16:01:39 --> Model Class Initialized
ERROR - 2016-08-24 16:01:39 --> Severity: Notice --> Undefined property: Dashboard::$fullname D:\wamp\www\library.pnc.lan\application\helpers\utils_helper.php 38
ERROR - 2016-08-24 16:01:40 --> Severity: Notice --> Undefined property: Dashboard::$is_admin D:\wamp\www\library.pnc.lan\application\helpers\utils_helper.php 39
ERROR - 2016-08-24 16:01:40 --> Severity: Notice --> Undefined property: Dashboard::$user_id D:\wamp\www\library.pnc.lan\application\helpers\utils_helper.php 40
ERROR - 2016-08-24 16:01:40 --> Severity: Notice --> Undefined property: Dashboard::$login D:\wamp\www\library.pnc.lan\application\helpers\utils_helper.php 41
INFO - 2016-08-24 16:01:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:01:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:01:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 16:01:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:01:40 --> Final output sent to browser
DEBUG - 2016-08-24 16:01:40 --> Total execution time: 1.0330
INFO - 2016-08-24 16:12:01 --> Config Class Initialized
INFO - 2016-08-24 16:12:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:12:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:12:01 --> Utf8 Class Initialized
INFO - 2016-08-24 16:12:01 --> URI Class Initialized
INFO - 2016-08-24 16:12:01 --> Router Class Initialized
INFO - 2016-08-24 16:12:01 --> Output Class Initialized
INFO - 2016-08-24 16:12:01 --> Security Class Initialized
DEBUG - 2016-08-24 16:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:12:01 --> Input Class Initialized
INFO - 2016-08-24 16:12:01 --> Language Class Initialized
INFO - 2016-08-24 16:12:01 --> Loader Class Initialized
INFO - 2016-08-24 16:12:01 --> Helper loaded: url_helper
INFO - 2016-08-24 16:12:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:12:01 --> Helper loaded: html_helper
INFO - 2016-08-24 16:12:01 --> Helper loaded: form_helper
INFO - 2016-08-24 16:12:01 --> Helper loaded: file_helper
INFO - 2016-08-24 16:12:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:12:01 --> Database Driver Class Initialized
INFO - 2016-08-24 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:12:02 --> Form Validation Class Initialized
INFO - 2016-08-24 16:12:02 --> Email Class Initialized
INFO - 2016-08-24 16:12:02 --> Controller Class Initialized
INFO - 2016-08-24 16:12:02 --> Model Class Initialized
ERROR - 2016-08-24 16:12:03 --> Severity: Notice --> Undefined variable: firstName D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 224
ERROR - 2016-08-24 16:12:03 --> Severity: Notice --> Undefined variable: lastName D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 225
ERROR - 2016-08-24 16:12:03 --> Severity: Notice --> Undefined variable: login D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 226
ERROR - 2016-08-24 16:12:03 --> Severity: Notice --> Undefined variable: email D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 227
ERROR - 2016-08-24 16:12:03 --> Query error: Column 'email' cannot be null - Invalid query: INSERT INTO `users` (`firstname`, `lastname`, `login`, `email`, `password`, `role`) VALUES (NULL, NULL, NULL, NULL, '$2a$08$wpdKIkMV5SbiLgdSIVDFfOy0pctaOU/yTNa8GX8fKZWs0oo/IRINe', 2)
INFO - 2016-08-24 16:12:03 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-24 16:17:43 --> Config Class Initialized
INFO - 2016-08-24 16:17:43 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:17:43 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:17:43 --> Utf8 Class Initialized
INFO - 2016-08-24 16:17:43 --> URI Class Initialized
INFO - 2016-08-24 16:17:43 --> Router Class Initialized
INFO - 2016-08-24 16:17:43 --> Output Class Initialized
INFO - 2016-08-24 16:17:43 --> Security Class Initialized
DEBUG - 2016-08-24 16:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:17:43 --> Input Class Initialized
INFO - 2016-08-24 16:17:43 --> Language Class Initialized
INFO - 2016-08-24 16:17:43 --> Loader Class Initialized
INFO - 2016-08-24 16:17:43 --> Helper loaded: url_helper
INFO - 2016-08-24 16:17:43 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:17:43 --> Helper loaded: html_helper
INFO - 2016-08-24 16:17:43 --> Helper loaded: form_helper
INFO - 2016-08-24 16:17:43 --> Helper loaded: file_helper
INFO - 2016-08-24 16:17:43 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:17:43 --> Database Driver Class Initialized
INFO - 2016-08-24 16:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:17:43 --> Form Validation Class Initialized
INFO - 2016-08-24 16:17:43 --> Email Class Initialized
INFO - 2016-08-24 16:17:43 --> Controller Class Initialized
INFO - 2016-08-24 16:17:43 --> Model Class Initialized
INFO - 2016-08-24 16:17:45 --> Config Class Initialized
INFO - 2016-08-24 16:17:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:17:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:17:45 --> Utf8 Class Initialized
INFO - 2016-08-24 16:17:45 --> URI Class Initialized
INFO - 2016-08-24 16:17:45 --> Router Class Initialized
INFO - 2016-08-24 16:17:45 --> Output Class Initialized
INFO - 2016-08-24 16:17:45 --> Security Class Initialized
DEBUG - 2016-08-24 16:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:17:45 --> Input Class Initialized
INFO - 2016-08-24 16:17:45 --> Language Class Initialized
INFO - 2016-08-24 16:17:45 --> Loader Class Initialized
INFO - 2016-08-24 16:17:45 --> Helper loaded: url_helper
INFO - 2016-08-24 16:17:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:17:45 --> Helper loaded: html_helper
INFO - 2016-08-24 16:17:45 --> Helper loaded: form_helper
INFO - 2016-08-24 16:17:45 --> Helper loaded: file_helper
INFO - 2016-08-24 16:17:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:17:45 --> Database Driver Class Initialized
INFO - 2016-08-24 16:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:17:45 --> Form Validation Class Initialized
INFO - 2016-08-24 16:17:45 --> Email Class Initialized
INFO - 2016-08-24 16:17:45 --> Controller Class Initialized
DEBUG - 2016-08-24 16:17:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 16:17:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:17:45 --> Model Class Initialized
INFO - 2016-08-24 16:17:45 --> Model Class Initialized
INFO - 2016-08-24 16:17:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:17:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:17:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 16:17:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:17:45 --> Final output sent to browser
DEBUG - 2016-08-24 16:17:45 --> Total execution time: 0.7174
INFO - 2016-08-24 16:19:12 --> Config Class Initialized
INFO - 2016-08-24 16:19:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:19:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:19:12 --> Utf8 Class Initialized
INFO - 2016-08-24 16:19:12 --> URI Class Initialized
INFO - 2016-08-24 16:19:12 --> Router Class Initialized
INFO - 2016-08-24 16:19:12 --> Output Class Initialized
INFO - 2016-08-24 16:19:12 --> Security Class Initialized
DEBUG - 2016-08-24 16:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:19:12 --> Input Class Initialized
INFO - 2016-08-24 16:19:12 --> Language Class Initialized
INFO - 2016-08-24 16:19:12 --> Loader Class Initialized
INFO - 2016-08-24 16:19:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:19:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:19:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:19:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:19:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:19:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:19:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:19:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:19:12 --> Email Class Initialized
INFO - 2016-08-24 16:19:12 --> Controller Class Initialized
INFO - 2016-08-24 16:19:12 --> Model Class Initialized
INFO - 2016-08-24 16:19:14 --> Config Class Initialized
INFO - 2016-08-24 16:19:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:19:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:19:14 --> Utf8 Class Initialized
INFO - 2016-08-24 16:19:14 --> URI Class Initialized
INFO - 2016-08-24 16:19:14 --> Router Class Initialized
INFO - 2016-08-24 16:19:14 --> Output Class Initialized
INFO - 2016-08-24 16:19:14 --> Security Class Initialized
DEBUG - 2016-08-24 16:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:19:14 --> Input Class Initialized
INFO - 2016-08-24 16:19:14 --> Language Class Initialized
INFO - 2016-08-24 16:19:14 --> Loader Class Initialized
INFO - 2016-08-24 16:19:14 --> Helper loaded: url_helper
INFO - 2016-08-24 16:19:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:19:14 --> Helper loaded: html_helper
INFO - 2016-08-24 16:19:14 --> Helper loaded: form_helper
INFO - 2016-08-24 16:19:14 --> Helper loaded: file_helper
INFO - 2016-08-24 16:19:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:19:14 --> Database Driver Class Initialized
INFO - 2016-08-24 16:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:19:14 --> Form Validation Class Initialized
INFO - 2016-08-24 16:19:14 --> Email Class Initialized
INFO - 2016-08-24 16:19:14 --> Controller Class Initialized
DEBUG - 2016-08-24 16:19:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 16:19:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:19:14 --> Model Class Initialized
INFO - 2016-08-24 16:19:14 --> Model Class Initialized
INFO - 2016-08-24 16:19:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:19:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:19:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 16:19:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:19:15 --> Final output sent to browser
DEBUG - 2016-08-24 16:19:15 --> Total execution time: 0.7276
INFO - 2016-08-24 16:24:02 --> Config Class Initialized
INFO - 2016-08-24 16:24:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:02 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:02 --> URI Class Initialized
INFO - 2016-08-24 16:24:02 --> Router Class Initialized
INFO - 2016-08-24 16:24:02 --> Output Class Initialized
INFO - 2016-08-24 16:24:02 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:02 --> Input Class Initialized
INFO - 2016-08-24 16:24:02 --> Language Class Initialized
INFO - 2016-08-24 16:24:02 --> Loader Class Initialized
INFO - 2016-08-24 16:24:02 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:02 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:02 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:02 --> Email Class Initialized
INFO - 2016-08-24 16:24:02 --> Controller Class Initialized
INFO - 2016-08-24 16:24:02 --> Model Class Initialized
INFO - 2016-08-24 16:24:02 --> Config Class Initialized
INFO - 2016-08-24 16:24:02 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:02 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:02 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:02 --> URI Class Initialized
INFO - 2016-08-24 16:24:02 --> Router Class Initialized
INFO - 2016-08-24 16:24:02 --> Output Class Initialized
INFO - 2016-08-24 16:24:02 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:02 --> Input Class Initialized
INFO - 2016-08-24 16:24:02 --> Language Class Initialized
INFO - 2016-08-24 16:24:02 --> Loader Class Initialized
INFO - 2016-08-24 16:24:02 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:02 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:03 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:03 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:03 --> Email Class Initialized
INFO - 2016-08-24 16:24:03 --> Controller Class Initialized
INFO - 2016-08-24 16:24:03 --> Model Class Initialized
DEBUG - 2016-08-24 16:24:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:24:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:24:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:24:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:03 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:03 --> Total execution time: 0.5961
INFO - 2016-08-24 16:24:05 --> Config Class Initialized
INFO - 2016-08-24 16:24:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:05 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:05 --> URI Class Initialized
INFO - 2016-08-24 16:24:05 --> Router Class Initialized
INFO - 2016-08-24 16:24:05 --> Output Class Initialized
INFO - 2016-08-24 16:24:05 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:05 --> Input Class Initialized
INFO - 2016-08-24 16:24:05 --> Language Class Initialized
INFO - 2016-08-24 16:24:05 --> Loader Class Initialized
INFO - 2016-08-24 16:24:05 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:05 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:05 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:05 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:05 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:05 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:05 --> Email Class Initialized
INFO - 2016-08-24 16:24:05 --> Controller Class Initialized
INFO - 2016-08-24 16:24:05 --> Model Class Initialized
INFO - 2016-08-24 16:24:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:24:05 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:05 --> Total execution time: 0.5268
INFO - 2016-08-24 16:24:09 --> Config Class Initialized
INFO - 2016-08-24 16:24:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:09 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:09 --> URI Class Initialized
INFO - 2016-08-24 16:24:09 --> Router Class Initialized
INFO - 2016-08-24 16:24:09 --> Output Class Initialized
INFO - 2016-08-24 16:24:09 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:09 --> Input Class Initialized
INFO - 2016-08-24 16:24:09 --> Language Class Initialized
INFO - 2016-08-24 16:24:09 --> Loader Class Initialized
INFO - 2016-08-24 16:24:09 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:09 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:09 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:09 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:09 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:09 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:09 --> Email Class Initialized
INFO - 2016-08-24 16:24:09 --> Controller Class Initialized
INFO - 2016-08-24 16:24:09 --> Model Class Initialized
INFO - 2016-08-24 16:24:11 --> Config Class Initialized
INFO - 2016-08-24 16:24:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:11 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:11 --> URI Class Initialized
DEBUG - 2016-08-24 16:24:11 --> No URI present. Default controller set.
INFO - 2016-08-24 16:24:11 --> Router Class Initialized
INFO - 2016-08-24 16:24:11 --> Output Class Initialized
INFO - 2016-08-24 16:24:11 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:11 --> Input Class Initialized
INFO - 2016-08-24 16:24:11 --> Language Class Initialized
INFO - 2016-08-24 16:24:11 --> Loader Class Initialized
INFO - 2016-08-24 16:24:11 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:11 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:11 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:11 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:11 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:12 --> Email Class Initialized
INFO - 2016-08-24 16:24:12 --> Controller Class Initialized
INFO - 2016-08-24 16:24:12 --> Config Class Initialized
INFO - 2016-08-24 16:24:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:12 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:12 --> URI Class Initialized
INFO - 2016-08-24 16:24:12 --> Router Class Initialized
INFO - 2016-08-24 16:24:12 --> Output Class Initialized
INFO - 2016-08-24 16:24:12 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:12 --> Input Class Initialized
INFO - 2016-08-24 16:24:12 --> Language Class Initialized
INFO - 2016-08-24 16:24:12 --> Loader Class Initialized
INFO - 2016-08-24 16:24:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:12 --> Email Class Initialized
INFO - 2016-08-24 16:24:12 --> Controller Class Initialized
INFO - 2016-08-24 16:24:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:24:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:24:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:12 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:12 --> Total execution time: 0.6832
INFO - 2016-08-24 16:24:18 --> Config Class Initialized
INFO - 2016-08-24 16:24:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:18 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:18 --> URI Class Initialized
INFO - 2016-08-24 16:24:18 --> Router Class Initialized
INFO - 2016-08-24 16:24:18 --> Output Class Initialized
INFO - 2016-08-24 16:24:18 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:18 --> Input Class Initialized
INFO - 2016-08-24 16:24:18 --> Language Class Initialized
INFO - 2016-08-24 16:24:18 --> Loader Class Initialized
INFO - 2016-08-24 16:24:18 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:18 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:18 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:18 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:18 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:18 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:18 --> Email Class Initialized
INFO - 2016-08-24 16:24:18 --> Controller Class Initialized
DEBUG - 2016-08-24 16:24:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:24:18 --> Model Class Initialized
INFO - 2016-08-24 16:24:18 --> Model Class Initialized
INFO - 2016-08-24 16:24:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:24:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-24 16:24:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:19 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:19 --> Total execution time: 0.8956
INFO - 2016-08-24 16:24:21 --> Config Class Initialized
INFO - 2016-08-24 16:24:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:21 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:21 --> URI Class Initialized
INFO - 2016-08-24 16:24:21 --> Router Class Initialized
INFO - 2016-08-24 16:24:21 --> Output Class Initialized
INFO - 2016-08-24 16:24:21 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:21 --> Input Class Initialized
INFO - 2016-08-24 16:24:21 --> Language Class Initialized
INFO - 2016-08-24 16:24:21 --> Loader Class Initialized
INFO - 2016-08-24 16:24:21 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:21 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:21 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:21 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:21 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:21 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:21 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:21 --> Email Class Initialized
INFO - 2016-08-24 16:24:21 --> Controller Class Initialized
DEBUG - 2016-08-24 16:24:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:24:21 --> Model Class Initialized
INFO - 2016-08-24 16:24:21 --> Model Class Initialized
INFO - 2016-08-24 16:24:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:24:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 16:24:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:21 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:21 --> Total execution time: 0.7080
INFO - 2016-08-24 16:24:45 --> Config Class Initialized
INFO - 2016-08-24 16:24:45 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:45 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:45 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:45 --> URI Class Initialized
INFO - 2016-08-24 16:24:45 --> Router Class Initialized
INFO - 2016-08-24 16:24:45 --> Output Class Initialized
INFO - 2016-08-24 16:24:45 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:45 --> Input Class Initialized
INFO - 2016-08-24 16:24:45 --> Language Class Initialized
INFO - 2016-08-24 16:24:45 --> Loader Class Initialized
INFO - 2016-08-24 16:24:45 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:45 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:45 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:45 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:45 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:45 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:45 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:46 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:46 --> Email Class Initialized
INFO - 2016-08-24 16:24:46 --> Controller Class Initialized
INFO - 2016-08-24 16:24:46 --> Model Class Initialized
INFO - 2016-08-24 16:24:46 --> Config Class Initialized
INFO - 2016-08-24 16:24:46 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:46 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:46 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:46 --> URI Class Initialized
INFO - 2016-08-24 16:24:46 --> Router Class Initialized
INFO - 2016-08-24 16:24:46 --> Output Class Initialized
INFO - 2016-08-24 16:24:46 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:46 --> Input Class Initialized
INFO - 2016-08-24 16:24:46 --> Language Class Initialized
INFO - 2016-08-24 16:24:46 --> Loader Class Initialized
INFO - 2016-08-24 16:24:46 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:46 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:46 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:46 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:46 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:46 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:46 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:46 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:46 --> Email Class Initialized
INFO - 2016-08-24 16:24:46 --> Controller Class Initialized
INFO - 2016-08-24 16:24:46 --> Model Class Initialized
DEBUG - 2016-08-24 16:24:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:24:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:24:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:24:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:46 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:46 --> Total execution time: 0.7572
INFO - 2016-08-24 16:24:49 --> Config Class Initialized
INFO - 2016-08-24 16:24:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:49 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:49 --> URI Class Initialized
INFO - 2016-08-24 16:24:49 --> Router Class Initialized
INFO - 2016-08-24 16:24:49 --> Output Class Initialized
INFO - 2016-08-24 16:24:49 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:49 --> Input Class Initialized
INFO - 2016-08-24 16:24:49 --> Language Class Initialized
INFO - 2016-08-24 16:24:49 --> Loader Class Initialized
INFO - 2016-08-24 16:24:49 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:49 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:49 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:49 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:49 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:49 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:49 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:49 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:49 --> Email Class Initialized
INFO - 2016-08-24 16:24:49 --> Controller Class Initialized
INFO - 2016-08-24 16:24:49 --> Model Class Initialized
INFO - 2016-08-24 16:24:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:24:49 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:49 --> Total execution time: 0.5126
INFO - 2016-08-24 16:24:53 --> Config Class Initialized
INFO - 2016-08-24 16:24:53 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:53 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:53 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:53 --> URI Class Initialized
INFO - 2016-08-24 16:24:53 --> Router Class Initialized
INFO - 2016-08-24 16:24:53 --> Output Class Initialized
INFO - 2016-08-24 16:24:53 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:53 --> Input Class Initialized
INFO - 2016-08-24 16:24:53 --> Language Class Initialized
INFO - 2016-08-24 16:24:53 --> Loader Class Initialized
INFO - 2016-08-24 16:24:53 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:53 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:53 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:53 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:53 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:53 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:53 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:54 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:54 --> Email Class Initialized
INFO - 2016-08-24 16:24:54 --> Controller Class Initialized
INFO - 2016-08-24 16:24:54 --> Model Class Initialized
INFO - 2016-08-24 16:24:55 --> Config Class Initialized
INFO - 2016-08-24 16:24:55 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:55 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:55 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:55 --> URI Class Initialized
DEBUG - 2016-08-24 16:24:55 --> No URI present. Default controller set.
INFO - 2016-08-24 16:24:55 --> Router Class Initialized
INFO - 2016-08-24 16:24:55 --> Output Class Initialized
INFO - 2016-08-24 16:24:55 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:55 --> Input Class Initialized
INFO - 2016-08-24 16:24:55 --> Language Class Initialized
INFO - 2016-08-24 16:24:56 --> Loader Class Initialized
INFO - 2016-08-24 16:24:56 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:56 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:56 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:56 --> Email Class Initialized
INFO - 2016-08-24 16:24:56 --> Controller Class Initialized
INFO - 2016-08-24 16:24:56 --> Config Class Initialized
INFO - 2016-08-24 16:24:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:24:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:24:56 --> Utf8 Class Initialized
INFO - 2016-08-24 16:24:56 --> URI Class Initialized
INFO - 2016-08-24 16:24:56 --> Router Class Initialized
INFO - 2016-08-24 16:24:56 --> Output Class Initialized
INFO - 2016-08-24 16:24:56 --> Security Class Initialized
DEBUG - 2016-08-24 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:24:56 --> Input Class Initialized
INFO - 2016-08-24 16:24:56 --> Language Class Initialized
INFO - 2016-08-24 16:24:56 --> Loader Class Initialized
INFO - 2016-08-24 16:24:56 --> Helper loaded: url_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: html_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: form_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: file_helper
INFO - 2016-08-24 16:24:56 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:24:56 --> Database Driver Class Initialized
INFO - 2016-08-24 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:24:56 --> Form Validation Class Initialized
INFO - 2016-08-24 16:24:56 --> Email Class Initialized
INFO - 2016-08-24 16:24:56 --> Controller Class Initialized
INFO - 2016-08-24 16:24:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:24:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:24:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:24:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:24:56 --> Final output sent to browser
DEBUG - 2016-08-24 16:24:56 --> Total execution time: 0.5393
INFO - 2016-08-24 16:25:00 --> Config Class Initialized
INFO - 2016-08-24 16:25:00 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:00 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:00 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:00 --> URI Class Initialized
INFO - 2016-08-24 16:25:00 --> Router Class Initialized
INFO - 2016-08-24 16:25:00 --> Output Class Initialized
INFO - 2016-08-24 16:25:00 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:00 --> Input Class Initialized
INFO - 2016-08-24 16:25:00 --> Language Class Initialized
INFO - 2016-08-24 16:25:00 --> Loader Class Initialized
INFO - 2016-08-24 16:25:00 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:00 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:00 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:00 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:00 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:00 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:00 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:01 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:01 --> Email Class Initialized
INFO - 2016-08-24 16:25:01 --> Controller Class Initialized
DEBUG - 2016-08-24 16:25:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:25:01 --> Model Class Initialized
INFO - 2016-08-24 16:25:01 --> Model Class Initialized
INFO - 2016-08-24 16:25:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 16:25:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:01 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:01 --> Total execution time: 0.6339
INFO - 2016-08-24 16:25:05 --> Config Class Initialized
INFO - 2016-08-24 16:25:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:05 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:05 --> URI Class Initialized
INFO - 2016-08-24 16:25:05 --> Router Class Initialized
INFO - 2016-08-24 16:25:05 --> Output Class Initialized
INFO - 2016-08-24 16:25:05 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:05 --> Input Class Initialized
INFO - 2016-08-24 16:25:05 --> Language Class Initialized
INFO - 2016-08-24 16:25:05 --> Loader Class Initialized
INFO - 2016-08-24 16:25:05 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:05 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:05 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:05 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:05 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:05 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:05 --> Email Class Initialized
INFO - 2016-08-24 16:25:05 --> Controller Class Initialized
DEBUG - 2016-08-24 16:25:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:25:05 --> Model Class Initialized
INFO - 2016-08-24 16:25:05 --> Model Class Initialized
INFO - 2016-08-24 16:25:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-24 16:25:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:06 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:06 --> Total execution time: 0.6162
INFO - 2016-08-24 16:25:09 --> Config Class Initialized
INFO - 2016-08-24 16:25:09 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:09 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:09 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:09 --> URI Class Initialized
INFO - 2016-08-24 16:25:09 --> Router Class Initialized
INFO - 2016-08-24 16:25:09 --> Output Class Initialized
INFO - 2016-08-24 16:25:09 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:09 --> Input Class Initialized
INFO - 2016-08-24 16:25:09 --> Language Class Initialized
INFO - 2016-08-24 16:25:09 --> Loader Class Initialized
INFO - 2016-08-24 16:25:09 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:09 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:09 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:09 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:09 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:09 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:09 --> Email Class Initialized
INFO - 2016-08-24 16:25:09 --> Controller Class Initialized
INFO - 2016-08-24 16:25:09 --> Model Class Initialized
INFO - 2016-08-24 16:25:09 --> Model Class Initialized
INFO - 2016-08-24 16:25:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-24 16:25:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:10 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:10 --> Total execution time: 0.7584
INFO - 2016-08-24 16:25:11 --> Config Class Initialized
INFO - 2016-08-24 16:25:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:11 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:11 --> URI Class Initialized
INFO - 2016-08-24 16:25:11 --> Router Class Initialized
INFO - 2016-08-24 16:25:12 --> Output Class Initialized
INFO - 2016-08-24 16:25:12 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:12 --> Input Class Initialized
INFO - 2016-08-24 16:25:12 --> Language Class Initialized
INFO - 2016-08-24 16:25:12 --> Loader Class Initialized
INFO - 2016-08-24 16:25:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:12 --> Email Class Initialized
INFO - 2016-08-24 16:25:12 --> Controller Class Initialized
INFO - 2016-08-24 16:25:12 --> Config Class Initialized
INFO - 2016-08-24 16:25:12 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:12 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:12 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:12 --> URI Class Initialized
INFO - 2016-08-24 16:25:12 --> Router Class Initialized
INFO - 2016-08-24 16:25:12 --> Output Class Initialized
INFO - 2016-08-24 16:25:12 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:12 --> Input Class Initialized
INFO - 2016-08-24 16:25:12 --> Language Class Initialized
INFO - 2016-08-24 16:25:12 --> Loader Class Initialized
INFO - 2016-08-24 16:25:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:12 --> Email Class Initialized
INFO - 2016-08-24 16:25:12 --> Controller Class Initialized
INFO - 2016-08-24 16:25:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:25:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:12 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:12 --> Total execution time: 0.5446
INFO - 2016-08-24 16:25:17 --> Config Class Initialized
INFO - 2016-08-24 16:25:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:17 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:17 --> URI Class Initialized
INFO - 2016-08-24 16:25:17 --> Router Class Initialized
INFO - 2016-08-24 16:25:17 --> Output Class Initialized
INFO - 2016-08-24 16:25:17 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:17 --> Input Class Initialized
INFO - 2016-08-24 16:25:17 --> Language Class Initialized
INFO - 2016-08-24 16:25:18 --> Loader Class Initialized
INFO - 2016-08-24 16:25:18 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:18 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:18 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:18 --> Email Class Initialized
INFO - 2016-08-24 16:25:18 --> Controller Class Initialized
INFO - 2016-08-24 16:25:18 --> Config Class Initialized
INFO - 2016-08-24 16:25:18 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:18 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:18 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:18 --> URI Class Initialized
INFO - 2016-08-24 16:25:18 --> Router Class Initialized
INFO - 2016-08-24 16:25:18 --> Output Class Initialized
INFO - 2016-08-24 16:25:18 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:18 --> Input Class Initialized
INFO - 2016-08-24 16:25:18 --> Language Class Initialized
INFO - 2016-08-24 16:25:18 --> Loader Class Initialized
INFO - 2016-08-24 16:25:18 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:18 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:18 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:18 --> Email Class Initialized
INFO - 2016-08-24 16:25:18 --> Controller Class Initialized
INFO - 2016-08-24 16:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:25:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:18 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:18 --> Total execution time: 0.5469
INFO - 2016-08-24 16:25:40 --> Config Class Initialized
INFO - 2016-08-24 16:25:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:40 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:40 --> URI Class Initialized
INFO - 2016-08-24 16:25:40 --> Router Class Initialized
INFO - 2016-08-24 16:25:40 --> Output Class Initialized
INFO - 2016-08-24 16:25:40 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:40 --> Input Class Initialized
INFO - 2016-08-24 16:25:40 --> Language Class Initialized
INFO - 2016-08-24 16:25:40 --> Loader Class Initialized
INFO - 2016-08-24 16:25:40 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:40 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:40 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:40 --> Email Class Initialized
INFO - 2016-08-24 16:25:40 --> Controller Class Initialized
INFO - 2016-08-24 16:25:40 --> Config Class Initialized
INFO - 2016-08-24 16:25:40 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:25:40 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:25:40 --> Utf8 Class Initialized
INFO - 2016-08-24 16:25:40 --> URI Class Initialized
INFO - 2016-08-24 16:25:40 --> Router Class Initialized
INFO - 2016-08-24 16:25:40 --> Output Class Initialized
INFO - 2016-08-24 16:25:40 --> Security Class Initialized
DEBUG - 2016-08-24 16:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:25:40 --> Input Class Initialized
INFO - 2016-08-24 16:25:40 --> Language Class Initialized
INFO - 2016-08-24 16:25:40 --> Loader Class Initialized
INFO - 2016-08-24 16:25:40 --> Helper loaded: url_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: html_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: form_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: file_helper
INFO - 2016-08-24 16:25:40 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:25:40 --> Database Driver Class Initialized
INFO - 2016-08-24 16:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:25:41 --> Form Validation Class Initialized
INFO - 2016-08-24 16:25:41 --> Email Class Initialized
INFO - 2016-08-24 16:25:41 --> Controller Class Initialized
INFO - 2016-08-24 16:25:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:25:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:25:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:25:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:25:41 --> Final output sent to browser
DEBUG - 2016-08-24 16:25:41 --> Total execution time: 0.6123
INFO - 2016-08-24 16:26:10 --> Config Class Initialized
INFO - 2016-08-24 16:26:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:26:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:26:11 --> Utf8 Class Initialized
INFO - 2016-08-24 16:26:11 --> URI Class Initialized
INFO - 2016-08-24 16:26:11 --> Router Class Initialized
INFO - 2016-08-24 16:26:11 --> Output Class Initialized
INFO - 2016-08-24 16:26:11 --> Security Class Initialized
DEBUG - 2016-08-24 16:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:26:11 --> Input Class Initialized
INFO - 2016-08-24 16:26:11 --> Language Class Initialized
INFO - 2016-08-24 16:26:11 --> Loader Class Initialized
INFO - 2016-08-24 16:26:11 --> Helper loaded: url_helper
INFO - 2016-08-24 16:26:11 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:26:11 --> Helper loaded: html_helper
INFO - 2016-08-24 16:26:11 --> Helper loaded: form_helper
INFO - 2016-08-24 16:26:11 --> Helper loaded: file_helper
INFO - 2016-08-24 16:26:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:26:11 --> Database Driver Class Initialized
INFO - 2016-08-24 16:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:26:11 --> Form Validation Class Initialized
INFO - 2016-08-24 16:26:11 --> Email Class Initialized
INFO - 2016-08-24 16:26:11 --> Controller Class Initialized
INFO - 2016-08-24 16:26:11 --> Model Class Initialized
DEBUG - 2016-08-24 16:26:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:26:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:26:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:26:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 16:26:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:26:11 --> Final output sent to browser
DEBUG - 2016-08-24 16:26:11 --> Total execution time: 0.6565
INFO - 2016-08-24 16:27:03 --> Config Class Initialized
INFO - 2016-08-24 16:27:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:03 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:03 --> URI Class Initialized
INFO - 2016-08-24 16:27:03 --> Router Class Initialized
INFO - 2016-08-24 16:27:04 --> Output Class Initialized
INFO - 2016-08-24 16:27:04 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:04 --> Input Class Initialized
INFO - 2016-08-24 16:27:04 --> Language Class Initialized
INFO - 2016-08-24 16:27:04 --> Loader Class Initialized
INFO - 2016-08-24 16:27:04 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:04 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:04 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:04 --> Email Class Initialized
INFO - 2016-08-24 16:27:04 --> Controller Class Initialized
INFO - 2016-08-24 16:27:04 --> Model Class Initialized
INFO - 2016-08-24 16:27:04 --> Config Class Initialized
INFO - 2016-08-24 16:27:04 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:04 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:04 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:04 --> URI Class Initialized
INFO - 2016-08-24 16:27:04 --> Router Class Initialized
INFO - 2016-08-24 16:27:04 --> Output Class Initialized
INFO - 2016-08-24 16:27:04 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:04 --> Input Class Initialized
INFO - 2016-08-24 16:27:04 --> Language Class Initialized
INFO - 2016-08-24 16:27:04 --> Loader Class Initialized
INFO - 2016-08-24 16:27:04 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:04 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:04 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:04 --> Email Class Initialized
INFO - 2016-08-24 16:27:04 --> Controller Class Initialized
INFO - 2016-08-24 16:27:04 --> Model Class Initialized
DEBUG - 2016-08-24 16:27:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:27:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:27:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:27:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:04 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:05 --> Total execution time: 0.6030
INFO - 2016-08-24 16:27:08 --> Config Class Initialized
INFO - 2016-08-24 16:27:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:08 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:08 --> URI Class Initialized
INFO - 2016-08-24 16:27:08 --> Router Class Initialized
INFO - 2016-08-24 16:27:08 --> Output Class Initialized
INFO - 2016-08-24 16:27:08 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:08 --> Input Class Initialized
INFO - 2016-08-24 16:27:08 --> Language Class Initialized
INFO - 2016-08-24 16:27:08 --> Loader Class Initialized
INFO - 2016-08-24 16:27:08 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:08 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:08 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:08 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:08 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:08 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:08 --> Email Class Initialized
INFO - 2016-08-24 16:27:08 --> Controller Class Initialized
INFO - 2016-08-24 16:27:08 --> Model Class Initialized
INFO - 2016-08-24 16:27:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:27:09 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:09 --> Total execution time: 0.5312
INFO - 2016-08-24 16:27:11 --> Config Class Initialized
INFO - 2016-08-24 16:27:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:11 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:11 --> URI Class Initialized
INFO - 2016-08-24 16:27:11 --> Router Class Initialized
INFO - 2016-08-24 16:27:11 --> Output Class Initialized
INFO - 2016-08-24 16:27:11 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:12 --> Input Class Initialized
INFO - 2016-08-24 16:27:12 --> Language Class Initialized
INFO - 2016-08-24 16:27:12 --> Loader Class Initialized
INFO - 2016-08-24 16:27:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:12 --> Email Class Initialized
INFO - 2016-08-24 16:27:12 --> Controller Class Initialized
INFO - 2016-08-24 16:27:12 --> Model Class Initialized
INFO - 2016-08-24 16:27:14 --> Config Class Initialized
INFO - 2016-08-24 16:27:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:14 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:14 --> URI Class Initialized
DEBUG - 2016-08-24 16:27:14 --> No URI present. Default controller set.
INFO - 2016-08-24 16:27:14 --> Router Class Initialized
INFO - 2016-08-24 16:27:14 --> Output Class Initialized
INFO - 2016-08-24 16:27:14 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:14 --> Input Class Initialized
INFO - 2016-08-24 16:27:14 --> Language Class Initialized
INFO - 2016-08-24 16:27:14 --> Loader Class Initialized
INFO - 2016-08-24 16:27:14 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:14 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:14 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:14 --> Email Class Initialized
INFO - 2016-08-24 16:27:14 --> Controller Class Initialized
INFO - 2016-08-24 16:27:14 --> Config Class Initialized
INFO - 2016-08-24 16:27:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:14 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:14 --> URI Class Initialized
INFO - 2016-08-24 16:27:14 --> Router Class Initialized
INFO - 2016-08-24 16:27:14 --> Output Class Initialized
INFO - 2016-08-24 16:27:14 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:14 --> Input Class Initialized
INFO - 2016-08-24 16:27:14 --> Language Class Initialized
INFO - 2016-08-24 16:27:14 --> Loader Class Initialized
INFO - 2016-08-24 16:27:14 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:14 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:15 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:15 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:15 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:15 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:15 --> Email Class Initialized
INFO - 2016-08-24 16:27:15 --> Controller Class Initialized
INFO - 2016-08-24 16:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:27:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:15 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:15 --> Total execution time: 0.6246
INFO - 2016-08-24 16:27:19 --> Config Class Initialized
INFO - 2016-08-24 16:27:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:19 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:19 --> URI Class Initialized
INFO - 2016-08-24 16:27:19 --> Router Class Initialized
INFO - 2016-08-24 16:27:19 --> Output Class Initialized
INFO - 2016-08-24 16:27:19 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:19 --> Input Class Initialized
INFO - 2016-08-24 16:27:19 --> Language Class Initialized
INFO - 2016-08-24 16:27:19 --> Loader Class Initialized
INFO - 2016-08-24 16:27:19 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:20 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:20 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:20 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:20 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:20 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:20 --> Email Class Initialized
INFO - 2016-08-24 16:27:20 --> Controller Class Initialized
INFO - 2016-08-24 16:27:20 --> Model Class Initialized
DEBUG - 2016-08-24 16:27:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:27:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:27:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 16:27:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:20 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:20 --> Total execution time: 0.5966
INFO - 2016-08-24 16:27:27 --> Config Class Initialized
INFO - 2016-08-24 16:27:27 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:27 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:27 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:27 --> URI Class Initialized
INFO - 2016-08-24 16:27:27 --> Router Class Initialized
INFO - 2016-08-24 16:27:27 --> Output Class Initialized
INFO - 2016-08-24 16:27:28 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:28 --> Input Class Initialized
INFO - 2016-08-24 16:27:28 --> Language Class Initialized
INFO - 2016-08-24 16:27:28 --> Loader Class Initialized
INFO - 2016-08-24 16:27:28 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:28 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:28 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:28 --> Email Class Initialized
INFO - 2016-08-24 16:27:28 --> Controller Class Initialized
INFO - 2016-08-24 16:27:28 --> Model Class Initialized
INFO - 2016-08-24 16:27:28 --> Config Class Initialized
INFO - 2016-08-24 16:27:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:28 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:28 --> URI Class Initialized
INFO - 2016-08-24 16:27:28 --> Router Class Initialized
INFO - 2016-08-24 16:27:28 --> Output Class Initialized
INFO - 2016-08-24 16:27:28 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:28 --> Input Class Initialized
INFO - 2016-08-24 16:27:28 --> Language Class Initialized
INFO - 2016-08-24 16:27:28 --> Loader Class Initialized
INFO - 2016-08-24 16:27:28 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:28 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:28 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:28 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:28 --> Email Class Initialized
INFO - 2016-08-24 16:27:28 --> Controller Class Initialized
INFO - 2016-08-24 16:27:28 --> Model Class Initialized
DEBUG - 2016-08-24 16:27:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:27:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:27:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:27:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:29 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:29 --> Total execution time: 0.6065
INFO - 2016-08-24 16:27:33 --> Config Class Initialized
INFO - 2016-08-24 16:27:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:33 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:33 --> URI Class Initialized
INFO - 2016-08-24 16:27:33 --> Router Class Initialized
INFO - 2016-08-24 16:27:33 --> Output Class Initialized
INFO - 2016-08-24 16:27:34 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:34 --> Input Class Initialized
INFO - 2016-08-24 16:27:34 --> Language Class Initialized
INFO - 2016-08-24 16:27:34 --> Loader Class Initialized
INFO - 2016-08-24 16:27:34 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:34 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:34 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:34 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:34 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:34 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:34 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:34 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:34 --> Email Class Initialized
INFO - 2016-08-24 16:27:34 --> Controller Class Initialized
INFO - 2016-08-24 16:27:34 --> Model Class Initialized
DEBUG - 2016-08-24 16:27:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:27:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 16:27:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:27:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:27:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:34 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:34 --> Total execution time: 0.6807
INFO - 2016-08-24 16:27:47 --> Config Class Initialized
INFO - 2016-08-24 16:27:47 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:47 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:47 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:47 --> URI Class Initialized
INFO - 2016-08-24 16:27:47 --> Router Class Initialized
INFO - 2016-08-24 16:27:47 --> Output Class Initialized
INFO - 2016-08-24 16:27:47 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:47 --> Input Class Initialized
INFO - 2016-08-24 16:27:47 --> Language Class Initialized
INFO - 2016-08-24 16:27:47 --> Loader Class Initialized
INFO - 2016-08-24 16:27:47 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:47 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:48 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:48 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:48 --> Email Class Initialized
INFO - 2016-08-24 16:27:48 --> Controller Class Initialized
INFO - 2016-08-24 16:27:48 --> Model Class Initialized
DEBUG - 2016-08-24 16:27:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:27:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 16:27:48 --> Config Class Initialized
INFO - 2016-08-24 16:27:48 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:27:48 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:27:48 --> Utf8 Class Initialized
INFO - 2016-08-24 16:27:48 --> URI Class Initialized
INFO - 2016-08-24 16:27:48 --> Router Class Initialized
INFO - 2016-08-24 16:27:48 --> Output Class Initialized
INFO - 2016-08-24 16:27:48 --> Security Class Initialized
DEBUG - 2016-08-24 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:27:48 --> Input Class Initialized
INFO - 2016-08-24 16:27:48 --> Language Class Initialized
INFO - 2016-08-24 16:27:48 --> Loader Class Initialized
INFO - 2016-08-24 16:27:48 --> Helper loaded: url_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: html_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: form_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: file_helper
INFO - 2016-08-24 16:27:48 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:27:48 --> Database Driver Class Initialized
INFO - 2016-08-24 16:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:27:48 --> Form Validation Class Initialized
INFO - 2016-08-24 16:27:48 --> Email Class Initialized
INFO - 2016-08-24 16:27:48 --> Controller Class Initialized
INFO - 2016-08-24 16:27:48 --> Model Class Initialized
INFO - 2016-08-24 16:27:48 --> Model Class Initialized
INFO - 2016-08-24 16:27:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:27:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:27:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-24 16:27:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:27:48 --> Final output sent to browser
DEBUG - 2016-08-24 16:27:48 --> Total execution time: 0.6165
INFO - 2016-08-24 16:28:10 --> Config Class Initialized
INFO - 2016-08-24 16:28:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:28:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:28:10 --> Utf8 Class Initialized
INFO - 2016-08-24 16:28:10 --> URI Class Initialized
INFO - 2016-08-24 16:28:10 --> Router Class Initialized
INFO - 2016-08-24 16:28:10 --> Output Class Initialized
INFO - 2016-08-24 16:28:10 --> Security Class Initialized
DEBUG - 2016-08-24 16:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:28:10 --> Input Class Initialized
INFO - 2016-08-24 16:28:10 --> Language Class Initialized
INFO - 2016-08-24 16:28:10 --> Loader Class Initialized
INFO - 2016-08-24 16:28:10 --> Helper loaded: url_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: html_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: form_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: file_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:28:10 --> Database Driver Class Initialized
INFO - 2016-08-24 16:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:28:10 --> Form Validation Class Initialized
INFO - 2016-08-24 16:28:10 --> Email Class Initialized
INFO - 2016-08-24 16:28:10 --> Controller Class Initialized
INFO - 2016-08-24 16:28:10 --> Model Class Initialized
INFO - 2016-08-24 16:28:10 --> Config Class Initialized
INFO - 2016-08-24 16:28:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:28:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:28:10 --> Utf8 Class Initialized
INFO - 2016-08-24 16:28:10 --> URI Class Initialized
INFO - 2016-08-24 16:28:10 --> Router Class Initialized
INFO - 2016-08-24 16:28:10 --> Output Class Initialized
INFO - 2016-08-24 16:28:10 --> Security Class Initialized
DEBUG - 2016-08-24 16:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:28:10 --> Input Class Initialized
INFO - 2016-08-24 16:28:10 --> Language Class Initialized
INFO - 2016-08-24 16:28:10 --> Loader Class Initialized
INFO - 2016-08-24 16:28:10 --> Helper loaded: url_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: html_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: form_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: file_helper
INFO - 2016-08-24 16:28:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:28:10 --> Database Driver Class Initialized
INFO - 2016-08-24 16:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:28:10 --> Form Validation Class Initialized
INFO - 2016-08-24 16:28:10 --> Email Class Initialized
INFO - 2016-08-24 16:28:10 --> Controller Class Initialized
INFO - 2016-08-24 16:28:11 --> Model Class Initialized
DEBUG - 2016-08-24 16:28:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:28:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:28:11 --> Final output sent to browser
DEBUG - 2016-08-24 16:28:11 --> Total execution time: 0.6032
INFO - 2016-08-24 16:28:17 --> Config Class Initialized
INFO - 2016-08-24 16:28:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:28:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:28:17 --> Utf8 Class Initialized
INFO - 2016-08-24 16:28:17 --> URI Class Initialized
INFO - 2016-08-24 16:28:17 --> Router Class Initialized
INFO - 2016-08-24 16:28:17 --> Output Class Initialized
INFO - 2016-08-24 16:28:17 --> Security Class Initialized
DEBUG - 2016-08-24 16:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:28:17 --> Input Class Initialized
INFO - 2016-08-24 16:28:18 --> Language Class Initialized
INFO - 2016-08-24 16:28:18 --> Loader Class Initialized
INFO - 2016-08-24 16:28:18 --> Helper loaded: url_helper
INFO - 2016-08-24 16:28:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:28:18 --> Helper loaded: html_helper
INFO - 2016-08-24 16:28:18 --> Helper loaded: form_helper
INFO - 2016-08-24 16:28:18 --> Helper loaded: file_helper
INFO - 2016-08-24 16:28:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:28:18 --> Database Driver Class Initialized
INFO - 2016-08-24 16:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:28:18 --> Form Validation Class Initialized
INFO - 2016-08-24 16:28:18 --> Email Class Initialized
INFO - 2016-08-24 16:28:18 --> Controller Class Initialized
INFO - 2016-08-24 16:28:18 --> Model Class Initialized
DEBUG - 2016-08-24 16:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:28:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-24 16:28:18 --> {controllers/session/login} Invalid login id or password for user=sophea.ou
INFO - 2016-08-24 16:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:28:18 --> Final output sent to browser
DEBUG - 2016-08-24 16:28:18 --> Total execution time: 0.6712
INFO - 2016-08-24 16:28:49 --> Config Class Initialized
INFO - 2016-08-24 16:28:49 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:28:49 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:28:49 --> Utf8 Class Initialized
INFO - 2016-08-24 16:28:49 --> URI Class Initialized
INFO - 2016-08-24 16:28:49 --> Router Class Initialized
INFO - 2016-08-24 16:28:50 --> Output Class Initialized
INFO - 2016-08-24 16:28:50 --> Security Class Initialized
DEBUG - 2016-08-24 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:28:50 --> Input Class Initialized
INFO - 2016-08-24 16:28:50 --> Language Class Initialized
INFO - 2016-08-24 16:28:50 --> Loader Class Initialized
INFO - 2016-08-24 16:28:50 --> Helper loaded: url_helper
INFO - 2016-08-24 16:28:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:28:50 --> Helper loaded: html_helper
INFO - 2016-08-24 16:28:50 --> Helper loaded: form_helper
INFO - 2016-08-24 16:28:50 --> Helper loaded: file_helper
INFO - 2016-08-24 16:28:50 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:28:50 --> Database Driver Class Initialized
INFO - 2016-08-24 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:28:50 --> Form Validation Class Initialized
INFO - 2016-08-24 16:28:50 --> Email Class Initialized
INFO - 2016-08-24 16:28:50 --> Controller Class Initialized
INFO - 2016-08-24 16:28:50 --> Model Class Initialized
DEBUG - 2016-08-24 16:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:28:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-24 16:28:50 --> {controllers/session/login} Invalid login id or password for user=Sophea.Ou
INFO - 2016-08-24 16:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:28:50 --> Final output sent to browser
DEBUG - 2016-08-24 16:28:50 --> Total execution time: 0.8259
INFO - 2016-08-24 16:29:08 --> Config Class Initialized
INFO - 2016-08-24 16:29:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:08 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:08 --> URI Class Initialized
INFO - 2016-08-24 16:29:08 --> Router Class Initialized
INFO - 2016-08-24 16:29:08 --> Output Class Initialized
INFO - 2016-08-24 16:29:08 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:08 --> Input Class Initialized
INFO - 2016-08-24 16:29:08 --> Language Class Initialized
INFO - 2016-08-24 16:29:08 --> Loader Class Initialized
INFO - 2016-08-24 16:29:08 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:08 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:08 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:08 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:08 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:08 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:08 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:08 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:08 --> Email Class Initialized
INFO - 2016-08-24 16:29:08 --> Controller Class Initialized
INFO - 2016-08-24 16:29:08 --> Model Class Initialized
INFO - 2016-08-24 16:29:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:29:09 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:09 --> Total execution time: 0.5331
INFO - 2016-08-24 16:29:11 --> Config Class Initialized
INFO - 2016-08-24 16:29:11 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:11 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:12 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:12 --> URI Class Initialized
INFO - 2016-08-24 16:29:12 --> Router Class Initialized
INFO - 2016-08-24 16:29:12 --> Output Class Initialized
INFO - 2016-08-24 16:29:12 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:12 --> Input Class Initialized
INFO - 2016-08-24 16:29:12 --> Language Class Initialized
INFO - 2016-08-24 16:29:12 --> Loader Class Initialized
INFO - 2016-08-24 16:29:12 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:12 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:12 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:12 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:12 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:12 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:12 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:12 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:12 --> Email Class Initialized
INFO - 2016-08-24 16:29:12 --> Controller Class Initialized
INFO - 2016-08-24 16:29:12 --> Model Class Initialized
INFO - 2016-08-24 16:29:14 --> Config Class Initialized
INFO - 2016-08-24 16:29:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:14 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:14 --> URI Class Initialized
DEBUG - 2016-08-24 16:29:14 --> No URI present. Default controller set.
INFO - 2016-08-24 16:29:14 --> Router Class Initialized
INFO - 2016-08-24 16:29:14 --> Output Class Initialized
INFO - 2016-08-24 16:29:14 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:14 --> Input Class Initialized
INFO - 2016-08-24 16:29:14 --> Language Class Initialized
INFO - 2016-08-24 16:29:14 --> Loader Class Initialized
INFO - 2016-08-24 16:29:14 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:14 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:14 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:14 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:14 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:14 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:14 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:14 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:14 --> Email Class Initialized
INFO - 2016-08-24 16:29:14 --> Controller Class Initialized
INFO - 2016-08-24 16:29:14 --> Config Class Initialized
INFO - 2016-08-24 16:29:14 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:14 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:14 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:14 --> URI Class Initialized
INFO - 2016-08-24 16:29:14 --> Router Class Initialized
INFO - 2016-08-24 16:29:14 --> Output Class Initialized
INFO - 2016-08-24 16:29:15 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:15 --> Input Class Initialized
INFO - 2016-08-24 16:29:15 --> Language Class Initialized
INFO - 2016-08-24 16:29:15 --> Loader Class Initialized
INFO - 2016-08-24 16:29:15 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:15 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:15 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:15 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:15 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:15 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:15 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:15 --> Email Class Initialized
INFO - 2016-08-24 16:29:15 --> Controller Class Initialized
INFO - 2016-08-24 16:29:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:29:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:29:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:29:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:29:15 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:15 --> Total execution time: 0.6179
INFO - 2016-08-24 16:29:19 --> Config Class Initialized
INFO - 2016-08-24 16:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:19 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:19 --> URI Class Initialized
INFO - 2016-08-24 16:29:19 --> Router Class Initialized
INFO - 2016-08-24 16:29:19 --> Output Class Initialized
INFO - 2016-08-24 16:29:19 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:19 --> Input Class Initialized
INFO - 2016-08-24 16:29:19 --> Language Class Initialized
INFO - 2016-08-24 16:29:19 --> Loader Class Initialized
INFO - 2016-08-24 16:29:19 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:19 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:19 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:19 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:19 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:19 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:19 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:19 --> Email Class Initialized
INFO - 2016-08-24 16:29:19 --> Controller Class Initialized
INFO - 2016-08-24 16:29:19 --> Model Class Initialized
DEBUG - 2016-08-24 16:29:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:29:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 16:29:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:29:20 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:20 --> Total execution time: 0.6096
INFO - 2016-08-24 16:29:33 --> Config Class Initialized
INFO - 2016-08-24 16:29:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:33 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:33 --> URI Class Initialized
INFO - 2016-08-24 16:29:33 --> Router Class Initialized
INFO - 2016-08-24 16:29:33 --> Output Class Initialized
INFO - 2016-08-24 16:29:33 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:33 --> Input Class Initialized
INFO - 2016-08-24 16:29:33 --> Language Class Initialized
INFO - 2016-08-24 16:29:33 --> Loader Class Initialized
INFO - 2016-08-24 16:29:33 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:33 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:33 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:33 --> Email Class Initialized
INFO - 2016-08-24 16:29:33 --> Controller Class Initialized
INFO - 2016-08-24 16:29:33 --> Model Class Initialized
INFO - 2016-08-24 16:29:33 --> Config Class Initialized
INFO - 2016-08-24 16:29:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:33 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:33 --> URI Class Initialized
INFO - 2016-08-24 16:29:33 --> Router Class Initialized
INFO - 2016-08-24 16:29:33 --> Output Class Initialized
INFO - 2016-08-24 16:29:33 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:33 --> Input Class Initialized
INFO - 2016-08-24 16:29:33 --> Language Class Initialized
INFO - 2016-08-24 16:29:33 --> Loader Class Initialized
INFO - 2016-08-24 16:29:33 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:33 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:33 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:34 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:34 --> Email Class Initialized
INFO - 2016-08-24 16:29:34 --> Controller Class Initialized
INFO - 2016-08-24 16:29:34 --> Model Class Initialized
DEBUG - 2016-08-24 16:29:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:29:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:29:34 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:34 --> Total execution time: 0.6879
INFO - 2016-08-24 16:29:41 --> Config Class Initialized
INFO - 2016-08-24 16:29:41 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:41 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:41 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:41 --> URI Class Initialized
INFO - 2016-08-24 16:29:41 --> Router Class Initialized
INFO - 2016-08-24 16:29:41 --> Output Class Initialized
INFO - 2016-08-24 16:29:41 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:41 --> Input Class Initialized
INFO - 2016-08-24 16:29:41 --> Language Class Initialized
INFO - 2016-08-24 16:29:41 --> Loader Class Initialized
INFO - 2016-08-24 16:29:41 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:41 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:41 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:41 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:41 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:41 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:41 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:41 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:41 --> Email Class Initialized
INFO - 2016-08-24 16:29:41 --> Controller Class Initialized
INFO - 2016-08-24 16:29:41 --> Model Class Initialized
DEBUG - 2016-08-24 16:29:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:29:41 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-24 16:29:41 --> {controllers/session/login} Invalid login id or password for user=Sophea.Ou
INFO - 2016-08-24 16:29:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:29:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:29:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:29:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:29:42 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:42 --> Total execution time: 0.7271
INFO - 2016-08-24 16:29:54 --> Config Class Initialized
INFO - 2016-08-24 16:29:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:29:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:29:54 --> Utf8 Class Initialized
INFO - 2016-08-24 16:29:54 --> URI Class Initialized
INFO - 2016-08-24 16:29:54 --> Router Class Initialized
INFO - 2016-08-24 16:29:54 --> Output Class Initialized
INFO - 2016-08-24 16:29:54 --> Security Class Initialized
DEBUG - 2016-08-24 16:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:29:54 --> Input Class Initialized
INFO - 2016-08-24 16:29:54 --> Language Class Initialized
INFO - 2016-08-24 16:29:54 --> Loader Class Initialized
INFO - 2016-08-24 16:29:54 --> Helper loaded: url_helper
INFO - 2016-08-24 16:29:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:29:54 --> Helper loaded: html_helper
INFO - 2016-08-24 16:29:54 --> Helper loaded: form_helper
INFO - 2016-08-24 16:29:54 --> Helper loaded: file_helper
INFO - 2016-08-24 16:29:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:29:54 --> Database Driver Class Initialized
INFO - 2016-08-24 16:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:29:54 --> Form Validation Class Initialized
INFO - 2016-08-24 16:29:54 --> Email Class Initialized
INFO - 2016-08-24 16:29:54 --> Controller Class Initialized
INFO - 2016-08-24 16:29:54 --> Model Class Initialized
DEBUG - 2016-08-24 16:29:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:29:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-24 16:29:55 --> {controllers/session/login} Invalid login id or password for user=Sophea.Ou
INFO - 2016-08-24 16:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:29:55 --> Final output sent to browser
DEBUG - 2016-08-24 16:29:55 --> Total execution time: 0.7332
INFO - 2016-08-24 16:30:32 --> Config Class Initialized
INFO - 2016-08-24 16:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:30:32 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:30:32 --> Utf8 Class Initialized
INFO - 2016-08-24 16:30:33 --> URI Class Initialized
INFO - 2016-08-24 16:30:33 --> Router Class Initialized
INFO - 2016-08-24 16:30:33 --> Output Class Initialized
INFO - 2016-08-24 16:30:33 --> Security Class Initialized
DEBUG - 2016-08-24 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:30:33 --> Input Class Initialized
INFO - 2016-08-24 16:30:33 --> Language Class Initialized
INFO - 2016-08-24 16:30:33 --> Loader Class Initialized
INFO - 2016-08-24 16:30:33 --> Helper loaded: url_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: html_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: form_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: file_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:30:33 --> Database Driver Class Initialized
INFO - 2016-08-24 16:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:30:33 --> Form Validation Class Initialized
INFO - 2016-08-24 16:30:33 --> Email Class Initialized
INFO - 2016-08-24 16:30:33 --> Controller Class Initialized
INFO - 2016-08-24 16:30:33 --> Model Class Initialized
DEBUG - 2016-08-24 16:30:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:30:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 16:30:33 --> Config Class Initialized
INFO - 2016-08-24 16:30:33 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:30:33 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:30:33 --> Utf8 Class Initialized
INFO - 2016-08-24 16:30:33 --> URI Class Initialized
INFO - 2016-08-24 16:30:33 --> Router Class Initialized
INFO - 2016-08-24 16:30:33 --> Output Class Initialized
INFO - 2016-08-24 16:30:33 --> Security Class Initialized
DEBUG - 2016-08-24 16:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:30:33 --> Input Class Initialized
INFO - 2016-08-24 16:30:33 --> Language Class Initialized
INFO - 2016-08-24 16:30:33 --> Loader Class Initialized
INFO - 2016-08-24 16:30:33 --> Helper loaded: url_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: html_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: form_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: file_helper
INFO - 2016-08-24 16:30:33 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:30:33 --> Database Driver Class Initialized
INFO - 2016-08-24 16:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:30:33 --> Form Validation Class Initialized
INFO - 2016-08-24 16:30:33 --> Email Class Initialized
INFO - 2016-08-24 16:30:34 --> Controller Class Initialized
DEBUG - 2016-08-24 16:30:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 16:30:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:30:34 --> Model Class Initialized
INFO - 2016-08-24 16:30:34 --> Model Class Initialized
INFO - 2016-08-24 16:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 16:30:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:30:34 --> Final output sent to browser
DEBUG - 2016-08-24 16:30:34 --> Total execution time: 0.7220
INFO - 2016-08-24 16:34:44 --> Config Class Initialized
INFO - 2016-08-24 16:34:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:34:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:34:44 --> Utf8 Class Initialized
INFO - 2016-08-24 16:34:44 --> URI Class Initialized
INFO - 2016-08-24 16:34:44 --> Router Class Initialized
INFO - 2016-08-24 16:34:44 --> Output Class Initialized
INFO - 2016-08-24 16:34:44 --> Security Class Initialized
DEBUG - 2016-08-24 16:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:34:44 --> Input Class Initialized
INFO - 2016-08-24 16:34:44 --> Language Class Initialized
INFO - 2016-08-24 16:34:44 --> Loader Class Initialized
INFO - 2016-08-24 16:34:44 --> Helper loaded: url_helper
INFO - 2016-08-24 16:34:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:34:44 --> Helper loaded: html_helper
INFO - 2016-08-24 16:34:44 --> Helper loaded: form_helper
INFO - 2016-08-24 16:34:44 --> Helper loaded: file_helper
INFO - 2016-08-24 16:34:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:34:44 --> Database Driver Class Initialized
INFO - 2016-08-24 16:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:34:44 --> Form Validation Class Initialized
INFO - 2016-08-24 16:34:44 --> Email Class Initialized
INFO - 2016-08-24 16:34:44 --> Controller Class Initialized
DEBUG - 2016-08-24 16:34:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-24 16:34:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:34:44 --> Model Class Initialized
INFO - 2016-08-24 16:34:44 --> Model Class Initialized
INFO - 2016-08-24 16:34:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:34:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:34:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-24 16:34:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:34:44 --> Final output sent to browser
DEBUG - 2016-08-24 16:34:44 --> Total execution time: 0.7257
INFO - 2016-08-24 16:36:03 --> Config Class Initialized
INFO - 2016-08-24 16:36:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:03 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:03 --> URI Class Initialized
INFO - 2016-08-24 16:36:03 --> Router Class Initialized
INFO - 2016-08-24 16:36:03 --> Output Class Initialized
INFO - 2016-08-24 16:36:03 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:03 --> Input Class Initialized
INFO - 2016-08-24 16:36:03 --> Language Class Initialized
INFO - 2016-08-24 16:36:03 --> Loader Class Initialized
INFO - 2016-08-24 16:36:03 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:03 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:03 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:03 --> Email Class Initialized
INFO - 2016-08-24 16:36:03 --> Controller Class Initialized
INFO - 2016-08-24 16:36:03 --> Model Class Initialized
INFO - 2016-08-24 16:36:03 --> Config Class Initialized
INFO - 2016-08-24 16:36:03 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:03 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:03 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:03 --> URI Class Initialized
INFO - 2016-08-24 16:36:03 --> Router Class Initialized
INFO - 2016-08-24 16:36:03 --> Output Class Initialized
INFO - 2016-08-24 16:36:03 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:03 --> Input Class Initialized
INFO - 2016-08-24 16:36:03 --> Language Class Initialized
INFO - 2016-08-24 16:36:03 --> Loader Class Initialized
INFO - 2016-08-24 16:36:03 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:03 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:04 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:04 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:04 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:04 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:04 --> Email Class Initialized
INFO - 2016-08-24 16:36:04 --> Controller Class Initialized
INFO - 2016-08-24 16:36:04 --> Model Class Initialized
DEBUG - 2016-08-24 16:36:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:36:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:36:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:36:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:36:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:36:04 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:04 --> Total execution time: 0.6131
INFO - 2016-08-24 16:36:06 --> Config Class Initialized
INFO - 2016-08-24 16:36:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:07 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:07 --> URI Class Initialized
INFO - 2016-08-24 16:36:07 --> Router Class Initialized
INFO - 2016-08-24 16:36:07 --> Output Class Initialized
INFO - 2016-08-24 16:36:07 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:07 --> Input Class Initialized
INFO - 2016-08-24 16:36:07 --> Language Class Initialized
INFO - 2016-08-24 16:36:07 --> Loader Class Initialized
INFO - 2016-08-24 16:36:07 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:07 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:07 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:07 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:07 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:07 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:07 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:07 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:07 --> Email Class Initialized
INFO - 2016-08-24 16:36:07 --> Controller Class Initialized
INFO - 2016-08-24 16:36:07 --> Model Class Initialized
INFO - 2016-08-24 16:36:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:36:07 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:07 --> Total execution time: 0.5550
INFO - 2016-08-24 16:36:10 --> Config Class Initialized
INFO - 2016-08-24 16:36:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:10 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:10 --> URI Class Initialized
INFO - 2016-08-24 16:36:10 --> Router Class Initialized
INFO - 2016-08-24 16:36:10 --> Output Class Initialized
INFO - 2016-08-24 16:36:10 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:10 --> Input Class Initialized
INFO - 2016-08-24 16:36:10 --> Language Class Initialized
INFO - 2016-08-24 16:36:10 --> Loader Class Initialized
INFO - 2016-08-24 16:36:10 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:10 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:11 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:11 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:11 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:11 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:11 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:11 --> Email Class Initialized
INFO - 2016-08-24 16:36:11 --> Controller Class Initialized
INFO - 2016-08-24 16:36:11 --> Model Class Initialized
INFO - 2016-08-24 16:36:13 --> Config Class Initialized
INFO - 2016-08-24 16:36:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:13 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:13 --> URI Class Initialized
DEBUG - 2016-08-24 16:36:13 --> No URI present. Default controller set.
INFO - 2016-08-24 16:36:13 --> Router Class Initialized
INFO - 2016-08-24 16:36:13 --> Output Class Initialized
INFO - 2016-08-24 16:36:13 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:13 --> Input Class Initialized
INFO - 2016-08-24 16:36:13 --> Language Class Initialized
INFO - 2016-08-24 16:36:13 --> Loader Class Initialized
INFO - 2016-08-24 16:36:13 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:13 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:13 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:13 --> Email Class Initialized
INFO - 2016-08-24 16:36:13 --> Controller Class Initialized
INFO - 2016-08-24 16:36:13 --> Config Class Initialized
INFO - 2016-08-24 16:36:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:13 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:13 --> URI Class Initialized
INFO - 2016-08-24 16:36:13 --> Router Class Initialized
INFO - 2016-08-24 16:36:13 --> Output Class Initialized
INFO - 2016-08-24 16:36:13 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:13 --> Input Class Initialized
INFO - 2016-08-24 16:36:13 --> Language Class Initialized
INFO - 2016-08-24 16:36:13 --> Loader Class Initialized
INFO - 2016-08-24 16:36:13 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:14 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:14 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:14 --> Email Class Initialized
INFO - 2016-08-24 16:36:14 --> Controller Class Initialized
INFO - 2016-08-24 16:36:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:36:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:36:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 16:36:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:36:14 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:14 --> Total execution time: 0.5785
INFO - 2016-08-24 16:36:20 --> Config Class Initialized
INFO - 2016-08-24 16:36:20 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:20 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:20 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:20 --> URI Class Initialized
INFO - 2016-08-24 16:36:20 --> Router Class Initialized
INFO - 2016-08-24 16:36:20 --> Output Class Initialized
INFO - 2016-08-24 16:36:20 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:20 --> Input Class Initialized
INFO - 2016-08-24 16:36:20 --> Language Class Initialized
INFO - 2016-08-24 16:36:20 --> Loader Class Initialized
INFO - 2016-08-24 16:36:20 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:20 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:20 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:20 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:20 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:20 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:20 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:20 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:20 --> Email Class Initialized
INFO - 2016-08-24 16:36:21 --> Controller Class Initialized
INFO - 2016-08-24 16:36:21 --> Model Class Initialized
DEBUG - 2016-08-24 16:36:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:36:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:36:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:36:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 16:36:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:36:21 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:21 --> Total execution time: 0.6181
INFO - 2016-08-24 16:36:24 --> Config Class Initialized
INFO - 2016-08-24 16:36:24 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:24 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:24 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:24 --> URI Class Initialized
INFO - 2016-08-24 16:36:24 --> Router Class Initialized
INFO - 2016-08-24 16:36:24 --> Output Class Initialized
INFO - 2016-08-24 16:36:24 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:24 --> Input Class Initialized
INFO - 2016-08-24 16:36:25 --> Language Class Initialized
INFO - 2016-08-24 16:36:25 --> Loader Class Initialized
INFO - 2016-08-24 16:36:25 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:25 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:25 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:25 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:25 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:25 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:25 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:25 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:25 --> Email Class Initialized
INFO - 2016-08-24 16:36:25 --> Controller Class Initialized
INFO - 2016-08-24 16:36:25 --> Model Class Initialized
DEBUG - 2016-08-24 16:36:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:36:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:36:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:36:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/change-password.php
INFO - 2016-08-24 16:36:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:36:25 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:25 --> Total execution time: 0.7792
INFO - 2016-08-24 16:36:38 --> Config Class Initialized
INFO - 2016-08-24 16:36:38 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:36:38 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:36:38 --> Utf8 Class Initialized
INFO - 2016-08-24 16:36:38 --> URI Class Initialized
INFO - 2016-08-24 16:36:38 --> Router Class Initialized
INFO - 2016-08-24 16:36:38 --> Output Class Initialized
INFO - 2016-08-24 16:36:38 --> Security Class Initialized
DEBUG - 2016-08-24 16:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:36:38 --> Input Class Initialized
INFO - 2016-08-24 16:36:38 --> Language Class Initialized
INFO - 2016-08-24 16:36:38 --> Loader Class Initialized
INFO - 2016-08-24 16:36:38 --> Helper loaded: url_helper
INFO - 2016-08-24 16:36:38 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:36:38 --> Helper loaded: html_helper
INFO - 2016-08-24 16:36:38 --> Helper loaded: form_helper
INFO - 2016-08-24 16:36:38 --> Helper loaded: file_helper
INFO - 2016-08-24 16:36:38 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:36:38 --> Database Driver Class Initialized
INFO - 2016-08-24 16:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:36:38 --> Form Validation Class Initialized
INFO - 2016-08-24 16:36:39 --> Email Class Initialized
INFO - 2016-08-24 16:36:39 --> Controller Class Initialized
INFO - 2016-08-24 16:36:39 --> Model Class Initialized
DEBUG - 2016-08-24 16:36:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:36:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 16:36:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:36:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:36:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/change-password.php
INFO - 2016-08-24 16:36:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:36:39 --> Final output sent to browser
DEBUG - 2016-08-24 16:36:39 --> Total execution time: 0.9445
INFO - 2016-08-24 16:38:21 --> Config Class Initialized
INFO - 2016-08-24 16:38:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:38:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:38:21 --> Utf8 Class Initialized
INFO - 2016-08-24 16:38:21 --> URI Class Initialized
INFO - 2016-08-24 16:38:21 --> Router Class Initialized
INFO - 2016-08-24 16:38:21 --> Output Class Initialized
INFO - 2016-08-24 16:38:21 --> Security Class Initialized
DEBUG - 2016-08-24 16:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:38:21 --> Input Class Initialized
INFO - 2016-08-24 16:38:21 --> Language Class Initialized
INFO - 2016-08-24 16:38:21 --> Loader Class Initialized
INFO - 2016-08-24 16:38:21 --> Helper loaded: url_helper
INFO - 2016-08-24 16:38:21 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:38:21 --> Helper loaded: html_helper
INFO - 2016-08-24 16:38:21 --> Helper loaded: form_helper
INFO - 2016-08-24 16:38:21 --> Helper loaded: file_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:38:22 --> Database Driver Class Initialized
INFO - 2016-08-24 16:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:38:22 --> Form Validation Class Initialized
INFO - 2016-08-24 16:38:22 --> Email Class Initialized
INFO - 2016-08-24 16:38:22 --> Controller Class Initialized
INFO - 2016-08-24 16:38:22 --> Model Class Initialized
INFO - 2016-08-24 16:38:22 --> Config Class Initialized
INFO - 2016-08-24 16:38:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:38:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:38:22 --> Utf8 Class Initialized
INFO - 2016-08-24 16:38:22 --> URI Class Initialized
INFO - 2016-08-24 16:38:22 --> Router Class Initialized
INFO - 2016-08-24 16:38:22 --> Output Class Initialized
INFO - 2016-08-24 16:38:22 --> Security Class Initialized
DEBUG - 2016-08-24 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:38:22 --> Input Class Initialized
INFO - 2016-08-24 16:38:22 --> Language Class Initialized
INFO - 2016-08-24 16:38:22 --> Loader Class Initialized
INFO - 2016-08-24 16:38:22 --> Helper loaded: url_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: html_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: form_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: file_helper
INFO - 2016-08-24 16:38:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:38:22 --> Database Driver Class Initialized
INFO - 2016-08-24 16:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:38:22 --> Form Validation Class Initialized
INFO - 2016-08-24 16:38:22 --> Email Class Initialized
INFO - 2016-08-24 16:38:22 --> Controller Class Initialized
INFO - 2016-08-24 16:38:22 --> Model Class Initialized
DEBUG - 2016-08-24 16:38:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:38:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:38:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:38:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:38:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:38:22 --> Final output sent to browser
DEBUG - 2016-08-24 16:38:22 --> Total execution time: 0.6254
INFO - 2016-08-24 16:38:28 --> Config Class Initialized
INFO - 2016-08-24 16:38:28 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:38:28 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:38:29 --> Utf8 Class Initialized
INFO - 2016-08-24 16:38:29 --> URI Class Initialized
INFO - 2016-08-24 16:38:29 --> Router Class Initialized
INFO - 2016-08-24 16:38:29 --> Output Class Initialized
INFO - 2016-08-24 16:38:29 --> Security Class Initialized
DEBUG - 2016-08-24 16:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:38:29 --> Input Class Initialized
INFO - 2016-08-24 16:38:29 --> Language Class Initialized
INFO - 2016-08-24 16:38:29 --> Loader Class Initialized
INFO - 2016-08-24 16:38:29 --> Helper loaded: url_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: html_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: form_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: file_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:38:29 --> Database Driver Class Initialized
INFO - 2016-08-24 16:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:38:29 --> Form Validation Class Initialized
INFO - 2016-08-24 16:38:29 --> Email Class Initialized
INFO - 2016-08-24 16:38:29 --> Controller Class Initialized
INFO - 2016-08-24 16:38:29 --> Model Class Initialized
DEBUG - 2016-08-24 16:38:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:38:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 16:38:29 --> Config Class Initialized
INFO - 2016-08-24 16:38:29 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:38:29 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:38:29 --> Utf8 Class Initialized
INFO - 2016-08-24 16:38:29 --> URI Class Initialized
INFO - 2016-08-24 16:38:29 --> Router Class Initialized
INFO - 2016-08-24 16:38:29 --> Output Class Initialized
INFO - 2016-08-24 16:38:29 --> Security Class Initialized
DEBUG - 2016-08-24 16:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:38:29 --> Input Class Initialized
INFO - 2016-08-24 16:38:29 --> Language Class Initialized
INFO - 2016-08-24 16:38:29 --> Loader Class Initialized
INFO - 2016-08-24 16:38:29 --> Helper loaded: url_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: html_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: form_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: file_helper
INFO - 2016-08-24 16:38:29 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:38:29 --> Database Driver Class Initialized
INFO - 2016-08-24 16:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:38:29 --> Form Validation Class Initialized
INFO - 2016-08-24 16:38:30 --> Email Class Initialized
INFO - 2016-08-24 16:38:30 --> Controller Class Initialized
INFO - 2016-08-24 16:38:30 --> Model Class Initialized
INFO - 2016-08-24 16:38:30 --> Model Class Initialized
INFO - 2016-08-24 16:38:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:38:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:38:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-24 16:38:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:38:30 --> Final output sent to browser
DEBUG - 2016-08-24 16:38:30 --> Total execution time: 0.6289
INFO - 2016-08-24 16:49:50 --> Config Class Initialized
INFO - 2016-08-24 16:49:50 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:49:50 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:49:50 --> Utf8 Class Initialized
INFO - 2016-08-24 16:49:50 --> URI Class Initialized
INFO - 2016-08-24 16:49:50 --> Router Class Initialized
INFO - 2016-08-24 16:49:50 --> Output Class Initialized
INFO - 2016-08-24 16:49:50 --> Security Class Initialized
DEBUG - 2016-08-24 16:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:49:50 --> Input Class Initialized
INFO - 2016-08-24 16:49:50 --> Language Class Initialized
INFO - 2016-08-24 16:49:50 --> Loader Class Initialized
INFO - 2016-08-24 16:49:50 --> Helper loaded: url_helper
INFO - 2016-08-24 16:49:50 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:49:51 --> Helper loaded: html_helper
INFO - 2016-08-24 16:49:51 --> Helper loaded: form_helper
INFO - 2016-08-24 16:49:51 --> Helper loaded: file_helper
INFO - 2016-08-24 16:49:51 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:49:51 --> Database Driver Class Initialized
INFO - 2016-08-24 16:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:49:51 --> Form Validation Class Initialized
INFO - 2016-08-24 16:49:51 --> Email Class Initialized
INFO - 2016-08-24 16:49:51 --> Controller Class Initialized
INFO - 2016-08-24 16:49:51 --> Model Class Initialized
DEBUG - 2016-08-24 16:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 16:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 16:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:49:51 --> Final output sent to browser
DEBUG - 2016-08-24 16:49:51 --> Total execution time: 0.6313
INFO - 2016-08-24 16:49:54 --> Config Class Initialized
INFO - 2016-08-24 16:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:49:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:49:54 --> Utf8 Class Initialized
INFO - 2016-08-24 16:49:54 --> URI Class Initialized
INFO - 2016-08-24 16:49:54 --> Router Class Initialized
INFO - 2016-08-24 16:49:54 --> Output Class Initialized
INFO - 2016-08-24 16:49:54 --> Security Class Initialized
DEBUG - 2016-08-24 16:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:49:54 --> Input Class Initialized
INFO - 2016-08-24 16:49:54 --> Language Class Initialized
INFO - 2016-08-24 16:49:54 --> Loader Class Initialized
INFO - 2016-08-24 16:49:54 --> Helper loaded: url_helper
INFO - 2016-08-24 16:49:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:49:54 --> Helper loaded: html_helper
INFO - 2016-08-24 16:49:54 --> Helper loaded: form_helper
INFO - 2016-08-24 16:49:54 --> Helper loaded: file_helper
INFO - 2016-08-24 16:49:54 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:49:54 --> Database Driver Class Initialized
INFO - 2016-08-24 16:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:49:54 --> Form Validation Class Initialized
INFO - 2016-08-24 16:49:54 --> Email Class Initialized
INFO - 2016-08-24 16:49:54 --> Controller Class Initialized
INFO - 2016-08-24 16:49:54 --> Model Class Initialized
INFO - 2016-08-24 16:49:54 --> Config Class Initialized
INFO - 2016-08-24 16:49:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:49:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:49:54 --> Utf8 Class Initialized
INFO - 2016-08-24 16:49:54 --> URI Class Initialized
INFO - 2016-08-24 16:49:54 --> Router Class Initialized
INFO - 2016-08-24 16:49:54 --> Output Class Initialized
INFO - 2016-08-24 16:49:54 --> Security Class Initialized
DEBUG - 2016-08-24 16:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:49:54 --> Input Class Initialized
INFO - 2016-08-24 16:49:55 --> Language Class Initialized
INFO - 2016-08-24 16:49:55 --> Loader Class Initialized
INFO - 2016-08-24 16:49:55 --> Helper loaded: url_helper
INFO - 2016-08-24 16:49:55 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:49:55 --> Helper loaded: html_helper
INFO - 2016-08-24 16:49:55 --> Helper loaded: form_helper
INFO - 2016-08-24 16:49:55 --> Helper loaded: file_helper
INFO - 2016-08-24 16:49:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:49:55 --> Database Driver Class Initialized
INFO - 2016-08-24 16:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:49:55 --> Form Validation Class Initialized
INFO - 2016-08-24 16:49:55 --> Email Class Initialized
INFO - 2016-08-24 16:49:55 --> Controller Class Initialized
INFO - 2016-08-24 16:49:55 --> Model Class Initialized
DEBUG - 2016-08-24 16:49:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:49:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:49:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:49:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:49:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:49:55 --> Final output sent to browser
DEBUG - 2016-08-24 16:49:55 --> Total execution time: 0.6260
INFO - 2016-08-24 16:50:01 --> Config Class Initialized
INFO - 2016-08-24 16:50:01 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:50:01 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:50:01 --> Utf8 Class Initialized
INFO - 2016-08-24 16:50:01 --> URI Class Initialized
INFO - 2016-08-24 16:50:01 --> Router Class Initialized
INFO - 2016-08-24 16:50:01 --> Output Class Initialized
INFO - 2016-08-24 16:50:01 --> Security Class Initialized
DEBUG - 2016-08-24 16:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:50:01 --> Input Class Initialized
INFO - 2016-08-24 16:50:01 --> Language Class Initialized
INFO - 2016-08-24 16:50:01 --> Loader Class Initialized
INFO - 2016-08-24 16:50:01 --> Helper loaded: url_helper
INFO - 2016-08-24 16:50:01 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:50:01 --> Helper loaded: html_helper
INFO - 2016-08-24 16:50:01 --> Helper loaded: form_helper
INFO - 2016-08-24 16:50:01 --> Helper loaded: file_helper
INFO - 2016-08-24 16:50:01 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:50:01 --> Database Driver Class Initialized
INFO - 2016-08-24 16:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:50:01 --> Form Validation Class Initialized
INFO - 2016-08-24 16:50:01 --> Email Class Initialized
INFO - 2016-08-24 16:50:01 --> Controller Class Initialized
INFO - 2016-08-24 16:50:01 --> Model Class Initialized
INFO - 2016-08-24 16:50:01 --> Register method called
DEBUG - 2016-08-24 16:50:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:50:01 --> Form not validated
INFO - 2016-08-24 16:50:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:50:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/register.php
INFO - 2016-08-24 16:50:01 --> Final output sent to browser
DEBUG - 2016-08-24 16:50:01 --> Total execution time: 0.6319
INFO - 2016-08-24 16:50:05 --> Config Class Initialized
INFO - 2016-08-24 16:50:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:50:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:50:05 --> Utf8 Class Initialized
INFO - 2016-08-24 16:50:05 --> URI Class Initialized
DEBUG - 2016-08-24 16:50:05 --> No URI present. Default controller set.
INFO - 2016-08-24 16:50:05 --> Router Class Initialized
INFO - 2016-08-24 16:50:05 --> Output Class Initialized
INFO - 2016-08-24 16:50:05 --> Security Class Initialized
DEBUG - 2016-08-24 16:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:50:05 --> Input Class Initialized
INFO - 2016-08-24 16:50:05 --> Language Class Initialized
INFO - 2016-08-24 16:50:05 --> Loader Class Initialized
INFO - 2016-08-24 16:50:05 --> Helper loaded: url_helper
INFO - 2016-08-24 16:50:05 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:50:05 --> Helper loaded: html_helper
INFO - 2016-08-24 16:50:05 --> Helper loaded: form_helper
INFO - 2016-08-24 16:50:05 --> Helper loaded: file_helper
INFO - 2016-08-24 16:50:05 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:50:05 --> Database Driver Class Initialized
INFO - 2016-08-24 16:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:50:05 --> Form Validation Class Initialized
INFO - 2016-08-24 16:50:05 --> Email Class Initialized
INFO - 2016-08-24 16:50:05 --> Controller Class Initialized
INFO - 2016-08-24 16:50:05 --> Config Class Initialized
INFO - 2016-08-24 16:50:05 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:50:05 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:50:05 --> Utf8 Class Initialized
INFO - 2016-08-24 16:50:05 --> URI Class Initialized
INFO - 2016-08-24 16:50:05 --> Router Class Initialized
INFO - 2016-08-24 16:50:05 --> Output Class Initialized
INFO - 2016-08-24 16:50:05 --> Security Class Initialized
DEBUG - 2016-08-24 16:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:50:05 --> Input Class Initialized
INFO - 2016-08-24 16:50:05 --> Language Class Initialized
INFO - 2016-08-24 16:50:05 --> Loader Class Initialized
INFO - 2016-08-24 16:50:05 --> Helper loaded: url_helper
INFO - 2016-08-24 16:50:06 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:50:06 --> Helper loaded: html_helper
INFO - 2016-08-24 16:50:06 --> Helper loaded: form_helper
INFO - 2016-08-24 16:50:06 --> Helper loaded: file_helper
INFO - 2016-08-24 16:50:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:50:06 --> Database Driver Class Initialized
INFO - 2016-08-24 16:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:50:06 --> Form Validation Class Initialized
INFO - 2016-08-24 16:50:06 --> Email Class Initialized
INFO - 2016-08-24 16:50:06 --> Controller Class Initialized
INFO - 2016-08-24 16:50:06 --> Model Class Initialized
DEBUG - 2016-08-24 16:50:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:50:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:50:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:50:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:50:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:50:06 --> Final output sent to browser
DEBUG - 2016-08-24 16:50:06 --> Total execution time: 0.6579
INFO - 2016-08-24 16:53:06 --> Config Class Initialized
INFO - 2016-08-24 16:53:06 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:53:06 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:53:06 --> Utf8 Class Initialized
INFO - 2016-08-24 16:53:06 --> URI Class Initialized
INFO - 2016-08-24 16:53:06 --> Router Class Initialized
INFO - 2016-08-24 16:53:06 --> Output Class Initialized
INFO - 2016-08-24 16:53:06 --> Security Class Initialized
DEBUG - 2016-08-24 16:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:53:06 --> Input Class Initialized
INFO - 2016-08-24 16:53:06 --> Language Class Initialized
INFO - 2016-08-24 16:53:06 --> Loader Class Initialized
INFO - 2016-08-24 16:53:06 --> Helper loaded: url_helper
INFO - 2016-08-24 16:53:06 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:53:06 --> Helper loaded: html_helper
INFO - 2016-08-24 16:53:06 --> Helper loaded: form_helper
INFO - 2016-08-24 16:53:06 --> Helper loaded: file_helper
INFO - 2016-08-24 16:53:06 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:53:06 --> Database Driver Class Initialized
INFO - 2016-08-24 16:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:53:06 --> Form Validation Class Initialized
INFO - 2016-08-24 16:53:06 --> Email Class Initialized
INFO - 2016-08-24 16:53:06 --> Controller Class Initialized
INFO - 2016-08-24 16:53:06 --> Model Class Initialized
DEBUG - 2016-08-24 16:53:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:53:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:53:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:53:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:53:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:53:06 --> Final output sent to browser
DEBUG - 2016-08-24 16:53:06 --> Total execution time: 0.6476
INFO - 2016-08-24 16:53:10 --> Config Class Initialized
INFO - 2016-08-24 16:53:10 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:53:10 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:53:10 --> Utf8 Class Initialized
INFO - 2016-08-24 16:53:10 --> URI Class Initialized
INFO - 2016-08-24 16:53:10 --> Router Class Initialized
INFO - 2016-08-24 16:53:10 --> Output Class Initialized
INFO - 2016-08-24 16:53:10 --> Security Class Initialized
DEBUG - 2016-08-24 16:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:53:10 --> Input Class Initialized
INFO - 2016-08-24 16:53:10 --> Language Class Initialized
INFO - 2016-08-24 16:53:10 --> Loader Class Initialized
INFO - 2016-08-24 16:53:10 --> Helper loaded: url_helper
INFO - 2016-08-24 16:53:10 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:53:10 --> Helper loaded: html_helper
INFO - 2016-08-24 16:53:10 --> Helper loaded: form_helper
INFO - 2016-08-24 16:53:10 --> Helper loaded: file_helper
INFO - 2016-08-24 16:53:10 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:53:10 --> Database Driver Class Initialized
INFO - 2016-08-24 16:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:53:10 --> Form Validation Class Initialized
INFO - 2016-08-24 16:53:10 --> Email Class Initialized
INFO - 2016-08-24 16:53:10 --> Controller Class Initialized
INFO - 2016-08-24 16:53:10 --> Model Class Initialized
INFO - 2016-08-24 16:53:10 --> Register method called
DEBUG - 2016-08-24 16:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:53:10 --> Form not validated
INFO - 2016-08-24 16:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/register.php
INFO - 2016-08-24 16:53:10 --> Final output sent to browser
DEBUG - 2016-08-24 16:53:10 --> Total execution time: 0.6349
INFO - 2016-08-24 16:53:15 --> Config Class Initialized
INFO - 2016-08-24 16:53:15 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:53:15 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:53:15 --> Utf8 Class Initialized
INFO - 2016-08-24 16:53:15 --> URI Class Initialized
INFO - 2016-08-24 16:53:15 --> Router Class Initialized
INFO - 2016-08-24 16:53:15 --> Output Class Initialized
INFO - 2016-08-24 16:53:15 --> Security Class Initialized
DEBUG - 2016-08-24 16:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:53:15 --> Input Class Initialized
INFO - 2016-08-24 16:53:15 --> Language Class Initialized
INFO - 2016-08-24 16:53:15 --> Loader Class Initialized
INFO - 2016-08-24 16:53:15 --> Helper loaded: url_helper
INFO - 2016-08-24 16:53:15 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:53:15 --> Helper loaded: html_helper
INFO - 2016-08-24 16:53:15 --> Helper loaded: form_helper
INFO - 2016-08-24 16:53:16 --> Helper loaded: file_helper
INFO - 2016-08-24 16:53:16 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:53:16 --> Database Driver Class Initialized
INFO - 2016-08-24 16:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:53:16 --> Form Validation Class Initialized
INFO - 2016-08-24 16:53:16 --> Email Class Initialized
INFO - 2016-08-24 16:53:16 --> Controller Class Initialized
INFO - 2016-08-24 16:53:16 --> Model Class Initialized
DEBUG - 2016-08-24 16:53:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:53:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:53:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:53:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:53:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:53:16 --> Final output sent to browser
DEBUG - 2016-08-24 16:53:16 --> Total execution time: 0.6842
INFO - 2016-08-24 16:53:21 --> Config Class Initialized
INFO - 2016-08-24 16:53:21 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:53:21 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:53:21 --> Utf8 Class Initialized
INFO - 2016-08-24 16:53:21 --> URI Class Initialized
INFO - 2016-08-24 16:53:21 --> Router Class Initialized
INFO - 2016-08-24 16:53:22 --> Output Class Initialized
INFO - 2016-08-24 16:53:22 --> Security Class Initialized
DEBUG - 2016-08-24 16:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:53:22 --> Input Class Initialized
INFO - 2016-08-24 16:53:22 --> Language Class Initialized
INFO - 2016-08-24 16:53:22 --> Loader Class Initialized
INFO - 2016-08-24 16:53:22 --> Helper loaded: url_helper
INFO - 2016-08-24 16:53:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:53:22 --> Helper loaded: html_helper
INFO - 2016-08-24 16:53:22 --> Helper loaded: form_helper
INFO - 2016-08-24 16:53:22 --> Helper loaded: file_helper
INFO - 2016-08-24 16:53:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:53:22 --> Database Driver Class Initialized
INFO - 2016-08-24 16:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:53:22 --> Form Validation Class Initialized
INFO - 2016-08-24 16:53:22 --> Email Class Initialized
INFO - 2016-08-24 16:53:22 --> Controller Class Initialized
INFO - 2016-08-24 16:53:22 --> Model Class Initialized
DEBUG - 2016-08-24 16:53:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:53:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:53:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:53:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:53:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:53:22 --> Final output sent to browser
DEBUG - 2016-08-24 16:53:22 --> Total execution time: 0.6772
INFO - 2016-08-24 16:58:44 --> Config Class Initialized
INFO - 2016-08-24 16:58:44 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:58:44 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:58:44 --> Utf8 Class Initialized
INFO - 2016-08-24 16:58:44 --> URI Class Initialized
INFO - 2016-08-24 16:58:44 --> Router Class Initialized
INFO - 2016-08-24 16:58:44 --> Output Class Initialized
INFO - 2016-08-24 16:58:44 --> Security Class Initialized
DEBUG - 2016-08-24 16:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:58:44 --> Input Class Initialized
INFO - 2016-08-24 16:58:44 --> Language Class Initialized
INFO - 2016-08-24 16:58:44 --> Loader Class Initialized
INFO - 2016-08-24 16:58:44 --> Helper loaded: url_helper
INFO - 2016-08-24 16:58:44 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:58:44 --> Helper loaded: html_helper
INFO - 2016-08-24 16:58:44 --> Helper loaded: form_helper
INFO - 2016-08-24 16:58:44 --> Helper loaded: file_helper
INFO - 2016-08-24 16:58:44 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:58:44 --> Database Driver Class Initialized
INFO - 2016-08-24 16:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:58:44 --> Form Validation Class Initialized
INFO - 2016-08-24 16:58:44 --> Email Class Initialized
INFO - 2016-08-24 16:58:44 --> Controller Class Initialized
INFO - 2016-08-24 16:58:44 --> Model Class Initialized
DEBUG - 2016-08-24 16:58:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 16:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-24 16:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 16:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-24 16:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 16:58:44 --> Final output sent to browser
DEBUG - 2016-08-24 16:58:44 --> Total execution time: 0.6522
INFO - 2016-08-24 16:59:31 --> Config Class Initialized
INFO - 2016-08-24 16:59:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 16:59:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 16:59:31 --> Utf8 Class Initialized
INFO - 2016-08-24 16:59:31 --> URI Class Initialized
INFO - 2016-08-24 16:59:31 --> Router Class Initialized
INFO - 2016-08-24 16:59:31 --> Output Class Initialized
INFO - 2016-08-24 16:59:31 --> Security Class Initialized
DEBUG - 2016-08-24 16:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 16:59:31 --> Input Class Initialized
INFO - 2016-08-24 16:59:32 --> Language Class Initialized
INFO - 2016-08-24 16:59:32 --> Loader Class Initialized
INFO - 2016-08-24 16:59:32 --> Helper loaded: url_helper
INFO - 2016-08-24 16:59:32 --> Helper loaded: utils_helper
INFO - 2016-08-24 16:59:32 --> Helper loaded: html_helper
INFO - 2016-08-24 16:59:32 --> Helper loaded: form_helper
INFO - 2016-08-24 16:59:32 --> Helper loaded: file_helper
INFO - 2016-08-24 16:59:32 --> Helper loaded: myemail_helper
INFO - 2016-08-24 16:59:32 --> Database Driver Class Initialized
INFO - 2016-08-24 16:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 16:59:32 --> Form Validation Class Initialized
INFO - 2016-08-24 16:59:32 --> Email Class Initialized
INFO - 2016-08-24 16:59:32 --> Controller Class Initialized
INFO - 2016-08-24 16:59:32 --> Model Class Initialized
INFO - 2016-08-24 16:59:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-24 16:59:32 --> Final output sent to browser
DEBUG - 2016-08-24 16:59:32 --> Total execution time: 0.5728
INFO - 2016-08-24 17:08:54 --> Config Class Initialized
INFO - 2016-08-24 17:08:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:08:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:08:54 --> Utf8 Class Initialized
INFO - 2016-08-24 17:08:54 --> URI Class Initialized
INFO - 2016-08-24 17:08:54 --> Router Class Initialized
INFO - 2016-08-24 17:08:54 --> Output Class Initialized
INFO - 2016-08-24 17:08:54 --> Security Class Initialized
DEBUG - 2016-08-24 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:08:54 --> Input Class Initialized
INFO - 2016-08-24 17:08:54 --> Language Class Initialized
INFO - 2016-08-24 17:08:54 --> Loader Class Initialized
INFO - 2016-08-24 17:08:54 --> Helper loaded: url_helper
INFO - 2016-08-24 17:08:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:08:54 --> Helper loaded: html_helper
INFO - 2016-08-24 17:08:55 --> Helper loaded: form_helper
INFO - 2016-08-24 17:08:55 --> Helper loaded: file_helper
INFO - 2016-08-24 17:08:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:08:55 --> Database Driver Class Initialized
INFO - 2016-08-24 17:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:08:55 --> Form Validation Class Initialized
INFO - 2016-08-24 17:08:55 --> Email Class Initialized
INFO - 2016-08-24 17:08:55 --> Controller Class Initialized
INFO - 2016-08-24 17:08:55 --> Model Class Initialized
INFO - 2016-08-24 17:08:56 --> Config Class Initialized
INFO - 2016-08-24 17:08:56 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:08:56 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:08:56 --> Utf8 Class Initialized
INFO - 2016-08-24 17:08:56 --> URI Class Initialized
DEBUG - 2016-08-24 17:08:56 --> No URI present. Default controller set.
INFO - 2016-08-24 17:08:56 --> Router Class Initialized
INFO - 2016-08-24 17:08:56 --> Output Class Initialized
INFO - 2016-08-24 17:08:56 --> Security Class Initialized
DEBUG - 2016-08-24 17:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:08:56 --> Input Class Initialized
INFO - 2016-08-24 17:08:56 --> Language Class Initialized
INFO - 2016-08-24 17:08:57 --> Loader Class Initialized
INFO - 2016-08-24 17:08:57 --> Helper loaded: url_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: html_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: form_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: file_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:08:57 --> Database Driver Class Initialized
INFO - 2016-08-24 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:08:57 --> Form Validation Class Initialized
INFO - 2016-08-24 17:08:57 --> Email Class Initialized
INFO - 2016-08-24 17:08:57 --> Controller Class Initialized
INFO - 2016-08-24 17:08:57 --> Config Class Initialized
INFO - 2016-08-24 17:08:57 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:08:57 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:08:57 --> Utf8 Class Initialized
INFO - 2016-08-24 17:08:57 --> URI Class Initialized
INFO - 2016-08-24 17:08:57 --> Router Class Initialized
INFO - 2016-08-24 17:08:57 --> Output Class Initialized
INFO - 2016-08-24 17:08:57 --> Security Class Initialized
DEBUG - 2016-08-24 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:08:57 --> Input Class Initialized
INFO - 2016-08-24 17:08:57 --> Language Class Initialized
INFO - 2016-08-24 17:08:57 --> Loader Class Initialized
INFO - 2016-08-24 17:08:57 --> Helper loaded: url_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: html_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: form_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: file_helper
INFO - 2016-08-24 17:08:57 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:08:57 --> Database Driver Class Initialized
INFO - 2016-08-24 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:08:57 --> Form Validation Class Initialized
INFO - 2016-08-24 17:08:57 --> Email Class Initialized
INFO - 2016-08-24 17:08:57 --> Controller Class Initialized
INFO - 2016-08-24 17:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-24 17:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:08:57 --> Final output sent to browser
DEBUG - 2016-08-24 17:08:57 --> Total execution time: 0.5938
INFO - 2016-08-24 17:09:07 --> Config Class Initialized
INFO - 2016-08-24 17:09:07 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:09:07 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:09:07 --> Utf8 Class Initialized
INFO - 2016-08-24 17:09:07 --> URI Class Initialized
INFO - 2016-08-24 17:09:07 --> Router Class Initialized
INFO - 2016-08-24 17:09:07 --> Output Class Initialized
INFO - 2016-08-24 17:09:07 --> Security Class Initialized
DEBUG - 2016-08-24 17:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:09:07 --> Input Class Initialized
INFO - 2016-08-24 17:09:07 --> Language Class Initialized
INFO - 2016-08-24 17:09:07 --> Loader Class Initialized
INFO - 2016-08-24 17:09:07 --> Helper loaded: url_helper
INFO - 2016-08-24 17:09:07 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:09:07 --> Helper loaded: html_helper
INFO - 2016-08-24 17:09:07 --> Helper loaded: form_helper
INFO - 2016-08-24 17:09:07 --> Helper loaded: file_helper
INFO - 2016-08-24 17:09:07 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:09:07 --> Database Driver Class Initialized
INFO - 2016-08-24 17:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:09:07 --> Form Validation Class Initialized
INFO - 2016-08-24 17:09:07 --> Email Class Initialized
INFO - 2016-08-24 17:09:07 --> Controller Class Initialized
INFO - 2016-08-24 17:09:07 --> Model Class Initialized
INFO - 2016-08-24 17:09:07 --> Model Class Initialized
INFO - 2016-08-24 17:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-24 17:09:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:09:07 --> Final output sent to browser
DEBUG - 2016-08-24 17:09:07 --> Total execution time: 0.6477
INFO - 2016-08-24 17:09:08 --> Config Class Initialized
INFO - 2016-08-24 17:09:08 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:09:08 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:09:08 --> Utf8 Class Initialized
INFO - 2016-08-24 17:09:08 --> URI Class Initialized
INFO - 2016-08-24 17:09:08 --> Router Class Initialized
INFO - 2016-08-24 17:09:08 --> Output Class Initialized
INFO - 2016-08-24 17:09:09 --> Security Class Initialized
DEBUG - 2016-08-24 17:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:09:09 --> Input Class Initialized
INFO - 2016-08-24 17:09:09 --> Language Class Initialized
INFO - 2016-08-24 17:09:09 --> Loader Class Initialized
INFO - 2016-08-24 17:09:09 --> Helper loaded: url_helper
INFO - 2016-08-24 17:09:09 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:09:09 --> Helper loaded: html_helper
INFO - 2016-08-24 17:09:09 --> Helper loaded: form_helper
INFO - 2016-08-24 17:09:09 --> Helper loaded: file_helper
INFO - 2016-08-24 17:09:09 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:09:09 --> Database Driver Class Initialized
INFO - 2016-08-24 17:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:09:09 --> Form Validation Class Initialized
INFO - 2016-08-24 17:09:09 --> Email Class Initialized
INFO - 2016-08-24 17:09:09 --> Controller Class Initialized
DEBUG - 2016-08-24 17:09:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:09:09 --> Model Class Initialized
INFO - 2016-08-24 17:09:09 --> Model Class Initialized
INFO - 2016-08-24 17:09:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:09:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:09:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 17:09:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:09:09 --> Final output sent to browser
DEBUG - 2016-08-24 17:09:09 --> Total execution time: 0.6726
INFO - 2016-08-24 17:09:19 --> Config Class Initialized
INFO - 2016-08-24 17:09:19 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:09:19 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:09:19 --> Utf8 Class Initialized
INFO - 2016-08-24 17:09:19 --> URI Class Initialized
INFO - 2016-08-24 17:09:19 --> Router Class Initialized
INFO - 2016-08-24 17:09:19 --> Output Class Initialized
INFO - 2016-08-24 17:09:19 --> Security Class Initialized
DEBUG - 2016-08-24 17:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:09:19 --> Input Class Initialized
INFO - 2016-08-24 17:09:19 --> Language Class Initialized
INFO - 2016-08-24 17:09:19 --> Loader Class Initialized
INFO - 2016-08-24 17:09:19 --> Helper loaded: url_helper
INFO - 2016-08-24 17:09:19 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:09:19 --> Helper loaded: html_helper
INFO - 2016-08-24 17:09:19 --> Helper loaded: form_helper
INFO - 2016-08-24 17:09:19 --> Helper loaded: file_helper
INFO - 2016-08-24 17:09:19 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:09:19 --> Database Driver Class Initialized
INFO - 2016-08-24 17:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:09:19 --> Form Validation Class Initialized
INFO - 2016-08-24 17:09:19 --> Email Class Initialized
INFO - 2016-08-24 17:09:19 --> Controller Class Initialized
INFO - 2016-08-24 17:09:19 --> Model Class Initialized
DEBUG - 2016-08-24 17:09:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 17:09:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:09:19 --> Final output sent to browser
DEBUG - 2016-08-24 17:09:19 --> Total execution time: 0.6681
INFO - 2016-08-24 17:09:22 --> Config Class Initialized
INFO - 2016-08-24 17:09:22 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:09:22 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:09:22 --> Utf8 Class Initialized
INFO - 2016-08-24 17:09:22 --> URI Class Initialized
INFO - 2016-08-24 17:09:22 --> Router Class Initialized
INFO - 2016-08-24 17:09:22 --> Output Class Initialized
INFO - 2016-08-24 17:09:22 --> Security Class Initialized
DEBUG - 2016-08-24 17:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:09:22 --> Input Class Initialized
INFO - 2016-08-24 17:09:22 --> Language Class Initialized
INFO - 2016-08-24 17:09:22 --> Loader Class Initialized
INFO - 2016-08-24 17:09:22 --> Helper loaded: url_helper
INFO - 2016-08-24 17:09:22 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:09:22 --> Helper loaded: html_helper
INFO - 2016-08-24 17:09:22 --> Helper loaded: form_helper
INFO - 2016-08-24 17:09:22 --> Helper loaded: file_helper
INFO - 2016-08-24 17:09:22 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:09:22 --> Database Driver Class Initialized
INFO - 2016-08-24 17:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:09:22 --> Form Validation Class Initialized
INFO - 2016-08-24 17:09:22 --> Email Class Initialized
INFO - 2016-08-24 17:09:22 --> Controller Class Initialized
INFO - 2016-08-24 17:09:22 --> Model Class Initialized
DEBUG - 2016-08-24 17:09:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:09:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:09:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/change-password.php
INFO - 2016-08-24 17:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:09:23 --> Final output sent to browser
DEBUG - 2016-08-24 17:09:23 --> Total execution time: 0.6508
INFO - 2016-08-24 17:09:31 --> Config Class Initialized
INFO - 2016-08-24 17:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:09:31 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:09:31 --> Utf8 Class Initialized
INFO - 2016-08-24 17:09:31 --> URI Class Initialized
INFO - 2016-08-24 17:09:31 --> Router Class Initialized
INFO - 2016-08-24 17:09:31 --> Output Class Initialized
INFO - 2016-08-24 17:09:31 --> Security Class Initialized
DEBUG - 2016-08-24 17:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:09:31 --> Input Class Initialized
INFO - 2016-08-24 17:09:31 --> Language Class Initialized
INFO - 2016-08-24 17:09:31 --> Loader Class Initialized
INFO - 2016-08-24 17:09:31 --> Helper loaded: url_helper
INFO - 2016-08-24 17:09:31 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:09:31 --> Helper loaded: html_helper
INFO - 2016-08-24 17:09:31 --> Helper loaded: form_helper
INFO - 2016-08-24 17:09:31 --> Helper loaded: file_helper
INFO - 2016-08-24 17:09:31 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:09:31 --> Database Driver Class Initialized
INFO - 2016-08-24 17:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:09:31 --> Form Validation Class Initialized
INFO - 2016-08-24 17:09:31 --> Email Class Initialized
INFO - 2016-08-24 17:09:31 --> Controller Class Initialized
INFO - 2016-08-24 17:09:31 --> Model Class Initialized
DEBUG - 2016-08-24 17:09:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:09:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-24 17:09:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:09:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:09:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/change-password.php
INFO - 2016-08-24 17:09:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:09:31 --> Final output sent to browser
DEBUG - 2016-08-24 17:09:31 --> Total execution time: 0.6732
INFO - 2016-08-24 17:22:12 --> Config Class Initialized
INFO - 2016-08-24 17:22:13 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:22:13 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:22:13 --> Utf8 Class Initialized
INFO - 2016-08-24 17:22:13 --> URI Class Initialized
INFO - 2016-08-24 17:22:13 --> Router Class Initialized
INFO - 2016-08-24 17:22:13 --> Output Class Initialized
INFO - 2016-08-24 17:22:13 --> Security Class Initialized
DEBUG - 2016-08-24 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:22:13 --> Input Class Initialized
INFO - 2016-08-24 17:22:13 --> Language Class Initialized
INFO - 2016-08-24 17:22:13 --> Loader Class Initialized
INFO - 2016-08-24 17:22:13 --> Helper loaded: url_helper
INFO - 2016-08-24 17:22:13 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:22:13 --> Helper loaded: html_helper
INFO - 2016-08-24 17:22:13 --> Helper loaded: form_helper
INFO - 2016-08-24 17:22:13 --> Helper loaded: file_helper
INFO - 2016-08-24 17:22:13 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:22:13 --> Database Driver Class Initialized
INFO - 2016-08-24 17:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:22:13 --> Form Validation Class Initialized
INFO - 2016-08-24 17:22:13 --> Email Class Initialized
INFO - 2016-08-24 17:22:13 --> Controller Class Initialized
DEBUG - 2016-08-24 17:22:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:22:13 --> Model Class Initialized
INFO - 2016-08-24 17:22:13 --> Model Class Initialized
INFO - 2016-08-24 17:22:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:22:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:22:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-24 17:22:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:22:13 --> Final output sent to browser
DEBUG - 2016-08-24 17:22:13 --> Total execution time: 0.7212
INFO - 2016-08-24 17:22:17 --> Config Class Initialized
INFO - 2016-08-24 17:22:17 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:22:17 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:22:18 --> Utf8 Class Initialized
INFO - 2016-08-24 17:22:18 --> URI Class Initialized
INFO - 2016-08-24 17:22:18 --> Router Class Initialized
INFO - 2016-08-24 17:22:18 --> Output Class Initialized
INFO - 2016-08-24 17:22:18 --> Security Class Initialized
DEBUG - 2016-08-24 17:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:22:18 --> Input Class Initialized
INFO - 2016-08-24 17:22:18 --> Language Class Initialized
INFO - 2016-08-24 17:22:18 --> Loader Class Initialized
INFO - 2016-08-24 17:22:18 --> Helper loaded: url_helper
INFO - 2016-08-24 17:22:18 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:22:18 --> Helper loaded: html_helper
INFO - 2016-08-24 17:22:18 --> Helper loaded: form_helper
INFO - 2016-08-24 17:22:18 --> Helper loaded: file_helper
INFO - 2016-08-24 17:22:18 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:22:18 --> Database Driver Class Initialized
INFO - 2016-08-24 17:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:22:18 --> Form Validation Class Initialized
INFO - 2016-08-24 17:22:18 --> Email Class Initialized
INFO - 2016-08-24 17:22:18 --> Controller Class Initialized
INFO - 2016-08-24 17:22:18 --> Model Class Initialized
INFO - 2016-08-24 17:22:18 --> Model Class Initialized
INFO - 2016-08-24 17:22:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:22:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:22:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-24 17:22:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:22:18 --> Final output sent to browser
DEBUG - 2016-08-24 17:22:18 --> Total execution time: 0.7559
INFO - 2016-08-24 17:32:54 --> Config Class Initialized
INFO - 2016-08-24 17:32:54 --> Hooks Class Initialized
DEBUG - 2016-08-24 17:32:54 --> UTF-8 Support Enabled
INFO - 2016-08-24 17:32:54 --> Utf8 Class Initialized
INFO - 2016-08-24 17:32:54 --> URI Class Initialized
INFO - 2016-08-24 17:32:54 --> Router Class Initialized
INFO - 2016-08-24 17:32:54 --> Output Class Initialized
INFO - 2016-08-24 17:32:54 --> Security Class Initialized
DEBUG - 2016-08-24 17:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-24 17:32:54 --> Input Class Initialized
INFO - 2016-08-24 17:32:54 --> Language Class Initialized
INFO - 2016-08-24 17:32:54 --> Loader Class Initialized
INFO - 2016-08-24 17:32:54 --> Helper loaded: url_helper
INFO - 2016-08-24 17:32:54 --> Helper loaded: utils_helper
INFO - 2016-08-24 17:32:54 --> Helper loaded: html_helper
INFO - 2016-08-24 17:32:54 --> Helper loaded: form_helper
INFO - 2016-08-24 17:32:55 --> Helper loaded: file_helper
INFO - 2016-08-24 17:32:55 --> Helper loaded: myemail_helper
INFO - 2016-08-24 17:32:55 --> Database Driver Class Initialized
INFO - 2016-08-24 17:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-24 17:32:55 --> Form Validation Class Initialized
INFO - 2016-08-24 17:32:55 --> Email Class Initialized
INFO - 2016-08-24 17:32:55 --> Controller Class Initialized
INFO - 2016-08-24 17:32:55 --> Model Class Initialized
DEBUG - 2016-08-24 17:32:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-24 17:32:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-24 17:32:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-24 17:32:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-24 17:32:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-24 17:32:55 --> Final output sent to browser
DEBUG - 2016-08-24 17:32:55 --> Total execution time: 0.7049
