<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-09-01 03:37:23 --> Config Class Initialized
INFO - 2016-09-01 03:37:23 --> Hooks Class Initialized
DEBUG - 2016-09-01 03:37:23 --> UTF-8 Support Enabled
INFO - 2016-09-01 03:37:23 --> Utf8 Class Initialized
INFO - 2016-09-01 03:37:23 --> URI Class Initialized
INFO - 2016-09-01 03:37:23 --> Router Class Initialized
INFO - 2016-09-01 03:37:23 --> Output Class Initialized
INFO - 2016-09-01 03:37:24 --> Security Class Initialized
DEBUG - 2016-09-01 03:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 03:37:24 --> Input Class Initialized
INFO - 2016-09-01 03:37:24 --> Language Class Initialized
INFO - 2016-09-01 03:37:24 --> Loader Class Initialized
INFO - 2016-09-01 03:37:24 --> Helper loaded: url_helper
INFO - 2016-09-01 03:37:24 --> Helper loaded: utils_helper
INFO - 2016-09-01 03:37:24 --> Helper loaded: html_helper
INFO - 2016-09-01 03:37:24 --> Helper loaded: form_helper
INFO - 2016-09-01 03:37:24 --> Helper loaded: file_helper
INFO - 2016-09-01 03:37:24 --> Helper loaded: myemail_helper
INFO - 2016-09-01 03:37:24 --> Database Driver Class Initialized
INFO - 2016-09-01 03:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-09-01 03:37:24 --> Form Validation Class Initialized
INFO - 2016-09-01 03:37:24 --> Email Class Initialized
INFO - 2016-09-01 03:37:24 --> Controller Class Initialized
INFO - 2016-09-01 03:37:24 --> Model Class Initialized
DEBUG - 2016-09-01 03:37:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-09-01 03:37:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-09-01 03:37:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-09-01 03:37:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-09-01 03:37:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-09-01 03:37:24 --> Final output sent to browser
DEBUG - 2016-09-01 03:37:24 --> Total execution time: 1.0744
INFO - 2016-09-01 03:37:26 --> Config Class Initialized
INFO - 2016-09-01 03:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-01 03:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-01 03:37:26 --> Utf8 Class Initialized
INFO - 2016-09-01 03:37:26 --> URI Class Initialized
INFO - 2016-09-01 03:37:26 --> Router Class Initialized
INFO - 2016-09-01 03:37:26 --> Output Class Initialized
INFO - 2016-09-01 03:37:26 --> Security Class Initialized
DEBUG - 2016-09-01 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 03:37:26 --> Input Class Initialized
INFO - 2016-09-01 03:37:26 --> Language Class Initialized
ERROR - 2016-09-01 03:37:26 --> 404 Page Not Found: Faviconico/index
INFO - 2016-09-01 03:37:26 --> Config Class Initialized
INFO - 2016-09-01 03:37:26 --> Hooks Class Initialized
DEBUG - 2016-09-01 03:37:26 --> UTF-8 Support Enabled
INFO - 2016-09-01 03:37:26 --> Utf8 Class Initialized
INFO - 2016-09-01 03:37:26 --> URI Class Initialized
INFO - 2016-09-01 03:37:26 --> Router Class Initialized
INFO - 2016-09-01 03:37:26 --> Output Class Initialized
INFO - 2016-09-01 03:37:26 --> Security Class Initialized
DEBUG - 2016-09-01 03:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-09-01 03:37:26 --> Input Class Initialized
INFO - 2016-09-01 03:37:26 --> Language Class Initialized
ERROR - 2016-09-01 03:37:26 --> 404 Page Not Found: Faviconico/index
