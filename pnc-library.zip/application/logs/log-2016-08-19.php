<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-19 02:33:49 --> Config Class Initialized
INFO - 2016-08-19 02:33:49 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:50 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:50 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:50 --> URI Class Initialized
DEBUG - 2016-08-19 02:33:50 --> No URI present. Default controller set.
INFO - 2016-08-19 02:33:50 --> Router Class Initialized
INFO - 2016-08-19 02:33:50 --> Output Class Initialized
INFO - 2016-08-19 02:33:50 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:50 --> Input Class Initialized
INFO - 2016-08-19 02:33:50 --> Language Class Initialized
INFO - 2016-08-19 02:33:50 --> Loader Class Initialized
INFO - 2016-08-19 02:33:51 --> Helper loaded: url_helper
INFO - 2016-08-19 02:33:51 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:33:51 --> Helper loaded: html_helper
INFO - 2016-08-19 02:33:51 --> Helper loaded: form_helper
INFO - 2016-08-19 02:33:51 --> Helper loaded: file_helper
INFO - 2016-08-19 02:33:51 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:33:51 --> Database Driver Class Initialized
INFO - 2016-08-19 02:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:33:52 --> Form Validation Class Initialized
INFO - 2016-08-19 02:33:52 --> Email Class Initialized
INFO - 2016-08-19 02:33:52 --> Controller Class Initialized
INFO - 2016-08-19 02:33:52 --> Config Class Initialized
INFO - 2016-08-19 02:33:52 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:52 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:52 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:52 --> URI Class Initialized
INFO - 2016-08-19 02:33:52 --> Router Class Initialized
INFO - 2016-08-19 02:33:52 --> Output Class Initialized
INFO - 2016-08-19 02:33:52 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:52 --> Input Class Initialized
INFO - 2016-08-19 02:33:52 --> Language Class Initialized
INFO - 2016-08-19 02:33:52 --> Loader Class Initialized
INFO - 2016-08-19 02:33:52 --> Helper loaded: url_helper
INFO - 2016-08-19 02:33:52 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:33:52 --> Helper loaded: html_helper
INFO - 2016-08-19 02:33:52 --> Helper loaded: form_helper
INFO - 2016-08-19 02:33:52 --> Helper loaded: file_helper
INFO - 2016-08-19 02:33:52 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:33:52 --> Database Driver Class Initialized
INFO - 2016-08-19 02:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:33:52 --> Form Validation Class Initialized
INFO - 2016-08-19 02:33:52 --> Email Class Initialized
INFO - 2016-08-19 02:33:52 --> Controller Class Initialized
INFO - 2016-08-19 02:33:52 --> Model Class Initialized
DEBUG - 2016-08-19 02:33:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 02:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 02:33:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:33:53 --> Final output sent to browser
DEBUG - 2016-08-19 02:33:53 --> Total execution time: 0.7868
INFO - 2016-08-19 02:33:54 --> Config Class Initialized
INFO - 2016-08-19 02:33:54 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:54 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:54 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:54 --> URI Class Initialized
INFO - 2016-08-19 02:33:54 --> Router Class Initialized
INFO - 2016-08-19 02:33:54 --> Output Class Initialized
INFO - 2016-08-19 02:33:54 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:54 --> Input Class Initialized
INFO - 2016-08-19 02:33:54 --> Language Class Initialized
ERROR - 2016-08-19 02:33:54 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-19 02:33:54 --> Config Class Initialized
INFO - 2016-08-19 02:33:54 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:54 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:54 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:54 --> URI Class Initialized
INFO - 2016-08-19 02:33:54 --> Router Class Initialized
INFO - 2016-08-19 02:33:54 --> Output Class Initialized
INFO - 2016-08-19 02:33:54 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:54 --> Input Class Initialized
INFO - 2016-08-19 02:33:54 --> Language Class Initialized
ERROR - 2016-08-19 02:33:54 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-19 02:33:57 --> Config Class Initialized
INFO - 2016-08-19 02:33:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:57 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:57 --> URI Class Initialized
INFO - 2016-08-19 02:33:57 --> Router Class Initialized
INFO - 2016-08-19 02:33:57 --> Output Class Initialized
INFO - 2016-08-19 02:33:57 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:57 --> Input Class Initialized
INFO - 2016-08-19 02:33:57 --> Language Class Initialized
INFO - 2016-08-19 02:33:57 --> Loader Class Initialized
INFO - 2016-08-19 02:33:57 --> Helper loaded: url_helper
INFO - 2016-08-19 02:33:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:33:57 --> Helper loaded: html_helper
INFO - 2016-08-19 02:33:57 --> Helper loaded: form_helper
INFO - 2016-08-19 02:33:57 --> Helper loaded: file_helper
INFO - 2016-08-19 02:33:57 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:33:57 --> Database Driver Class Initialized
INFO - 2016-08-19 02:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:33:57 --> Form Validation Class Initialized
INFO - 2016-08-19 02:33:57 --> Email Class Initialized
INFO - 2016-08-19 02:33:57 --> Controller Class Initialized
INFO - 2016-08-19 02:33:57 --> Model Class Initialized
DEBUG - 2016-08-19 02:33:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:33:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 02:33:58 --> Config Class Initialized
INFO - 2016-08-19 02:33:58 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:33:58 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:33:58 --> Utf8 Class Initialized
INFO - 2016-08-19 02:33:58 --> URI Class Initialized
DEBUG - 2016-08-19 02:33:58 --> No URI present. Default controller set.
INFO - 2016-08-19 02:33:58 --> Router Class Initialized
INFO - 2016-08-19 02:33:58 --> Output Class Initialized
INFO - 2016-08-19 02:33:58 --> Security Class Initialized
DEBUG - 2016-08-19 02:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:33:58 --> Input Class Initialized
INFO - 2016-08-19 02:33:58 --> Language Class Initialized
INFO - 2016-08-19 02:33:58 --> Loader Class Initialized
INFO - 2016-08-19 02:33:58 --> Helper loaded: url_helper
INFO - 2016-08-19 02:33:58 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:33:58 --> Helper loaded: html_helper
INFO - 2016-08-19 02:33:58 --> Helper loaded: form_helper
INFO - 2016-08-19 02:33:58 --> Helper loaded: file_helper
INFO - 2016-08-19 02:33:58 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:33:58 --> Database Driver Class Initialized
INFO - 2016-08-19 02:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:33:58 --> Form Validation Class Initialized
INFO - 2016-08-19 02:33:58 --> Email Class Initialized
INFO - 2016-08-19 02:33:58 --> Controller Class Initialized
INFO - 2016-08-19 02:33:58 --> Model Class Initialized
INFO - 2016-08-19 02:33:58 --> Model Class Initialized
INFO - 2016-08-19 02:33:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:33:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:33:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 02:33:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:33:58 --> Final output sent to browser
DEBUG - 2016-08-19 02:33:58 --> Total execution time: 0.4741
INFO - 2016-08-19 02:34:16 --> Config Class Initialized
INFO - 2016-08-19 02:34:16 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:34:16 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:34:16 --> Utf8 Class Initialized
INFO - 2016-08-19 02:34:16 --> URI Class Initialized
INFO - 2016-08-19 02:34:16 --> Router Class Initialized
INFO - 2016-08-19 02:34:16 --> Output Class Initialized
INFO - 2016-08-19 02:34:16 --> Security Class Initialized
DEBUG - 2016-08-19 02:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:34:16 --> Input Class Initialized
INFO - 2016-08-19 02:34:16 --> Language Class Initialized
INFO - 2016-08-19 02:34:16 --> Loader Class Initialized
INFO - 2016-08-19 02:34:16 --> Helper loaded: url_helper
INFO - 2016-08-19 02:34:16 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:34:16 --> Helper loaded: html_helper
INFO - 2016-08-19 02:34:16 --> Helper loaded: form_helper
INFO - 2016-08-19 02:34:16 --> Helper loaded: file_helper
INFO - 2016-08-19 02:34:16 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:34:16 --> Database Driver Class Initialized
INFO - 2016-08-19 02:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:34:16 --> Form Validation Class Initialized
INFO - 2016-08-19 02:34:16 --> Email Class Initialized
INFO - 2016-08-19 02:34:16 --> Controller Class Initialized
DEBUG - 2016-08-19 02:34:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 02:34:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:34:16 --> Model Class Initialized
INFO - 2016-08-19 02:34:16 --> Model Class Initialized
INFO - 2016-08-19 02:34:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:34:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 02:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:34:17 --> Final output sent to browser
DEBUG - 2016-08-19 02:34:17 --> Total execution time: 0.6776
INFO - 2016-08-19 02:35:20 --> Config Class Initialized
INFO - 2016-08-19 02:35:20 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:35:20 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:35:20 --> Utf8 Class Initialized
INFO - 2016-08-19 02:35:20 --> URI Class Initialized
INFO - 2016-08-19 02:35:20 --> Router Class Initialized
INFO - 2016-08-19 02:35:20 --> Output Class Initialized
INFO - 2016-08-19 02:35:20 --> Security Class Initialized
DEBUG - 2016-08-19 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:35:20 --> Input Class Initialized
INFO - 2016-08-19 02:35:20 --> Language Class Initialized
INFO - 2016-08-19 02:35:20 --> Loader Class Initialized
INFO - 2016-08-19 02:35:20 --> Helper loaded: url_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: html_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: form_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: file_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:35:20 --> Database Driver Class Initialized
INFO - 2016-08-19 02:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:35:20 --> Form Validation Class Initialized
INFO - 2016-08-19 02:35:20 --> Email Class Initialized
INFO - 2016-08-19 02:35:20 --> Controller Class Initialized
INFO - 2016-08-19 02:35:20 --> Model Class Initialized
INFO - 2016-08-19 02:35:20 --> Config Class Initialized
INFO - 2016-08-19 02:35:20 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:35:20 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:35:20 --> Utf8 Class Initialized
INFO - 2016-08-19 02:35:20 --> URI Class Initialized
INFO - 2016-08-19 02:35:20 --> Router Class Initialized
INFO - 2016-08-19 02:35:20 --> Output Class Initialized
INFO - 2016-08-19 02:35:20 --> Security Class Initialized
DEBUG - 2016-08-19 02:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:35:20 --> Input Class Initialized
INFO - 2016-08-19 02:35:20 --> Language Class Initialized
INFO - 2016-08-19 02:35:20 --> Loader Class Initialized
INFO - 2016-08-19 02:35:20 --> Helper loaded: url_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: html_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: form_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: file_helper
INFO - 2016-08-19 02:35:20 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:35:20 --> Database Driver Class Initialized
INFO - 2016-08-19 02:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:35:20 --> Form Validation Class Initialized
INFO - 2016-08-19 02:35:20 --> Email Class Initialized
INFO - 2016-08-19 02:35:20 --> Controller Class Initialized
INFO - 2016-08-19 02:35:20 --> Model Class Initialized
DEBUG - 2016-08-19 02:35:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:35:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 02:35:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:35:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 02:35:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:35:20 --> Final output sent to browser
DEBUG - 2016-08-19 02:35:20 --> Total execution time: 0.2353
INFO - 2016-08-19 02:35:24 --> Config Class Initialized
INFO - 2016-08-19 02:35:24 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:35:24 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:35:24 --> Utf8 Class Initialized
INFO - 2016-08-19 02:35:24 --> URI Class Initialized
INFO - 2016-08-19 02:35:24 --> Router Class Initialized
INFO - 2016-08-19 02:35:24 --> Output Class Initialized
INFO - 2016-08-19 02:35:24 --> Security Class Initialized
DEBUG - 2016-08-19 02:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:35:24 --> Input Class Initialized
INFO - 2016-08-19 02:35:24 --> Language Class Initialized
INFO - 2016-08-19 02:35:24 --> Loader Class Initialized
INFO - 2016-08-19 02:35:24 --> Helper loaded: url_helper
INFO - 2016-08-19 02:35:24 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:35:24 --> Helper loaded: html_helper
INFO - 2016-08-19 02:35:24 --> Helper loaded: form_helper
INFO - 2016-08-19 02:35:24 --> Helper loaded: file_helper
INFO - 2016-08-19 02:35:24 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:35:24 --> Database Driver Class Initialized
INFO - 2016-08-19 02:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:35:24 --> Form Validation Class Initialized
INFO - 2016-08-19 02:35:24 --> Email Class Initialized
INFO - 2016-08-19 02:35:24 --> Controller Class Initialized
INFO - 2016-08-19 02:35:24 --> Model Class Initialized
DEBUG - 2016-08-19 02:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:35:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 02:35:24 --> Config Class Initialized
INFO - 2016-08-19 02:35:24 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:35:25 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:35:25 --> Utf8 Class Initialized
INFO - 2016-08-19 02:35:25 --> URI Class Initialized
INFO - 2016-08-19 02:35:25 --> Router Class Initialized
INFO - 2016-08-19 02:35:25 --> Output Class Initialized
INFO - 2016-08-19 02:35:25 --> Security Class Initialized
DEBUG - 2016-08-19 02:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:35:25 --> Input Class Initialized
INFO - 2016-08-19 02:35:25 --> Language Class Initialized
INFO - 2016-08-19 02:35:25 --> Loader Class Initialized
INFO - 2016-08-19 02:35:25 --> Helper loaded: url_helper
INFO - 2016-08-19 02:35:25 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:35:25 --> Helper loaded: html_helper
INFO - 2016-08-19 02:35:25 --> Helper loaded: form_helper
INFO - 2016-08-19 02:35:25 --> Helper loaded: file_helper
INFO - 2016-08-19 02:35:25 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:35:25 --> Database Driver Class Initialized
INFO - 2016-08-19 02:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:35:25 --> Form Validation Class Initialized
INFO - 2016-08-19 02:35:25 --> Email Class Initialized
INFO - 2016-08-19 02:35:25 --> Controller Class Initialized
DEBUG - 2016-08-19 02:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 02:35:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:35:25 --> Model Class Initialized
INFO - 2016-08-19 02:35:25 --> Model Class Initialized
INFO - 2016-08-19 02:35:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:35:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:35:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 02:35:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:35:25 --> Final output sent to browser
DEBUG - 2016-08-19 02:35:25 --> Total execution time: 0.3551
INFO - 2016-08-19 02:40:28 --> Config Class Initialized
INFO - 2016-08-19 02:40:28 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:40:28 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:40:28 --> Utf8 Class Initialized
INFO - 2016-08-19 02:40:28 --> URI Class Initialized
INFO - 2016-08-19 02:40:28 --> Router Class Initialized
INFO - 2016-08-19 02:40:28 --> Output Class Initialized
INFO - 2016-08-19 02:40:28 --> Security Class Initialized
DEBUG - 2016-08-19 02:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:40:28 --> Input Class Initialized
INFO - 2016-08-19 02:40:28 --> Language Class Initialized
INFO - 2016-08-19 02:40:28 --> Loader Class Initialized
INFO - 2016-08-19 02:40:28 --> Helper loaded: url_helper
INFO - 2016-08-19 02:40:28 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:40:28 --> Helper loaded: html_helper
INFO - 2016-08-19 02:40:28 --> Helper loaded: form_helper
INFO - 2016-08-19 02:40:28 --> Helper loaded: file_helper
INFO - 2016-08-19 02:40:28 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:40:28 --> Database Driver Class Initialized
INFO - 2016-08-19 02:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:40:28 --> Form Validation Class Initialized
INFO - 2016-08-19 02:40:28 --> Email Class Initialized
INFO - 2016-08-19 02:40:28 --> Controller Class Initialized
INFO - 2016-08-19 02:40:28 --> Model Class Initialized
INFO - 2016-08-19 02:40:28 --> Config Class Initialized
INFO - 2016-08-19 02:40:28 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:40:28 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:40:28 --> Utf8 Class Initialized
INFO - 2016-08-19 02:40:28 --> URI Class Initialized
INFO - 2016-08-19 02:40:29 --> Router Class Initialized
INFO - 2016-08-19 02:40:29 --> Output Class Initialized
INFO - 2016-08-19 02:40:29 --> Security Class Initialized
DEBUG - 2016-08-19 02:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:40:29 --> Input Class Initialized
INFO - 2016-08-19 02:40:29 --> Language Class Initialized
INFO - 2016-08-19 02:40:29 --> Loader Class Initialized
INFO - 2016-08-19 02:40:29 --> Helper loaded: url_helper
INFO - 2016-08-19 02:40:29 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:40:29 --> Helper loaded: html_helper
INFO - 2016-08-19 02:40:29 --> Helper loaded: form_helper
INFO - 2016-08-19 02:40:29 --> Helper loaded: file_helper
INFO - 2016-08-19 02:40:29 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:40:29 --> Database Driver Class Initialized
INFO - 2016-08-19 02:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:40:29 --> Form Validation Class Initialized
INFO - 2016-08-19 02:40:29 --> Email Class Initialized
INFO - 2016-08-19 02:40:29 --> Controller Class Initialized
INFO - 2016-08-19 02:40:29 --> Model Class Initialized
DEBUG - 2016-08-19 02:40:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 02:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 02:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:40:29 --> Final output sent to browser
DEBUG - 2016-08-19 02:40:29 --> Total execution time: 0.2378
INFO - 2016-08-19 02:40:33 --> Config Class Initialized
INFO - 2016-08-19 02:40:33 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:40:33 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:40:33 --> Utf8 Class Initialized
INFO - 2016-08-19 02:40:33 --> URI Class Initialized
INFO - 2016-08-19 02:40:33 --> Router Class Initialized
INFO - 2016-08-19 02:40:33 --> Output Class Initialized
INFO - 2016-08-19 02:40:33 --> Security Class Initialized
DEBUG - 2016-08-19 02:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:40:33 --> Input Class Initialized
INFO - 2016-08-19 02:40:33 --> Language Class Initialized
INFO - 2016-08-19 02:40:33 --> Loader Class Initialized
INFO - 2016-08-19 02:40:33 --> Helper loaded: url_helper
INFO - 2016-08-19 02:40:33 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:40:33 --> Helper loaded: html_helper
INFO - 2016-08-19 02:40:33 --> Helper loaded: form_helper
INFO - 2016-08-19 02:40:33 --> Helper loaded: file_helper
INFO - 2016-08-19 02:40:33 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:40:33 --> Database Driver Class Initialized
INFO - 2016-08-19 02:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:40:33 --> Form Validation Class Initialized
INFO - 2016-08-19 02:40:33 --> Email Class Initialized
INFO - 2016-08-19 02:40:33 --> Controller Class Initialized
INFO - 2016-08-19 02:40:33 --> Model Class Initialized
DEBUG - 2016-08-19 02:40:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:40:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 02:40:33 --> Config Class Initialized
INFO - 2016-08-19 02:40:33 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:40:33 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:40:33 --> Utf8 Class Initialized
INFO - 2016-08-19 02:40:33 --> URI Class Initialized
INFO - 2016-08-19 02:40:33 --> Router Class Initialized
INFO - 2016-08-19 02:40:33 --> Output Class Initialized
INFO - 2016-08-19 02:40:33 --> Security Class Initialized
DEBUG - 2016-08-19 02:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:40:33 --> Input Class Initialized
INFO - 2016-08-19 02:40:33 --> Language Class Initialized
INFO - 2016-08-19 02:40:33 --> Loader Class Initialized
INFO - 2016-08-19 02:40:33 --> Helper loaded: url_helper
INFO - 2016-08-19 02:40:34 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:40:34 --> Helper loaded: html_helper
INFO - 2016-08-19 02:40:34 --> Helper loaded: form_helper
INFO - 2016-08-19 02:40:34 --> Helper loaded: file_helper
INFO - 2016-08-19 02:40:34 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:40:34 --> Database Driver Class Initialized
INFO - 2016-08-19 02:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:40:34 --> Form Validation Class Initialized
INFO - 2016-08-19 02:40:34 --> Email Class Initialized
INFO - 2016-08-19 02:40:34 --> Controller Class Initialized
DEBUG - 2016-08-19 02:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 02:40:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:40:34 --> Model Class Initialized
INFO - 2016-08-19 02:40:34 --> Model Class Initialized
INFO - 2016-08-19 02:40:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:40:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:40:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 02:40:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:40:34 --> Final output sent to browser
DEBUG - 2016-08-19 02:40:34 --> Total execution time: 0.3557
INFO - 2016-08-19 02:40:41 --> Config Class Initialized
INFO - 2016-08-19 02:40:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:40:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:40:41 --> Utf8 Class Initialized
INFO - 2016-08-19 02:40:41 --> URI Class Initialized
DEBUG - 2016-08-19 02:40:41 --> No URI present. Default controller set.
INFO - 2016-08-19 02:40:41 --> Router Class Initialized
INFO - 2016-08-19 02:40:41 --> Output Class Initialized
INFO - 2016-08-19 02:40:41 --> Security Class Initialized
DEBUG - 2016-08-19 02:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:40:41 --> Input Class Initialized
INFO - 2016-08-19 02:40:41 --> Language Class Initialized
INFO - 2016-08-19 02:40:41 --> Loader Class Initialized
INFO - 2016-08-19 02:40:41 --> Helper loaded: url_helper
INFO - 2016-08-19 02:40:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:40:41 --> Helper loaded: html_helper
INFO - 2016-08-19 02:40:41 --> Helper loaded: form_helper
INFO - 2016-08-19 02:40:41 --> Helper loaded: file_helper
INFO - 2016-08-19 02:40:41 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:40:41 --> Database Driver Class Initialized
INFO - 2016-08-19 02:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:40:42 --> Form Validation Class Initialized
INFO - 2016-08-19 02:40:42 --> Email Class Initialized
INFO - 2016-08-19 02:40:42 --> Controller Class Initialized
INFO - 2016-08-19 02:40:42 --> Model Class Initialized
INFO - 2016-08-19 02:40:42 --> Model Class Initialized
INFO - 2016-08-19 02:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 02:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:40:42 --> Final output sent to browser
DEBUG - 2016-08-19 02:40:42 --> Total execution time: 0.2454
INFO - 2016-08-19 02:41:53 --> Config Class Initialized
INFO - 2016-08-19 02:41:53 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:41:53 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:41:53 --> Utf8 Class Initialized
INFO - 2016-08-19 02:41:53 --> URI Class Initialized
DEBUG - 2016-08-19 02:41:53 --> No URI present. Default controller set.
INFO - 2016-08-19 02:41:53 --> Router Class Initialized
INFO - 2016-08-19 02:41:53 --> Output Class Initialized
INFO - 2016-08-19 02:41:53 --> Security Class Initialized
DEBUG - 2016-08-19 02:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:41:53 --> Input Class Initialized
INFO - 2016-08-19 02:41:53 --> Language Class Initialized
INFO - 2016-08-19 02:41:53 --> Loader Class Initialized
INFO - 2016-08-19 02:41:53 --> Helper loaded: url_helper
INFO - 2016-08-19 02:41:53 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:41:53 --> Helper loaded: html_helper
INFO - 2016-08-19 02:41:53 --> Helper loaded: form_helper
INFO - 2016-08-19 02:41:53 --> Helper loaded: file_helper
INFO - 2016-08-19 02:41:53 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:41:53 --> Database Driver Class Initialized
INFO - 2016-08-19 02:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:41:53 --> Form Validation Class Initialized
INFO - 2016-08-19 02:41:53 --> Email Class Initialized
INFO - 2016-08-19 02:41:53 --> Controller Class Initialized
INFO - 2016-08-19 02:41:53 --> Model Class Initialized
INFO - 2016-08-19 02:41:53 --> Model Class Initialized
INFO - 2016-08-19 02:41:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:41:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:41:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 02:41:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:41:53 --> Final output sent to browser
DEBUG - 2016-08-19 02:41:53 --> Total execution time: 0.2558
INFO - 2016-08-19 02:41:56 --> Config Class Initialized
INFO - 2016-08-19 02:41:56 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:41:56 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:41:56 --> Utf8 Class Initialized
INFO - 2016-08-19 02:41:56 --> URI Class Initialized
INFO - 2016-08-19 02:41:56 --> Router Class Initialized
INFO - 2016-08-19 02:41:56 --> Output Class Initialized
INFO - 2016-08-19 02:41:56 --> Security Class Initialized
DEBUG - 2016-08-19 02:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:41:56 --> Input Class Initialized
INFO - 2016-08-19 02:41:56 --> Language Class Initialized
INFO - 2016-08-19 02:41:56 --> Loader Class Initialized
INFO - 2016-08-19 02:41:56 --> Helper loaded: url_helper
INFO - 2016-08-19 02:41:56 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:41:56 --> Helper loaded: html_helper
INFO - 2016-08-19 02:41:56 --> Helper loaded: form_helper
INFO - 2016-08-19 02:41:56 --> Helper loaded: file_helper
INFO - 2016-08-19 02:41:56 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:41:56 --> Database Driver Class Initialized
INFO - 2016-08-19 02:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:41:57 --> Form Validation Class Initialized
INFO - 2016-08-19 02:41:57 --> Email Class Initialized
INFO - 2016-08-19 02:41:57 --> Controller Class Initialized
INFO - 2016-08-19 02:41:57 --> Model Class Initialized
INFO - 2016-08-19 02:41:57 --> Config Class Initialized
INFO - 2016-08-19 02:41:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:41:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:41:57 --> Utf8 Class Initialized
INFO - 2016-08-19 02:41:57 --> URI Class Initialized
INFO - 2016-08-19 02:41:57 --> Router Class Initialized
INFO - 2016-08-19 02:41:57 --> Output Class Initialized
INFO - 2016-08-19 02:41:57 --> Security Class Initialized
DEBUG - 2016-08-19 02:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:41:57 --> Input Class Initialized
INFO - 2016-08-19 02:41:57 --> Language Class Initialized
INFO - 2016-08-19 02:41:57 --> Loader Class Initialized
INFO - 2016-08-19 02:41:57 --> Helper loaded: url_helper
INFO - 2016-08-19 02:41:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:41:57 --> Helper loaded: html_helper
INFO - 2016-08-19 02:41:57 --> Helper loaded: form_helper
INFO - 2016-08-19 02:41:57 --> Helper loaded: file_helper
INFO - 2016-08-19 02:41:57 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:41:57 --> Database Driver Class Initialized
INFO - 2016-08-19 02:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:41:57 --> Form Validation Class Initialized
INFO - 2016-08-19 02:41:57 --> Email Class Initialized
INFO - 2016-08-19 02:41:57 --> Controller Class Initialized
INFO - 2016-08-19 02:41:57 --> Model Class Initialized
DEBUG - 2016-08-19 02:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:41:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 02:41:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:41:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 02:41:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:41:57 --> Final output sent to browser
DEBUG - 2016-08-19 02:41:57 --> Total execution time: 0.2678
INFO - 2016-08-19 02:42:00 --> Config Class Initialized
INFO - 2016-08-19 02:42:00 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:00 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:00 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:00 --> URI Class Initialized
INFO - 2016-08-19 02:42:00 --> Router Class Initialized
INFO - 2016-08-19 02:42:00 --> Output Class Initialized
INFO - 2016-08-19 02:42:00 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:00 --> Input Class Initialized
INFO - 2016-08-19 02:42:00 --> Language Class Initialized
INFO - 2016-08-19 02:42:00 --> Loader Class Initialized
INFO - 2016-08-19 02:42:00 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:00 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:00 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:00 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:00 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:00 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:00 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:00 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:00 --> Email Class Initialized
INFO - 2016-08-19 02:42:00 --> Controller Class Initialized
INFO - 2016-08-19 02:42:00 --> Model Class Initialized
DEBUG - 2016-08-19 02:42:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:42:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 02:42:00 --> Config Class Initialized
INFO - 2016-08-19 02:42:00 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:00 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:00 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:00 --> URI Class Initialized
INFO - 2016-08-19 02:42:00 --> Router Class Initialized
INFO - 2016-08-19 02:42:00 --> Output Class Initialized
INFO - 2016-08-19 02:42:00 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:00 --> Input Class Initialized
INFO - 2016-08-19 02:42:00 --> Language Class Initialized
INFO - 2016-08-19 02:42:01 --> Loader Class Initialized
INFO - 2016-08-19 02:42:01 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:01 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:01 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:01 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:01 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:01 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:01 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:01 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:01 --> Email Class Initialized
INFO - 2016-08-19 02:42:01 --> Controller Class Initialized
INFO - 2016-08-19 02:42:01 --> Model Class Initialized
INFO - 2016-08-19 02:42:01 --> Model Class Initialized
INFO - 2016-08-19 02:42:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:42:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:42:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-19 02:42:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:42:01 --> Final output sent to browser
DEBUG - 2016-08-19 02:42:01 --> Total execution time: 0.2653
INFO - 2016-08-19 02:42:04 --> Config Class Initialized
INFO - 2016-08-19 02:42:04 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:04 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:04 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:04 --> URI Class Initialized
INFO - 2016-08-19 02:42:04 --> Router Class Initialized
INFO - 2016-08-19 02:42:04 --> Output Class Initialized
INFO - 2016-08-19 02:42:04 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:04 --> Input Class Initialized
INFO - 2016-08-19 02:42:04 --> Language Class Initialized
INFO - 2016-08-19 02:42:04 --> Loader Class Initialized
INFO - 2016-08-19 02:42:04 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:04 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:04 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:04 --> Email Class Initialized
INFO - 2016-08-19 02:42:04 --> Controller Class Initialized
INFO - 2016-08-19 02:42:04 --> Model Class Initialized
INFO - 2016-08-19 02:42:04 --> Config Class Initialized
INFO - 2016-08-19 02:42:04 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:04 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:04 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:04 --> URI Class Initialized
INFO - 2016-08-19 02:42:04 --> Router Class Initialized
INFO - 2016-08-19 02:42:04 --> Output Class Initialized
INFO - 2016-08-19 02:42:04 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:04 --> Input Class Initialized
INFO - 2016-08-19 02:42:04 --> Language Class Initialized
INFO - 2016-08-19 02:42:04 --> Loader Class Initialized
INFO - 2016-08-19 02:42:04 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:04 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:04 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:04 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:04 --> Email Class Initialized
INFO - 2016-08-19 02:42:04 --> Controller Class Initialized
INFO - 2016-08-19 02:42:04 --> Model Class Initialized
DEBUG - 2016-08-19 02:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 02:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 02:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:42:04 --> Final output sent to browser
DEBUG - 2016-08-19 02:42:04 --> Total execution time: 0.2609
INFO - 2016-08-19 02:42:07 --> Config Class Initialized
INFO - 2016-08-19 02:42:07 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:07 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:07 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:07 --> URI Class Initialized
INFO - 2016-08-19 02:42:07 --> Router Class Initialized
INFO - 2016-08-19 02:42:07 --> Output Class Initialized
INFO - 2016-08-19 02:42:07 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:07 --> Input Class Initialized
INFO - 2016-08-19 02:42:07 --> Language Class Initialized
INFO - 2016-08-19 02:42:07 --> Loader Class Initialized
INFO - 2016-08-19 02:42:07 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:07 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:07 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:07 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:07 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:07 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:07 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:07 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:07 --> Email Class Initialized
INFO - 2016-08-19 02:42:07 --> Controller Class Initialized
INFO - 2016-08-19 02:42:07 --> Model Class Initialized
DEBUG - 2016-08-19 02:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:42:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 02:42:08 --> Config Class Initialized
INFO - 2016-08-19 02:42:08 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:42:08 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:42:08 --> Utf8 Class Initialized
INFO - 2016-08-19 02:42:08 --> URI Class Initialized
INFO - 2016-08-19 02:42:08 --> Router Class Initialized
INFO - 2016-08-19 02:42:08 --> Output Class Initialized
INFO - 2016-08-19 02:42:08 --> Security Class Initialized
DEBUG - 2016-08-19 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:42:08 --> Input Class Initialized
INFO - 2016-08-19 02:42:08 --> Language Class Initialized
INFO - 2016-08-19 02:42:08 --> Loader Class Initialized
INFO - 2016-08-19 02:42:08 --> Helper loaded: url_helper
INFO - 2016-08-19 02:42:08 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:42:08 --> Helper loaded: html_helper
INFO - 2016-08-19 02:42:08 --> Helper loaded: form_helper
INFO - 2016-08-19 02:42:08 --> Helper loaded: file_helper
INFO - 2016-08-19 02:42:08 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:42:08 --> Database Driver Class Initialized
INFO - 2016-08-19 02:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:42:08 --> Form Validation Class Initialized
INFO - 2016-08-19 02:42:08 --> Email Class Initialized
INFO - 2016-08-19 02:42:08 --> Controller Class Initialized
DEBUG - 2016-08-19 02:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 02:42:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:42:08 --> Model Class Initialized
INFO - 2016-08-19 02:42:08 --> Model Class Initialized
INFO - 2016-08-19 02:42:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:42:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:42:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 02:42:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:42:08 --> Final output sent to browser
DEBUG - 2016-08-19 02:42:08 --> Total execution time: 0.3242
INFO - 2016-08-19 02:54:44 --> Config Class Initialized
INFO - 2016-08-19 02:54:44 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:54:44 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:54:44 --> Utf8 Class Initialized
INFO - 2016-08-19 02:54:44 --> URI Class Initialized
INFO - 2016-08-19 02:54:44 --> Router Class Initialized
INFO - 2016-08-19 02:54:44 --> Output Class Initialized
INFO - 2016-08-19 02:54:44 --> Security Class Initialized
DEBUG - 2016-08-19 02:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:54:44 --> Input Class Initialized
INFO - 2016-08-19 02:54:44 --> Language Class Initialized
INFO - 2016-08-19 02:54:44 --> Loader Class Initialized
INFO - 2016-08-19 02:54:44 --> Helper loaded: url_helper
INFO - 2016-08-19 02:54:44 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:54:44 --> Helper loaded: html_helper
INFO - 2016-08-19 02:54:44 --> Helper loaded: form_helper
INFO - 2016-08-19 02:54:44 --> Helper loaded: file_helper
INFO - 2016-08-19 02:54:44 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:54:44 --> Database Driver Class Initialized
INFO - 2016-08-19 02:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:54:44 --> Form Validation Class Initialized
INFO - 2016-08-19 02:54:44 --> Email Class Initialized
INFO - 2016-08-19 02:54:44 --> Controller Class Initialized
DEBUG - 2016-08-19 02:54:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:54:44 --> Model Class Initialized
INFO - 2016-08-19 02:54:44 --> Model Class Initialized
INFO - 2016-08-19 02:54:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:54:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:54:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-19 02:54:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:54:44 --> Final output sent to browser
DEBUG - 2016-08-19 02:54:44 --> Total execution time: 0.2621
INFO - 2016-08-19 02:54:47 --> Config Class Initialized
INFO - 2016-08-19 02:54:47 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:54:47 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:54:47 --> Utf8 Class Initialized
INFO - 2016-08-19 02:54:47 --> URI Class Initialized
INFO - 2016-08-19 02:54:47 --> Router Class Initialized
INFO - 2016-08-19 02:54:47 --> Output Class Initialized
INFO - 2016-08-19 02:54:47 --> Security Class Initialized
DEBUG - 2016-08-19 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:54:47 --> Input Class Initialized
INFO - 2016-08-19 02:54:47 --> Language Class Initialized
INFO - 2016-08-19 02:54:47 --> Loader Class Initialized
INFO - 2016-08-19 02:54:47 --> Helper loaded: url_helper
INFO - 2016-08-19 02:54:47 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:54:47 --> Helper loaded: html_helper
INFO - 2016-08-19 02:54:47 --> Helper loaded: form_helper
INFO - 2016-08-19 02:54:47 --> Helper loaded: file_helper
INFO - 2016-08-19 02:54:47 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:54:47 --> Database Driver Class Initialized
INFO - 2016-08-19 02:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:54:47 --> Form Validation Class Initialized
INFO - 2016-08-19 02:54:47 --> Email Class Initialized
INFO - 2016-08-19 02:54:47 --> Controller Class Initialized
DEBUG - 2016-08-19 02:54:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:54:47 --> Model Class Initialized
INFO - 2016-08-19 02:54:47 --> Model Class Initialized
INFO - 2016-08-19 02:54:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:54:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:54:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 02:54:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:54:48 --> Final output sent to browser
DEBUG - 2016-08-19 02:54:48 --> Total execution time: 0.3733
INFO - 2016-08-19 02:54:56 --> Config Class Initialized
INFO - 2016-08-19 02:54:56 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:54:56 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:54:56 --> Utf8 Class Initialized
INFO - 2016-08-19 02:54:56 --> URI Class Initialized
INFO - 2016-08-19 02:54:56 --> Router Class Initialized
INFO - 2016-08-19 02:54:56 --> Output Class Initialized
INFO - 2016-08-19 02:54:56 --> Security Class Initialized
DEBUG - 2016-08-19 02:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:54:56 --> Input Class Initialized
INFO - 2016-08-19 02:54:56 --> Language Class Initialized
INFO - 2016-08-19 02:54:56 --> Loader Class Initialized
INFO - 2016-08-19 02:54:56 --> Helper loaded: url_helper
INFO - 2016-08-19 02:54:56 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:54:56 --> Helper loaded: html_helper
INFO - 2016-08-19 02:54:56 --> Helper loaded: form_helper
INFO - 2016-08-19 02:54:56 --> Helper loaded: file_helper
INFO - 2016-08-19 02:54:56 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:54:56 --> Database Driver Class Initialized
INFO - 2016-08-19 02:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:54:56 --> Form Validation Class Initialized
INFO - 2016-08-19 02:54:56 --> Email Class Initialized
INFO - 2016-08-19 02:54:56 --> Controller Class Initialized
DEBUG - 2016-08-19 02:54:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:54:56 --> Model Class Initialized
INFO - 2016-08-19 02:54:56 --> Model Class Initialized
INFO - 2016-08-19 02:54:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:54:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:54:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 02:54:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:54:56 --> Final output sent to browser
DEBUG - 2016-08-19 02:54:56 --> Total execution time: 0.3189
INFO - 2016-08-19 02:55:06 --> Config Class Initialized
INFO - 2016-08-19 02:55:06 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:55:06 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:55:06 --> Utf8 Class Initialized
INFO - 2016-08-19 02:55:06 --> URI Class Initialized
INFO - 2016-08-19 02:55:06 --> Router Class Initialized
INFO - 2016-08-19 02:55:06 --> Output Class Initialized
INFO - 2016-08-19 02:55:06 --> Security Class Initialized
DEBUG - 2016-08-19 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:55:06 --> Input Class Initialized
INFO - 2016-08-19 02:55:06 --> Language Class Initialized
INFO - 2016-08-19 02:55:06 --> Loader Class Initialized
INFO - 2016-08-19 02:55:06 --> Helper loaded: url_helper
INFO - 2016-08-19 02:55:06 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:55:06 --> Helper loaded: html_helper
INFO - 2016-08-19 02:55:06 --> Helper loaded: form_helper
INFO - 2016-08-19 02:55:06 --> Helper loaded: file_helper
INFO - 2016-08-19 02:55:06 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:55:06 --> Database Driver Class Initialized
INFO - 2016-08-19 02:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:55:06 --> Form Validation Class Initialized
INFO - 2016-08-19 02:55:06 --> Email Class Initialized
INFO - 2016-08-19 02:55:06 --> Controller Class Initialized
DEBUG - 2016-08-19 02:55:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:55:06 --> Model Class Initialized
INFO - 2016-08-19 02:55:06 --> Model Class Initialized
INFO - 2016-08-19 02:55:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:55:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:55:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-19 02:55:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:55:06 --> Final output sent to browser
DEBUG - 2016-08-19 02:55:06 --> Total execution time: 0.3268
INFO - 2016-08-19 02:55:13 --> Config Class Initialized
INFO - 2016-08-19 02:55:13 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:55:13 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:55:13 --> Utf8 Class Initialized
INFO - 2016-08-19 02:55:13 --> URI Class Initialized
INFO - 2016-08-19 02:55:13 --> Router Class Initialized
INFO - 2016-08-19 02:55:13 --> Output Class Initialized
INFO - 2016-08-19 02:55:13 --> Security Class Initialized
DEBUG - 2016-08-19 02:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:55:13 --> Input Class Initialized
INFO - 2016-08-19 02:55:13 --> Language Class Initialized
INFO - 2016-08-19 02:55:13 --> Loader Class Initialized
INFO - 2016-08-19 02:55:13 --> Helper loaded: url_helper
INFO - 2016-08-19 02:55:13 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:55:13 --> Helper loaded: html_helper
INFO - 2016-08-19 02:55:13 --> Helper loaded: form_helper
INFO - 2016-08-19 02:55:13 --> Helper loaded: file_helper
INFO - 2016-08-19 02:55:13 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:55:13 --> Database Driver Class Initialized
INFO - 2016-08-19 02:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:55:13 --> Form Validation Class Initialized
INFO - 2016-08-19 02:55:13 --> Email Class Initialized
INFO - 2016-08-19 02:55:13 --> Controller Class Initialized
DEBUG - 2016-08-19 02:55:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:55:13 --> Model Class Initialized
INFO - 2016-08-19 02:55:13 --> Model Class Initialized
INFO - 2016-08-19 02:55:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:55:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:55:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-19 02:55:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:55:13 --> Final output sent to browser
DEBUG - 2016-08-19 02:55:13 --> Total execution time: 0.2866
INFO - 2016-08-19 02:55:26 --> Config Class Initialized
INFO - 2016-08-19 02:55:26 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:55:26 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:55:26 --> Utf8 Class Initialized
INFO - 2016-08-19 02:55:26 --> URI Class Initialized
INFO - 2016-08-19 02:55:27 --> Router Class Initialized
INFO - 2016-08-19 02:55:27 --> Output Class Initialized
INFO - 2016-08-19 02:55:27 --> Security Class Initialized
DEBUG - 2016-08-19 02:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:55:27 --> Input Class Initialized
INFO - 2016-08-19 02:55:27 --> Language Class Initialized
INFO - 2016-08-19 02:55:27 --> Loader Class Initialized
INFO - 2016-08-19 02:55:27 --> Helper loaded: url_helper
INFO - 2016-08-19 02:55:27 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:55:27 --> Helper loaded: html_helper
INFO - 2016-08-19 02:55:27 --> Helper loaded: form_helper
INFO - 2016-08-19 02:55:27 --> Helper loaded: file_helper
INFO - 2016-08-19 02:55:27 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:55:27 --> Database Driver Class Initialized
INFO - 2016-08-19 02:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:55:27 --> Form Validation Class Initialized
INFO - 2016-08-19 02:55:27 --> Email Class Initialized
INFO - 2016-08-19 02:55:27 --> Controller Class Initialized
DEBUG - 2016-08-19 02:55:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:55:27 --> Model Class Initialized
INFO - 2016-08-19 02:55:27 --> Model Class Initialized
INFO - 2016-08-19 02:55:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 02:55:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 02:55:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-19 02:55:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 02:55:27 --> Final output sent to browser
DEBUG - 2016-08-19 02:55:27 --> Total execution time: 0.3512
INFO - 2016-08-19 02:56:56 --> Config Class Initialized
INFO - 2016-08-19 02:56:56 --> Hooks Class Initialized
DEBUG - 2016-08-19 02:56:56 --> UTF-8 Support Enabled
INFO - 2016-08-19 02:56:56 --> Utf8 Class Initialized
INFO - 2016-08-19 02:56:56 --> URI Class Initialized
INFO - 2016-08-19 02:56:56 --> Router Class Initialized
INFO - 2016-08-19 02:56:56 --> Output Class Initialized
INFO - 2016-08-19 02:56:56 --> Security Class Initialized
DEBUG - 2016-08-19 02:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 02:56:56 --> Input Class Initialized
INFO - 2016-08-19 02:56:56 --> Language Class Initialized
INFO - 2016-08-19 02:56:56 --> Loader Class Initialized
INFO - 2016-08-19 02:56:56 --> Helper loaded: url_helper
INFO - 2016-08-19 02:56:56 --> Helper loaded: utils_helper
INFO - 2016-08-19 02:56:56 --> Helper loaded: html_helper
INFO - 2016-08-19 02:56:56 --> Helper loaded: form_helper
INFO - 2016-08-19 02:56:56 --> Helper loaded: file_helper
INFO - 2016-08-19 02:56:56 --> Helper loaded: myemail_helper
INFO - 2016-08-19 02:56:56 --> Database Driver Class Initialized
INFO - 2016-08-19 02:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 02:56:57 --> Form Validation Class Initialized
INFO - 2016-08-19 02:56:57 --> Email Class Initialized
INFO - 2016-08-19 02:56:57 --> Controller Class Initialized
DEBUG - 2016-08-19 02:56:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 02:56:57 --> Model Class Initialized
INFO - 2016-08-19 02:56:57 --> Model Class Initialized
INFO - 2016-08-19 02:56:57 --> Final output sent to browser
DEBUG - 2016-08-19 02:56:57 --> Total execution time: 0.5781
INFO - 2016-08-19 03:03:11 --> Config Class Initialized
INFO - 2016-08-19 03:03:11 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:03:11 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:03:11 --> Utf8 Class Initialized
INFO - 2016-08-19 03:03:11 --> URI Class Initialized
INFO - 2016-08-19 03:03:11 --> Router Class Initialized
INFO - 2016-08-19 03:03:11 --> Output Class Initialized
INFO - 2016-08-19 03:03:11 --> Security Class Initialized
DEBUG - 2016-08-19 03:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:03:11 --> Input Class Initialized
INFO - 2016-08-19 03:03:11 --> Language Class Initialized
INFO - 2016-08-19 03:03:11 --> Loader Class Initialized
INFO - 2016-08-19 03:03:11 --> Helper loaded: url_helper
INFO - 2016-08-19 03:03:11 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:03:11 --> Helper loaded: html_helper
INFO - 2016-08-19 03:03:11 --> Helper loaded: form_helper
INFO - 2016-08-19 03:03:11 --> Helper loaded: file_helper
INFO - 2016-08-19 03:03:11 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:03:11 --> Database Driver Class Initialized
INFO - 2016-08-19 03:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:03:11 --> Form Validation Class Initialized
INFO - 2016-08-19 03:03:11 --> Email Class Initialized
INFO - 2016-08-19 03:03:11 --> Controller Class Initialized
DEBUG - 2016-08-19 03:03:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:03:11 --> Model Class Initialized
INFO - 2016-08-19 03:03:11 --> Model Class Initialized
INFO - 2016-08-19 03:03:11 --> Model Class Initialized
INFO - 2016-08-19 03:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-19 03:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:03:11 --> Final output sent to browser
DEBUG - 2016-08-19 03:03:11 --> Total execution time: 0.6999
INFO - 2016-08-19 03:04:30 --> Config Class Initialized
INFO - 2016-08-19 03:04:30 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:04:30 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:04:30 --> Utf8 Class Initialized
INFO - 2016-08-19 03:04:30 --> URI Class Initialized
INFO - 2016-08-19 03:04:30 --> Router Class Initialized
INFO - 2016-08-19 03:04:30 --> Output Class Initialized
INFO - 2016-08-19 03:04:30 --> Security Class Initialized
DEBUG - 2016-08-19 03:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:04:30 --> Input Class Initialized
INFO - 2016-08-19 03:04:30 --> Language Class Initialized
INFO - 2016-08-19 03:04:30 --> Loader Class Initialized
INFO - 2016-08-19 03:04:30 --> Helper loaded: url_helper
INFO - 2016-08-19 03:04:30 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:04:30 --> Helper loaded: html_helper
INFO - 2016-08-19 03:04:30 --> Helper loaded: form_helper
INFO - 2016-08-19 03:04:30 --> Helper loaded: file_helper
INFO - 2016-08-19 03:04:30 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:04:30 --> Database Driver Class Initialized
INFO - 2016-08-19 03:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:04:30 --> Form Validation Class Initialized
INFO - 2016-08-19 03:04:30 --> Email Class Initialized
INFO - 2016-08-19 03:04:30 --> Controller Class Initialized
INFO - 2016-08-19 03:04:30 --> Model Class Initialized
INFO - 2016-08-19 03:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-19 03:04:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:04:30 --> Final output sent to browser
DEBUG - 2016-08-19 03:04:30 --> Total execution time: 0.3736
INFO - 2016-08-19 03:04:32 --> Config Class Initialized
INFO - 2016-08-19 03:04:32 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:04:32 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:04:32 --> Utf8 Class Initialized
INFO - 2016-08-19 03:04:32 --> URI Class Initialized
INFO - 2016-08-19 03:04:32 --> Router Class Initialized
INFO - 2016-08-19 03:04:32 --> Output Class Initialized
INFO - 2016-08-19 03:04:32 --> Security Class Initialized
DEBUG - 2016-08-19 03:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:04:32 --> Input Class Initialized
INFO - 2016-08-19 03:04:32 --> Language Class Initialized
INFO - 2016-08-19 03:04:32 --> Loader Class Initialized
INFO - 2016-08-19 03:04:32 --> Helper loaded: url_helper
INFO - 2016-08-19 03:04:32 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:04:32 --> Helper loaded: html_helper
INFO - 2016-08-19 03:04:32 --> Helper loaded: form_helper
INFO - 2016-08-19 03:04:32 --> Helper loaded: file_helper
INFO - 2016-08-19 03:04:32 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:04:32 --> Database Driver Class Initialized
INFO - 2016-08-19 03:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:04:32 --> Form Validation Class Initialized
INFO - 2016-08-19 03:04:32 --> Email Class Initialized
INFO - 2016-08-19 03:04:32 --> Controller Class Initialized
INFO - 2016-08-19 03:04:32 --> Model Class Initialized
INFO - 2016-08-19 03:04:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:04:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:04:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-19 03:04:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:04:32 --> Final output sent to browser
DEBUG - 2016-08-19 03:04:32 --> Total execution time: 0.3311
INFO - 2016-08-19 03:04:36 --> Config Class Initialized
INFO - 2016-08-19 03:04:36 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:04:36 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:04:36 --> Utf8 Class Initialized
INFO - 2016-08-19 03:04:36 --> URI Class Initialized
INFO - 2016-08-19 03:04:36 --> Router Class Initialized
INFO - 2016-08-19 03:04:36 --> Output Class Initialized
INFO - 2016-08-19 03:04:36 --> Security Class Initialized
DEBUG - 2016-08-19 03:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:04:36 --> Input Class Initialized
INFO - 2016-08-19 03:04:36 --> Language Class Initialized
INFO - 2016-08-19 03:04:36 --> Loader Class Initialized
INFO - 2016-08-19 03:04:36 --> Helper loaded: url_helper
INFO - 2016-08-19 03:04:36 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:04:36 --> Helper loaded: html_helper
INFO - 2016-08-19 03:04:36 --> Helper loaded: form_helper
INFO - 2016-08-19 03:04:36 --> Helper loaded: file_helper
INFO - 2016-08-19 03:04:36 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:04:36 --> Database Driver Class Initialized
INFO - 2016-08-19 03:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:04:36 --> Form Validation Class Initialized
INFO - 2016-08-19 03:04:36 --> Email Class Initialized
INFO - 2016-08-19 03:04:36 --> Controller Class Initialized
INFO - 2016-08-19 03:04:36 --> Model Class Initialized
INFO - 2016-08-19 03:04:36 --> Model Class Initialized
DEBUG - 2016-08-19 03:04:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:04:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:04:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:04:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-19 03:04:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:04:36 --> Final output sent to browser
DEBUG - 2016-08-19 03:04:36 --> Total execution time: 0.3435
INFO - 2016-08-19 03:04:40 --> Config Class Initialized
INFO - 2016-08-19 03:04:40 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:04:40 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:04:40 --> Utf8 Class Initialized
INFO - 2016-08-19 03:04:40 --> URI Class Initialized
INFO - 2016-08-19 03:04:40 --> Router Class Initialized
INFO - 2016-08-19 03:04:40 --> Output Class Initialized
INFO - 2016-08-19 03:04:40 --> Security Class Initialized
DEBUG - 2016-08-19 03:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:04:40 --> Input Class Initialized
INFO - 2016-08-19 03:04:40 --> Language Class Initialized
INFO - 2016-08-19 03:04:40 --> Loader Class Initialized
INFO - 2016-08-19 03:04:40 --> Helper loaded: url_helper
INFO - 2016-08-19 03:04:40 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:04:40 --> Helper loaded: html_helper
INFO - 2016-08-19 03:04:40 --> Helper loaded: form_helper
INFO - 2016-08-19 03:04:40 --> Helper loaded: file_helper
INFO - 2016-08-19 03:04:40 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:04:40 --> Database Driver Class Initialized
INFO - 2016-08-19 03:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:04:40 --> Form Validation Class Initialized
INFO - 2016-08-19 03:04:40 --> Email Class Initialized
INFO - 2016-08-19 03:04:40 --> Controller Class Initialized
DEBUG - 2016-08-19 03:04:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:04:40 --> Model Class Initialized
INFO - 2016-08-19 03:04:40 --> Model Class Initialized
INFO - 2016-08-19 03:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-19 03:04:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:04:40 --> Final output sent to browser
DEBUG - 2016-08-19 03:04:40 --> Total execution time: 0.3588
INFO - 2016-08-19 03:05:47 --> Config Class Initialized
INFO - 2016-08-19 03:05:47 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:05:47 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:05:47 --> Utf8 Class Initialized
INFO - 2016-08-19 03:05:47 --> URI Class Initialized
INFO - 2016-08-19 03:05:47 --> Router Class Initialized
INFO - 2016-08-19 03:05:47 --> Output Class Initialized
INFO - 2016-08-19 03:05:47 --> Security Class Initialized
DEBUG - 2016-08-19 03:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:05:47 --> Input Class Initialized
INFO - 2016-08-19 03:05:47 --> Language Class Initialized
INFO - 2016-08-19 03:05:47 --> Loader Class Initialized
INFO - 2016-08-19 03:05:47 --> Helper loaded: url_helper
INFO - 2016-08-19 03:05:47 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:05:47 --> Helper loaded: html_helper
INFO - 2016-08-19 03:05:47 --> Helper loaded: form_helper
INFO - 2016-08-19 03:05:47 --> Helper loaded: file_helper
INFO - 2016-08-19 03:05:47 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:05:47 --> Database Driver Class Initialized
INFO - 2016-08-19 03:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:05:47 --> Form Validation Class Initialized
INFO - 2016-08-19 03:05:47 --> Email Class Initialized
INFO - 2016-08-19 03:05:47 --> Controller Class Initialized
INFO - 2016-08-19 03:05:47 --> Model Class Initialized
INFO - 2016-08-19 03:05:47 --> Model Class Initialized
INFO - 2016-08-19 03:05:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:05:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:05:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-19 03:05:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:05:48 --> Final output sent to browser
DEBUG - 2016-08-19 03:05:48 --> Total execution time: 1.1157
INFO - 2016-08-19 03:05:51 --> Config Class Initialized
INFO - 2016-08-19 03:05:51 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:05:51 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:05:51 --> Utf8 Class Initialized
INFO - 2016-08-19 03:05:51 --> URI Class Initialized
INFO - 2016-08-19 03:05:51 --> Router Class Initialized
INFO - 2016-08-19 03:05:51 --> Output Class Initialized
INFO - 2016-08-19 03:05:51 --> Security Class Initialized
DEBUG - 2016-08-19 03:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:05:51 --> Input Class Initialized
INFO - 2016-08-19 03:05:51 --> Language Class Initialized
INFO - 2016-08-19 03:05:51 --> Loader Class Initialized
INFO - 2016-08-19 03:05:51 --> Helper loaded: url_helper
INFO - 2016-08-19 03:05:51 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:05:51 --> Helper loaded: html_helper
INFO - 2016-08-19 03:05:51 --> Helper loaded: form_helper
INFO - 2016-08-19 03:05:51 --> Helper loaded: file_helper
INFO - 2016-08-19 03:05:51 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:05:51 --> Database Driver Class Initialized
INFO - 2016-08-19 03:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:05:51 --> Form Validation Class Initialized
INFO - 2016-08-19 03:05:51 --> Email Class Initialized
INFO - 2016-08-19 03:05:51 --> Controller Class Initialized
INFO - 2016-08-19 03:05:51 --> Model Class Initialized
INFO - 2016-08-19 03:05:51 --> Model Class Initialized
INFO - 2016-08-19 03:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:05:51 --> Final output sent to browser
DEBUG - 2016-08-19 03:05:51 --> Total execution time: 0.3288
INFO - 2016-08-19 03:07:39 --> Config Class Initialized
INFO - 2016-08-19 03:07:39 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:07:39 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:07:39 --> Utf8 Class Initialized
INFO - 2016-08-19 03:07:39 --> URI Class Initialized
INFO - 2016-08-19 03:07:39 --> Router Class Initialized
INFO - 2016-08-19 03:07:39 --> Output Class Initialized
INFO - 2016-08-19 03:07:39 --> Security Class Initialized
DEBUG - 2016-08-19 03:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:07:39 --> Input Class Initialized
INFO - 2016-08-19 03:07:39 --> Language Class Initialized
INFO - 2016-08-19 03:07:39 --> Loader Class Initialized
INFO - 2016-08-19 03:07:39 --> Helper loaded: url_helper
INFO - 2016-08-19 03:07:39 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:07:39 --> Helper loaded: html_helper
INFO - 2016-08-19 03:07:39 --> Helper loaded: form_helper
INFO - 2016-08-19 03:07:40 --> Helper loaded: file_helper
INFO - 2016-08-19 03:07:40 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:07:40 --> Database Driver Class Initialized
INFO - 2016-08-19 03:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:07:40 --> Form Validation Class Initialized
INFO - 2016-08-19 03:07:40 --> Email Class Initialized
INFO - 2016-08-19 03:07:40 --> Controller Class Initialized
INFO - 2016-08-19 03:07:40 --> Model Class Initialized
INFO - 2016-08-19 03:07:40 --> Model Class Initialized
INFO - 2016-08-19 03:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-19 03:07:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:07:40 --> Final output sent to browser
DEBUG - 2016-08-19 03:07:40 --> Total execution time: 0.3326
INFO - 2016-08-19 03:08:41 --> Config Class Initialized
INFO - 2016-08-19 03:08:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:08:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:08:41 --> Utf8 Class Initialized
INFO - 2016-08-19 03:08:41 --> URI Class Initialized
INFO - 2016-08-19 03:08:41 --> Router Class Initialized
INFO - 2016-08-19 03:08:41 --> Output Class Initialized
INFO - 2016-08-19 03:08:41 --> Security Class Initialized
DEBUG - 2016-08-19 03:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:08:41 --> Input Class Initialized
INFO - 2016-08-19 03:08:41 --> Language Class Initialized
INFO - 2016-08-19 03:08:41 --> Loader Class Initialized
INFO - 2016-08-19 03:08:41 --> Helper loaded: url_helper
INFO - 2016-08-19 03:08:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:08:41 --> Helper loaded: html_helper
INFO - 2016-08-19 03:08:41 --> Helper loaded: form_helper
INFO - 2016-08-19 03:08:41 --> Helper loaded: file_helper
INFO - 2016-08-19 03:08:42 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:08:42 --> Database Driver Class Initialized
INFO - 2016-08-19 03:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:08:42 --> Form Validation Class Initialized
INFO - 2016-08-19 03:08:42 --> Email Class Initialized
INFO - 2016-08-19 03:08:42 --> Controller Class Initialized
INFO - 2016-08-19 03:08:42 --> Model Class Initialized
INFO - 2016-08-19 03:08:42 --> Model Class Initialized
INFO - 2016-08-19 03:08:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:08:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:08:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-19 03:08:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:08:42 --> Final output sent to browser
DEBUG - 2016-08-19 03:08:42 --> Total execution time: 0.4884
INFO - 2016-08-19 03:08:49 --> Config Class Initialized
INFO - 2016-08-19 03:08:49 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:08:49 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:08:49 --> Utf8 Class Initialized
INFO - 2016-08-19 03:08:49 --> URI Class Initialized
INFO - 2016-08-19 03:08:49 --> Router Class Initialized
INFO - 2016-08-19 03:08:49 --> Output Class Initialized
INFO - 2016-08-19 03:08:49 --> Security Class Initialized
DEBUG - 2016-08-19 03:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:08:49 --> Input Class Initialized
INFO - 2016-08-19 03:08:49 --> Language Class Initialized
INFO - 2016-08-19 03:08:49 --> Loader Class Initialized
INFO - 2016-08-19 03:08:49 --> Helper loaded: url_helper
INFO - 2016-08-19 03:08:49 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:08:49 --> Helper loaded: html_helper
INFO - 2016-08-19 03:08:49 --> Helper loaded: form_helper
INFO - 2016-08-19 03:08:49 --> Helper loaded: file_helper
INFO - 2016-08-19 03:08:49 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:08:49 --> Database Driver Class Initialized
INFO - 2016-08-19 03:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:08:49 --> Form Validation Class Initialized
INFO - 2016-08-19 03:08:49 --> Email Class Initialized
INFO - 2016-08-19 03:08:49 --> Controller Class Initialized
INFO - 2016-08-19 03:08:49 --> Model Class Initialized
INFO - 2016-08-19 03:08:49 --> Model Class Initialized
INFO - 2016-08-19 03:08:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:08:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:08:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:08:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:08:49 --> Final output sent to browser
DEBUG - 2016-08-19 03:08:49 --> Total execution time: 0.3375
INFO - 2016-08-19 03:08:57 --> Config Class Initialized
INFO - 2016-08-19 03:08:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:08:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:08:57 --> Utf8 Class Initialized
INFO - 2016-08-19 03:08:57 --> URI Class Initialized
INFO - 2016-08-19 03:08:57 --> Router Class Initialized
INFO - 2016-08-19 03:08:57 --> Output Class Initialized
INFO - 2016-08-19 03:08:57 --> Security Class Initialized
DEBUG - 2016-08-19 03:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:08:57 --> Input Class Initialized
INFO - 2016-08-19 03:08:57 --> Language Class Initialized
INFO - 2016-08-19 03:08:57 --> Loader Class Initialized
INFO - 2016-08-19 03:08:57 --> Helper loaded: url_helper
INFO - 2016-08-19 03:08:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:08:57 --> Helper loaded: html_helper
INFO - 2016-08-19 03:08:57 --> Helper loaded: form_helper
INFO - 2016-08-19 03:08:57 --> Helper loaded: file_helper
INFO - 2016-08-19 03:08:57 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:08:57 --> Database Driver Class Initialized
INFO - 2016-08-19 03:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:08:57 --> Form Validation Class Initialized
INFO - 2016-08-19 03:08:57 --> Email Class Initialized
INFO - 2016-08-19 03:08:57 --> Controller Class Initialized
INFO - 2016-08-19 03:08:57 --> Model Class Initialized
INFO - 2016-08-19 03:08:57 --> Model Class Initialized
INFO - 2016-08-19 03:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-19 03:08:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:08:58 --> Final output sent to browser
DEBUG - 2016-08-19 03:08:58 --> Total execution time: 0.3505
INFO - 2016-08-19 03:09:47 --> Config Class Initialized
INFO - 2016-08-19 03:09:47 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:09:47 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:09:47 --> Utf8 Class Initialized
INFO - 2016-08-19 03:09:47 --> URI Class Initialized
INFO - 2016-08-19 03:09:47 --> Router Class Initialized
INFO - 2016-08-19 03:09:47 --> Output Class Initialized
INFO - 2016-08-19 03:09:47 --> Security Class Initialized
DEBUG - 2016-08-19 03:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:09:47 --> Input Class Initialized
INFO - 2016-08-19 03:09:47 --> Language Class Initialized
INFO - 2016-08-19 03:09:47 --> Loader Class Initialized
INFO - 2016-08-19 03:09:47 --> Helper loaded: url_helper
INFO - 2016-08-19 03:09:47 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:09:47 --> Helper loaded: html_helper
INFO - 2016-08-19 03:09:47 --> Helper loaded: form_helper
INFO - 2016-08-19 03:09:47 --> Helper loaded: file_helper
INFO - 2016-08-19 03:09:47 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:09:47 --> Database Driver Class Initialized
INFO - 2016-08-19 03:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:09:48 --> Form Validation Class Initialized
INFO - 2016-08-19 03:09:48 --> Email Class Initialized
INFO - 2016-08-19 03:09:48 --> Controller Class Initialized
INFO - 2016-08-19 03:09:48 --> Model Class Initialized
INFO - 2016-08-19 03:09:48 --> Model Class Initialized
INFO - 2016-08-19 03:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:09:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:09:48 --> Final output sent to browser
DEBUG - 2016-08-19 03:09:48 --> Total execution time: 0.4269
INFO - 2016-08-19 03:11:10 --> Config Class Initialized
INFO - 2016-08-19 03:11:10 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:11:10 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:11:10 --> Utf8 Class Initialized
INFO - 2016-08-19 03:11:10 --> URI Class Initialized
INFO - 2016-08-19 03:11:10 --> Router Class Initialized
INFO - 2016-08-19 03:11:10 --> Output Class Initialized
INFO - 2016-08-19 03:11:10 --> Security Class Initialized
DEBUG - 2016-08-19 03:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:11:10 --> Input Class Initialized
INFO - 2016-08-19 03:11:10 --> Language Class Initialized
INFO - 2016-08-19 03:11:10 --> Loader Class Initialized
INFO - 2016-08-19 03:11:10 --> Helper loaded: url_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: html_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: form_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: file_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:11:10 --> Database Driver Class Initialized
INFO - 2016-08-19 03:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:11:10 --> Form Validation Class Initialized
INFO - 2016-08-19 03:11:10 --> Email Class Initialized
INFO - 2016-08-19 03:11:10 --> Controller Class Initialized
INFO - 2016-08-19 03:11:10 --> Model Class Initialized
INFO - 2016-08-19 03:11:10 --> Model Class Initialized
INFO - 2016-08-19 03:11:10 --> Config Class Initialized
INFO - 2016-08-19 03:11:10 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:11:10 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:11:10 --> Utf8 Class Initialized
INFO - 2016-08-19 03:11:10 --> URI Class Initialized
INFO - 2016-08-19 03:11:10 --> Router Class Initialized
INFO - 2016-08-19 03:11:10 --> Output Class Initialized
INFO - 2016-08-19 03:11:10 --> Security Class Initialized
DEBUG - 2016-08-19 03:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:11:10 --> Input Class Initialized
INFO - 2016-08-19 03:11:10 --> Language Class Initialized
INFO - 2016-08-19 03:11:10 --> Loader Class Initialized
INFO - 2016-08-19 03:11:10 --> Helper loaded: url_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: html_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: form_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: file_helper
INFO - 2016-08-19 03:11:10 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:11:10 --> Database Driver Class Initialized
INFO - 2016-08-19 03:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:11:10 --> Form Validation Class Initialized
INFO - 2016-08-19 03:11:10 --> Email Class Initialized
INFO - 2016-08-19 03:11:10 --> Controller Class Initialized
INFO - 2016-08-19 03:11:10 --> Model Class Initialized
INFO - 2016-08-19 03:11:10 --> Model Class Initialized
INFO - 2016-08-19 03:11:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:11:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:11:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:11:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:11:10 --> Final output sent to browser
DEBUG - 2016-08-19 03:11:10 --> Total execution time: 0.3548
INFO - 2016-08-19 03:11:17 --> Config Class Initialized
INFO - 2016-08-19 03:11:17 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:11:17 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:11:17 --> Utf8 Class Initialized
INFO - 2016-08-19 03:11:17 --> URI Class Initialized
INFO - 2016-08-19 03:11:17 --> Router Class Initialized
INFO - 2016-08-19 03:11:17 --> Output Class Initialized
INFO - 2016-08-19 03:11:17 --> Security Class Initialized
DEBUG - 2016-08-19 03:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:11:17 --> Input Class Initialized
INFO - 2016-08-19 03:11:17 --> Language Class Initialized
INFO - 2016-08-19 03:11:17 --> Loader Class Initialized
INFO - 2016-08-19 03:11:17 --> Helper loaded: url_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: html_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: form_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: file_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:11:17 --> Database Driver Class Initialized
INFO - 2016-08-19 03:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:11:17 --> Form Validation Class Initialized
INFO - 2016-08-19 03:11:17 --> Email Class Initialized
INFO - 2016-08-19 03:11:17 --> Controller Class Initialized
INFO - 2016-08-19 03:11:17 --> Model Class Initialized
INFO - 2016-08-19 03:11:17 --> Model Class Initialized
INFO - 2016-08-19 03:11:17 --> Config Class Initialized
INFO - 2016-08-19 03:11:17 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:11:17 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:11:17 --> Utf8 Class Initialized
INFO - 2016-08-19 03:11:17 --> URI Class Initialized
INFO - 2016-08-19 03:11:17 --> Router Class Initialized
INFO - 2016-08-19 03:11:17 --> Output Class Initialized
INFO - 2016-08-19 03:11:17 --> Security Class Initialized
DEBUG - 2016-08-19 03:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:11:17 --> Input Class Initialized
INFO - 2016-08-19 03:11:17 --> Language Class Initialized
INFO - 2016-08-19 03:11:17 --> Loader Class Initialized
INFO - 2016-08-19 03:11:17 --> Helper loaded: url_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: html_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: form_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: file_helper
INFO - 2016-08-19 03:11:17 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:11:17 --> Database Driver Class Initialized
INFO - 2016-08-19 03:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:11:17 --> Form Validation Class Initialized
INFO - 2016-08-19 03:11:17 --> Email Class Initialized
INFO - 2016-08-19 03:11:17 --> Controller Class Initialized
INFO - 2016-08-19 03:11:17 --> Model Class Initialized
INFO - 2016-08-19 03:11:17 --> Model Class Initialized
INFO - 2016-08-19 03:11:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:11:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:11:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:11:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:11:17 --> Final output sent to browser
DEBUG - 2016-08-19 03:11:17 --> Total execution time: 0.3304
INFO - 2016-08-19 03:11:21 --> Config Class Initialized
INFO - 2016-08-19 03:11:21 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:11:21 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:11:21 --> Utf8 Class Initialized
INFO - 2016-08-19 03:11:21 --> URI Class Initialized
INFO - 2016-08-19 03:11:21 --> Router Class Initialized
INFO - 2016-08-19 03:11:21 --> Output Class Initialized
INFO - 2016-08-19 03:11:21 --> Security Class Initialized
DEBUG - 2016-08-19 03:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:11:21 --> Input Class Initialized
INFO - 2016-08-19 03:11:21 --> Language Class Initialized
INFO - 2016-08-19 03:11:21 --> Loader Class Initialized
INFO - 2016-08-19 03:11:21 --> Helper loaded: url_helper
INFO - 2016-08-19 03:11:21 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:11:21 --> Helper loaded: html_helper
INFO - 2016-08-19 03:11:21 --> Helper loaded: form_helper
INFO - 2016-08-19 03:11:21 --> Helper loaded: file_helper
INFO - 2016-08-19 03:11:21 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:11:21 --> Database Driver Class Initialized
INFO - 2016-08-19 03:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:11:21 --> Form Validation Class Initialized
INFO - 2016-08-19 03:11:21 --> Email Class Initialized
INFO - 2016-08-19 03:11:21 --> Controller Class Initialized
INFO - 2016-08-19 03:11:21 --> Model Class Initialized
INFO - 2016-08-19 03:11:21 --> Model Class Initialized
INFO - 2016-08-19 03:11:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:11:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:11:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:11:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:11:21 --> Final output sent to browser
DEBUG - 2016-08-19 03:11:21 --> Total execution time: 0.3426
INFO - 2016-08-19 03:12:32 --> Config Class Initialized
INFO - 2016-08-19 03:12:32 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:32 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:32 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:32 --> URI Class Initialized
INFO - 2016-08-19 03:12:32 --> Router Class Initialized
INFO - 2016-08-19 03:12:32 --> Output Class Initialized
INFO - 2016-08-19 03:12:32 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:32 --> Input Class Initialized
INFO - 2016-08-19 03:12:32 --> Language Class Initialized
INFO - 2016-08-19 03:12:32 --> Loader Class Initialized
INFO - 2016-08-19 03:12:32 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:32 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:32 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:32 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:32 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:32 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:32 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:32 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:32 --> Email Class Initialized
INFO - 2016-08-19 03:12:32 --> Controller Class Initialized
INFO - 2016-08-19 03:12:32 --> Model Class Initialized
INFO - 2016-08-19 03:12:32 --> Model Class Initialized
INFO - 2016-08-19 03:12:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:12:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:32 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:32 --> Total execution time: 0.3462
INFO - 2016-08-19 03:12:34 --> Config Class Initialized
INFO - 2016-08-19 03:12:34 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:34 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:34 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:34 --> URI Class Initialized
INFO - 2016-08-19 03:12:34 --> Router Class Initialized
INFO - 2016-08-19 03:12:34 --> Output Class Initialized
INFO - 2016-08-19 03:12:34 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:34 --> Input Class Initialized
INFO - 2016-08-19 03:12:34 --> Language Class Initialized
INFO - 2016-08-19 03:12:34 --> Loader Class Initialized
INFO - 2016-08-19 03:12:34 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:34 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:34 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:34 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:34 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:34 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:34 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:34 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:34 --> Email Class Initialized
INFO - 2016-08-19 03:12:34 --> Controller Class Initialized
DEBUG - 2016-08-19 03:12:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:12:34 --> Model Class Initialized
INFO - 2016-08-19 03:12:34 --> Model Class Initialized
INFO - 2016-08-19 03:12:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-19 03:12:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:34 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:34 --> Total execution time: 0.4539
INFO - 2016-08-19 03:12:40 --> Config Class Initialized
INFO - 2016-08-19 03:12:40 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:40 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:40 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:40 --> URI Class Initialized
INFO - 2016-08-19 03:12:40 --> Router Class Initialized
INFO - 2016-08-19 03:12:40 --> Output Class Initialized
INFO - 2016-08-19 03:12:40 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:40 --> Input Class Initialized
INFO - 2016-08-19 03:12:40 --> Language Class Initialized
INFO - 2016-08-19 03:12:40 --> Loader Class Initialized
INFO - 2016-08-19 03:12:40 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:40 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:40 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:40 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:40 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:40 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:40 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:40 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:40 --> Email Class Initialized
INFO - 2016-08-19 03:12:40 --> Controller Class Initialized
DEBUG - 2016-08-19 03:12:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:12:40 --> Model Class Initialized
INFO - 2016-08-19 03:12:40 --> Model Class Initialized
INFO - 2016-08-19 03:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:40 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:40 --> Total execution time: 0.4254
INFO - 2016-08-19 03:12:42 --> Config Class Initialized
INFO - 2016-08-19 03:12:42 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:42 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:42 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:42 --> URI Class Initialized
INFO - 2016-08-19 03:12:42 --> Router Class Initialized
INFO - 2016-08-19 03:12:42 --> Output Class Initialized
INFO - 2016-08-19 03:12:42 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:42 --> Input Class Initialized
INFO - 2016-08-19 03:12:42 --> Language Class Initialized
INFO - 2016-08-19 03:12:42 --> Loader Class Initialized
INFO - 2016-08-19 03:12:42 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:42 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:43 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:43 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:43 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:43 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:43 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:43 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:43 --> Email Class Initialized
INFO - 2016-08-19 03:12:43 --> Controller Class Initialized
DEBUG - 2016-08-19 03:12:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:12:43 --> Model Class Initialized
INFO - 2016-08-19 03:12:43 --> Model Class Initialized
INFO - 2016-08-19 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:12:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:43 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:43 --> Total execution time: 0.4998
INFO - 2016-08-19 03:12:44 --> Config Class Initialized
INFO - 2016-08-19 03:12:44 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:44 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:44 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:44 --> URI Class Initialized
INFO - 2016-08-19 03:12:44 --> Router Class Initialized
INFO - 2016-08-19 03:12:44 --> Output Class Initialized
INFO - 2016-08-19 03:12:44 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:44 --> Input Class Initialized
INFO - 2016-08-19 03:12:44 --> Language Class Initialized
INFO - 2016-08-19 03:12:44 --> Loader Class Initialized
INFO - 2016-08-19 03:12:44 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:44 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:44 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:44 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:44 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:44 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:44 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:44 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:44 --> Email Class Initialized
INFO - 2016-08-19 03:12:44 --> Controller Class Initialized
DEBUG - 2016-08-19 03:12:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:12:44 --> Model Class Initialized
INFO - 2016-08-19 03:12:44 --> Model Class Initialized
INFO - 2016-08-19 03:12:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-19 03:12:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:45 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:45 --> Total execution time: 0.3821
INFO - 2016-08-19 03:12:53 --> Config Class Initialized
INFO - 2016-08-19 03:12:53 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:53 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:53 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:53 --> URI Class Initialized
INFO - 2016-08-19 03:12:53 --> Router Class Initialized
INFO - 2016-08-19 03:12:53 --> Output Class Initialized
INFO - 2016-08-19 03:12:53 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:53 --> Input Class Initialized
INFO - 2016-08-19 03:12:53 --> Language Class Initialized
INFO - 2016-08-19 03:12:53 --> Loader Class Initialized
INFO - 2016-08-19 03:12:53 --> Helper loaded: url_helper
INFO - 2016-08-19 03:12:53 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:12:53 --> Helper loaded: html_helper
INFO - 2016-08-19 03:12:53 --> Helper loaded: form_helper
INFO - 2016-08-19 03:12:53 --> Helper loaded: file_helper
INFO - 2016-08-19 03:12:53 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:12:54 --> Database Driver Class Initialized
INFO - 2016-08-19 03:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:12:54 --> Form Validation Class Initialized
INFO - 2016-08-19 03:12:54 --> Email Class Initialized
INFO - 2016-08-19 03:12:54 --> Controller Class Initialized
DEBUG - 2016-08-19 03:12:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:12:54 --> Model Class Initialized
INFO - 2016-08-19 03:12:54 --> Model Class Initialized
INFO - 2016-08-19 03:12:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:12:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:12:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:12:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:12:54 --> Final output sent to browser
DEBUG - 2016-08-19 03:12:54 --> Total execution time: 0.3746
INFO - 2016-08-19 03:12:59 --> Config Class Initialized
INFO - 2016-08-19 03:12:59 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:12:59 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:12:59 --> Utf8 Class Initialized
INFO - 2016-08-19 03:12:59 --> URI Class Initialized
INFO - 2016-08-19 03:12:59 --> Router Class Initialized
INFO - 2016-08-19 03:12:59 --> Output Class Initialized
INFO - 2016-08-19 03:12:59 --> Security Class Initialized
DEBUG - 2016-08-19 03:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:12:59 --> Input Class Initialized
INFO - 2016-08-19 03:12:59 --> Language Class Initialized
INFO - 2016-08-19 03:13:00 --> Loader Class Initialized
INFO - 2016-08-19 03:13:00 --> Helper loaded: url_helper
INFO - 2016-08-19 03:13:00 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:13:00 --> Helper loaded: html_helper
INFO - 2016-08-19 03:13:00 --> Helper loaded: form_helper
INFO - 2016-08-19 03:13:00 --> Helper loaded: file_helper
INFO - 2016-08-19 03:13:00 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:13:00 --> Database Driver Class Initialized
INFO - 2016-08-19 03:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:13:00 --> Form Validation Class Initialized
INFO - 2016-08-19 03:13:00 --> Email Class Initialized
INFO - 2016-08-19 03:13:00 --> Controller Class Initialized
INFO - 2016-08-19 03:13:00 --> Model Class Initialized
INFO - 2016-08-19 03:13:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:13:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:13:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-19 03:13:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:13:00 --> Final output sent to browser
DEBUG - 2016-08-19 03:13:00 --> Total execution time: 0.4151
INFO - 2016-08-19 03:13:01 --> Config Class Initialized
INFO - 2016-08-19 03:13:01 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:13:01 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:13:01 --> Utf8 Class Initialized
INFO - 2016-08-19 03:13:01 --> URI Class Initialized
INFO - 2016-08-19 03:13:01 --> Router Class Initialized
INFO - 2016-08-19 03:13:01 --> Output Class Initialized
INFO - 2016-08-19 03:13:01 --> Security Class Initialized
DEBUG - 2016-08-19 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:13:01 --> Input Class Initialized
INFO - 2016-08-19 03:13:01 --> Language Class Initialized
INFO - 2016-08-19 03:13:01 --> Loader Class Initialized
INFO - 2016-08-19 03:13:01 --> Helper loaded: url_helper
INFO - 2016-08-19 03:13:01 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:13:01 --> Helper loaded: html_helper
INFO - 2016-08-19 03:13:01 --> Helper loaded: form_helper
INFO - 2016-08-19 03:13:01 --> Helper loaded: file_helper
INFO - 2016-08-19 03:13:01 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:13:01 --> Database Driver Class Initialized
INFO - 2016-08-19 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:13:01 --> Form Validation Class Initialized
INFO - 2016-08-19 03:13:01 --> Email Class Initialized
INFO - 2016-08-19 03:13:01 --> Controller Class Initialized
DEBUG - 2016-08-19 03:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:13:01 --> Model Class Initialized
INFO - 2016-08-19 03:13:01 --> Model Class Initialized
INFO - 2016-08-19 03:13:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:13:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:13:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:13:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:13:01 --> Final output sent to browser
DEBUG - 2016-08-19 03:13:01 --> Total execution time: 0.4019
INFO - 2016-08-19 03:13:04 --> Config Class Initialized
INFO - 2016-08-19 03:13:04 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:13:04 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:13:04 --> Utf8 Class Initialized
INFO - 2016-08-19 03:13:04 --> URI Class Initialized
INFO - 2016-08-19 03:13:04 --> Router Class Initialized
INFO - 2016-08-19 03:13:04 --> Output Class Initialized
INFO - 2016-08-19 03:13:04 --> Security Class Initialized
DEBUG - 2016-08-19 03:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:13:04 --> Input Class Initialized
INFO - 2016-08-19 03:13:05 --> Language Class Initialized
INFO - 2016-08-19 03:13:05 --> Loader Class Initialized
INFO - 2016-08-19 03:13:05 --> Helper loaded: url_helper
INFO - 2016-08-19 03:13:05 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:13:05 --> Helper loaded: html_helper
INFO - 2016-08-19 03:13:05 --> Helper loaded: form_helper
INFO - 2016-08-19 03:13:05 --> Helper loaded: file_helper
INFO - 2016-08-19 03:13:05 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:13:05 --> Database Driver Class Initialized
INFO - 2016-08-19 03:13:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:13:05 --> Form Validation Class Initialized
INFO - 2016-08-19 03:13:05 --> Email Class Initialized
INFO - 2016-08-19 03:13:05 --> Controller Class Initialized
INFO - 2016-08-19 03:13:05 --> Model Class Initialized
INFO - 2016-08-19 03:13:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:13:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:13:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-19 03:13:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:13:05 --> Final output sent to browser
DEBUG - 2016-08-19 03:13:05 --> Total execution time: 0.3841
INFO - 2016-08-19 03:13:20 --> Config Class Initialized
INFO - 2016-08-19 03:13:20 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:13:20 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:13:20 --> Utf8 Class Initialized
INFO - 2016-08-19 03:13:20 --> URI Class Initialized
INFO - 2016-08-19 03:13:20 --> Router Class Initialized
INFO - 2016-08-19 03:13:20 --> Output Class Initialized
INFO - 2016-08-19 03:13:20 --> Security Class Initialized
DEBUG - 2016-08-19 03:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:13:20 --> Input Class Initialized
INFO - 2016-08-19 03:13:20 --> Language Class Initialized
INFO - 2016-08-19 03:13:20 --> Loader Class Initialized
INFO - 2016-08-19 03:13:20 --> Helper loaded: url_helper
INFO - 2016-08-19 03:13:20 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:13:20 --> Helper loaded: html_helper
INFO - 2016-08-19 03:13:20 --> Helper loaded: form_helper
INFO - 2016-08-19 03:13:20 --> Helper loaded: file_helper
INFO - 2016-08-19 03:13:20 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:13:20 --> Database Driver Class Initialized
INFO - 2016-08-19 03:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:13:20 --> Form Validation Class Initialized
INFO - 2016-08-19 03:13:20 --> Email Class Initialized
INFO - 2016-08-19 03:13:21 --> Controller Class Initialized
DEBUG - 2016-08-19 03:13:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:13:21 --> Model Class Initialized
INFO - 2016-08-19 03:13:21 --> Model Class Initialized
INFO - 2016-08-19 03:13:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:13:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:13:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-19 03:13:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:13:21 --> Final output sent to browser
DEBUG - 2016-08-19 03:13:21 --> Total execution time: 0.3574
INFO - 2016-08-19 03:13:22 --> Config Class Initialized
INFO - 2016-08-19 03:13:22 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:13:22 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:13:22 --> Utf8 Class Initialized
INFO - 2016-08-19 03:13:22 --> URI Class Initialized
INFO - 2016-08-19 03:13:22 --> Router Class Initialized
INFO - 2016-08-19 03:13:22 --> Output Class Initialized
INFO - 2016-08-19 03:13:22 --> Security Class Initialized
DEBUG - 2016-08-19 03:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:13:22 --> Input Class Initialized
INFO - 2016-08-19 03:13:22 --> Language Class Initialized
INFO - 2016-08-19 03:13:22 --> Loader Class Initialized
INFO - 2016-08-19 03:13:22 --> Helper loaded: url_helper
INFO - 2016-08-19 03:13:22 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:13:22 --> Helper loaded: html_helper
INFO - 2016-08-19 03:13:22 --> Helper loaded: form_helper
INFO - 2016-08-19 03:13:22 --> Helper loaded: file_helper
INFO - 2016-08-19 03:13:22 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:13:22 --> Database Driver Class Initialized
INFO - 2016-08-19 03:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:13:22 --> Form Validation Class Initialized
INFO - 2016-08-19 03:13:22 --> Email Class Initialized
INFO - 2016-08-19 03:13:22 --> Controller Class Initialized
DEBUG - 2016-08-19 03:13:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:13:22 --> Model Class Initialized
INFO - 2016-08-19 03:13:22 --> Model Class Initialized
INFO - 2016-08-19 03:13:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:13:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:13:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:13:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:13:22 --> Final output sent to browser
DEBUG - 2016-08-19 03:13:22 --> Total execution time: 0.3889
INFO - 2016-08-19 03:24:10 --> Config Class Initialized
INFO - 2016-08-19 03:24:10 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:24:10 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:24:10 --> Utf8 Class Initialized
INFO - 2016-08-19 03:24:10 --> URI Class Initialized
INFO - 2016-08-19 03:24:10 --> Router Class Initialized
INFO - 2016-08-19 03:24:10 --> Output Class Initialized
INFO - 2016-08-19 03:24:10 --> Security Class Initialized
DEBUG - 2016-08-19 03:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:24:10 --> Input Class Initialized
INFO - 2016-08-19 03:24:10 --> Language Class Initialized
INFO - 2016-08-19 03:24:10 --> Loader Class Initialized
INFO - 2016-08-19 03:24:10 --> Helper loaded: url_helper
INFO - 2016-08-19 03:24:10 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:24:10 --> Helper loaded: html_helper
INFO - 2016-08-19 03:24:10 --> Helper loaded: form_helper
INFO - 2016-08-19 03:24:10 --> Helper loaded: file_helper
INFO - 2016-08-19 03:24:10 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:24:10 --> Database Driver Class Initialized
INFO - 2016-08-19 03:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:24:10 --> Form Validation Class Initialized
INFO - 2016-08-19 03:24:10 --> Email Class Initialized
INFO - 2016-08-19 03:24:10 --> Controller Class Initialized
DEBUG - 2016-08-19 03:24:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:24:10 --> Model Class Initialized
INFO - 2016-08-19 03:24:10 --> Model Class Initialized
INFO - 2016-08-19 03:24:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:24:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:24:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:24:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:24:10 --> Final output sent to browser
DEBUG - 2016-08-19 03:24:10 --> Total execution time: 0.4147
INFO - 2016-08-19 03:24:35 --> Config Class Initialized
INFO - 2016-08-19 03:24:35 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:24:35 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:24:35 --> Utf8 Class Initialized
INFO - 2016-08-19 03:24:35 --> URI Class Initialized
INFO - 2016-08-19 03:24:35 --> Router Class Initialized
INFO - 2016-08-19 03:24:35 --> Output Class Initialized
INFO - 2016-08-19 03:24:35 --> Security Class Initialized
DEBUG - 2016-08-19 03:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:24:35 --> Input Class Initialized
INFO - 2016-08-19 03:24:35 --> Language Class Initialized
INFO - 2016-08-19 03:24:35 --> Loader Class Initialized
INFO - 2016-08-19 03:24:35 --> Helper loaded: url_helper
INFO - 2016-08-19 03:24:35 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:24:35 --> Helper loaded: html_helper
INFO - 2016-08-19 03:24:35 --> Helper loaded: form_helper
INFO - 2016-08-19 03:24:35 --> Helper loaded: file_helper
INFO - 2016-08-19 03:24:35 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:24:35 --> Database Driver Class Initialized
INFO - 2016-08-19 03:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:24:35 --> Form Validation Class Initialized
INFO - 2016-08-19 03:24:35 --> Email Class Initialized
INFO - 2016-08-19 03:24:35 --> Controller Class Initialized
DEBUG - 2016-08-19 03:24:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:24:35 --> Model Class Initialized
INFO - 2016-08-19 03:24:35 --> Model Class Initialized
INFO - 2016-08-19 03:24:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:24:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:24:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:24:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:24:35 --> Final output sent to browser
DEBUG - 2016-08-19 03:24:35 --> Total execution time: 0.4770
INFO - 2016-08-19 03:24:38 --> Config Class Initialized
INFO - 2016-08-19 03:24:38 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:24:38 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:24:38 --> Utf8 Class Initialized
INFO - 2016-08-19 03:24:38 --> URI Class Initialized
INFO - 2016-08-19 03:24:38 --> Router Class Initialized
INFO - 2016-08-19 03:24:38 --> Output Class Initialized
INFO - 2016-08-19 03:24:38 --> Security Class Initialized
DEBUG - 2016-08-19 03:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:24:38 --> Input Class Initialized
INFO - 2016-08-19 03:24:38 --> Language Class Initialized
INFO - 2016-08-19 03:24:38 --> Loader Class Initialized
INFO - 2016-08-19 03:24:38 --> Helper loaded: url_helper
INFO - 2016-08-19 03:24:38 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:24:38 --> Helper loaded: html_helper
INFO - 2016-08-19 03:24:38 --> Helper loaded: form_helper
INFO - 2016-08-19 03:24:38 --> Helper loaded: file_helper
INFO - 2016-08-19 03:24:38 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:24:38 --> Database Driver Class Initialized
INFO - 2016-08-19 03:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:24:38 --> Form Validation Class Initialized
INFO - 2016-08-19 03:24:38 --> Email Class Initialized
INFO - 2016-08-19 03:24:38 --> Controller Class Initialized
INFO - 2016-08-19 03:24:38 --> Model Class Initialized
INFO - 2016-08-19 03:24:38 --> Model Class Initialized
INFO - 2016-08-19 03:24:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:24:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:24:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 03:24:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:24:38 --> Final output sent to browser
DEBUG - 2016-08-19 03:24:38 --> Total execution time: 0.4202
INFO - 2016-08-19 03:52:13 --> Config Class Initialized
INFO - 2016-08-19 03:52:13 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:52:13 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:52:13 --> Utf8 Class Initialized
INFO - 2016-08-19 03:52:13 --> URI Class Initialized
INFO - 2016-08-19 03:52:13 --> Router Class Initialized
INFO - 2016-08-19 03:52:13 --> Output Class Initialized
INFO - 2016-08-19 03:52:13 --> Security Class Initialized
DEBUG - 2016-08-19 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:52:13 --> Input Class Initialized
INFO - 2016-08-19 03:52:14 --> Language Class Initialized
INFO - 2016-08-19 03:52:14 --> Loader Class Initialized
INFO - 2016-08-19 03:52:14 --> Helper loaded: url_helper
INFO - 2016-08-19 03:52:14 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:52:14 --> Helper loaded: html_helper
INFO - 2016-08-19 03:52:14 --> Helper loaded: form_helper
INFO - 2016-08-19 03:52:14 --> Helper loaded: file_helper
INFO - 2016-08-19 03:52:14 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:52:14 --> Database Driver Class Initialized
INFO - 2016-08-19 03:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:52:14 --> Form Validation Class Initialized
INFO - 2016-08-19 03:52:14 --> Email Class Initialized
INFO - 2016-08-19 03:52:14 --> Controller Class Initialized
DEBUG - 2016-08-19 03:52:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:52:14 --> Model Class Initialized
INFO - 2016-08-19 03:52:14 --> Model Class Initialized
INFO - 2016-08-19 03:52:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:52:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:52:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-19 03:52:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:52:14 --> Final output sent to browser
DEBUG - 2016-08-19 03:52:14 --> Total execution time: 0.4004
INFO - 2016-08-19 03:52:17 --> Config Class Initialized
INFO - 2016-08-19 03:52:17 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:52:17 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:52:17 --> Utf8 Class Initialized
INFO - 2016-08-19 03:52:17 --> URI Class Initialized
INFO - 2016-08-19 03:52:17 --> Router Class Initialized
INFO - 2016-08-19 03:52:17 --> Output Class Initialized
INFO - 2016-08-19 03:52:17 --> Security Class Initialized
DEBUG - 2016-08-19 03:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:52:17 --> Input Class Initialized
INFO - 2016-08-19 03:52:17 --> Language Class Initialized
INFO - 2016-08-19 03:52:17 --> Loader Class Initialized
INFO - 2016-08-19 03:52:17 --> Helper loaded: url_helper
INFO - 2016-08-19 03:52:17 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:52:17 --> Helper loaded: html_helper
INFO - 2016-08-19 03:52:17 --> Helper loaded: form_helper
INFO - 2016-08-19 03:52:17 --> Helper loaded: file_helper
INFO - 2016-08-19 03:52:17 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:52:17 --> Database Driver Class Initialized
INFO - 2016-08-19 03:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:52:17 --> Form Validation Class Initialized
INFO - 2016-08-19 03:52:17 --> Email Class Initialized
INFO - 2016-08-19 03:52:18 --> Controller Class Initialized
INFO - 2016-08-19 03:52:18 --> Model Class Initialized
INFO - 2016-08-19 03:52:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:52:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:52:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-19 03:52:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:52:18 --> Final output sent to browser
DEBUG - 2016-08-19 03:52:18 --> Total execution time: 0.3492
INFO - 2016-08-19 03:52:20 --> Config Class Initialized
INFO - 2016-08-19 03:52:20 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:52:20 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:52:20 --> Utf8 Class Initialized
INFO - 2016-08-19 03:52:20 --> URI Class Initialized
INFO - 2016-08-19 03:52:20 --> Router Class Initialized
INFO - 2016-08-19 03:52:20 --> Output Class Initialized
INFO - 2016-08-19 03:52:20 --> Security Class Initialized
DEBUG - 2016-08-19 03:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:52:20 --> Input Class Initialized
INFO - 2016-08-19 03:52:20 --> Language Class Initialized
INFO - 2016-08-19 03:52:20 --> Loader Class Initialized
INFO - 2016-08-19 03:52:20 --> Helper loaded: url_helper
INFO - 2016-08-19 03:52:20 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:52:20 --> Helper loaded: html_helper
INFO - 2016-08-19 03:52:20 --> Helper loaded: form_helper
INFO - 2016-08-19 03:52:20 --> Helper loaded: file_helper
INFO - 2016-08-19 03:52:20 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:52:20 --> Database Driver Class Initialized
INFO - 2016-08-19 03:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:52:20 --> Form Validation Class Initialized
INFO - 2016-08-19 03:52:20 --> Email Class Initialized
INFO - 2016-08-19 03:52:20 --> Controller Class Initialized
DEBUG - 2016-08-19 03:52:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:52:20 --> Model Class Initialized
INFO - 2016-08-19 03:52:20 --> Model Class Initialized
INFO - 2016-08-19 03:52:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:52:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:52:20 --> Model Class Initialized
INFO - 2016-08-19 03:52:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-19 03:52:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:52:20 --> Final output sent to browser
DEBUG - 2016-08-19 03:52:20 --> Total execution time: 0.3994
INFO - 2016-08-19 03:53:03 --> Config Class Initialized
INFO - 2016-08-19 03:53:03 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:03 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:03 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:03 --> URI Class Initialized
INFO - 2016-08-19 03:53:03 --> Router Class Initialized
INFO - 2016-08-19 03:53:03 --> Output Class Initialized
INFO - 2016-08-19 03:53:03 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:03 --> Input Class Initialized
INFO - 2016-08-19 03:53:03 --> Language Class Initialized
INFO - 2016-08-19 03:53:03 --> Loader Class Initialized
INFO - 2016-08-19 03:53:03 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:03 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:03 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:03 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:03 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:03 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:03 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:03 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:03 --> Email Class Initialized
INFO - 2016-08-19 03:53:03 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:03 --> Model Class Initialized
INFO - 2016-08-19 03:53:03 --> Model Class Initialized
INFO - 2016-08-19 03:53:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:03 --> Model Class Initialized
INFO - 2016-08-19 03:53:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-19 03:53:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:03 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:03 --> Total execution time: 0.4243
INFO - 2016-08-19 03:53:09 --> Config Class Initialized
INFO - 2016-08-19 03:53:09 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:09 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:09 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:09 --> URI Class Initialized
INFO - 2016-08-19 03:53:09 --> Router Class Initialized
INFO - 2016-08-19 03:53:09 --> Output Class Initialized
INFO - 2016-08-19 03:53:09 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:09 --> Input Class Initialized
INFO - 2016-08-19 03:53:09 --> Language Class Initialized
INFO - 2016-08-19 03:53:09 --> Loader Class Initialized
INFO - 2016-08-19 03:53:09 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:10 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:10 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:10 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:10 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:10 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:10 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:10 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:10 --> Email Class Initialized
INFO - 2016-08-19 03:53:10 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:10 --> Model Class Initialized
INFO - 2016-08-19 03:53:10 --> Model Class Initialized
INFO - 2016-08-19 03:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:10 --> Model Class Initialized
INFO - 2016-08-19 03:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-19 03:53:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:10 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:10 --> Total execution time: 0.3918
INFO - 2016-08-19 03:53:17 --> Config Class Initialized
INFO - 2016-08-19 03:53:17 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:17 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:17 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:17 --> URI Class Initialized
INFO - 2016-08-19 03:53:17 --> Router Class Initialized
INFO - 2016-08-19 03:53:17 --> Output Class Initialized
INFO - 2016-08-19 03:53:17 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:17 --> Input Class Initialized
INFO - 2016-08-19 03:53:17 --> Language Class Initialized
INFO - 2016-08-19 03:53:17 --> Loader Class Initialized
INFO - 2016-08-19 03:53:17 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:17 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:17 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:17 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:17 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:17 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:17 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:17 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:17 --> Email Class Initialized
INFO - 2016-08-19 03:53:17 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:17 --> Model Class Initialized
INFO - 2016-08-19 03:53:17 --> Model Class Initialized
INFO - 2016-08-19 03:53:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:53:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:17 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:17 --> Total execution time: 0.3814
INFO - 2016-08-19 03:53:27 --> Config Class Initialized
INFO - 2016-08-19 03:53:27 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:27 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:27 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:27 --> URI Class Initialized
INFO - 2016-08-19 03:53:27 --> Router Class Initialized
INFO - 2016-08-19 03:53:27 --> Output Class Initialized
INFO - 2016-08-19 03:53:27 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:27 --> Input Class Initialized
INFO - 2016-08-19 03:53:27 --> Language Class Initialized
INFO - 2016-08-19 03:53:27 --> Loader Class Initialized
INFO - 2016-08-19 03:53:27 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:27 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:27 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:27 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:27 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:27 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:28 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:28 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:28 --> Email Class Initialized
INFO - 2016-08-19 03:53:28 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:28 --> Model Class Initialized
INFO - 2016-08-19 03:53:28 --> Model Class Initialized
INFO - 2016-08-19 03:53:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:53:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:28 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:28 --> Total execution time: 0.4010
INFO - 2016-08-19 03:53:31 --> Config Class Initialized
INFO - 2016-08-19 03:53:31 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:31 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:31 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:31 --> URI Class Initialized
INFO - 2016-08-19 03:53:31 --> Router Class Initialized
INFO - 2016-08-19 03:53:31 --> Output Class Initialized
INFO - 2016-08-19 03:53:31 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:31 --> Input Class Initialized
INFO - 2016-08-19 03:53:31 --> Language Class Initialized
INFO - 2016-08-19 03:53:31 --> Loader Class Initialized
INFO - 2016-08-19 03:53:31 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:31 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:31 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:31 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:31 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:31 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:31 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:31 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:31 --> Email Class Initialized
INFO - 2016-08-19 03:53:31 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:31 --> Model Class Initialized
INFO - 2016-08-19 03:53:31 --> Model Class Initialized
INFO - 2016-08-19 03:53:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 03:53:32 --> Config Class Initialized
INFO - 2016-08-19 03:53:32 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:32 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:32 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:32 --> URI Class Initialized
INFO - 2016-08-19 03:53:32 --> Router Class Initialized
INFO - 2016-08-19 03:53:32 --> Output Class Initialized
INFO - 2016-08-19 03:53:32 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:32 --> Input Class Initialized
INFO - 2016-08-19 03:53:32 --> Language Class Initialized
INFO - 2016-08-19 03:53:32 --> Loader Class Initialized
INFO - 2016-08-19 03:53:32 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:32 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:32 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:32 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:32 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:32 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:32 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:32 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:32 --> Email Class Initialized
INFO - 2016-08-19 03:53:32 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:32 --> Model Class Initialized
INFO - 2016-08-19 03:53:32 --> Model Class Initialized
INFO - 2016-08-19 03:53:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:53:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:32 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:32 --> Total execution time: 0.4421
INFO - 2016-08-19 03:53:38 --> Config Class Initialized
INFO - 2016-08-19 03:53:38 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:38 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:38 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:38 --> URI Class Initialized
INFO - 2016-08-19 03:53:38 --> Router Class Initialized
INFO - 2016-08-19 03:53:38 --> Output Class Initialized
INFO - 2016-08-19 03:53:38 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:38 --> Input Class Initialized
INFO - 2016-08-19 03:53:38 --> Language Class Initialized
INFO - 2016-08-19 03:53:38 --> Loader Class Initialized
INFO - 2016-08-19 03:53:38 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:38 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:38 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:38 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:38 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:39 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:39 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:39 --> Email Class Initialized
INFO - 2016-08-19 03:53:39 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:39 --> Model Class Initialized
INFO - 2016-08-19 03:53:39 --> Model Class Initialized
INFO - 2016-08-19 03:53:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 03:53:39 --> Config Class Initialized
INFO - 2016-08-19 03:53:39 --> Hooks Class Initialized
DEBUG - 2016-08-19 03:53:39 --> UTF-8 Support Enabled
INFO - 2016-08-19 03:53:39 --> Utf8 Class Initialized
INFO - 2016-08-19 03:53:39 --> URI Class Initialized
INFO - 2016-08-19 03:53:39 --> Router Class Initialized
INFO - 2016-08-19 03:53:39 --> Output Class Initialized
INFO - 2016-08-19 03:53:39 --> Security Class Initialized
DEBUG - 2016-08-19 03:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 03:53:39 --> Input Class Initialized
INFO - 2016-08-19 03:53:39 --> Language Class Initialized
INFO - 2016-08-19 03:53:39 --> Loader Class Initialized
INFO - 2016-08-19 03:53:39 --> Helper loaded: url_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: utils_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: html_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: form_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: file_helper
INFO - 2016-08-19 03:53:39 --> Helper loaded: myemail_helper
INFO - 2016-08-19 03:53:39 --> Database Driver Class Initialized
INFO - 2016-08-19 03:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 03:53:39 --> Form Validation Class Initialized
INFO - 2016-08-19 03:53:39 --> Email Class Initialized
INFO - 2016-08-19 03:53:39 --> Controller Class Initialized
DEBUG - 2016-08-19 03:53:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 03:53:39 --> Model Class Initialized
INFO - 2016-08-19 03:53:39 --> Model Class Initialized
INFO - 2016-08-19 03:53:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 03:53:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 03:53:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 03:53:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 03:53:39 --> Final output sent to browser
DEBUG - 2016-08-19 03:53:39 --> Total execution time: 0.3860
INFO - 2016-08-19 04:17:49 --> Config Class Initialized
INFO - 2016-08-19 04:17:49 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:17:49 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:17:49 --> Utf8 Class Initialized
INFO - 2016-08-19 04:17:49 --> URI Class Initialized
DEBUG - 2016-08-19 04:17:49 --> No URI present. Default controller set.
INFO - 2016-08-19 04:17:49 --> Router Class Initialized
INFO - 2016-08-19 04:17:49 --> Output Class Initialized
INFO - 2016-08-19 04:17:49 --> Security Class Initialized
DEBUG - 2016-08-19 04:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:17:49 --> Input Class Initialized
INFO - 2016-08-19 04:17:49 --> Language Class Initialized
INFO - 2016-08-19 04:17:49 --> Loader Class Initialized
INFO - 2016-08-19 04:17:49 --> Helper loaded: url_helper
INFO - 2016-08-19 04:17:49 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:17:49 --> Helper loaded: html_helper
INFO - 2016-08-19 04:17:49 --> Helper loaded: form_helper
INFO - 2016-08-19 04:17:49 --> Helper loaded: file_helper
INFO - 2016-08-19 04:17:49 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:17:49 --> Database Driver Class Initialized
INFO - 2016-08-19 04:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:17:49 --> Form Validation Class Initialized
INFO - 2016-08-19 04:17:49 --> Email Class Initialized
INFO - 2016-08-19 04:17:49 --> Controller Class Initialized
INFO - 2016-08-19 04:17:49 --> Model Class Initialized
INFO - 2016-08-19 04:17:49 --> Model Class Initialized
INFO - 2016-08-19 04:17:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:17:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:17:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 04:17:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:17:49 --> Final output sent to browser
DEBUG - 2016-08-19 04:17:49 --> Total execution time: 0.3876
INFO - 2016-08-19 04:17:55 --> Config Class Initialized
INFO - 2016-08-19 04:17:55 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:17:55 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:17:55 --> Utf8 Class Initialized
INFO - 2016-08-19 04:17:55 --> URI Class Initialized
INFO - 2016-08-19 04:17:55 --> Router Class Initialized
INFO - 2016-08-19 04:17:55 --> Output Class Initialized
INFO - 2016-08-19 04:17:55 --> Security Class Initialized
DEBUG - 2016-08-19 04:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:17:55 --> Input Class Initialized
INFO - 2016-08-19 04:17:55 --> Language Class Initialized
INFO - 2016-08-19 04:17:55 --> Loader Class Initialized
INFO - 2016-08-19 04:17:55 --> Helper loaded: url_helper
INFO - 2016-08-19 04:17:55 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:17:55 --> Helper loaded: html_helper
INFO - 2016-08-19 04:17:55 --> Helper loaded: form_helper
INFO - 2016-08-19 04:17:55 --> Helper loaded: file_helper
INFO - 2016-08-19 04:17:55 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:17:55 --> Database Driver Class Initialized
INFO - 2016-08-19 04:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:17:55 --> Form Validation Class Initialized
INFO - 2016-08-19 04:17:56 --> Email Class Initialized
INFO - 2016-08-19 04:17:56 --> Controller Class Initialized
INFO - 2016-08-19 04:17:56 --> Model Class Initialized
INFO - 2016-08-19 04:17:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:17:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:17:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-19 04:17:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:17:56 --> Final output sent to browser
DEBUG - 2016-08-19 04:17:56 --> Total execution time: 0.3652
INFO - 2016-08-19 04:17:58 --> Config Class Initialized
INFO - 2016-08-19 04:17:58 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:17:58 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:17:58 --> Utf8 Class Initialized
INFO - 2016-08-19 04:17:58 --> URI Class Initialized
INFO - 2016-08-19 04:17:58 --> Router Class Initialized
INFO - 2016-08-19 04:17:58 --> Output Class Initialized
INFO - 2016-08-19 04:17:58 --> Security Class Initialized
DEBUG - 2016-08-19 04:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:17:58 --> Input Class Initialized
INFO - 2016-08-19 04:17:58 --> Language Class Initialized
INFO - 2016-08-19 04:17:58 --> Loader Class Initialized
INFO - 2016-08-19 04:17:58 --> Helper loaded: url_helper
INFO - 2016-08-19 04:17:58 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:17:58 --> Helper loaded: html_helper
INFO - 2016-08-19 04:17:58 --> Helper loaded: form_helper
INFO - 2016-08-19 04:17:58 --> Helper loaded: file_helper
INFO - 2016-08-19 04:17:58 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:17:58 --> Database Driver Class Initialized
INFO - 2016-08-19 04:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:17:58 --> Form Validation Class Initialized
INFO - 2016-08-19 04:17:58 --> Email Class Initialized
INFO - 2016-08-19 04:17:58 --> Controller Class Initialized
DEBUG - 2016-08-19 04:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:17:58 --> Model Class Initialized
INFO - 2016-08-19 04:17:58 --> Model Class Initialized
INFO - 2016-08-19 04:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:17:58 --> Model Class Initialized
INFO - 2016-08-19 04:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-19 04:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:17:58 --> Final output sent to browser
DEBUG - 2016-08-19 04:17:58 --> Total execution time: 0.4379
INFO - 2016-08-19 04:18:10 --> Config Class Initialized
INFO - 2016-08-19 04:18:10 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:18:10 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:18:10 --> Utf8 Class Initialized
INFO - 2016-08-19 04:18:10 --> URI Class Initialized
INFO - 2016-08-19 04:18:10 --> Router Class Initialized
INFO - 2016-08-19 04:18:10 --> Output Class Initialized
INFO - 2016-08-19 04:18:10 --> Security Class Initialized
DEBUG - 2016-08-19 04:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:18:10 --> Input Class Initialized
INFO - 2016-08-19 04:18:10 --> Language Class Initialized
INFO - 2016-08-19 04:18:10 --> Loader Class Initialized
INFO - 2016-08-19 04:18:11 --> Helper loaded: url_helper
INFO - 2016-08-19 04:18:11 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:18:11 --> Helper loaded: html_helper
INFO - 2016-08-19 04:18:11 --> Helper loaded: form_helper
INFO - 2016-08-19 04:18:11 --> Helper loaded: file_helper
INFO - 2016-08-19 04:18:11 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:18:11 --> Database Driver Class Initialized
INFO - 2016-08-19 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:18:11 --> Form Validation Class Initialized
INFO - 2016-08-19 04:18:11 --> Email Class Initialized
INFO - 2016-08-19 04:18:11 --> Controller Class Initialized
DEBUG - 2016-08-19 04:18:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 04:18:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:18:11 --> Model Class Initialized
INFO - 2016-08-19 04:18:11 --> Model Class Initialized
INFO - 2016-08-19 04:18:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:18:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:18:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 04:18:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:18:11 --> Final output sent to browser
DEBUG - 2016-08-19 04:18:11 --> Total execution time: 0.4519
INFO - 2016-08-19 04:18:15 --> Config Class Initialized
INFO - 2016-08-19 04:18:15 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:18:15 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:18:15 --> Utf8 Class Initialized
INFO - 2016-08-19 04:18:15 --> URI Class Initialized
INFO - 2016-08-19 04:18:15 --> Router Class Initialized
INFO - 2016-08-19 04:18:15 --> Output Class Initialized
INFO - 2016-08-19 04:18:15 --> Security Class Initialized
DEBUG - 2016-08-19 04:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:18:15 --> Input Class Initialized
INFO - 2016-08-19 04:18:15 --> Language Class Initialized
INFO - 2016-08-19 04:18:15 --> Loader Class Initialized
INFO - 2016-08-19 04:18:15 --> Helper loaded: url_helper
INFO - 2016-08-19 04:18:15 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:18:15 --> Helper loaded: html_helper
INFO - 2016-08-19 04:18:15 --> Helper loaded: form_helper
INFO - 2016-08-19 04:18:15 --> Helper loaded: file_helper
INFO - 2016-08-19 04:18:15 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:18:15 --> Database Driver Class Initialized
INFO - 2016-08-19 04:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:18:16 --> Form Validation Class Initialized
INFO - 2016-08-19 04:18:16 --> Email Class Initialized
INFO - 2016-08-19 04:18:16 --> Controller Class Initialized
INFO - 2016-08-19 04:18:16 --> Model Class Initialized
INFO - 2016-08-19 04:18:16 --> Model Class Initialized
INFO - 2016-08-19 04:18:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:18:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:18:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-19 04:18:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:18:16 --> Final output sent to browser
DEBUG - 2016-08-19 04:18:16 --> Total execution time: 0.4079
INFO - 2016-08-19 04:18:18 --> Config Class Initialized
INFO - 2016-08-19 04:18:18 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:18:18 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:18:18 --> Utf8 Class Initialized
INFO - 2016-08-19 04:18:18 --> URI Class Initialized
INFO - 2016-08-19 04:18:18 --> Router Class Initialized
INFO - 2016-08-19 04:18:18 --> Output Class Initialized
INFO - 2016-08-19 04:18:18 --> Security Class Initialized
DEBUG - 2016-08-19 04:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:18:18 --> Input Class Initialized
INFO - 2016-08-19 04:18:18 --> Language Class Initialized
INFO - 2016-08-19 04:18:18 --> Loader Class Initialized
INFO - 2016-08-19 04:18:18 --> Helper loaded: url_helper
INFO - 2016-08-19 04:18:18 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:18:18 --> Helper loaded: html_helper
INFO - 2016-08-19 04:18:18 --> Helper loaded: form_helper
INFO - 2016-08-19 04:18:18 --> Helper loaded: file_helper
INFO - 2016-08-19 04:18:18 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:18:18 --> Database Driver Class Initialized
INFO - 2016-08-19 04:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:18:18 --> Form Validation Class Initialized
INFO - 2016-08-19 04:18:18 --> Email Class Initialized
INFO - 2016-08-19 04:18:18 --> Controller Class Initialized
INFO - 2016-08-19 04:18:18 --> Model Class Initialized
INFO - 2016-08-19 04:18:18 --> Model Class Initialized
INFO - 2016-08-19 04:18:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:18:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:18:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-19 04:18:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:18:19 --> Final output sent to browser
DEBUG - 2016-08-19 04:18:19 --> Total execution time: 0.3874
INFO - 2016-08-19 04:18:22 --> Config Class Initialized
INFO - 2016-08-19 04:18:22 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:18:22 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:18:22 --> Utf8 Class Initialized
INFO - 2016-08-19 04:18:22 --> URI Class Initialized
INFO - 2016-08-19 04:18:22 --> Router Class Initialized
INFO - 2016-08-19 04:18:22 --> Output Class Initialized
INFO - 2016-08-19 04:18:22 --> Security Class Initialized
DEBUG - 2016-08-19 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:18:22 --> Input Class Initialized
INFO - 2016-08-19 04:18:23 --> Language Class Initialized
INFO - 2016-08-19 04:18:23 --> Loader Class Initialized
INFO - 2016-08-19 04:18:23 --> Helper loaded: url_helper
INFO - 2016-08-19 04:18:23 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:18:23 --> Helper loaded: html_helper
INFO - 2016-08-19 04:18:23 --> Helper loaded: form_helper
INFO - 2016-08-19 04:18:23 --> Helper loaded: file_helper
INFO - 2016-08-19 04:18:23 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:18:23 --> Database Driver Class Initialized
INFO - 2016-08-19 04:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:18:23 --> Form Validation Class Initialized
INFO - 2016-08-19 04:18:23 --> Email Class Initialized
INFO - 2016-08-19 04:18:23 --> Controller Class Initialized
INFO - 2016-08-19 04:18:23 --> Model Class Initialized
INFO - 2016-08-19 04:18:23 --> Model Class Initialized
INFO - 2016-08-19 04:18:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:18:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:18:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-19 04:18:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:18:23 --> Final output sent to browser
DEBUG - 2016-08-19 04:18:23 --> Total execution time: 0.4116
INFO - 2016-08-19 04:19:12 --> Config Class Initialized
INFO - 2016-08-19 04:19:12 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:19:12 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:19:12 --> Utf8 Class Initialized
INFO - 2016-08-19 04:19:12 --> URI Class Initialized
INFO - 2016-08-19 04:19:12 --> Router Class Initialized
INFO - 2016-08-19 04:19:12 --> Output Class Initialized
INFO - 2016-08-19 04:19:12 --> Security Class Initialized
DEBUG - 2016-08-19 04:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:19:12 --> Input Class Initialized
INFO - 2016-08-19 04:19:12 --> Language Class Initialized
INFO - 2016-08-19 04:19:12 --> Loader Class Initialized
INFO - 2016-08-19 04:19:12 --> Helper loaded: url_helper
INFO - 2016-08-19 04:19:12 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:19:12 --> Helper loaded: html_helper
INFO - 2016-08-19 04:19:12 --> Helper loaded: form_helper
INFO - 2016-08-19 04:19:12 --> Helper loaded: file_helper
INFO - 2016-08-19 04:19:12 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:19:12 --> Database Driver Class Initialized
INFO - 2016-08-19 04:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:19:12 --> Form Validation Class Initialized
INFO - 2016-08-19 04:19:12 --> Email Class Initialized
INFO - 2016-08-19 04:19:12 --> Controller Class Initialized
DEBUG - 2016-08-19 04:19:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-19 04:19:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:19:12 --> Model Class Initialized
INFO - 2016-08-19 04:19:12 --> Model Class Initialized
INFO - 2016-08-19 04:19:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:19:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:19:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-19 04:19:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:19:13 --> Final output sent to browser
DEBUG - 2016-08-19 04:19:13 --> Total execution time: 0.4832
INFO - 2016-08-19 04:28:28 --> Config Class Initialized
INFO - 2016-08-19 04:28:28 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:28:28 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:28:28 --> Utf8 Class Initialized
INFO - 2016-08-19 04:28:28 --> URI Class Initialized
DEBUG - 2016-08-19 04:28:28 --> No URI present. Default controller set.
INFO - 2016-08-19 04:28:28 --> Router Class Initialized
INFO - 2016-08-19 04:28:28 --> Output Class Initialized
INFO - 2016-08-19 04:28:28 --> Security Class Initialized
DEBUG - 2016-08-19 04:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:28:28 --> Input Class Initialized
INFO - 2016-08-19 04:28:28 --> Language Class Initialized
INFO - 2016-08-19 04:28:29 --> Loader Class Initialized
INFO - 2016-08-19 04:28:29 --> Helper loaded: url_helper
INFO - 2016-08-19 04:28:29 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:28:29 --> Helper loaded: html_helper
INFO - 2016-08-19 04:28:29 --> Helper loaded: form_helper
INFO - 2016-08-19 04:28:29 --> Helper loaded: file_helper
INFO - 2016-08-19 04:28:29 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:28:29 --> Database Driver Class Initialized
INFO - 2016-08-19 04:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:28:29 --> Form Validation Class Initialized
INFO - 2016-08-19 04:28:29 --> Email Class Initialized
INFO - 2016-08-19 04:28:29 --> Controller Class Initialized
INFO - 2016-08-19 04:28:29 --> Model Class Initialized
INFO - 2016-08-19 04:28:29 --> Model Class Initialized
INFO - 2016-08-19 04:28:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:28:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:28:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 04:28:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:28:29 --> Final output sent to browser
DEBUG - 2016-08-19 04:28:29 --> Total execution time: 0.4657
INFO - 2016-08-19 04:40:29 --> Config Class Initialized
INFO - 2016-08-19 04:40:29 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:40:29 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:40:29 --> Utf8 Class Initialized
INFO - 2016-08-19 04:40:29 --> URI Class Initialized
INFO - 2016-08-19 04:40:29 --> Router Class Initialized
INFO - 2016-08-19 04:40:29 --> Output Class Initialized
INFO - 2016-08-19 04:40:29 --> Security Class Initialized
DEBUG - 2016-08-19 04:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:40:29 --> Input Class Initialized
INFO - 2016-08-19 04:40:29 --> Language Class Initialized
INFO - 2016-08-19 04:40:29 --> Loader Class Initialized
INFO - 2016-08-19 04:40:29 --> Helper loaded: url_helper
INFO - 2016-08-19 04:40:29 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:40:29 --> Helper loaded: html_helper
INFO - 2016-08-19 04:40:29 --> Helper loaded: form_helper
INFO - 2016-08-19 04:40:29 --> Helper loaded: file_helper
INFO - 2016-08-19 04:40:29 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:40:29 --> Database Driver Class Initialized
INFO - 2016-08-19 04:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:40:29 --> Form Validation Class Initialized
INFO - 2016-08-19 04:40:29 --> Email Class Initialized
INFO - 2016-08-19 04:40:29 --> Controller Class Initialized
DEBUG - 2016-08-19 04:40:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:40:29 --> Model Class Initialized
INFO - 2016-08-19 04:40:29 --> Model Class Initialized
INFO - 2016-08-19 04:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:40:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:40:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:40:30 --> Final output sent to browser
DEBUG - 2016-08-19 04:40:30 --> Total execution time: 0.4111
INFO - 2016-08-19 04:40:41 --> Config Class Initialized
INFO - 2016-08-19 04:40:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:40:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:40:41 --> Utf8 Class Initialized
INFO - 2016-08-19 04:40:41 --> URI Class Initialized
INFO - 2016-08-19 04:40:41 --> Router Class Initialized
INFO - 2016-08-19 04:40:41 --> Output Class Initialized
INFO - 2016-08-19 04:40:41 --> Security Class Initialized
DEBUG - 2016-08-19 04:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:40:41 --> Input Class Initialized
INFO - 2016-08-19 04:40:41 --> Language Class Initialized
INFO - 2016-08-19 04:40:41 --> Loader Class Initialized
INFO - 2016-08-19 04:40:41 --> Helper loaded: url_helper
INFO - 2016-08-19 04:40:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:40:41 --> Helper loaded: html_helper
INFO - 2016-08-19 04:40:41 --> Helper loaded: form_helper
INFO - 2016-08-19 04:40:41 --> Helper loaded: file_helper
INFO - 2016-08-19 04:40:41 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:40:41 --> Database Driver Class Initialized
INFO - 2016-08-19 04:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:40:41 --> Form Validation Class Initialized
INFO - 2016-08-19 04:40:41 --> Email Class Initialized
INFO - 2016-08-19 04:40:41 --> Controller Class Initialized
DEBUG - 2016-08-19 04:40:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:40:41 --> Model Class Initialized
INFO - 2016-08-19 04:40:41 --> Model Class Initialized
INFO - 2016-08-19 04:40:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:40:42 --> Config Class Initialized
INFO - 2016-08-19 04:40:42 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:40:42 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:40:42 --> Utf8 Class Initialized
INFO - 2016-08-19 04:40:42 --> URI Class Initialized
INFO - 2016-08-19 04:40:42 --> Router Class Initialized
INFO - 2016-08-19 04:40:42 --> Output Class Initialized
INFO - 2016-08-19 04:40:42 --> Security Class Initialized
DEBUG - 2016-08-19 04:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:40:42 --> Input Class Initialized
INFO - 2016-08-19 04:40:42 --> Language Class Initialized
INFO - 2016-08-19 04:40:42 --> Loader Class Initialized
INFO - 2016-08-19 04:40:42 --> Helper loaded: url_helper
INFO - 2016-08-19 04:40:42 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:40:42 --> Helper loaded: html_helper
INFO - 2016-08-19 04:40:42 --> Helper loaded: form_helper
INFO - 2016-08-19 04:40:42 --> Helper loaded: file_helper
INFO - 2016-08-19 04:40:42 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:40:42 --> Database Driver Class Initialized
INFO - 2016-08-19 04:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:40:42 --> Form Validation Class Initialized
INFO - 2016-08-19 04:40:42 --> Email Class Initialized
INFO - 2016-08-19 04:40:42 --> Controller Class Initialized
DEBUG - 2016-08-19 04:40:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:40:42 --> Model Class Initialized
INFO - 2016-08-19 04:40:42 --> Model Class Initialized
INFO - 2016-08-19 04:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:40:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:40:42 --> Final output sent to browser
DEBUG - 2016-08-19 04:40:42 --> Total execution time: 0.4147
INFO - 2016-08-19 04:41:37 --> Config Class Initialized
INFO - 2016-08-19 04:41:37 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:41:37 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:41:37 --> Utf8 Class Initialized
INFO - 2016-08-19 04:41:37 --> URI Class Initialized
INFO - 2016-08-19 04:41:37 --> Router Class Initialized
INFO - 2016-08-19 04:41:37 --> Output Class Initialized
INFO - 2016-08-19 04:41:37 --> Security Class Initialized
DEBUG - 2016-08-19 04:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:41:37 --> Input Class Initialized
INFO - 2016-08-19 04:41:37 --> Language Class Initialized
INFO - 2016-08-19 04:41:37 --> Loader Class Initialized
INFO - 2016-08-19 04:41:37 --> Helper loaded: url_helper
INFO - 2016-08-19 04:41:37 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:41:37 --> Helper loaded: html_helper
INFO - 2016-08-19 04:41:37 --> Helper loaded: form_helper
INFO - 2016-08-19 04:41:37 --> Helper loaded: file_helper
INFO - 2016-08-19 04:41:37 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:41:37 --> Database Driver Class Initialized
INFO - 2016-08-19 04:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:41:37 --> Form Validation Class Initialized
INFO - 2016-08-19 04:41:37 --> Email Class Initialized
INFO - 2016-08-19 04:41:37 --> Controller Class Initialized
DEBUG - 2016-08-19 04:41:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:41:37 --> Model Class Initialized
INFO - 2016-08-19 04:41:37 --> Model Class Initialized
INFO - 2016-08-19 04:41:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:41:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:41:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:41:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:41:37 --> Final output sent to browser
DEBUG - 2016-08-19 04:41:37 --> Total execution time: 0.4080
INFO - 2016-08-19 04:41:42 --> Config Class Initialized
INFO - 2016-08-19 04:41:42 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:41:42 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:41:42 --> Utf8 Class Initialized
INFO - 2016-08-19 04:41:42 --> URI Class Initialized
INFO - 2016-08-19 04:41:42 --> Router Class Initialized
INFO - 2016-08-19 04:41:42 --> Output Class Initialized
INFO - 2016-08-19 04:41:42 --> Security Class Initialized
DEBUG - 2016-08-19 04:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:41:42 --> Input Class Initialized
INFO - 2016-08-19 04:41:42 --> Language Class Initialized
INFO - 2016-08-19 04:41:42 --> Loader Class Initialized
INFO - 2016-08-19 04:41:42 --> Helper loaded: url_helper
INFO - 2016-08-19 04:41:42 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:41:42 --> Helper loaded: html_helper
INFO - 2016-08-19 04:41:42 --> Helper loaded: form_helper
INFO - 2016-08-19 04:41:42 --> Helper loaded: file_helper
INFO - 2016-08-19 04:41:42 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:41:42 --> Database Driver Class Initialized
INFO - 2016-08-19 04:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:41:42 --> Form Validation Class Initialized
INFO - 2016-08-19 04:41:42 --> Email Class Initialized
INFO - 2016-08-19 04:41:42 --> Controller Class Initialized
INFO - 2016-08-19 04:41:42 --> Model Class Initialized
INFO - 2016-08-19 04:41:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:41:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:41:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-19 04:41:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:41:42 --> Final output sent to browser
DEBUG - 2016-08-19 04:41:42 --> Total execution time: 0.4220
INFO - 2016-08-19 04:41:51 --> Config Class Initialized
INFO - 2016-08-19 04:41:51 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:41:51 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:41:51 --> Utf8 Class Initialized
INFO - 2016-08-19 04:41:51 --> URI Class Initialized
INFO - 2016-08-19 04:41:51 --> Router Class Initialized
INFO - 2016-08-19 04:41:51 --> Output Class Initialized
INFO - 2016-08-19 04:41:51 --> Security Class Initialized
DEBUG - 2016-08-19 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:41:51 --> Input Class Initialized
INFO - 2016-08-19 04:41:51 --> Language Class Initialized
INFO - 2016-08-19 04:41:51 --> Loader Class Initialized
INFO - 2016-08-19 04:41:51 --> Helper loaded: url_helper
INFO - 2016-08-19 04:41:51 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:41:51 --> Helper loaded: html_helper
INFO - 2016-08-19 04:41:51 --> Helper loaded: form_helper
INFO - 2016-08-19 04:41:51 --> Helper loaded: file_helper
INFO - 2016-08-19 04:41:51 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:41:51 --> Database Driver Class Initialized
INFO - 2016-08-19 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:41:51 --> Form Validation Class Initialized
INFO - 2016-08-19 04:41:51 --> Email Class Initialized
INFO - 2016-08-19 04:41:51 --> Controller Class Initialized
INFO - 2016-08-19 04:41:51 --> Model Class Initialized
DEBUG - 2016-08-19 04:41:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:41:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:41:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:41:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-19 04:41:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:41:51 --> Final output sent to browser
DEBUG - 2016-08-19 04:41:51 --> Total execution time: 0.4126
INFO - 2016-08-19 04:41:57 --> Config Class Initialized
INFO - 2016-08-19 04:41:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:41:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:41:57 --> Utf8 Class Initialized
INFO - 2016-08-19 04:41:57 --> URI Class Initialized
INFO - 2016-08-19 04:41:57 --> Router Class Initialized
INFO - 2016-08-19 04:41:57 --> Output Class Initialized
INFO - 2016-08-19 04:41:57 --> Security Class Initialized
DEBUG - 2016-08-19 04:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:41:57 --> Input Class Initialized
INFO - 2016-08-19 04:41:57 --> Language Class Initialized
INFO - 2016-08-19 04:41:57 --> Loader Class Initialized
INFO - 2016-08-19 04:41:57 --> Helper loaded: url_helper
INFO - 2016-08-19 04:41:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:41:57 --> Helper loaded: html_helper
INFO - 2016-08-19 04:41:57 --> Helper loaded: form_helper
INFO - 2016-08-19 04:41:57 --> Helper loaded: file_helper
INFO - 2016-08-19 04:41:57 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:41:57 --> Database Driver Class Initialized
INFO - 2016-08-19 04:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:41:57 --> Form Validation Class Initialized
INFO - 2016-08-19 04:41:57 --> Email Class Initialized
INFO - 2016-08-19 04:41:57 --> Controller Class Initialized
INFO - 2016-08-19 04:41:57 --> Model Class Initialized
DEBUG - 2016-08-19 04:41:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:41:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 04:41:57 --> Config Class Initialized
INFO - 2016-08-19 04:41:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:41:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:41:57 --> Utf8 Class Initialized
INFO - 2016-08-19 04:41:57 --> URI Class Initialized
DEBUG - 2016-08-19 04:41:58 --> No URI present. Default controller set.
INFO - 2016-08-19 04:41:58 --> Router Class Initialized
INFO - 2016-08-19 04:41:58 --> Output Class Initialized
INFO - 2016-08-19 04:41:58 --> Security Class Initialized
DEBUG - 2016-08-19 04:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:41:58 --> Input Class Initialized
INFO - 2016-08-19 04:41:58 --> Language Class Initialized
INFO - 2016-08-19 04:41:58 --> Loader Class Initialized
INFO - 2016-08-19 04:41:58 --> Helper loaded: url_helper
INFO - 2016-08-19 04:41:58 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:41:58 --> Helper loaded: html_helper
INFO - 2016-08-19 04:41:58 --> Helper loaded: form_helper
INFO - 2016-08-19 04:41:58 --> Helper loaded: file_helper
INFO - 2016-08-19 04:41:58 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:41:58 --> Database Driver Class Initialized
INFO - 2016-08-19 04:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:41:58 --> Form Validation Class Initialized
INFO - 2016-08-19 04:41:58 --> Email Class Initialized
INFO - 2016-08-19 04:41:58 --> Controller Class Initialized
INFO - 2016-08-19 04:41:58 --> Model Class Initialized
INFO - 2016-08-19 04:41:58 --> Model Class Initialized
INFO - 2016-08-19 04:41:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:41:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:41:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-19 04:41:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:41:58 --> Final output sent to browser
DEBUG - 2016-08-19 04:41:58 --> Total execution time: 0.4082
INFO - 2016-08-19 04:42:03 --> Config Class Initialized
INFO - 2016-08-19 04:42:03 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:42:03 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:42:03 --> Utf8 Class Initialized
INFO - 2016-08-19 04:42:03 --> URI Class Initialized
INFO - 2016-08-19 04:42:04 --> Router Class Initialized
INFO - 2016-08-19 04:42:04 --> Output Class Initialized
INFO - 2016-08-19 04:42:04 --> Security Class Initialized
DEBUG - 2016-08-19 04:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:42:04 --> Input Class Initialized
INFO - 2016-08-19 04:42:04 --> Language Class Initialized
INFO - 2016-08-19 04:42:04 --> Loader Class Initialized
INFO - 2016-08-19 04:42:04 --> Helper loaded: url_helper
INFO - 2016-08-19 04:42:04 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:42:04 --> Helper loaded: html_helper
INFO - 2016-08-19 04:42:04 --> Helper loaded: form_helper
INFO - 2016-08-19 04:42:04 --> Helper loaded: file_helper
INFO - 2016-08-19 04:42:04 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:42:04 --> Database Driver Class Initialized
INFO - 2016-08-19 04:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:42:04 --> Form Validation Class Initialized
INFO - 2016-08-19 04:42:04 --> Email Class Initialized
INFO - 2016-08-19 04:42:04 --> Controller Class Initialized
DEBUG - 2016-08-19 04:42:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:42:04 --> Model Class Initialized
INFO - 2016-08-19 04:42:04 --> Model Class Initialized
INFO - 2016-08-19 04:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:42:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:42:04 --> Final output sent to browser
DEBUG - 2016-08-19 04:42:04 --> Total execution time: 0.4175
INFO - 2016-08-19 04:42:06 --> Config Class Initialized
INFO - 2016-08-19 04:42:06 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:42:06 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:42:06 --> Utf8 Class Initialized
INFO - 2016-08-19 04:42:06 --> URI Class Initialized
INFO - 2016-08-19 04:42:06 --> Router Class Initialized
INFO - 2016-08-19 04:42:06 --> Output Class Initialized
INFO - 2016-08-19 04:42:06 --> Security Class Initialized
DEBUG - 2016-08-19 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:42:06 --> Input Class Initialized
INFO - 2016-08-19 04:42:06 --> Language Class Initialized
INFO - 2016-08-19 04:42:06 --> Loader Class Initialized
INFO - 2016-08-19 04:42:06 --> Helper loaded: url_helper
INFO - 2016-08-19 04:42:06 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:42:06 --> Helper loaded: html_helper
INFO - 2016-08-19 04:42:06 --> Helper loaded: form_helper
INFO - 2016-08-19 04:42:06 --> Helper loaded: file_helper
INFO - 2016-08-19 04:42:06 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:42:06 --> Database Driver Class Initialized
INFO - 2016-08-19 04:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:42:06 --> Form Validation Class Initialized
INFO - 2016-08-19 04:42:06 --> Email Class Initialized
INFO - 2016-08-19 04:42:06 --> Controller Class Initialized
DEBUG - 2016-08-19 04:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:42:06 --> Model Class Initialized
INFO - 2016-08-19 04:42:06 --> Model Class Initialized
INFO - 2016-08-19 04:42:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:42:07 --> Config Class Initialized
INFO - 2016-08-19 04:42:07 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:42:07 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:42:07 --> Utf8 Class Initialized
INFO - 2016-08-19 04:42:07 --> URI Class Initialized
INFO - 2016-08-19 04:42:07 --> Router Class Initialized
INFO - 2016-08-19 04:42:07 --> Output Class Initialized
INFO - 2016-08-19 04:42:07 --> Security Class Initialized
DEBUG - 2016-08-19 04:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:42:07 --> Input Class Initialized
INFO - 2016-08-19 04:42:07 --> Language Class Initialized
INFO - 2016-08-19 04:42:07 --> Loader Class Initialized
INFO - 2016-08-19 04:42:07 --> Helper loaded: url_helper
INFO - 2016-08-19 04:42:07 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:42:07 --> Helper loaded: html_helper
INFO - 2016-08-19 04:42:07 --> Helper loaded: form_helper
INFO - 2016-08-19 04:42:07 --> Helper loaded: file_helper
INFO - 2016-08-19 04:42:07 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:42:07 --> Database Driver Class Initialized
INFO - 2016-08-19 04:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:42:07 --> Form Validation Class Initialized
INFO - 2016-08-19 04:42:07 --> Email Class Initialized
INFO - 2016-08-19 04:42:07 --> Controller Class Initialized
DEBUG - 2016-08-19 04:42:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:42:07 --> Model Class Initialized
INFO - 2016-08-19 04:42:07 --> Model Class Initialized
INFO - 2016-08-19 04:42:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:42:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:42:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:42:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:42:07 --> Final output sent to browser
DEBUG - 2016-08-19 04:42:07 --> Total execution time: 0.4212
INFO - 2016-08-19 04:42:57 --> Config Class Initialized
INFO - 2016-08-19 04:42:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:42:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:42:57 --> Utf8 Class Initialized
INFO - 2016-08-19 04:42:57 --> URI Class Initialized
INFO - 2016-08-19 04:42:57 --> Router Class Initialized
INFO - 2016-08-19 04:42:57 --> Output Class Initialized
INFO - 2016-08-19 04:42:57 --> Security Class Initialized
DEBUG - 2016-08-19 04:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:42:57 --> Input Class Initialized
INFO - 2016-08-19 04:42:57 --> Language Class Initialized
INFO - 2016-08-19 04:42:57 --> Loader Class Initialized
INFO - 2016-08-19 04:42:57 --> Helper loaded: url_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: html_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: form_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: file_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:42:57 --> Database Driver Class Initialized
INFO - 2016-08-19 04:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:42:57 --> Form Validation Class Initialized
INFO - 2016-08-19 04:42:57 --> Email Class Initialized
INFO - 2016-08-19 04:42:57 --> Controller Class Initialized
DEBUG - 2016-08-19 04:42:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:42:57 --> Model Class Initialized
INFO - 2016-08-19 04:42:57 --> Model Class Initialized
INFO - 2016-08-19 04:42:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:42:57 --> Config Class Initialized
INFO - 2016-08-19 04:42:57 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:42:57 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:42:57 --> Utf8 Class Initialized
INFO - 2016-08-19 04:42:57 --> URI Class Initialized
INFO - 2016-08-19 04:42:57 --> Router Class Initialized
INFO - 2016-08-19 04:42:57 --> Output Class Initialized
INFO - 2016-08-19 04:42:57 --> Security Class Initialized
DEBUG - 2016-08-19 04:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:42:57 --> Input Class Initialized
INFO - 2016-08-19 04:42:57 --> Language Class Initialized
INFO - 2016-08-19 04:42:57 --> Loader Class Initialized
INFO - 2016-08-19 04:42:57 --> Helper loaded: url_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: html_helper
INFO - 2016-08-19 04:42:57 --> Helper loaded: form_helper
INFO - 2016-08-19 04:42:58 --> Helper loaded: file_helper
INFO - 2016-08-19 04:42:58 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:42:58 --> Database Driver Class Initialized
INFO - 2016-08-19 04:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:42:58 --> Form Validation Class Initialized
INFO - 2016-08-19 04:42:58 --> Email Class Initialized
INFO - 2016-08-19 04:42:58 --> Controller Class Initialized
DEBUG - 2016-08-19 04:42:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:42:58 --> Model Class Initialized
INFO - 2016-08-19 04:42:58 --> Model Class Initialized
INFO - 2016-08-19 04:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:42:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:42:58 --> Final output sent to browser
DEBUG - 2016-08-19 04:42:58 --> Total execution time: 0.4659
INFO - 2016-08-19 04:43:01 --> Config Class Initialized
INFO - 2016-08-19 04:43:01 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:43:01 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:43:01 --> Utf8 Class Initialized
INFO - 2016-08-19 04:43:01 --> URI Class Initialized
INFO - 2016-08-19 04:43:01 --> Router Class Initialized
INFO - 2016-08-19 04:43:01 --> Output Class Initialized
INFO - 2016-08-19 04:43:01 --> Security Class Initialized
DEBUG - 2016-08-19 04:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:43:01 --> Input Class Initialized
INFO - 2016-08-19 04:43:01 --> Language Class Initialized
INFO - 2016-08-19 04:43:01 --> Loader Class Initialized
INFO - 2016-08-19 04:43:01 --> Helper loaded: url_helper
INFO - 2016-08-19 04:43:01 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:43:01 --> Helper loaded: html_helper
INFO - 2016-08-19 04:43:01 --> Helper loaded: form_helper
INFO - 2016-08-19 04:43:01 --> Helper loaded: file_helper
INFO - 2016-08-19 04:43:01 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:43:01 --> Database Driver Class Initialized
INFO - 2016-08-19 04:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:43:01 --> Form Validation Class Initialized
INFO - 2016-08-19 04:43:01 --> Email Class Initialized
INFO - 2016-08-19 04:43:01 --> Controller Class Initialized
DEBUG - 2016-08-19 04:43:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:43:01 --> Model Class Initialized
INFO - 2016-08-19 04:43:02 --> Model Class Initialized
INFO - 2016-08-19 04:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:43:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:43:02 --> Final output sent to browser
DEBUG - 2016-08-19 04:43:02 --> Total execution time: 0.4361
INFO - 2016-08-19 04:44:02 --> Config Class Initialized
INFO - 2016-08-19 04:44:02 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:44:02 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:44:02 --> Utf8 Class Initialized
INFO - 2016-08-19 04:44:02 --> URI Class Initialized
INFO - 2016-08-19 04:44:02 --> Router Class Initialized
INFO - 2016-08-19 04:44:02 --> Output Class Initialized
INFO - 2016-08-19 04:44:02 --> Security Class Initialized
DEBUG - 2016-08-19 04:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:44:03 --> Input Class Initialized
INFO - 2016-08-19 04:44:03 --> Language Class Initialized
INFO - 2016-08-19 04:44:03 --> Loader Class Initialized
INFO - 2016-08-19 04:44:03 --> Helper loaded: url_helper
INFO - 2016-08-19 04:44:03 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:44:03 --> Helper loaded: html_helper
INFO - 2016-08-19 04:44:03 --> Helper loaded: form_helper
INFO - 2016-08-19 04:44:03 --> Helper loaded: file_helper
INFO - 2016-08-19 04:44:03 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:44:03 --> Database Driver Class Initialized
INFO - 2016-08-19 04:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:44:03 --> Form Validation Class Initialized
INFO - 2016-08-19 04:44:03 --> Email Class Initialized
INFO - 2016-08-19 04:44:03 --> Controller Class Initialized
INFO - 2016-08-19 04:44:03 --> Model Class Initialized
INFO - 2016-08-19 04:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-19 04:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:44:03 --> Final output sent to browser
DEBUG - 2016-08-19 04:44:03 --> Total execution time: 0.3987
INFO - 2016-08-19 04:49:21 --> Config Class Initialized
INFO - 2016-08-19 04:49:21 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:49:21 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:49:21 --> Utf8 Class Initialized
INFO - 2016-08-19 04:49:21 --> URI Class Initialized
INFO - 2016-08-19 04:49:21 --> Router Class Initialized
INFO - 2016-08-19 04:49:21 --> Output Class Initialized
INFO - 2016-08-19 04:49:21 --> Security Class Initialized
DEBUG - 2016-08-19 04:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:49:21 --> Input Class Initialized
INFO - 2016-08-19 04:49:21 --> Language Class Initialized
INFO - 2016-08-19 04:49:21 --> Loader Class Initialized
INFO - 2016-08-19 04:49:21 --> Helper loaded: url_helper
INFO - 2016-08-19 04:49:21 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:49:21 --> Helper loaded: html_helper
INFO - 2016-08-19 04:49:21 --> Helper loaded: form_helper
INFO - 2016-08-19 04:49:21 --> Helper loaded: file_helper
INFO - 2016-08-19 04:49:21 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:49:21 --> Database Driver Class Initialized
INFO - 2016-08-19 04:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:49:21 --> Form Validation Class Initialized
INFO - 2016-08-19 04:49:21 --> Email Class Initialized
INFO - 2016-08-19 04:49:21 --> Controller Class Initialized
DEBUG - 2016-08-19 04:49:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:49:21 --> Model Class Initialized
INFO - 2016-08-19 04:49:21 --> Model Class Initialized
INFO - 2016-08-19 04:49:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:49:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:49:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:49:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:49:21 --> Final output sent to browser
DEBUG - 2016-08-19 04:49:21 --> Total execution time: 0.5633
INFO - 2016-08-19 04:49:23 --> Config Class Initialized
INFO - 2016-08-19 04:49:23 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:49:23 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:49:23 --> Utf8 Class Initialized
INFO - 2016-08-19 04:49:23 --> URI Class Initialized
INFO - 2016-08-19 04:49:23 --> Router Class Initialized
INFO - 2016-08-19 04:49:23 --> Output Class Initialized
INFO - 2016-08-19 04:49:23 --> Security Class Initialized
DEBUG - 2016-08-19 04:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:49:23 --> Input Class Initialized
INFO - 2016-08-19 04:49:23 --> Language Class Initialized
INFO - 2016-08-19 04:49:23 --> Loader Class Initialized
INFO - 2016-08-19 04:49:23 --> Helper loaded: url_helper
INFO - 2016-08-19 04:49:23 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:49:23 --> Helper loaded: html_helper
INFO - 2016-08-19 04:49:23 --> Helper loaded: form_helper
INFO - 2016-08-19 04:49:23 --> Helper loaded: file_helper
INFO - 2016-08-19 04:49:23 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:49:23 --> Database Driver Class Initialized
INFO - 2016-08-19 04:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:49:23 --> Form Validation Class Initialized
INFO - 2016-08-19 04:49:23 --> Email Class Initialized
INFO - 2016-08-19 04:49:23 --> Controller Class Initialized
DEBUG - 2016-08-19 04:49:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:49:23 --> Model Class Initialized
INFO - 2016-08-19 04:49:23 --> Model Class Initialized
INFO - 2016-08-19 04:49:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:49:24 --> Config Class Initialized
INFO - 2016-08-19 04:49:24 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:49:24 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:49:24 --> Utf8 Class Initialized
INFO - 2016-08-19 04:49:24 --> URI Class Initialized
INFO - 2016-08-19 04:49:24 --> Router Class Initialized
INFO - 2016-08-19 04:49:24 --> Output Class Initialized
INFO - 2016-08-19 04:49:24 --> Security Class Initialized
DEBUG - 2016-08-19 04:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:49:24 --> Input Class Initialized
INFO - 2016-08-19 04:49:24 --> Language Class Initialized
INFO - 2016-08-19 04:49:24 --> Loader Class Initialized
INFO - 2016-08-19 04:49:24 --> Helper loaded: url_helper
INFO - 2016-08-19 04:49:24 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:49:24 --> Helper loaded: html_helper
INFO - 2016-08-19 04:49:24 --> Helper loaded: form_helper
INFO - 2016-08-19 04:49:24 --> Helper loaded: file_helper
INFO - 2016-08-19 04:49:24 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:49:24 --> Database Driver Class Initialized
INFO - 2016-08-19 04:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:49:24 --> Form Validation Class Initialized
INFO - 2016-08-19 04:49:24 --> Email Class Initialized
INFO - 2016-08-19 04:49:24 --> Controller Class Initialized
DEBUG - 2016-08-19 04:49:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:49:24 --> Model Class Initialized
INFO - 2016-08-19 04:49:24 --> Model Class Initialized
INFO - 2016-08-19 04:49:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:49:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:49:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:49:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:49:24 --> Final output sent to browser
DEBUG - 2016-08-19 04:49:24 --> Total execution time: 0.4915
INFO - 2016-08-19 04:49:28 --> Config Class Initialized
INFO - 2016-08-19 04:49:28 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:49:28 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:49:28 --> Utf8 Class Initialized
INFO - 2016-08-19 04:49:28 --> URI Class Initialized
INFO - 2016-08-19 04:49:28 --> Router Class Initialized
INFO - 2016-08-19 04:49:28 --> Output Class Initialized
INFO - 2016-08-19 04:49:28 --> Security Class Initialized
DEBUG - 2016-08-19 04:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:49:28 --> Input Class Initialized
INFO - 2016-08-19 04:49:28 --> Language Class Initialized
INFO - 2016-08-19 04:49:28 --> Loader Class Initialized
INFO - 2016-08-19 04:49:28 --> Helper loaded: url_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: html_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: form_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: file_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:49:28 --> Database Driver Class Initialized
INFO - 2016-08-19 04:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:49:28 --> Form Validation Class Initialized
INFO - 2016-08-19 04:49:28 --> Email Class Initialized
INFO - 2016-08-19 04:49:28 --> Controller Class Initialized
DEBUG - 2016-08-19 04:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:49:28 --> Model Class Initialized
INFO - 2016-08-19 04:49:28 --> Model Class Initialized
INFO - 2016-08-19 04:49:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:49:28 --> Config Class Initialized
INFO - 2016-08-19 04:49:28 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:49:28 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:49:28 --> Utf8 Class Initialized
INFO - 2016-08-19 04:49:28 --> URI Class Initialized
INFO - 2016-08-19 04:49:28 --> Router Class Initialized
INFO - 2016-08-19 04:49:28 --> Output Class Initialized
INFO - 2016-08-19 04:49:28 --> Security Class Initialized
DEBUG - 2016-08-19 04:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:49:28 --> Input Class Initialized
INFO - 2016-08-19 04:49:28 --> Language Class Initialized
INFO - 2016-08-19 04:49:28 --> Loader Class Initialized
INFO - 2016-08-19 04:49:28 --> Helper loaded: url_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: html_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: form_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: file_helper
INFO - 2016-08-19 04:49:28 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:49:28 --> Database Driver Class Initialized
INFO - 2016-08-19 04:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:49:28 --> Form Validation Class Initialized
INFO - 2016-08-19 04:49:28 --> Email Class Initialized
INFO - 2016-08-19 04:49:28 --> Controller Class Initialized
DEBUG - 2016-08-19 04:49:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:49:28 --> Model Class Initialized
INFO - 2016-08-19 04:49:28 --> Model Class Initialized
INFO - 2016-08-19 04:49:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:49:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:49:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:49:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:49:28 --> Final output sent to browser
DEBUG - 2016-08-19 04:49:28 --> Total execution time: 0.4358
INFO - 2016-08-19 04:51:43 --> Config Class Initialized
INFO - 2016-08-19 04:51:43 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:51:43 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:51:43 --> Utf8 Class Initialized
INFO - 2016-08-19 04:51:43 --> URI Class Initialized
INFO - 2016-08-19 04:51:43 --> Router Class Initialized
INFO - 2016-08-19 04:51:43 --> Output Class Initialized
INFO - 2016-08-19 04:51:43 --> Security Class Initialized
DEBUG - 2016-08-19 04:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:51:43 --> Input Class Initialized
INFO - 2016-08-19 04:51:43 --> Language Class Initialized
INFO - 2016-08-19 04:51:44 --> Loader Class Initialized
INFO - 2016-08-19 04:51:44 --> Helper loaded: url_helper
INFO - 2016-08-19 04:51:44 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:51:44 --> Helper loaded: html_helper
INFO - 2016-08-19 04:51:44 --> Helper loaded: form_helper
INFO - 2016-08-19 04:51:44 --> Helper loaded: file_helper
INFO - 2016-08-19 04:51:44 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:51:44 --> Database Driver Class Initialized
INFO - 2016-08-19 04:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:51:44 --> Form Validation Class Initialized
INFO - 2016-08-19 04:51:44 --> Email Class Initialized
INFO - 2016-08-19 04:51:44 --> Controller Class Initialized
DEBUG - 2016-08-19 04:51:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:51:44 --> Model Class Initialized
INFO - 2016-08-19 04:51:44 --> Model Class Initialized
INFO - 2016-08-19 04:51:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:51:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:51:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:51:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:51:44 --> Final output sent to browser
DEBUG - 2016-08-19 04:51:44 --> Total execution time: 0.4886
INFO - 2016-08-19 04:51:48 --> Config Class Initialized
INFO - 2016-08-19 04:51:48 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:51:48 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:51:48 --> Utf8 Class Initialized
INFO - 2016-08-19 04:51:48 --> URI Class Initialized
INFO - 2016-08-19 04:51:48 --> Router Class Initialized
INFO - 2016-08-19 04:51:48 --> Output Class Initialized
INFO - 2016-08-19 04:51:48 --> Security Class Initialized
DEBUG - 2016-08-19 04:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:51:48 --> Input Class Initialized
INFO - 2016-08-19 04:51:48 --> Language Class Initialized
INFO - 2016-08-19 04:51:48 --> Loader Class Initialized
INFO - 2016-08-19 04:51:48 --> Helper loaded: url_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: html_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: form_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: file_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:51:48 --> Database Driver Class Initialized
INFO - 2016-08-19 04:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:51:48 --> Form Validation Class Initialized
INFO - 2016-08-19 04:51:48 --> Email Class Initialized
INFO - 2016-08-19 04:51:48 --> Controller Class Initialized
DEBUG - 2016-08-19 04:51:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:51:48 --> Model Class Initialized
INFO - 2016-08-19 04:51:48 --> Model Class Initialized
INFO - 2016-08-19 04:51:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:51:48 --> Config Class Initialized
INFO - 2016-08-19 04:51:48 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:51:48 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:51:48 --> Utf8 Class Initialized
INFO - 2016-08-19 04:51:48 --> URI Class Initialized
INFO - 2016-08-19 04:51:48 --> Router Class Initialized
INFO - 2016-08-19 04:51:48 --> Output Class Initialized
INFO - 2016-08-19 04:51:48 --> Security Class Initialized
DEBUG - 2016-08-19 04:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:51:48 --> Input Class Initialized
INFO - 2016-08-19 04:51:48 --> Language Class Initialized
INFO - 2016-08-19 04:51:48 --> Loader Class Initialized
INFO - 2016-08-19 04:51:48 --> Helper loaded: url_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: html_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: form_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: file_helper
INFO - 2016-08-19 04:51:48 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:51:48 --> Database Driver Class Initialized
INFO - 2016-08-19 04:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:51:48 --> Form Validation Class Initialized
INFO - 2016-08-19 04:51:48 --> Email Class Initialized
INFO - 2016-08-19 04:51:48 --> Controller Class Initialized
DEBUG - 2016-08-19 04:51:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:51:48 --> Model Class Initialized
INFO - 2016-08-19 04:51:48 --> Model Class Initialized
INFO - 2016-08-19 04:51:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:51:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:51:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:51:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:51:49 --> Final output sent to browser
DEBUG - 2016-08-19 04:51:49 --> Total execution time: 0.4348
INFO - 2016-08-19 04:58:41 --> Config Class Initialized
INFO - 2016-08-19 04:58:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:58:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:58:41 --> Utf8 Class Initialized
INFO - 2016-08-19 04:58:41 --> URI Class Initialized
INFO - 2016-08-19 04:58:41 --> Router Class Initialized
INFO - 2016-08-19 04:58:41 --> Output Class Initialized
INFO - 2016-08-19 04:58:41 --> Security Class Initialized
DEBUG - 2016-08-19 04:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:58:41 --> Input Class Initialized
INFO - 2016-08-19 04:58:41 --> Language Class Initialized
INFO - 2016-08-19 04:58:41 --> Loader Class Initialized
INFO - 2016-08-19 04:58:41 --> Helper loaded: url_helper
INFO - 2016-08-19 04:58:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:58:41 --> Helper loaded: html_helper
INFO - 2016-08-19 04:58:41 --> Helper loaded: form_helper
INFO - 2016-08-19 04:58:41 --> Helper loaded: file_helper
INFO - 2016-08-19 04:58:41 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:58:41 --> Database Driver Class Initialized
INFO - 2016-08-19 04:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:58:41 --> Form Validation Class Initialized
INFO - 2016-08-19 04:58:41 --> Email Class Initialized
INFO - 2016-08-19 04:58:41 --> Controller Class Initialized
DEBUG - 2016-08-19 04:58:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:58:41 --> Model Class Initialized
INFO - 2016-08-19 04:58:41 --> Model Class Initialized
INFO - 2016-08-19 04:58:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:58:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:58:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:58:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:58:41 --> Final output sent to browser
DEBUG - 2016-08-19 04:58:42 --> Total execution time: 0.5443
INFO - 2016-08-19 04:58:44 --> Config Class Initialized
INFO - 2016-08-19 04:58:44 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:58:44 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:58:44 --> Utf8 Class Initialized
INFO - 2016-08-19 04:58:44 --> URI Class Initialized
INFO - 2016-08-19 04:58:44 --> Router Class Initialized
INFO - 2016-08-19 04:58:44 --> Output Class Initialized
INFO - 2016-08-19 04:58:44 --> Security Class Initialized
DEBUG - 2016-08-19 04:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:58:44 --> Input Class Initialized
INFO - 2016-08-19 04:58:44 --> Language Class Initialized
INFO - 2016-08-19 04:58:44 --> Loader Class Initialized
INFO - 2016-08-19 04:58:44 --> Helper loaded: url_helper
INFO - 2016-08-19 04:58:44 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:58:44 --> Helper loaded: html_helper
INFO - 2016-08-19 04:58:44 --> Helper loaded: form_helper
INFO - 2016-08-19 04:58:44 --> Helper loaded: file_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:58:45 --> Database Driver Class Initialized
INFO - 2016-08-19 04:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:58:45 --> Form Validation Class Initialized
INFO - 2016-08-19 04:58:45 --> Email Class Initialized
INFO - 2016-08-19 04:58:45 --> Controller Class Initialized
DEBUG - 2016-08-19 04:58:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:58:45 --> Model Class Initialized
INFO - 2016-08-19 04:58:45 --> Model Class Initialized
INFO - 2016-08-19 04:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:58:45 --> Config Class Initialized
INFO - 2016-08-19 04:58:45 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:58:45 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:58:45 --> Utf8 Class Initialized
INFO - 2016-08-19 04:58:45 --> URI Class Initialized
INFO - 2016-08-19 04:58:45 --> Router Class Initialized
INFO - 2016-08-19 04:58:45 --> Output Class Initialized
INFO - 2016-08-19 04:58:45 --> Security Class Initialized
DEBUG - 2016-08-19 04:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:58:45 --> Input Class Initialized
INFO - 2016-08-19 04:58:45 --> Language Class Initialized
INFO - 2016-08-19 04:58:45 --> Loader Class Initialized
INFO - 2016-08-19 04:58:45 --> Helper loaded: url_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: html_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: form_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: file_helper
INFO - 2016-08-19 04:58:45 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:58:45 --> Database Driver Class Initialized
INFO - 2016-08-19 04:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:58:45 --> Form Validation Class Initialized
INFO - 2016-08-19 04:58:45 --> Email Class Initialized
INFO - 2016-08-19 04:58:45 --> Controller Class Initialized
DEBUG - 2016-08-19 04:58:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:58:45 --> Model Class Initialized
INFO - 2016-08-19 04:58:45 --> Model Class Initialized
INFO - 2016-08-19 04:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:58:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:58:45 --> Final output sent to browser
DEBUG - 2016-08-19 04:58:45 --> Total execution time: 0.4554
INFO - 2016-08-19 04:59:18 --> Config Class Initialized
INFO - 2016-08-19 04:59:18 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:59:18 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:59:18 --> Utf8 Class Initialized
INFO - 2016-08-19 04:59:18 --> URI Class Initialized
INFO - 2016-08-19 04:59:18 --> Router Class Initialized
INFO - 2016-08-19 04:59:18 --> Output Class Initialized
INFO - 2016-08-19 04:59:18 --> Security Class Initialized
DEBUG - 2016-08-19 04:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:59:19 --> Input Class Initialized
INFO - 2016-08-19 04:59:19 --> Language Class Initialized
INFO - 2016-08-19 04:59:19 --> Loader Class Initialized
INFO - 2016-08-19 04:59:19 --> Helper loaded: url_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: html_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: form_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: file_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:59:19 --> Database Driver Class Initialized
INFO - 2016-08-19 04:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:59:19 --> Form Validation Class Initialized
INFO - 2016-08-19 04:59:19 --> Email Class Initialized
INFO - 2016-08-19 04:59:19 --> Controller Class Initialized
DEBUG - 2016-08-19 04:59:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:59:19 --> Model Class Initialized
INFO - 2016-08-19 04:59:19 --> Model Class Initialized
INFO - 2016-08-19 04:59:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\emails/mailformat.php
INFO - 2016-08-19 04:59:19 --> Config Class Initialized
INFO - 2016-08-19 04:59:19 --> Hooks Class Initialized
DEBUG - 2016-08-19 04:59:19 --> UTF-8 Support Enabled
INFO - 2016-08-19 04:59:19 --> Utf8 Class Initialized
INFO - 2016-08-19 04:59:19 --> URI Class Initialized
INFO - 2016-08-19 04:59:19 --> Router Class Initialized
INFO - 2016-08-19 04:59:19 --> Output Class Initialized
INFO - 2016-08-19 04:59:19 --> Security Class Initialized
DEBUG - 2016-08-19 04:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 04:59:19 --> Input Class Initialized
INFO - 2016-08-19 04:59:19 --> Language Class Initialized
INFO - 2016-08-19 04:59:19 --> Loader Class Initialized
INFO - 2016-08-19 04:59:19 --> Helper loaded: url_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: utils_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: html_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: form_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: file_helper
INFO - 2016-08-19 04:59:19 --> Helper loaded: myemail_helper
INFO - 2016-08-19 04:59:19 --> Database Driver Class Initialized
INFO - 2016-08-19 04:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 04:59:19 --> Form Validation Class Initialized
INFO - 2016-08-19 04:59:19 --> Email Class Initialized
INFO - 2016-08-19 04:59:19 --> Controller Class Initialized
DEBUG - 2016-08-19 04:59:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 04:59:19 --> Model Class Initialized
INFO - 2016-08-19 04:59:19 --> Model Class Initialized
INFO - 2016-08-19 04:59:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 04:59:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 04:59:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 04:59:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 04:59:19 --> Final output sent to browser
DEBUG - 2016-08-19 04:59:19 --> Total execution time: 0.4354
INFO - 2016-08-19 08:18:41 --> Config Class Initialized
INFO - 2016-08-19 08:18:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:18:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:18:41 --> Utf8 Class Initialized
INFO - 2016-08-19 08:18:41 --> URI Class Initialized
INFO - 2016-08-19 08:18:41 --> Router Class Initialized
INFO - 2016-08-19 08:18:41 --> Output Class Initialized
INFO - 2016-08-19 08:18:41 --> Security Class Initialized
DEBUG - 2016-08-19 08:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:18:41 --> Input Class Initialized
INFO - 2016-08-19 08:18:41 --> Language Class Initialized
INFO - 2016-08-19 08:18:41 --> Loader Class Initialized
INFO - 2016-08-19 08:18:41 --> Helper loaded: url_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: html_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: form_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: file_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:18:41 --> Database Driver Class Initialized
INFO - 2016-08-19 08:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:18:41 --> Form Validation Class Initialized
INFO - 2016-08-19 08:18:41 --> Email Class Initialized
INFO - 2016-08-19 08:18:41 --> Controller Class Initialized
INFO - 2016-08-19 08:18:41 --> Config Class Initialized
INFO - 2016-08-19 08:18:41 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:18:41 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:18:41 --> Utf8 Class Initialized
INFO - 2016-08-19 08:18:41 --> URI Class Initialized
INFO - 2016-08-19 08:18:41 --> Router Class Initialized
INFO - 2016-08-19 08:18:41 --> Output Class Initialized
INFO - 2016-08-19 08:18:41 --> Security Class Initialized
DEBUG - 2016-08-19 08:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:18:41 --> Input Class Initialized
INFO - 2016-08-19 08:18:41 --> Language Class Initialized
INFO - 2016-08-19 08:18:41 --> Loader Class Initialized
INFO - 2016-08-19 08:18:41 --> Helper loaded: url_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:18:41 --> Helper loaded: html_helper
INFO - 2016-08-19 08:18:42 --> Helper loaded: form_helper
INFO - 2016-08-19 08:18:42 --> Helper loaded: file_helper
INFO - 2016-08-19 08:18:42 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:18:42 --> Database Driver Class Initialized
INFO - 2016-08-19 08:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:18:42 --> Form Validation Class Initialized
INFO - 2016-08-19 08:18:42 --> Email Class Initialized
INFO - 2016-08-19 08:18:42 --> Controller Class Initialized
INFO - 2016-08-19 08:18:42 --> Model Class Initialized
DEBUG - 2016-08-19 08:18:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 08:18:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 08:18:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 08:18:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 08:18:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 08:18:42 --> Final output sent to browser
DEBUG - 2016-08-19 08:18:42 --> Total execution time: 0.4419
INFO - 2016-08-19 08:18:45 --> Config Class Initialized
INFO - 2016-08-19 08:18:45 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:18:45 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:18:46 --> Utf8 Class Initialized
INFO - 2016-08-19 08:18:46 --> URI Class Initialized
INFO - 2016-08-19 08:18:46 --> Router Class Initialized
INFO - 2016-08-19 08:18:46 --> Output Class Initialized
INFO - 2016-08-19 08:18:46 --> Security Class Initialized
DEBUG - 2016-08-19 08:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:18:46 --> Input Class Initialized
INFO - 2016-08-19 08:18:46 --> Language Class Initialized
INFO - 2016-08-19 08:18:46 --> Loader Class Initialized
INFO - 2016-08-19 08:18:46 --> Helper loaded: url_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: html_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: form_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: file_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:18:46 --> Database Driver Class Initialized
INFO - 2016-08-19 08:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:18:46 --> Form Validation Class Initialized
INFO - 2016-08-19 08:18:46 --> Email Class Initialized
INFO - 2016-08-19 08:18:46 --> Controller Class Initialized
INFO - 2016-08-19 08:18:46 --> Model Class Initialized
DEBUG - 2016-08-19 08:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 08:18:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-19 08:18:46 --> Config Class Initialized
INFO - 2016-08-19 08:18:46 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:18:46 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:18:46 --> Utf8 Class Initialized
INFO - 2016-08-19 08:18:46 --> URI Class Initialized
INFO - 2016-08-19 08:18:46 --> Router Class Initialized
INFO - 2016-08-19 08:18:46 --> Output Class Initialized
INFO - 2016-08-19 08:18:46 --> Security Class Initialized
DEBUG - 2016-08-19 08:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:18:46 --> Input Class Initialized
INFO - 2016-08-19 08:18:46 --> Language Class Initialized
INFO - 2016-08-19 08:18:46 --> Loader Class Initialized
INFO - 2016-08-19 08:18:46 --> Helper loaded: url_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: html_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: form_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: file_helper
INFO - 2016-08-19 08:18:46 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:18:46 --> Database Driver Class Initialized
INFO - 2016-08-19 08:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:18:46 --> Form Validation Class Initialized
INFO - 2016-08-19 08:18:46 --> Email Class Initialized
INFO - 2016-08-19 08:18:46 --> Controller Class Initialized
DEBUG - 2016-08-19 08:18:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 08:18:46 --> Model Class Initialized
INFO - 2016-08-19 08:18:46 --> Model Class Initialized
INFO - 2016-08-19 08:18:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 08:18:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-19 08:18:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-19 08:18:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 08:18:46 --> Final output sent to browser
DEBUG - 2016-08-19 08:18:46 --> Total execution time: 0.4565
INFO - 2016-08-19 08:28:47 --> Config Class Initialized
INFO - 2016-08-19 08:28:47 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:28:47 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:28:47 --> Utf8 Class Initialized
INFO - 2016-08-19 08:28:47 --> URI Class Initialized
INFO - 2016-08-19 08:28:47 --> Router Class Initialized
INFO - 2016-08-19 08:28:47 --> Output Class Initialized
INFO - 2016-08-19 08:28:47 --> Security Class Initialized
DEBUG - 2016-08-19 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:28:47 --> Input Class Initialized
INFO - 2016-08-19 08:28:47 --> Language Class Initialized
INFO - 2016-08-19 08:28:47 --> Loader Class Initialized
INFO - 2016-08-19 08:28:47 --> Helper loaded: url_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: html_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: form_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: file_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:28:47 --> Database Driver Class Initialized
INFO - 2016-08-19 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:28:47 --> Form Validation Class Initialized
INFO - 2016-08-19 08:28:47 --> Email Class Initialized
INFO - 2016-08-19 08:28:47 --> Controller Class Initialized
INFO - 2016-08-19 08:28:47 --> Model Class Initialized
INFO - 2016-08-19 08:28:47 --> Config Class Initialized
INFO - 2016-08-19 08:28:47 --> Hooks Class Initialized
DEBUG - 2016-08-19 08:28:47 --> UTF-8 Support Enabled
INFO - 2016-08-19 08:28:47 --> Utf8 Class Initialized
INFO - 2016-08-19 08:28:47 --> URI Class Initialized
INFO - 2016-08-19 08:28:47 --> Router Class Initialized
INFO - 2016-08-19 08:28:47 --> Output Class Initialized
INFO - 2016-08-19 08:28:47 --> Security Class Initialized
DEBUG - 2016-08-19 08:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-19 08:28:47 --> Input Class Initialized
INFO - 2016-08-19 08:28:47 --> Language Class Initialized
INFO - 2016-08-19 08:28:47 --> Loader Class Initialized
INFO - 2016-08-19 08:28:47 --> Helper loaded: url_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: utils_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: html_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: form_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: file_helper
INFO - 2016-08-19 08:28:47 --> Helper loaded: myemail_helper
INFO - 2016-08-19 08:28:47 --> Database Driver Class Initialized
INFO - 2016-08-19 08:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-19 08:28:47 --> Form Validation Class Initialized
INFO - 2016-08-19 08:28:47 --> Email Class Initialized
INFO - 2016-08-19 08:28:47 --> Controller Class Initialized
INFO - 2016-08-19 08:28:47 --> Model Class Initialized
DEBUG - 2016-08-19 08:28:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-19 08:28:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-19 08:28:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-19 08:28:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-19 08:28:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-19 08:28:47 --> Final output sent to browser
DEBUG - 2016-08-19 08:28:47 --> Total execution time: 0.4126
