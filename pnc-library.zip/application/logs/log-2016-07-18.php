<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-18 08:06:01 --> Config Class Initialized
INFO - 2016-07-18 08:06:01 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:06:01 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:06:01 --> Utf8 Class Initialized
INFO - 2016-07-18 08:06:01 --> URI Class Initialized
DEBUG - 2016-07-18 08:06:01 --> No URI present. Default controller set.
INFO - 2016-07-18 08:06:01 --> Router Class Initialized
INFO - 2016-07-18 08:06:01 --> Output Class Initialized
INFO - 2016-07-18 08:06:01 --> Security Class Initialized
DEBUG - 2016-07-18 08:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:06:01 --> Input Class Initialized
INFO - 2016-07-18 08:06:01 --> Language Class Initialized
INFO - 2016-07-18 08:06:01 --> Loader Class Initialized
INFO - 2016-07-18 08:06:01 --> Helper loaded: url_helper
INFO - 2016-07-18 08:06:01 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:06:01 --> Helper loaded: html_helper
INFO - 2016-07-18 08:06:01 --> Helper loaded: form_helper
INFO - 2016-07-18 08:06:01 --> Helper loaded: file_helper
INFO - 2016-07-18 08:06:01 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:06:01 --> Database Driver Class Initialized
INFO - 2016-07-18 08:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:06:01 --> Form Validation Class Initialized
INFO - 2016-07-18 08:06:01 --> Email Class Initialized
INFO - 2016-07-18 08:06:01 --> Controller Class Initialized
INFO - 2016-07-18 08:06:02 --> Config Class Initialized
INFO - 2016-07-18 08:06:02 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:06:02 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:06:02 --> Utf8 Class Initialized
INFO - 2016-07-18 08:06:02 --> URI Class Initialized
INFO - 2016-07-18 08:06:02 --> Router Class Initialized
INFO - 2016-07-18 08:06:02 --> Output Class Initialized
INFO - 2016-07-18 08:06:02 --> Security Class Initialized
DEBUG - 2016-07-18 08:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:06:02 --> Input Class Initialized
INFO - 2016-07-18 08:06:02 --> Language Class Initialized
INFO - 2016-07-18 08:06:02 --> Loader Class Initialized
INFO - 2016-07-18 08:06:02 --> Helper loaded: url_helper
INFO - 2016-07-18 08:06:02 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:06:02 --> Helper loaded: html_helper
INFO - 2016-07-18 08:06:02 --> Helper loaded: form_helper
INFO - 2016-07-18 08:06:02 --> Helper loaded: file_helper
INFO - 2016-07-18 08:06:02 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:06:02 --> Database Driver Class Initialized
INFO - 2016-07-18 08:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:06:02 --> Form Validation Class Initialized
INFO - 2016-07-18 08:06:02 --> Email Class Initialized
INFO - 2016-07-18 08:06:02 --> Controller Class Initialized
INFO - 2016-07-18 08:06:02 --> Model Class Initialized
DEBUG - 2016-07-18 08:06:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:06:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-18 08:06:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-18 08:06:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-18 08:06:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-18 08:06:02 --> Final output sent to browser
DEBUG - 2016-07-18 08:06:02 --> Total execution time: 0.4193
INFO - 2016-07-18 08:06:03 --> Config Class Initialized
INFO - 2016-07-18 08:06:03 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:06:03 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:06:03 --> Utf8 Class Initialized
INFO - 2016-07-18 08:06:03 --> URI Class Initialized
INFO - 2016-07-18 08:06:03 --> Router Class Initialized
INFO - 2016-07-18 08:06:03 --> Output Class Initialized
INFO - 2016-07-18 08:06:03 --> Security Class Initialized
DEBUG - 2016-07-18 08:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:06:03 --> Input Class Initialized
INFO - 2016-07-18 08:06:03 --> Language Class Initialized
ERROR - 2016-07-18 08:06:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-18 08:07:17 --> Config Class Initialized
INFO - 2016-07-18 08:07:17 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:17 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:17 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:17 --> URI Class Initialized
INFO - 2016-07-18 08:07:17 --> Router Class Initialized
INFO - 2016-07-18 08:07:17 --> Output Class Initialized
INFO - 2016-07-18 08:07:17 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:17 --> Input Class Initialized
INFO - 2016-07-18 08:07:17 --> Language Class Initialized
INFO - 2016-07-18 08:07:17 --> Loader Class Initialized
INFO - 2016-07-18 08:07:17 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:17 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:17 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:17 --> Email Class Initialized
INFO - 2016-07-18 08:07:17 --> Controller Class Initialized
INFO - 2016-07-18 08:07:17 --> Model Class Initialized
DEBUG - 2016-07-18 08:07:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:07:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-18 08:07:17 --> Config Class Initialized
INFO - 2016-07-18 08:07:17 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:17 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:17 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:17 --> URI Class Initialized
DEBUG - 2016-07-18 08:07:17 --> No URI present. Default controller set.
INFO - 2016-07-18 08:07:17 --> Router Class Initialized
INFO - 2016-07-18 08:07:17 --> Output Class Initialized
INFO - 2016-07-18 08:07:17 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:17 --> Input Class Initialized
INFO - 2016-07-18 08:07:17 --> Language Class Initialized
INFO - 2016-07-18 08:07:17 --> Loader Class Initialized
INFO - 2016-07-18 08:07:17 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:17 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:17 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:17 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:17 --> Email Class Initialized
INFO - 2016-07-18 08:07:17 --> Controller Class Initialized
INFO - 2016-07-18 08:07:17 --> Model Class Initialized
INFO - 2016-07-18 08:07:17 --> Model Class Initialized
INFO - 2016-07-18 08:07:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-18 08:07:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-18 08:07:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-18 08:07:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-18 08:07:17 --> Final output sent to browser
DEBUG - 2016-07-18 08:07:17 --> Total execution time: 0.2500
INFO - 2016-07-18 08:07:18 --> Config Class Initialized
INFO - 2016-07-18 08:07:18 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:18 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:18 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:18 --> URI Class Initialized
INFO - 2016-07-18 08:07:18 --> Router Class Initialized
INFO - 2016-07-18 08:07:18 --> Output Class Initialized
INFO - 2016-07-18 08:07:18 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:18 --> Input Class Initialized
INFO - 2016-07-18 08:07:18 --> Language Class Initialized
ERROR - 2016-07-18 08:07:18 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-18 08:07:22 --> Config Class Initialized
INFO - 2016-07-18 08:07:22 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:22 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:22 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:22 --> URI Class Initialized
INFO - 2016-07-18 08:07:22 --> Router Class Initialized
INFO - 2016-07-18 08:07:22 --> Output Class Initialized
INFO - 2016-07-18 08:07:22 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:22 --> Input Class Initialized
INFO - 2016-07-18 08:07:22 --> Language Class Initialized
INFO - 2016-07-18 08:07:23 --> Loader Class Initialized
INFO - 2016-07-18 08:07:23 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:23 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:23 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:23 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:23 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:23 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:23 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:23 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:23 --> Email Class Initialized
INFO - 2016-07-18 08:07:23 --> Controller Class Initialized
DEBUG - 2016-07-18 08:07:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:07:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-18 08:07:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-18 08:07:23 --> Model Class Initialized
INFO - 2016-07-18 08:07:23 --> Model Class Initialized
INFO - 2016-07-18 08:07:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-07-18 08:07:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-18 08:07:23 --> Final output sent to browser
DEBUG - 2016-07-18 08:07:23 --> Total execution time: 0.3323
INFO - 2016-07-18 08:07:23 --> Config Class Initialized
INFO - 2016-07-18 08:07:23 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:23 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:23 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:23 --> URI Class Initialized
INFO - 2016-07-18 08:07:23 --> Router Class Initialized
INFO - 2016-07-18 08:07:23 --> Output Class Initialized
INFO - 2016-07-18 08:07:23 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:23 --> Input Class Initialized
INFO - 2016-07-18 08:07:23 --> Language Class Initialized
ERROR - 2016-07-18 08:07:23 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-18 08:07:25 --> Config Class Initialized
INFO - 2016-07-18 08:07:25 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:25 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:25 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:25 --> URI Class Initialized
INFO - 2016-07-18 08:07:25 --> Router Class Initialized
INFO - 2016-07-18 08:07:25 --> Output Class Initialized
INFO - 2016-07-18 08:07:25 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:25 --> Input Class Initialized
INFO - 2016-07-18 08:07:25 --> Language Class Initialized
INFO - 2016-07-18 08:07:25 --> Loader Class Initialized
INFO - 2016-07-18 08:07:25 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:25 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:25 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:25 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:25 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:25 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:25 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:25 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:25 --> Email Class Initialized
INFO - 2016-07-18 08:07:25 --> Controller Class Initialized
DEBUG - 2016-07-18 08:07:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:07:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-18 08:07:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-18 08:07:25 --> Model Class Initialized
INFO - 2016-07-18 08:07:25 --> Model Class Initialized
INFO - 2016-07-18 08:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-07-18 08:07:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-18 08:07:26 --> Final output sent to browser
DEBUG - 2016-07-18 08:07:26 --> Total execution time: 0.3122
INFO - 2016-07-18 08:07:26 --> Config Class Initialized
INFO - 2016-07-18 08:07:26 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:26 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:26 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:26 --> URI Class Initialized
INFO - 2016-07-18 08:07:26 --> Router Class Initialized
INFO - 2016-07-18 08:07:26 --> Output Class Initialized
INFO - 2016-07-18 08:07:26 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:26 --> Input Class Initialized
INFO - 2016-07-18 08:07:26 --> Language Class Initialized
ERROR - 2016-07-18 08:07:26 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-18 08:07:28 --> Config Class Initialized
INFO - 2016-07-18 08:07:28 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:28 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:28 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:28 --> URI Class Initialized
INFO - 2016-07-18 08:07:28 --> Router Class Initialized
INFO - 2016-07-18 08:07:28 --> Output Class Initialized
INFO - 2016-07-18 08:07:28 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:28 --> Input Class Initialized
INFO - 2016-07-18 08:07:28 --> Language Class Initialized
INFO - 2016-07-18 08:07:28 --> Loader Class Initialized
INFO - 2016-07-18 08:07:28 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:28 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:28 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:28 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:28 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:28 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:28 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:28 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:28 --> Email Class Initialized
INFO - 2016-07-18 08:07:28 --> Controller Class Initialized
DEBUG - 2016-07-18 08:07:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:07:28 --> Model Class Initialized
INFO - 2016-07-18 08:07:28 --> Model Class Initialized
INFO - 2016-07-18 08:07:28 --> Model Class Initialized
INFO - 2016-07-18 08:07:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-18 08:07:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-18 08:07:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-07-18 08:07:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-18 08:07:28 --> Final output sent to browser
DEBUG - 2016-07-18 08:07:28 --> Total execution time: 0.3238
INFO - 2016-07-18 08:07:28 --> Config Class Initialized
INFO - 2016-07-18 08:07:28 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:28 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:28 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:28 --> URI Class Initialized
INFO - 2016-07-18 08:07:28 --> Router Class Initialized
INFO - 2016-07-18 08:07:28 --> Output Class Initialized
INFO - 2016-07-18 08:07:28 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:28 --> Input Class Initialized
INFO - 2016-07-18 08:07:28 --> Language Class Initialized
ERROR - 2016-07-18 08:07:28 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-18 08:07:32 --> Config Class Initialized
INFO - 2016-07-18 08:07:32 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:32 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:32 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:32 --> URI Class Initialized
INFO - 2016-07-18 08:07:32 --> Router Class Initialized
INFO - 2016-07-18 08:07:32 --> Output Class Initialized
INFO - 2016-07-18 08:07:32 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:32 --> Input Class Initialized
INFO - 2016-07-18 08:07:32 --> Language Class Initialized
INFO - 2016-07-18 08:07:32 --> Loader Class Initialized
INFO - 2016-07-18 08:07:32 --> Helper loaded: url_helper
INFO - 2016-07-18 08:07:32 --> Helper loaded: utils_helper
INFO - 2016-07-18 08:07:32 --> Helper loaded: html_helper
INFO - 2016-07-18 08:07:32 --> Helper loaded: form_helper
INFO - 2016-07-18 08:07:32 --> Helper loaded: file_helper
INFO - 2016-07-18 08:07:32 --> Helper loaded: myemail_helper
INFO - 2016-07-18 08:07:32 --> Database Driver Class Initialized
INFO - 2016-07-18 08:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-18 08:07:32 --> Form Validation Class Initialized
INFO - 2016-07-18 08:07:32 --> Email Class Initialized
INFO - 2016-07-18 08:07:32 --> Controller Class Initialized
DEBUG - 2016-07-18 08:07:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-18 08:07:32 --> Helper loaded: download_helper
INFO - 2016-07-18 08:07:32 --> Config Class Initialized
INFO - 2016-07-18 08:07:32 --> Hooks Class Initialized
DEBUG - 2016-07-18 08:07:32 --> UTF-8 Support Enabled
INFO - 2016-07-18 08:07:32 --> Utf8 Class Initialized
INFO - 2016-07-18 08:07:32 --> URI Class Initialized
INFO - 2016-07-18 08:07:32 --> Router Class Initialized
INFO - 2016-07-18 08:07:32 --> Output Class Initialized
INFO - 2016-07-18 08:07:32 --> Security Class Initialized
DEBUG - 2016-07-18 08:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-18 08:07:32 --> Input Class Initialized
INFO - 2016-07-18 08:07:32 --> Language Class Initialized
ERROR - 2016-07-18 08:07:32 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-07-18 08:07:32 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 321
