<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-13 01:49:55 --> Config Class Initialized
INFO - 2016-07-13 01:49:55 --> Hooks Class Initialized
DEBUG - 2016-07-13 01:49:55 --> UTF-8 Support Enabled
INFO - 2016-07-13 01:49:55 --> Utf8 Class Initialized
INFO - 2016-07-13 01:49:55 --> URI Class Initialized
DEBUG - 2016-07-13 01:49:55 --> No URI present. Default controller set.
INFO - 2016-07-13 01:49:55 --> Router Class Initialized
INFO - 2016-07-13 01:49:55 --> Output Class Initialized
INFO - 2016-07-13 01:49:55 --> Security Class Initialized
DEBUG - 2016-07-13 01:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-13 01:49:55 --> Input Class Initialized
INFO - 2016-07-13 01:49:55 --> Language Class Initialized
INFO - 2016-07-13 01:49:55 --> Loader Class Initialized
INFO - 2016-07-13 01:49:55 --> Helper loaded: url_helper
INFO - 2016-07-13 01:49:55 --> Helper loaded: utils_helper
INFO - 2016-07-13 01:49:55 --> Helper loaded: html_helper
INFO - 2016-07-13 01:49:55 --> Helper loaded: form_helper
INFO - 2016-07-13 01:49:55 --> Helper loaded: file_helper
INFO - 2016-07-13 01:49:55 --> Helper loaded: myemail_helper
INFO - 2016-07-13 01:49:55 --> Database Driver Class Initialized
INFO - 2016-07-13 01:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-13 01:49:56 --> Form Validation Class Initialized
INFO - 2016-07-13 01:49:56 --> Email Class Initialized
INFO - 2016-07-13 01:49:56 --> Controller Class Initialized
INFO - 2016-07-13 01:49:56 --> Config Class Initialized
INFO - 2016-07-13 01:49:56 --> Hooks Class Initialized
DEBUG - 2016-07-13 01:49:56 --> UTF-8 Support Enabled
INFO - 2016-07-13 01:49:56 --> Utf8 Class Initialized
INFO - 2016-07-13 01:49:56 --> URI Class Initialized
INFO - 2016-07-13 01:49:56 --> Router Class Initialized
INFO - 2016-07-13 01:49:56 --> Output Class Initialized
INFO - 2016-07-13 01:49:56 --> Security Class Initialized
DEBUG - 2016-07-13 01:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-13 01:49:56 --> Input Class Initialized
INFO - 2016-07-13 01:49:56 --> Language Class Initialized
INFO - 2016-07-13 01:49:56 --> Loader Class Initialized
INFO - 2016-07-13 01:49:56 --> Helper loaded: url_helper
INFO - 2016-07-13 01:49:56 --> Helper loaded: utils_helper
INFO - 2016-07-13 01:49:56 --> Helper loaded: html_helper
INFO - 2016-07-13 01:49:56 --> Helper loaded: form_helper
INFO - 2016-07-13 01:49:56 --> Helper loaded: file_helper
INFO - 2016-07-13 01:49:56 --> Helper loaded: myemail_helper
INFO - 2016-07-13 01:49:56 --> Database Driver Class Initialized
INFO - 2016-07-13 01:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-13 01:49:56 --> Form Validation Class Initialized
INFO - 2016-07-13 01:49:56 --> Email Class Initialized
INFO - 2016-07-13 01:49:56 --> Controller Class Initialized
INFO - 2016-07-13 01:49:56 --> Model Class Initialized
DEBUG - 2016-07-13 01:49:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-13 01:49:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-13 01:49:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-13 01:49:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-13 01:49:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-13 01:49:56 --> Final output sent to browser
DEBUG - 2016-07-13 01:49:56 --> Total execution time: 0.4911
INFO - 2016-07-13 04:37:55 --> Config Class Initialized
INFO - 2016-07-13 04:37:55 --> Hooks Class Initialized
DEBUG - 2016-07-13 04:37:56 --> UTF-8 Support Enabled
INFO - 2016-07-13 04:37:56 --> Utf8 Class Initialized
INFO - 2016-07-13 04:37:56 --> URI Class Initialized
INFO - 2016-07-13 04:37:56 --> Router Class Initialized
INFO - 2016-07-13 04:37:56 --> Output Class Initialized
INFO - 2016-07-13 04:37:56 --> Security Class Initialized
DEBUG - 2016-07-13 04:37:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-13 04:37:56 --> Input Class Initialized
INFO - 2016-07-13 04:37:56 --> Language Class Initialized
INFO - 2016-07-13 04:37:56 --> Loader Class Initialized
INFO - 2016-07-13 04:37:56 --> Helper loaded: url_helper
INFO - 2016-07-13 04:37:56 --> Helper loaded: utils_helper
INFO - 2016-07-13 04:37:56 --> Helper loaded: html_helper
INFO - 2016-07-13 04:37:56 --> Helper loaded: form_helper
INFO - 2016-07-13 04:37:56 --> Helper loaded: file_helper
INFO - 2016-07-13 04:37:56 --> Helper loaded: myemail_helper
INFO - 2016-07-13 04:37:56 --> Database Driver Class Initialized
INFO - 2016-07-13 04:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-13 04:37:56 --> Form Validation Class Initialized
INFO - 2016-07-13 04:37:56 --> Email Class Initialized
INFO - 2016-07-13 04:37:56 --> Controller Class Initialized
INFO - 2016-07-13 04:37:56 --> Model Class Initialized
DEBUG - 2016-07-13 04:37:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-13 04:37:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-13 04:37:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-13 04:37:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-13 04:37:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-13 04:37:56 --> Final output sent to browser
DEBUG - 2016-07-13 04:37:56 --> Total execution time: 0.2976
