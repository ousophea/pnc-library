<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-21 01:26:19 --> Config Class Initialized
INFO - 2016-07-21 01:26:19 --> Hooks Class Initialized
DEBUG - 2016-07-21 01:26:20 --> UTF-8 Support Enabled
INFO - 2016-07-21 01:26:20 --> Utf8 Class Initialized
INFO - 2016-07-21 01:26:21 --> URI Class Initialized
INFO - 2016-07-21 01:26:22 --> Router Class Initialized
INFO - 2016-07-21 01:26:23 --> Output Class Initialized
INFO - 2016-07-21 01:26:23 --> Security Class Initialized
DEBUG - 2016-07-21 01:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 01:26:23 --> Input Class Initialized
INFO - 2016-07-21 01:26:23 --> Language Class Initialized
INFO - 2016-07-21 01:26:24 --> Loader Class Initialized
INFO - 2016-07-21 01:26:25 --> Helper loaded: url_helper
INFO - 2016-07-21 01:26:25 --> Helper loaded: utils_helper
INFO - 2016-07-21 01:26:26 --> Helper loaded: html_helper
INFO - 2016-07-21 01:26:26 --> Helper loaded: form_helper
INFO - 2016-07-21 01:26:27 --> Helper loaded: file_helper
INFO - 2016-07-21 01:26:27 --> Helper loaded: myemail_helper
INFO - 2016-07-21 01:26:29 --> Database Driver Class Initialized
INFO - 2016-07-21 01:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 01:26:34 --> Form Validation Class Initialized
INFO - 2016-07-21 01:26:34 --> Email Class Initialized
INFO - 2016-07-21 01:26:34 --> Controller Class Initialized
INFO - 2016-07-21 01:26:37 --> Config Class Initialized
INFO - 2016-07-21 01:26:37 --> Hooks Class Initialized
DEBUG - 2016-07-21 01:26:37 --> UTF-8 Support Enabled
INFO - 2016-07-21 01:26:37 --> Utf8 Class Initialized
INFO - 2016-07-21 01:26:37 --> URI Class Initialized
INFO - 2016-07-21 01:26:38 --> Router Class Initialized
INFO - 2016-07-21 01:26:38 --> Output Class Initialized
INFO - 2016-07-21 01:26:38 --> Security Class Initialized
DEBUG - 2016-07-21 01:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 01:26:38 --> Input Class Initialized
INFO - 2016-07-21 01:26:38 --> Language Class Initialized
INFO - 2016-07-21 01:26:38 --> Loader Class Initialized
INFO - 2016-07-21 01:26:38 --> Helper loaded: url_helper
INFO - 2016-07-21 01:26:38 --> Helper loaded: utils_helper
INFO - 2016-07-21 01:26:38 --> Helper loaded: html_helper
INFO - 2016-07-21 01:26:38 --> Helper loaded: form_helper
INFO - 2016-07-21 01:26:38 --> Helper loaded: file_helper
INFO - 2016-07-21 01:26:38 --> Helper loaded: myemail_helper
INFO - 2016-07-21 01:26:38 --> Database Driver Class Initialized
INFO - 2016-07-21 01:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 01:26:38 --> Form Validation Class Initialized
INFO - 2016-07-21 01:26:38 --> Email Class Initialized
INFO - 2016-07-21 01:26:38 --> Controller Class Initialized
INFO - 2016-07-21 01:26:38 --> Model Class Initialized
DEBUG - 2016-07-21 01:26:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-21 01:26:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-21 01:26:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-21 01:26:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-21 01:26:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-21 01:26:41 --> Final output sent to browser
DEBUG - 2016-07-21 01:26:41 --> Total execution time: 4.7026
INFO - 2016-07-21 01:26:45 --> Config Class Initialized
INFO - 2016-07-21 01:26:45 --> Hooks Class Initialized
DEBUG - 2016-07-21 01:26:45 --> UTF-8 Support Enabled
INFO - 2016-07-21 01:26:45 --> Utf8 Class Initialized
INFO - 2016-07-21 01:26:45 --> URI Class Initialized
INFO - 2016-07-21 01:26:45 --> Router Class Initialized
INFO - 2016-07-21 01:26:45 --> Output Class Initialized
INFO - 2016-07-21 01:26:45 --> Security Class Initialized
DEBUG - 2016-07-21 01:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 01:26:45 --> Input Class Initialized
INFO - 2016-07-21 01:26:45 --> Language Class Initialized
ERROR - 2016-07-21 01:26:45 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 01:26:45 --> Config Class Initialized
INFO - 2016-07-21 01:26:45 --> Hooks Class Initialized
DEBUG - 2016-07-21 01:26:45 --> UTF-8 Support Enabled
INFO - 2016-07-21 01:26:45 --> Utf8 Class Initialized
INFO - 2016-07-21 01:26:45 --> URI Class Initialized
INFO - 2016-07-21 01:26:45 --> Router Class Initialized
INFO - 2016-07-21 01:26:45 --> Output Class Initialized
INFO - 2016-07-21 01:26:45 --> Security Class Initialized
DEBUG - 2016-07-21 01:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 01:26:45 --> Input Class Initialized
INFO - 2016-07-21 01:26:45 --> Language Class Initialized
ERROR - 2016-07-21 01:26:45 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 02:11:04 --> Config Class Initialized
INFO - 2016-07-21 02:11:04 --> Hooks Class Initialized
DEBUG - 2016-07-21 02:11:05 --> UTF-8 Support Enabled
INFO - 2016-07-21 02:11:05 --> Utf8 Class Initialized
INFO - 2016-07-21 02:11:05 --> URI Class Initialized
INFO - 2016-07-21 02:11:05 --> Router Class Initialized
INFO - 2016-07-21 02:11:05 --> Output Class Initialized
INFO - 2016-07-21 02:11:05 --> Security Class Initialized
DEBUG - 2016-07-21 02:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 02:11:05 --> Input Class Initialized
INFO - 2016-07-21 02:11:05 --> Language Class Initialized
ERROR - 2016-07-21 02:11:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 02:11:06 --> Config Class Initialized
INFO - 2016-07-21 02:11:06 --> Hooks Class Initialized
DEBUG - 2016-07-21 02:11:06 --> UTF-8 Support Enabled
INFO - 2016-07-21 02:11:06 --> Utf8 Class Initialized
INFO - 2016-07-21 02:11:06 --> URI Class Initialized
INFO - 2016-07-21 02:11:06 --> Router Class Initialized
INFO - 2016-07-21 02:11:06 --> Output Class Initialized
INFO - 2016-07-21 02:11:06 --> Security Class Initialized
DEBUG - 2016-07-21 02:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 02:11:06 --> Input Class Initialized
INFO - 2016-07-21 02:11:06 --> Language Class Initialized
ERROR - 2016-07-21 02:11:06 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 03:27:05 --> Config Class Initialized
INFO - 2016-07-21 03:27:05 --> Hooks Class Initialized
DEBUG - 2016-07-21 03:27:05 --> UTF-8 Support Enabled
INFO - 2016-07-21 03:27:05 --> Utf8 Class Initialized
INFO - 2016-07-21 03:27:05 --> URI Class Initialized
INFO - 2016-07-21 03:27:05 --> Router Class Initialized
INFO - 2016-07-21 03:27:05 --> Output Class Initialized
INFO - 2016-07-21 03:27:05 --> Security Class Initialized
DEBUG - 2016-07-21 03:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 03:27:05 --> Input Class Initialized
INFO - 2016-07-21 03:27:05 --> Language Class Initialized
ERROR - 2016-07-21 03:27:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 03:27:06 --> Config Class Initialized
INFO - 2016-07-21 03:27:06 --> Hooks Class Initialized
DEBUG - 2016-07-21 03:27:06 --> UTF-8 Support Enabled
INFO - 2016-07-21 03:27:06 --> Utf8 Class Initialized
INFO - 2016-07-21 03:27:06 --> URI Class Initialized
INFO - 2016-07-21 03:27:06 --> Router Class Initialized
INFO - 2016-07-21 03:27:06 --> Output Class Initialized
INFO - 2016-07-21 03:27:06 --> Security Class Initialized
DEBUG - 2016-07-21 03:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 03:27:06 --> Input Class Initialized
INFO - 2016-07-21 03:27:06 --> Language Class Initialized
ERROR - 2016-07-21 03:27:06 --> 404 Page Not Found: Faviconico/index
INFO - 2016-07-21 03:27:10 --> Config Class Initialized
INFO - 2016-07-21 03:27:10 --> Hooks Class Initialized
DEBUG - 2016-07-21 03:27:10 --> UTF-8 Support Enabled
INFO - 2016-07-21 03:27:10 --> Utf8 Class Initialized
INFO - 2016-07-21 03:27:10 --> URI Class Initialized
INFO - 2016-07-21 03:27:10 --> Router Class Initialized
INFO - 2016-07-21 03:27:10 --> Output Class Initialized
INFO - 2016-07-21 03:27:10 --> Security Class Initialized
DEBUG - 2016-07-21 03:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-21 03:27:10 --> Input Class Initialized
INFO - 2016-07-21 03:27:10 --> Language Class Initialized
INFO - 2016-07-21 03:27:10 --> Loader Class Initialized
INFO - 2016-07-21 03:27:10 --> Helper loaded: url_helper
INFO - 2016-07-21 03:27:10 --> Helper loaded: utils_helper
INFO - 2016-07-21 03:27:10 --> Helper loaded: html_helper
INFO - 2016-07-21 03:27:10 --> Helper loaded: form_helper
INFO - 2016-07-21 03:27:10 --> Helper loaded: file_helper
INFO - 2016-07-21 03:27:10 --> Helper loaded: myemail_helper
INFO - 2016-07-21 03:27:10 --> Database Driver Class Initialized
INFO - 2016-07-21 03:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-21 03:27:10 --> Form Validation Class Initialized
INFO - 2016-07-21 03:27:10 --> Email Class Initialized
INFO - 2016-07-21 03:27:11 --> Controller Class Initialized
INFO - 2016-07-21 03:27:11 --> Model Class Initialized
DEBUG - 2016-07-21 03:27:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-21 03:27:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-21 03:27:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-21 03:27:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-21 03:27:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-21 03:27:11 --> Final output sent to browser
DEBUG - 2016-07-21 03:27:11 --> Total execution time: 0.6457
