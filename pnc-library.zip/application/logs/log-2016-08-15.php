<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-15 01:55:56 --> Config Class Initialized
INFO - 2016-08-15 01:55:56 --> Hooks Class Initialized
DEBUG - 2016-08-15 01:55:56 --> UTF-8 Support Enabled
INFO - 2016-08-15 01:55:56 --> Utf8 Class Initialized
INFO - 2016-08-15 01:55:56 --> URI Class Initialized
INFO - 2016-08-15 01:55:56 --> Router Class Initialized
INFO - 2016-08-15 01:55:56 --> Output Class Initialized
INFO - 2016-08-15 01:55:56 --> Security Class Initialized
DEBUG - 2016-08-15 01:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 01:55:56 --> Input Class Initialized
INFO - 2016-08-15 01:55:56 --> Language Class Initialized
INFO - 2016-08-15 01:55:56 --> Loader Class Initialized
INFO - 2016-08-15 01:55:56 --> Helper loaded: url_helper
INFO - 2016-08-15 01:55:56 --> Helper loaded: utils_helper
INFO - 2016-08-15 01:55:56 --> Helper loaded: html_helper
INFO - 2016-08-15 01:55:56 --> Helper loaded: form_helper
INFO - 2016-08-15 01:55:56 --> Helper loaded: file_helper
INFO - 2016-08-15 01:55:56 --> Helper loaded: myemail_helper
INFO - 2016-08-15 01:55:56 --> Database Driver Class Initialized
INFO - 2016-08-15 01:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 01:55:56 --> Form Validation Class Initialized
INFO - 2016-08-15 01:55:56 --> Email Class Initialized
INFO - 2016-08-15 01:55:56 --> Controller Class Initialized
INFO - 2016-08-15 01:55:56 --> Model Class Initialized
DEBUG - 2016-08-15 01:55:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 01:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-15 01:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 01:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-15 01:55:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 01:55:56 --> Final output sent to browser
DEBUG - 2016-08-15 01:55:56 --> Total execution time: 0.2775
INFO - 2016-08-15 01:55:57 --> Config Class Initialized
INFO - 2016-08-15 01:55:57 --> Hooks Class Initialized
DEBUG - 2016-08-15 01:55:57 --> UTF-8 Support Enabled
INFO - 2016-08-15 01:55:57 --> Utf8 Class Initialized
INFO - 2016-08-15 01:55:57 --> URI Class Initialized
INFO - 2016-08-15 01:55:57 --> Router Class Initialized
INFO - 2016-08-15 01:55:57 --> Output Class Initialized
INFO - 2016-08-15 01:55:57 --> Security Class Initialized
DEBUG - 2016-08-15 01:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 01:55:57 --> Input Class Initialized
INFO - 2016-08-15 01:55:57 --> Language Class Initialized
ERROR - 2016-08-15 01:55:57 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-15 01:55:58 --> Config Class Initialized
INFO - 2016-08-15 01:55:58 --> Hooks Class Initialized
DEBUG - 2016-08-15 01:55:58 --> UTF-8 Support Enabled
INFO - 2016-08-15 01:55:58 --> Utf8 Class Initialized
INFO - 2016-08-15 01:55:58 --> URI Class Initialized
INFO - 2016-08-15 01:55:58 --> Router Class Initialized
INFO - 2016-08-15 01:55:58 --> Output Class Initialized
INFO - 2016-08-15 01:55:58 --> Security Class Initialized
DEBUG - 2016-08-15 01:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 01:55:58 --> Input Class Initialized
INFO - 2016-08-15 01:55:58 --> Language Class Initialized
ERROR - 2016-08-15 01:55:58 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-15 06:25:46 --> Config Class Initialized
INFO - 2016-08-15 06:25:46 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:25:46 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:25:46 --> Utf8 Class Initialized
INFO - 2016-08-15 06:25:46 --> URI Class Initialized
DEBUG - 2016-08-15 06:25:46 --> No URI present. Default controller set.
INFO - 2016-08-15 06:25:46 --> Router Class Initialized
INFO - 2016-08-15 06:25:46 --> Output Class Initialized
INFO - 2016-08-15 06:25:46 --> Security Class Initialized
DEBUG - 2016-08-15 06:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:25:46 --> Input Class Initialized
INFO - 2016-08-15 06:25:46 --> Language Class Initialized
INFO - 2016-08-15 06:25:46 --> Loader Class Initialized
INFO - 2016-08-15 06:25:46 --> Helper loaded: url_helper
INFO - 2016-08-15 06:25:46 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:25:46 --> Helper loaded: html_helper
INFO - 2016-08-15 06:25:46 --> Helper loaded: form_helper
INFO - 2016-08-15 06:25:46 --> Helper loaded: file_helper
INFO - 2016-08-15 06:25:46 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:25:46 --> Database Driver Class Initialized
INFO - 2016-08-15 06:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:25:46 --> Form Validation Class Initialized
INFO - 2016-08-15 06:25:46 --> Email Class Initialized
INFO - 2016-08-15 06:25:46 --> Controller Class Initialized
INFO - 2016-08-15 06:25:46 --> Config Class Initialized
INFO - 2016-08-15 06:25:46 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:25:46 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:25:46 --> Utf8 Class Initialized
INFO - 2016-08-15 06:25:46 --> URI Class Initialized
INFO - 2016-08-15 06:25:46 --> Router Class Initialized
INFO - 2016-08-15 06:25:47 --> Output Class Initialized
INFO - 2016-08-15 06:25:47 --> Security Class Initialized
DEBUG - 2016-08-15 06:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:25:47 --> Input Class Initialized
INFO - 2016-08-15 06:25:47 --> Language Class Initialized
INFO - 2016-08-15 06:25:47 --> Loader Class Initialized
INFO - 2016-08-15 06:25:47 --> Helper loaded: url_helper
INFO - 2016-08-15 06:25:47 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:25:47 --> Helper loaded: html_helper
INFO - 2016-08-15 06:25:47 --> Helper loaded: form_helper
INFO - 2016-08-15 06:25:47 --> Helper loaded: file_helper
INFO - 2016-08-15 06:25:47 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:25:47 --> Database Driver Class Initialized
INFO - 2016-08-15 06:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:25:47 --> Form Validation Class Initialized
INFO - 2016-08-15 06:25:47 --> Email Class Initialized
INFO - 2016-08-15 06:25:47 --> Controller Class Initialized
INFO - 2016-08-15 06:25:47 --> Model Class Initialized
DEBUG - 2016-08-15 06:25:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 06:25:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-15 06:25:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 06:25:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-15 06:25:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 06:25:47 --> Final output sent to browser
DEBUG - 2016-08-15 06:25:47 --> Total execution time: 0.3181
INFO - 2016-08-15 06:25:51 --> Config Class Initialized
INFO - 2016-08-15 06:25:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:25:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:25:51 --> Utf8 Class Initialized
INFO - 2016-08-15 06:25:51 --> URI Class Initialized
INFO - 2016-08-15 06:25:51 --> Router Class Initialized
INFO - 2016-08-15 06:25:51 --> Output Class Initialized
INFO - 2016-08-15 06:25:51 --> Security Class Initialized
DEBUG - 2016-08-15 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:25:51 --> Input Class Initialized
INFO - 2016-08-15 06:25:51 --> Language Class Initialized
INFO - 2016-08-15 06:25:51 --> Loader Class Initialized
INFO - 2016-08-15 06:25:51 --> Helper loaded: url_helper
INFO - 2016-08-15 06:25:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:25:51 --> Helper loaded: html_helper
INFO - 2016-08-15 06:25:51 --> Helper loaded: form_helper
INFO - 2016-08-15 06:25:51 --> Helper loaded: file_helper
INFO - 2016-08-15 06:25:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:25:51 --> Database Driver Class Initialized
INFO - 2016-08-15 06:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:25:51 --> Form Validation Class Initialized
INFO - 2016-08-15 06:25:51 --> Email Class Initialized
INFO - 2016-08-15 06:25:51 --> Controller Class Initialized
INFO - 2016-08-15 06:25:51 --> Model Class Initialized
DEBUG - 2016-08-15 06:25:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 06:25:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 06:25:51 --> Config Class Initialized
INFO - 2016-08-15 06:25:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:25:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:25:51 --> Utf8 Class Initialized
INFO - 2016-08-15 06:25:51 --> URI Class Initialized
DEBUG - 2016-08-15 06:25:51 --> No URI present. Default controller set.
INFO - 2016-08-15 06:25:51 --> Router Class Initialized
INFO - 2016-08-15 06:25:51 --> Output Class Initialized
INFO - 2016-08-15 06:25:51 --> Security Class Initialized
DEBUG - 2016-08-15 06:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:25:51 --> Input Class Initialized
INFO - 2016-08-15 06:25:52 --> Language Class Initialized
INFO - 2016-08-15 06:25:52 --> Loader Class Initialized
INFO - 2016-08-15 06:25:52 --> Helper loaded: url_helper
INFO - 2016-08-15 06:25:52 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:25:52 --> Helper loaded: html_helper
INFO - 2016-08-15 06:25:52 --> Helper loaded: form_helper
INFO - 2016-08-15 06:25:52 --> Helper loaded: file_helper
INFO - 2016-08-15 06:25:52 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:25:52 --> Database Driver Class Initialized
INFO - 2016-08-15 06:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:25:52 --> Form Validation Class Initialized
INFO - 2016-08-15 06:25:52 --> Email Class Initialized
INFO - 2016-08-15 06:25:52 --> Controller Class Initialized
INFO - 2016-08-15 06:25:52 --> Model Class Initialized
INFO - 2016-08-15 06:25:52 --> Model Class Initialized
INFO - 2016-08-15 06:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 06:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 06:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-15 06:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 06:25:52 --> Final output sent to browser
DEBUG - 2016-08-15 06:25:52 --> Total execution time: 0.2904
INFO - 2016-08-15 06:26:06 --> Config Class Initialized
INFO - 2016-08-15 06:26:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:26:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:26:06 --> Utf8 Class Initialized
INFO - 2016-08-15 06:26:06 --> URI Class Initialized
INFO - 2016-08-15 06:26:06 --> Router Class Initialized
INFO - 2016-08-15 06:26:06 --> Output Class Initialized
INFO - 2016-08-15 06:26:06 --> Security Class Initialized
DEBUG - 2016-08-15 06:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:26:06 --> Input Class Initialized
INFO - 2016-08-15 06:26:06 --> Language Class Initialized
INFO - 2016-08-15 06:26:06 --> Loader Class Initialized
INFO - 2016-08-15 06:26:06 --> Helper loaded: url_helper
INFO - 2016-08-15 06:26:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:26:06 --> Helper loaded: html_helper
INFO - 2016-08-15 06:26:06 --> Helper loaded: form_helper
INFO - 2016-08-15 06:26:06 --> Helper loaded: file_helper
INFO - 2016-08-15 06:26:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:26:06 --> Database Driver Class Initialized
INFO - 2016-08-15 06:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:26:06 --> Form Validation Class Initialized
INFO - 2016-08-15 06:26:06 --> Email Class Initialized
INFO - 2016-08-15 06:26:06 --> Controller Class Initialized
DEBUG - 2016-08-15 06:26:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 06:26:06 --> Model Class Initialized
INFO - 2016-08-15 06:26:06 --> Model Class Initialized
INFO - 2016-08-15 06:26:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 06:26:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 06:26:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-15 06:26:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 06:26:06 --> Final output sent to browser
DEBUG - 2016-08-15 06:26:06 --> Total execution time: 0.4190
INFO - 2016-08-15 06:26:23 --> Config Class Initialized
INFO - 2016-08-15 06:26:23 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:26:23 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:26:23 --> Utf8 Class Initialized
INFO - 2016-08-15 06:26:23 --> URI Class Initialized
INFO - 2016-08-15 06:26:23 --> Router Class Initialized
INFO - 2016-08-15 06:26:23 --> Output Class Initialized
INFO - 2016-08-15 06:26:23 --> Security Class Initialized
DEBUG - 2016-08-15 06:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:26:23 --> Input Class Initialized
INFO - 2016-08-15 06:26:23 --> Language Class Initialized
INFO - 2016-08-15 06:26:23 --> Loader Class Initialized
INFO - 2016-08-15 06:26:23 --> Helper loaded: url_helper
INFO - 2016-08-15 06:26:23 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:26:23 --> Helper loaded: html_helper
INFO - 2016-08-15 06:26:23 --> Helper loaded: form_helper
INFO - 2016-08-15 06:26:23 --> Helper loaded: file_helper
INFO - 2016-08-15 06:26:23 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:26:24 --> Database Driver Class Initialized
INFO - 2016-08-15 06:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:26:24 --> Form Validation Class Initialized
INFO - 2016-08-15 06:26:24 --> Email Class Initialized
INFO - 2016-08-15 06:26:24 --> Controller Class Initialized
DEBUG - 2016-08-15 06:26:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 06:26:24 --> Model Class Initialized
INFO - 2016-08-15 06:26:24 --> Model Class Initialized
INFO - 2016-08-15 06:26:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 06:26:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 06:26:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 06:26:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 06:26:24 --> Final output sent to browser
DEBUG - 2016-08-15 06:26:24 --> Total execution time: 0.2905
INFO - 2016-08-15 06:57:53 --> Config Class Initialized
INFO - 2016-08-15 06:57:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 06:57:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 06:57:53 --> Utf8 Class Initialized
INFO - 2016-08-15 06:57:53 --> URI Class Initialized
INFO - 2016-08-15 06:57:53 --> Router Class Initialized
INFO - 2016-08-15 06:57:53 --> Output Class Initialized
INFO - 2016-08-15 06:57:53 --> Security Class Initialized
DEBUG - 2016-08-15 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 06:57:53 --> Input Class Initialized
INFO - 2016-08-15 06:57:53 --> Language Class Initialized
INFO - 2016-08-15 06:57:53 --> Loader Class Initialized
INFO - 2016-08-15 06:57:53 --> Helper loaded: url_helper
INFO - 2016-08-15 06:57:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 06:57:53 --> Helper loaded: html_helper
INFO - 2016-08-15 06:57:53 --> Helper loaded: form_helper
INFO - 2016-08-15 06:57:53 --> Helper loaded: file_helper
INFO - 2016-08-15 06:57:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 06:57:53 --> Database Driver Class Initialized
INFO - 2016-08-15 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 06:57:53 --> Form Validation Class Initialized
INFO - 2016-08-15 06:57:53 --> Email Class Initialized
INFO - 2016-08-15 06:57:53 --> Controller Class Initialized
DEBUG - 2016-08-15 06:57:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 06:57:53 --> Model Class Initialized
INFO - 2016-08-15 06:57:53 --> Model Class Initialized
INFO - 2016-08-15 06:57:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 06:57:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 06:57:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 06:57:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 06:57:53 --> Final output sent to browser
DEBUG - 2016-08-15 06:57:53 --> Total execution time: 0.2466
INFO - 2016-08-15 07:00:56 --> Config Class Initialized
INFO - 2016-08-15 07:00:56 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:00:56 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:00:56 --> Utf8 Class Initialized
INFO - 2016-08-15 07:00:56 --> URI Class Initialized
INFO - 2016-08-15 07:00:56 --> Router Class Initialized
INFO - 2016-08-15 07:00:56 --> Output Class Initialized
INFO - 2016-08-15 07:00:56 --> Security Class Initialized
DEBUG - 2016-08-15 07:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:00:56 --> Input Class Initialized
INFO - 2016-08-15 07:00:56 --> Language Class Initialized
INFO - 2016-08-15 07:00:56 --> Loader Class Initialized
INFO - 2016-08-15 07:00:56 --> Helper loaded: url_helper
INFO - 2016-08-15 07:00:56 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:00:56 --> Helper loaded: html_helper
INFO - 2016-08-15 07:00:56 --> Helper loaded: form_helper
INFO - 2016-08-15 07:00:56 --> Helper loaded: file_helper
INFO - 2016-08-15 07:00:56 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:00:56 --> Database Driver Class Initialized
INFO - 2016-08-15 07:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:00:56 --> Form Validation Class Initialized
INFO - 2016-08-15 07:00:56 --> Email Class Initialized
INFO - 2016-08-15 07:00:56 --> Controller Class Initialized
DEBUG - 2016-08-15 07:00:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:00:56 --> Model Class Initialized
INFO - 2016-08-15 07:00:56 --> Model Class Initialized
INFO - 2016-08-15 07:00:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:00:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:00:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:00:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:00:56 --> Final output sent to browser
DEBUG - 2016-08-15 07:00:56 --> Total execution time: 0.2686
INFO - 2016-08-15 07:01:35 --> Config Class Initialized
INFO - 2016-08-15 07:01:35 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:01:35 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:01:35 --> Utf8 Class Initialized
INFO - 2016-08-15 07:01:35 --> URI Class Initialized
INFO - 2016-08-15 07:01:35 --> Router Class Initialized
INFO - 2016-08-15 07:01:35 --> Output Class Initialized
INFO - 2016-08-15 07:01:35 --> Security Class Initialized
DEBUG - 2016-08-15 07:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:01:35 --> Input Class Initialized
INFO - 2016-08-15 07:01:35 --> Language Class Initialized
INFO - 2016-08-15 07:01:35 --> Loader Class Initialized
INFO - 2016-08-15 07:01:35 --> Helper loaded: url_helper
INFO - 2016-08-15 07:01:35 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:01:35 --> Helper loaded: html_helper
INFO - 2016-08-15 07:01:35 --> Helper loaded: form_helper
INFO - 2016-08-15 07:01:35 --> Helper loaded: file_helper
INFO - 2016-08-15 07:01:35 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:01:35 --> Database Driver Class Initialized
INFO - 2016-08-15 07:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:01:35 --> Form Validation Class Initialized
INFO - 2016-08-15 07:01:35 --> Email Class Initialized
INFO - 2016-08-15 07:01:35 --> Controller Class Initialized
DEBUG - 2016-08-15 07:01:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:01:35 --> Model Class Initialized
INFO - 2016-08-15 07:01:35 --> Model Class Initialized
INFO - 2016-08-15 07:01:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:01:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:01:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:01:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:01:35 --> Final output sent to browser
DEBUG - 2016-08-15 07:01:35 --> Total execution time: 0.2406
INFO - 2016-08-15 07:01:53 --> Config Class Initialized
INFO - 2016-08-15 07:01:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:01:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:01:53 --> Utf8 Class Initialized
INFO - 2016-08-15 07:01:53 --> URI Class Initialized
INFO - 2016-08-15 07:01:53 --> Router Class Initialized
INFO - 2016-08-15 07:01:53 --> Output Class Initialized
INFO - 2016-08-15 07:01:53 --> Security Class Initialized
DEBUG - 2016-08-15 07:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:01:53 --> Input Class Initialized
INFO - 2016-08-15 07:01:53 --> Language Class Initialized
INFO - 2016-08-15 07:01:53 --> Loader Class Initialized
INFO - 2016-08-15 07:01:53 --> Helper loaded: url_helper
INFO - 2016-08-15 07:01:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:01:53 --> Helper loaded: html_helper
INFO - 2016-08-15 07:01:53 --> Helper loaded: form_helper
INFO - 2016-08-15 07:01:53 --> Helper loaded: file_helper
INFO - 2016-08-15 07:01:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:01:53 --> Database Driver Class Initialized
INFO - 2016-08-15 07:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:01:53 --> Form Validation Class Initialized
INFO - 2016-08-15 07:01:53 --> Email Class Initialized
INFO - 2016-08-15 07:01:53 --> Controller Class Initialized
DEBUG - 2016-08-15 07:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:01:53 --> Model Class Initialized
INFO - 2016-08-15 07:01:53 --> Model Class Initialized
INFO - 2016-08-15 07:01:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:01:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:01:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:01:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:01:53 --> Final output sent to browser
DEBUG - 2016-08-15 07:01:53 --> Total execution time: 0.2691
INFO - 2016-08-15 07:02:34 --> Config Class Initialized
INFO - 2016-08-15 07:02:34 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:02:34 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:02:34 --> Utf8 Class Initialized
INFO - 2016-08-15 07:02:34 --> URI Class Initialized
INFO - 2016-08-15 07:02:34 --> Router Class Initialized
INFO - 2016-08-15 07:02:34 --> Output Class Initialized
INFO - 2016-08-15 07:02:34 --> Security Class Initialized
DEBUG - 2016-08-15 07:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:02:34 --> Input Class Initialized
INFO - 2016-08-15 07:02:34 --> Language Class Initialized
INFO - 2016-08-15 07:02:34 --> Loader Class Initialized
INFO - 2016-08-15 07:02:34 --> Helper loaded: url_helper
INFO - 2016-08-15 07:02:34 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:02:34 --> Helper loaded: html_helper
INFO - 2016-08-15 07:02:34 --> Helper loaded: form_helper
INFO - 2016-08-15 07:02:34 --> Helper loaded: file_helper
INFO - 2016-08-15 07:02:34 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:02:34 --> Database Driver Class Initialized
INFO - 2016-08-15 07:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:02:34 --> Form Validation Class Initialized
INFO - 2016-08-15 07:02:34 --> Email Class Initialized
INFO - 2016-08-15 07:02:34 --> Controller Class Initialized
DEBUG - 2016-08-15 07:02:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:02:34 --> Model Class Initialized
INFO - 2016-08-15 07:02:34 --> Model Class Initialized
INFO - 2016-08-15 07:02:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:02:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:02:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-15 07:02:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:02:34 --> Final output sent to browser
DEBUG - 2016-08-15 07:02:34 --> Total execution time: 0.2472
INFO - 2016-08-15 07:02:39 --> Config Class Initialized
INFO - 2016-08-15 07:02:39 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:02:39 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:02:39 --> Utf8 Class Initialized
INFO - 2016-08-15 07:02:39 --> URI Class Initialized
INFO - 2016-08-15 07:02:39 --> Router Class Initialized
INFO - 2016-08-15 07:02:39 --> Output Class Initialized
INFO - 2016-08-15 07:02:39 --> Security Class Initialized
DEBUG - 2016-08-15 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:02:39 --> Input Class Initialized
INFO - 2016-08-15 07:02:39 --> Language Class Initialized
INFO - 2016-08-15 07:02:39 --> Loader Class Initialized
INFO - 2016-08-15 07:02:39 --> Helper loaded: url_helper
INFO - 2016-08-15 07:02:39 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:02:39 --> Helper loaded: html_helper
INFO - 2016-08-15 07:02:39 --> Helper loaded: form_helper
INFO - 2016-08-15 07:02:39 --> Helper loaded: file_helper
INFO - 2016-08-15 07:02:39 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:02:39 --> Database Driver Class Initialized
INFO - 2016-08-15 07:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:02:39 --> Form Validation Class Initialized
INFO - 2016-08-15 07:02:39 --> Email Class Initialized
INFO - 2016-08-15 07:02:39 --> Controller Class Initialized
DEBUG - 2016-08-15 07:02:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:02:39 --> Model Class Initialized
INFO - 2016-08-15 07:02:39 --> Model Class Initialized
INFO - 2016-08-15 07:02:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:02:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:02:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:02:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:02:39 --> Final output sent to browser
DEBUG - 2016-08-15 07:02:39 --> Total execution time: 0.2417
INFO - 2016-08-15 07:04:37 --> Config Class Initialized
INFO - 2016-08-15 07:04:37 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:04:37 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:04:37 --> Utf8 Class Initialized
INFO - 2016-08-15 07:04:37 --> URI Class Initialized
INFO - 2016-08-15 07:04:37 --> Router Class Initialized
INFO - 2016-08-15 07:04:37 --> Output Class Initialized
INFO - 2016-08-15 07:04:38 --> Security Class Initialized
DEBUG - 2016-08-15 07:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:04:38 --> Input Class Initialized
INFO - 2016-08-15 07:04:38 --> Language Class Initialized
INFO - 2016-08-15 07:04:38 --> Loader Class Initialized
INFO - 2016-08-15 07:04:38 --> Helper loaded: url_helper
INFO - 2016-08-15 07:04:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:04:38 --> Helper loaded: html_helper
INFO - 2016-08-15 07:04:38 --> Helper loaded: form_helper
INFO - 2016-08-15 07:04:38 --> Helper loaded: file_helper
INFO - 2016-08-15 07:04:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:04:38 --> Database Driver Class Initialized
INFO - 2016-08-15 07:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:04:38 --> Form Validation Class Initialized
INFO - 2016-08-15 07:04:38 --> Email Class Initialized
INFO - 2016-08-15 07:04:38 --> Controller Class Initialized
DEBUG - 2016-08-15 07:04:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:04:38 --> Model Class Initialized
INFO - 2016-08-15 07:04:38 --> Model Class Initialized
INFO - 2016-08-15 07:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:04:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:04:38 --> Final output sent to browser
DEBUG - 2016-08-15 07:04:38 --> Total execution time: 0.2649
INFO - 2016-08-15 07:04:53 --> Config Class Initialized
INFO - 2016-08-15 07:04:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:04:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:04:53 --> Utf8 Class Initialized
INFO - 2016-08-15 07:04:53 --> URI Class Initialized
INFO - 2016-08-15 07:04:53 --> Router Class Initialized
INFO - 2016-08-15 07:04:53 --> Output Class Initialized
INFO - 2016-08-15 07:04:53 --> Security Class Initialized
DEBUG - 2016-08-15 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:04:53 --> Input Class Initialized
INFO - 2016-08-15 07:04:53 --> Language Class Initialized
INFO - 2016-08-15 07:04:53 --> Loader Class Initialized
INFO - 2016-08-15 07:04:53 --> Helper loaded: url_helper
INFO - 2016-08-15 07:04:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:04:53 --> Helper loaded: html_helper
INFO - 2016-08-15 07:04:53 --> Helper loaded: form_helper
INFO - 2016-08-15 07:04:53 --> Helper loaded: file_helper
INFO - 2016-08-15 07:04:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:04:53 --> Database Driver Class Initialized
INFO - 2016-08-15 07:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:04:53 --> Form Validation Class Initialized
INFO - 2016-08-15 07:04:53 --> Email Class Initialized
INFO - 2016-08-15 07:04:53 --> Controller Class Initialized
DEBUG - 2016-08-15 07:04:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:04:53 --> Model Class Initialized
INFO - 2016-08-15 07:04:53 --> Model Class Initialized
INFO - 2016-08-15 07:04:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:04:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:04:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-15 07:04:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:04:53 --> Final output sent to browser
DEBUG - 2016-08-15 07:04:53 --> Total execution time: 0.2502
INFO - 2016-08-15 07:05:15 --> Config Class Initialized
INFO - 2016-08-15 07:05:15 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:05:15 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:05:15 --> Utf8 Class Initialized
INFO - 2016-08-15 07:05:15 --> URI Class Initialized
INFO - 2016-08-15 07:05:15 --> Router Class Initialized
INFO - 2016-08-15 07:05:15 --> Output Class Initialized
INFO - 2016-08-15 07:05:15 --> Security Class Initialized
DEBUG - 2016-08-15 07:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:05:15 --> Input Class Initialized
INFO - 2016-08-15 07:05:15 --> Language Class Initialized
INFO - 2016-08-15 07:05:15 --> Loader Class Initialized
INFO - 2016-08-15 07:05:15 --> Helper loaded: url_helper
INFO - 2016-08-15 07:05:15 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:05:15 --> Helper loaded: html_helper
INFO - 2016-08-15 07:05:15 --> Helper loaded: form_helper
INFO - 2016-08-15 07:05:15 --> Helper loaded: file_helper
INFO - 2016-08-15 07:05:15 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:05:15 --> Database Driver Class Initialized
INFO - 2016-08-15 07:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:05:15 --> Form Validation Class Initialized
INFO - 2016-08-15 07:05:15 --> Email Class Initialized
INFO - 2016-08-15 07:05:15 --> Controller Class Initialized
DEBUG - 2016-08-15 07:05:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:05:15 --> Model Class Initialized
INFO - 2016-08-15 07:05:15 --> Model Class Initialized
INFO - 2016-08-15 07:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:05:15 --> Final output sent to browser
DEBUG - 2016-08-15 07:05:15 --> Total execution time: 0.2743
INFO - 2016-08-15 07:06:05 --> Config Class Initialized
INFO - 2016-08-15 07:06:05 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:05 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:05 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:05 --> URI Class Initialized
INFO - 2016-08-15 07:06:05 --> Router Class Initialized
INFO - 2016-08-15 07:06:05 --> Output Class Initialized
INFO - 2016-08-15 07:06:05 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:05 --> Input Class Initialized
INFO - 2016-08-15 07:06:05 --> Language Class Initialized
INFO - 2016-08-15 07:06:05 --> Loader Class Initialized
INFO - 2016-08-15 07:06:05 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:05 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:05 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:05 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:05 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:05 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:05 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:05 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:05 --> Email Class Initialized
INFO - 2016-08-15 07:06:05 --> Controller Class Initialized
DEBUG - 2016-08-15 07:06:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:06:05 --> Model Class Initialized
INFO - 2016-08-15 07:06:05 --> Model Class Initialized
INFO - 2016-08-15 07:06:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:06:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:06:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:06:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:06:05 --> Final output sent to browser
DEBUG - 2016-08-15 07:06:05 --> Total execution time: 0.2528
INFO - 2016-08-15 07:06:28 --> Config Class Initialized
INFO - 2016-08-15 07:06:28 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:28 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:28 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:28 --> URI Class Initialized
INFO - 2016-08-15 07:06:28 --> Router Class Initialized
INFO - 2016-08-15 07:06:28 --> Output Class Initialized
INFO - 2016-08-15 07:06:28 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:28 --> Input Class Initialized
INFO - 2016-08-15 07:06:28 --> Language Class Initialized
INFO - 2016-08-15 07:06:28 --> Loader Class Initialized
INFO - 2016-08-15 07:06:28 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:28 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:28 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:28 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:28 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:28 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:28 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:28 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:28 --> Email Class Initialized
INFO - 2016-08-15 07:06:28 --> Controller Class Initialized
INFO - 2016-08-15 07:06:28 --> Model Class Initialized
INFO - 2016-08-15 07:06:29 --> Config Class Initialized
INFO - 2016-08-15 07:06:29 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:29 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:29 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:29 --> URI Class Initialized
INFO - 2016-08-15 07:06:29 --> Router Class Initialized
INFO - 2016-08-15 07:06:29 --> Output Class Initialized
INFO - 2016-08-15 07:06:29 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:29 --> Input Class Initialized
INFO - 2016-08-15 07:06:29 --> Language Class Initialized
INFO - 2016-08-15 07:06:29 --> Loader Class Initialized
INFO - 2016-08-15 07:06:29 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:29 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:29 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:29 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:29 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:29 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:29 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:29 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:29 --> Email Class Initialized
INFO - 2016-08-15 07:06:29 --> Controller Class Initialized
INFO - 2016-08-15 07:06:29 --> Model Class Initialized
DEBUG - 2016-08-15 07:06:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-15 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-15 07:06:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:06:29 --> Final output sent to browser
DEBUG - 2016-08-15 07:06:29 --> Total execution time: 0.2516
INFO - 2016-08-15 07:06:32 --> Config Class Initialized
INFO - 2016-08-15 07:06:32 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:32 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:32 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:32 --> URI Class Initialized
INFO - 2016-08-15 07:06:32 --> Router Class Initialized
INFO - 2016-08-15 07:06:32 --> Output Class Initialized
INFO - 2016-08-15 07:06:33 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:33 --> Input Class Initialized
INFO - 2016-08-15 07:06:33 --> Language Class Initialized
INFO - 2016-08-15 07:06:33 --> Loader Class Initialized
INFO - 2016-08-15 07:06:33 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:33 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:33 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:33 --> Email Class Initialized
INFO - 2016-08-15 07:06:33 --> Controller Class Initialized
INFO - 2016-08-15 07:06:33 --> Model Class Initialized
DEBUG - 2016-08-15 07:06:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:06:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 07:06:33 --> Config Class Initialized
INFO - 2016-08-15 07:06:33 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:33 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:33 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:33 --> URI Class Initialized
INFO - 2016-08-15 07:06:33 --> Router Class Initialized
INFO - 2016-08-15 07:06:33 --> Output Class Initialized
INFO - 2016-08-15 07:06:33 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:33 --> Input Class Initialized
INFO - 2016-08-15 07:06:33 --> Language Class Initialized
INFO - 2016-08-15 07:06:33 --> Loader Class Initialized
INFO - 2016-08-15 07:06:33 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:33 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:33 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:33 --> Email Class Initialized
INFO - 2016-08-15 07:06:33 --> Controller Class Initialized
INFO - 2016-08-15 07:06:33 --> Config Class Initialized
INFO - 2016-08-15 07:06:33 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:33 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:33 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:33 --> URI Class Initialized
INFO - 2016-08-15 07:06:33 --> Router Class Initialized
INFO - 2016-08-15 07:06:33 --> Output Class Initialized
INFO - 2016-08-15 07:06:33 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:33 --> Input Class Initialized
INFO - 2016-08-15 07:06:33 --> Language Class Initialized
INFO - 2016-08-15 07:06:33 --> Loader Class Initialized
INFO - 2016-08-15 07:06:33 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:33 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:33 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:33 --> Email Class Initialized
INFO - 2016-08-15 07:06:33 --> Controller Class Initialized
INFO - 2016-08-15 07:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 07:06:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:06:33 --> Final output sent to browser
DEBUG - 2016-08-15 07:06:33 --> Total execution time: 0.2279
INFO - 2016-08-15 07:06:36 --> Config Class Initialized
INFO - 2016-08-15 07:06:36 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:36 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:36 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:36 --> URI Class Initialized
INFO - 2016-08-15 07:06:36 --> Router Class Initialized
INFO - 2016-08-15 07:06:36 --> Output Class Initialized
INFO - 2016-08-15 07:06:36 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:36 --> Input Class Initialized
INFO - 2016-08-15 07:06:36 --> Language Class Initialized
INFO - 2016-08-15 07:06:36 --> Loader Class Initialized
INFO - 2016-08-15 07:06:36 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:36 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:36 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:36 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:36 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:36 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:36 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:36 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:36 --> Email Class Initialized
INFO - 2016-08-15 07:06:36 --> Controller Class Initialized
DEBUG - 2016-08-15 07:06:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:06:36 --> Model Class Initialized
INFO - 2016-08-15 07:06:36 --> Model Class Initialized
INFO - 2016-08-15 07:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:06:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:06:36 --> Final output sent to browser
DEBUG - 2016-08-15 07:06:36 --> Total execution time: 0.3508
INFO - 2016-08-15 07:06:59 --> Config Class Initialized
INFO - 2016-08-15 07:06:59 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:06:59 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:06:59 --> Utf8 Class Initialized
INFO - 2016-08-15 07:06:59 --> URI Class Initialized
INFO - 2016-08-15 07:06:59 --> Router Class Initialized
INFO - 2016-08-15 07:06:59 --> Output Class Initialized
INFO - 2016-08-15 07:06:59 --> Security Class Initialized
DEBUG - 2016-08-15 07:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:06:59 --> Input Class Initialized
INFO - 2016-08-15 07:06:59 --> Language Class Initialized
INFO - 2016-08-15 07:06:59 --> Loader Class Initialized
INFO - 2016-08-15 07:06:59 --> Helper loaded: url_helper
INFO - 2016-08-15 07:06:59 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:06:59 --> Helper loaded: html_helper
INFO - 2016-08-15 07:06:59 --> Helper loaded: form_helper
INFO - 2016-08-15 07:06:59 --> Helper loaded: file_helper
INFO - 2016-08-15 07:06:59 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:06:59 --> Database Driver Class Initialized
INFO - 2016-08-15 07:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:06:59 --> Form Validation Class Initialized
INFO - 2016-08-15 07:06:59 --> Email Class Initialized
INFO - 2016-08-15 07:06:59 --> Controller Class Initialized
DEBUG - 2016-08-15 07:06:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:06:59 --> Model Class Initialized
INFO - 2016-08-15 07:06:59 --> Model Class Initialized
INFO - 2016-08-15 07:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:06:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:06:59 --> Final output sent to browser
DEBUG - 2016-08-15 07:06:59 --> Total execution time: 0.2649
INFO - 2016-08-15 07:08:38 --> Config Class Initialized
INFO - 2016-08-15 07:08:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:08:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:08:38 --> Utf8 Class Initialized
INFO - 2016-08-15 07:08:38 --> URI Class Initialized
INFO - 2016-08-15 07:08:38 --> Router Class Initialized
INFO - 2016-08-15 07:08:38 --> Output Class Initialized
INFO - 2016-08-15 07:08:38 --> Security Class Initialized
DEBUG - 2016-08-15 07:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:08:38 --> Input Class Initialized
INFO - 2016-08-15 07:08:38 --> Language Class Initialized
INFO - 2016-08-15 07:08:38 --> Loader Class Initialized
INFO - 2016-08-15 07:08:38 --> Helper loaded: url_helper
INFO - 2016-08-15 07:08:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:08:38 --> Helper loaded: html_helper
INFO - 2016-08-15 07:08:38 --> Helper loaded: form_helper
INFO - 2016-08-15 07:08:38 --> Helper loaded: file_helper
INFO - 2016-08-15 07:08:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:08:38 --> Database Driver Class Initialized
INFO - 2016-08-15 07:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:08:38 --> Form Validation Class Initialized
INFO - 2016-08-15 07:08:38 --> Email Class Initialized
INFO - 2016-08-15 07:08:38 --> Controller Class Initialized
DEBUG - 2016-08-15 07:08:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:08:38 --> Model Class Initialized
INFO - 2016-08-15 07:08:38 --> Model Class Initialized
INFO - 2016-08-15 07:08:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:08:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:08:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:08:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:08:38 --> Final output sent to browser
DEBUG - 2016-08-15 07:08:38 --> Total execution time: 0.2645
INFO - 2016-08-15 07:09:29 --> Config Class Initialized
INFO - 2016-08-15 07:09:29 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:09:29 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:09:29 --> Utf8 Class Initialized
INFO - 2016-08-15 07:09:29 --> URI Class Initialized
INFO - 2016-08-15 07:09:29 --> Router Class Initialized
INFO - 2016-08-15 07:09:29 --> Output Class Initialized
INFO - 2016-08-15 07:09:29 --> Security Class Initialized
DEBUG - 2016-08-15 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:09:29 --> Input Class Initialized
INFO - 2016-08-15 07:09:29 --> Language Class Initialized
INFO - 2016-08-15 07:09:29 --> Loader Class Initialized
INFO - 2016-08-15 07:09:29 --> Helper loaded: url_helper
INFO - 2016-08-15 07:09:29 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:09:29 --> Helper loaded: html_helper
INFO - 2016-08-15 07:09:29 --> Helper loaded: form_helper
INFO - 2016-08-15 07:09:29 --> Helper loaded: file_helper
INFO - 2016-08-15 07:09:29 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:09:29 --> Database Driver Class Initialized
INFO - 2016-08-15 07:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:09:29 --> Form Validation Class Initialized
INFO - 2016-08-15 07:09:29 --> Email Class Initialized
INFO - 2016-08-15 07:09:29 --> Controller Class Initialized
DEBUG - 2016-08-15 07:09:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:09:29 --> Model Class Initialized
INFO - 2016-08-15 07:09:29 --> Model Class Initialized
INFO - 2016-08-15 07:09:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:09:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:09:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:09:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:09:29 --> Final output sent to browser
DEBUG - 2016-08-15 07:09:29 --> Total execution time: 0.2747
INFO - 2016-08-15 07:09:42 --> Config Class Initialized
INFO - 2016-08-15 07:09:42 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:09:42 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:09:42 --> Utf8 Class Initialized
INFO - 2016-08-15 07:09:42 --> URI Class Initialized
INFO - 2016-08-15 07:09:42 --> Router Class Initialized
INFO - 2016-08-15 07:09:42 --> Output Class Initialized
INFO - 2016-08-15 07:09:42 --> Security Class Initialized
DEBUG - 2016-08-15 07:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:09:42 --> Input Class Initialized
INFO - 2016-08-15 07:09:42 --> Language Class Initialized
INFO - 2016-08-15 07:09:42 --> Loader Class Initialized
INFO - 2016-08-15 07:09:42 --> Helper loaded: url_helper
INFO - 2016-08-15 07:09:42 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:09:42 --> Helper loaded: html_helper
INFO - 2016-08-15 07:09:42 --> Helper loaded: form_helper
INFO - 2016-08-15 07:09:42 --> Helper loaded: file_helper
INFO - 2016-08-15 07:09:42 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:09:42 --> Database Driver Class Initialized
INFO - 2016-08-15 07:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:09:42 --> Form Validation Class Initialized
INFO - 2016-08-15 07:09:42 --> Email Class Initialized
INFO - 2016-08-15 07:09:42 --> Controller Class Initialized
DEBUG - 2016-08-15 07:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:09:42 --> Model Class Initialized
INFO - 2016-08-15 07:09:42 --> Model Class Initialized
INFO - 2016-08-15 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:09:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:09:43 --> Final output sent to browser
DEBUG - 2016-08-15 07:09:43 --> Total execution time: 0.2698
INFO - 2016-08-15 07:11:35 --> Config Class Initialized
INFO - 2016-08-15 07:11:35 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:11:35 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:11:35 --> Utf8 Class Initialized
INFO - 2016-08-15 07:11:35 --> URI Class Initialized
INFO - 2016-08-15 07:11:35 --> Router Class Initialized
INFO - 2016-08-15 07:11:35 --> Output Class Initialized
INFO - 2016-08-15 07:11:35 --> Security Class Initialized
DEBUG - 2016-08-15 07:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:11:35 --> Input Class Initialized
INFO - 2016-08-15 07:11:35 --> Language Class Initialized
INFO - 2016-08-15 07:11:35 --> Loader Class Initialized
INFO - 2016-08-15 07:11:35 --> Helper loaded: url_helper
INFO - 2016-08-15 07:11:35 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:11:35 --> Helper loaded: html_helper
INFO - 2016-08-15 07:11:35 --> Helper loaded: form_helper
INFO - 2016-08-15 07:11:35 --> Helper loaded: file_helper
INFO - 2016-08-15 07:11:35 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:11:35 --> Database Driver Class Initialized
INFO - 2016-08-15 07:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:11:35 --> Form Validation Class Initialized
INFO - 2016-08-15 07:11:35 --> Email Class Initialized
INFO - 2016-08-15 07:11:35 --> Controller Class Initialized
DEBUG - 2016-08-15 07:11:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:11:35 --> Model Class Initialized
INFO - 2016-08-15 07:11:35 --> Model Class Initialized
INFO - 2016-08-15 07:11:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:11:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:11:35 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:11:35 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:11:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:11:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:11:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:11:35 --> Final output sent to browser
DEBUG - 2016-08-15 07:11:35 --> Total execution time: 0.4294
INFO - 2016-08-15 07:13:59 --> Config Class Initialized
INFO - 2016-08-15 07:13:59 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:13:59 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:13:59 --> Utf8 Class Initialized
INFO - 2016-08-15 07:13:59 --> URI Class Initialized
INFO - 2016-08-15 07:13:59 --> Router Class Initialized
INFO - 2016-08-15 07:13:59 --> Output Class Initialized
INFO - 2016-08-15 07:13:59 --> Security Class Initialized
DEBUG - 2016-08-15 07:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:13:59 --> Input Class Initialized
INFO - 2016-08-15 07:13:59 --> Language Class Initialized
INFO - 2016-08-15 07:13:59 --> Loader Class Initialized
INFO - 2016-08-15 07:13:59 --> Helper loaded: url_helper
INFO - 2016-08-15 07:13:59 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:13:59 --> Helper loaded: html_helper
INFO - 2016-08-15 07:13:59 --> Helper loaded: form_helper
INFO - 2016-08-15 07:13:59 --> Helper loaded: file_helper
INFO - 2016-08-15 07:13:59 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:13:59 --> Database Driver Class Initialized
INFO - 2016-08-15 07:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:13:59 --> Form Validation Class Initialized
INFO - 2016-08-15 07:13:59 --> Email Class Initialized
INFO - 2016-08-15 07:13:59 --> Controller Class Initialized
DEBUG - 2016-08-15 07:13:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:13:59 --> Model Class Initialized
INFO - 2016-08-15 07:13:59 --> Model Class Initialized
INFO - 2016-08-15 07:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:13:59 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:13:59 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:13:59 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:13:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:13:59 --> Final output sent to browser
DEBUG - 2016-08-15 07:13:59 --> Total execution time: 0.2976
INFO - 2016-08-15 07:17:58 --> Config Class Initialized
INFO - 2016-08-15 07:17:58 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:17:58 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:17:58 --> Utf8 Class Initialized
INFO - 2016-08-15 07:17:58 --> URI Class Initialized
INFO - 2016-08-15 07:17:58 --> Router Class Initialized
INFO - 2016-08-15 07:17:58 --> Output Class Initialized
INFO - 2016-08-15 07:17:58 --> Security Class Initialized
DEBUG - 2016-08-15 07:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:17:58 --> Input Class Initialized
INFO - 2016-08-15 07:17:58 --> Language Class Initialized
INFO - 2016-08-15 07:17:58 --> Loader Class Initialized
INFO - 2016-08-15 07:17:58 --> Helper loaded: url_helper
INFO - 2016-08-15 07:17:58 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:17:58 --> Helper loaded: html_helper
INFO - 2016-08-15 07:17:58 --> Helper loaded: form_helper
INFO - 2016-08-15 07:17:58 --> Helper loaded: file_helper
INFO - 2016-08-15 07:17:58 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:17:58 --> Database Driver Class Initialized
INFO - 2016-08-15 07:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:17:58 --> Form Validation Class Initialized
INFO - 2016-08-15 07:17:58 --> Email Class Initialized
INFO - 2016-08-15 07:17:58 --> Controller Class Initialized
DEBUG - 2016-08-15 07:17:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:17:58 --> Model Class Initialized
INFO - 2016-08-15 07:17:58 --> Model Class Initialized
INFO - 2016-08-15 07:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:17:58 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:17:58 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:17:58 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:17:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:17:58 --> Final output sent to browser
DEBUG - 2016-08-15 07:17:58 --> Total execution time: 0.2997
INFO - 2016-08-15 07:18:09 --> Config Class Initialized
INFO - 2016-08-15 07:18:09 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:18:09 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:18:09 --> Utf8 Class Initialized
INFO - 2016-08-15 07:18:09 --> URI Class Initialized
INFO - 2016-08-15 07:18:09 --> Router Class Initialized
INFO - 2016-08-15 07:18:09 --> Output Class Initialized
INFO - 2016-08-15 07:18:09 --> Security Class Initialized
DEBUG - 2016-08-15 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:18:09 --> Input Class Initialized
INFO - 2016-08-15 07:18:09 --> Language Class Initialized
INFO - 2016-08-15 07:18:09 --> Loader Class Initialized
INFO - 2016-08-15 07:18:09 --> Helper loaded: url_helper
INFO - 2016-08-15 07:18:09 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:18:09 --> Helper loaded: html_helper
INFO - 2016-08-15 07:18:09 --> Helper loaded: form_helper
INFO - 2016-08-15 07:18:09 --> Helper loaded: file_helper
INFO - 2016-08-15 07:18:09 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:18:09 --> Database Driver Class Initialized
INFO - 2016-08-15 07:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:18:09 --> Form Validation Class Initialized
INFO - 2016-08-15 07:18:09 --> Email Class Initialized
INFO - 2016-08-15 07:18:09 --> Controller Class Initialized
DEBUG - 2016-08-15 07:18:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:18:09 --> Model Class Initialized
INFO - 2016-08-15 07:18:09 --> Model Class Initialized
INFO - 2016-08-15 07:18:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:18:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:18:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:18:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:18:09 --> Final output sent to browser
DEBUG - 2016-08-15 07:18:09 --> Total execution time: 0.2642
INFO - 2016-08-15 07:22:18 --> Config Class Initialized
INFO - 2016-08-15 07:22:18 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:22:18 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:22:18 --> Utf8 Class Initialized
INFO - 2016-08-15 07:22:18 --> URI Class Initialized
INFO - 2016-08-15 07:22:18 --> Router Class Initialized
INFO - 2016-08-15 07:22:18 --> Output Class Initialized
INFO - 2016-08-15 07:22:18 --> Security Class Initialized
DEBUG - 2016-08-15 07:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:22:18 --> Input Class Initialized
INFO - 2016-08-15 07:22:18 --> Language Class Initialized
INFO - 2016-08-15 07:22:18 --> Loader Class Initialized
INFO - 2016-08-15 07:22:18 --> Helper loaded: url_helper
INFO - 2016-08-15 07:22:18 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:22:18 --> Helper loaded: html_helper
INFO - 2016-08-15 07:22:18 --> Helper loaded: form_helper
INFO - 2016-08-15 07:22:18 --> Helper loaded: file_helper
INFO - 2016-08-15 07:22:18 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:22:18 --> Database Driver Class Initialized
INFO - 2016-08-15 07:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:22:18 --> Form Validation Class Initialized
INFO - 2016-08-15 07:22:18 --> Email Class Initialized
INFO - 2016-08-15 07:22:18 --> Controller Class Initialized
DEBUG - 2016-08-15 07:22:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:22:18 --> Model Class Initialized
INFO - 2016-08-15 07:22:18 --> Model Class Initialized
ERROR - 2016-08-15 07:22:18 --> Severity: Error --> Function name must be a string D:\wamp\www\library.pnc.lan\application\controllers\BorrowBook.php 25
INFO - 2016-08-15 07:22:45 --> Config Class Initialized
INFO - 2016-08-15 07:22:45 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:22:45 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:22:45 --> Utf8 Class Initialized
INFO - 2016-08-15 07:22:45 --> URI Class Initialized
INFO - 2016-08-15 07:22:45 --> Router Class Initialized
INFO - 2016-08-15 07:22:45 --> Output Class Initialized
INFO - 2016-08-15 07:22:45 --> Security Class Initialized
DEBUG - 2016-08-15 07:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:22:45 --> Input Class Initialized
INFO - 2016-08-15 07:22:45 --> Language Class Initialized
INFO - 2016-08-15 07:22:45 --> Loader Class Initialized
INFO - 2016-08-15 07:22:45 --> Helper loaded: url_helper
INFO - 2016-08-15 07:22:45 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:22:45 --> Helper loaded: html_helper
INFO - 2016-08-15 07:22:45 --> Helper loaded: form_helper
INFO - 2016-08-15 07:22:45 --> Helper loaded: file_helper
INFO - 2016-08-15 07:22:45 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:22:45 --> Database Driver Class Initialized
INFO - 2016-08-15 07:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:22:45 --> Form Validation Class Initialized
INFO - 2016-08-15 07:22:45 --> Email Class Initialized
INFO - 2016-08-15 07:22:46 --> Controller Class Initialized
DEBUG - 2016-08-15 07:22:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:22:46 --> Model Class Initialized
INFO - 2016-08-15 07:22:46 --> Model Class Initialized
ERROR - 2016-08-15 07:22:46 --> Severity: Notice --> Undefined index: com_barcode D:\wamp\www\library.pnc.lan\application\controllers\BorrowBook.php 25
INFO - 2016-08-15 07:22:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:22:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:22:46 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:22:46 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:22:46 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:22:46 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:22:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:22:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:22:46 --> Final output sent to browser
DEBUG - 2016-08-15 07:22:46 --> Total execution time: 0.3504
INFO - 2016-08-15 07:24:48 --> Config Class Initialized
INFO - 2016-08-15 07:24:48 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:24:48 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:24:48 --> Utf8 Class Initialized
INFO - 2016-08-15 07:24:48 --> URI Class Initialized
INFO - 2016-08-15 07:24:48 --> Router Class Initialized
INFO - 2016-08-15 07:24:48 --> Output Class Initialized
INFO - 2016-08-15 07:24:48 --> Security Class Initialized
DEBUG - 2016-08-15 07:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:24:48 --> Input Class Initialized
INFO - 2016-08-15 07:24:48 --> Language Class Initialized
INFO - 2016-08-15 07:24:48 --> Loader Class Initialized
INFO - 2016-08-15 07:24:48 --> Helper loaded: url_helper
INFO - 2016-08-15 07:24:48 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:24:48 --> Helper loaded: html_helper
INFO - 2016-08-15 07:24:48 --> Helper loaded: form_helper
INFO - 2016-08-15 07:24:48 --> Helper loaded: file_helper
INFO - 2016-08-15 07:24:48 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:24:48 --> Database Driver Class Initialized
INFO - 2016-08-15 07:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:24:48 --> Form Validation Class Initialized
INFO - 2016-08-15 07:24:48 --> Email Class Initialized
INFO - 2016-08-15 07:24:48 --> Controller Class Initialized
DEBUG - 2016-08-15 07:24:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:24:48 --> Model Class Initialized
INFO - 2016-08-15 07:24:48 --> Model Class Initialized
INFO - 2016-08-15 07:24:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:24:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:24:48 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:24:48 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:24:48 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:24:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:24:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:24:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:24:48 --> Final output sent to browser
DEBUG - 2016-08-15 07:24:48 --> Total execution time: 0.3615
INFO - 2016-08-15 07:29:06 --> Config Class Initialized
INFO - 2016-08-15 07:29:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:29:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:29:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:29:06 --> URI Class Initialized
INFO - 2016-08-15 07:29:06 --> Router Class Initialized
INFO - 2016-08-15 07:29:06 --> Output Class Initialized
INFO - 2016-08-15 07:29:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:29:06 --> Input Class Initialized
INFO - 2016-08-15 07:29:06 --> Language Class Initialized
INFO - 2016-08-15 07:29:06 --> Loader Class Initialized
INFO - 2016-08-15 07:29:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:29:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:29:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:29:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:29:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:29:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:29:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:29:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:29:06 --> Email Class Initialized
INFO - 2016-08-15 07:29:06 --> Controller Class Initialized
DEBUG - 2016-08-15 07:29:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:29:06 --> Model Class Initialized
INFO - 2016-08-15 07:29:06 --> Model Class Initialized
INFO - 2016-08-15 07:29:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:29:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:29:06 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 37
ERROR - 2016-08-15 07:29:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 37
ERROR - 2016-08-15 07:29:06 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 41
ERROR - 2016-08-15 07:29:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 41
INFO - 2016-08-15 07:29:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:29:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:29:06 --> Final output sent to browser
DEBUG - 2016-08-15 07:29:06 --> Total execution time: 0.3603
INFO - 2016-08-15 07:29:43 --> Config Class Initialized
INFO - 2016-08-15 07:29:43 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:29:43 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:29:43 --> Utf8 Class Initialized
INFO - 2016-08-15 07:29:43 --> URI Class Initialized
INFO - 2016-08-15 07:29:43 --> Router Class Initialized
INFO - 2016-08-15 07:29:43 --> Output Class Initialized
INFO - 2016-08-15 07:29:43 --> Security Class Initialized
DEBUG - 2016-08-15 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:29:43 --> Input Class Initialized
INFO - 2016-08-15 07:29:43 --> Language Class Initialized
INFO - 2016-08-15 07:29:43 --> Loader Class Initialized
INFO - 2016-08-15 07:29:43 --> Helper loaded: url_helper
INFO - 2016-08-15 07:29:43 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:29:43 --> Helper loaded: html_helper
INFO - 2016-08-15 07:29:43 --> Helper loaded: form_helper
INFO - 2016-08-15 07:29:43 --> Helper loaded: file_helper
INFO - 2016-08-15 07:29:43 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:29:43 --> Database Driver Class Initialized
INFO - 2016-08-15 07:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:29:43 --> Form Validation Class Initialized
INFO - 2016-08-15 07:29:43 --> Email Class Initialized
INFO - 2016-08-15 07:29:43 --> Controller Class Initialized
DEBUG - 2016-08-15 07:29:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:29:43 --> Model Class Initialized
INFO - 2016-08-15 07:29:43 --> Model Class Initialized
INFO - 2016-08-15 07:29:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:29:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:29:43 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 39
ERROR - 2016-08-15 07:29:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 39
ERROR - 2016-08-15 07:29:43 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 44
ERROR - 2016-08-15 07:29:43 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 44
INFO - 2016-08-15 07:29:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:29:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:29:43 --> Final output sent to browser
DEBUG - 2016-08-15 07:29:43 --> Total execution time: 0.3341
INFO - 2016-08-15 07:29:47 --> Config Class Initialized
INFO - 2016-08-15 07:29:47 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:29:47 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:29:47 --> Utf8 Class Initialized
INFO - 2016-08-15 07:29:47 --> URI Class Initialized
INFO - 2016-08-15 07:29:47 --> Router Class Initialized
INFO - 2016-08-15 07:29:47 --> Output Class Initialized
INFO - 2016-08-15 07:29:47 --> Security Class Initialized
DEBUG - 2016-08-15 07:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:29:47 --> Input Class Initialized
INFO - 2016-08-15 07:29:47 --> Language Class Initialized
INFO - 2016-08-15 07:29:47 --> Loader Class Initialized
INFO - 2016-08-15 07:29:47 --> Helper loaded: url_helper
INFO - 2016-08-15 07:29:47 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:29:47 --> Helper loaded: html_helper
INFO - 2016-08-15 07:29:47 --> Helper loaded: form_helper
INFO - 2016-08-15 07:29:47 --> Helper loaded: file_helper
INFO - 2016-08-15 07:29:47 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:29:47 --> Database Driver Class Initialized
INFO - 2016-08-15 07:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:29:47 --> Form Validation Class Initialized
INFO - 2016-08-15 07:29:47 --> Email Class Initialized
INFO - 2016-08-15 07:29:47 --> Controller Class Initialized
DEBUG - 2016-08-15 07:29:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:29:47 --> Model Class Initialized
INFO - 2016-08-15 07:29:47 --> Model Class Initialized
INFO - 2016-08-15 07:29:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:29:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:29:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:29:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:29:47 --> Final output sent to browser
DEBUG - 2016-08-15 07:29:48 --> Total execution time: 0.2990
INFO - 2016-08-15 07:29:54 --> Config Class Initialized
INFO - 2016-08-15 07:29:54 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:29:55 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:29:55 --> Utf8 Class Initialized
INFO - 2016-08-15 07:29:55 --> URI Class Initialized
INFO - 2016-08-15 07:29:55 --> Router Class Initialized
INFO - 2016-08-15 07:29:55 --> Output Class Initialized
INFO - 2016-08-15 07:29:55 --> Security Class Initialized
DEBUG - 2016-08-15 07:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:29:55 --> Input Class Initialized
INFO - 2016-08-15 07:29:55 --> Language Class Initialized
INFO - 2016-08-15 07:29:55 --> Loader Class Initialized
INFO - 2016-08-15 07:29:55 --> Helper loaded: url_helper
INFO - 2016-08-15 07:29:55 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:29:55 --> Helper loaded: html_helper
INFO - 2016-08-15 07:29:55 --> Helper loaded: form_helper
INFO - 2016-08-15 07:29:55 --> Helper loaded: file_helper
INFO - 2016-08-15 07:29:55 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:29:55 --> Database Driver Class Initialized
INFO - 2016-08-15 07:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:29:55 --> Form Validation Class Initialized
INFO - 2016-08-15 07:29:55 --> Email Class Initialized
INFO - 2016-08-15 07:29:55 --> Controller Class Initialized
DEBUG - 2016-08-15 07:29:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:29:55 --> Model Class Initialized
INFO - 2016-08-15 07:29:55 --> Model Class Initialized
INFO - 2016-08-15 07:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:29:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:29:55 --> Final output sent to browser
DEBUG - 2016-08-15 07:29:55 --> Total execution time: 0.2995
INFO - 2016-08-15 07:30:57 --> Config Class Initialized
INFO - 2016-08-15 07:30:57 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:30:57 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:30:57 --> Utf8 Class Initialized
INFO - 2016-08-15 07:30:57 --> URI Class Initialized
INFO - 2016-08-15 07:30:57 --> Router Class Initialized
INFO - 2016-08-15 07:30:57 --> Output Class Initialized
INFO - 2016-08-15 07:30:57 --> Security Class Initialized
DEBUG - 2016-08-15 07:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:30:57 --> Input Class Initialized
INFO - 2016-08-15 07:30:57 --> Language Class Initialized
INFO - 2016-08-15 07:30:57 --> Loader Class Initialized
INFO - 2016-08-15 07:30:57 --> Helper loaded: url_helper
INFO - 2016-08-15 07:30:57 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:30:57 --> Helper loaded: html_helper
INFO - 2016-08-15 07:30:57 --> Helper loaded: form_helper
INFO - 2016-08-15 07:30:57 --> Helper loaded: file_helper
INFO - 2016-08-15 07:30:57 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:30:57 --> Database Driver Class Initialized
INFO - 2016-08-15 07:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:30:57 --> Form Validation Class Initialized
INFO - 2016-08-15 07:30:57 --> Email Class Initialized
INFO - 2016-08-15 07:30:57 --> Controller Class Initialized
DEBUG - 2016-08-15 07:30:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:30:57 --> Model Class Initialized
INFO - 2016-08-15 07:30:57 --> Model Class Initialized
INFO - 2016-08-15 07:30:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:30:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:30:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:30:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:30:57 --> Final output sent to browser
DEBUG - 2016-08-15 07:30:57 --> Total execution time: 0.3030
INFO - 2016-08-15 07:31:02 --> Config Class Initialized
INFO - 2016-08-15 07:31:02 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:31:02 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:31:02 --> Utf8 Class Initialized
INFO - 2016-08-15 07:31:02 --> URI Class Initialized
INFO - 2016-08-15 07:31:02 --> Router Class Initialized
INFO - 2016-08-15 07:31:02 --> Output Class Initialized
INFO - 2016-08-15 07:31:02 --> Security Class Initialized
DEBUG - 2016-08-15 07:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:31:02 --> Input Class Initialized
INFO - 2016-08-15 07:31:02 --> Language Class Initialized
INFO - 2016-08-15 07:31:02 --> Loader Class Initialized
INFO - 2016-08-15 07:31:02 --> Helper loaded: url_helper
INFO - 2016-08-15 07:31:02 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:31:02 --> Helper loaded: html_helper
INFO - 2016-08-15 07:31:02 --> Helper loaded: form_helper
INFO - 2016-08-15 07:31:02 --> Helper loaded: file_helper
INFO - 2016-08-15 07:31:02 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:31:02 --> Database Driver Class Initialized
INFO - 2016-08-15 07:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:31:02 --> Form Validation Class Initialized
INFO - 2016-08-15 07:31:02 --> Email Class Initialized
INFO - 2016-08-15 07:31:02 --> Controller Class Initialized
DEBUG - 2016-08-15 07:31:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:31:02 --> Model Class Initialized
INFO - 2016-08-15 07:31:02 --> Model Class Initialized
INFO - 2016-08-15 07:31:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:31:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:31:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:31:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:31:02 --> Final output sent to browser
DEBUG - 2016-08-15 07:31:02 --> Total execution time: 0.3019
INFO - 2016-08-15 07:31:09 --> Config Class Initialized
INFO - 2016-08-15 07:31:09 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:31:09 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:31:09 --> Utf8 Class Initialized
INFO - 2016-08-15 07:31:09 --> URI Class Initialized
INFO - 2016-08-15 07:31:09 --> Router Class Initialized
INFO - 2016-08-15 07:31:09 --> Output Class Initialized
INFO - 2016-08-15 07:31:09 --> Security Class Initialized
DEBUG - 2016-08-15 07:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:31:09 --> Input Class Initialized
INFO - 2016-08-15 07:31:09 --> Language Class Initialized
INFO - 2016-08-15 07:31:09 --> Loader Class Initialized
INFO - 2016-08-15 07:31:10 --> Helper loaded: url_helper
INFO - 2016-08-15 07:31:10 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:31:10 --> Helper loaded: html_helper
INFO - 2016-08-15 07:31:10 --> Helper loaded: form_helper
INFO - 2016-08-15 07:31:10 --> Helper loaded: file_helper
INFO - 2016-08-15 07:31:10 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:31:10 --> Database Driver Class Initialized
INFO - 2016-08-15 07:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:31:10 --> Form Validation Class Initialized
INFO - 2016-08-15 07:31:10 --> Email Class Initialized
INFO - 2016-08-15 07:31:10 --> Controller Class Initialized
DEBUG - 2016-08-15 07:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:31:10 --> Model Class Initialized
INFO - 2016-08-15 07:31:10 --> Model Class Initialized
INFO - 2016-08-15 07:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:31:10 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:31:10 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:31:10 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:31:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:31:10 --> Final output sent to browser
DEBUG - 2016-08-15 07:31:10 --> Total execution time: 0.3733
INFO - 2016-08-15 07:31:12 --> Config Class Initialized
INFO - 2016-08-15 07:31:12 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:31:12 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:31:12 --> Utf8 Class Initialized
INFO - 2016-08-15 07:31:12 --> URI Class Initialized
INFO - 2016-08-15 07:31:12 --> Router Class Initialized
INFO - 2016-08-15 07:31:12 --> Output Class Initialized
INFO - 2016-08-15 07:31:12 --> Security Class Initialized
DEBUG - 2016-08-15 07:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:31:12 --> Input Class Initialized
INFO - 2016-08-15 07:31:12 --> Language Class Initialized
INFO - 2016-08-15 07:31:12 --> Loader Class Initialized
INFO - 2016-08-15 07:31:12 --> Helper loaded: url_helper
INFO - 2016-08-15 07:31:12 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:31:12 --> Helper loaded: html_helper
INFO - 2016-08-15 07:31:12 --> Helper loaded: form_helper
INFO - 2016-08-15 07:31:12 --> Helper loaded: file_helper
INFO - 2016-08-15 07:31:13 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:31:13 --> Database Driver Class Initialized
INFO - 2016-08-15 07:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:31:13 --> Form Validation Class Initialized
INFO - 2016-08-15 07:31:13 --> Email Class Initialized
INFO - 2016-08-15 07:31:13 --> Controller Class Initialized
DEBUG - 2016-08-15 07:31:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:31:13 --> Model Class Initialized
INFO - 2016-08-15 07:31:13 --> Model Class Initialized
INFO - 2016-08-15 07:31:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:31:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:31:13 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:31:13 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 34
ERROR - 2016-08-15 07:31:13 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:31:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:31:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:31:13 --> Final output sent to browser
DEBUG - 2016-08-15 07:31:13 --> Total execution time: 0.3554
INFO - 2016-08-15 07:33:00 --> Config Class Initialized
INFO - 2016-08-15 07:33:00 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:33:00 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:33:00 --> Utf8 Class Initialized
INFO - 2016-08-15 07:33:00 --> URI Class Initialized
INFO - 2016-08-15 07:33:00 --> Router Class Initialized
INFO - 2016-08-15 07:33:00 --> Output Class Initialized
INFO - 2016-08-15 07:33:00 --> Security Class Initialized
DEBUG - 2016-08-15 07:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:33:00 --> Input Class Initialized
INFO - 2016-08-15 07:33:00 --> Language Class Initialized
INFO - 2016-08-15 07:33:00 --> Loader Class Initialized
INFO - 2016-08-15 07:33:00 --> Helper loaded: url_helper
INFO - 2016-08-15 07:33:00 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:33:00 --> Helper loaded: html_helper
INFO - 2016-08-15 07:33:00 --> Helper loaded: form_helper
INFO - 2016-08-15 07:33:00 --> Helper loaded: file_helper
INFO - 2016-08-15 07:33:00 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:33:00 --> Database Driver Class Initialized
INFO - 2016-08-15 07:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:33:00 --> Form Validation Class Initialized
INFO - 2016-08-15 07:33:00 --> Email Class Initialized
INFO - 2016-08-15 07:33:00 --> Controller Class Initialized
DEBUG - 2016-08-15 07:33:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:33:00 --> Model Class Initialized
INFO - 2016-08-15 07:33:00 --> Model Class Initialized
INFO - 2016-08-15 07:33:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:33:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:33:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:33:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:33:00 --> Final output sent to browser
DEBUG - 2016-08-15 07:33:00 --> Total execution time: 0.3113
INFO - 2016-08-15 07:33:02 --> Config Class Initialized
INFO - 2016-08-15 07:33:02 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:33:02 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:33:02 --> Utf8 Class Initialized
INFO - 2016-08-15 07:33:02 --> URI Class Initialized
INFO - 2016-08-15 07:33:02 --> Router Class Initialized
INFO - 2016-08-15 07:33:02 --> Output Class Initialized
INFO - 2016-08-15 07:33:02 --> Security Class Initialized
DEBUG - 2016-08-15 07:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:33:02 --> Input Class Initialized
INFO - 2016-08-15 07:33:02 --> Language Class Initialized
INFO - 2016-08-15 07:33:02 --> Loader Class Initialized
INFO - 2016-08-15 07:33:02 --> Helper loaded: url_helper
INFO - 2016-08-15 07:33:02 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:33:02 --> Helper loaded: html_helper
INFO - 2016-08-15 07:33:02 --> Helper loaded: form_helper
INFO - 2016-08-15 07:33:02 --> Helper loaded: file_helper
INFO - 2016-08-15 07:33:02 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:33:02 --> Database Driver Class Initialized
INFO - 2016-08-15 07:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:33:02 --> Form Validation Class Initialized
INFO - 2016-08-15 07:33:02 --> Email Class Initialized
INFO - 2016-08-15 07:33:02 --> Controller Class Initialized
DEBUG - 2016-08-15 07:33:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:33:02 --> Model Class Initialized
INFO - 2016-08-15 07:33:02 --> Model Class Initialized
INFO - 2016-08-15 07:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:33:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:33:02 --> Final output sent to browser
DEBUG - 2016-08-15 07:33:02 --> Total execution time: 0.3154
INFO - 2016-08-15 07:33:16 --> Config Class Initialized
INFO - 2016-08-15 07:33:16 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:33:16 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:33:16 --> Utf8 Class Initialized
INFO - 2016-08-15 07:33:16 --> URI Class Initialized
INFO - 2016-08-15 07:33:16 --> Router Class Initialized
INFO - 2016-08-15 07:33:16 --> Output Class Initialized
INFO - 2016-08-15 07:33:16 --> Security Class Initialized
DEBUG - 2016-08-15 07:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:33:16 --> Input Class Initialized
INFO - 2016-08-15 07:33:16 --> Language Class Initialized
INFO - 2016-08-15 07:33:16 --> Loader Class Initialized
INFO - 2016-08-15 07:33:16 --> Helper loaded: url_helper
INFO - 2016-08-15 07:33:16 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:33:16 --> Helper loaded: html_helper
INFO - 2016-08-15 07:33:16 --> Helper loaded: form_helper
INFO - 2016-08-15 07:33:16 --> Helper loaded: file_helper
INFO - 2016-08-15 07:33:16 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:33:16 --> Database Driver Class Initialized
INFO - 2016-08-15 07:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:33:16 --> Form Validation Class Initialized
INFO - 2016-08-15 07:33:16 --> Email Class Initialized
INFO - 2016-08-15 07:33:16 --> Controller Class Initialized
DEBUG - 2016-08-15 07:33:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:33:16 --> Model Class Initialized
INFO - 2016-08-15 07:33:16 --> Model Class Initialized
INFO - 2016-08-15 07:33:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:33:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:33:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-15 07:33:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:33:16 --> Final output sent to browser
DEBUG - 2016-08-15 07:33:16 --> Total execution time: 0.3093
INFO - 2016-08-15 07:33:23 --> Config Class Initialized
INFO - 2016-08-15 07:33:23 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:33:23 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:33:23 --> Utf8 Class Initialized
INFO - 2016-08-15 07:33:23 --> URI Class Initialized
INFO - 2016-08-15 07:33:23 --> Router Class Initialized
INFO - 2016-08-15 07:33:23 --> Output Class Initialized
INFO - 2016-08-15 07:33:23 --> Security Class Initialized
DEBUG - 2016-08-15 07:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:33:23 --> Input Class Initialized
INFO - 2016-08-15 07:33:23 --> Language Class Initialized
INFO - 2016-08-15 07:33:23 --> Loader Class Initialized
INFO - 2016-08-15 07:33:23 --> Helper loaded: url_helper
INFO - 2016-08-15 07:33:23 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:33:23 --> Helper loaded: html_helper
INFO - 2016-08-15 07:33:23 --> Helper loaded: form_helper
INFO - 2016-08-15 07:33:23 --> Helper loaded: file_helper
INFO - 2016-08-15 07:33:23 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:33:23 --> Database Driver Class Initialized
INFO - 2016-08-15 07:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:33:23 --> Form Validation Class Initialized
INFO - 2016-08-15 07:33:23 --> Email Class Initialized
INFO - 2016-08-15 07:33:23 --> Controller Class Initialized
DEBUG - 2016-08-15 07:33:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:33:23 --> Model Class Initialized
INFO - 2016-08-15 07:33:23 --> Model Class Initialized
INFO - 2016-08-15 07:33:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:33:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:33:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:33:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:33:23 --> Final output sent to browser
DEBUG - 2016-08-15 07:33:23 --> Total execution time: 0.3312
INFO - 2016-08-15 07:34:35 --> Config Class Initialized
INFO - 2016-08-15 07:34:35 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:34:35 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:34:35 --> Utf8 Class Initialized
INFO - 2016-08-15 07:34:35 --> URI Class Initialized
INFO - 2016-08-15 07:34:35 --> Router Class Initialized
INFO - 2016-08-15 07:34:35 --> Output Class Initialized
INFO - 2016-08-15 07:34:35 --> Security Class Initialized
DEBUG - 2016-08-15 07:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:34:35 --> Input Class Initialized
INFO - 2016-08-15 07:34:35 --> Language Class Initialized
INFO - 2016-08-15 07:34:35 --> Loader Class Initialized
INFO - 2016-08-15 07:34:35 --> Helper loaded: url_helper
INFO - 2016-08-15 07:34:35 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:34:35 --> Helper loaded: html_helper
INFO - 2016-08-15 07:34:35 --> Helper loaded: form_helper
INFO - 2016-08-15 07:34:35 --> Helper loaded: file_helper
INFO - 2016-08-15 07:34:35 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:34:35 --> Database Driver Class Initialized
INFO - 2016-08-15 07:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:34:35 --> Form Validation Class Initialized
INFO - 2016-08-15 07:34:35 --> Email Class Initialized
INFO - 2016-08-15 07:34:35 --> Controller Class Initialized
DEBUG - 2016-08-15 07:34:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:34:35 --> Model Class Initialized
INFO - 2016-08-15 07:34:35 --> Model Class Initialized
INFO - 2016-08-15 07:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:34:35 --> Final output sent to browser
DEBUG - 2016-08-15 07:34:35 --> Total execution time: 0.3069
INFO - 2016-08-15 07:34:38 --> Config Class Initialized
INFO - 2016-08-15 07:34:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:34:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:34:38 --> Utf8 Class Initialized
INFO - 2016-08-15 07:34:38 --> URI Class Initialized
INFO - 2016-08-15 07:34:38 --> Router Class Initialized
INFO - 2016-08-15 07:34:38 --> Output Class Initialized
INFO - 2016-08-15 07:34:38 --> Security Class Initialized
DEBUG - 2016-08-15 07:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:34:38 --> Input Class Initialized
INFO - 2016-08-15 07:34:38 --> Language Class Initialized
INFO - 2016-08-15 07:34:38 --> Loader Class Initialized
INFO - 2016-08-15 07:34:38 --> Helper loaded: url_helper
INFO - 2016-08-15 07:34:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:34:38 --> Helper loaded: html_helper
INFO - 2016-08-15 07:34:38 --> Helper loaded: form_helper
INFO - 2016-08-15 07:34:38 --> Helper loaded: file_helper
INFO - 2016-08-15 07:34:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:34:38 --> Database Driver Class Initialized
INFO - 2016-08-15 07:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:34:38 --> Form Validation Class Initialized
INFO - 2016-08-15 07:34:38 --> Email Class Initialized
INFO - 2016-08-15 07:34:38 --> Controller Class Initialized
DEBUG - 2016-08-15 07:34:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:34:38 --> Model Class Initialized
INFO - 2016-08-15 07:34:38 --> Model Class Initialized
INFO - 2016-08-15 07:34:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:34:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:34:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:34:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:34:38 --> Final output sent to browser
DEBUG - 2016-08-15 07:34:38 --> Total execution time: 0.3395
INFO - 2016-08-15 07:36:01 --> Config Class Initialized
INFO - 2016-08-15 07:36:01 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:01 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:01 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:01 --> URI Class Initialized
INFO - 2016-08-15 07:36:02 --> Router Class Initialized
INFO - 2016-08-15 07:36:02 --> Output Class Initialized
INFO - 2016-08-15 07:36:02 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:02 --> Input Class Initialized
INFO - 2016-08-15 07:36:02 --> Language Class Initialized
INFO - 2016-08-15 07:36:02 --> Loader Class Initialized
INFO - 2016-08-15 07:36:02 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:02 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:02 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:02 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:02 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:02 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:02 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:02 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:02 --> Email Class Initialized
INFO - 2016-08-15 07:36:02 --> Controller Class Initialized
DEBUG - 2016-08-15 07:36:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:36:02 --> Model Class Initialized
INFO - 2016-08-15 07:36:02 --> Model Class Initialized
INFO - 2016-08-15 07:36:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:36:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:36:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:36:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:36:02 --> Final output sent to browser
DEBUG - 2016-08-15 07:36:02 --> Total execution time: 0.3109
INFO - 2016-08-15 07:36:06 --> Config Class Initialized
INFO - 2016-08-15 07:36:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:06 --> URI Class Initialized
INFO - 2016-08-15 07:36:06 --> Router Class Initialized
INFO - 2016-08-15 07:36:06 --> Output Class Initialized
INFO - 2016-08-15 07:36:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:06 --> Input Class Initialized
INFO - 2016-08-15 07:36:06 --> Language Class Initialized
INFO - 2016-08-15 07:36:06 --> Loader Class Initialized
INFO - 2016-08-15 07:36:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:06 --> Email Class Initialized
INFO - 2016-08-15 07:36:06 --> Controller Class Initialized
INFO - 2016-08-15 07:36:06 --> Config Class Initialized
INFO - 2016-08-15 07:36:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:06 --> URI Class Initialized
INFO - 2016-08-15 07:36:06 --> Router Class Initialized
INFO - 2016-08-15 07:36:06 --> Output Class Initialized
INFO - 2016-08-15 07:36:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:06 --> Input Class Initialized
INFO - 2016-08-15 07:36:06 --> Language Class Initialized
INFO - 2016-08-15 07:36:06 --> Loader Class Initialized
INFO - 2016-08-15 07:36:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:06 --> Email Class Initialized
INFO - 2016-08-15 07:36:06 --> Controller Class Initialized
INFO - 2016-08-15 07:36:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:36:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:36:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 07:36:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:36:06 --> Final output sent to browser
DEBUG - 2016-08-15 07:36:06 --> Total execution time: 0.2820
INFO - 2016-08-15 07:36:11 --> Config Class Initialized
INFO - 2016-08-15 07:36:11 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:11 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:11 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:11 --> URI Class Initialized
INFO - 2016-08-15 07:36:11 --> Router Class Initialized
INFO - 2016-08-15 07:36:11 --> Output Class Initialized
INFO - 2016-08-15 07:36:11 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:11 --> Input Class Initialized
INFO - 2016-08-15 07:36:11 --> Language Class Initialized
INFO - 2016-08-15 07:36:11 --> Loader Class Initialized
INFO - 2016-08-15 07:36:11 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:11 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:11 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:11 --> Email Class Initialized
INFO - 2016-08-15 07:36:11 --> Controller Class Initialized
INFO - 2016-08-15 07:36:11 --> Config Class Initialized
INFO - 2016-08-15 07:36:11 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:11 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:11 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:11 --> URI Class Initialized
INFO - 2016-08-15 07:36:11 --> Router Class Initialized
INFO - 2016-08-15 07:36:11 --> Output Class Initialized
INFO - 2016-08-15 07:36:11 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:11 --> Input Class Initialized
INFO - 2016-08-15 07:36:11 --> Language Class Initialized
INFO - 2016-08-15 07:36:11 --> Loader Class Initialized
INFO - 2016-08-15 07:36:11 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:11 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:11 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:11 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:11 --> Email Class Initialized
INFO - 2016-08-15 07:36:11 --> Controller Class Initialized
INFO - 2016-08-15 07:36:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:36:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:36:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 07:36:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:36:11 --> Final output sent to browser
DEBUG - 2016-08-15 07:36:11 --> Total execution time: 0.2845
INFO - 2016-08-15 07:36:16 --> Config Class Initialized
INFO - 2016-08-15 07:36:16 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:16 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:16 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:16 --> URI Class Initialized
INFO - 2016-08-15 07:36:16 --> Router Class Initialized
INFO - 2016-08-15 07:36:16 --> Output Class Initialized
INFO - 2016-08-15 07:36:16 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:16 --> Input Class Initialized
INFO - 2016-08-15 07:36:16 --> Language Class Initialized
INFO - 2016-08-15 07:36:16 --> Loader Class Initialized
INFO - 2016-08-15 07:36:16 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:16 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:16 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:16 --> Email Class Initialized
INFO - 2016-08-15 07:36:16 --> Controller Class Initialized
INFO - 2016-08-15 07:36:16 --> Config Class Initialized
INFO - 2016-08-15 07:36:16 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:16 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:16 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:16 --> URI Class Initialized
INFO - 2016-08-15 07:36:16 --> Router Class Initialized
INFO - 2016-08-15 07:36:16 --> Output Class Initialized
INFO - 2016-08-15 07:36:16 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:16 --> Input Class Initialized
INFO - 2016-08-15 07:36:16 --> Language Class Initialized
INFO - 2016-08-15 07:36:16 --> Loader Class Initialized
INFO - 2016-08-15 07:36:16 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:16 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:16 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:17 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:17 --> Email Class Initialized
INFO - 2016-08-15 07:36:17 --> Controller Class Initialized
INFO - 2016-08-15 07:36:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:36:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:36:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 07:36:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:36:17 --> Final output sent to browser
DEBUG - 2016-08-15 07:36:17 --> Total execution time: 0.2871
INFO - 2016-08-15 07:36:18 --> Config Class Initialized
INFO - 2016-08-15 07:36:18 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:36:18 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:36:18 --> Utf8 Class Initialized
INFO - 2016-08-15 07:36:18 --> URI Class Initialized
INFO - 2016-08-15 07:36:18 --> Router Class Initialized
INFO - 2016-08-15 07:36:18 --> Output Class Initialized
INFO - 2016-08-15 07:36:18 --> Security Class Initialized
DEBUG - 2016-08-15 07:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:36:18 --> Input Class Initialized
INFO - 2016-08-15 07:36:18 --> Language Class Initialized
INFO - 2016-08-15 07:36:18 --> Loader Class Initialized
INFO - 2016-08-15 07:36:18 --> Helper loaded: url_helper
INFO - 2016-08-15 07:36:18 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:36:18 --> Helper loaded: html_helper
INFO - 2016-08-15 07:36:18 --> Helper loaded: form_helper
INFO - 2016-08-15 07:36:18 --> Helper loaded: file_helper
INFO - 2016-08-15 07:36:18 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:36:18 --> Database Driver Class Initialized
INFO - 2016-08-15 07:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:36:18 --> Form Validation Class Initialized
INFO - 2016-08-15 07:36:19 --> Email Class Initialized
INFO - 2016-08-15 07:36:19 --> Controller Class Initialized
DEBUG - 2016-08-15 07:36:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:36:19 --> Model Class Initialized
INFO - 2016-08-15 07:36:19 --> Model Class Initialized
INFO - 2016-08-15 07:36:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:36:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:36:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:36:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:36:19 --> Final output sent to browser
DEBUG - 2016-08-15 07:36:19 --> Total execution time: 0.3515
INFO - 2016-08-15 07:37:20 --> Config Class Initialized
INFO - 2016-08-15 07:37:20 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:37:20 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:37:20 --> Utf8 Class Initialized
INFO - 2016-08-15 07:37:20 --> URI Class Initialized
INFO - 2016-08-15 07:37:20 --> Router Class Initialized
INFO - 2016-08-15 07:37:20 --> Output Class Initialized
INFO - 2016-08-15 07:37:20 --> Security Class Initialized
DEBUG - 2016-08-15 07:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:37:20 --> Input Class Initialized
INFO - 2016-08-15 07:37:20 --> Language Class Initialized
INFO - 2016-08-15 07:37:20 --> Loader Class Initialized
INFO - 2016-08-15 07:37:20 --> Helper loaded: url_helper
INFO - 2016-08-15 07:37:20 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:37:20 --> Helper loaded: html_helper
INFO - 2016-08-15 07:37:20 --> Helper loaded: form_helper
INFO - 2016-08-15 07:37:20 --> Helper loaded: file_helper
INFO - 2016-08-15 07:37:20 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:37:20 --> Database Driver Class Initialized
INFO - 2016-08-15 07:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:37:20 --> Form Validation Class Initialized
INFO - 2016-08-15 07:37:20 --> Email Class Initialized
INFO - 2016-08-15 07:37:20 --> Controller Class Initialized
DEBUG - 2016-08-15 07:37:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:37:20 --> Model Class Initialized
INFO - 2016-08-15 07:37:20 --> Model Class Initialized
INFO - 2016-08-15 07:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:37:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:37:20 --> Final output sent to browser
DEBUG - 2016-08-15 07:37:20 --> Total execution time: 0.3333
INFO - 2016-08-15 07:37:32 --> Config Class Initialized
INFO - 2016-08-15 07:37:32 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:37:32 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:37:32 --> Utf8 Class Initialized
INFO - 2016-08-15 07:37:32 --> URI Class Initialized
INFO - 2016-08-15 07:37:32 --> Router Class Initialized
INFO - 2016-08-15 07:37:32 --> Output Class Initialized
INFO - 2016-08-15 07:37:32 --> Security Class Initialized
DEBUG - 2016-08-15 07:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:37:32 --> Input Class Initialized
INFO - 2016-08-15 07:37:33 --> Language Class Initialized
INFO - 2016-08-15 07:37:33 --> Loader Class Initialized
INFO - 2016-08-15 07:37:33 --> Helper loaded: url_helper
INFO - 2016-08-15 07:37:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:37:33 --> Helper loaded: html_helper
INFO - 2016-08-15 07:37:33 --> Helper loaded: form_helper
INFO - 2016-08-15 07:37:33 --> Helper loaded: file_helper
INFO - 2016-08-15 07:37:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:37:33 --> Database Driver Class Initialized
INFO - 2016-08-15 07:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:37:33 --> Form Validation Class Initialized
INFO - 2016-08-15 07:37:33 --> Email Class Initialized
INFO - 2016-08-15 07:37:33 --> Controller Class Initialized
DEBUG - 2016-08-15 07:37:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:37:33 --> Model Class Initialized
INFO - 2016-08-15 07:37:33 --> Model Class Initialized
INFO - 2016-08-15 07:37:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:37:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:37:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:37:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:37:33 --> Final output sent to browser
DEBUG - 2016-08-15 07:37:33 --> Total execution time: 0.3372
INFO - 2016-08-15 07:37:38 --> Config Class Initialized
INFO - 2016-08-15 07:37:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:37:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:37:38 --> Utf8 Class Initialized
INFO - 2016-08-15 07:37:38 --> URI Class Initialized
INFO - 2016-08-15 07:37:38 --> Router Class Initialized
INFO - 2016-08-15 07:37:38 --> Output Class Initialized
INFO - 2016-08-15 07:37:38 --> Security Class Initialized
DEBUG - 2016-08-15 07:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:37:38 --> Input Class Initialized
INFO - 2016-08-15 07:37:38 --> Language Class Initialized
INFO - 2016-08-15 07:37:38 --> Loader Class Initialized
INFO - 2016-08-15 07:37:38 --> Helper loaded: url_helper
INFO - 2016-08-15 07:37:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:37:38 --> Helper loaded: html_helper
INFO - 2016-08-15 07:37:38 --> Helper loaded: form_helper
INFO - 2016-08-15 07:37:38 --> Helper loaded: file_helper
INFO - 2016-08-15 07:37:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:37:38 --> Database Driver Class Initialized
INFO - 2016-08-15 07:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:37:38 --> Form Validation Class Initialized
INFO - 2016-08-15 07:37:38 --> Email Class Initialized
INFO - 2016-08-15 07:37:38 --> Controller Class Initialized
DEBUG - 2016-08-15 07:37:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:37:38 --> Model Class Initialized
INFO - 2016-08-15 07:37:38 --> Model Class Initialized
INFO - 2016-08-15 07:37:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:37:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:37:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:37:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:37:39 --> Final output sent to browser
DEBUG - 2016-08-15 07:37:39 --> Total execution time: 0.3378
INFO - 2016-08-15 07:38:18 --> Config Class Initialized
INFO - 2016-08-15 07:38:18 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:38:18 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:38:18 --> Utf8 Class Initialized
INFO - 2016-08-15 07:38:18 --> URI Class Initialized
INFO - 2016-08-15 07:38:18 --> Router Class Initialized
INFO - 2016-08-15 07:38:18 --> Output Class Initialized
INFO - 2016-08-15 07:38:18 --> Security Class Initialized
DEBUG - 2016-08-15 07:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:38:18 --> Input Class Initialized
INFO - 2016-08-15 07:38:18 --> Language Class Initialized
INFO - 2016-08-15 07:38:18 --> Loader Class Initialized
INFO - 2016-08-15 07:38:18 --> Helper loaded: url_helper
INFO - 2016-08-15 07:38:18 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:38:18 --> Helper loaded: html_helper
INFO - 2016-08-15 07:38:18 --> Helper loaded: form_helper
INFO - 2016-08-15 07:38:18 --> Helper loaded: file_helper
INFO - 2016-08-15 07:38:18 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:38:18 --> Database Driver Class Initialized
INFO - 2016-08-15 07:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:38:18 --> Form Validation Class Initialized
INFO - 2016-08-15 07:38:18 --> Email Class Initialized
INFO - 2016-08-15 07:38:18 --> Controller Class Initialized
DEBUG - 2016-08-15 07:38:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:38:18 --> Model Class Initialized
INFO - 2016-08-15 07:38:18 --> Model Class Initialized
INFO - 2016-08-15 07:38:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:38:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:38:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:38:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:38:18 --> Final output sent to browser
DEBUG - 2016-08-15 07:38:18 --> Total execution time: 0.3297
INFO - 2016-08-15 07:38:21 --> Config Class Initialized
INFO - 2016-08-15 07:38:21 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:38:21 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:38:21 --> Utf8 Class Initialized
INFO - 2016-08-15 07:38:21 --> URI Class Initialized
INFO - 2016-08-15 07:38:21 --> Router Class Initialized
INFO - 2016-08-15 07:38:21 --> Output Class Initialized
INFO - 2016-08-15 07:38:21 --> Security Class Initialized
DEBUG - 2016-08-15 07:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:38:21 --> Input Class Initialized
INFO - 2016-08-15 07:38:21 --> Language Class Initialized
INFO - 2016-08-15 07:38:21 --> Loader Class Initialized
INFO - 2016-08-15 07:38:21 --> Helper loaded: url_helper
INFO - 2016-08-15 07:38:21 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:38:21 --> Helper loaded: html_helper
INFO - 2016-08-15 07:38:21 --> Helper loaded: form_helper
INFO - 2016-08-15 07:38:21 --> Helper loaded: file_helper
INFO - 2016-08-15 07:38:21 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:38:21 --> Database Driver Class Initialized
INFO - 2016-08-15 07:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:38:21 --> Form Validation Class Initialized
INFO - 2016-08-15 07:38:21 --> Email Class Initialized
INFO - 2016-08-15 07:38:21 --> Controller Class Initialized
DEBUG - 2016-08-15 07:38:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:38:21 --> Model Class Initialized
INFO - 2016-08-15 07:38:21 --> Model Class Initialized
INFO - 2016-08-15 07:38:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:38:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:38:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:38:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:38:21 --> Final output sent to browser
DEBUG - 2016-08-15 07:38:21 --> Total execution time: 0.3277
INFO - 2016-08-15 07:38:43 --> Config Class Initialized
INFO - 2016-08-15 07:38:43 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:38:43 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:38:43 --> Utf8 Class Initialized
INFO - 2016-08-15 07:38:43 --> URI Class Initialized
INFO - 2016-08-15 07:38:43 --> Router Class Initialized
INFO - 2016-08-15 07:38:43 --> Output Class Initialized
INFO - 2016-08-15 07:38:43 --> Security Class Initialized
DEBUG - 2016-08-15 07:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:38:43 --> Input Class Initialized
INFO - 2016-08-15 07:38:43 --> Language Class Initialized
INFO - 2016-08-15 07:38:43 --> Loader Class Initialized
INFO - 2016-08-15 07:38:43 --> Helper loaded: url_helper
INFO - 2016-08-15 07:38:43 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:38:43 --> Helper loaded: html_helper
INFO - 2016-08-15 07:38:43 --> Helper loaded: form_helper
INFO - 2016-08-15 07:38:44 --> Helper loaded: file_helper
INFO - 2016-08-15 07:38:44 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:38:44 --> Database Driver Class Initialized
INFO - 2016-08-15 07:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:38:44 --> Form Validation Class Initialized
INFO - 2016-08-15 07:38:44 --> Email Class Initialized
INFO - 2016-08-15 07:38:44 --> Controller Class Initialized
DEBUG - 2016-08-15 07:38:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:38:44 --> Model Class Initialized
INFO - 2016-08-15 07:38:44 --> Model Class Initialized
INFO - 2016-08-15 07:39:06 --> Config Class Initialized
INFO - 2016-08-15 07:39:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:39:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:39:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:39:06 --> URI Class Initialized
INFO - 2016-08-15 07:39:06 --> Router Class Initialized
INFO - 2016-08-15 07:39:06 --> Output Class Initialized
INFO - 2016-08-15 07:39:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:39:06 --> Input Class Initialized
INFO - 2016-08-15 07:39:06 --> Language Class Initialized
INFO - 2016-08-15 07:39:06 --> Loader Class Initialized
INFO - 2016-08-15 07:39:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:39:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:39:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:39:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:39:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:39:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:39:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:39:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:39:06 --> Email Class Initialized
INFO - 2016-08-15 07:39:06 --> Controller Class Initialized
DEBUG - 2016-08-15 07:39:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:39:06 --> Model Class Initialized
INFO - 2016-08-15 07:39:06 --> Model Class Initialized
INFO - 2016-08-15 07:39:20 --> Config Class Initialized
INFO - 2016-08-15 07:39:20 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:39:20 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:39:20 --> Utf8 Class Initialized
INFO - 2016-08-15 07:39:20 --> URI Class Initialized
INFO - 2016-08-15 07:39:20 --> Router Class Initialized
INFO - 2016-08-15 07:39:20 --> Output Class Initialized
INFO - 2016-08-15 07:39:20 --> Security Class Initialized
DEBUG - 2016-08-15 07:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:39:20 --> Input Class Initialized
INFO - 2016-08-15 07:39:20 --> Language Class Initialized
INFO - 2016-08-15 07:39:20 --> Loader Class Initialized
INFO - 2016-08-15 07:39:20 --> Helper loaded: url_helper
INFO - 2016-08-15 07:39:20 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:39:20 --> Helper loaded: html_helper
INFO - 2016-08-15 07:39:20 --> Helper loaded: form_helper
INFO - 2016-08-15 07:39:20 --> Helper loaded: file_helper
INFO - 2016-08-15 07:39:20 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:39:20 --> Database Driver Class Initialized
INFO - 2016-08-15 07:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:39:20 --> Form Validation Class Initialized
INFO - 2016-08-15 07:39:20 --> Email Class Initialized
INFO - 2016-08-15 07:39:20 --> Controller Class Initialized
DEBUG - 2016-08-15 07:39:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:39:20 --> Model Class Initialized
INFO - 2016-08-15 07:39:20 --> Model Class Initialized
INFO - 2016-08-15 07:39:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:39:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:39:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:39:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:39:20 --> Final output sent to browser
DEBUG - 2016-08-15 07:39:20 --> Total execution time: 0.3300
INFO - 2016-08-15 07:40:01 --> Config Class Initialized
INFO - 2016-08-15 07:40:01 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:40:01 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:40:01 --> Utf8 Class Initialized
INFO - 2016-08-15 07:40:01 --> URI Class Initialized
INFO - 2016-08-15 07:40:01 --> Router Class Initialized
INFO - 2016-08-15 07:40:01 --> Output Class Initialized
INFO - 2016-08-15 07:40:01 --> Security Class Initialized
DEBUG - 2016-08-15 07:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:40:01 --> Input Class Initialized
INFO - 2016-08-15 07:40:01 --> Language Class Initialized
INFO - 2016-08-15 07:40:01 --> Loader Class Initialized
INFO - 2016-08-15 07:40:01 --> Helper loaded: url_helper
INFO - 2016-08-15 07:40:01 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:40:01 --> Helper loaded: html_helper
INFO - 2016-08-15 07:40:01 --> Helper loaded: form_helper
INFO - 2016-08-15 07:40:01 --> Helper loaded: file_helper
INFO - 2016-08-15 07:40:01 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:40:01 --> Database Driver Class Initialized
INFO - 2016-08-15 07:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:40:02 --> Form Validation Class Initialized
INFO - 2016-08-15 07:40:02 --> Email Class Initialized
INFO - 2016-08-15 07:40:02 --> Controller Class Initialized
DEBUG - 2016-08-15 07:40:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:40:02 --> Model Class Initialized
INFO - 2016-08-15 07:40:02 --> Model Class Initialized
INFO - 2016-08-15 07:40:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:40:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:40:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:40:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:40:02 --> Final output sent to browser
DEBUG - 2016-08-15 07:40:02 --> Total execution time: 0.3572
INFO - 2016-08-15 07:41:10 --> Config Class Initialized
INFO - 2016-08-15 07:41:10 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:41:10 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:41:10 --> Utf8 Class Initialized
INFO - 2016-08-15 07:41:10 --> URI Class Initialized
INFO - 2016-08-15 07:41:10 --> Router Class Initialized
INFO - 2016-08-15 07:41:10 --> Output Class Initialized
INFO - 2016-08-15 07:41:10 --> Security Class Initialized
DEBUG - 2016-08-15 07:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:41:10 --> Input Class Initialized
INFO - 2016-08-15 07:41:10 --> Language Class Initialized
INFO - 2016-08-15 07:41:10 --> Loader Class Initialized
INFO - 2016-08-15 07:41:10 --> Helper loaded: url_helper
INFO - 2016-08-15 07:41:10 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:41:10 --> Helper loaded: html_helper
INFO - 2016-08-15 07:41:10 --> Helper loaded: form_helper
INFO - 2016-08-15 07:41:10 --> Helper loaded: file_helper
INFO - 2016-08-15 07:41:10 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:41:10 --> Database Driver Class Initialized
INFO - 2016-08-15 07:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:41:10 --> Form Validation Class Initialized
INFO - 2016-08-15 07:41:10 --> Email Class Initialized
INFO - 2016-08-15 07:41:10 --> Controller Class Initialized
DEBUG - 2016-08-15 07:41:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:41:10 --> Model Class Initialized
INFO - 2016-08-15 07:41:10 --> Model Class Initialized
INFO - 2016-08-15 07:41:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:41:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:41:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:41:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:41:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:41:11 --> Final output sent to browser
DEBUG - 2016-08-15 07:41:11 --> Total execution time: 0.3595
INFO - 2016-08-15 07:41:24 --> Config Class Initialized
INFO - 2016-08-15 07:41:24 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:41:24 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:41:24 --> Utf8 Class Initialized
INFO - 2016-08-15 07:41:24 --> URI Class Initialized
INFO - 2016-08-15 07:41:24 --> Router Class Initialized
INFO - 2016-08-15 07:41:24 --> Output Class Initialized
INFO - 2016-08-15 07:41:24 --> Security Class Initialized
DEBUG - 2016-08-15 07:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:41:24 --> Input Class Initialized
INFO - 2016-08-15 07:41:24 --> Language Class Initialized
INFO - 2016-08-15 07:41:24 --> Loader Class Initialized
INFO - 2016-08-15 07:41:24 --> Helper loaded: url_helper
INFO - 2016-08-15 07:41:24 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:41:24 --> Helper loaded: html_helper
INFO - 2016-08-15 07:41:24 --> Helper loaded: form_helper
INFO - 2016-08-15 07:41:24 --> Helper loaded: file_helper
INFO - 2016-08-15 07:41:24 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:41:24 --> Database Driver Class Initialized
INFO - 2016-08-15 07:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:41:24 --> Form Validation Class Initialized
INFO - 2016-08-15 07:41:24 --> Email Class Initialized
INFO - 2016-08-15 07:41:24 --> Controller Class Initialized
DEBUG - 2016-08-15 07:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:41:24 --> Model Class Initialized
INFO - 2016-08-15 07:41:24 --> Model Class Initialized
INFO - 2016-08-15 07:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:41:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:41:24 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:41:24 --> Final output sent to browser
DEBUG - 2016-08-15 07:41:24 --> Total execution time: 0.3795
INFO - 2016-08-15 07:42:06 --> Config Class Initialized
INFO - 2016-08-15 07:42:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:42:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:42:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:42:06 --> URI Class Initialized
INFO - 2016-08-15 07:42:06 --> Router Class Initialized
INFO - 2016-08-15 07:42:06 --> Output Class Initialized
INFO - 2016-08-15 07:42:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:42:06 --> Input Class Initialized
INFO - 2016-08-15 07:42:06 --> Language Class Initialized
INFO - 2016-08-15 07:42:06 --> Loader Class Initialized
INFO - 2016-08-15 07:42:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:42:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:42:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:42:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:42:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:42:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:42:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:42:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:42:06 --> Email Class Initialized
INFO - 2016-08-15 07:42:06 --> Controller Class Initialized
DEBUG - 2016-08-15 07:42:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:42:06 --> Model Class Initialized
INFO - 2016-08-15 07:42:06 --> Model Class Initialized
INFO - 2016-08-15 07:42:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:42:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:42:06 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:42:06 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:42:06 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:42:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:42:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:42:06 --> Final output sent to browser
DEBUG - 2016-08-15 07:42:06 --> Total execution time: 0.3790
INFO - 2016-08-15 07:42:22 --> Config Class Initialized
INFO - 2016-08-15 07:42:22 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:42:22 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:42:22 --> Utf8 Class Initialized
INFO - 2016-08-15 07:42:22 --> URI Class Initialized
INFO - 2016-08-15 07:42:22 --> Router Class Initialized
INFO - 2016-08-15 07:42:22 --> Output Class Initialized
INFO - 2016-08-15 07:42:22 --> Security Class Initialized
DEBUG - 2016-08-15 07:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:42:22 --> Input Class Initialized
INFO - 2016-08-15 07:42:22 --> Language Class Initialized
INFO - 2016-08-15 07:42:22 --> Loader Class Initialized
INFO - 2016-08-15 07:42:22 --> Helper loaded: url_helper
INFO - 2016-08-15 07:42:22 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:42:22 --> Helper loaded: html_helper
INFO - 2016-08-15 07:42:22 --> Helper loaded: form_helper
INFO - 2016-08-15 07:42:22 --> Helper loaded: file_helper
INFO - 2016-08-15 07:42:22 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:42:22 --> Database Driver Class Initialized
INFO - 2016-08-15 07:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:42:22 --> Form Validation Class Initialized
INFO - 2016-08-15 07:42:22 --> Email Class Initialized
INFO - 2016-08-15 07:42:22 --> Controller Class Initialized
DEBUG - 2016-08-15 07:42:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:42:22 --> Model Class Initialized
INFO - 2016-08-15 07:42:22 --> Model Class Initialized
INFO - 2016-08-15 07:42:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:42:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:42:22 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 25
ERROR - 2016-08-15 07:42:22 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:42:22 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
INFO - 2016-08-15 07:42:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:42:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:42:22 --> Final output sent to browser
DEBUG - 2016-08-15 07:42:22 --> Total execution time: 0.3765
INFO - 2016-08-15 07:46:51 --> Config Class Initialized
INFO - 2016-08-15 07:46:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:46:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:46:51 --> Utf8 Class Initialized
INFO - 2016-08-15 07:46:51 --> URI Class Initialized
INFO - 2016-08-15 07:46:52 --> Router Class Initialized
INFO - 2016-08-15 07:46:52 --> Output Class Initialized
INFO - 2016-08-15 07:46:52 --> Security Class Initialized
DEBUG - 2016-08-15 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:46:52 --> Input Class Initialized
INFO - 2016-08-15 07:46:52 --> Language Class Initialized
INFO - 2016-08-15 07:46:52 --> Loader Class Initialized
INFO - 2016-08-15 07:46:52 --> Helper loaded: url_helper
INFO - 2016-08-15 07:46:52 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:46:52 --> Helper loaded: html_helper
INFO - 2016-08-15 07:46:52 --> Helper loaded: form_helper
INFO - 2016-08-15 07:46:52 --> Helper loaded: file_helper
INFO - 2016-08-15 07:46:52 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:46:52 --> Database Driver Class Initialized
INFO - 2016-08-15 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:46:52 --> Form Validation Class Initialized
INFO - 2016-08-15 07:46:52 --> Email Class Initialized
INFO - 2016-08-15 07:46:52 --> Controller Class Initialized
DEBUG - 2016-08-15 07:46:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:46:52 --> Model Class Initialized
INFO - 2016-08-15 07:46:52 --> Model Class Initialized
INFO - 2016-08-15 07:46:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:46:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:46:52 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:46:52 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 43
ERROR - 2016-08-15 07:46:52 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 43
INFO - 2016-08-15 07:46:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:46:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:46:52 --> Final output sent to browser
DEBUG - 2016-08-15 07:46:52 --> Total execution time: 0.3910
INFO - 2016-08-15 07:46:54 --> Config Class Initialized
INFO - 2016-08-15 07:46:54 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:46:54 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:46:54 --> Utf8 Class Initialized
INFO - 2016-08-15 07:46:54 --> URI Class Initialized
INFO - 2016-08-15 07:46:54 --> Router Class Initialized
INFO - 2016-08-15 07:46:54 --> Output Class Initialized
INFO - 2016-08-15 07:46:54 --> Security Class Initialized
DEBUG - 2016-08-15 07:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:46:54 --> Input Class Initialized
INFO - 2016-08-15 07:46:54 --> Language Class Initialized
INFO - 2016-08-15 07:46:54 --> Loader Class Initialized
INFO - 2016-08-15 07:46:54 --> Helper loaded: url_helper
INFO - 2016-08-15 07:46:54 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:46:54 --> Helper loaded: html_helper
INFO - 2016-08-15 07:46:54 --> Helper loaded: form_helper
INFO - 2016-08-15 07:46:54 --> Helper loaded: file_helper
INFO - 2016-08-15 07:46:54 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:46:54 --> Database Driver Class Initialized
INFO - 2016-08-15 07:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:46:54 --> Form Validation Class Initialized
INFO - 2016-08-15 07:46:54 --> Email Class Initialized
INFO - 2016-08-15 07:46:54 --> Controller Class Initialized
DEBUG - 2016-08-15 07:46:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:46:54 --> Model Class Initialized
INFO - 2016-08-15 07:46:54 --> Model Class Initialized
INFO - 2016-08-15 07:46:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:46:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:46:54 --> Severity: Notice --> Undefined variable: rule D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 38
ERROR - 2016-08-15 07:46:54 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 43
ERROR - 2016-08-15 07:46:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 43
INFO - 2016-08-15 07:46:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:46:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:46:54 --> Final output sent to browser
DEBUG - 2016-08-15 07:46:54 --> Total execution time: 0.4158
INFO - 2016-08-15 07:47:35 --> Config Class Initialized
INFO - 2016-08-15 07:47:35 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:47:35 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:47:35 --> Utf8 Class Initialized
INFO - 2016-08-15 07:47:35 --> URI Class Initialized
INFO - 2016-08-15 07:47:35 --> Router Class Initialized
INFO - 2016-08-15 07:47:35 --> Output Class Initialized
INFO - 2016-08-15 07:47:35 --> Security Class Initialized
DEBUG - 2016-08-15 07:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:47:35 --> Input Class Initialized
INFO - 2016-08-15 07:47:35 --> Language Class Initialized
INFO - 2016-08-15 07:47:35 --> Loader Class Initialized
INFO - 2016-08-15 07:47:35 --> Helper loaded: url_helper
INFO - 2016-08-15 07:47:35 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:47:35 --> Helper loaded: html_helper
INFO - 2016-08-15 07:47:35 --> Helper loaded: form_helper
INFO - 2016-08-15 07:47:35 --> Helper loaded: file_helper
INFO - 2016-08-15 07:47:35 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:47:35 --> Database Driver Class Initialized
INFO - 2016-08-15 07:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:47:35 --> Form Validation Class Initialized
INFO - 2016-08-15 07:47:35 --> Email Class Initialized
INFO - 2016-08-15 07:47:35 --> Controller Class Initialized
DEBUG - 2016-08-15 07:47:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:47:35 --> Model Class Initialized
INFO - 2016-08-15 07:47:35 --> Model Class Initialized
INFO - 2016-08-15 07:47:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:47:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 07:47:35 --> Severity: Notice --> Undefined variable: gbarcode D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 48
ERROR - 2016-08-15 07:47:35 --> Severity: Warning --> Invalid argument supplied for foreach() D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 48
INFO - 2016-08-15 07:47:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:47:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:47:35 --> Final output sent to browser
DEBUG - 2016-08-15 07:47:35 --> Total execution time: 0.3819
INFO - 2016-08-15 07:48:06 --> Config Class Initialized
INFO - 2016-08-15 07:48:06 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:48:06 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:48:06 --> Utf8 Class Initialized
INFO - 2016-08-15 07:48:06 --> URI Class Initialized
INFO - 2016-08-15 07:48:06 --> Router Class Initialized
INFO - 2016-08-15 07:48:06 --> Output Class Initialized
INFO - 2016-08-15 07:48:06 --> Security Class Initialized
DEBUG - 2016-08-15 07:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:48:06 --> Input Class Initialized
INFO - 2016-08-15 07:48:06 --> Language Class Initialized
INFO - 2016-08-15 07:48:06 --> Loader Class Initialized
INFO - 2016-08-15 07:48:06 --> Helper loaded: url_helper
INFO - 2016-08-15 07:48:06 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:48:06 --> Helper loaded: html_helper
INFO - 2016-08-15 07:48:06 --> Helper loaded: form_helper
INFO - 2016-08-15 07:48:06 --> Helper loaded: file_helper
INFO - 2016-08-15 07:48:06 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:48:06 --> Database Driver Class Initialized
INFO - 2016-08-15 07:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:48:06 --> Form Validation Class Initialized
INFO - 2016-08-15 07:48:06 --> Email Class Initialized
INFO - 2016-08-15 07:48:06 --> Controller Class Initialized
DEBUG - 2016-08-15 07:48:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:48:07 --> Model Class Initialized
INFO - 2016-08-15 07:48:07 --> Model Class Initialized
INFO - 2016-08-15 07:48:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:48:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:48:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:48:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:48:07 --> Final output sent to browser
DEBUG - 2016-08-15 07:48:07 --> Total execution time: 0.3477
INFO - 2016-08-15 07:48:20 --> Config Class Initialized
INFO - 2016-08-15 07:48:20 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:48:20 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:48:20 --> Utf8 Class Initialized
INFO - 2016-08-15 07:48:20 --> URI Class Initialized
INFO - 2016-08-15 07:48:20 --> Router Class Initialized
INFO - 2016-08-15 07:48:20 --> Output Class Initialized
INFO - 2016-08-15 07:48:20 --> Security Class Initialized
DEBUG - 2016-08-15 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:48:20 --> Input Class Initialized
INFO - 2016-08-15 07:48:20 --> Language Class Initialized
INFO - 2016-08-15 07:48:20 --> Loader Class Initialized
INFO - 2016-08-15 07:48:21 --> Helper loaded: url_helper
INFO - 2016-08-15 07:48:21 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:48:21 --> Helper loaded: html_helper
INFO - 2016-08-15 07:48:21 --> Helper loaded: form_helper
INFO - 2016-08-15 07:48:21 --> Helper loaded: file_helper
INFO - 2016-08-15 07:48:21 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:48:21 --> Database Driver Class Initialized
INFO - 2016-08-15 07:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:48:21 --> Form Validation Class Initialized
INFO - 2016-08-15 07:48:21 --> Email Class Initialized
INFO - 2016-08-15 07:48:21 --> Controller Class Initialized
DEBUG - 2016-08-15 07:48:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:48:21 --> Model Class Initialized
INFO - 2016-08-15 07:48:21 --> Model Class Initialized
INFO - 2016-08-15 07:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:48:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:48:21 --> Final output sent to browser
DEBUG - 2016-08-15 07:48:21 --> Total execution time: 0.3430
INFO - 2016-08-15 07:48:26 --> Config Class Initialized
INFO - 2016-08-15 07:48:26 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:48:26 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:48:26 --> Utf8 Class Initialized
INFO - 2016-08-15 07:48:26 --> URI Class Initialized
INFO - 2016-08-15 07:48:26 --> Router Class Initialized
INFO - 2016-08-15 07:48:26 --> Output Class Initialized
INFO - 2016-08-15 07:48:26 --> Security Class Initialized
DEBUG - 2016-08-15 07:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:48:26 --> Input Class Initialized
INFO - 2016-08-15 07:48:26 --> Language Class Initialized
INFO - 2016-08-15 07:48:26 --> Loader Class Initialized
INFO - 2016-08-15 07:48:26 --> Helper loaded: url_helper
INFO - 2016-08-15 07:48:26 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:48:26 --> Helper loaded: html_helper
INFO - 2016-08-15 07:48:26 --> Helper loaded: form_helper
INFO - 2016-08-15 07:48:26 --> Helper loaded: file_helper
INFO - 2016-08-15 07:48:26 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:48:26 --> Database Driver Class Initialized
INFO - 2016-08-15 07:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:48:26 --> Form Validation Class Initialized
INFO - 2016-08-15 07:48:26 --> Email Class Initialized
INFO - 2016-08-15 07:48:26 --> Controller Class Initialized
DEBUG - 2016-08-15 07:48:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:48:26 --> Model Class Initialized
INFO - 2016-08-15 07:48:26 --> Model Class Initialized
INFO - 2016-08-15 07:48:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:48:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:48:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:48:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:48:26 --> Final output sent to browser
DEBUG - 2016-08-15 07:48:26 --> Total execution time: 0.3422
INFO - 2016-08-15 07:49:12 --> Config Class Initialized
INFO - 2016-08-15 07:49:12 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:49:12 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:49:12 --> Utf8 Class Initialized
INFO - 2016-08-15 07:49:12 --> URI Class Initialized
INFO - 2016-08-15 07:49:12 --> Router Class Initialized
INFO - 2016-08-15 07:49:12 --> Output Class Initialized
INFO - 2016-08-15 07:49:12 --> Security Class Initialized
DEBUG - 2016-08-15 07:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:49:12 --> Input Class Initialized
INFO - 2016-08-15 07:49:12 --> Language Class Initialized
INFO - 2016-08-15 07:49:12 --> Loader Class Initialized
INFO - 2016-08-15 07:49:12 --> Helper loaded: url_helper
INFO - 2016-08-15 07:49:12 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:49:12 --> Helper loaded: html_helper
INFO - 2016-08-15 07:49:12 --> Helper loaded: form_helper
INFO - 2016-08-15 07:49:12 --> Helper loaded: file_helper
INFO - 2016-08-15 07:49:12 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:49:12 --> Database Driver Class Initialized
INFO - 2016-08-15 07:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:49:12 --> Form Validation Class Initialized
INFO - 2016-08-15 07:49:12 --> Email Class Initialized
INFO - 2016-08-15 07:49:12 --> Controller Class Initialized
DEBUG - 2016-08-15 07:49:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:49:12 --> Model Class Initialized
INFO - 2016-08-15 07:49:12 --> Model Class Initialized
INFO - 2016-08-15 07:49:32 --> Config Class Initialized
INFO - 2016-08-15 07:49:32 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:49:32 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:49:32 --> Utf8 Class Initialized
INFO - 2016-08-15 07:49:32 --> URI Class Initialized
INFO - 2016-08-15 07:49:32 --> Router Class Initialized
INFO - 2016-08-15 07:49:32 --> Output Class Initialized
INFO - 2016-08-15 07:49:32 --> Security Class Initialized
DEBUG - 2016-08-15 07:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:49:32 --> Input Class Initialized
INFO - 2016-08-15 07:49:32 --> Language Class Initialized
INFO - 2016-08-15 07:49:32 --> Loader Class Initialized
INFO - 2016-08-15 07:49:32 --> Helper loaded: url_helper
INFO - 2016-08-15 07:49:32 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:49:32 --> Helper loaded: html_helper
INFO - 2016-08-15 07:49:32 --> Helper loaded: form_helper
INFO - 2016-08-15 07:49:32 --> Helper loaded: file_helper
INFO - 2016-08-15 07:49:32 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:49:32 --> Database Driver Class Initialized
INFO - 2016-08-15 07:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:49:32 --> Form Validation Class Initialized
INFO - 2016-08-15 07:49:32 --> Email Class Initialized
INFO - 2016-08-15 07:49:32 --> Controller Class Initialized
DEBUG - 2016-08-15 07:49:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:49:32 --> Model Class Initialized
INFO - 2016-08-15 07:49:32 --> Model Class Initialized
INFO - 2016-08-15 07:49:49 --> Config Class Initialized
INFO - 2016-08-15 07:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:49:49 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:49:49 --> Utf8 Class Initialized
INFO - 2016-08-15 07:49:49 --> URI Class Initialized
INFO - 2016-08-15 07:49:49 --> Router Class Initialized
INFO - 2016-08-15 07:49:49 --> Output Class Initialized
INFO - 2016-08-15 07:49:49 --> Security Class Initialized
DEBUG - 2016-08-15 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:49:49 --> Input Class Initialized
INFO - 2016-08-15 07:49:49 --> Language Class Initialized
INFO - 2016-08-15 07:49:49 --> Loader Class Initialized
INFO - 2016-08-15 07:49:49 --> Helper loaded: url_helper
INFO - 2016-08-15 07:49:49 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:49:49 --> Helper loaded: html_helper
INFO - 2016-08-15 07:49:49 --> Helper loaded: form_helper
INFO - 2016-08-15 07:49:49 --> Helper loaded: file_helper
INFO - 2016-08-15 07:49:49 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:49:49 --> Database Driver Class Initialized
INFO - 2016-08-15 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:49:49 --> Form Validation Class Initialized
INFO - 2016-08-15 07:49:49 --> Email Class Initialized
INFO - 2016-08-15 07:49:49 --> Controller Class Initialized
DEBUG - 2016-08-15 07:49:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:49:49 --> Model Class Initialized
INFO - 2016-08-15 07:49:49 --> Model Class Initialized
INFO - 2016-08-15 07:49:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:49:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:49:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:49:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:49:49 --> Final output sent to browser
DEBUG - 2016-08-15 07:49:49 --> Total execution time: 0.3507
INFO - 2016-08-15 07:49:51 --> Config Class Initialized
INFO - 2016-08-15 07:49:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:49:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:49:51 --> Utf8 Class Initialized
INFO - 2016-08-15 07:49:51 --> URI Class Initialized
INFO - 2016-08-15 07:49:51 --> Router Class Initialized
INFO - 2016-08-15 07:49:51 --> Output Class Initialized
INFO - 2016-08-15 07:49:51 --> Security Class Initialized
DEBUG - 2016-08-15 07:49:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:49:51 --> Input Class Initialized
INFO - 2016-08-15 07:49:51 --> Language Class Initialized
INFO - 2016-08-15 07:49:51 --> Loader Class Initialized
INFO - 2016-08-15 07:49:51 --> Helper loaded: url_helper
INFO - 2016-08-15 07:49:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:49:51 --> Helper loaded: html_helper
INFO - 2016-08-15 07:49:51 --> Helper loaded: form_helper
INFO - 2016-08-15 07:49:51 --> Helper loaded: file_helper
INFO - 2016-08-15 07:49:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:49:51 --> Database Driver Class Initialized
INFO - 2016-08-15 07:49:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:49:51 --> Form Validation Class Initialized
INFO - 2016-08-15 07:49:51 --> Email Class Initialized
INFO - 2016-08-15 07:49:51 --> Controller Class Initialized
DEBUG - 2016-08-15 07:49:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:49:51 --> Model Class Initialized
INFO - 2016-08-15 07:49:51 --> Model Class Initialized
INFO - 2016-08-15 07:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-15 07:49:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:49:51 --> Final output sent to browser
DEBUG - 2016-08-15 07:49:51 --> Total execution time: 0.3594
INFO - 2016-08-15 07:49:59 --> Config Class Initialized
INFO - 2016-08-15 07:49:59 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:49:59 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:49:59 --> Utf8 Class Initialized
INFO - 2016-08-15 07:49:59 --> URI Class Initialized
INFO - 2016-08-15 07:49:59 --> Router Class Initialized
INFO - 2016-08-15 07:49:59 --> Output Class Initialized
INFO - 2016-08-15 07:49:59 --> Security Class Initialized
DEBUG - 2016-08-15 07:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:49:59 --> Input Class Initialized
INFO - 2016-08-15 07:49:59 --> Language Class Initialized
INFO - 2016-08-15 07:49:59 --> Loader Class Initialized
INFO - 2016-08-15 07:49:59 --> Helper loaded: url_helper
INFO - 2016-08-15 07:49:59 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:49:59 --> Helper loaded: html_helper
INFO - 2016-08-15 07:49:59 --> Helper loaded: form_helper
INFO - 2016-08-15 07:49:59 --> Helper loaded: file_helper
INFO - 2016-08-15 07:49:59 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:49:59 --> Database Driver Class Initialized
INFO - 2016-08-15 07:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:49:59 --> Form Validation Class Initialized
INFO - 2016-08-15 07:49:59 --> Email Class Initialized
INFO - 2016-08-15 07:49:59 --> Controller Class Initialized
DEBUG - 2016-08-15 07:49:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:49:59 --> Model Class Initialized
INFO - 2016-08-15 07:49:59 --> Model Class Initialized
INFO - 2016-08-15 07:49:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:49:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:49:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:49:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:49:59 --> Final output sent to browser
DEBUG - 2016-08-15 07:49:59 --> Total execution time: 0.3817
INFO - 2016-08-15 07:50:03 --> Config Class Initialized
INFO - 2016-08-15 07:50:03 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:50:03 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:50:03 --> Utf8 Class Initialized
INFO - 2016-08-15 07:50:03 --> URI Class Initialized
INFO - 2016-08-15 07:50:03 --> Router Class Initialized
INFO - 2016-08-15 07:50:03 --> Output Class Initialized
INFO - 2016-08-15 07:50:03 --> Security Class Initialized
DEBUG - 2016-08-15 07:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:50:03 --> Input Class Initialized
INFO - 2016-08-15 07:50:03 --> Language Class Initialized
INFO - 2016-08-15 07:50:03 --> Loader Class Initialized
INFO - 2016-08-15 07:50:03 --> Helper loaded: url_helper
INFO - 2016-08-15 07:50:03 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:50:03 --> Helper loaded: html_helper
INFO - 2016-08-15 07:50:03 --> Helper loaded: form_helper
INFO - 2016-08-15 07:50:03 --> Helper loaded: file_helper
INFO - 2016-08-15 07:50:03 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:50:03 --> Database Driver Class Initialized
INFO - 2016-08-15 07:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:50:03 --> Form Validation Class Initialized
INFO - 2016-08-15 07:50:03 --> Email Class Initialized
INFO - 2016-08-15 07:50:03 --> Controller Class Initialized
DEBUG - 2016-08-15 07:50:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:50:03 --> Model Class Initialized
INFO - 2016-08-15 07:50:03 --> Model Class Initialized
INFO - 2016-08-15 07:50:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:50:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:50:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:50:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:50:03 --> Final output sent to browser
DEBUG - 2016-08-15 07:50:03 --> Total execution time: 0.3471
INFO - 2016-08-15 07:50:07 --> Config Class Initialized
INFO - 2016-08-15 07:50:07 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:50:07 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:50:07 --> Utf8 Class Initialized
INFO - 2016-08-15 07:50:07 --> URI Class Initialized
INFO - 2016-08-15 07:50:07 --> Router Class Initialized
INFO - 2016-08-15 07:50:07 --> Output Class Initialized
INFO - 2016-08-15 07:50:07 --> Security Class Initialized
DEBUG - 2016-08-15 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:50:07 --> Input Class Initialized
INFO - 2016-08-15 07:50:07 --> Language Class Initialized
INFO - 2016-08-15 07:50:07 --> Loader Class Initialized
INFO - 2016-08-15 07:50:07 --> Helper loaded: url_helper
INFO - 2016-08-15 07:50:07 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:50:07 --> Helper loaded: html_helper
INFO - 2016-08-15 07:50:07 --> Helper loaded: form_helper
INFO - 2016-08-15 07:50:07 --> Helper loaded: file_helper
INFO - 2016-08-15 07:50:07 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:50:07 --> Database Driver Class Initialized
INFO - 2016-08-15 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:50:07 --> Form Validation Class Initialized
INFO - 2016-08-15 07:50:07 --> Email Class Initialized
INFO - 2016-08-15 07:50:07 --> Controller Class Initialized
DEBUG - 2016-08-15 07:50:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:50:07 --> Model Class Initialized
INFO - 2016-08-15 07:50:07 --> Model Class Initialized
INFO - 2016-08-15 07:50:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:50:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:50:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:50:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:50:07 --> Final output sent to browser
DEBUG - 2016-08-15 07:50:07 --> Total execution time: 0.3710
INFO - 2016-08-15 07:50:42 --> Config Class Initialized
INFO - 2016-08-15 07:50:42 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:50:42 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:50:42 --> Utf8 Class Initialized
INFO - 2016-08-15 07:50:42 --> URI Class Initialized
INFO - 2016-08-15 07:50:42 --> Router Class Initialized
INFO - 2016-08-15 07:50:42 --> Output Class Initialized
INFO - 2016-08-15 07:50:42 --> Security Class Initialized
DEBUG - 2016-08-15 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:50:42 --> Input Class Initialized
INFO - 2016-08-15 07:50:42 --> Language Class Initialized
INFO - 2016-08-15 07:50:42 --> Loader Class Initialized
INFO - 2016-08-15 07:50:42 --> Helper loaded: url_helper
INFO - 2016-08-15 07:50:42 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:50:42 --> Helper loaded: html_helper
INFO - 2016-08-15 07:50:42 --> Helper loaded: form_helper
INFO - 2016-08-15 07:50:42 --> Helper loaded: file_helper
INFO - 2016-08-15 07:50:42 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:50:42 --> Database Driver Class Initialized
INFO - 2016-08-15 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:50:42 --> Form Validation Class Initialized
INFO - 2016-08-15 07:50:42 --> Email Class Initialized
INFO - 2016-08-15 07:50:42 --> Controller Class Initialized
DEBUG - 2016-08-15 07:50:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:50:42 --> Model Class Initialized
INFO - 2016-08-15 07:50:42 --> Model Class Initialized
INFO - 2016-08-15 07:50:54 --> Config Class Initialized
INFO - 2016-08-15 07:50:54 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:50:54 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:50:54 --> Utf8 Class Initialized
INFO - 2016-08-15 07:50:54 --> URI Class Initialized
INFO - 2016-08-15 07:50:54 --> Router Class Initialized
INFO - 2016-08-15 07:50:54 --> Output Class Initialized
INFO - 2016-08-15 07:50:54 --> Security Class Initialized
DEBUG - 2016-08-15 07:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:50:54 --> Input Class Initialized
INFO - 2016-08-15 07:50:54 --> Language Class Initialized
INFO - 2016-08-15 07:50:54 --> Loader Class Initialized
INFO - 2016-08-15 07:50:54 --> Helper loaded: url_helper
INFO - 2016-08-15 07:50:54 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:50:54 --> Helper loaded: html_helper
INFO - 2016-08-15 07:50:54 --> Helper loaded: form_helper
INFO - 2016-08-15 07:50:54 --> Helper loaded: file_helper
INFO - 2016-08-15 07:50:54 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:50:54 --> Database Driver Class Initialized
INFO - 2016-08-15 07:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:50:54 --> Form Validation Class Initialized
INFO - 2016-08-15 07:50:54 --> Email Class Initialized
INFO - 2016-08-15 07:50:54 --> Controller Class Initialized
DEBUG - 2016-08-15 07:50:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:50:54 --> Model Class Initialized
INFO - 2016-08-15 07:50:54 --> Model Class Initialized
INFO - 2016-08-15 07:52:08 --> Config Class Initialized
INFO - 2016-08-15 07:52:08 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:52:08 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:52:08 --> Utf8 Class Initialized
INFO - 2016-08-15 07:52:08 --> URI Class Initialized
INFO - 2016-08-15 07:52:08 --> Router Class Initialized
INFO - 2016-08-15 07:52:08 --> Output Class Initialized
INFO - 2016-08-15 07:52:08 --> Security Class Initialized
DEBUG - 2016-08-15 07:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:52:08 --> Input Class Initialized
INFO - 2016-08-15 07:52:08 --> Language Class Initialized
INFO - 2016-08-15 07:52:08 --> Loader Class Initialized
INFO - 2016-08-15 07:52:08 --> Helper loaded: url_helper
INFO - 2016-08-15 07:52:08 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:52:08 --> Helper loaded: html_helper
INFO - 2016-08-15 07:52:08 --> Helper loaded: form_helper
INFO - 2016-08-15 07:52:08 --> Helper loaded: file_helper
INFO - 2016-08-15 07:52:08 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:52:08 --> Database Driver Class Initialized
INFO - 2016-08-15 07:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:52:08 --> Form Validation Class Initialized
INFO - 2016-08-15 07:52:08 --> Email Class Initialized
INFO - 2016-08-15 07:52:08 --> Controller Class Initialized
DEBUG - 2016-08-15 07:52:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:52:08 --> Model Class Initialized
INFO - 2016-08-15 07:52:08 --> Model Class Initialized
INFO - 2016-08-15 07:52:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:52:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:52:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:52:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:52:08 --> Final output sent to browser
DEBUG - 2016-08-15 07:52:08 --> Total execution time: 0.3662
INFO - 2016-08-15 07:52:11 --> Config Class Initialized
INFO - 2016-08-15 07:52:11 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:52:11 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:52:11 --> Utf8 Class Initialized
INFO - 2016-08-15 07:52:11 --> URI Class Initialized
INFO - 2016-08-15 07:52:12 --> Router Class Initialized
INFO - 2016-08-15 07:52:12 --> Output Class Initialized
INFO - 2016-08-15 07:52:12 --> Security Class Initialized
DEBUG - 2016-08-15 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:52:12 --> Input Class Initialized
INFO - 2016-08-15 07:52:12 --> Language Class Initialized
INFO - 2016-08-15 07:52:12 --> Loader Class Initialized
INFO - 2016-08-15 07:52:12 --> Helper loaded: url_helper
INFO - 2016-08-15 07:52:12 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:52:12 --> Helper loaded: html_helper
INFO - 2016-08-15 07:52:12 --> Helper loaded: form_helper
INFO - 2016-08-15 07:52:12 --> Helper loaded: file_helper
INFO - 2016-08-15 07:52:12 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:52:12 --> Database Driver Class Initialized
INFO - 2016-08-15 07:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:52:12 --> Form Validation Class Initialized
INFO - 2016-08-15 07:52:12 --> Email Class Initialized
INFO - 2016-08-15 07:52:12 --> Controller Class Initialized
DEBUG - 2016-08-15 07:52:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:52:12 --> Model Class Initialized
INFO - 2016-08-15 07:52:12 --> Model Class Initialized
INFO - 2016-08-15 07:52:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:52:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:52:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:52:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:52:12 --> Final output sent to browser
DEBUG - 2016-08-15 07:52:12 --> Total execution time: 0.3576
INFO - 2016-08-15 07:52:29 --> Config Class Initialized
INFO - 2016-08-15 07:52:29 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:52:29 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:52:29 --> Utf8 Class Initialized
INFO - 2016-08-15 07:52:29 --> URI Class Initialized
INFO - 2016-08-15 07:52:29 --> Router Class Initialized
INFO - 2016-08-15 07:52:29 --> Output Class Initialized
INFO - 2016-08-15 07:52:29 --> Security Class Initialized
DEBUG - 2016-08-15 07:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:52:30 --> Input Class Initialized
INFO - 2016-08-15 07:52:30 --> Language Class Initialized
INFO - 2016-08-15 07:52:30 --> Loader Class Initialized
INFO - 2016-08-15 07:52:30 --> Helper loaded: url_helper
INFO - 2016-08-15 07:52:30 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:52:30 --> Helper loaded: html_helper
INFO - 2016-08-15 07:52:30 --> Helper loaded: form_helper
INFO - 2016-08-15 07:52:30 --> Helper loaded: file_helper
INFO - 2016-08-15 07:52:30 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:52:30 --> Database Driver Class Initialized
INFO - 2016-08-15 07:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:52:30 --> Form Validation Class Initialized
INFO - 2016-08-15 07:52:30 --> Email Class Initialized
INFO - 2016-08-15 07:52:30 --> Controller Class Initialized
DEBUG - 2016-08-15 07:52:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:52:30 --> Model Class Initialized
INFO - 2016-08-15 07:52:30 --> Model Class Initialized
INFO - 2016-08-15 07:52:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:52:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:52:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:52:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:52:30 --> Final output sent to browser
DEBUG - 2016-08-15 07:52:30 --> Total execution time: 0.3691
INFO - 2016-08-15 07:52:41 --> Config Class Initialized
INFO - 2016-08-15 07:52:41 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:52:41 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:52:41 --> Utf8 Class Initialized
INFO - 2016-08-15 07:52:41 --> URI Class Initialized
INFO - 2016-08-15 07:52:41 --> Router Class Initialized
INFO - 2016-08-15 07:52:41 --> Output Class Initialized
INFO - 2016-08-15 07:52:41 --> Security Class Initialized
DEBUG - 2016-08-15 07:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:52:41 --> Input Class Initialized
INFO - 2016-08-15 07:52:41 --> Language Class Initialized
INFO - 2016-08-15 07:52:41 --> Loader Class Initialized
INFO - 2016-08-15 07:52:41 --> Helper loaded: url_helper
INFO - 2016-08-15 07:52:41 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:52:41 --> Helper loaded: html_helper
INFO - 2016-08-15 07:52:41 --> Helper loaded: form_helper
INFO - 2016-08-15 07:52:41 --> Helper loaded: file_helper
INFO - 2016-08-15 07:52:41 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:52:41 --> Database Driver Class Initialized
INFO - 2016-08-15 07:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:52:41 --> Form Validation Class Initialized
INFO - 2016-08-15 07:52:41 --> Email Class Initialized
INFO - 2016-08-15 07:52:41 --> Controller Class Initialized
DEBUG - 2016-08-15 07:52:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:52:42 --> Model Class Initialized
INFO - 2016-08-15 07:52:42 --> Model Class Initialized
ERROR - 2016-08-15 07:52:42 --> Query error: Table 'pnc_library.booksd' doesn't exist - Invalid query: SELECT *
FROM `booksd` `bo`
JOIN `categories` ON `bo`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `bo`.`sta_id` = `status`.`sta_id`
WHERE `b_barcode` = '2016070299'
INFO - 2016-08-15 07:52:42 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-15 07:53:33 --> Config Class Initialized
INFO - 2016-08-15 07:53:33 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:53:33 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:53:33 --> Utf8 Class Initialized
INFO - 2016-08-15 07:53:33 --> URI Class Initialized
INFO - 2016-08-15 07:53:33 --> Router Class Initialized
INFO - 2016-08-15 07:53:33 --> Output Class Initialized
INFO - 2016-08-15 07:53:33 --> Security Class Initialized
DEBUG - 2016-08-15 07:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:53:33 --> Input Class Initialized
INFO - 2016-08-15 07:53:33 --> Language Class Initialized
INFO - 2016-08-15 07:53:33 --> Loader Class Initialized
INFO - 2016-08-15 07:53:33 --> Helper loaded: url_helper
INFO - 2016-08-15 07:53:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:53:33 --> Helper loaded: html_helper
INFO - 2016-08-15 07:53:33 --> Helper loaded: form_helper
INFO - 2016-08-15 07:53:33 --> Helper loaded: file_helper
INFO - 2016-08-15 07:53:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:53:33 --> Database Driver Class Initialized
INFO - 2016-08-15 07:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:53:33 --> Form Validation Class Initialized
INFO - 2016-08-15 07:53:33 --> Email Class Initialized
INFO - 2016-08-15 07:53:33 --> Controller Class Initialized
DEBUG - 2016-08-15 07:53:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:53:33 --> Model Class Initialized
INFO - 2016-08-15 07:53:33 --> Model Class Initialized
INFO - 2016-08-15 07:53:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:53:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:53:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:53:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:53:33 --> Final output sent to browser
DEBUG - 2016-08-15 07:53:33 --> Total execution time: 0.4321
INFO - 2016-08-15 07:54:08 --> Config Class Initialized
INFO - 2016-08-15 07:54:08 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:54:08 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:54:08 --> Utf8 Class Initialized
INFO - 2016-08-15 07:54:08 --> URI Class Initialized
INFO - 2016-08-15 07:54:08 --> Router Class Initialized
INFO - 2016-08-15 07:54:08 --> Output Class Initialized
INFO - 2016-08-15 07:54:08 --> Security Class Initialized
DEBUG - 2016-08-15 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:54:08 --> Input Class Initialized
INFO - 2016-08-15 07:54:08 --> Language Class Initialized
INFO - 2016-08-15 07:54:08 --> Loader Class Initialized
INFO - 2016-08-15 07:54:08 --> Helper loaded: url_helper
INFO - 2016-08-15 07:54:08 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:54:08 --> Helper loaded: html_helper
INFO - 2016-08-15 07:54:08 --> Helper loaded: form_helper
INFO - 2016-08-15 07:54:08 --> Helper loaded: file_helper
INFO - 2016-08-15 07:54:08 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:54:08 --> Database Driver Class Initialized
INFO - 2016-08-15 07:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:54:08 --> Form Validation Class Initialized
INFO - 2016-08-15 07:54:08 --> Email Class Initialized
INFO - 2016-08-15 07:54:08 --> Controller Class Initialized
DEBUG - 2016-08-15 07:54:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:54:08 --> Model Class Initialized
INFO - 2016-08-15 07:54:08 --> Model Class Initialized
INFO - 2016-08-15 07:54:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:54:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:54:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:54:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:54:08 --> Final output sent to browser
DEBUG - 2016-08-15 07:54:08 --> Total execution time: 0.3695
INFO - 2016-08-15 07:54:50 --> Config Class Initialized
INFO - 2016-08-15 07:54:50 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:54:50 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:54:50 --> Utf8 Class Initialized
INFO - 2016-08-15 07:54:50 --> URI Class Initialized
INFO - 2016-08-15 07:54:50 --> Router Class Initialized
INFO - 2016-08-15 07:54:50 --> Output Class Initialized
INFO - 2016-08-15 07:54:50 --> Security Class Initialized
DEBUG - 2016-08-15 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:54:50 --> Input Class Initialized
INFO - 2016-08-15 07:54:50 --> Language Class Initialized
INFO - 2016-08-15 07:54:50 --> Loader Class Initialized
INFO - 2016-08-15 07:54:50 --> Helper loaded: url_helper
INFO - 2016-08-15 07:54:50 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:54:50 --> Helper loaded: html_helper
INFO - 2016-08-15 07:54:50 --> Helper loaded: form_helper
INFO - 2016-08-15 07:54:50 --> Helper loaded: file_helper
INFO - 2016-08-15 07:54:50 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:54:50 --> Database Driver Class Initialized
INFO - 2016-08-15 07:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:54:50 --> Form Validation Class Initialized
INFO - 2016-08-15 07:54:50 --> Email Class Initialized
INFO - 2016-08-15 07:54:50 --> Controller Class Initialized
DEBUG - 2016-08-15 07:54:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:54:50 --> Model Class Initialized
INFO - 2016-08-15 07:54:50 --> Model Class Initialized
INFO - 2016-08-15 07:54:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:54:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:54:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:54:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:54:50 --> Final output sent to browser
DEBUG - 2016-08-15 07:54:50 --> Total execution time: 0.3666
INFO - 2016-08-15 07:55:54 --> Config Class Initialized
INFO - 2016-08-15 07:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:55:54 --> Utf8 Class Initialized
INFO - 2016-08-15 07:55:54 --> URI Class Initialized
INFO - 2016-08-15 07:55:54 --> Router Class Initialized
INFO - 2016-08-15 07:55:54 --> Output Class Initialized
INFO - 2016-08-15 07:55:54 --> Security Class Initialized
DEBUG - 2016-08-15 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:55:54 --> Input Class Initialized
INFO - 2016-08-15 07:55:54 --> Language Class Initialized
INFO - 2016-08-15 07:55:54 --> Loader Class Initialized
INFO - 2016-08-15 07:55:54 --> Helper loaded: url_helper
INFO - 2016-08-15 07:55:54 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:55:54 --> Helper loaded: html_helper
INFO - 2016-08-15 07:55:54 --> Helper loaded: form_helper
INFO - 2016-08-15 07:55:54 --> Helper loaded: file_helper
INFO - 2016-08-15 07:55:54 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:55:54 --> Database Driver Class Initialized
INFO - 2016-08-15 07:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:55:54 --> Form Validation Class Initialized
INFO - 2016-08-15 07:55:54 --> Email Class Initialized
INFO - 2016-08-15 07:55:54 --> Controller Class Initialized
DEBUG - 2016-08-15 07:55:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:55:54 --> Model Class Initialized
INFO - 2016-08-15 07:55:54 --> Model Class Initialized
INFO - 2016-08-15 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:55:54 --> Final output sent to browser
DEBUG - 2016-08-15 07:55:54 --> Total execution time: 0.3922
INFO - 2016-08-15 07:57:39 --> Config Class Initialized
INFO - 2016-08-15 07:57:39 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:57:39 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:57:39 --> Utf8 Class Initialized
INFO - 2016-08-15 07:57:39 --> URI Class Initialized
INFO - 2016-08-15 07:57:39 --> Router Class Initialized
INFO - 2016-08-15 07:57:39 --> Output Class Initialized
INFO - 2016-08-15 07:57:39 --> Security Class Initialized
DEBUG - 2016-08-15 07:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:57:39 --> Input Class Initialized
INFO - 2016-08-15 07:57:39 --> Language Class Initialized
INFO - 2016-08-15 07:57:39 --> Loader Class Initialized
INFO - 2016-08-15 07:57:39 --> Helper loaded: url_helper
INFO - 2016-08-15 07:57:39 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:57:39 --> Helper loaded: html_helper
INFO - 2016-08-15 07:57:39 --> Helper loaded: form_helper
INFO - 2016-08-15 07:57:39 --> Helper loaded: file_helper
INFO - 2016-08-15 07:57:39 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:57:39 --> Database Driver Class Initialized
INFO - 2016-08-15 07:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:57:39 --> Form Validation Class Initialized
INFO - 2016-08-15 07:57:39 --> Email Class Initialized
INFO - 2016-08-15 07:57:39 --> Controller Class Initialized
DEBUG - 2016-08-15 07:57:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:57:39 --> Model Class Initialized
INFO - 2016-08-15 07:57:39 --> Model Class Initialized
INFO - 2016-08-15 07:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:57:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:57:39 --> Final output sent to browser
DEBUG - 2016-08-15 07:57:39 --> Total execution time: 0.3723
INFO - 2016-08-15 07:57:44 --> Config Class Initialized
INFO - 2016-08-15 07:57:44 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:57:44 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:57:44 --> Utf8 Class Initialized
INFO - 2016-08-15 07:57:44 --> URI Class Initialized
INFO - 2016-08-15 07:57:44 --> Router Class Initialized
INFO - 2016-08-15 07:57:44 --> Output Class Initialized
INFO - 2016-08-15 07:57:44 --> Security Class Initialized
DEBUG - 2016-08-15 07:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:57:44 --> Input Class Initialized
INFO - 2016-08-15 07:57:44 --> Language Class Initialized
INFO - 2016-08-15 07:57:44 --> Loader Class Initialized
INFO - 2016-08-15 07:57:44 --> Helper loaded: url_helper
INFO - 2016-08-15 07:57:44 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:57:44 --> Helper loaded: html_helper
INFO - 2016-08-15 07:57:44 --> Helper loaded: form_helper
INFO - 2016-08-15 07:57:44 --> Helper loaded: file_helper
INFO - 2016-08-15 07:57:44 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:57:44 --> Database Driver Class Initialized
INFO - 2016-08-15 07:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:57:44 --> Form Validation Class Initialized
INFO - 2016-08-15 07:57:44 --> Email Class Initialized
INFO - 2016-08-15 07:57:44 --> Controller Class Initialized
DEBUG - 2016-08-15 07:57:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:57:44 --> Model Class Initialized
INFO - 2016-08-15 07:57:44 --> Model Class Initialized
INFO - 2016-08-15 07:57:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:57:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:57:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:57:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:57:44 --> Final output sent to browser
DEBUG - 2016-08-15 07:57:44 --> Total execution time: 0.3669
INFO - 2016-08-15 07:58:38 --> Config Class Initialized
INFO - 2016-08-15 07:58:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:58:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:58:38 --> Utf8 Class Initialized
INFO - 2016-08-15 07:58:38 --> URI Class Initialized
INFO - 2016-08-15 07:58:38 --> Router Class Initialized
INFO - 2016-08-15 07:58:38 --> Output Class Initialized
INFO - 2016-08-15 07:58:38 --> Security Class Initialized
DEBUG - 2016-08-15 07:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:58:38 --> Input Class Initialized
INFO - 2016-08-15 07:58:38 --> Language Class Initialized
INFO - 2016-08-15 07:58:38 --> Loader Class Initialized
INFO - 2016-08-15 07:58:38 --> Helper loaded: url_helper
INFO - 2016-08-15 07:58:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:58:38 --> Helper loaded: html_helper
INFO - 2016-08-15 07:58:38 --> Helper loaded: form_helper
INFO - 2016-08-15 07:58:38 --> Helper loaded: file_helper
INFO - 2016-08-15 07:58:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:58:38 --> Database Driver Class Initialized
INFO - 2016-08-15 07:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:58:38 --> Form Validation Class Initialized
INFO - 2016-08-15 07:58:38 --> Email Class Initialized
INFO - 2016-08-15 07:58:38 --> Controller Class Initialized
DEBUG - 2016-08-15 07:58:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:58:38 --> Model Class Initialized
INFO - 2016-08-15 07:58:38 --> Model Class Initialized
INFO - 2016-08-15 07:58:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:58:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:58:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:58:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:58:38 --> Final output sent to browser
DEBUG - 2016-08-15 07:58:38 --> Total execution time: 0.3857
INFO - 2016-08-15 07:58:43 --> Config Class Initialized
INFO - 2016-08-15 07:58:43 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:58:43 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:58:43 --> Utf8 Class Initialized
INFO - 2016-08-15 07:58:43 --> URI Class Initialized
INFO - 2016-08-15 07:58:43 --> Router Class Initialized
INFO - 2016-08-15 07:58:43 --> Output Class Initialized
INFO - 2016-08-15 07:58:43 --> Security Class Initialized
DEBUG - 2016-08-15 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:58:43 --> Input Class Initialized
INFO - 2016-08-15 07:58:43 --> Language Class Initialized
INFO - 2016-08-15 07:58:43 --> Loader Class Initialized
INFO - 2016-08-15 07:58:43 --> Helper loaded: url_helper
INFO - 2016-08-15 07:58:43 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:58:43 --> Helper loaded: html_helper
INFO - 2016-08-15 07:58:43 --> Helper loaded: form_helper
INFO - 2016-08-15 07:58:44 --> Helper loaded: file_helper
INFO - 2016-08-15 07:58:44 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:58:44 --> Database Driver Class Initialized
INFO - 2016-08-15 07:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:58:44 --> Form Validation Class Initialized
INFO - 2016-08-15 07:58:44 --> Email Class Initialized
INFO - 2016-08-15 07:58:44 --> Controller Class Initialized
DEBUG - 2016-08-15 07:58:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:58:44 --> Model Class Initialized
INFO - 2016-08-15 07:58:44 --> Model Class Initialized
INFO - 2016-08-15 07:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:58:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:58:44 --> Final output sent to browser
DEBUG - 2016-08-15 07:58:44 --> Total execution time: 0.3747
INFO - 2016-08-15 07:58:50 --> Config Class Initialized
INFO - 2016-08-15 07:58:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:58:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:58:51 --> Utf8 Class Initialized
INFO - 2016-08-15 07:58:51 --> URI Class Initialized
INFO - 2016-08-15 07:58:51 --> Router Class Initialized
INFO - 2016-08-15 07:58:51 --> Output Class Initialized
INFO - 2016-08-15 07:58:51 --> Security Class Initialized
DEBUG - 2016-08-15 07:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:58:51 --> Input Class Initialized
INFO - 2016-08-15 07:58:51 --> Language Class Initialized
INFO - 2016-08-15 07:58:51 --> Loader Class Initialized
INFO - 2016-08-15 07:58:51 --> Helper loaded: url_helper
INFO - 2016-08-15 07:58:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:58:51 --> Helper loaded: html_helper
INFO - 2016-08-15 07:58:51 --> Helper loaded: form_helper
INFO - 2016-08-15 07:58:51 --> Helper loaded: file_helper
INFO - 2016-08-15 07:58:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:58:51 --> Database Driver Class Initialized
INFO - 2016-08-15 07:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:58:51 --> Form Validation Class Initialized
INFO - 2016-08-15 07:58:51 --> Email Class Initialized
INFO - 2016-08-15 07:58:51 --> Controller Class Initialized
DEBUG - 2016-08-15 07:58:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:58:51 --> Model Class Initialized
INFO - 2016-08-15 07:58:51 --> Model Class Initialized
INFO - 2016-08-15 07:58:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 07:58:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 07:58:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 07:58:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 07:58:51 --> Final output sent to browser
DEBUG - 2016-08-15 07:58:51 --> Total execution time: 0.3720
INFO - 2016-08-15 07:59:47 --> Config Class Initialized
INFO - 2016-08-15 07:59:47 --> Hooks Class Initialized
DEBUG - 2016-08-15 07:59:47 --> UTF-8 Support Enabled
INFO - 2016-08-15 07:59:47 --> Utf8 Class Initialized
INFO - 2016-08-15 07:59:47 --> URI Class Initialized
INFO - 2016-08-15 07:59:47 --> Router Class Initialized
INFO - 2016-08-15 07:59:47 --> Output Class Initialized
INFO - 2016-08-15 07:59:47 --> Security Class Initialized
DEBUG - 2016-08-15 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 07:59:47 --> Input Class Initialized
INFO - 2016-08-15 07:59:47 --> Language Class Initialized
INFO - 2016-08-15 07:59:47 --> Loader Class Initialized
INFO - 2016-08-15 07:59:47 --> Helper loaded: url_helper
INFO - 2016-08-15 07:59:47 --> Helper loaded: utils_helper
INFO - 2016-08-15 07:59:47 --> Helper loaded: html_helper
INFO - 2016-08-15 07:59:47 --> Helper loaded: form_helper
INFO - 2016-08-15 07:59:47 --> Helper loaded: file_helper
INFO - 2016-08-15 07:59:47 --> Helper loaded: myemail_helper
INFO - 2016-08-15 07:59:47 --> Database Driver Class Initialized
INFO - 2016-08-15 07:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 07:59:47 --> Form Validation Class Initialized
INFO - 2016-08-15 07:59:47 --> Email Class Initialized
INFO - 2016-08-15 07:59:47 --> Controller Class Initialized
DEBUG - 2016-08-15 07:59:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 07:59:47 --> Model Class Initialized
INFO - 2016-08-15 07:59:47 --> Model Class Initialized
ERROR - 2016-08-15 07:59:47 --> Query error: Table 'pnc_library.booksd' doesn't exist - Invalid query: SELECT *
FROM `booksd` `bo`
JOIN `categories` ON `bo`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `bo`.`sta_id` = `status`.`sta_id`
WHERE `b_barcode` = '2016070299'
INFO - 2016-08-15 07:59:47 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-15 08:00:19 --> Config Class Initialized
INFO - 2016-08-15 08:00:19 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:00:19 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:00:19 --> Utf8 Class Initialized
INFO - 2016-08-15 08:00:19 --> URI Class Initialized
INFO - 2016-08-15 08:00:19 --> Router Class Initialized
INFO - 2016-08-15 08:00:19 --> Output Class Initialized
INFO - 2016-08-15 08:00:19 --> Security Class Initialized
DEBUG - 2016-08-15 08:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:00:19 --> Input Class Initialized
INFO - 2016-08-15 08:00:19 --> Language Class Initialized
INFO - 2016-08-15 08:00:19 --> Loader Class Initialized
INFO - 2016-08-15 08:00:19 --> Helper loaded: url_helper
INFO - 2016-08-15 08:00:19 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:00:19 --> Helper loaded: html_helper
INFO - 2016-08-15 08:00:19 --> Helper loaded: form_helper
INFO - 2016-08-15 08:00:19 --> Helper loaded: file_helper
INFO - 2016-08-15 08:00:19 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:00:19 --> Database Driver Class Initialized
INFO - 2016-08-15 08:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:00:19 --> Form Validation Class Initialized
INFO - 2016-08-15 08:00:19 --> Email Class Initialized
INFO - 2016-08-15 08:00:19 --> Controller Class Initialized
DEBUG - 2016-08-15 08:00:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:00:20 --> Model Class Initialized
INFO - 2016-08-15 08:00:20 --> Model Class Initialized
INFO - 2016-08-15 08:00:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:00:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:00:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:00:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:00:20 --> Final output sent to browser
DEBUG - 2016-08-15 08:00:20 --> Total execution time: 0.3780
INFO - 2016-08-15 08:00:45 --> Config Class Initialized
INFO - 2016-08-15 08:00:45 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:00:45 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:00:45 --> Utf8 Class Initialized
INFO - 2016-08-15 08:00:45 --> URI Class Initialized
INFO - 2016-08-15 08:00:45 --> Router Class Initialized
INFO - 2016-08-15 08:00:45 --> Output Class Initialized
INFO - 2016-08-15 08:00:45 --> Security Class Initialized
DEBUG - 2016-08-15 08:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:00:45 --> Input Class Initialized
INFO - 2016-08-15 08:00:45 --> Language Class Initialized
INFO - 2016-08-15 08:00:45 --> Loader Class Initialized
INFO - 2016-08-15 08:00:45 --> Helper loaded: url_helper
INFO - 2016-08-15 08:00:45 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:00:45 --> Helper loaded: html_helper
INFO - 2016-08-15 08:00:45 --> Helper loaded: form_helper
INFO - 2016-08-15 08:00:45 --> Helper loaded: file_helper
INFO - 2016-08-15 08:00:45 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:00:45 --> Database Driver Class Initialized
INFO - 2016-08-15 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:00:45 --> Form Validation Class Initialized
INFO - 2016-08-15 08:00:45 --> Email Class Initialized
INFO - 2016-08-15 08:00:45 --> Controller Class Initialized
DEBUG - 2016-08-15 08:00:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:00:45 --> Model Class Initialized
INFO - 2016-08-15 08:00:45 --> Model Class Initialized
INFO - 2016-08-15 08:00:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:00:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:00:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:00:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:00:45 --> Final output sent to browser
DEBUG - 2016-08-15 08:00:45 --> Total execution time: 0.3885
INFO - 2016-08-15 08:00:51 --> Config Class Initialized
INFO - 2016-08-15 08:00:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:00:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:00:51 --> Utf8 Class Initialized
INFO - 2016-08-15 08:00:51 --> URI Class Initialized
INFO - 2016-08-15 08:00:51 --> Router Class Initialized
INFO - 2016-08-15 08:00:51 --> Output Class Initialized
INFO - 2016-08-15 08:00:51 --> Security Class Initialized
DEBUG - 2016-08-15 08:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:00:51 --> Input Class Initialized
INFO - 2016-08-15 08:00:51 --> Language Class Initialized
INFO - 2016-08-15 08:00:51 --> Loader Class Initialized
INFO - 2016-08-15 08:00:51 --> Helper loaded: url_helper
INFO - 2016-08-15 08:00:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:00:51 --> Helper loaded: html_helper
INFO - 2016-08-15 08:00:51 --> Helper loaded: form_helper
INFO - 2016-08-15 08:00:51 --> Helper loaded: file_helper
INFO - 2016-08-15 08:00:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:00:51 --> Database Driver Class Initialized
INFO - 2016-08-15 08:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:00:51 --> Form Validation Class Initialized
INFO - 2016-08-15 08:00:51 --> Email Class Initialized
INFO - 2016-08-15 08:00:51 --> Controller Class Initialized
DEBUG - 2016-08-15 08:00:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:00:51 --> Model Class Initialized
INFO - 2016-08-15 08:00:51 --> Model Class Initialized
INFO - 2016-08-15 08:00:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:00:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:00:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:00:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:00:52 --> Final output sent to browser
DEBUG - 2016-08-15 08:00:52 --> Total execution time: 0.3745
INFO - 2016-08-15 08:01:52 --> Config Class Initialized
INFO - 2016-08-15 08:01:52 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:01:52 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:01:52 --> Utf8 Class Initialized
INFO - 2016-08-15 08:01:52 --> URI Class Initialized
INFO - 2016-08-15 08:01:52 --> Router Class Initialized
INFO - 2016-08-15 08:01:52 --> Output Class Initialized
INFO - 2016-08-15 08:01:53 --> Security Class Initialized
DEBUG - 2016-08-15 08:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:01:53 --> Input Class Initialized
INFO - 2016-08-15 08:01:53 --> Language Class Initialized
INFO - 2016-08-15 08:01:53 --> Loader Class Initialized
INFO - 2016-08-15 08:01:53 --> Helper loaded: url_helper
INFO - 2016-08-15 08:01:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:01:53 --> Helper loaded: html_helper
INFO - 2016-08-15 08:01:53 --> Helper loaded: form_helper
INFO - 2016-08-15 08:01:53 --> Helper loaded: file_helper
INFO - 2016-08-15 08:01:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:01:53 --> Database Driver Class Initialized
INFO - 2016-08-15 08:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:01:53 --> Form Validation Class Initialized
INFO - 2016-08-15 08:01:53 --> Email Class Initialized
INFO - 2016-08-15 08:01:53 --> Controller Class Initialized
DEBUG - 2016-08-15 08:01:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:01:53 --> Model Class Initialized
INFO - 2016-08-15 08:01:53 --> Model Class Initialized
INFO - 2016-08-15 08:02:33 --> Config Class Initialized
INFO - 2016-08-15 08:02:33 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:02:33 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:02:33 --> Utf8 Class Initialized
INFO - 2016-08-15 08:02:33 --> URI Class Initialized
INFO - 2016-08-15 08:02:33 --> Router Class Initialized
INFO - 2016-08-15 08:02:33 --> Output Class Initialized
INFO - 2016-08-15 08:02:33 --> Security Class Initialized
DEBUG - 2016-08-15 08:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:02:33 --> Input Class Initialized
INFO - 2016-08-15 08:02:33 --> Language Class Initialized
INFO - 2016-08-15 08:02:33 --> Loader Class Initialized
INFO - 2016-08-15 08:02:33 --> Helper loaded: url_helper
INFO - 2016-08-15 08:02:33 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:02:33 --> Helper loaded: html_helper
INFO - 2016-08-15 08:02:33 --> Helper loaded: form_helper
INFO - 2016-08-15 08:02:33 --> Helper loaded: file_helper
INFO - 2016-08-15 08:02:33 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:02:33 --> Database Driver Class Initialized
INFO - 2016-08-15 08:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:02:33 --> Form Validation Class Initialized
INFO - 2016-08-15 08:02:33 --> Email Class Initialized
INFO - 2016-08-15 08:02:33 --> Controller Class Initialized
DEBUG - 2016-08-15 08:02:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:02:33 --> Model Class Initialized
INFO - 2016-08-15 08:02:33 --> Model Class Initialized
INFO - 2016-08-15 08:03:26 --> Config Class Initialized
INFO - 2016-08-15 08:03:26 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:03:26 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:03:26 --> Utf8 Class Initialized
INFO - 2016-08-15 08:03:26 --> URI Class Initialized
INFO - 2016-08-15 08:03:26 --> Router Class Initialized
INFO - 2016-08-15 08:03:26 --> Output Class Initialized
INFO - 2016-08-15 08:03:26 --> Security Class Initialized
DEBUG - 2016-08-15 08:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:03:26 --> Input Class Initialized
INFO - 2016-08-15 08:03:26 --> Language Class Initialized
INFO - 2016-08-15 08:03:26 --> Loader Class Initialized
INFO - 2016-08-15 08:03:26 --> Helper loaded: url_helper
INFO - 2016-08-15 08:03:26 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:03:26 --> Helper loaded: html_helper
INFO - 2016-08-15 08:03:26 --> Helper loaded: form_helper
INFO - 2016-08-15 08:03:26 --> Helper loaded: file_helper
INFO - 2016-08-15 08:03:26 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:03:26 --> Database Driver Class Initialized
INFO - 2016-08-15 08:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:03:26 --> Form Validation Class Initialized
INFO - 2016-08-15 08:03:26 --> Email Class Initialized
INFO - 2016-08-15 08:03:26 --> Controller Class Initialized
DEBUG - 2016-08-15 08:03:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:03:26 --> Model Class Initialized
INFO - 2016-08-15 08:03:26 --> Model Class Initialized
INFO - 2016-08-15 08:03:53 --> Config Class Initialized
INFO - 2016-08-15 08:03:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:03:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:03:53 --> Utf8 Class Initialized
INFO - 2016-08-15 08:03:53 --> URI Class Initialized
INFO - 2016-08-15 08:03:53 --> Router Class Initialized
INFO - 2016-08-15 08:03:53 --> Output Class Initialized
INFO - 2016-08-15 08:03:53 --> Security Class Initialized
DEBUG - 2016-08-15 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:03:53 --> Input Class Initialized
INFO - 2016-08-15 08:03:53 --> Language Class Initialized
INFO - 2016-08-15 08:03:53 --> Loader Class Initialized
INFO - 2016-08-15 08:03:53 --> Helper loaded: url_helper
INFO - 2016-08-15 08:03:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:03:53 --> Helper loaded: html_helper
INFO - 2016-08-15 08:03:53 --> Helper loaded: form_helper
INFO - 2016-08-15 08:03:53 --> Helper loaded: file_helper
INFO - 2016-08-15 08:03:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:03:53 --> Database Driver Class Initialized
INFO - 2016-08-15 08:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:03:53 --> Form Validation Class Initialized
INFO - 2016-08-15 08:03:53 --> Email Class Initialized
INFO - 2016-08-15 08:03:53 --> Controller Class Initialized
DEBUG - 2016-08-15 08:03:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:03:53 --> Model Class Initialized
INFO - 2016-08-15 08:03:53 --> Model Class Initialized
INFO - 2016-08-15 08:03:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:03:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-15 08:03:53 --> Severity: Notice --> Array to string conversion D:\wamp\www\library.pnc.lan\application\views\books\borrow.php 43
INFO - 2016-08-15 08:03:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:03:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:03:53 --> Final output sent to browser
DEBUG - 2016-08-15 08:03:53 --> Total execution time: 0.3988
INFO - 2016-08-15 08:04:15 --> Config Class Initialized
INFO - 2016-08-15 08:04:15 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:04:15 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:04:15 --> Utf8 Class Initialized
INFO - 2016-08-15 08:04:15 --> URI Class Initialized
INFO - 2016-08-15 08:04:15 --> Router Class Initialized
INFO - 2016-08-15 08:04:15 --> Output Class Initialized
INFO - 2016-08-15 08:04:15 --> Security Class Initialized
DEBUG - 2016-08-15 08:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:04:15 --> Input Class Initialized
INFO - 2016-08-15 08:04:15 --> Language Class Initialized
INFO - 2016-08-15 08:04:15 --> Loader Class Initialized
INFO - 2016-08-15 08:04:15 --> Helper loaded: url_helper
INFO - 2016-08-15 08:04:15 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:04:15 --> Helper loaded: html_helper
INFO - 2016-08-15 08:04:15 --> Helper loaded: form_helper
INFO - 2016-08-15 08:04:15 --> Helper loaded: file_helper
INFO - 2016-08-15 08:04:15 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:04:15 --> Database Driver Class Initialized
INFO - 2016-08-15 08:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:04:15 --> Form Validation Class Initialized
INFO - 2016-08-15 08:04:15 --> Email Class Initialized
INFO - 2016-08-15 08:04:15 --> Controller Class Initialized
DEBUG - 2016-08-15 08:04:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:04:15 --> Model Class Initialized
INFO - 2016-08-15 08:04:15 --> Model Class Initialized
INFO - 2016-08-15 08:04:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:04:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:04:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:04:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:04:15 --> Final output sent to browser
DEBUG - 2016-08-15 08:04:15 --> Total execution time: 0.3807
INFO - 2016-08-15 08:05:04 --> Config Class Initialized
INFO - 2016-08-15 08:05:04 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:05:04 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:05:04 --> Utf8 Class Initialized
INFO - 2016-08-15 08:05:04 --> URI Class Initialized
INFO - 2016-08-15 08:05:04 --> Router Class Initialized
INFO - 2016-08-15 08:05:04 --> Output Class Initialized
INFO - 2016-08-15 08:05:04 --> Security Class Initialized
DEBUG - 2016-08-15 08:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:05:04 --> Input Class Initialized
INFO - 2016-08-15 08:05:04 --> Language Class Initialized
INFO - 2016-08-15 08:05:04 --> Loader Class Initialized
INFO - 2016-08-15 08:05:04 --> Helper loaded: url_helper
INFO - 2016-08-15 08:05:04 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:05:04 --> Helper loaded: html_helper
INFO - 2016-08-15 08:05:04 --> Helper loaded: form_helper
INFO - 2016-08-15 08:05:04 --> Helper loaded: file_helper
INFO - 2016-08-15 08:05:04 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:05:04 --> Database Driver Class Initialized
INFO - 2016-08-15 08:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:05:04 --> Form Validation Class Initialized
INFO - 2016-08-15 08:05:04 --> Email Class Initialized
INFO - 2016-08-15 08:05:04 --> Controller Class Initialized
DEBUG - 2016-08-15 08:05:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:05:04 --> Model Class Initialized
INFO - 2016-08-15 08:05:04 --> Model Class Initialized
INFO - 2016-08-15 08:05:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:05:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:05:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:05:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:05:04 --> Final output sent to browser
DEBUG - 2016-08-15 08:05:04 --> Total execution time: 0.3862
INFO - 2016-08-15 08:05:15 --> Config Class Initialized
INFO - 2016-08-15 08:05:15 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:05:15 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:05:15 --> Utf8 Class Initialized
INFO - 2016-08-15 08:05:15 --> URI Class Initialized
INFO - 2016-08-15 08:05:15 --> Router Class Initialized
INFO - 2016-08-15 08:05:15 --> Output Class Initialized
INFO - 2016-08-15 08:05:15 --> Security Class Initialized
DEBUG - 2016-08-15 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:05:15 --> Input Class Initialized
INFO - 2016-08-15 08:05:15 --> Language Class Initialized
INFO - 2016-08-15 08:05:15 --> Loader Class Initialized
INFO - 2016-08-15 08:05:15 --> Helper loaded: url_helper
INFO - 2016-08-15 08:05:15 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:05:15 --> Helper loaded: html_helper
INFO - 2016-08-15 08:05:15 --> Helper loaded: form_helper
INFO - 2016-08-15 08:05:15 --> Helper loaded: file_helper
INFO - 2016-08-15 08:05:15 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:05:15 --> Database Driver Class Initialized
INFO - 2016-08-15 08:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:05:15 --> Form Validation Class Initialized
INFO - 2016-08-15 08:05:15 --> Email Class Initialized
INFO - 2016-08-15 08:05:15 --> Controller Class Initialized
DEBUG - 2016-08-15 08:05:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:05:15 --> Model Class Initialized
INFO - 2016-08-15 08:05:15 --> Model Class Initialized
INFO - 2016-08-15 08:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:05:15 --> Final output sent to browser
DEBUG - 2016-08-15 08:05:15 --> Total execution time: 0.3909
INFO - 2016-08-15 08:05:16 --> Config Class Initialized
INFO - 2016-08-15 08:05:17 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:05:17 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:05:17 --> Utf8 Class Initialized
INFO - 2016-08-15 08:05:17 --> URI Class Initialized
INFO - 2016-08-15 08:05:17 --> Router Class Initialized
INFO - 2016-08-15 08:05:17 --> Output Class Initialized
INFO - 2016-08-15 08:05:17 --> Security Class Initialized
DEBUG - 2016-08-15 08:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:05:17 --> Input Class Initialized
INFO - 2016-08-15 08:05:17 --> Language Class Initialized
INFO - 2016-08-15 08:05:17 --> Loader Class Initialized
INFO - 2016-08-15 08:05:17 --> Helper loaded: url_helper
INFO - 2016-08-15 08:05:17 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:05:17 --> Helper loaded: html_helper
INFO - 2016-08-15 08:05:17 --> Helper loaded: form_helper
INFO - 2016-08-15 08:05:17 --> Helper loaded: file_helper
INFO - 2016-08-15 08:05:17 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:05:17 --> Database Driver Class Initialized
INFO - 2016-08-15 08:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:05:17 --> Form Validation Class Initialized
INFO - 2016-08-15 08:05:17 --> Email Class Initialized
INFO - 2016-08-15 08:05:17 --> Controller Class Initialized
DEBUG - 2016-08-15 08:05:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:05:17 --> Model Class Initialized
INFO - 2016-08-15 08:05:17 --> Model Class Initialized
INFO - 2016-08-15 08:05:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:05:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:05:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:05:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:05:17 --> Final output sent to browser
DEBUG - 2016-08-15 08:05:17 --> Total execution time: 0.4205
INFO - 2016-08-15 08:05:19 --> Config Class Initialized
INFO - 2016-08-15 08:05:19 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:05:19 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:05:19 --> Utf8 Class Initialized
INFO - 2016-08-15 08:05:19 --> URI Class Initialized
INFO - 2016-08-15 08:05:19 --> Router Class Initialized
INFO - 2016-08-15 08:05:19 --> Output Class Initialized
INFO - 2016-08-15 08:05:19 --> Security Class Initialized
DEBUG - 2016-08-15 08:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:05:19 --> Input Class Initialized
INFO - 2016-08-15 08:05:19 --> Language Class Initialized
INFO - 2016-08-15 08:05:19 --> Loader Class Initialized
INFO - 2016-08-15 08:05:19 --> Helper loaded: url_helper
INFO - 2016-08-15 08:05:19 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:05:19 --> Helper loaded: html_helper
INFO - 2016-08-15 08:05:19 --> Helper loaded: form_helper
INFO - 2016-08-15 08:05:19 --> Helper loaded: file_helper
INFO - 2016-08-15 08:05:19 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:05:19 --> Database Driver Class Initialized
INFO - 2016-08-15 08:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:05:19 --> Form Validation Class Initialized
INFO - 2016-08-15 08:05:19 --> Email Class Initialized
INFO - 2016-08-15 08:05:19 --> Controller Class Initialized
DEBUG - 2016-08-15 08:05:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:05:19 --> Model Class Initialized
INFO - 2016-08-15 08:05:19 --> Model Class Initialized
INFO - 2016-08-15 08:05:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:05:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:05:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:05:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:05:19 --> Final output sent to browser
DEBUG - 2016-08-15 08:05:19 --> Total execution time: 0.4112
INFO - 2016-08-15 08:05:22 --> Config Class Initialized
INFO - 2016-08-15 08:05:22 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:05:22 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:05:22 --> Utf8 Class Initialized
INFO - 2016-08-15 08:05:22 --> URI Class Initialized
INFO - 2016-08-15 08:05:22 --> Router Class Initialized
INFO - 2016-08-15 08:05:22 --> Output Class Initialized
INFO - 2016-08-15 08:05:22 --> Security Class Initialized
DEBUG - 2016-08-15 08:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:05:22 --> Input Class Initialized
INFO - 2016-08-15 08:05:22 --> Language Class Initialized
INFO - 2016-08-15 08:05:22 --> Loader Class Initialized
INFO - 2016-08-15 08:05:22 --> Helper loaded: url_helper
INFO - 2016-08-15 08:05:22 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:05:22 --> Helper loaded: html_helper
INFO - 2016-08-15 08:05:22 --> Helper loaded: form_helper
INFO - 2016-08-15 08:05:22 --> Helper loaded: file_helper
INFO - 2016-08-15 08:05:22 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:05:22 --> Database Driver Class Initialized
INFO - 2016-08-15 08:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:05:22 --> Form Validation Class Initialized
INFO - 2016-08-15 08:05:22 --> Email Class Initialized
INFO - 2016-08-15 08:05:22 --> Controller Class Initialized
DEBUG - 2016-08-15 08:05:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:05:22 --> Model Class Initialized
INFO - 2016-08-15 08:05:22 --> Model Class Initialized
INFO - 2016-08-15 08:05:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:05:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:05:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:05:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:05:22 --> Final output sent to browser
DEBUG - 2016-08-15 08:05:23 --> Total execution time: 0.3853
INFO - 2016-08-15 08:08:44 --> Config Class Initialized
INFO - 2016-08-15 08:08:44 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:08:44 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:08:44 --> Utf8 Class Initialized
INFO - 2016-08-15 08:08:44 --> URI Class Initialized
INFO - 2016-08-15 08:08:44 --> Router Class Initialized
INFO - 2016-08-15 08:08:44 --> Output Class Initialized
INFO - 2016-08-15 08:08:44 --> Security Class Initialized
DEBUG - 2016-08-15 08:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:08:44 --> Input Class Initialized
INFO - 2016-08-15 08:08:44 --> Language Class Initialized
INFO - 2016-08-15 08:08:45 --> Loader Class Initialized
INFO - 2016-08-15 08:08:45 --> Helper loaded: url_helper
INFO - 2016-08-15 08:08:45 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:08:45 --> Helper loaded: html_helper
INFO - 2016-08-15 08:08:45 --> Helper loaded: form_helper
INFO - 2016-08-15 08:08:45 --> Helper loaded: file_helper
INFO - 2016-08-15 08:08:45 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:08:45 --> Database Driver Class Initialized
INFO - 2016-08-15 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:08:45 --> Form Validation Class Initialized
INFO - 2016-08-15 08:08:45 --> Email Class Initialized
INFO - 2016-08-15 08:08:45 --> Controller Class Initialized
DEBUG - 2016-08-15 08:08:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:08:45 --> Model Class Initialized
INFO - 2016-08-15 08:08:45 --> Model Class Initialized
INFO - 2016-08-15 08:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:08:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:08:45 --> Final output sent to browser
DEBUG - 2016-08-15 08:08:45 --> Total execution time: 0.3952
INFO - 2016-08-15 08:08:53 --> Config Class Initialized
INFO - 2016-08-15 08:08:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:08:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:08:53 --> Utf8 Class Initialized
INFO - 2016-08-15 08:08:53 --> URI Class Initialized
INFO - 2016-08-15 08:08:53 --> Router Class Initialized
INFO - 2016-08-15 08:08:54 --> Output Class Initialized
INFO - 2016-08-15 08:08:54 --> Security Class Initialized
DEBUG - 2016-08-15 08:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:08:54 --> Input Class Initialized
INFO - 2016-08-15 08:08:54 --> Language Class Initialized
INFO - 2016-08-15 08:08:54 --> Loader Class Initialized
INFO - 2016-08-15 08:08:54 --> Helper loaded: url_helper
INFO - 2016-08-15 08:08:54 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:08:54 --> Helper loaded: html_helper
INFO - 2016-08-15 08:08:54 --> Helper loaded: form_helper
INFO - 2016-08-15 08:08:54 --> Helper loaded: file_helper
INFO - 2016-08-15 08:08:54 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:08:54 --> Database Driver Class Initialized
INFO - 2016-08-15 08:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:08:54 --> Form Validation Class Initialized
INFO - 2016-08-15 08:08:54 --> Email Class Initialized
INFO - 2016-08-15 08:08:54 --> Controller Class Initialized
DEBUG - 2016-08-15 08:08:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:08:54 --> Model Class Initialized
INFO - 2016-08-15 08:08:54 --> Model Class Initialized
INFO - 2016-08-15 08:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:08:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:08:54 --> Final output sent to browser
DEBUG - 2016-08-15 08:08:54 --> Total execution time: 0.4196
INFO - 2016-08-15 08:09:10 --> Config Class Initialized
INFO - 2016-08-15 08:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:09:10 --> Utf8 Class Initialized
INFO - 2016-08-15 08:09:10 --> URI Class Initialized
INFO - 2016-08-15 08:09:10 --> Router Class Initialized
INFO - 2016-08-15 08:09:10 --> Output Class Initialized
INFO - 2016-08-15 08:09:10 --> Security Class Initialized
DEBUG - 2016-08-15 08:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:09:10 --> Input Class Initialized
INFO - 2016-08-15 08:09:10 --> Language Class Initialized
INFO - 2016-08-15 08:09:10 --> Loader Class Initialized
INFO - 2016-08-15 08:09:10 --> Helper loaded: url_helper
INFO - 2016-08-15 08:09:10 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:09:10 --> Helper loaded: html_helper
INFO - 2016-08-15 08:09:10 --> Helper loaded: form_helper
INFO - 2016-08-15 08:09:10 --> Helper loaded: file_helper
INFO - 2016-08-15 08:09:11 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:09:11 --> Database Driver Class Initialized
INFO - 2016-08-15 08:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:09:11 --> Form Validation Class Initialized
INFO - 2016-08-15 08:09:11 --> Email Class Initialized
INFO - 2016-08-15 08:09:11 --> Controller Class Initialized
DEBUG - 2016-08-15 08:09:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:09:11 --> Model Class Initialized
INFO - 2016-08-15 08:09:11 --> Model Class Initialized
INFO - 2016-08-15 08:09:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:09:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:09:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:09:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:09:11 --> Final output sent to browser
DEBUG - 2016-08-15 08:09:11 --> Total execution time: 0.4366
INFO - 2016-08-15 08:12:36 --> Config Class Initialized
INFO - 2016-08-15 08:12:36 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:12:36 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:12:36 --> Utf8 Class Initialized
INFO - 2016-08-15 08:12:36 --> URI Class Initialized
INFO - 2016-08-15 08:12:37 --> Router Class Initialized
INFO - 2016-08-15 08:12:37 --> Output Class Initialized
INFO - 2016-08-15 08:12:37 --> Security Class Initialized
DEBUG - 2016-08-15 08:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:12:37 --> Input Class Initialized
INFO - 2016-08-15 08:12:37 --> Language Class Initialized
INFO - 2016-08-15 08:12:37 --> Loader Class Initialized
INFO - 2016-08-15 08:12:37 --> Helper loaded: url_helper
INFO - 2016-08-15 08:12:37 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:12:37 --> Helper loaded: html_helper
INFO - 2016-08-15 08:12:37 --> Helper loaded: form_helper
INFO - 2016-08-15 08:12:37 --> Helper loaded: file_helper
INFO - 2016-08-15 08:12:37 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:12:37 --> Database Driver Class Initialized
INFO - 2016-08-15 08:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:12:37 --> Form Validation Class Initialized
INFO - 2016-08-15 08:12:37 --> Email Class Initialized
INFO - 2016-08-15 08:12:37 --> Controller Class Initialized
DEBUG - 2016-08-15 08:12:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:12:37 --> Model Class Initialized
INFO - 2016-08-15 08:12:37 --> Model Class Initialized
INFO - 2016-08-15 08:12:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:12:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:12:37 --> Final output sent to browser
DEBUG - 2016-08-15 08:12:37 --> Total execution time: 0.4811
INFO - 2016-08-15 08:12:46 --> Config Class Initialized
INFO - 2016-08-15 08:12:46 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:12:46 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:12:46 --> Utf8 Class Initialized
INFO - 2016-08-15 08:12:46 --> URI Class Initialized
INFO - 2016-08-15 08:12:46 --> Router Class Initialized
INFO - 2016-08-15 08:12:46 --> Output Class Initialized
INFO - 2016-08-15 08:12:46 --> Security Class Initialized
DEBUG - 2016-08-15 08:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:12:46 --> Input Class Initialized
INFO - 2016-08-15 08:12:46 --> Language Class Initialized
INFO - 2016-08-15 08:12:46 --> Loader Class Initialized
INFO - 2016-08-15 08:12:46 --> Helper loaded: url_helper
INFO - 2016-08-15 08:12:46 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:12:46 --> Helper loaded: html_helper
INFO - 2016-08-15 08:12:46 --> Helper loaded: form_helper
INFO - 2016-08-15 08:12:46 --> Helper loaded: file_helper
INFO - 2016-08-15 08:12:46 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:12:46 --> Database Driver Class Initialized
INFO - 2016-08-15 08:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:12:46 --> Form Validation Class Initialized
INFO - 2016-08-15 08:12:46 --> Email Class Initialized
INFO - 2016-08-15 08:12:46 --> Controller Class Initialized
DEBUG - 2016-08-15 08:12:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:12:46 --> Model Class Initialized
INFO - 2016-08-15 08:12:46 --> Model Class Initialized
INFO - 2016-08-15 08:12:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:12:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:12:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:12:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:12:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:12:46 --> Final output sent to browser
DEBUG - 2016-08-15 08:12:46 --> Total execution time: 0.4671
INFO - 2016-08-15 08:14:36 --> Config Class Initialized
INFO - 2016-08-15 08:14:36 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:14:36 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:14:36 --> Utf8 Class Initialized
INFO - 2016-08-15 08:14:36 --> URI Class Initialized
INFO - 2016-08-15 08:14:36 --> Router Class Initialized
INFO - 2016-08-15 08:14:36 --> Output Class Initialized
INFO - 2016-08-15 08:14:36 --> Security Class Initialized
DEBUG - 2016-08-15 08:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:14:36 --> Input Class Initialized
INFO - 2016-08-15 08:14:36 --> Language Class Initialized
INFO - 2016-08-15 08:14:36 --> Loader Class Initialized
INFO - 2016-08-15 08:14:36 --> Helper loaded: url_helper
INFO - 2016-08-15 08:14:36 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:14:36 --> Helper loaded: html_helper
INFO - 2016-08-15 08:14:36 --> Helper loaded: form_helper
INFO - 2016-08-15 08:14:36 --> Helper loaded: file_helper
INFO - 2016-08-15 08:14:36 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:14:36 --> Database Driver Class Initialized
INFO - 2016-08-15 08:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:14:36 --> Form Validation Class Initialized
INFO - 2016-08-15 08:14:36 --> Email Class Initialized
INFO - 2016-08-15 08:14:36 --> Controller Class Initialized
DEBUG - 2016-08-15 08:14:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:14:36 --> Model Class Initialized
INFO - 2016-08-15 08:14:36 --> Model Class Initialized
INFO - 2016-08-15 08:14:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:14:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:14:36 --> Final output sent to browser
DEBUG - 2016-08-15 08:14:36 --> Total execution time: 0.4115
INFO - 2016-08-15 08:14:53 --> Config Class Initialized
INFO - 2016-08-15 08:14:53 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:14:53 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:14:53 --> Utf8 Class Initialized
INFO - 2016-08-15 08:14:53 --> URI Class Initialized
INFO - 2016-08-15 08:14:53 --> Router Class Initialized
INFO - 2016-08-15 08:14:53 --> Output Class Initialized
INFO - 2016-08-15 08:14:53 --> Security Class Initialized
DEBUG - 2016-08-15 08:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:14:53 --> Input Class Initialized
INFO - 2016-08-15 08:14:53 --> Language Class Initialized
INFO - 2016-08-15 08:14:53 --> Loader Class Initialized
INFO - 2016-08-15 08:14:53 --> Helper loaded: url_helper
INFO - 2016-08-15 08:14:53 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:14:53 --> Helper loaded: html_helper
INFO - 2016-08-15 08:14:53 --> Helper loaded: form_helper
INFO - 2016-08-15 08:14:53 --> Helper loaded: file_helper
INFO - 2016-08-15 08:14:53 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:14:53 --> Database Driver Class Initialized
INFO - 2016-08-15 08:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:14:53 --> Form Validation Class Initialized
INFO - 2016-08-15 08:14:53 --> Email Class Initialized
INFO - 2016-08-15 08:14:53 --> Controller Class Initialized
DEBUG - 2016-08-15 08:14:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:14:53 --> Model Class Initialized
INFO - 2016-08-15 08:14:53 --> Model Class Initialized
INFO - 2016-08-15 08:14:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:14:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:14:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:14:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:14:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:14:53 --> Final output sent to browser
DEBUG - 2016-08-15 08:14:53 --> Total execution time: 0.4094
INFO - 2016-08-15 08:14:56 --> Config Class Initialized
INFO - 2016-08-15 08:14:56 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:14:56 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:14:57 --> Utf8 Class Initialized
INFO - 2016-08-15 08:14:57 --> URI Class Initialized
INFO - 2016-08-15 08:14:57 --> Router Class Initialized
INFO - 2016-08-15 08:14:57 --> Output Class Initialized
INFO - 2016-08-15 08:14:57 --> Security Class Initialized
DEBUG - 2016-08-15 08:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:14:57 --> Input Class Initialized
INFO - 2016-08-15 08:14:57 --> Language Class Initialized
INFO - 2016-08-15 08:14:57 --> Loader Class Initialized
INFO - 2016-08-15 08:14:57 --> Helper loaded: url_helper
INFO - 2016-08-15 08:14:57 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:14:57 --> Helper loaded: html_helper
INFO - 2016-08-15 08:14:57 --> Helper loaded: form_helper
INFO - 2016-08-15 08:14:57 --> Helper loaded: file_helper
INFO - 2016-08-15 08:14:57 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:14:57 --> Database Driver Class Initialized
INFO - 2016-08-15 08:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:14:57 --> Form Validation Class Initialized
INFO - 2016-08-15 08:14:57 --> Email Class Initialized
INFO - 2016-08-15 08:14:57 --> Controller Class Initialized
DEBUG - 2016-08-15 08:14:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:14:57 --> Model Class Initialized
INFO - 2016-08-15 08:14:57 --> Model Class Initialized
INFO - 2016-08-15 08:14:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:14:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:14:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:14:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:14:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:14:57 --> Final output sent to browser
DEBUG - 2016-08-15 08:14:57 --> Total execution time: 0.4093
INFO - 2016-08-15 08:15:00 --> Config Class Initialized
INFO - 2016-08-15 08:15:00 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:00 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:00 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:00 --> URI Class Initialized
INFO - 2016-08-15 08:15:00 --> Router Class Initialized
INFO - 2016-08-15 08:15:00 --> Output Class Initialized
INFO - 2016-08-15 08:15:00 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:01 --> Input Class Initialized
INFO - 2016-08-15 08:15:01 --> Language Class Initialized
INFO - 2016-08-15 08:15:01 --> Loader Class Initialized
INFO - 2016-08-15 08:15:01 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:01 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:01 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:01 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:01 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:01 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:01 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:01 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:01 --> Email Class Initialized
INFO - 2016-08-15 08:15:01 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:01 --> Model Class Initialized
INFO - 2016-08-15 08:15:01 --> Model Class Initialized
INFO - 2016-08-15 08:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-15 08:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:01 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:01 --> Total execution time: 0.4129
INFO - 2016-08-15 08:15:05 --> Config Class Initialized
INFO - 2016-08-15 08:15:05 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:05 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:05 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:05 --> URI Class Initialized
INFO - 2016-08-15 08:15:05 --> Router Class Initialized
INFO - 2016-08-15 08:15:05 --> Output Class Initialized
INFO - 2016-08-15 08:15:05 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:05 --> Input Class Initialized
INFO - 2016-08-15 08:15:05 --> Language Class Initialized
INFO - 2016-08-15 08:15:05 --> Loader Class Initialized
INFO - 2016-08-15 08:15:05 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:05 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:05 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:05 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:05 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:05 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:05 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:05 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:05 --> Email Class Initialized
INFO - 2016-08-15 08:15:05 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:05 --> Model Class Initialized
INFO - 2016-08-15 08:15:05 --> Model Class Initialized
ERROR - 2016-08-15 08:15:05 --> Severity: Notice --> Undefined index: gbarcode D:\wamp\www\library.pnc.lan\application\controllers\BorrowBook.php 32
INFO - 2016-08-15 08:15:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:05 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:06 --> Total execution time: 0.4102
INFO - 2016-08-15 08:15:09 --> Config Class Initialized
INFO - 2016-08-15 08:15:09 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:09 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:09 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:09 --> URI Class Initialized
INFO - 2016-08-15 08:15:09 --> Router Class Initialized
INFO - 2016-08-15 08:15:09 --> Output Class Initialized
INFO - 2016-08-15 08:15:09 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:09 --> Input Class Initialized
INFO - 2016-08-15 08:15:09 --> Language Class Initialized
INFO - 2016-08-15 08:15:09 --> Loader Class Initialized
INFO - 2016-08-15 08:15:09 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:09 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:09 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:09 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:09 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:09 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:09 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:09 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:09 --> Email Class Initialized
INFO - 2016-08-15 08:15:09 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:09 --> Model Class Initialized
INFO - 2016-08-15 08:15:09 --> Model Class Initialized
ERROR - 2016-08-15 08:15:09 --> Severity: Notice --> Undefined index: gbarcode D:\wamp\www\library.pnc.lan\application\controllers\BorrowBook.php 32
INFO - 2016-08-15 08:15:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:09 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:09 --> Total execution time: 0.4219
INFO - 2016-08-15 08:15:31 --> Config Class Initialized
INFO - 2016-08-15 08:15:31 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:31 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:31 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:31 --> URI Class Initialized
INFO - 2016-08-15 08:15:31 --> Router Class Initialized
INFO - 2016-08-15 08:15:31 --> Output Class Initialized
INFO - 2016-08-15 08:15:31 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:31 --> Input Class Initialized
INFO - 2016-08-15 08:15:31 --> Language Class Initialized
INFO - 2016-08-15 08:15:31 --> Loader Class Initialized
INFO - 2016-08-15 08:15:31 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:31 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:31 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:31 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:31 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:31 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:31 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:31 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:31 --> Email Class Initialized
INFO - 2016-08-15 08:15:31 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:31 --> Model Class Initialized
INFO - 2016-08-15 08:15:31 --> Model Class Initialized
INFO - 2016-08-15 08:15:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:31 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:31 --> Total execution time: 0.4220
INFO - 2016-08-15 08:15:35 --> Config Class Initialized
INFO - 2016-08-15 08:15:35 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:35 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:35 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:35 --> URI Class Initialized
INFO - 2016-08-15 08:15:35 --> Router Class Initialized
INFO - 2016-08-15 08:15:35 --> Output Class Initialized
INFO - 2016-08-15 08:15:35 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:35 --> Input Class Initialized
INFO - 2016-08-15 08:15:35 --> Language Class Initialized
INFO - 2016-08-15 08:15:35 --> Loader Class Initialized
INFO - 2016-08-15 08:15:35 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:35 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:35 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:35 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:35 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:35 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:35 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:35 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:35 --> Email Class Initialized
INFO - 2016-08-15 08:15:35 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:35 --> Model Class Initialized
INFO - 2016-08-15 08:15:35 --> Model Class Initialized
INFO - 2016-08-15 08:15:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-15 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:35 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:35 --> Total execution time: 0.4114
INFO - 2016-08-15 08:15:38 --> Config Class Initialized
INFO - 2016-08-15 08:15:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:38 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:38 --> URI Class Initialized
INFO - 2016-08-15 08:15:38 --> Router Class Initialized
INFO - 2016-08-15 08:15:38 --> Output Class Initialized
INFO - 2016-08-15 08:15:38 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:38 --> Input Class Initialized
INFO - 2016-08-15 08:15:38 --> Language Class Initialized
INFO - 2016-08-15 08:15:38 --> Loader Class Initialized
INFO - 2016-08-15 08:15:38 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:38 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:38 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:38 --> Email Class Initialized
INFO - 2016-08-15 08:15:38 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:38 --> Model Class Initialized
INFO - 2016-08-15 08:15:38 --> Model Class Initialized
INFO - 2016-08-15 08:15:38 --> Config Class Initialized
INFO - 2016-08-15 08:15:38 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:38 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:38 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:38 --> URI Class Initialized
INFO - 2016-08-15 08:15:38 --> Router Class Initialized
INFO - 2016-08-15 08:15:38 --> Output Class Initialized
INFO - 2016-08-15 08:15:38 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:38 --> Input Class Initialized
INFO - 2016-08-15 08:15:38 --> Language Class Initialized
INFO - 2016-08-15 08:15:38 --> Loader Class Initialized
INFO - 2016-08-15 08:15:38 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:38 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:38 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:38 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:38 --> Email Class Initialized
INFO - 2016-08-15 08:15:39 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:39 --> Model Class Initialized
INFO - 2016-08-15 08:15:39 --> Model Class Initialized
INFO - 2016-08-15 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:39 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:39 --> Total execution time: 0.3974
INFO - 2016-08-15 08:15:45 --> Config Class Initialized
INFO - 2016-08-15 08:15:45 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:45 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:45 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:45 --> URI Class Initialized
INFO - 2016-08-15 08:15:45 --> Router Class Initialized
INFO - 2016-08-15 08:15:45 --> Output Class Initialized
INFO - 2016-08-15 08:15:45 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:45 --> Input Class Initialized
INFO - 2016-08-15 08:15:45 --> Language Class Initialized
INFO - 2016-08-15 08:15:45 --> Loader Class Initialized
INFO - 2016-08-15 08:15:45 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:45 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:45 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:45 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:45 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:45 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:45 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:45 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:45 --> Email Class Initialized
INFO - 2016-08-15 08:15:45 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:45 --> Model Class Initialized
INFO - 2016-08-15 08:15:45 --> Model Class Initialized
INFO - 2016-08-15 08:15:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-15 08:15:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:45 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:45 --> Total execution time: 0.4142
INFO - 2016-08-15 08:15:46 --> Config Class Initialized
INFO - 2016-08-15 08:15:46 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:47 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:47 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:47 --> URI Class Initialized
INFO - 2016-08-15 08:15:47 --> Router Class Initialized
INFO - 2016-08-15 08:15:47 --> Output Class Initialized
INFO - 2016-08-15 08:15:47 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:47 --> Input Class Initialized
INFO - 2016-08-15 08:15:47 --> Language Class Initialized
INFO - 2016-08-15 08:15:47 --> Loader Class Initialized
INFO - 2016-08-15 08:15:47 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:47 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:47 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:47 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:47 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:47 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:47 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:47 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:47 --> Email Class Initialized
INFO - 2016-08-15 08:15:47 --> Controller Class Initialized
DEBUG - 2016-08-15 08:15:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-15 08:15:47 --> Model Class Initialized
INFO - 2016-08-15 08:15:47 --> Model Class Initialized
INFO - 2016-08-15 08:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-15 08:15:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:47 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:47 --> Total execution time: 0.4083
INFO - 2016-08-15 08:15:50 --> Config Class Initialized
INFO - 2016-08-15 08:15:50 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:50 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:50 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:50 --> URI Class Initialized
INFO - 2016-08-15 08:15:50 --> Router Class Initialized
INFO - 2016-08-15 08:15:51 --> Output Class Initialized
INFO - 2016-08-15 08:15:51 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:51 --> Input Class Initialized
INFO - 2016-08-15 08:15:51 --> Language Class Initialized
INFO - 2016-08-15 08:15:51 --> Loader Class Initialized
INFO - 2016-08-15 08:15:51 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:51 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:51 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:51 --> Email Class Initialized
INFO - 2016-08-15 08:15:51 --> Controller Class Initialized
INFO - 2016-08-15 08:15:51 --> Config Class Initialized
INFO - 2016-08-15 08:15:51 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:15:51 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:15:51 --> Utf8 Class Initialized
INFO - 2016-08-15 08:15:51 --> URI Class Initialized
INFO - 2016-08-15 08:15:51 --> Router Class Initialized
INFO - 2016-08-15 08:15:51 --> Output Class Initialized
INFO - 2016-08-15 08:15:51 --> Security Class Initialized
DEBUG - 2016-08-15 08:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:15:51 --> Input Class Initialized
INFO - 2016-08-15 08:15:51 --> Language Class Initialized
INFO - 2016-08-15 08:15:51 --> Loader Class Initialized
INFO - 2016-08-15 08:15:51 --> Helper loaded: url_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: html_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: form_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: file_helper
INFO - 2016-08-15 08:15:51 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:15:51 --> Database Driver Class Initialized
INFO - 2016-08-15 08:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:15:51 --> Form Validation Class Initialized
INFO - 2016-08-15 08:15:51 --> Email Class Initialized
INFO - 2016-08-15 08:15:51 --> Controller Class Initialized
INFO - 2016-08-15 08:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 08:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:15:51 --> Final output sent to browser
DEBUG - 2016-08-15 08:15:51 --> Total execution time: 0.3852
INFO - 2016-08-15 08:18:58 --> Config Class Initialized
INFO - 2016-08-15 08:18:58 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:18:58 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:18:58 --> Utf8 Class Initialized
INFO - 2016-08-15 08:18:58 --> URI Class Initialized
INFO - 2016-08-15 08:18:58 --> Router Class Initialized
INFO - 2016-08-15 08:18:58 --> Output Class Initialized
INFO - 2016-08-15 08:18:58 --> Security Class Initialized
DEBUG - 2016-08-15 08:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:18:58 --> Input Class Initialized
INFO - 2016-08-15 08:18:58 --> Language Class Initialized
INFO - 2016-08-15 08:18:58 --> Loader Class Initialized
INFO - 2016-08-15 08:18:58 --> Helper loaded: url_helper
INFO - 2016-08-15 08:18:58 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:18:58 --> Helper loaded: html_helper
INFO - 2016-08-15 08:18:58 --> Helper loaded: form_helper
INFO - 2016-08-15 08:18:58 --> Helper loaded: file_helper
INFO - 2016-08-15 08:18:58 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:18:58 --> Database Driver Class Initialized
INFO - 2016-08-15 08:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:18:58 --> Form Validation Class Initialized
INFO - 2016-08-15 08:18:58 --> Email Class Initialized
INFO - 2016-08-15 08:18:58 --> Controller Class Initialized
INFO - 2016-08-15 08:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-15 08:18:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:18:58 --> Final output sent to browser
DEBUG - 2016-08-15 08:18:58 --> Total execution time: 0.4110
INFO - 2016-08-15 08:19:03 --> Config Class Initialized
INFO - 2016-08-15 08:19:03 --> Hooks Class Initialized
DEBUG - 2016-08-15 08:19:03 --> UTF-8 Support Enabled
INFO - 2016-08-15 08:19:03 --> Utf8 Class Initialized
INFO - 2016-08-15 08:19:03 --> URI Class Initialized
INFO - 2016-08-15 08:19:03 --> Router Class Initialized
INFO - 2016-08-15 08:19:03 --> Output Class Initialized
INFO - 2016-08-15 08:19:03 --> Security Class Initialized
DEBUG - 2016-08-15 08:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-15 08:19:03 --> Input Class Initialized
INFO - 2016-08-15 08:19:03 --> Language Class Initialized
INFO - 2016-08-15 08:19:03 --> Loader Class Initialized
INFO - 2016-08-15 08:19:03 --> Helper loaded: url_helper
INFO - 2016-08-15 08:19:03 --> Helper loaded: utils_helper
INFO - 2016-08-15 08:19:03 --> Helper loaded: html_helper
INFO - 2016-08-15 08:19:03 --> Helper loaded: form_helper
INFO - 2016-08-15 08:19:03 --> Helper loaded: file_helper
INFO - 2016-08-15 08:19:03 --> Helper loaded: myemail_helper
INFO - 2016-08-15 08:19:03 --> Database Driver Class Initialized
INFO - 2016-08-15 08:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-15 08:19:04 --> Form Validation Class Initialized
INFO - 2016-08-15 08:19:04 --> Email Class Initialized
INFO - 2016-08-15 08:19:04 --> Controller Class Initialized
INFO - 2016-08-15 08:19:04 --> Model Class Initialized
INFO - 2016-08-15 08:19:04 --> Model Class Initialized
INFO - 2016-08-15 08:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-15 08:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-15 08:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-15 08:19:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-15 08:19:04 --> Final output sent to browser
DEBUG - 2016-08-15 08:19:04 --> Total execution time: 0.4029
