<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-29 16:25:16 --> Config Class Initialized
INFO - 2016-08-29 16:25:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:16 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:16 --> URI Class Initialized
INFO - 2016-08-29 16:25:16 --> Router Class Initialized
INFO - 2016-08-29 16:25:16 --> Output Class Initialized
INFO - 2016-08-29 16:25:16 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:16 --> Input Class Initialized
INFO - 2016-08-29 16:25:16 --> Language Class Initialized
INFO - 2016-08-29 16:25:16 --> Loader Class Initialized
INFO - 2016-08-29 16:25:16 --> Helper loaded: url_helper
INFO - 2016-08-29 16:25:16 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:25:16 --> Helper loaded: html_helper
INFO - 2016-08-29 16:25:16 --> Helper loaded: form_helper
INFO - 2016-08-29 16:25:16 --> Helper loaded: file_helper
INFO - 2016-08-29 16:25:16 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:25:16 --> Database Driver Class Initialized
INFO - 2016-08-29 16:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:25:16 --> Form Validation Class Initialized
INFO - 2016-08-29 16:25:16 --> Email Class Initialized
INFO - 2016-08-29 16:25:16 --> Controller Class Initialized
INFO - 2016-08-29 16:25:17 --> Model Class Initialized
DEBUG - 2016-08-29 16:25:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:25:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-29 16:25:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:25:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-29 16:25:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:25:17 --> Final output sent to browser
DEBUG - 2016-08-29 16:25:17 --> Total execution time: 0.3200
INFO - 2016-08-29 16:25:18 --> Config Class Initialized
INFO - 2016-08-29 16:25:18 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:18 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:18 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:18 --> URI Class Initialized
INFO - 2016-08-29 16:25:18 --> Router Class Initialized
INFO - 2016-08-29 16:25:18 --> Output Class Initialized
INFO - 2016-08-29 16:25:18 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:18 --> Input Class Initialized
INFO - 2016-08-29 16:25:18 --> Language Class Initialized
ERROR - 2016-08-29 16:25:18 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-29 16:25:18 --> Config Class Initialized
INFO - 2016-08-29 16:25:18 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:18 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:18 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:18 --> URI Class Initialized
INFO - 2016-08-29 16:25:18 --> Router Class Initialized
INFO - 2016-08-29 16:25:18 --> Output Class Initialized
INFO - 2016-08-29 16:25:18 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:18 --> Input Class Initialized
INFO - 2016-08-29 16:25:18 --> Language Class Initialized
ERROR - 2016-08-29 16:25:18 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-29 16:25:33 --> Config Class Initialized
INFO - 2016-08-29 16:25:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:33 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:33 --> URI Class Initialized
INFO - 2016-08-29 16:25:33 --> Router Class Initialized
INFO - 2016-08-29 16:25:33 --> Output Class Initialized
INFO - 2016-08-29 16:25:33 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:33 --> Input Class Initialized
INFO - 2016-08-29 16:25:33 --> Language Class Initialized
INFO - 2016-08-29 16:25:33 --> Loader Class Initialized
INFO - 2016-08-29 16:25:33 --> Helper loaded: url_helper
INFO - 2016-08-29 16:25:33 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:25:33 --> Helper loaded: html_helper
INFO - 2016-08-29 16:25:33 --> Helper loaded: form_helper
INFO - 2016-08-29 16:25:33 --> Helper loaded: file_helper
INFO - 2016-08-29 16:25:33 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:25:33 --> Database Driver Class Initialized
INFO - 2016-08-29 16:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:25:34 --> Form Validation Class Initialized
INFO - 2016-08-29 16:25:34 --> Email Class Initialized
INFO - 2016-08-29 16:25:34 --> Controller Class Initialized
INFO - 2016-08-29 16:25:34 --> Model Class Initialized
DEBUG - 2016-08-29 16:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:25:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-29 16:25:34 --> Config Class Initialized
INFO - 2016-08-29 16:25:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:34 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:34 --> URI Class Initialized
INFO - 2016-08-29 16:25:34 --> Router Class Initialized
INFO - 2016-08-29 16:25:34 --> Output Class Initialized
INFO - 2016-08-29 16:25:34 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:34 --> Input Class Initialized
INFO - 2016-08-29 16:25:34 --> Language Class Initialized
INFO - 2016-08-29 16:25:34 --> Loader Class Initialized
INFO - 2016-08-29 16:25:34 --> Helper loaded: url_helper
INFO - 2016-08-29 16:25:34 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:25:34 --> Helper loaded: html_helper
INFO - 2016-08-29 16:25:34 --> Helper loaded: form_helper
INFO - 2016-08-29 16:25:34 --> Helper loaded: file_helper
INFO - 2016-08-29 16:25:34 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:25:34 --> Database Driver Class Initialized
INFO - 2016-08-29 16:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:25:34 --> Form Validation Class Initialized
INFO - 2016-08-29 16:25:34 --> Email Class Initialized
INFO - 2016-08-29 16:25:34 --> Controller Class Initialized
DEBUG - 2016-08-29 16:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-29 16:25:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:25:34 --> Model Class Initialized
INFO - 2016-08-29 16:25:34 --> Model Class Initialized
INFO - 2016-08-29 16:25:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:25:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:25:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-29 16:25:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:25:34 --> Final output sent to browser
DEBUG - 2016-08-29 16:25:34 --> Total execution time: 0.3389
INFO - 2016-08-29 16:25:45 --> Config Class Initialized
INFO - 2016-08-29 16:25:46 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:46 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:46 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:46 --> URI Class Initialized
INFO - 2016-08-29 16:25:46 --> Router Class Initialized
INFO - 2016-08-29 16:25:46 --> Output Class Initialized
INFO - 2016-08-29 16:25:46 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:46 --> Input Class Initialized
INFO - 2016-08-29 16:25:46 --> Language Class Initialized
INFO - 2016-08-29 16:25:46 --> Loader Class Initialized
INFO - 2016-08-29 16:25:46 --> Helper loaded: url_helper
INFO - 2016-08-29 16:25:46 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:25:46 --> Helper loaded: html_helper
INFO - 2016-08-29 16:25:46 --> Helper loaded: form_helper
INFO - 2016-08-29 16:25:46 --> Helper loaded: file_helper
INFO - 2016-08-29 16:25:46 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:25:46 --> Database Driver Class Initialized
INFO - 2016-08-29 16:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:25:46 --> Form Validation Class Initialized
INFO - 2016-08-29 16:25:46 --> Email Class Initialized
INFO - 2016-08-29 16:25:46 --> Controller Class Initialized
DEBUG - 2016-08-29 16:25:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:25:46 --> Model Class Initialized
INFO - 2016-08-29 16:25:46 --> Model Class Initialized
INFO - 2016-08-29 16:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:25:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:25:46 --> Final output sent to browser
DEBUG - 2016-08-29 16:25:46 --> Total execution time: 0.2687
INFO - 2016-08-29 16:25:48 --> Config Class Initialized
INFO - 2016-08-29 16:25:49 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:25:49 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:25:49 --> Utf8 Class Initialized
INFO - 2016-08-29 16:25:49 --> URI Class Initialized
INFO - 2016-08-29 16:25:49 --> Router Class Initialized
INFO - 2016-08-29 16:25:49 --> Output Class Initialized
INFO - 2016-08-29 16:25:49 --> Security Class Initialized
DEBUG - 2016-08-29 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:25:49 --> Input Class Initialized
INFO - 2016-08-29 16:25:49 --> Language Class Initialized
INFO - 2016-08-29 16:25:49 --> Loader Class Initialized
INFO - 2016-08-29 16:25:49 --> Helper loaded: url_helper
INFO - 2016-08-29 16:25:49 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:25:49 --> Helper loaded: html_helper
INFO - 2016-08-29 16:25:49 --> Helper loaded: form_helper
INFO - 2016-08-29 16:25:49 --> Helper loaded: file_helper
INFO - 2016-08-29 16:25:49 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:25:49 --> Database Driver Class Initialized
INFO - 2016-08-29 16:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:25:49 --> Form Validation Class Initialized
INFO - 2016-08-29 16:25:49 --> Email Class Initialized
INFO - 2016-08-29 16:25:49 --> Controller Class Initialized
DEBUG - 2016-08-29 16:25:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:25:49 --> Model Class Initialized
INFO - 2016-08-29 16:25:49 --> Model Class Initialized
INFO - 2016-08-29 16:25:49 --> Model Class Initialized
INFO - 2016-08-29 16:25:49 --> Model Class Initialized
INFO - 2016-08-29 16:25:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:25:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:25:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:25:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:25:49 --> Final output sent to browser
DEBUG - 2016-08-29 16:25:49 --> Total execution time: 0.2150
INFO - 2016-08-29 16:26:26 --> Config Class Initialized
INFO - 2016-08-29 16:26:26 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:26:26 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:26:26 --> Utf8 Class Initialized
INFO - 2016-08-29 16:26:26 --> URI Class Initialized
INFO - 2016-08-29 16:26:26 --> Router Class Initialized
INFO - 2016-08-29 16:26:26 --> Output Class Initialized
INFO - 2016-08-29 16:26:26 --> Security Class Initialized
DEBUG - 2016-08-29 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:26:26 --> Input Class Initialized
INFO - 2016-08-29 16:26:26 --> Language Class Initialized
INFO - 2016-08-29 16:26:26 --> Loader Class Initialized
INFO - 2016-08-29 16:26:26 --> Helper loaded: url_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: html_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: form_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: file_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:26:26 --> Database Driver Class Initialized
INFO - 2016-08-29 16:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:26:26 --> Form Validation Class Initialized
INFO - 2016-08-29 16:26:26 --> Email Class Initialized
INFO - 2016-08-29 16:26:26 --> Controller Class Initialized
DEBUG - 2016-08-29 16:26:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:26:26 --> Config Class Initialized
INFO - 2016-08-29 16:26:26 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:26:26 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:26:26 --> Utf8 Class Initialized
INFO - 2016-08-29 16:26:26 --> URI Class Initialized
INFO - 2016-08-29 16:26:26 --> Router Class Initialized
INFO - 2016-08-29 16:26:26 --> Output Class Initialized
INFO - 2016-08-29 16:26:26 --> Security Class Initialized
DEBUG - 2016-08-29 16:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:26:26 --> Input Class Initialized
INFO - 2016-08-29 16:26:26 --> Language Class Initialized
INFO - 2016-08-29 16:26:26 --> Loader Class Initialized
INFO - 2016-08-29 16:26:26 --> Helper loaded: url_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: html_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: form_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: file_helper
INFO - 2016-08-29 16:26:26 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:26:26 --> Database Driver Class Initialized
INFO - 2016-08-29 16:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:26:26 --> Form Validation Class Initialized
INFO - 2016-08-29 16:26:26 --> Email Class Initialized
INFO - 2016-08-29 16:26:26 --> Controller Class Initialized
DEBUG - 2016-08-29 16:26:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> Model Class Initialized
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 16:26:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:26:26 --> Final output sent to browser
DEBUG - 2016-08-29 16:26:26 --> Total execution time: 0.2154
INFO - 2016-08-29 16:32:41 --> Config Class Initialized
INFO - 2016-08-29 16:32:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:32:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:32:41 --> Utf8 Class Initialized
INFO - 2016-08-29 16:32:41 --> URI Class Initialized
INFO - 2016-08-29 16:32:41 --> Router Class Initialized
INFO - 2016-08-29 16:32:41 --> Output Class Initialized
INFO - 2016-08-29 16:32:41 --> Security Class Initialized
DEBUG - 2016-08-29 16:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:32:41 --> Input Class Initialized
INFO - 2016-08-29 16:32:41 --> Language Class Initialized
INFO - 2016-08-29 16:32:41 --> Loader Class Initialized
INFO - 2016-08-29 16:32:41 --> Helper loaded: url_helper
INFO - 2016-08-29 16:32:41 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:32:41 --> Helper loaded: html_helper
INFO - 2016-08-29 16:32:41 --> Helper loaded: form_helper
INFO - 2016-08-29 16:32:41 --> Helper loaded: file_helper
INFO - 2016-08-29 16:32:41 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:32:41 --> Database Driver Class Initialized
INFO - 2016-08-29 16:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:32:41 --> Form Validation Class Initialized
INFO - 2016-08-29 16:32:41 --> Email Class Initialized
INFO - 2016-08-29 16:32:41 --> Controller Class Initialized
DEBUG - 2016-08-29 16:32:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:32:41 --> Model Class Initialized
INFO - 2016-08-29 16:32:41 --> Model Class Initialized
INFO - 2016-08-29 16:32:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:32:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:32:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:32:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:32:41 --> Final output sent to browser
DEBUG - 2016-08-29 16:32:41 --> Total execution time: 0.2267
INFO - 2016-08-29 16:32:50 --> Config Class Initialized
INFO - 2016-08-29 16:32:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:32:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:32:50 --> Utf8 Class Initialized
INFO - 2016-08-29 16:32:50 --> URI Class Initialized
INFO - 2016-08-29 16:32:50 --> Router Class Initialized
INFO - 2016-08-29 16:32:50 --> Output Class Initialized
INFO - 2016-08-29 16:32:50 --> Security Class Initialized
DEBUG - 2016-08-29 16:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:32:50 --> Input Class Initialized
INFO - 2016-08-29 16:32:50 --> Language Class Initialized
INFO - 2016-08-29 16:32:50 --> Loader Class Initialized
INFO - 2016-08-29 16:32:50 --> Helper loaded: url_helper
INFO - 2016-08-29 16:32:50 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:32:50 --> Helper loaded: html_helper
INFO - 2016-08-29 16:32:50 --> Helper loaded: form_helper
INFO - 2016-08-29 16:32:50 --> Helper loaded: file_helper
INFO - 2016-08-29 16:32:50 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:32:50 --> Database Driver Class Initialized
INFO - 2016-08-29 16:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:32:50 --> Form Validation Class Initialized
INFO - 2016-08-29 16:32:50 --> Email Class Initialized
INFO - 2016-08-29 16:32:50 --> Controller Class Initialized
DEBUG - 2016-08-29 16:32:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:32:50 --> Model Class Initialized
INFO - 2016-08-29 16:32:50 --> Model Class Initialized
INFO - 2016-08-29 16:32:50 --> Model Class Initialized
INFO - 2016-08-29 16:32:50 --> Final output sent to browser
DEBUG - 2016-08-29 16:32:50 --> Total execution time: 0.2493
INFO - 2016-08-29 16:35:01 --> Config Class Initialized
INFO - 2016-08-29 16:35:01 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:35:01 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:35:01 --> Utf8 Class Initialized
INFO - 2016-08-29 16:35:01 --> URI Class Initialized
INFO - 2016-08-29 16:35:01 --> Router Class Initialized
INFO - 2016-08-29 16:35:01 --> Output Class Initialized
INFO - 2016-08-29 16:35:01 --> Security Class Initialized
DEBUG - 2016-08-29 16:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:35:01 --> Input Class Initialized
INFO - 2016-08-29 16:35:01 --> Language Class Initialized
INFO - 2016-08-29 16:35:01 --> Loader Class Initialized
INFO - 2016-08-29 16:35:01 --> Helper loaded: url_helper
INFO - 2016-08-29 16:35:01 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:35:01 --> Helper loaded: html_helper
INFO - 2016-08-29 16:35:02 --> Helper loaded: form_helper
INFO - 2016-08-29 16:35:02 --> Helper loaded: file_helper
INFO - 2016-08-29 16:35:02 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:35:02 --> Database Driver Class Initialized
INFO - 2016-08-29 16:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:35:02 --> Form Validation Class Initialized
INFO - 2016-08-29 16:35:02 --> Email Class Initialized
INFO - 2016-08-29 16:35:02 --> Controller Class Initialized
DEBUG - 2016-08-29 16:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:35:02 --> Model Class Initialized
INFO - 2016-08-29 16:35:02 --> Model Class Initialized
INFO - 2016-08-29 16:35:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:35:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:35:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:35:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:35:02 --> Final output sent to browser
DEBUG - 2016-08-29 16:35:02 --> Total execution time: 0.2876
INFO - 2016-08-29 16:35:18 --> Config Class Initialized
INFO - 2016-08-29 16:35:18 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:35:18 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:35:18 --> Utf8 Class Initialized
INFO - 2016-08-29 16:35:18 --> URI Class Initialized
INFO - 2016-08-29 16:35:18 --> Router Class Initialized
INFO - 2016-08-29 16:35:18 --> Output Class Initialized
INFO - 2016-08-29 16:35:19 --> Security Class Initialized
DEBUG - 2016-08-29 16:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:35:19 --> Input Class Initialized
INFO - 2016-08-29 16:35:19 --> Language Class Initialized
INFO - 2016-08-29 16:35:19 --> Loader Class Initialized
INFO - 2016-08-29 16:35:19 --> Helper loaded: url_helper
INFO - 2016-08-29 16:35:19 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:35:19 --> Helper loaded: html_helper
INFO - 2016-08-29 16:35:19 --> Helper loaded: form_helper
INFO - 2016-08-29 16:35:19 --> Helper loaded: file_helper
INFO - 2016-08-29 16:35:19 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:35:19 --> Database Driver Class Initialized
INFO - 2016-08-29 16:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:35:19 --> Form Validation Class Initialized
INFO - 2016-08-29 16:35:19 --> Email Class Initialized
INFO - 2016-08-29 16:35:19 --> Controller Class Initialized
DEBUG - 2016-08-29 16:35:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:35:19 --> Model Class Initialized
INFO - 2016-08-29 16:35:19 --> Model Class Initialized
INFO - 2016-08-29 16:35:19 --> Model Class Initialized
INFO - 2016-08-29 16:35:19 --> Final output sent to browser
DEBUG - 2016-08-29 16:35:19 --> Total execution time: 0.2303
INFO - 2016-08-29 16:35:41 --> Config Class Initialized
INFO - 2016-08-29 16:35:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:35:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:35:41 --> Utf8 Class Initialized
INFO - 2016-08-29 16:35:41 --> URI Class Initialized
INFO - 2016-08-29 16:35:41 --> Router Class Initialized
INFO - 2016-08-29 16:35:41 --> Output Class Initialized
INFO - 2016-08-29 16:35:41 --> Security Class Initialized
DEBUG - 2016-08-29 16:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:35:41 --> Input Class Initialized
INFO - 2016-08-29 16:35:41 --> Language Class Initialized
INFO - 2016-08-29 16:35:41 --> Loader Class Initialized
INFO - 2016-08-29 16:35:41 --> Helper loaded: url_helper
INFO - 2016-08-29 16:35:41 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:35:41 --> Helper loaded: html_helper
INFO - 2016-08-29 16:35:41 --> Helper loaded: form_helper
INFO - 2016-08-29 16:35:41 --> Helper loaded: file_helper
INFO - 2016-08-29 16:35:41 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:35:41 --> Database Driver Class Initialized
INFO - 2016-08-29 16:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:35:41 --> Form Validation Class Initialized
INFO - 2016-08-29 16:35:41 --> Email Class Initialized
INFO - 2016-08-29 16:35:41 --> Controller Class Initialized
DEBUG - 2016-08-29 16:35:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:35:41 --> Model Class Initialized
INFO - 2016-08-29 16:35:41 --> Model Class Initialized
INFO - 2016-08-29 16:35:41 --> Model Class Initialized
INFO - 2016-08-29 16:35:41 --> Final output sent to browser
DEBUG - 2016-08-29 16:35:41 --> Total execution time: 0.2284
INFO - 2016-08-29 16:35:51 --> Config Class Initialized
INFO - 2016-08-29 16:35:51 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:35:51 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:35:51 --> Utf8 Class Initialized
INFO - 2016-08-29 16:35:51 --> URI Class Initialized
INFO - 2016-08-29 16:35:51 --> Router Class Initialized
INFO - 2016-08-29 16:35:51 --> Output Class Initialized
INFO - 2016-08-29 16:35:51 --> Security Class Initialized
DEBUG - 2016-08-29 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:35:51 --> Input Class Initialized
INFO - 2016-08-29 16:35:51 --> Language Class Initialized
INFO - 2016-08-29 16:35:51 --> Loader Class Initialized
INFO - 2016-08-29 16:35:51 --> Helper loaded: url_helper
INFO - 2016-08-29 16:35:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:35:51 --> Helper loaded: html_helper
INFO - 2016-08-29 16:35:51 --> Helper loaded: form_helper
INFO - 2016-08-29 16:35:51 --> Helper loaded: file_helper
INFO - 2016-08-29 16:35:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:35:51 --> Database Driver Class Initialized
INFO - 2016-08-29 16:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:35:51 --> Form Validation Class Initialized
INFO - 2016-08-29 16:35:51 --> Email Class Initialized
INFO - 2016-08-29 16:35:51 --> Controller Class Initialized
DEBUG - 2016-08-29 16:35:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:35:51 --> Model Class Initialized
INFO - 2016-08-29 16:35:51 --> Model Class Initialized
INFO - 2016-08-29 16:35:51 --> Model Class Initialized
INFO - 2016-08-29 16:35:51 --> Final output sent to browser
DEBUG - 2016-08-29 16:35:51 --> Total execution time: 0.2247
INFO - 2016-08-29 16:37:25 --> Config Class Initialized
INFO - 2016-08-29 16:37:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:37:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:37:25 --> Utf8 Class Initialized
INFO - 2016-08-29 16:37:25 --> URI Class Initialized
INFO - 2016-08-29 16:37:25 --> Router Class Initialized
INFO - 2016-08-29 16:37:25 --> Output Class Initialized
INFO - 2016-08-29 16:37:25 --> Security Class Initialized
DEBUG - 2016-08-29 16:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:37:25 --> Input Class Initialized
INFO - 2016-08-29 16:37:25 --> Language Class Initialized
INFO - 2016-08-29 16:37:25 --> Loader Class Initialized
INFO - 2016-08-29 16:37:25 --> Helper loaded: url_helper
INFO - 2016-08-29 16:37:25 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:37:25 --> Helper loaded: html_helper
INFO - 2016-08-29 16:37:25 --> Helper loaded: form_helper
INFO - 2016-08-29 16:37:25 --> Helper loaded: file_helper
INFO - 2016-08-29 16:37:25 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:37:25 --> Database Driver Class Initialized
INFO - 2016-08-29 16:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:37:25 --> Form Validation Class Initialized
INFO - 2016-08-29 16:37:25 --> Email Class Initialized
INFO - 2016-08-29 16:37:25 --> Controller Class Initialized
DEBUG - 2016-08-29 16:37:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:37:25 --> Model Class Initialized
INFO - 2016-08-29 16:37:25 --> Model Class Initialized
INFO - 2016-08-29 16:37:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:37:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:37:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:37:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:37:25 --> Final output sent to browser
DEBUG - 2016-08-29 16:37:25 --> Total execution time: 0.2577
INFO - 2016-08-29 16:37:29 --> Config Class Initialized
INFO - 2016-08-29 16:37:29 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:37:29 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:37:29 --> Utf8 Class Initialized
INFO - 2016-08-29 16:37:29 --> URI Class Initialized
INFO - 2016-08-29 16:37:29 --> Router Class Initialized
INFO - 2016-08-29 16:37:29 --> Output Class Initialized
INFO - 2016-08-29 16:37:29 --> Security Class Initialized
DEBUG - 2016-08-29 16:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:37:29 --> Input Class Initialized
INFO - 2016-08-29 16:37:29 --> Language Class Initialized
INFO - 2016-08-29 16:37:29 --> Loader Class Initialized
INFO - 2016-08-29 16:37:29 --> Helper loaded: url_helper
INFO - 2016-08-29 16:37:29 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:37:29 --> Helper loaded: html_helper
INFO - 2016-08-29 16:37:29 --> Helper loaded: form_helper
INFO - 2016-08-29 16:37:29 --> Helper loaded: file_helper
INFO - 2016-08-29 16:37:29 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:37:29 --> Database Driver Class Initialized
INFO - 2016-08-29 16:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:37:29 --> Form Validation Class Initialized
INFO - 2016-08-29 16:37:29 --> Email Class Initialized
INFO - 2016-08-29 16:37:29 --> Controller Class Initialized
DEBUG - 2016-08-29 16:37:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:37:29 --> Model Class Initialized
INFO - 2016-08-29 16:37:29 --> Model Class Initialized
INFO - 2016-08-29 16:37:29 --> Model Class Initialized
INFO - 2016-08-29 16:37:29 --> Final output sent to browser
DEBUG - 2016-08-29 16:37:29 --> Total execution time: 0.2357
INFO - 2016-08-29 16:37:43 --> Config Class Initialized
INFO - 2016-08-29 16:37:43 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:37:43 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:37:43 --> Utf8 Class Initialized
INFO - 2016-08-29 16:37:43 --> URI Class Initialized
INFO - 2016-08-29 16:37:43 --> Router Class Initialized
INFO - 2016-08-29 16:37:43 --> Output Class Initialized
INFO - 2016-08-29 16:37:43 --> Security Class Initialized
DEBUG - 2016-08-29 16:37:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:37:43 --> Input Class Initialized
INFO - 2016-08-29 16:37:43 --> Language Class Initialized
INFO - 2016-08-29 16:37:43 --> Loader Class Initialized
INFO - 2016-08-29 16:37:43 --> Helper loaded: url_helper
INFO - 2016-08-29 16:37:43 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:37:43 --> Helper loaded: html_helper
INFO - 2016-08-29 16:37:43 --> Helper loaded: form_helper
INFO - 2016-08-29 16:37:43 --> Helper loaded: file_helper
INFO - 2016-08-29 16:37:43 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:37:43 --> Database Driver Class Initialized
INFO - 2016-08-29 16:37:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:37:43 --> Form Validation Class Initialized
INFO - 2016-08-29 16:37:43 --> Email Class Initialized
INFO - 2016-08-29 16:37:43 --> Controller Class Initialized
DEBUG - 2016-08-29 16:37:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:37:43 --> Model Class Initialized
INFO - 2016-08-29 16:37:43 --> Model Class Initialized
INFO - 2016-08-29 16:37:43 --> Model Class Initialized
INFO - 2016-08-29 16:37:43 --> Final output sent to browser
DEBUG - 2016-08-29 16:37:43 --> Total execution time: 0.2302
INFO - 2016-08-29 16:37:45 --> Config Class Initialized
INFO - 2016-08-29 16:37:45 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:37:45 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:37:45 --> Utf8 Class Initialized
INFO - 2016-08-29 16:37:45 --> URI Class Initialized
INFO - 2016-08-29 16:37:45 --> Router Class Initialized
INFO - 2016-08-29 16:37:45 --> Output Class Initialized
INFO - 2016-08-29 16:37:45 --> Security Class Initialized
DEBUG - 2016-08-29 16:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:37:46 --> Input Class Initialized
INFO - 2016-08-29 16:37:46 --> Language Class Initialized
INFO - 2016-08-29 16:37:46 --> Loader Class Initialized
INFO - 2016-08-29 16:37:46 --> Helper loaded: url_helper
INFO - 2016-08-29 16:37:46 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:37:46 --> Helper loaded: html_helper
INFO - 2016-08-29 16:37:46 --> Helper loaded: form_helper
INFO - 2016-08-29 16:37:46 --> Helper loaded: file_helper
INFO - 2016-08-29 16:37:46 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:37:46 --> Database Driver Class Initialized
INFO - 2016-08-29 16:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:37:46 --> Form Validation Class Initialized
INFO - 2016-08-29 16:37:46 --> Email Class Initialized
INFO - 2016-08-29 16:37:46 --> Controller Class Initialized
DEBUG - 2016-08-29 16:37:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:37:46 --> Model Class Initialized
INFO - 2016-08-29 16:37:46 --> Model Class Initialized
INFO - 2016-08-29 16:37:46 --> Model Class Initialized
INFO - 2016-08-29 16:37:46 --> Final output sent to browser
DEBUG - 2016-08-29 16:37:46 --> Total execution time: 0.2308
INFO - 2016-08-29 16:43:51 --> Config Class Initialized
INFO - 2016-08-29 16:43:51 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:43:51 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:43:51 --> Utf8 Class Initialized
INFO - 2016-08-29 16:43:51 --> URI Class Initialized
INFO - 2016-08-29 16:43:51 --> Router Class Initialized
INFO - 2016-08-29 16:43:51 --> Output Class Initialized
INFO - 2016-08-29 16:43:51 --> Security Class Initialized
DEBUG - 2016-08-29 16:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:43:51 --> Input Class Initialized
INFO - 2016-08-29 16:43:51 --> Language Class Initialized
INFO - 2016-08-29 16:43:51 --> Loader Class Initialized
INFO - 2016-08-29 16:43:51 --> Helper loaded: url_helper
INFO - 2016-08-29 16:43:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:43:51 --> Helper loaded: html_helper
INFO - 2016-08-29 16:43:51 --> Helper loaded: form_helper
INFO - 2016-08-29 16:43:51 --> Helper loaded: file_helper
INFO - 2016-08-29 16:43:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:43:51 --> Database Driver Class Initialized
INFO - 2016-08-29 16:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:43:51 --> Form Validation Class Initialized
INFO - 2016-08-29 16:43:51 --> Email Class Initialized
INFO - 2016-08-29 16:43:51 --> Controller Class Initialized
DEBUG - 2016-08-29 16:43:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:43:51 --> Model Class Initialized
INFO - 2016-08-29 16:43:51 --> Model Class Initialized
INFO - 2016-08-29 16:43:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:43:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:43:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:43:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:43:51 --> Final output sent to browser
DEBUG - 2016-08-29 16:43:51 --> Total execution time: 0.3142
INFO - 2016-08-29 16:43:57 --> Config Class Initialized
INFO - 2016-08-29 16:43:57 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:43:57 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:43:57 --> Utf8 Class Initialized
INFO - 2016-08-29 16:43:57 --> URI Class Initialized
INFO - 2016-08-29 16:43:57 --> Router Class Initialized
INFO - 2016-08-29 16:43:57 --> Output Class Initialized
INFO - 2016-08-29 16:43:57 --> Security Class Initialized
DEBUG - 2016-08-29 16:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:43:58 --> Input Class Initialized
INFO - 2016-08-29 16:43:58 --> Language Class Initialized
INFO - 2016-08-29 16:43:58 --> Loader Class Initialized
INFO - 2016-08-29 16:43:58 --> Helper loaded: url_helper
INFO - 2016-08-29 16:43:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:43:58 --> Helper loaded: html_helper
INFO - 2016-08-29 16:43:58 --> Helper loaded: form_helper
INFO - 2016-08-29 16:43:58 --> Helper loaded: file_helper
INFO - 2016-08-29 16:43:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:43:58 --> Database Driver Class Initialized
INFO - 2016-08-29 16:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:43:58 --> Form Validation Class Initialized
INFO - 2016-08-29 16:43:58 --> Email Class Initialized
INFO - 2016-08-29 16:43:58 --> Controller Class Initialized
DEBUG - 2016-08-29 16:43:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:43:58 --> Model Class Initialized
INFO - 2016-08-29 16:43:58 --> Model Class Initialized
INFO - 2016-08-29 16:43:58 --> Model Class Initialized
INFO - 2016-08-29 16:43:58 --> Model Class Initialized
INFO - 2016-08-29 16:43:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:43:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:43:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:43:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:43:58 --> Final output sent to browser
DEBUG - 2016-08-29 16:43:58 --> Total execution time: 0.2430
INFO - 2016-08-29 16:44:02 --> Config Class Initialized
INFO - 2016-08-29 16:44:02 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:02 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:02 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:02 --> URI Class Initialized
INFO - 2016-08-29 16:44:02 --> Router Class Initialized
INFO - 2016-08-29 16:44:03 --> Output Class Initialized
INFO - 2016-08-29 16:44:03 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:03 --> Input Class Initialized
INFO - 2016-08-29 16:44:03 --> Language Class Initialized
INFO - 2016-08-29 16:44:03 --> Loader Class Initialized
INFO - 2016-08-29 16:44:03 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:03 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:03 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:03 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:03 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:03 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:03 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:03 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:03 --> Email Class Initialized
INFO - 2016-08-29 16:44:03 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:03 --> Model Class Initialized
INFO - 2016-08-29 16:44:03 --> Model Class Initialized
INFO - 2016-08-29 16:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:44:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:44:03 --> Final output sent to browser
DEBUG - 2016-08-29 16:44:03 --> Total execution time: 0.2652
INFO - 2016-08-29 16:44:14 --> Config Class Initialized
INFO - 2016-08-29 16:44:14 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:14 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:14 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:14 --> URI Class Initialized
INFO - 2016-08-29 16:44:14 --> Router Class Initialized
INFO - 2016-08-29 16:44:14 --> Output Class Initialized
INFO - 2016-08-29 16:44:14 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:14 --> Input Class Initialized
INFO - 2016-08-29 16:44:14 --> Language Class Initialized
INFO - 2016-08-29 16:44:14 --> Loader Class Initialized
INFO - 2016-08-29 16:44:14 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:14 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:14 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:14 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:14 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:14 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:14 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:14 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:14 --> Email Class Initialized
INFO - 2016-08-29 16:44:14 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:14 --> Model Class Initialized
INFO - 2016-08-29 16:44:14 --> Model Class Initialized
INFO - 2016-08-29 16:44:14 --> Config Class Initialized
INFO - 2016-08-29 16:44:15 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:15 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:15 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:15 --> URI Class Initialized
INFO - 2016-08-29 16:44:15 --> Router Class Initialized
INFO - 2016-08-29 16:44:15 --> Output Class Initialized
INFO - 2016-08-29 16:44:15 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:15 --> Input Class Initialized
INFO - 2016-08-29 16:44:15 --> Language Class Initialized
INFO - 2016-08-29 16:44:15 --> Loader Class Initialized
INFO - 2016-08-29 16:44:15 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:15 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:15 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:15 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:15 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:15 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:15 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:15 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:15 --> Email Class Initialized
INFO - 2016-08-29 16:44:15 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:15 --> Model Class Initialized
INFO - 2016-08-29 16:44:15 --> Model Class Initialized
INFO - 2016-08-29 16:44:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:44:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:44:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:44:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:44:15 --> Final output sent to browser
DEBUG - 2016-08-29 16:44:15 --> Total execution time: 0.2569
INFO - 2016-08-29 16:44:19 --> Config Class Initialized
INFO - 2016-08-29 16:44:19 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:19 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:19 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:19 --> URI Class Initialized
INFO - 2016-08-29 16:44:19 --> Router Class Initialized
INFO - 2016-08-29 16:44:19 --> Output Class Initialized
INFO - 2016-08-29 16:44:19 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:19 --> Input Class Initialized
INFO - 2016-08-29 16:44:19 --> Language Class Initialized
INFO - 2016-08-29 16:44:19 --> Loader Class Initialized
INFO - 2016-08-29 16:44:19 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:19 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:19 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:19 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:19 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:20 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:20 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:20 --> Email Class Initialized
INFO - 2016-08-29 16:44:20 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:20 --> Model Class Initialized
INFO - 2016-08-29 16:44:20 --> Model Class Initialized
INFO - 2016-08-29 16:44:20 --> Config Class Initialized
INFO - 2016-08-29 16:44:20 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:20 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:20 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:20 --> URI Class Initialized
INFO - 2016-08-29 16:44:20 --> Router Class Initialized
INFO - 2016-08-29 16:44:20 --> Output Class Initialized
INFO - 2016-08-29 16:44:20 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:20 --> Input Class Initialized
INFO - 2016-08-29 16:44:20 --> Language Class Initialized
INFO - 2016-08-29 16:44:20 --> Loader Class Initialized
INFO - 2016-08-29 16:44:20 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:20 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:20 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:20 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:20 --> Email Class Initialized
INFO - 2016-08-29 16:44:20 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:20 --> Model Class Initialized
INFO - 2016-08-29 16:44:20 --> Model Class Initialized
INFO - 2016-08-29 16:44:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:44:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:44:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:44:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:44:20 --> Final output sent to browser
DEBUG - 2016-08-29 16:44:20 --> Total execution time: 0.2444
INFO - 2016-08-29 16:44:27 --> Config Class Initialized
INFO - 2016-08-29 16:44:27 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:27 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:27 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:27 --> URI Class Initialized
INFO - 2016-08-29 16:44:27 --> Router Class Initialized
INFO - 2016-08-29 16:44:27 --> Output Class Initialized
INFO - 2016-08-29 16:44:27 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:27 --> Input Class Initialized
INFO - 2016-08-29 16:44:28 --> Language Class Initialized
INFO - 2016-08-29 16:44:28 --> Loader Class Initialized
INFO - 2016-08-29 16:44:28 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:28 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:28 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:28 --> Email Class Initialized
INFO - 2016-08-29 16:44:28 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:28 --> Model Class Initialized
INFO - 2016-08-29 16:44:28 --> Model Class Initialized
INFO - 2016-08-29 16:44:28 --> Config Class Initialized
INFO - 2016-08-29 16:44:28 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:28 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:28 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:28 --> URI Class Initialized
INFO - 2016-08-29 16:44:28 --> Router Class Initialized
INFO - 2016-08-29 16:44:28 --> Output Class Initialized
INFO - 2016-08-29 16:44:28 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:28 --> Input Class Initialized
INFO - 2016-08-29 16:44:28 --> Language Class Initialized
INFO - 2016-08-29 16:44:28 --> Loader Class Initialized
INFO - 2016-08-29 16:44:28 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:28 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:28 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:28 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:28 --> Email Class Initialized
INFO - 2016-08-29 16:44:28 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:28 --> Model Class Initialized
INFO - 2016-08-29 16:44:28 --> Model Class Initialized
INFO - 2016-08-29 16:44:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:44:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:44:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:44:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:44:28 --> Final output sent to browser
DEBUG - 2016-08-29 16:44:28 --> Total execution time: 0.2802
INFO - 2016-08-29 16:44:33 --> Config Class Initialized
INFO - 2016-08-29 16:44:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:33 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:33 --> URI Class Initialized
INFO - 2016-08-29 16:44:33 --> Router Class Initialized
INFO - 2016-08-29 16:44:33 --> Output Class Initialized
INFO - 2016-08-29 16:44:33 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:33 --> Input Class Initialized
INFO - 2016-08-29 16:44:33 --> Language Class Initialized
INFO - 2016-08-29 16:44:33 --> Loader Class Initialized
INFO - 2016-08-29 16:44:33 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:33 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:33 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:33 --> Email Class Initialized
INFO - 2016-08-29 16:44:33 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:33 --> Model Class Initialized
INFO - 2016-08-29 16:44:33 --> Model Class Initialized
INFO - 2016-08-29 16:44:33 --> Config Class Initialized
INFO - 2016-08-29 16:44:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:44:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:44:33 --> Utf8 Class Initialized
INFO - 2016-08-29 16:44:33 --> URI Class Initialized
INFO - 2016-08-29 16:44:33 --> Router Class Initialized
INFO - 2016-08-29 16:44:33 --> Output Class Initialized
INFO - 2016-08-29 16:44:33 --> Security Class Initialized
DEBUG - 2016-08-29 16:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:44:33 --> Input Class Initialized
INFO - 2016-08-29 16:44:33 --> Language Class Initialized
INFO - 2016-08-29 16:44:33 --> Loader Class Initialized
INFO - 2016-08-29 16:44:33 --> Helper loaded: url_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: html_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: form_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: file_helper
INFO - 2016-08-29 16:44:33 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:44:33 --> Database Driver Class Initialized
INFO - 2016-08-29 16:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:44:33 --> Form Validation Class Initialized
INFO - 2016-08-29 16:44:33 --> Email Class Initialized
INFO - 2016-08-29 16:44:33 --> Controller Class Initialized
DEBUG - 2016-08-29 16:44:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:44:33 --> Model Class Initialized
INFO - 2016-08-29 16:44:33 --> Model Class Initialized
INFO - 2016-08-29 16:44:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:44:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:44:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:44:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:44:33 --> Final output sent to browser
DEBUG - 2016-08-29 16:44:33 --> Total execution time: 0.2934
INFO - 2016-08-29 16:45:01 --> Config Class Initialized
INFO - 2016-08-29 16:45:01 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:01 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:01 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:01 --> URI Class Initialized
INFO - 2016-08-29 16:45:01 --> Router Class Initialized
INFO - 2016-08-29 16:45:01 --> Output Class Initialized
INFO - 2016-08-29 16:45:01 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:01 --> Input Class Initialized
INFO - 2016-08-29 16:45:01 --> Language Class Initialized
INFO - 2016-08-29 16:45:01 --> Loader Class Initialized
INFO - 2016-08-29 16:45:01 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:01 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:01 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:01 --> Email Class Initialized
INFO - 2016-08-29 16:45:01 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:01 --> Model Class Initialized
INFO - 2016-08-29 16:45:01 --> Model Class Initialized
INFO - 2016-08-29 16:45:01 --> Config Class Initialized
INFO - 2016-08-29 16:45:01 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:01 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:01 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:01 --> URI Class Initialized
INFO - 2016-08-29 16:45:01 --> Router Class Initialized
INFO - 2016-08-29 16:45:01 --> Output Class Initialized
INFO - 2016-08-29 16:45:01 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:01 --> Input Class Initialized
INFO - 2016-08-29 16:45:01 --> Language Class Initialized
INFO - 2016-08-29 16:45:01 --> Loader Class Initialized
INFO - 2016-08-29 16:45:01 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:01 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:01 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:01 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:01 --> Email Class Initialized
INFO - 2016-08-29 16:45:01 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:01 --> Model Class Initialized
INFO - 2016-08-29 16:45:01 --> Model Class Initialized
INFO - 2016-08-29 16:45:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:45:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:45:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:45:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:45:01 --> Final output sent to browser
DEBUG - 2016-08-29 16:45:01 --> Total execution time: 0.2911
INFO - 2016-08-29 16:45:12 --> Config Class Initialized
INFO - 2016-08-29 16:45:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:12 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:12 --> URI Class Initialized
INFO - 2016-08-29 16:45:12 --> Router Class Initialized
INFO - 2016-08-29 16:45:12 --> Output Class Initialized
INFO - 2016-08-29 16:45:12 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:12 --> Input Class Initialized
INFO - 2016-08-29 16:45:12 --> Language Class Initialized
INFO - 2016-08-29 16:45:12 --> Loader Class Initialized
INFO - 2016-08-29 16:45:12 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:12 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:12 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:12 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:12 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:12 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:12 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:12 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:12 --> Email Class Initialized
INFO - 2016-08-29 16:45:12 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:12 --> Model Class Initialized
INFO - 2016-08-29 16:45:12 --> Model Class Initialized
INFO - 2016-08-29 16:45:12 --> Config Class Initialized
INFO - 2016-08-29 16:45:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:12 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:12 --> URI Class Initialized
INFO - 2016-08-29 16:45:12 --> Router Class Initialized
INFO - 2016-08-29 16:45:12 --> Output Class Initialized
INFO - 2016-08-29 16:45:12 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:13 --> Input Class Initialized
INFO - 2016-08-29 16:45:13 --> Language Class Initialized
INFO - 2016-08-29 16:45:13 --> Loader Class Initialized
INFO - 2016-08-29 16:45:13 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:13 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:13 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:13 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:13 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:13 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:13 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:13 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:13 --> Email Class Initialized
INFO - 2016-08-29 16:45:13 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:13 --> Model Class Initialized
INFO - 2016-08-29 16:45:13 --> Model Class Initialized
INFO - 2016-08-29 16:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:45:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:45:13 --> Final output sent to browser
DEBUG - 2016-08-29 16:45:13 --> Total execution time: 0.2776
INFO - 2016-08-29 16:45:33 --> Config Class Initialized
INFO - 2016-08-29 16:45:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:33 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:33 --> URI Class Initialized
INFO - 2016-08-29 16:45:33 --> Router Class Initialized
INFO - 2016-08-29 16:45:33 --> Output Class Initialized
INFO - 2016-08-29 16:45:33 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:33 --> Input Class Initialized
INFO - 2016-08-29 16:45:34 --> Language Class Initialized
INFO - 2016-08-29 16:45:34 --> Loader Class Initialized
INFO - 2016-08-29 16:45:34 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:34 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:34 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:34 --> Email Class Initialized
INFO - 2016-08-29 16:45:34 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:34 --> Model Class Initialized
INFO - 2016-08-29 16:45:34 --> Model Class Initialized
INFO - 2016-08-29 16:45:34 --> Config Class Initialized
INFO - 2016-08-29 16:45:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:34 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:34 --> URI Class Initialized
INFO - 2016-08-29 16:45:34 --> Router Class Initialized
INFO - 2016-08-29 16:45:34 --> Output Class Initialized
INFO - 2016-08-29 16:45:34 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:34 --> Input Class Initialized
INFO - 2016-08-29 16:45:34 --> Language Class Initialized
INFO - 2016-08-29 16:45:34 --> Loader Class Initialized
INFO - 2016-08-29 16:45:34 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:34 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:34 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:34 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:34 --> Email Class Initialized
INFO - 2016-08-29 16:45:34 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:34 --> Model Class Initialized
INFO - 2016-08-29 16:45:34 --> Model Class Initialized
INFO - 2016-08-29 16:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:45:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:45:34 --> Final output sent to browser
DEBUG - 2016-08-29 16:45:34 --> Total execution time: 0.2893
INFO - 2016-08-29 16:45:57 --> Config Class Initialized
INFO - 2016-08-29 16:45:57 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:57 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:57 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:57 --> URI Class Initialized
INFO - 2016-08-29 16:45:57 --> Router Class Initialized
INFO - 2016-08-29 16:45:57 --> Output Class Initialized
INFO - 2016-08-29 16:45:57 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:58 --> Input Class Initialized
INFO - 2016-08-29 16:45:58 --> Language Class Initialized
INFO - 2016-08-29 16:45:58 --> Loader Class Initialized
INFO - 2016-08-29 16:45:58 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:58 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:58 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:58 --> Email Class Initialized
INFO - 2016-08-29 16:45:58 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:58 --> Model Class Initialized
INFO - 2016-08-29 16:45:58 --> Model Class Initialized
INFO - 2016-08-29 16:45:58 --> Config Class Initialized
INFO - 2016-08-29 16:45:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:45:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:45:58 --> Utf8 Class Initialized
INFO - 2016-08-29 16:45:58 --> URI Class Initialized
INFO - 2016-08-29 16:45:58 --> Router Class Initialized
INFO - 2016-08-29 16:45:58 --> Output Class Initialized
INFO - 2016-08-29 16:45:58 --> Security Class Initialized
DEBUG - 2016-08-29 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:45:58 --> Input Class Initialized
INFO - 2016-08-29 16:45:58 --> Language Class Initialized
INFO - 2016-08-29 16:45:58 --> Loader Class Initialized
INFO - 2016-08-29 16:45:58 --> Helper loaded: url_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: html_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: form_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: file_helper
INFO - 2016-08-29 16:45:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:45:58 --> Database Driver Class Initialized
INFO - 2016-08-29 16:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:45:58 --> Form Validation Class Initialized
INFO - 2016-08-29 16:45:58 --> Email Class Initialized
INFO - 2016-08-29 16:45:58 --> Controller Class Initialized
DEBUG - 2016-08-29 16:45:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:45:58 --> Model Class Initialized
INFO - 2016-08-29 16:45:58 --> Model Class Initialized
INFO - 2016-08-29 16:45:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:45:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:45:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:45:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:45:58 --> Final output sent to browser
DEBUG - 2016-08-29 16:45:58 --> Total execution time: 0.2781
INFO - 2016-08-29 16:46:12 --> Config Class Initialized
INFO - 2016-08-29 16:46:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:46:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:46:12 --> Utf8 Class Initialized
INFO - 2016-08-29 16:46:12 --> URI Class Initialized
INFO - 2016-08-29 16:46:12 --> Router Class Initialized
INFO - 2016-08-29 16:46:12 --> Output Class Initialized
INFO - 2016-08-29 16:46:12 --> Security Class Initialized
DEBUG - 2016-08-29 16:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:46:12 --> Input Class Initialized
INFO - 2016-08-29 16:46:12 --> Language Class Initialized
INFO - 2016-08-29 16:46:12 --> Loader Class Initialized
INFO - 2016-08-29 16:46:12 --> Helper loaded: url_helper
INFO - 2016-08-29 16:46:12 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:46:12 --> Helper loaded: html_helper
INFO - 2016-08-29 16:46:12 --> Helper loaded: form_helper
INFO - 2016-08-29 16:46:12 --> Helper loaded: file_helper
INFO - 2016-08-29 16:46:12 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:46:12 --> Database Driver Class Initialized
INFO - 2016-08-29 16:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:46:12 --> Form Validation Class Initialized
INFO - 2016-08-29 16:46:12 --> Email Class Initialized
INFO - 2016-08-29 16:46:12 --> Controller Class Initialized
DEBUG - 2016-08-29 16:46:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:46:12 --> Model Class Initialized
INFO - 2016-08-29 16:46:12 --> Model Class Initialized
INFO - 2016-08-29 16:46:12 --> Model Class Initialized
INFO - 2016-08-29 16:46:12 --> Model Class Initialized
INFO - 2016-08-29 16:46:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:46:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:46:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:46:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:46:12 --> Final output sent to browser
DEBUG - 2016-08-29 16:46:12 --> Total execution time: 0.3010
INFO - 2016-08-29 16:46:17 --> Config Class Initialized
INFO - 2016-08-29 16:46:17 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:46:17 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:46:17 --> Utf8 Class Initialized
INFO - 2016-08-29 16:46:17 --> URI Class Initialized
INFO - 2016-08-29 16:46:17 --> Router Class Initialized
INFO - 2016-08-29 16:46:17 --> Output Class Initialized
INFO - 2016-08-29 16:46:17 --> Security Class Initialized
DEBUG - 2016-08-29 16:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:46:17 --> Input Class Initialized
INFO - 2016-08-29 16:46:17 --> Language Class Initialized
INFO - 2016-08-29 16:46:17 --> Loader Class Initialized
INFO - 2016-08-29 16:46:17 --> Helper loaded: url_helper
INFO - 2016-08-29 16:46:17 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:46:17 --> Helper loaded: html_helper
INFO - 2016-08-29 16:46:17 --> Helper loaded: form_helper
INFO - 2016-08-29 16:46:17 --> Helper loaded: file_helper
INFO - 2016-08-29 16:46:17 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:46:18 --> Database Driver Class Initialized
INFO - 2016-08-29 16:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:46:18 --> Form Validation Class Initialized
INFO - 2016-08-29 16:46:18 --> Email Class Initialized
INFO - 2016-08-29 16:46:18 --> Controller Class Initialized
DEBUG - 2016-08-29 16:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:46:18 --> Config Class Initialized
INFO - 2016-08-29 16:46:18 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:46:18 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:46:18 --> Utf8 Class Initialized
INFO - 2016-08-29 16:46:18 --> URI Class Initialized
INFO - 2016-08-29 16:46:18 --> Router Class Initialized
INFO - 2016-08-29 16:46:18 --> Output Class Initialized
INFO - 2016-08-29 16:46:18 --> Security Class Initialized
DEBUG - 2016-08-29 16:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:46:18 --> Input Class Initialized
INFO - 2016-08-29 16:46:18 --> Language Class Initialized
INFO - 2016-08-29 16:46:18 --> Loader Class Initialized
INFO - 2016-08-29 16:46:18 --> Helper loaded: url_helper
INFO - 2016-08-29 16:46:18 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:46:18 --> Helper loaded: html_helper
INFO - 2016-08-29 16:46:18 --> Helper loaded: form_helper
INFO - 2016-08-29 16:46:18 --> Helper loaded: file_helper
INFO - 2016-08-29 16:46:18 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:46:18 --> Database Driver Class Initialized
INFO - 2016-08-29 16:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:46:18 --> Form Validation Class Initialized
INFO - 2016-08-29 16:46:18 --> Email Class Initialized
INFO - 2016-08-29 16:46:18 --> Controller Class Initialized
DEBUG - 2016-08-29 16:46:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> Model Class Initialized
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 16:46:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:46:18 --> Final output sent to browser
DEBUG - 2016-08-29 16:46:18 --> Total execution time: 0.2877
INFO - 2016-08-29 16:46:28 --> Config Class Initialized
INFO - 2016-08-29 16:46:28 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:46:28 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:46:28 --> Utf8 Class Initialized
INFO - 2016-08-29 16:46:28 --> URI Class Initialized
INFO - 2016-08-29 16:46:28 --> Router Class Initialized
INFO - 2016-08-29 16:46:28 --> Output Class Initialized
INFO - 2016-08-29 16:46:28 --> Security Class Initialized
DEBUG - 2016-08-29 16:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:46:28 --> Input Class Initialized
INFO - 2016-08-29 16:46:28 --> Language Class Initialized
INFO - 2016-08-29 16:46:28 --> Loader Class Initialized
INFO - 2016-08-29 16:46:28 --> Helper loaded: url_helper
INFO - 2016-08-29 16:46:28 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:46:28 --> Helper loaded: html_helper
INFO - 2016-08-29 16:46:28 --> Helper loaded: form_helper
INFO - 2016-08-29 16:46:28 --> Helper loaded: file_helper
INFO - 2016-08-29 16:46:28 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:46:28 --> Database Driver Class Initialized
INFO - 2016-08-29 16:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:46:28 --> Form Validation Class Initialized
INFO - 2016-08-29 16:46:28 --> Email Class Initialized
INFO - 2016-08-29 16:46:28 --> Controller Class Initialized
DEBUG - 2016-08-29 16:46:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:46:28 --> Model Class Initialized
INFO - 2016-08-29 16:46:28 --> Model Class Initialized
INFO - 2016-08-29 16:46:28 --> Model Class Initialized
INFO - 2016-08-29 16:46:28 --> Model Class Initialized
INFO - 2016-08-29 16:46:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:46:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:46:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 16:46:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:46:28 --> Final output sent to browser
DEBUG - 2016-08-29 16:46:28 --> Total execution time: 0.2893
INFO - 2016-08-29 16:46:33 --> Config Class Initialized
INFO - 2016-08-29 16:46:33 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:46:33 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:46:33 --> Utf8 Class Initialized
INFO - 2016-08-29 16:46:33 --> URI Class Initialized
INFO - 2016-08-29 16:46:33 --> Router Class Initialized
INFO - 2016-08-29 16:46:33 --> Output Class Initialized
INFO - 2016-08-29 16:46:33 --> Security Class Initialized
DEBUG - 2016-08-29 16:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:46:33 --> Input Class Initialized
INFO - 2016-08-29 16:46:33 --> Language Class Initialized
INFO - 2016-08-29 16:46:33 --> Loader Class Initialized
INFO - 2016-08-29 16:46:33 --> Helper loaded: url_helper
INFO - 2016-08-29 16:46:33 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:46:33 --> Helper loaded: html_helper
INFO - 2016-08-29 16:46:33 --> Helper loaded: form_helper
INFO - 2016-08-29 16:46:33 --> Helper loaded: file_helper
INFO - 2016-08-29 16:46:33 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:46:33 --> Database Driver Class Initialized
INFO - 2016-08-29 16:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:46:33 --> Form Validation Class Initialized
INFO - 2016-08-29 16:46:33 --> Email Class Initialized
INFO - 2016-08-29 16:46:33 --> Controller Class Initialized
DEBUG - 2016-08-29 16:46:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:46:33 --> Model Class Initialized
INFO - 2016-08-29 16:46:33 --> Model Class Initialized
INFO - 2016-08-29 16:46:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:46:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:46:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:46:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:46:33 --> Final output sent to browser
DEBUG - 2016-08-29 16:46:33 --> Total execution time: 0.2897
INFO - 2016-08-29 16:54:16 --> Config Class Initialized
INFO - 2016-08-29 16:54:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:54:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:54:17 --> Utf8 Class Initialized
INFO - 2016-08-29 16:54:17 --> URI Class Initialized
INFO - 2016-08-29 16:54:17 --> Router Class Initialized
INFO - 2016-08-29 16:54:17 --> Output Class Initialized
INFO - 2016-08-29 16:54:17 --> Security Class Initialized
DEBUG - 2016-08-29 16:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:54:17 --> Input Class Initialized
INFO - 2016-08-29 16:54:17 --> Language Class Initialized
INFO - 2016-08-29 16:54:17 --> Loader Class Initialized
INFO - 2016-08-29 16:54:17 --> Helper loaded: url_helper
INFO - 2016-08-29 16:54:17 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:54:17 --> Helper loaded: html_helper
INFO - 2016-08-29 16:54:17 --> Helper loaded: form_helper
INFO - 2016-08-29 16:54:17 --> Helper loaded: file_helper
INFO - 2016-08-29 16:54:17 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:54:17 --> Database Driver Class Initialized
INFO - 2016-08-29 16:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:54:17 --> Form Validation Class Initialized
INFO - 2016-08-29 16:54:17 --> Email Class Initialized
INFO - 2016-08-29 16:54:17 --> Controller Class Initialized
DEBUG - 2016-08-29 16:54:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:54:17 --> Model Class Initialized
INFO - 2016-08-29 16:54:17 --> Model Class Initialized
INFO - 2016-08-29 16:54:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:54:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:54:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:54:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:54:17 --> Final output sent to browser
DEBUG - 2016-08-29 16:54:17 --> Total execution time: 0.2986
INFO - 2016-08-29 16:54:24 --> Config Class Initialized
INFO - 2016-08-29 16:54:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:54:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:54:24 --> Utf8 Class Initialized
INFO - 2016-08-29 16:54:24 --> URI Class Initialized
INFO - 2016-08-29 16:54:24 --> Router Class Initialized
INFO - 2016-08-29 16:54:24 --> Output Class Initialized
INFO - 2016-08-29 16:54:24 --> Security Class Initialized
DEBUG - 2016-08-29 16:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:54:24 --> Input Class Initialized
INFO - 2016-08-29 16:54:24 --> Language Class Initialized
INFO - 2016-08-29 16:54:24 --> Loader Class Initialized
INFO - 2016-08-29 16:54:24 --> Helper loaded: url_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: html_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: form_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: file_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:54:24 --> Database Driver Class Initialized
INFO - 2016-08-29 16:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:54:24 --> Form Validation Class Initialized
INFO - 2016-08-29 16:54:24 --> Email Class Initialized
INFO - 2016-08-29 16:54:24 --> Controller Class Initialized
DEBUG - 2016-08-29 16:54:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:54:24 --> Model Class Initialized
INFO - 2016-08-29 16:54:24 --> Model Class Initialized
INFO - 2016-08-29 16:54:24 --> Config Class Initialized
INFO - 2016-08-29 16:54:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:54:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:54:24 --> Utf8 Class Initialized
INFO - 2016-08-29 16:54:24 --> URI Class Initialized
INFO - 2016-08-29 16:54:24 --> Router Class Initialized
INFO - 2016-08-29 16:54:24 --> Output Class Initialized
INFO - 2016-08-29 16:54:24 --> Security Class Initialized
DEBUG - 2016-08-29 16:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:54:24 --> Input Class Initialized
INFO - 2016-08-29 16:54:24 --> Language Class Initialized
INFO - 2016-08-29 16:54:24 --> Loader Class Initialized
INFO - 2016-08-29 16:54:24 --> Helper loaded: url_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: html_helper
INFO - 2016-08-29 16:54:24 --> Helper loaded: form_helper
INFO - 2016-08-29 16:54:25 --> Helper loaded: file_helper
INFO - 2016-08-29 16:54:25 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:54:25 --> Database Driver Class Initialized
INFO - 2016-08-29 16:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:54:25 --> Form Validation Class Initialized
INFO - 2016-08-29 16:54:25 --> Email Class Initialized
INFO - 2016-08-29 16:54:25 --> Controller Class Initialized
DEBUG - 2016-08-29 16:54:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:54:25 --> Model Class Initialized
INFO - 2016-08-29 16:54:25 --> Model Class Initialized
INFO - 2016-08-29 16:54:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:54:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:54:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:54:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:54:25 --> Final output sent to browser
DEBUG - 2016-08-29 16:54:25 --> Total execution time: 0.2953
INFO - 2016-08-29 16:54:43 --> Config Class Initialized
INFO - 2016-08-29 16:54:43 --> Hooks Class Initialized
DEBUG - 2016-08-29 16:54:43 --> UTF-8 Support Enabled
INFO - 2016-08-29 16:54:43 --> Utf8 Class Initialized
INFO - 2016-08-29 16:54:43 --> URI Class Initialized
INFO - 2016-08-29 16:54:43 --> Router Class Initialized
INFO - 2016-08-29 16:54:43 --> Output Class Initialized
INFO - 2016-08-29 16:54:43 --> Security Class Initialized
DEBUG - 2016-08-29 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 16:54:43 --> Input Class Initialized
INFO - 2016-08-29 16:54:43 --> Language Class Initialized
INFO - 2016-08-29 16:54:43 --> Loader Class Initialized
INFO - 2016-08-29 16:54:43 --> Helper loaded: url_helper
INFO - 2016-08-29 16:54:43 --> Helper loaded: utils_helper
INFO - 2016-08-29 16:54:43 --> Helper loaded: html_helper
INFO - 2016-08-29 16:54:43 --> Helper loaded: form_helper
INFO - 2016-08-29 16:54:43 --> Helper loaded: file_helper
INFO - 2016-08-29 16:54:43 --> Helper loaded: myemail_helper
INFO - 2016-08-29 16:54:43 --> Database Driver Class Initialized
INFO - 2016-08-29 16:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 16:54:43 --> Form Validation Class Initialized
INFO - 2016-08-29 16:54:43 --> Email Class Initialized
INFO - 2016-08-29 16:54:43 --> Controller Class Initialized
DEBUG - 2016-08-29 16:54:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 16:54:43 --> Model Class Initialized
INFO - 2016-08-29 16:54:43 --> Model Class Initialized
INFO - 2016-08-29 16:54:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 16:54:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 16:54:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 16:54:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 16:54:43 --> Final output sent to browser
DEBUG - 2016-08-29 16:54:43 --> Total execution time: 0.3356
INFO - 2016-08-29 17:01:41 --> Config Class Initialized
INFO - 2016-08-29 17:01:41 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:01:41 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:01:41 --> Utf8 Class Initialized
INFO - 2016-08-29 17:01:41 --> URI Class Initialized
INFO - 2016-08-29 17:01:41 --> Router Class Initialized
INFO - 2016-08-29 17:01:41 --> Output Class Initialized
INFO - 2016-08-29 17:01:41 --> Security Class Initialized
DEBUG - 2016-08-29 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:01:41 --> Input Class Initialized
INFO - 2016-08-29 17:01:41 --> Language Class Initialized
INFO - 2016-08-29 17:01:41 --> Loader Class Initialized
INFO - 2016-08-29 17:01:41 --> Helper loaded: url_helper
INFO - 2016-08-29 17:01:41 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:01:41 --> Helper loaded: html_helper
INFO - 2016-08-29 17:01:41 --> Helper loaded: form_helper
INFO - 2016-08-29 17:01:41 --> Helper loaded: file_helper
INFO - 2016-08-29 17:01:41 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:01:41 --> Database Driver Class Initialized
INFO - 2016-08-29 17:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:01:41 --> Form Validation Class Initialized
INFO - 2016-08-29 17:01:41 --> Email Class Initialized
INFO - 2016-08-29 17:01:41 --> Controller Class Initialized
DEBUG - 2016-08-29 17:01:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:01:41 --> Model Class Initialized
INFO - 2016-08-29 17:01:41 --> Model Class Initialized
INFO - 2016-08-29 17:01:41 --> Model Class Initialized
INFO - 2016-08-29 17:01:41 --> Model Class Initialized
INFO - 2016-08-29 17:01:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:01:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:01:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:01:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:01:41 --> Final output sent to browser
DEBUG - 2016-08-29 17:01:41 --> Total execution time: 0.3747
INFO - 2016-08-29 17:01:46 --> Config Class Initialized
INFO - 2016-08-29 17:01:46 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:01:47 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:01:47 --> Utf8 Class Initialized
INFO - 2016-08-29 17:01:47 --> URI Class Initialized
INFO - 2016-08-29 17:01:47 --> Router Class Initialized
INFO - 2016-08-29 17:01:47 --> Output Class Initialized
INFO - 2016-08-29 17:01:47 --> Security Class Initialized
DEBUG - 2016-08-29 17:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:01:47 --> Input Class Initialized
INFO - 2016-08-29 17:01:47 --> Language Class Initialized
INFO - 2016-08-29 17:01:47 --> Loader Class Initialized
INFO - 2016-08-29 17:01:47 --> Helper loaded: url_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: html_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: form_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: file_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:01:47 --> Database Driver Class Initialized
INFO - 2016-08-29 17:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:01:47 --> Form Validation Class Initialized
INFO - 2016-08-29 17:01:47 --> Email Class Initialized
INFO - 2016-08-29 17:01:47 --> Controller Class Initialized
DEBUG - 2016-08-29 17:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:01:47 --> Config Class Initialized
INFO - 2016-08-29 17:01:47 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:01:47 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:01:47 --> Utf8 Class Initialized
INFO - 2016-08-29 17:01:47 --> URI Class Initialized
INFO - 2016-08-29 17:01:47 --> Router Class Initialized
INFO - 2016-08-29 17:01:47 --> Output Class Initialized
INFO - 2016-08-29 17:01:47 --> Security Class Initialized
DEBUG - 2016-08-29 17:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:01:47 --> Input Class Initialized
INFO - 2016-08-29 17:01:47 --> Language Class Initialized
INFO - 2016-08-29 17:01:47 --> Loader Class Initialized
INFO - 2016-08-29 17:01:47 --> Helper loaded: url_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: html_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: form_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: file_helper
INFO - 2016-08-29 17:01:47 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:01:47 --> Database Driver Class Initialized
INFO - 2016-08-29 17:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:01:47 --> Form Validation Class Initialized
INFO - 2016-08-29 17:01:47 --> Email Class Initialized
INFO - 2016-08-29 17:01:47 --> Controller Class Initialized
DEBUG - 2016-08-29 17:01:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> Model Class Initialized
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 17:01:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:01:47 --> Final output sent to browser
DEBUG - 2016-08-29 17:01:47 --> Total execution time: 0.2904
INFO - 2016-08-29 17:01:51 --> Config Class Initialized
INFO - 2016-08-29 17:01:51 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:01:51 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:01:51 --> Utf8 Class Initialized
INFO - 2016-08-29 17:01:51 --> URI Class Initialized
INFO - 2016-08-29 17:01:51 --> Router Class Initialized
INFO - 2016-08-29 17:01:51 --> Output Class Initialized
INFO - 2016-08-29 17:01:51 --> Security Class Initialized
DEBUG - 2016-08-29 17:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:01:51 --> Input Class Initialized
INFO - 2016-08-29 17:01:51 --> Language Class Initialized
INFO - 2016-08-29 17:01:51 --> Loader Class Initialized
INFO - 2016-08-29 17:01:51 --> Helper loaded: url_helper
INFO - 2016-08-29 17:01:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:01:51 --> Helper loaded: html_helper
INFO - 2016-08-29 17:01:51 --> Helper loaded: form_helper
INFO - 2016-08-29 17:01:51 --> Helper loaded: file_helper
INFO - 2016-08-29 17:01:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:01:51 --> Database Driver Class Initialized
INFO - 2016-08-29 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:01:51 --> Form Validation Class Initialized
INFO - 2016-08-29 17:01:51 --> Email Class Initialized
INFO - 2016-08-29 17:01:51 --> Controller Class Initialized
DEBUG - 2016-08-29 17:01:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:01:51 --> Model Class Initialized
INFO - 2016-08-29 17:01:51 --> Model Class Initialized
INFO - 2016-08-29 17:01:51 --> Model Class Initialized
INFO - 2016-08-29 17:01:51 --> Model Class Initialized
INFO - 2016-08-29 17:01:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:01:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:01:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:01:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:01:51 --> Final output sent to browser
DEBUG - 2016-08-29 17:01:51 --> Total execution time: 0.3162
INFO - 2016-08-29 17:01:55 --> Config Class Initialized
INFO - 2016-08-29 17:01:55 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:01:55 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:01:55 --> Utf8 Class Initialized
INFO - 2016-08-29 17:01:55 --> URI Class Initialized
INFO - 2016-08-29 17:01:55 --> Router Class Initialized
INFO - 2016-08-29 17:01:55 --> Output Class Initialized
INFO - 2016-08-29 17:01:55 --> Security Class Initialized
DEBUG - 2016-08-29 17:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:01:55 --> Input Class Initialized
INFO - 2016-08-29 17:01:55 --> Language Class Initialized
INFO - 2016-08-29 17:01:55 --> Loader Class Initialized
INFO - 2016-08-29 17:01:55 --> Helper loaded: url_helper
INFO - 2016-08-29 17:01:55 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:01:55 --> Helper loaded: html_helper
INFO - 2016-08-29 17:01:55 --> Helper loaded: form_helper
INFO - 2016-08-29 17:01:55 --> Helper loaded: file_helper
INFO - 2016-08-29 17:01:55 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:01:55 --> Database Driver Class Initialized
INFO - 2016-08-29 17:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:01:55 --> Form Validation Class Initialized
INFO - 2016-08-29 17:01:55 --> Email Class Initialized
INFO - 2016-08-29 17:01:55 --> Controller Class Initialized
DEBUG - 2016-08-29 17:01:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:01:55 --> Model Class Initialized
INFO - 2016-08-29 17:01:55 --> Model Class Initialized
INFO - 2016-08-29 17:01:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:01:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:01:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:01:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:01:55 --> Final output sent to browser
DEBUG - 2016-08-29 17:01:55 --> Total execution time: 0.3082
INFO - 2016-08-29 17:02:12 --> Config Class Initialized
INFO - 2016-08-29 17:02:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:02:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:02:12 --> Utf8 Class Initialized
INFO - 2016-08-29 17:02:12 --> URI Class Initialized
INFO - 2016-08-29 17:02:12 --> Router Class Initialized
INFO - 2016-08-29 17:02:12 --> Output Class Initialized
INFO - 2016-08-29 17:02:12 --> Security Class Initialized
DEBUG - 2016-08-29 17:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:02:12 --> Input Class Initialized
INFO - 2016-08-29 17:02:12 --> Language Class Initialized
INFO - 2016-08-29 17:02:12 --> Loader Class Initialized
INFO - 2016-08-29 17:02:12 --> Helper loaded: url_helper
INFO - 2016-08-29 17:02:12 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:02:12 --> Helper loaded: html_helper
INFO - 2016-08-29 17:02:12 --> Helper loaded: form_helper
INFO - 2016-08-29 17:02:12 --> Helper loaded: file_helper
INFO - 2016-08-29 17:02:12 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:02:12 --> Database Driver Class Initialized
INFO - 2016-08-29 17:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:02:12 --> Form Validation Class Initialized
INFO - 2016-08-29 17:02:12 --> Email Class Initialized
INFO - 2016-08-29 17:02:12 --> Controller Class Initialized
DEBUG - 2016-08-29 17:02:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:02:12 --> Model Class Initialized
INFO - 2016-08-29 17:02:12 --> Model Class Initialized
INFO - 2016-08-29 17:02:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:02:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:02:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:02:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:02:12 --> Final output sent to browser
DEBUG - 2016-08-29 17:02:12 --> Total execution time: 0.2964
INFO - 2016-08-29 17:02:45 --> Config Class Initialized
INFO - 2016-08-29 17:02:45 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:02:45 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:02:45 --> Utf8 Class Initialized
INFO - 2016-08-29 17:02:45 --> URI Class Initialized
INFO - 2016-08-29 17:02:45 --> Router Class Initialized
INFO - 2016-08-29 17:02:45 --> Output Class Initialized
INFO - 2016-08-29 17:02:45 --> Security Class Initialized
DEBUG - 2016-08-29 17:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:02:45 --> Input Class Initialized
INFO - 2016-08-29 17:02:45 --> Language Class Initialized
INFO - 2016-08-29 17:02:45 --> Loader Class Initialized
INFO - 2016-08-29 17:02:45 --> Helper loaded: url_helper
INFO - 2016-08-29 17:02:45 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:02:45 --> Helper loaded: html_helper
INFO - 2016-08-29 17:02:45 --> Helper loaded: form_helper
INFO - 2016-08-29 17:02:45 --> Helper loaded: file_helper
INFO - 2016-08-29 17:02:45 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:02:45 --> Database Driver Class Initialized
INFO - 2016-08-29 17:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:02:45 --> Form Validation Class Initialized
INFO - 2016-08-29 17:02:45 --> Email Class Initialized
INFO - 2016-08-29 17:02:45 --> Controller Class Initialized
DEBUG - 2016-08-29 17:02:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:02:45 --> Model Class Initialized
INFO - 2016-08-29 17:02:45 --> Model Class Initialized
INFO - 2016-08-29 17:02:45 --> Model Class Initialized
INFO - 2016-08-29 17:02:45 --> Model Class Initialized
INFO - 2016-08-29 17:02:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:02:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:02:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:02:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:02:45 --> Final output sent to browser
DEBUG - 2016-08-29 17:02:45 --> Total execution time: 0.3217
INFO - 2016-08-29 17:02:54 --> Config Class Initialized
INFO - 2016-08-29 17:02:54 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:02:54 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:02:54 --> Utf8 Class Initialized
INFO - 2016-08-29 17:02:54 --> URI Class Initialized
INFO - 2016-08-29 17:02:54 --> Router Class Initialized
INFO - 2016-08-29 17:02:54 --> Output Class Initialized
INFO - 2016-08-29 17:02:54 --> Security Class Initialized
DEBUG - 2016-08-29 17:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:02:54 --> Input Class Initialized
INFO - 2016-08-29 17:02:54 --> Language Class Initialized
INFO - 2016-08-29 17:02:54 --> Loader Class Initialized
INFO - 2016-08-29 17:02:54 --> Helper loaded: url_helper
INFO - 2016-08-29 17:02:54 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:02:54 --> Helper loaded: html_helper
INFO - 2016-08-29 17:02:54 --> Helper loaded: form_helper
INFO - 2016-08-29 17:02:54 --> Helper loaded: file_helper
INFO - 2016-08-29 17:02:54 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:02:54 --> Database Driver Class Initialized
INFO - 2016-08-29 17:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:02:54 --> Form Validation Class Initialized
INFO - 2016-08-29 17:02:54 --> Email Class Initialized
INFO - 2016-08-29 17:02:54 --> Controller Class Initialized
DEBUG - 2016-08-29 17:02:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:02:54 --> Model Class Initialized
INFO - 2016-08-29 17:02:54 --> Model Class Initialized
INFO - 2016-08-29 17:02:54 --> Model Class Initialized
INFO - 2016-08-29 17:02:54 --> Model Class Initialized
INFO - 2016-08-29 17:02:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:02:55 --> Config Class Initialized
INFO - 2016-08-29 17:02:55 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:02:55 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:02:55 --> Utf8 Class Initialized
INFO - 2016-08-29 17:02:55 --> URI Class Initialized
INFO - 2016-08-29 17:02:55 --> Router Class Initialized
INFO - 2016-08-29 17:02:55 --> Output Class Initialized
INFO - 2016-08-29 17:02:55 --> Security Class Initialized
DEBUG - 2016-08-29 17:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:02:55 --> Input Class Initialized
INFO - 2016-08-29 17:02:55 --> Language Class Initialized
INFO - 2016-08-29 17:02:55 --> Loader Class Initialized
INFO - 2016-08-29 17:02:55 --> Helper loaded: url_helper
INFO - 2016-08-29 17:02:55 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:02:55 --> Helper loaded: html_helper
INFO - 2016-08-29 17:02:55 --> Helper loaded: form_helper
INFO - 2016-08-29 17:02:55 --> Helper loaded: file_helper
INFO - 2016-08-29 17:02:55 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:02:55 --> Database Driver Class Initialized
INFO - 2016-08-29 17:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:02:55 --> Form Validation Class Initialized
INFO - 2016-08-29 17:02:55 --> Email Class Initialized
INFO - 2016-08-29 17:02:55 --> Controller Class Initialized
DEBUG - 2016-08-29 17:02:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:02:55 --> Model Class Initialized
INFO - 2016-08-29 17:02:55 --> Model Class Initialized
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 17:02:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:02:55 --> Final output sent to browser
DEBUG - 2016-08-29 17:02:55 --> Total execution time: 0.3314
INFO - 2016-08-29 17:03:38 --> Config Class Initialized
INFO - 2016-08-29 17:03:38 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:03:38 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:03:38 --> Utf8 Class Initialized
INFO - 2016-08-29 17:03:38 --> URI Class Initialized
INFO - 2016-08-29 17:03:38 --> Router Class Initialized
INFO - 2016-08-29 17:03:38 --> Output Class Initialized
INFO - 2016-08-29 17:03:38 --> Security Class Initialized
DEBUG - 2016-08-29 17:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:03:38 --> Input Class Initialized
INFO - 2016-08-29 17:03:38 --> Language Class Initialized
INFO - 2016-08-29 17:03:38 --> Loader Class Initialized
INFO - 2016-08-29 17:03:38 --> Helper loaded: url_helper
INFO - 2016-08-29 17:03:38 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:03:38 --> Helper loaded: html_helper
INFO - 2016-08-29 17:03:38 --> Helper loaded: form_helper
INFO - 2016-08-29 17:03:38 --> Helper loaded: file_helper
INFO - 2016-08-29 17:03:38 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:03:38 --> Database Driver Class Initialized
INFO - 2016-08-29 17:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:03:38 --> Form Validation Class Initialized
INFO - 2016-08-29 17:03:38 --> Email Class Initialized
INFO - 2016-08-29 17:03:38 --> Controller Class Initialized
DEBUG - 2016-08-29 17:03:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:03:38 --> Model Class Initialized
INFO - 2016-08-29 17:03:38 --> Model Class Initialized
INFO - 2016-08-29 17:03:38 --> Model Class Initialized
INFO - 2016-08-29 17:03:38 --> Model Class Initialized
INFO - 2016-08-29 17:03:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:03:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:03:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:03:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:03:38 --> Final output sent to browser
DEBUG - 2016-08-29 17:03:38 --> Total execution time: 0.3222
INFO - 2016-08-29 17:03:42 --> Config Class Initialized
INFO - 2016-08-29 17:03:42 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:03:42 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:03:42 --> Utf8 Class Initialized
INFO - 2016-08-29 17:03:42 --> URI Class Initialized
INFO - 2016-08-29 17:03:42 --> Router Class Initialized
INFO - 2016-08-29 17:03:42 --> Output Class Initialized
INFO - 2016-08-29 17:03:42 --> Security Class Initialized
DEBUG - 2016-08-29 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:03:42 --> Input Class Initialized
INFO - 2016-08-29 17:03:42 --> Language Class Initialized
INFO - 2016-08-29 17:03:42 --> Loader Class Initialized
INFO - 2016-08-29 17:03:42 --> Helper loaded: url_helper
INFO - 2016-08-29 17:03:42 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:03:42 --> Helper loaded: html_helper
INFO - 2016-08-29 17:03:42 --> Helper loaded: form_helper
INFO - 2016-08-29 17:03:42 --> Helper loaded: file_helper
INFO - 2016-08-29 17:03:42 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:03:42 --> Database Driver Class Initialized
INFO - 2016-08-29 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:03:42 --> Form Validation Class Initialized
INFO - 2016-08-29 17:03:42 --> Email Class Initialized
INFO - 2016-08-29 17:03:42 --> Controller Class Initialized
DEBUG - 2016-08-29 17:03:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:03:42 --> Model Class Initialized
INFO - 2016-08-29 17:03:42 --> Model Class Initialized
INFO - 2016-08-29 17:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:03:42 --> Final output sent to browser
DEBUG - 2016-08-29 17:03:42 --> Total execution time: 0.3195
INFO - 2016-08-29 17:09:23 --> Config Class Initialized
INFO - 2016-08-29 17:09:23 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:09:23 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:09:23 --> Utf8 Class Initialized
INFO - 2016-08-29 17:09:23 --> URI Class Initialized
INFO - 2016-08-29 17:09:23 --> Router Class Initialized
INFO - 2016-08-29 17:09:23 --> Output Class Initialized
INFO - 2016-08-29 17:09:23 --> Security Class Initialized
DEBUG - 2016-08-29 17:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:09:23 --> Input Class Initialized
INFO - 2016-08-29 17:09:23 --> Language Class Initialized
INFO - 2016-08-29 17:09:23 --> Loader Class Initialized
INFO - 2016-08-29 17:09:23 --> Helper loaded: url_helper
INFO - 2016-08-29 17:09:23 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:09:23 --> Helper loaded: html_helper
INFO - 2016-08-29 17:09:23 --> Helper loaded: form_helper
INFO - 2016-08-29 17:09:23 --> Helper loaded: file_helper
INFO - 2016-08-29 17:09:23 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:09:23 --> Database Driver Class Initialized
INFO - 2016-08-29 17:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:09:24 --> Form Validation Class Initialized
INFO - 2016-08-29 17:09:24 --> Email Class Initialized
INFO - 2016-08-29 17:09:24 --> Controller Class Initialized
DEBUG - 2016-08-29 17:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:09:24 --> Model Class Initialized
INFO - 2016-08-29 17:09:24 --> Model Class Initialized
INFO - 2016-08-29 17:09:24 --> Config Class Initialized
INFO - 2016-08-29 17:09:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:09:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:09:24 --> Utf8 Class Initialized
INFO - 2016-08-29 17:09:24 --> URI Class Initialized
INFO - 2016-08-29 17:09:24 --> Router Class Initialized
INFO - 2016-08-29 17:09:24 --> Output Class Initialized
INFO - 2016-08-29 17:09:24 --> Security Class Initialized
DEBUG - 2016-08-29 17:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:09:24 --> Input Class Initialized
INFO - 2016-08-29 17:09:24 --> Language Class Initialized
INFO - 2016-08-29 17:09:24 --> Loader Class Initialized
INFO - 2016-08-29 17:09:24 --> Helper loaded: url_helper
INFO - 2016-08-29 17:09:24 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:09:24 --> Helper loaded: html_helper
INFO - 2016-08-29 17:09:24 --> Helper loaded: form_helper
INFO - 2016-08-29 17:09:24 --> Helper loaded: file_helper
INFO - 2016-08-29 17:09:24 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:09:24 --> Database Driver Class Initialized
INFO - 2016-08-29 17:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:09:24 --> Form Validation Class Initialized
INFO - 2016-08-29 17:09:24 --> Email Class Initialized
INFO - 2016-08-29 17:09:24 --> Controller Class Initialized
DEBUG - 2016-08-29 17:09:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:09:24 --> Model Class Initialized
INFO - 2016-08-29 17:09:24 --> Model Class Initialized
INFO - 2016-08-29 17:09:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:09:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:09:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:09:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:09:24 --> Final output sent to browser
DEBUG - 2016-08-29 17:09:24 --> Total execution time: 0.3390
INFO - 2016-08-29 17:11:09 --> Config Class Initialized
INFO - 2016-08-29 17:11:09 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:11:09 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:11:09 --> Utf8 Class Initialized
INFO - 2016-08-29 17:11:09 --> URI Class Initialized
INFO - 2016-08-29 17:11:09 --> Router Class Initialized
INFO - 2016-08-29 17:11:09 --> Output Class Initialized
INFO - 2016-08-29 17:11:09 --> Security Class Initialized
DEBUG - 2016-08-29 17:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:11:09 --> Input Class Initialized
INFO - 2016-08-29 17:11:09 --> Language Class Initialized
INFO - 2016-08-29 17:11:09 --> Loader Class Initialized
INFO - 2016-08-29 17:11:09 --> Helper loaded: url_helper
INFO - 2016-08-29 17:11:09 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:11:09 --> Helper loaded: html_helper
INFO - 2016-08-29 17:11:09 --> Helper loaded: form_helper
INFO - 2016-08-29 17:11:09 --> Helper loaded: file_helper
INFO - 2016-08-29 17:11:09 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:11:09 --> Database Driver Class Initialized
INFO - 2016-08-29 17:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:11:09 --> Form Validation Class Initialized
INFO - 2016-08-29 17:11:09 --> Email Class Initialized
INFO - 2016-08-29 17:11:09 --> Controller Class Initialized
DEBUG - 2016-08-29 17:11:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:11:09 --> Model Class Initialized
INFO - 2016-08-29 17:11:09 --> Model Class Initialized
INFO - 2016-08-29 17:11:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:11:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:11:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:11:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:11:09 --> Final output sent to browser
DEBUG - 2016-08-29 17:11:09 --> Total execution time: 0.3298
INFO - 2016-08-29 17:12:03 --> Config Class Initialized
INFO - 2016-08-29 17:12:03 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:12:03 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:12:03 --> Utf8 Class Initialized
INFO - 2016-08-29 17:12:03 --> URI Class Initialized
INFO - 2016-08-29 17:12:03 --> Router Class Initialized
INFO - 2016-08-29 17:12:03 --> Output Class Initialized
INFO - 2016-08-29 17:12:03 --> Security Class Initialized
DEBUG - 2016-08-29 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:12:03 --> Input Class Initialized
INFO - 2016-08-29 17:12:03 --> Language Class Initialized
INFO - 2016-08-29 17:12:03 --> Loader Class Initialized
INFO - 2016-08-29 17:12:03 --> Helper loaded: url_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: html_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: form_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: file_helper
INFO - 2016-08-29 17:12:03 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:12:03 --> Database Driver Class Initialized
INFO - 2016-08-29 17:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:12:03 --> Form Validation Class Initialized
INFO - 2016-08-29 17:12:03 --> Email Class Initialized
INFO - 2016-08-29 17:12:03 --> Controller Class Initialized
DEBUG - 2016-08-29 17:12:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:12:03 --> Model Class Initialized
INFO - 2016-08-29 17:12:03 --> Model Class Initialized
INFO - 2016-08-29 17:12:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:12:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:12:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-29 17:12:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:12:03 --> Final output sent to browser
DEBUG - 2016-08-29 17:12:03 --> Total execution time: 0.3222
INFO - 2016-08-29 17:12:11 --> Config Class Initialized
INFO - 2016-08-29 17:12:11 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:12:11 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:12:11 --> Utf8 Class Initialized
INFO - 2016-08-29 17:12:11 --> URI Class Initialized
INFO - 2016-08-29 17:12:11 --> Router Class Initialized
INFO - 2016-08-29 17:12:11 --> Output Class Initialized
INFO - 2016-08-29 17:12:11 --> Security Class Initialized
DEBUG - 2016-08-29 17:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:12:11 --> Input Class Initialized
INFO - 2016-08-29 17:12:11 --> Language Class Initialized
INFO - 2016-08-29 17:12:11 --> Loader Class Initialized
INFO - 2016-08-29 17:12:11 --> Helper loaded: url_helper
INFO - 2016-08-29 17:12:11 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:12:11 --> Helper loaded: html_helper
INFO - 2016-08-29 17:12:11 --> Helper loaded: form_helper
INFO - 2016-08-29 17:12:11 --> Helper loaded: file_helper
INFO - 2016-08-29 17:12:11 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:12:11 --> Database Driver Class Initialized
INFO - 2016-08-29 17:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:12:12 --> Form Validation Class Initialized
INFO - 2016-08-29 17:12:12 --> Email Class Initialized
INFO - 2016-08-29 17:12:12 --> Controller Class Initialized
DEBUG - 2016-08-29 17:12:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:12:12 --> Model Class Initialized
INFO - 2016-08-29 17:12:12 --> Model Class Initialized
INFO - 2016-08-29 17:12:12 --> Config Class Initialized
INFO - 2016-08-29 17:12:12 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:12:12 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:12:12 --> Utf8 Class Initialized
INFO - 2016-08-29 17:12:12 --> URI Class Initialized
INFO - 2016-08-29 17:12:12 --> Router Class Initialized
INFO - 2016-08-29 17:12:12 --> Output Class Initialized
INFO - 2016-08-29 17:12:12 --> Security Class Initialized
DEBUG - 2016-08-29 17:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:12:12 --> Input Class Initialized
INFO - 2016-08-29 17:12:12 --> Language Class Initialized
INFO - 2016-08-29 17:12:12 --> Loader Class Initialized
INFO - 2016-08-29 17:12:12 --> Helper loaded: url_helper
INFO - 2016-08-29 17:12:12 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:12:12 --> Helper loaded: html_helper
INFO - 2016-08-29 17:12:12 --> Helper loaded: form_helper
INFO - 2016-08-29 17:12:12 --> Helper loaded: file_helper
INFO - 2016-08-29 17:12:12 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:12:12 --> Database Driver Class Initialized
INFO - 2016-08-29 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:12:12 --> Form Validation Class Initialized
INFO - 2016-08-29 17:12:12 --> Email Class Initialized
INFO - 2016-08-29 17:12:12 --> Controller Class Initialized
DEBUG - 2016-08-29 17:12:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:12:12 --> Model Class Initialized
INFO - 2016-08-29 17:12:12 --> Model Class Initialized
INFO - 2016-08-29 17:12:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:12:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:12:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:12:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:12:12 --> Final output sent to browser
DEBUG - 2016-08-29 17:12:12 --> Total execution time: 0.3104
INFO - 2016-08-29 17:12:52 --> Config Class Initialized
INFO - 2016-08-29 17:12:52 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:12:52 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:12:52 --> Utf8 Class Initialized
INFO - 2016-08-29 17:12:52 --> URI Class Initialized
INFO - 2016-08-29 17:12:52 --> Router Class Initialized
INFO - 2016-08-29 17:12:52 --> Output Class Initialized
INFO - 2016-08-29 17:12:52 --> Security Class Initialized
DEBUG - 2016-08-29 17:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:12:52 --> Input Class Initialized
INFO - 2016-08-29 17:12:52 --> Language Class Initialized
INFO - 2016-08-29 17:12:52 --> Loader Class Initialized
INFO - 2016-08-29 17:12:52 --> Helper loaded: url_helper
INFO - 2016-08-29 17:12:52 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:12:52 --> Helper loaded: html_helper
INFO - 2016-08-29 17:12:52 --> Helper loaded: form_helper
INFO - 2016-08-29 17:12:52 --> Helper loaded: file_helper
INFO - 2016-08-29 17:12:52 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:12:52 --> Database Driver Class Initialized
INFO - 2016-08-29 17:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:12:52 --> Form Validation Class Initialized
INFO - 2016-08-29 17:12:52 --> Email Class Initialized
INFO - 2016-08-29 17:12:52 --> Controller Class Initialized
DEBUG - 2016-08-29 17:12:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:12:52 --> Model Class Initialized
INFO - 2016-08-29 17:12:52 --> Model Class Initialized
INFO - 2016-08-29 17:12:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:12:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:12:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:12:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:12:52 --> Final output sent to browser
DEBUG - 2016-08-29 17:12:52 --> Total execution time: 0.3217
INFO - 2016-08-29 17:13:01 --> Config Class Initialized
INFO - 2016-08-29 17:13:01 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:13:01 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:13:01 --> Utf8 Class Initialized
INFO - 2016-08-29 17:13:01 --> URI Class Initialized
INFO - 2016-08-29 17:13:01 --> Router Class Initialized
INFO - 2016-08-29 17:13:01 --> Output Class Initialized
INFO - 2016-08-29 17:13:01 --> Security Class Initialized
DEBUG - 2016-08-29 17:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:13:01 --> Input Class Initialized
INFO - 2016-08-29 17:13:01 --> Language Class Initialized
INFO - 2016-08-29 17:13:01 --> Loader Class Initialized
INFO - 2016-08-29 17:13:01 --> Helper loaded: url_helper
INFO - 2016-08-29 17:13:01 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:13:01 --> Helper loaded: html_helper
INFO - 2016-08-29 17:13:01 --> Helper loaded: form_helper
INFO - 2016-08-29 17:13:01 --> Helper loaded: file_helper
INFO - 2016-08-29 17:13:01 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:13:01 --> Database Driver Class Initialized
INFO - 2016-08-29 17:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:13:01 --> Form Validation Class Initialized
INFO - 2016-08-29 17:13:01 --> Email Class Initialized
INFO - 2016-08-29 17:13:01 --> Controller Class Initialized
DEBUG - 2016-08-29 17:13:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:13:01 --> Model Class Initialized
INFO - 2016-08-29 17:13:01 --> Model Class Initialized
ERROR - 2016-08-29 17:13:01 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: DELETE FROM `bookss`
WHERE `b_id` = '143'
INFO - 2016-08-29 17:13:01 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:13:48 --> Config Class Initialized
INFO - 2016-08-29 17:13:48 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:13:48 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:13:48 --> Utf8 Class Initialized
INFO - 2016-08-29 17:13:48 --> URI Class Initialized
INFO - 2016-08-29 17:13:48 --> Router Class Initialized
INFO - 2016-08-29 17:13:48 --> Output Class Initialized
INFO - 2016-08-29 17:13:48 --> Security Class Initialized
DEBUG - 2016-08-29 17:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:13:48 --> Input Class Initialized
INFO - 2016-08-29 17:13:48 --> Language Class Initialized
INFO - 2016-08-29 17:13:48 --> Loader Class Initialized
INFO - 2016-08-29 17:13:48 --> Helper loaded: url_helper
INFO - 2016-08-29 17:13:48 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:13:48 --> Helper loaded: html_helper
INFO - 2016-08-29 17:13:48 --> Helper loaded: form_helper
INFO - 2016-08-29 17:13:48 --> Helper loaded: file_helper
INFO - 2016-08-29 17:13:48 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:13:48 --> Database Driver Class Initialized
INFO - 2016-08-29 17:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:13:48 --> Form Validation Class Initialized
INFO - 2016-08-29 17:13:48 --> Email Class Initialized
INFO - 2016-08-29 17:13:48 --> Controller Class Initialized
DEBUG - 2016-08-29 17:13:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:13:48 --> Model Class Initialized
INFO - 2016-08-29 17:13:48 --> Model Class Initialized
INFO - 2016-08-29 17:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:13:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:13:48 --> Final output sent to browser
DEBUG - 2016-08-29 17:13:48 --> Total execution time: 0.3367
INFO - 2016-08-29 17:13:50 --> Config Class Initialized
INFO - 2016-08-29 17:13:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:13:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:13:50 --> Utf8 Class Initialized
INFO - 2016-08-29 17:13:50 --> URI Class Initialized
INFO - 2016-08-29 17:13:50 --> Router Class Initialized
INFO - 2016-08-29 17:13:50 --> Output Class Initialized
INFO - 2016-08-29 17:13:50 --> Security Class Initialized
DEBUG - 2016-08-29 17:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:13:50 --> Input Class Initialized
INFO - 2016-08-29 17:13:50 --> Language Class Initialized
INFO - 2016-08-29 17:13:50 --> Loader Class Initialized
INFO - 2016-08-29 17:13:50 --> Helper loaded: url_helper
INFO - 2016-08-29 17:13:50 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:13:50 --> Helper loaded: html_helper
INFO - 2016-08-29 17:13:50 --> Helper loaded: form_helper
INFO - 2016-08-29 17:13:50 --> Helper loaded: file_helper
INFO - 2016-08-29 17:13:50 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:13:50 --> Database Driver Class Initialized
INFO - 2016-08-29 17:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:13:50 --> Form Validation Class Initialized
INFO - 2016-08-29 17:13:50 --> Email Class Initialized
INFO - 2016-08-29 17:13:50 --> Controller Class Initialized
DEBUG - 2016-08-29 17:13:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:13:50 --> Model Class Initialized
INFO - 2016-08-29 17:13:50 --> Model Class Initialized
INFO - 2016-08-29 17:13:50 --> Model Class Initialized
INFO - 2016-08-29 17:13:50 --> Model Class Initialized
INFO - 2016-08-29 17:13:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:13:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:13:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:13:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:13:50 --> Final output sent to browser
DEBUG - 2016-08-29 17:13:50 --> Total execution time: 0.3388
INFO - 2016-08-29 17:13:55 --> Config Class Initialized
INFO - 2016-08-29 17:13:55 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:13:55 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:13:55 --> Utf8 Class Initialized
INFO - 2016-08-29 17:13:55 --> URI Class Initialized
INFO - 2016-08-29 17:13:55 --> Router Class Initialized
INFO - 2016-08-29 17:13:55 --> Output Class Initialized
INFO - 2016-08-29 17:13:55 --> Security Class Initialized
DEBUG - 2016-08-29 17:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:13:55 --> Input Class Initialized
INFO - 2016-08-29 17:13:55 --> Language Class Initialized
INFO - 2016-08-29 17:13:55 --> Loader Class Initialized
INFO - 2016-08-29 17:13:55 --> Helper loaded: url_helper
INFO - 2016-08-29 17:13:55 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:13:55 --> Helper loaded: html_helper
INFO - 2016-08-29 17:13:55 --> Helper loaded: form_helper
INFO - 2016-08-29 17:13:55 --> Helper loaded: file_helper
INFO - 2016-08-29 17:13:55 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:13:55 --> Database Driver Class Initialized
INFO - 2016-08-29 17:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:13:55 --> Form Validation Class Initialized
INFO - 2016-08-29 17:13:55 --> Email Class Initialized
INFO - 2016-08-29 17:13:55 --> Controller Class Initialized
DEBUG - 2016-08-29 17:13:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:13:55 --> Model Class Initialized
INFO - 2016-08-29 17:13:55 --> Model Class Initialized
INFO - 2016-08-29 17:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:13:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:13:55 --> Final output sent to browser
DEBUG - 2016-08-29 17:13:55 --> Total execution time: 0.3356
INFO - 2016-08-29 17:14:19 --> Config Class Initialized
INFO - 2016-08-29 17:14:19 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:19 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:19 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:19 --> URI Class Initialized
INFO - 2016-08-29 17:14:19 --> Router Class Initialized
INFO - 2016-08-29 17:14:19 --> Output Class Initialized
INFO - 2016-08-29 17:14:19 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:19 --> Input Class Initialized
INFO - 2016-08-29 17:14:19 --> Language Class Initialized
INFO - 2016-08-29 17:14:19 --> Loader Class Initialized
INFO - 2016-08-29 17:14:19 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:19 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:19 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:19 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:19 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:19 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:19 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:19 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:19 --> Email Class Initialized
INFO - 2016-08-29 17:14:19 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:19 --> Model Class Initialized
INFO - 2016-08-29 17:14:19 --> Model Class Initialized
ERROR - 2016-08-29 17:14:19 --> Query error: Table 'pnc_library.bookss' doesn't exist - Invalid query: DELETE FROM `bookss`
WHERE `b_id` = '144'
INFO - 2016-08-29 17:14:19 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:14:34 --> Config Class Initialized
INFO - 2016-08-29 17:14:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:34 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:34 --> URI Class Initialized
INFO - 2016-08-29 17:14:34 --> Router Class Initialized
INFO - 2016-08-29 17:14:34 --> Output Class Initialized
INFO - 2016-08-29 17:14:34 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:34 --> Input Class Initialized
INFO - 2016-08-29 17:14:34 --> Language Class Initialized
INFO - 2016-08-29 17:14:34 --> Loader Class Initialized
INFO - 2016-08-29 17:14:34 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:34 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:34 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:34 --> Email Class Initialized
INFO - 2016-08-29 17:14:34 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:34 --> Model Class Initialized
INFO - 2016-08-29 17:14:34 --> Model Class Initialized
INFO - 2016-08-29 17:14:34 --> Config Class Initialized
INFO - 2016-08-29 17:14:34 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:34 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:34 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:34 --> URI Class Initialized
INFO - 2016-08-29 17:14:34 --> Router Class Initialized
INFO - 2016-08-29 17:14:34 --> Output Class Initialized
INFO - 2016-08-29 17:14:34 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:34 --> Input Class Initialized
INFO - 2016-08-29 17:14:34 --> Language Class Initialized
INFO - 2016-08-29 17:14:34 --> Loader Class Initialized
INFO - 2016-08-29 17:14:34 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:34 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:35 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:35 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:35 --> Email Class Initialized
INFO - 2016-08-29 17:14:35 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:35 --> Model Class Initialized
INFO - 2016-08-29 17:14:35 --> Model Class Initialized
INFO - 2016-08-29 17:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:14:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:14:35 --> Final output sent to browser
DEBUG - 2016-08-29 17:14:35 --> Total execution time: 0.3226
INFO - 2016-08-29 17:14:40 --> Config Class Initialized
INFO - 2016-08-29 17:14:40 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:40 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:40 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:40 --> URI Class Initialized
INFO - 2016-08-29 17:14:40 --> Router Class Initialized
INFO - 2016-08-29 17:14:40 --> Output Class Initialized
INFO - 2016-08-29 17:14:40 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:40 --> Input Class Initialized
INFO - 2016-08-29 17:14:40 --> Language Class Initialized
INFO - 2016-08-29 17:14:40 --> Loader Class Initialized
INFO - 2016-08-29 17:14:40 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:40 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:40 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:40 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:40 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:40 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:40 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:40 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:40 --> Email Class Initialized
INFO - 2016-08-29 17:14:40 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:40 --> Model Class Initialized
INFO - 2016-08-29 17:14:40 --> Model Class Initialized
INFO - 2016-08-29 17:14:40 --> Model Class Initialized
INFO - 2016-08-29 17:14:40 --> Model Class Initialized
INFO - 2016-08-29 17:14:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:14:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:14:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:14:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:14:41 --> Final output sent to browser
DEBUG - 2016-08-29 17:14:41 --> Total execution time: 0.3514
INFO - 2016-08-29 17:14:46 --> Config Class Initialized
INFO - 2016-08-29 17:14:46 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:46 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:46 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:46 --> URI Class Initialized
INFO - 2016-08-29 17:14:46 --> Router Class Initialized
INFO - 2016-08-29 17:14:46 --> Output Class Initialized
INFO - 2016-08-29 17:14:46 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:46 --> Input Class Initialized
INFO - 2016-08-29 17:14:46 --> Language Class Initialized
INFO - 2016-08-29 17:14:46 --> Loader Class Initialized
INFO - 2016-08-29 17:14:46 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:46 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:46 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:46 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:46 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:46 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:46 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:46 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:46 --> Email Class Initialized
INFO - 2016-08-29 17:14:46 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:46 --> Model Class Initialized
INFO - 2016-08-29 17:14:46 --> Model Class Initialized
INFO - 2016-08-29 17:14:46 --> Model Class Initialized
INFO - 2016-08-29 17:14:46 --> Model Class Initialized
INFO - 2016-08-29 17:14:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:14:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:14:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:14:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:14:47 --> Config Class Initialized
INFO - 2016-08-29 17:14:47 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:14:47 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:14:47 --> Utf8 Class Initialized
INFO - 2016-08-29 17:14:47 --> URI Class Initialized
INFO - 2016-08-29 17:14:47 --> Router Class Initialized
INFO - 2016-08-29 17:14:47 --> Output Class Initialized
INFO - 2016-08-29 17:14:47 --> Security Class Initialized
DEBUG - 2016-08-29 17:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:14:47 --> Input Class Initialized
INFO - 2016-08-29 17:14:47 --> Language Class Initialized
INFO - 2016-08-29 17:14:47 --> Loader Class Initialized
INFO - 2016-08-29 17:14:47 --> Helper loaded: url_helper
INFO - 2016-08-29 17:14:47 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:14:47 --> Helper loaded: html_helper
INFO - 2016-08-29 17:14:47 --> Helper loaded: form_helper
INFO - 2016-08-29 17:14:47 --> Helper loaded: file_helper
INFO - 2016-08-29 17:14:47 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:14:47 --> Database Driver Class Initialized
INFO - 2016-08-29 17:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:14:47 --> Form Validation Class Initialized
INFO - 2016-08-29 17:14:47 --> Email Class Initialized
INFO - 2016-08-29 17:14:47 --> Controller Class Initialized
DEBUG - 2016-08-29 17:14:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:14:47 --> Model Class Initialized
INFO - 2016-08-29 17:14:47 --> Model Class Initialized
INFO - 2016-08-29 17:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:14:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:14:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 17:14:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:14:48 --> Final output sent to browser
DEBUG - 2016-08-29 17:14:48 --> Total execution time: 0.3344
INFO - 2016-08-29 17:15:00 --> Config Class Initialized
INFO - 2016-08-29 17:15:00 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:15:00 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:15:00 --> Utf8 Class Initialized
INFO - 2016-08-29 17:15:00 --> URI Class Initialized
INFO - 2016-08-29 17:15:00 --> Router Class Initialized
INFO - 2016-08-29 17:15:00 --> Output Class Initialized
INFO - 2016-08-29 17:15:00 --> Security Class Initialized
DEBUG - 2016-08-29 17:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:15:00 --> Input Class Initialized
INFO - 2016-08-29 17:15:00 --> Language Class Initialized
INFO - 2016-08-29 17:15:01 --> Loader Class Initialized
INFO - 2016-08-29 17:15:01 --> Helper loaded: url_helper
INFO - 2016-08-29 17:15:01 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:15:01 --> Helper loaded: html_helper
INFO - 2016-08-29 17:15:01 --> Helper loaded: form_helper
INFO - 2016-08-29 17:15:01 --> Helper loaded: file_helper
INFO - 2016-08-29 17:15:01 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:15:01 --> Database Driver Class Initialized
INFO - 2016-08-29 17:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:15:01 --> Form Validation Class Initialized
INFO - 2016-08-29 17:15:01 --> Email Class Initialized
INFO - 2016-08-29 17:15:01 --> Controller Class Initialized
DEBUG - 2016-08-29 17:15:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:15:01 --> Model Class Initialized
INFO - 2016-08-29 17:15:01 --> Model Class Initialized
INFO - 2016-08-29 17:15:01 --> Model Class Initialized
INFO - 2016-08-29 17:15:01 --> Model Class Initialized
INFO - 2016-08-29 17:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:15:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:15:01 --> Final output sent to browser
DEBUG - 2016-08-29 17:15:01 --> Total execution time: 0.3319
INFO - 2016-08-29 17:15:04 --> Config Class Initialized
INFO - 2016-08-29 17:15:04 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:15:04 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:15:04 --> Utf8 Class Initialized
INFO - 2016-08-29 17:15:04 --> URI Class Initialized
INFO - 2016-08-29 17:15:04 --> Router Class Initialized
INFO - 2016-08-29 17:15:04 --> Output Class Initialized
INFO - 2016-08-29 17:15:04 --> Security Class Initialized
DEBUG - 2016-08-29 17:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:15:04 --> Input Class Initialized
INFO - 2016-08-29 17:15:04 --> Language Class Initialized
INFO - 2016-08-29 17:15:04 --> Loader Class Initialized
INFO - 2016-08-29 17:15:04 --> Helper loaded: url_helper
INFO - 2016-08-29 17:15:04 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:15:04 --> Helper loaded: html_helper
INFO - 2016-08-29 17:15:04 --> Helper loaded: form_helper
INFO - 2016-08-29 17:15:04 --> Helper loaded: file_helper
INFO - 2016-08-29 17:15:04 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:15:04 --> Database Driver Class Initialized
INFO - 2016-08-29 17:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:15:04 --> Form Validation Class Initialized
INFO - 2016-08-29 17:15:04 --> Email Class Initialized
INFO - 2016-08-29 17:15:04 --> Controller Class Initialized
DEBUG - 2016-08-29 17:15:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:15:04 --> Model Class Initialized
INFO - 2016-08-29 17:15:04 --> Model Class Initialized
INFO - 2016-08-29 17:15:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:15:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:15:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:15:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:15:04 --> Final output sent to browser
DEBUG - 2016-08-29 17:15:04 --> Total execution time: 0.3379
INFO - 2016-08-29 17:15:58 --> Config Class Initialized
INFO - 2016-08-29 17:15:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:15:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:15:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:15:58 --> URI Class Initialized
INFO - 2016-08-29 17:15:58 --> Router Class Initialized
INFO - 2016-08-29 17:15:58 --> Output Class Initialized
INFO - 2016-08-29 17:15:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:15:58 --> Input Class Initialized
INFO - 2016-08-29 17:15:58 --> Language Class Initialized
INFO - 2016-08-29 17:15:58 --> Loader Class Initialized
INFO - 2016-08-29 17:15:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: html_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: form_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: file_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:15:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:15:58 --> Form Validation Class Initialized
INFO - 2016-08-29 17:15:58 --> Email Class Initialized
INFO - 2016-08-29 17:15:58 --> Controller Class Initialized
DEBUG - 2016-08-29 17:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:15:58 --> Model Class Initialized
INFO - 2016-08-29 17:15:58 --> Model Class Initialized
INFO - 2016-08-29 17:15:58 --> Config Class Initialized
INFO - 2016-08-29 17:15:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:15:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:15:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:15:58 --> URI Class Initialized
INFO - 2016-08-29 17:15:58 --> Router Class Initialized
INFO - 2016-08-29 17:15:58 --> Output Class Initialized
INFO - 2016-08-29 17:15:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:15:58 --> Input Class Initialized
INFO - 2016-08-29 17:15:58 --> Language Class Initialized
INFO - 2016-08-29 17:15:58 --> Loader Class Initialized
INFO - 2016-08-29 17:15:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: html_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: form_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: file_helper
INFO - 2016-08-29 17:15:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:15:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:15:58 --> Form Validation Class Initialized
INFO - 2016-08-29 17:15:58 --> Email Class Initialized
INFO - 2016-08-29 17:15:58 --> Controller Class Initialized
DEBUG - 2016-08-29 17:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:15:58 --> Model Class Initialized
INFO - 2016-08-29 17:15:58 --> Model Class Initialized
INFO - 2016-08-29 17:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:15:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:15:58 --> Final output sent to browser
DEBUG - 2016-08-29 17:15:59 --> Total execution time: 0.3237
INFO - 2016-08-29 17:30:58 --> Config Class Initialized
INFO - 2016-08-29 17:30:58 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:30:58 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:30:58 --> Utf8 Class Initialized
INFO - 2016-08-29 17:30:58 --> URI Class Initialized
INFO - 2016-08-29 17:30:58 --> Router Class Initialized
INFO - 2016-08-29 17:30:58 --> Output Class Initialized
INFO - 2016-08-29 17:30:58 --> Security Class Initialized
DEBUG - 2016-08-29 17:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:30:58 --> Input Class Initialized
INFO - 2016-08-29 17:30:58 --> Language Class Initialized
INFO - 2016-08-29 17:30:58 --> Loader Class Initialized
INFO - 2016-08-29 17:30:58 --> Helper loaded: url_helper
INFO - 2016-08-29 17:30:58 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:30:58 --> Helper loaded: html_helper
INFO - 2016-08-29 17:30:58 --> Helper loaded: form_helper
INFO - 2016-08-29 17:30:58 --> Helper loaded: file_helper
INFO - 2016-08-29 17:30:58 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:30:58 --> Database Driver Class Initialized
INFO - 2016-08-29 17:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:30:58 --> Form Validation Class Initialized
INFO - 2016-08-29 17:30:58 --> Email Class Initialized
INFO - 2016-08-29 17:30:58 --> Controller Class Initialized
DEBUG - 2016-08-29 17:30:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:30:58 --> Model Class Initialized
INFO - 2016-08-29 17:30:58 --> Model Class Initialized
INFO - 2016-08-29 17:30:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:30:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-29 17:30:58 --> Query error: Unknown column 'b_create_datse' in 'order clause' - Invalid query: SELECT *
FROM `books`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
ORDER BY `b_create_datse` DESC
INFO - 2016-08-29 17:30:58 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:31:26 --> Config Class Initialized
INFO - 2016-08-29 17:31:26 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:31:26 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:31:26 --> Utf8 Class Initialized
INFO - 2016-08-29 17:31:26 --> URI Class Initialized
INFO - 2016-08-29 17:31:26 --> Router Class Initialized
INFO - 2016-08-29 17:31:26 --> Output Class Initialized
INFO - 2016-08-29 17:31:26 --> Security Class Initialized
DEBUG - 2016-08-29 17:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:31:26 --> Input Class Initialized
INFO - 2016-08-29 17:31:26 --> Language Class Initialized
INFO - 2016-08-29 17:31:27 --> Loader Class Initialized
INFO - 2016-08-29 17:31:27 --> Helper loaded: url_helper
INFO - 2016-08-29 17:31:27 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:31:27 --> Helper loaded: html_helper
INFO - 2016-08-29 17:31:27 --> Helper loaded: form_helper
INFO - 2016-08-29 17:31:27 --> Helper loaded: file_helper
INFO - 2016-08-29 17:31:27 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:31:27 --> Database Driver Class Initialized
INFO - 2016-08-29 17:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:31:27 --> Form Validation Class Initialized
INFO - 2016-08-29 17:31:27 --> Email Class Initialized
INFO - 2016-08-29 17:31:27 --> Controller Class Initialized
DEBUG - 2016-08-29 17:31:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:31:27 --> Model Class Initialized
INFO - 2016-08-29 17:31:27 --> Model Class Initialized
INFO - 2016-08-29 17:31:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:31:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:31:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:31:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:31:27 --> Final output sent to browser
DEBUG - 2016-08-29 17:31:27 --> Total execution time: 0.3329
INFO - 2016-08-29 17:33:06 --> Config Class Initialized
INFO - 2016-08-29 17:33:06 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:33:06 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:33:06 --> Utf8 Class Initialized
INFO - 2016-08-29 17:33:06 --> URI Class Initialized
INFO - 2016-08-29 17:33:06 --> Router Class Initialized
INFO - 2016-08-29 17:33:06 --> Output Class Initialized
INFO - 2016-08-29 17:33:06 --> Security Class Initialized
DEBUG - 2016-08-29 17:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:33:06 --> Input Class Initialized
INFO - 2016-08-29 17:33:06 --> Language Class Initialized
INFO - 2016-08-29 17:33:06 --> Loader Class Initialized
INFO - 2016-08-29 17:33:06 --> Helper loaded: url_helper
INFO - 2016-08-29 17:33:06 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:33:06 --> Helper loaded: html_helper
INFO - 2016-08-29 17:33:06 --> Helper loaded: form_helper
INFO - 2016-08-29 17:33:06 --> Helper loaded: file_helper
INFO - 2016-08-29 17:33:06 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:33:06 --> Database Driver Class Initialized
INFO - 2016-08-29 17:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:33:06 --> Form Validation Class Initialized
INFO - 2016-08-29 17:33:06 --> Email Class Initialized
INFO - 2016-08-29 17:33:06 --> Controller Class Initialized
DEBUG - 2016-08-29 17:33:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:33:06 --> Model Class Initialized
INFO - 2016-08-29 17:33:06 --> Model Class Initialized
INFO - 2016-08-29 17:33:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:33:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:33:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:33:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:33:06 --> Final output sent to browser
DEBUG - 2016-08-29 17:33:06 --> Total execution time: 0.3564
INFO - 2016-08-29 17:33:30 --> Config Class Initialized
INFO - 2016-08-29 17:33:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:33:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:33:30 --> Utf8 Class Initialized
INFO - 2016-08-29 17:33:30 --> URI Class Initialized
INFO - 2016-08-29 17:33:30 --> Router Class Initialized
INFO - 2016-08-29 17:33:30 --> Output Class Initialized
INFO - 2016-08-29 17:33:30 --> Security Class Initialized
DEBUG - 2016-08-29 17:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:33:30 --> Input Class Initialized
INFO - 2016-08-29 17:33:30 --> Language Class Initialized
INFO - 2016-08-29 17:33:30 --> Loader Class Initialized
INFO - 2016-08-29 17:33:30 --> Helper loaded: url_helper
INFO - 2016-08-29 17:33:30 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:33:30 --> Helper loaded: html_helper
INFO - 2016-08-29 17:33:30 --> Helper loaded: form_helper
INFO - 2016-08-29 17:33:30 --> Helper loaded: file_helper
INFO - 2016-08-29 17:33:30 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:33:30 --> Database Driver Class Initialized
INFO - 2016-08-29 17:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:33:30 --> Form Validation Class Initialized
INFO - 2016-08-29 17:33:30 --> Email Class Initialized
INFO - 2016-08-29 17:33:30 --> Controller Class Initialized
DEBUG - 2016-08-29 17:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:33:30 --> Model Class Initialized
INFO - 2016-08-29 17:33:30 --> Model Class Initialized
INFO - 2016-08-29 17:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:33:31 --> Final output sent to browser
DEBUG - 2016-08-29 17:33:31 --> Total execution time: 0.3565
INFO - 2016-08-29 17:33:51 --> Config Class Initialized
INFO - 2016-08-29 17:33:51 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:33:51 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:33:51 --> Utf8 Class Initialized
INFO - 2016-08-29 17:33:51 --> URI Class Initialized
INFO - 2016-08-29 17:33:51 --> Router Class Initialized
INFO - 2016-08-29 17:33:51 --> Output Class Initialized
INFO - 2016-08-29 17:33:51 --> Security Class Initialized
DEBUG - 2016-08-29 17:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:33:51 --> Input Class Initialized
INFO - 2016-08-29 17:33:51 --> Language Class Initialized
INFO - 2016-08-29 17:33:51 --> Loader Class Initialized
INFO - 2016-08-29 17:33:51 --> Helper loaded: url_helper
INFO - 2016-08-29 17:33:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:33:51 --> Helper loaded: html_helper
INFO - 2016-08-29 17:33:51 --> Helper loaded: form_helper
INFO - 2016-08-29 17:33:51 --> Helper loaded: file_helper
INFO - 2016-08-29 17:33:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:33:51 --> Database Driver Class Initialized
INFO - 2016-08-29 17:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:33:51 --> Form Validation Class Initialized
INFO - 2016-08-29 17:33:51 --> Email Class Initialized
INFO - 2016-08-29 17:33:51 --> Controller Class Initialized
DEBUG - 2016-08-29 17:33:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:33:51 --> Model Class Initialized
INFO - 2016-08-29 17:33:51 --> Model Class Initialized
INFO - 2016-08-29 17:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:33:51 --> Final output sent to browser
DEBUG - 2016-08-29 17:33:51 --> Total execution time: 0.3391
INFO - 2016-08-29 17:34:36 --> Config Class Initialized
INFO - 2016-08-29 17:34:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:34:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:34:36 --> Utf8 Class Initialized
INFO - 2016-08-29 17:34:36 --> URI Class Initialized
INFO - 2016-08-29 17:34:36 --> Router Class Initialized
INFO - 2016-08-29 17:34:36 --> Output Class Initialized
INFO - 2016-08-29 17:34:36 --> Security Class Initialized
DEBUG - 2016-08-29 17:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:34:36 --> Input Class Initialized
INFO - 2016-08-29 17:34:36 --> Language Class Initialized
INFO - 2016-08-29 17:34:36 --> Loader Class Initialized
INFO - 2016-08-29 17:34:36 --> Helper loaded: url_helper
INFO - 2016-08-29 17:34:36 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:34:36 --> Helper loaded: html_helper
INFO - 2016-08-29 17:34:36 --> Helper loaded: form_helper
INFO - 2016-08-29 17:34:36 --> Helper loaded: file_helper
INFO - 2016-08-29 17:34:36 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:34:36 --> Database Driver Class Initialized
INFO - 2016-08-29 17:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:34:36 --> Form Validation Class Initialized
INFO - 2016-08-29 17:34:36 --> Email Class Initialized
INFO - 2016-08-29 17:34:36 --> Controller Class Initialized
DEBUG - 2016-08-29 17:34:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:34:36 --> Model Class Initialized
INFO - 2016-08-29 17:34:36 --> Model Class Initialized
INFO - 2016-08-29 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:34:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:34:36 --> Final output sent to browser
DEBUG - 2016-08-29 17:34:36 --> Total execution time: 0.3474
INFO - 2016-08-29 17:34:42 --> Config Class Initialized
INFO - 2016-08-29 17:34:42 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:34:42 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:34:42 --> Utf8 Class Initialized
INFO - 2016-08-29 17:34:42 --> URI Class Initialized
INFO - 2016-08-29 17:34:42 --> Router Class Initialized
INFO - 2016-08-29 17:34:42 --> Output Class Initialized
INFO - 2016-08-29 17:34:42 --> Security Class Initialized
DEBUG - 2016-08-29 17:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:34:42 --> Input Class Initialized
INFO - 2016-08-29 17:34:42 --> Language Class Initialized
INFO - 2016-08-29 17:34:42 --> Loader Class Initialized
INFO - 2016-08-29 17:34:42 --> Helper loaded: url_helper
INFO - 2016-08-29 17:34:42 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:34:42 --> Helper loaded: html_helper
INFO - 2016-08-29 17:34:42 --> Helper loaded: form_helper
INFO - 2016-08-29 17:34:42 --> Helper loaded: file_helper
INFO - 2016-08-29 17:34:42 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:34:42 --> Database Driver Class Initialized
INFO - 2016-08-29 17:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:34:42 --> Form Validation Class Initialized
INFO - 2016-08-29 17:34:42 --> Email Class Initialized
INFO - 2016-08-29 17:34:42 --> Controller Class Initialized
DEBUG - 2016-08-29 17:34:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:34:42 --> Model Class Initialized
INFO - 2016-08-29 17:34:42 --> Model Class Initialized
INFO - 2016-08-29 17:34:43 --> Model Class Initialized
INFO - 2016-08-29 17:34:43 --> Final output sent to browser
DEBUG - 2016-08-29 17:34:43 --> Total execution time: 0.3223
INFO - 2016-08-29 17:34:45 --> Config Class Initialized
INFO - 2016-08-29 17:34:45 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:34:45 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:34:45 --> Utf8 Class Initialized
INFO - 2016-08-29 17:34:45 --> URI Class Initialized
INFO - 2016-08-29 17:34:45 --> Router Class Initialized
INFO - 2016-08-29 17:34:45 --> Output Class Initialized
INFO - 2016-08-29 17:34:45 --> Security Class Initialized
DEBUG - 2016-08-29 17:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:34:45 --> Input Class Initialized
INFO - 2016-08-29 17:34:45 --> Language Class Initialized
INFO - 2016-08-29 17:34:45 --> Loader Class Initialized
INFO - 2016-08-29 17:34:45 --> Helper loaded: url_helper
INFO - 2016-08-29 17:34:45 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:34:45 --> Helper loaded: html_helper
INFO - 2016-08-29 17:34:45 --> Helper loaded: form_helper
INFO - 2016-08-29 17:34:45 --> Helper loaded: file_helper
INFO - 2016-08-29 17:34:45 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:34:45 --> Database Driver Class Initialized
INFO - 2016-08-29 17:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:34:45 --> Form Validation Class Initialized
INFO - 2016-08-29 17:34:45 --> Email Class Initialized
INFO - 2016-08-29 17:34:45 --> Controller Class Initialized
DEBUG - 2016-08-29 17:34:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:34:45 --> Model Class Initialized
INFO - 2016-08-29 17:34:45 --> Model Class Initialized
INFO - 2016-08-29 17:34:45 --> Model Class Initialized
INFO - 2016-08-29 17:34:45 --> Final output sent to browser
DEBUG - 2016-08-29 17:34:45 --> Total execution time: 0.3332
INFO - 2016-08-29 17:35:16 --> Config Class Initialized
INFO - 2016-08-29 17:35:16 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:35:16 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:35:16 --> Utf8 Class Initialized
INFO - 2016-08-29 17:35:16 --> URI Class Initialized
INFO - 2016-08-29 17:35:16 --> Router Class Initialized
INFO - 2016-08-29 17:35:16 --> Output Class Initialized
INFO - 2016-08-29 17:35:16 --> Security Class Initialized
DEBUG - 2016-08-29 17:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:35:16 --> Input Class Initialized
INFO - 2016-08-29 17:35:16 --> Language Class Initialized
INFO - 2016-08-29 17:35:16 --> Loader Class Initialized
INFO - 2016-08-29 17:35:16 --> Helper loaded: url_helper
INFO - 2016-08-29 17:35:16 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:35:16 --> Helper loaded: html_helper
INFO - 2016-08-29 17:35:16 --> Helper loaded: form_helper
INFO - 2016-08-29 17:35:16 --> Helper loaded: file_helper
INFO - 2016-08-29 17:35:16 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:35:16 --> Database Driver Class Initialized
INFO - 2016-08-29 17:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:35:16 --> Form Validation Class Initialized
INFO - 2016-08-29 17:35:16 --> Email Class Initialized
INFO - 2016-08-29 17:35:16 --> Controller Class Initialized
DEBUG - 2016-08-29 17:35:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:35:16 --> Model Class Initialized
INFO - 2016-08-29 17:35:16 --> Model Class Initialized
INFO - 2016-08-29 17:35:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:35:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:35:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:35:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:35:16 --> Final output sent to browser
DEBUG - 2016-08-29 17:35:16 --> Total execution time: 0.3480
INFO - 2016-08-29 17:35:25 --> Config Class Initialized
INFO - 2016-08-29 17:35:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:35:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:35:25 --> Utf8 Class Initialized
INFO - 2016-08-29 17:35:25 --> URI Class Initialized
INFO - 2016-08-29 17:35:25 --> Router Class Initialized
INFO - 2016-08-29 17:35:26 --> Output Class Initialized
INFO - 2016-08-29 17:35:26 --> Security Class Initialized
DEBUG - 2016-08-29 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:35:26 --> Input Class Initialized
INFO - 2016-08-29 17:35:26 --> Language Class Initialized
INFO - 2016-08-29 17:35:26 --> Loader Class Initialized
INFO - 2016-08-29 17:35:26 --> Helper loaded: url_helper
INFO - 2016-08-29 17:35:26 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:35:26 --> Helper loaded: html_helper
INFO - 2016-08-29 17:35:26 --> Helper loaded: form_helper
INFO - 2016-08-29 17:35:26 --> Helper loaded: file_helper
INFO - 2016-08-29 17:35:26 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:35:26 --> Database Driver Class Initialized
INFO - 2016-08-29 17:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:35:26 --> Form Validation Class Initialized
INFO - 2016-08-29 17:35:26 --> Email Class Initialized
INFO - 2016-08-29 17:35:26 --> Controller Class Initialized
DEBUG - 2016-08-29 17:35:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:35:26 --> Model Class Initialized
INFO - 2016-08-29 17:35:26 --> Model Class Initialized
INFO - 2016-08-29 17:35:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:35:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:35:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:35:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:35:26 --> Final output sent to browser
DEBUG - 2016-08-29 17:35:26 --> Total execution time: 0.3518
INFO - 2016-08-29 17:35:36 --> Config Class Initialized
INFO - 2016-08-29 17:35:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:35:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:35:36 --> Utf8 Class Initialized
INFO - 2016-08-29 17:35:36 --> URI Class Initialized
INFO - 2016-08-29 17:35:36 --> Router Class Initialized
INFO - 2016-08-29 17:35:36 --> Output Class Initialized
INFO - 2016-08-29 17:35:36 --> Security Class Initialized
DEBUG - 2016-08-29 17:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:35:36 --> Input Class Initialized
INFO - 2016-08-29 17:35:36 --> Language Class Initialized
INFO - 2016-08-29 17:35:36 --> Loader Class Initialized
INFO - 2016-08-29 17:35:36 --> Helper loaded: url_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: html_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: form_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: file_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:35:36 --> Database Driver Class Initialized
INFO - 2016-08-29 17:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:35:36 --> Form Validation Class Initialized
INFO - 2016-08-29 17:35:36 --> Email Class Initialized
INFO - 2016-08-29 17:35:36 --> Controller Class Initialized
DEBUG - 2016-08-29 17:35:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:35:36 --> Model Class Initialized
INFO - 2016-08-29 17:35:36 --> Model Class Initialized
INFO - 2016-08-29 17:35:36 --> Config Class Initialized
INFO - 2016-08-29 17:35:36 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:35:36 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:35:36 --> Utf8 Class Initialized
INFO - 2016-08-29 17:35:36 --> URI Class Initialized
INFO - 2016-08-29 17:35:36 --> Router Class Initialized
INFO - 2016-08-29 17:35:36 --> Output Class Initialized
INFO - 2016-08-29 17:35:36 --> Security Class Initialized
DEBUG - 2016-08-29 17:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:35:36 --> Input Class Initialized
INFO - 2016-08-29 17:35:36 --> Language Class Initialized
INFO - 2016-08-29 17:35:36 --> Loader Class Initialized
INFO - 2016-08-29 17:35:36 --> Helper loaded: url_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: html_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: form_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: file_helper
INFO - 2016-08-29 17:35:36 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:35:36 --> Database Driver Class Initialized
INFO - 2016-08-29 17:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:35:36 --> Form Validation Class Initialized
INFO - 2016-08-29 17:35:36 --> Email Class Initialized
INFO - 2016-08-29 17:35:37 --> Controller Class Initialized
DEBUG - 2016-08-29 17:35:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:35:37 --> Model Class Initialized
INFO - 2016-08-29 17:35:37 --> Model Class Initialized
INFO - 2016-08-29 17:35:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:35:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:35:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:35:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:35:37 --> Final output sent to browser
DEBUG - 2016-08-29 17:35:37 --> Total execution time: 0.3609
INFO - 2016-08-29 17:46:13 --> Config Class Initialized
INFO - 2016-08-29 17:46:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:46:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:46:13 --> Utf8 Class Initialized
INFO - 2016-08-29 17:46:13 --> URI Class Initialized
INFO - 2016-08-29 17:46:13 --> Router Class Initialized
INFO - 2016-08-29 17:46:13 --> Output Class Initialized
INFO - 2016-08-29 17:46:13 --> Security Class Initialized
DEBUG - 2016-08-29 17:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:46:13 --> Input Class Initialized
INFO - 2016-08-29 17:46:13 --> Language Class Initialized
INFO - 2016-08-29 17:46:13 --> Loader Class Initialized
INFO - 2016-08-29 17:46:13 --> Helper loaded: url_helper
INFO - 2016-08-29 17:46:13 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:46:13 --> Helper loaded: html_helper
INFO - 2016-08-29 17:46:13 --> Helper loaded: form_helper
INFO - 2016-08-29 17:46:13 --> Helper loaded: file_helper
INFO - 2016-08-29 17:46:13 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:46:13 --> Database Driver Class Initialized
INFO - 2016-08-29 17:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:46:13 --> Form Validation Class Initialized
INFO - 2016-08-29 17:46:13 --> Email Class Initialized
INFO - 2016-08-29 17:46:13 --> Controller Class Initialized
DEBUG - 2016-08-29 17:46:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:46:13 --> Model Class Initialized
INFO - 2016-08-29 17:46:13 --> Model Class Initialized
INFO - 2016-08-29 17:46:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:46:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:46:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:46:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:46:13 --> Final output sent to browser
DEBUG - 2016-08-29 17:46:13 --> Total execution time: 0.4026
INFO - 2016-08-29 17:46:21 --> Config Class Initialized
INFO - 2016-08-29 17:46:21 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:46:21 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:46:21 --> Utf8 Class Initialized
INFO - 2016-08-29 17:46:21 --> URI Class Initialized
INFO - 2016-08-29 17:46:21 --> Router Class Initialized
INFO - 2016-08-29 17:46:21 --> Output Class Initialized
INFO - 2016-08-29 17:46:21 --> Security Class Initialized
DEBUG - 2016-08-29 17:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:46:21 --> Input Class Initialized
INFO - 2016-08-29 17:46:21 --> Language Class Initialized
INFO - 2016-08-29 17:46:21 --> Loader Class Initialized
INFO - 2016-08-29 17:46:21 --> Helper loaded: url_helper
INFO - 2016-08-29 17:46:21 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:46:21 --> Helper loaded: html_helper
INFO - 2016-08-29 17:46:21 --> Helper loaded: form_helper
INFO - 2016-08-29 17:46:21 --> Helper loaded: file_helper
INFO - 2016-08-29 17:46:21 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:46:21 --> Database Driver Class Initialized
INFO - 2016-08-29 17:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:46:21 --> Form Validation Class Initialized
INFO - 2016-08-29 17:46:21 --> Email Class Initialized
INFO - 2016-08-29 17:46:21 --> Controller Class Initialized
DEBUG - 2016-08-29 17:46:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:46:21 --> Model Class Initialized
INFO - 2016-08-29 17:46:21 --> Model Class Initialized
ERROR - 2016-08-29 17:46:21 --> Severity: Notice --> Undefined variable: bookid D:\wamp\www\library.pnc.lan\application\models\books_model.php 111
ERROR - 2016-08-29 17:46:22 --> Severity: Notice --> Undefined variable: datas D:\wamp\www\library.pnc.lan\application\models\books_model.php 112
INFO - 2016-08-29 17:46:22 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:47:05 --> Config Class Initialized
INFO - 2016-08-29 17:47:05 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:47:05 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:47:05 --> Utf8 Class Initialized
INFO - 2016-08-29 17:47:05 --> URI Class Initialized
INFO - 2016-08-29 17:47:05 --> Router Class Initialized
INFO - 2016-08-29 17:47:05 --> Output Class Initialized
INFO - 2016-08-29 17:47:05 --> Security Class Initialized
DEBUG - 2016-08-29 17:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:47:06 --> Input Class Initialized
INFO - 2016-08-29 17:47:06 --> Language Class Initialized
INFO - 2016-08-29 17:47:06 --> Loader Class Initialized
INFO - 2016-08-29 17:47:06 --> Helper loaded: url_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: html_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: form_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: file_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:47:06 --> Database Driver Class Initialized
INFO - 2016-08-29 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:47:06 --> Form Validation Class Initialized
INFO - 2016-08-29 17:47:06 --> Email Class Initialized
INFO - 2016-08-29 17:47:06 --> Controller Class Initialized
DEBUG - 2016-08-29 17:47:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:47:06 --> Model Class Initialized
INFO - 2016-08-29 17:47:06 --> Model Class Initialized
INFO - 2016-08-29 17:47:06 --> Config Class Initialized
INFO - 2016-08-29 17:47:06 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:47:06 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:47:06 --> Utf8 Class Initialized
INFO - 2016-08-29 17:47:06 --> URI Class Initialized
INFO - 2016-08-29 17:47:06 --> Router Class Initialized
INFO - 2016-08-29 17:47:06 --> Output Class Initialized
INFO - 2016-08-29 17:47:06 --> Security Class Initialized
DEBUG - 2016-08-29 17:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:47:06 --> Input Class Initialized
INFO - 2016-08-29 17:47:06 --> Language Class Initialized
INFO - 2016-08-29 17:47:06 --> Loader Class Initialized
INFO - 2016-08-29 17:47:06 --> Helper loaded: url_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: html_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: form_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: file_helper
INFO - 2016-08-29 17:47:06 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:47:06 --> Database Driver Class Initialized
INFO - 2016-08-29 17:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:47:06 --> Form Validation Class Initialized
INFO - 2016-08-29 17:47:06 --> Email Class Initialized
INFO - 2016-08-29 17:47:06 --> Controller Class Initialized
DEBUG - 2016-08-29 17:47:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:47:06 --> Model Class Initialized
INFO - 2016-08-29 17:47:06 --> Model Class Initialized
INFO - 2016-08-29 17:47:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:47:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:47:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:47:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:47:06 --> Final output sent to browser
DEBUG - 2016-08-29 17:47:06 --> Total execution time: 0.3504
INFO - 2016-08-29 17:47:24 --> Config Class Initialized
INFO - 2016-08-29 17:47:24 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:47:24 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:47:24 --> Utf8 Class Initialized
INFO - 2016-08-29 17:47:24 --> URI Class Initialized
INFO - 2016-08-29 17:47:24 --> Router Class Initialized
INFO - 2016-08-29 17:47:24 --> Output Class Initialized
INFO - 2016-08-29 17:47:24 --> Security Class Initialized
DEBUG - 2016-08-29 17:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:47:24 --> Input Class Initialized
INFO - 2016-08-29 17:47:24 --> Language Class Initialized
INFO - 2016-08-29 17:47:24 --> Loader Class Initialized
INFO - 2016-08-29 17:47:24 --> Helper loaded: url_helper
INFO - 2016-08-29 17:47:24 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:47:24 --> Helper loaded: html_helper
INFO - 2016-08-29 17:47:24 --> Helper loaded: form_helper
INFO - 2016-08-29 17:47:24 --> Helper loaded: file_helper
INFO - 2016-08-29 17:47:24 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:47:24 --> Database Driver Class Initialized
INFO - 2016-08-29 17:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:47:24 --> Form Validation Class Initialized
INFO - 2016-08-29 17:47:24 --> Email Class Initialized
INFO - 2016-08-29 17:47:24 --> Controller Class Initialized
DEBUG - 2016-08-29 17:47:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:47:24 --> Model Class Initialized
INFO - 2016-08-29 17:47:24 --> Model Class Initialized
INFO - 2016-08-29 17:47:24 --> Model Class Initialized
INFO - 2016-08-29 17:47:24 --> Final output sent to browser
DEBUG - 2016-08-29 17:47:24 --> Total execution time: 0.3334
INFO - 2016-08-29 17:48:29 --> Config Class Initialized
INFO - 2016-08-29 17:48:29 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:48:29 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:48:29 --> Utf8 Class Initialized
INFO - 2016-08-29 17:48:29 --> URI Class Initialized
INFO - 2016-08-29 17:48:29 --> Router Class Initialized
INFO - 2016-08-29 17:48:29 --> Output Class Initialized
INFO - 2016-08-29 17:48:29 --> Security Class Initialized
DEBUG - 2016-08-29 17:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:48:29 --> Input Class Initialized
INFO - 2016-08-29 17:48:29 --> Language Class Initialized
INFO - 2016-08-29 17:48:29 --> Loader Class Initialized
INFO - 2016-08-29 17:48:29 --> Helper loaded: url_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: html_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: form_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: file_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:48:29 --> Database Driver Class Initialized
INFO - 2016-08-29 17:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:48:29 --> Form Validation Class Initialized
INFO - 2016-08-29 17:48:29 --> Email Class Initialized
INFO - 2016-08-29 17:48:29 --> Controller Class Initialized
DEBUG - 2016-08-29 17:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:48:29 --> Model Class Initialized
INFO - 2016-08-29 17:48:29 --> Model Class Initialized
INFO - 2016-08-29 17:48:29 --> Config Class Initialized
INFO - 2016-08-29 17:48:29 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:48:29 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:48:29 --> Utf8 Class Initialized
INFO - 2016-08-29 17:48:29 --> URI Class Initialized
INFO - 2016-08-29 17:48:29 --> Router Class Initialized
INFO - 2016-08-29 17:48:29 --> Output Class Initialized
INFO - 2016-08-29 17:48:29 --> Security Class Initialized
DEBUG - 2016-08-29 17:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:48:29 --> Input Class Initialized
INFO - 2016-08-29 17:48:29 --> Language Class Initialized
INFO - 2016-08-29 17:48:29 --> Loader Class Initialized
INFO - 2016-08-29 17:48:29 --> Helper loaded: url_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: html_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: form_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: file_helper
INFO - 2016-08-29 17:48:29 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:48:29 --> Database Driver Class Initialized
INFO - 2016-08-29 17:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:48:29 --> Form Validation Class Initialized
INFO - 2016-08-29 17:48:29 --> Email Class Initialized
INFO - 2016-08-29 17:48:29 --> Controller Class Initialized
DEBUG - 2016-08-29 17:48:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:48:29 --> Model Class Initialized
INFO - 2016-08-29 17:48:29 --> Model Class Initialized
INFO - 2016-08-29 17:48:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:48:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:48:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:48:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:48:29 --> Final output sent to browser
DEBUG - 2016-08-29 17:48:29 --> Total execution time: 0.3489
INFO - 2016-08-29 17:50:50 --> Config Class Initialized
INFO - 2016-08-29 17:50:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:50:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:50:50 --> Utf8 Class Initialized
INFO - 2016-08-29 17:50:50 --> URI Class Initialized
INFO - 2016-08-29 17:50:50 --> Router Class Initialized
INFO - 2016-08-29 17:50:50 --> Output Class Initialized
INFO - 2016-08-29 17:50:50 --> Security Class Initialized
DEBUG - 2016-08-29 17:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:50:50 --> Input Class Initialized
INFO - 2016-08-29 17:50:50 --> Language Class Initialized
INFO - 2016-08-29 17:50:50 --> Loader Class Initialized
INFO - 2016-08-29 17:50:50 --> Helper loaded: url_helper
INFO - 2016-08-29 17:50:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:50:51 --> Helper loaded: html_helper
INFO - 2016-08-29 17:50:51 --> Helper loaded: form_helper
INFO - 2016-08-29 17:50:51 --> Helper loaded: file_helper
INFO - 2016-08-29 17:50:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:50:51 --> Database Driver Class Initialized
INFO - 2016-08-29 17:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:50:51 --> Form Validation Class Initialized
INFO - 2016-08-29 17:50:51 --> Email Class Initialized
INFO - 2016-08-29 17:50:51 --> Controller Class Initialized
DEBUG - 2016-08-29 17:50:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:50:51 --> Model Class Initialized
INFO - 2016-08-29 17:50:51 --> Model Class Initialized
INFO - 2016-08-29 17:50:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:50:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-29 17:50:51 --> Query error: Column 'sta_id' in where clause is ambiguous - Invalid query: SELECT *
FROM `books`
JOIN `categories` ON `books`.`cat_id` = `categories`.`cat_id`
JOIN `status` ON `books`.`sta_id` = `status`.`sta_id`
JOIN `conditions` ON `books`.`con_id` = `conditions`.`con_id`
JOIN `users` ON `books`.`users_id` = `users`.`id`
WHERE `sta_id` <> 4
ORDER BY `b_create_date` DESC
INFO - 2016-08-29 17:50:51 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:52:25 --> Config Class Initialized
INFO - 2016-08-29 17:52:25 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:52:25 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:52:25 --> Utf8 Class Initialized
INFO - 2016-08-29 17:52:25 --> URI Class Initialized
INFO - 2016-08-29 17:52:25 --> Router Class Initialized
INFO - 2016-08-29 17:52:25 --> Output Class Initialized
INFO - 2016-08-29 17:52:25 --> Security Class Initialized
DEBUG - 2016-08-29 17:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:52:25 --> Input Class Initialized
INFO - 2016-08-29 17:52:25 --> Language Class Initialized
INFO - 2016-08-29 17:52:25 --> Loader Class Initialized
INFO - 2016-08-29 17:52:25 --> Helper loaded: url_helper
INFO - 2016-08-29 17:52:25 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:52:25 --> Helper loaded: html_helper
INFO - 2016-08-29 17:52:25 --> Helper loaded: form_helper
INFO - 2016-08-29 17:52:25 --> Helper loaded: file_helper
INFO - 2016-08-29 17:52:25 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:52:25 --> Database Driver Class Initialized
INFO - 2016-08-29 17:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:52:25 --> Form Validation Class Initialized
INFO - 2016-08-29 17:52:25 --> Email Class Initialized
INFO - 2016-08-29 17:52:25 --> Controller Class Initialized
DEBUG - 2016-08-29 17:52:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:52:25 --> Model Class Initialized
INFO - 2016-08-29 17:52:25 --> Model Class Initialized
INFO - 2016-08-29 17:52:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:52:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
ERROR - 2016-08-29 17:52:25 --> Query error: Not unique table/alias: 'c' - Invalid query: SELECT *
FROM `books` `b`
JOIN `categories` `c` ON `b`.`cat_id` = `c`.`cat_id`
JOIN `status` `s` ON `b`.`sta_id` = `s`.`sta_id`
JOIN `conditions` `c` ON `b`.`con_id` = `c`.`con_id`
JOIN `users` `u` ON `b`.`users_id` = `u`.`id`
WHERE `b`.`sta_id` <> 4
ORDER BY `b_create_date` DESC
INFO - 2016-08-29 17:52:25 --> Language file loaded: language/english/db_lang.php
INFO - 2016-08-29 17:52:50 --> Config Class Initialized
INFO - 2016-08-29 17:52:50 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:52:50 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:52:51 --> Utf8 Class Initialized
INFO - 2016-08-29 17:52:51 --> URI Class Initialized
INFO - 2016-08-29 17:52:51 --> Router Class Initialized
INFO - 2016-08-29 17:52:51 --> Output Class Initialized
INFO - 2016-08-29 17:52:51 --> Security Class Initialized
DEBUG - 2016-08-29 17:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:52:51 --> Input Class Initialized
INFO - 2016-08-29 17:52:51 --> Language Class Initialized
INFO - 2016-08-29 17:52:51 --> Loader Class Initialized
INFO - 2016-08-29 17:52:51 --> Helper loaded: url_helper
INFO - 2016-08-29 17:52:51 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:52:51 --> Helper loaded: html_helper
INFO - 2016-08-29 17:52:51 --> Helper loaded: form_helper
INFO - 2016-08-29 17:52:51 --> Helper loaded: file_helper
INFO - 2016-08-29 17:52:51 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:52:51 --> Database Driver Class Initialized
INFO - 2016-08-29 17:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:52:51 --> Form Validation Class Initialized
INFO - 2016-08-29 17:52:51 --> Email Class Initialized
INFO - 2016-08-29 17:52:51 --> Controller Class Initialized
DEBUG - 2016-08-29 17:52:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:52:51 --> Model Class Initialized
INFO - 2016-08-29 17:52:51 --> Model Class Initialized
INFO - 2016-08-29 17:52:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:52:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:52:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:52:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:52:51 --> Final output sent to browser
DEBUG - 2016-08-29 17:52:51 --> Total execution time: 0.3644
INFO - 2016-08-29 17:53:07 --> Config Class Initialized
INFO - 2016-08-29 17:53:07 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:07 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:07 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:07 --> URI Class Initialized
INFO - 2016-08-29 17:53:07 --> Router Class Initialized
INFO - 2016-08-29 17:53:07 --> Output Class Initialized
INFO - 2016-08-29 17:53:07 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:07 --> Input Class Initialized
INFO - 2016-08-29 17:53:07 --> Language Class Initialized
INFO - 2016-08-29 17:53:07 --> Loader Class Initialized
INFO - 2016-08-29 17:53:07 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:07 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:07 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:07 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:07 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:07 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:07 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:07 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:07 --> Email Class Initialized
INFO - 2016-08-29 17:53:07 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:07 --> Model Class Initialized
INFO - 2016-08-29 17:53:07 --> Model Class Initialized
INFO - 2016-08-29 17:53:07 --> Model Class Initialized
INFO - 2016-08-29 17:53:07 --> Model Class Initialized
INFO - 2016-08-29 17:53:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:53:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:07 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:07 --> Total execution time: 0.3690
INFO - 2016-08-29 17:53:13 --> Config Class Initialized
INFO - 2016-08-29 17:53:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:13 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:13 --> URI Class Initialized
INFO - 2016-08-29 17:53:13 --> Router Class Initialized
INFO - 2016-08-29 17:53:13 --> Output Class Initialized
INFO - 2016-08-29 17:53:13 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:13 --> Input Class Initialized
INFO - 2016-08-29 17:53:13 --> Language Class Initialized
INFO - 2016-08-29 17:53:13 --> Loader Class Initialized
INFO - 2016-08-29 17:53:13 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:13 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:13 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:13 --> Email Class Initialized
INFO - 2016-08-29 17:53:13 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:53:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:13 --> Config Class Initialized
INFO - 2016-08-29 17:53:13 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:13 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:13 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:13 --> URI Class Initialized
INFO - 2016-08-29 17:53:13 --> Router Class Initialized
INFO - 2016-08-29 17:53:13 --> Output Class Initialized
INFO - 2016-08-29 17:53:13 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:13 --> Input Class Initialized
INFO - 2016-08-29 17:53:13 --> Language Class Initialized
INFO - 2016-08-29 17:53:13 --> Loader Class Initialized
INFO - 2016-08-29 17:53:13 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:13 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:13 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:13 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:13 --> Email Class Initialized
INFO - 2016-08-29 17:53:13 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> Model Class Initialized
INFO - 2016-08-29 17:53:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-29 17:53:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:14 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:14 --> Total execution time: 0.3468
INFO - 2016-08-29 17:53:23 --> Config Class Initialized
INFO - 2016-08-29 17:53:23 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:23 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:23 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:23 --> URI Class Initialized
INFO - 2016-08-29 17:53:23 --> Router Class Initialized
INFO - 2016-08-29 17:53:23 --> Output Class Initialized
INFO - 2016-08-29 17:53:23 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:24 --> Input Class Initialized
INFO - 2016-08-29 17:53:24 --> Language Class Initialized
INFO - 2016-08-29 17:53:24 --> Loader Class Initialized
INFO - 2016-08-29 17:53:24 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:24 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:24 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:24 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:24 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:24 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:24 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:24 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:24 --> Email Class Initialized
INFO - 2016-08-29 17:53:24 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:24 --> Model Class Initialized
INFO - 2016-08-29 17:53:24 --> Model Class Initialized
INFO - 2016-08-29 17:53:24 --> Model Class Initialized
INFO - 2016-08-29 17:53:24 --> Model Class Initialized
INFO - 2016-08-29 17:53:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-29 17:53:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:24 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:24 --> Total execution time: 0.3717
INFO - 2016-08-29 17:53:26 --> Config Class Initialized
INFO - 2016-08-29 17:53:26 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:26 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:26 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:26 --> URI Class Initialized
INFO - 2016-08-29 17:53:26 --> Router Class Initialized
INFO - 2016-08-29 17:53:26 --> Output Class Initialized
INFO - 2016-08-29 17:53:26 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:26 --> Input Class Initialized
INFO - 2016-08-29 17:53:26 --> Language Class Initialized
INFO - 2016-08-29 17:53:26 --> Loader Class Initialized
INFO - 2016-08-29 17:53:26 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:26 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:26 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:26 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:26 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:26 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:26 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:26 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:26 --> Email Class Initialized
INFO - 2016-08-29 17:53:26 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:26 --> Model Class Initialized
INFO - 2016-08-29 17:53:26 --> Model Class Initialized
INFO - 2016-08-29 17:53:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:53:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:26 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:26 --> Total execution time: 0.3591
INFO - 2016-08-29 17:53:46 --> Config Class Initialized
INFO - 2016-08-29 17:53:46 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:46 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:46 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:46 --> URI Class Initialized
INFO - 2016-08-29 17:53:46 --> Router Class Initialized
INFO - 2016-08-29 17:53:46 --> Output Class Initialized
INFO - 2016-08-29 17:53:46 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:46 --> Input Class Initialized
INFO - 2016-08-29 17:53:46 --> Language Class Initialized
INFO - 2016-08-29 17:53:46 --> Loader Class Initialized
INFO - 2016-08-29 17:53:46 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:46 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:46 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:46 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:46 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:46 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:46 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:46 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:46 --> Email Class Initialized
INFO - 2016-08-29 17:53:46 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:46 --> Model Class Initialized
INFO - 2016-08-29 17:53:46 --> Model Class Initialized
INFO - 2016-08-29 17:53:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:53:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:46 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:46 --> Total execution time: 0.4311
INFO - 2016-08-29 17:53:56 --> Config Class Initialized
INFO - 2016-08-29 17:53:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:56 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:56 --> URI Class Initialized
INFO - 2016-08-29 17:53:56 --> Router Class Initialized
INFO - 2016-08-29 17:53:56 --> Output Class Initialized
INFO - 2016-08-29 17:53:56 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:56 --> Input Class Initialized
INFO - 2016-08-29 17:53:56 --> Language Class Initialized
INFO - 2016-08-29 17:53:56 --> Loader Class Initialized
INFO - 2016-08-29 17:53:56 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:56 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:56 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:56 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:56 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:56 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:56 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:56 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:56 --> Email Class Initialized
INFO - 2016-08-29 17:53:56 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:56 --> Model Class Initialized
INFO - 2016-08-29 17:53:56 --> Model Class Initialized
INFO - 2016-08-29 17:53:57 --> Config Class Initialized
INFO - 2016-08-29 17:53:57 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:53:57 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:53:57 --> Utf8 Class Initialized
INFO - 2016-08-29 17:53:57 --> URI Class Initialized
INFO - 2016-08-29 17:53:57 --> Router Class Initialized
INFO - 2016-08-29 17:53:57 --> Output Class Initialized
INFO - 2016-08-29 17:53:57 --> Security Class Initialized
DEBUG - 2016-08-29 17:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:53:57 --> Input Class Initialized
INFO - 2016-08-29 17:53:57 --> Language Class Initialized
INFO - 2016-08-29 17:53:57 --> Loader Class Initialized
INFO - 2016-08-29 17:53:57 --> Helper loaded: url_helper
INFO - 2016-08-29 17:53:57 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:53:57 --> Helper loaded: html_helper
INFO - 2016-08-29 17:53:57 --> Helper loaded: form_helper
INFO - 2016-08-29 17:53:57 --> Helper loaded: file_helper
INFO - 2016-08-29 17:53:57 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:53:57 --> Database Driver Class Initialized
INFO - 2016-08-29 17:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:53:57 --> Form Validation Class Initialized
INFO - 2016-08-29 17:53:57 --> Email Class Initialized
INFO - 2016-08-29 17:53:57 --> Controller Class Initialized
DEBUG - 2016-08-29 17:53:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:53:57 --> Model Class Initialized
INFO - 2016-08-29 17:53:57 --> Model Class Initialized
INFO - 2016-08-29 17:53:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:53:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:53:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-29 17:53:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:53:57 --> Final output sent to browser
DEBUG - 2016-08-29 17:53:57 --> Total execution time: 0.3756
INFO - 2016-08-29 17:56:30 --> Config Class Initialized
INFO - 2016-08-29 17:56:30 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:56:30 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:56:30 --> Utf8 Class Initialized
INFO - 2016-08-29 17:56:30 --> URI Class Initialized
INFO - 2016-08-29 17:56:30 --> Router Class Initialized
INFO - 2016-08-29 17:56:31 --> Output Class Initialized
INFO - 2016-08-29 17:56:31 --> Security Class Initialized
DEBUG - 2016-08-29 17:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:56:31 --> Input Class Initialized
INFO - 2016-08-29 17:56:31 --> Language Class Initialized
INFO - 2016-08-29 17:56:31 --> Loader Class Initialized
INFO - 2016-08-29 17:56:31 --> Helper loaded: url_helper
INFO - 2016-08-29 17:56:31 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:56:31 --> Helper loaded: html_helper
INFO - 2016-08-29 17:56:31 --> Helper loaded: form_helper
INFO - 2016-08-29 17:56:31 --> Helper loaded: file_helper
INFO - 2016-08-29 17:56:31 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:56:31 --> Database Driver Class Initialized
INFO - 2016-08-29 17:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:56:31 --> Form Validation Class Initialized
INFO - 2016-08-29 17:56:31 --> Email Class Initialized
INFO - 2016-08-29 17:56:31 --> Controller Class Initialized
INFO - 2016-08-29 17:56:31 --> Model Class Initialized
INFO - 2016-08-29 17:56:31 --> Model Class Initialized
DEBUG - 2016-08-29 17:56:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-29 17:56:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:56:31 --> Final output sent to browser
DEBUG - 2016-08-29 17:56:31 --> Total execution time: 0.3865
INFO - 2016-08-29 17:57:56 --> Config Class Initialized
INFO - 2016-08-29 17:57:56 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:57:56 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:57:56 --> Utf8 Class Initialized
INFO - 2016-08-29 17:57:56 --> URI Class Initialized
INFO - 2016-08-29 17:57:56 --> Router Class Initialized
INFO - 2016-08-29 17:57:56 --> Output Class Initialized
INFO - 2016-08-29 17:57:56 --> Security Class Initialized
DEBUG - 2016-08-29 17:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:57:56 --> Input Class Initialized
INFO - 2016-08-29 17:57:56 --> Language Class Initialized
INFO - 2016-08-29 17:57:56 --> Loader Class Initialized
INFO - 2016-08-29 17:57:56 --> Helper loaded: url_helper
INFO - 2016-08-29 17:57:56 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:57:56 --> Helper loaded: html_helper
INFO - 2016-08-29 17:57:56 --> Helper loaded: form_helper
INFO - 2016-08-29 17:57:56 --> Helper loaded: file_helper
INFO - 2016-08-29 17:57:57 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:57:57 --> Database Driver Class Initialized
INFO - 2016-08-29 17:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:57:57 --> Form Validation Class Initialized
INFO - 2016-08-29 17:57:57 --> Email Class Initialized
INFO - 2016-08-29 17:57:57 --> Controller Class Initialized
DEBUG - 2016-08-29 17:57:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:57:57 --> Model Class Initialized
INFO - 2016-08-29 17:57:57 --> Model Class Initialized
INFO - 2016-08-29 17:57:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-29 17:57:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-29 17:57:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-29 17:57:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-29 17:57:57 --> Final output sent to browser
DEBUG - 2016-08-29 17:57:57 --> Total execution time: 0.4167
INFO - 2016-08-29 17:57:59 --> Config Class Initialized
INFO - 2016-08-29 17:57:59 --> Hooks Class Initialized
DEBUG - 2016-08-29 17:57:59 --> UTF-8 Support Enabled
INFO - 2016-08-29 17:57:59 --> Utf8 Class Initialized
INFO - 2016-08-29 17:57:59 --> URI Class Initialized
INFO - 2016-08-29 17:57:59 --> Router Class Initialized
INFO - 2016-08-29 17:57:59 --> Output Class Initialized
INFO - 2016-08-29 17:57:59 --> Security Class Initialized
DEBUG - 2016-08-29 17:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-29 17:57:59 --> Input Class Initialized
INFO - 2016-08-29 17:57:59 --> Language Class Initialized
INFO - 2016-08-29 17:57:59 --> Loader Class Initialized
INFO - 2016-08-29 17:57:59 --> Helper loaded: url_helper
INFO - 2016-08-29 17:57:59 --> Helper loaded: utils_helper
INFO - 2016-08-29 17:57:59 --> Helper loaded: html_helper
INFO - 2016-08-29 17:57:59 --> Helper loaded: form_helper
INFO - 2016-08-29 17:57:59 --> Helper loaded: file_helper
INFO - 2016-08-29 17:57:59 --> Helper loaded: myemail_helper
INFO - 2016-08-29 17:57:59 --> Database Driver Class Initialized
INFO - 2016-08-29 17:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-29 17:57:59 --> Form Validation Class Initialized
INFO - 2016-08-29 17:57:59 --> Email Class Initialized
INFO - 2016-08-29 17:57:59 --> Controller Class Initialized
DEBUG - 2016-08-29 17:57:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-29 17:57:59 --> Final output sent to browser
DEBUG - 2016-08-29 17:57:59 --> Total execution time: 0.3062
