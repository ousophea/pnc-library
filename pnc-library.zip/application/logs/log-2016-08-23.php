<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-23 04:05:43 --> Config Class Initialized
INFO - 2016-08-23 04:05:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:43 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:43 --> URI Class Initialized
DEBUG - 2016-08-23 04:05:43 --> No URI present. Default controller set.
INFO - 2016-08-23 04:05:43 --> Router Class Initialized
INFO - 2016-08-23 04:05:43 --> Output Class Initialized
INFO - 2016-08-23 04:05:43 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:43 --> Input Class Initialized
INFO - 2016-08-23 04:05:43 --> Language Class Initialized
INFO - 2016-08-23 04:05:43 --> Loader Class Initialized
INFO - 2016-08-23 04:05:43 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:43 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:43 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:44 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:44 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:44 --> Email Class Initialized
INFO - 2016-08-23 04:05:44 --> Controller Class Initialized
INFO - 2016-08-23 04:05:44 --> Config Class Initialized
INFO - 2016-08-23 04:05:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:44 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:44 --> URI Class Initialized
INFO - 2016-08-23 04:05:44 --> Router Class Initialized
INFO - 2016-08-23 04:05:44 --> Output Class Initialized
INFO - 2016-08-23 04:05:44 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:44 --> Input Class Initialized
INFO - 2016-08-23 04:05:44 --> Language Class Initialized
INFO - 2016-08-23 04:05:44 --> Loader Class Initialized
INFO - 2016-08-23 04:05:44 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:44 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:44 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:44 --> Email Class Initialized
INFO - 2016-08-23 04:05:44 --> Controller Class Initialized
INFO - 2016-08-23 04:05:44 --> Model Class Initialized
DEBUG - 2016-08-23 04:05:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 04:05:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 04:05:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:05:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 04:05:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:05:44 --> Final output sent to browser
DEBUG - 2016-08-23 04:05:44 --> Total execution time: 0.2615
INFO - 2016-08-23 04:05:45 --> Config Class Initialized
INFO - 2016-08-23 04:05:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:45 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:45 --> URI Class Initialized
INFO - 2016-08-23 04:05:45 --> Router Class Initialized
INFO - 2016-08-23 04:05:45 --> Output Class Initialized
INFO - 2016-08-23 04:05:45 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:45 --> Input Class Initialized
INFO - 2016-08-23 04:05:45 --> Language Class Initialized
ERROR - 2016-08-23 04:05:45 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 04:05:45 --> Config Class Initialized
INFO - 2016-08-23 04:05:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:45 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:45 --> URI Class Initialized
INFO - 2016-08-23 04:05:45 --> Router Class Initialized
INFO - 2016-08-23 04:05:45 --> Output Class Initialized
INFO - 2016-08-23 04:05:45 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:46 --> Input Class Initialized
INFO - 2016-08-23 04:05:46 --> Language Class Initialized
ERROR - 2016-08-23 04:05:46 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 04:05:49 --> Config Class Initialized
INFO - 2016-08-23 04:05:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:49 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:49 --> URI Class Initialized
INFO - 2016-08-23 04:05:49 --> Router Class Initialized
INFO - 2016-08-23 04:05:49 --> Output Class Initialized
INFO - 2016-08-23 04:05:49 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:49 --> Input Class Initialized
INFO - 2016-08-23 04:05:49 --> Language Class Initialized
INFO - 2016-08-23 04:05:49 --> Loader Class Initialized
INFO - 2016-08-23 04:05:49 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:49 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:49 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:49 --> Email Class Initialized
INFO - 2016-08-23 04:05:49 --> Controller Class Initialized
INFO - 2016-08-23 04:05:49 --> Model Class Initialized
DEBUG - 2016-08-23 04:05:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 04:05:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 04:05:49 --> Config Class Initialized
INFO - 2016-08-23 04:05:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:49 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:49 --> URI Class Initialized
DEBUG - 2016-08-23 04:05:49 --> No URI present. Default controller set.
INFO - 2016-08-23 04:05:49 --> Router Class Initialized
INFO - 2016-08-23 04:05:49 --> Output Class Initialized
INFO - 2016-08-23 04:05:49 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:49 --> Input Class Initialized
INFO - 2016-08-23 04:05:49 --> Language Class Initialized
INFO - 2016-08-23 04:05:49 --> Loader Class Initialized
INFO - 2016-08-23 04:05:49 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:49 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:49 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:49 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:49 --> Email Class Initialized
INFO - 2016-08-23 04:05:49 --> Controller Class Initialized
INFO - 2016-08-23 04:05:49 --> Model Class Initialized
INFO - 2016-08-23 04:05:49 --> Model Class Initialized
INFO - 2016-08-23 04:05:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:05:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 04:05:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-23 04:05:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:05:49 --> Final output sent to browser
DEBUG - 2016-08-23 04:05:49 --> Total execution time: 0.2228
INFO - 2016-08-23 04:05:53 --> Config Class Initialized
INFO - 2016-08-23 04:05:53 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:53 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:53 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:53 --> URI Class Initialized
INFO - 2016-08-23 04:05:53 --> Router Class Initialized
INFO - 2016-08-23 04:05:53 --> Output Class Initialized
INFO - 2016-08-23 04:05:53 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:53 --> Input Class Initialized
INFO - 2016-08-23 04:05:53 --> Language Class Initialized
INFO - 2016-08-23 04:05:53 --> Loader Class Initialized
INFO - 2016-08-23 04:05:53 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:53 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:53 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:53 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:53 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:53 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:53 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:53 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:53 --> Email Class Initialized
INFO - 2016-08-23 04:05:53 --> Controller Class Initialized
INFO - 2016-08-23 04:05:53 --> Model Class Initialized
INFO - 2016-08-23 04:05:53 --> Model Class Initialized
INFO - 2016-08-23 04:05:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:05:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 04:05:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 04:05:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:05:53 --> Final output sent to browser
DEBUG - 2016-08-23 04:05:53 --> Total execution time: 0.2825
INFO - 2016-08-23 04:05:57 --> Config Class Initialized
INFO - 2016-08-23 04:05:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:05:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:05:57 --> Utf8 Class Initialized
INFO - 2016-08-23 04:05:57 --> URI Class Initialized
DEBUG - 2016-08-23 04:05:57 --> No URI present. Default controller set.
INFO - 2016-08-23 04:05:57 --> Router Class Initialized
INFO - 2016-08-23 04:05:57 --> Output Class Initialized
INFO - 2016-08-23 04:05:57 --> Security Class Initialized
DEBUG - 2016-08-23 04:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:05:57 --> Input Class Initialized
INFO - 2016-08-23 04:05:57 --> Language Class Initialized
INFO - 2016-08-23 04:05:57 --> Loader Class Initialized
INFO - 2016-08-23 04:05:57 --> Helper loaded: url_helper
INFO - 2016-08-23 04:05:57 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:05:57 --> Helper loaded: html_helper
INFO - 2016-08-23 04:05:57 --> Helper loaded: form_helper
INFO - 2016-08-23 04:05:57 --> Helper loaded: file_helper
INFO - 2016-08-23 04:05:57 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:05:57 --> Database Driver Class Initialized
INFO - 2016-08-23 04:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:05:57 --> Form Validation Class Initialized
INFO - 2016-08-23 04:05:57 --> Email Class Initialized
INFO - 2016-08-23 04:05:57 --> Controller Class Initialized
INFO - 2016-08-23 04:05:57 --> Model Class Initialized
INFO - 2016-08-23 04:05:57 --> Model Class Initialized
INFO - 2016-08-23 04:05:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:05:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 04:05:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-23 04:05:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:05:57 --> Final output sent to browser
DEBUG - 2016-08-23 04:05:57 --> Total execution time: 0.2445
INFO - 2016-08-23 04:07:01 --> Config Class Initialized
INFO - 2016-08-23 04:07:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:07:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:07:01 --> Utf8 Class Initialized
INFO - 2016-08-23 04:07:01 --> URI Class Initialized
INFO - 2016-08-23 04:07:01 --> Router Class Initialized
INFO - 2016-08-23 04:07:01 --> Output Class Initialized
INFO - 2016-08-23 04:07:01 --> Security Class Initialized
DEBUG - 2016-08-23 04:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:07:01 --> Input Class Initialized
INFO - 2016-08-23 04:07:01 --> Language Class Initialized
INFO - 2016-08-23 04:07:01 --> Loader Class Initialized
INFO - 2016-08-23 04:07:01 --> Helper loaded: url_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: html_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: form_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: file_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:07:01 --> Database Driver Class Initialized
INFO - 2016-08-23 04:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:07:01 --> Form Validation Class Initialized
INFO - 2016-08-23 04:07:01 --> Email Class Initialized
INFO - 2016-08-23 04:07:01 --> Controller Class Initialized
INFO - 2016-08-23 04:07:01 --> Model Class Initialized
INFO - 2016-08-23 04:07:01 --> Config Class Initialized
INFO - 2016-08-23 04:07:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:07:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:07:01 --> Utf8 Class Initialized
INFO - 2016-08-23 04:07:01 --> URI Class Initialized
INFO - 2016-08-23 04:07:01 --> Router Class Initialized
INFO - 2016-08-23 04:07:01 --> Output Class Initialized
INFO - 2016-08-23 04:07:01 --> Security Class Initialized
DEBUG - 2016-08-23 04:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:07:01 --> Input Class Initialized
INFO - 2016-08-23 04:07:01 --> Language Class Initialized
INFO - 2016-08-23 04:07:01 --> Loader Class Initialized
INFO - 2016-08-23 04:07:01 --> Helper loaded: url_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: html_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: form_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: file_helper
INFO - 2016-08-23 04:07:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:07:01 --> Database Driver Class Initialized
INFO - 2016-08-23 04:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:07:01 --> Form Validation Class Initialized
INFO - 2016-08-23 04:07:01 --> Email Class Initialized
INFO - 2016-08-23 04:07:01 --> Controller Class Initialized
INFO - 2016-08-23 04:07:01 --> Model Class Initialized
DEBUG - 2016-08-23 04:07:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 04:07:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 04:07:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:07:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 04:07:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:07:01 --> Final output sent to browser
DEBUG - 2016-08-23 04:07:01 --> Total execution time: 0.2388
INFO - 2016-08-23 04:07:03 --> Config Class Initialized
INFO - 2016-08-23 04:07:03 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:07:03 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:07:03 --> Utf8 Class Initialized
INFO - 2016-08-23 04:07:03 --> URI Class Initialized
INFO - 2016-08-23 04:07:03 --> Router Class Initialized
INFO - 2016-08-23 04:07:03 --> Output Class Initialized
INFO - 2016-08-23 04:07:03 --> Security Class Initialized
DEBUG - 2016-08-23 04:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:07:03 --> Input Class Initialized
INFO - 2016-08-23 04:07:03 --> Language Class Initialized
ERROR - 2016-08-23 04:07:03 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 04:32:43 --> Config Class Initialized
INFO - 2016-08-23 04:32:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:32:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:32:43 --> Utf8 Class Initialized
INFO - 2016-08-23 04:32:43 --> URI Class Initialized
INFO - 2016-08-23 04:32:43 --> Router Class Initialized
INFO - 2016-08-23 04:32:43 --> Output Class Initialized
INFO - 2016-08-23 04:32:43 --> Security Class Initialized
DEBUG - 2016-08-23 04:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:32:43 --> Input Class Initialized
INFO - 2016-08-23 04:32:43 --> Language Class Initialized
INFO - 2016-08-23 04:32:43 --> Loader Class Initialized
INFO - 2016-08-23 04:32:43 --> Helper loaded: url_helper
INFO - 2016-08-23 04:32:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:32:43 --> Helper loaded: html_helper
INFO - 2016-08-23 04:32:43 --> Helper loaded: form_helper
INFO - 2016-08-23 04:32:43 --> Helper loaded: file_helper
INFO - 2016-08-23 04:32:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:32:43 --> Database Driver Class Initialized
INFO - 2016-08-23 04:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:32:43 --> Form Validation Class Initialized
INFO - 2016-08-23 04:32:43 --> Email Class Initialized
INFO - 2016-08-23 04:32:43 --> Controller Class Initialized
INFO - 2016-08-23 04:32:43 --> Model Class Initialized
ERROR - 2016-08-23 04:32:43 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:33:06 --> Config Class Initialized
INFO - 2016-08-23 04:33:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:33:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:33:06 --> Utf8 Class Initialized
INFO - 2016-08-23 04:33:06 --> URI Class Initialized
INFO - 2016-08-23 04:33:06 --> Router Class Initialized
INFO - 2016-08-23 04:33:06 --> Output Class Initialized
INFO - 2016-08-23 04:33:06 --> Security Class Initialized
DEBUG - 2016-08-23 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:33:06 --> Input Class Initialized
INFO - 2016-08-23 04:33:06 --> Language Class Initialized
INFO - 2016-08-23 04:33:06 --> Loader Class Initialized
INFO - 2016-08-23 04:33:06 --> Helper loaded: url_helper
INFO - 2016-08-23 04:33:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:33:07 --> Helper loaded: html_helper
INFO - 2016-08-23 04:33:07 --> Helper loaded: form_helper
INFO - 2016-08-23 04:33:07 --> Helper loaded: file_helper
INFO - 2016-08-23 04:33:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:33:07 --> Database Driver Class Initialized
INFO - 2016-08-23 04:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:33:07 --> Form Validation Class Initialized
INFO - 2016-08-23 04:33:07 --> Email Class Initialized
INFO - 2016-08-23 04:33:07 --> Controller Class Initialized
INFO - 2016-08-23 04:33:07 --> Model Class Initialized
ERROR - 2016-08-23 04:33:07 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:34:45 --> Config Class Initialized
INFO - 2016-08-23 04:34:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:34:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:34:45 --> Utf8 Class Initialized
INFO - 2016-08-23 04:34:45 --> URI Class Initialized
INFO - 2016-08-23 04:34:45 --> Router Class Initialized
INFO - 2016-08-23 04:34:45 --> Output Class Initialized
INFO - 2016-08-23 04:34:45 --> Security Class Initialized
DEBUG - 2016-08-23 04:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:34:45 --> Input Class Initialized
INFO - 2016-08-23 04:34:45 --> Language Class Initialized
INFO - 2016-08-23 04:34:45 --> Loader Class Initialized
INFO - 2016-08-23 04:34:45 --> Helper loaded: url_helper
INFO - 2016-08-23 04:34:45 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:34:45 --> Helper loaded: html_helper
INFO - 2016-08-23 04:34:45 --> Helper loaded: form_helper
INFO - 2016-08-23 04:34:45 --> Helper loaded: file_helper
INFO - 2016-08-23 04:34:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:34:45 --> Database Driver Class Initialized
INFO - 2016-08-23 04:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:34:45 --> Form Validation Class Initialized
INFO - 2016-08-23 04:34:45 --> Email Class Initialized
INFO - 2016-08-23 04:34:45 --> Controller Class Initialized
INFO - 2016-08-23 04:34:45 --> Model Class Initialized
ERROR - 2016-08-23 04:34:45 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:34:47 --> Config Class Initialized
INFO - 2016-08-23 04:34:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:34:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:34:47 --> Utf8 Class Initialized
INFO - 2016-08-23 04:34:47 --> URI Class Initialized
INFO - 2016-08-23 04:34:47 --> Router Class Initialized
INFO - 2016-08-23 04:34:47 --> Output Class Initialized
INFO - 2016-08-23 04:34:47 --> Security Class Initialized
DEBUG - 2016-08-23 04:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:34:47 --> Input Class Initialized
INFO - 2016-08-23 04:34:47 --> Language Class Initialized
INFO - 2016-08-23 04:34:47 --> Loader Class Initialized
INFO - 2016-08-23 04:34:47 --> Helper loaded: url_helper
INFO - 2016-08-23 04:34:47 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:34:47 --> Helper loaded: html_helper
INFO - 2016-08-23 04:34:47 --> Helper loaded: form_helper
INFO - 2016-08-23 04:34:47 --> Helper loaded: file_helper
INFO - 2016-08-23 04:34:47 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:34:47 --> Database Driver Class Initialized
INFO - 2016-08-23 04:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:34:47 --> Form Validation Class Initialized
INFO - 2016-08-23 04:34:47 --> Email Class Initialized
INFO - 2016-08-23 04:34:47 --> Controller Class Initialized
INFO - 2016-08-23 04:34:47 --> Model Class Initialized
ERROR - 2016-08-23 04:34:47 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:34:54 --> Config Class Initialized
INFO - 2016-08-23 04:34:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:34:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:34:54 --> Utf8 Class Initialized
INFO - 2016-08-23 04:34:54 --> URI Class Initialized
INFO - 2016-08-23 04:34:54 --> Router Class Initialized
INFO - 2016-08-23 04:34:54 --> Output Class Initialized
INFO - 2016-08-23 04:34:54 --> Security Class Initialized
DEBUG - 2016-08-23 04:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:34:54 --> Input Class Initialized
INFO - 2016-08-23 04:34:54 --> Language Class Initialized
INFO - 2016-08-23 04:34:54 --> Loader Class Initialized
INFO - 2016-08-23 04:34:54 --> Helper loaded: url_helper
INFO - 2016-08-23 04:34:54 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:34:54 --> Helper loaded: html_helper
INFO - 2016-08-23 04:34:54 --> Helper loaded: form_helper
INFO - 2016-08-23 04:34:54 --> Helper loaded: file_helper
INFO - 2016-08-23 04:34:54 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:34:54 --> Database Driver Class Initialized
INFO - 2016-08-23 04:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:34:54 --> Form Validation Class Initialized
INFO - 2016-08-23 04:34:54 --> Email Class Initialized
INFO - 2016-08-23 04:34:54 --> Controller Class Initialized
INFO - 2016-08-23 04:34:54 --> Model Class Initialized
ERROR - 2016-08-23 04:34:54 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:40:57 --> Config Class Initialized
INFO - 2016-08-23 04:40:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:40:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:40:57 --> Utf8 Class Initialized
INFO - 2016-08-23 04:40:57 --> URI Class Initialized
INFO - 2016-08-23 04:40:57 --> Router Class Initialized
INFO - 2016-08-23 04:40:57 --> Output Class Initialized
INFO - 2016-08-23 04:40:57 --> Security Class Initialized
DEBUG - 2016-08-23 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:40:57 --> Input Class Initialized
INFO - 2016-08-23 04:40:57 --> Language Class Initialized
INFO - 2016-08-23 04:40:57 --> Loader Class Initialized
INFO - 2016-08-23 04:40:57 --> Helper loaded: url_helper
INFO - 2016-08-23 04:40:57 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:40:57 --> Helper loaded: html_helper
INFO - 2016-08-23 04:40:57 --> Helper loaded: form_helper
INFO - 2016-08-23 04:40:57 --> Helper loaded: file_helper
INFO - 2016-08-23 04:40:57 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:40:57 --> Database Driver Class Initialized
INFO - 2016-08-23 04:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:40:57 --> Form Validation Class Initialized
INFO - 2016-08-23 04:40:57 --> Email Class Initialized
INFO - 2016-08-23 04:40:57 --> Controller Class Initialized
INFO - 2016-08-23 04:40:57 --> Model Class Initialized
ERROR - 2016-08-23 04:40:57 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:40:58 --> Config Class Initialized
INFO - 2016-08-23 04:40:58 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:40:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:40:58 --> Utf8 Class Initialized
INFO - 2016-08-23 04:40:58 --> URI Class Initialized
INFO - 2016-08-23 04:40:58 --> Router Class Initialized
INFO - 2016-08-23 04:40:58 --> Output Class Initialized
INFO - 2016-08-23 04:40:58 --> Security Class Initialized
DEBUG - 2016-08-23 04:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:40:58 --> Input Class Initialized
INFO - 2016-08-23 04:40:58 --> Language Class Initialized
INFO - 2016-08-23 04:40:58 --> Loader Class Initialized
INFO - 2016-08-23 04:40:58 --> Helper loaded: url_helper
INFO - 2016-08-23 04:40:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:40:58 --> Helper loaded: html_helper
INFO - 2016-08-23 04:40:58 --> Helper loaded: form_helper
INFO - 2016-08-23 04:40:58 --> Helper loaded: file_helper
INFO - 2016-08-23 04:40:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:40:58 --> Database Driver Class Initialized
INFO - 2016-08-23 04:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:40:58 --> Form Validation Class Initialized
INFO - 2016-08-23 04:40:58 --> Email Class Initialized
INFO - 2016-08-23 04:40:58 --> Controller Class Initialized
INFO - 2016-08-23 04:40:58 --> Model Class Initialized
ERROR - 2016-08-23 04:40:58 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:41:01 --> Config Class Initialized
INFO - 2016-08-23 04:41:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:41:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:41:01 --> Utf8 Class Initialized
INFO - 2016-08-23 04:41:01 --> URI Class Initialized
INFO - 2016-08-23 04:41:01 --> Router Class Initialized
INFO - 2016-08-23 04:41:01 --> Output Class Initialized
INFO - 2016-08-23 04:41:01 --> Security Class Initialized
DEBUG - 2016-08-23 04:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:41:01 --> Input Class Initialized
INFO - 2016-08-23 04:41:01 --> Language Class Initialized
INFO - 2016-08-23 04:41:01 --> Loader Class Initialized
INFO - 2016-08-23 04:41:01 --> Helper loaded: url_helper
INFO - 2016-08-23 04:41:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:41:01 --> Helper loaded: html_helper
INFO - 2016-08-23 04:41:01 --> Helper loaded: form_helper
INFO - 2016-08-23 04:41:01 --> Helper loaded: file_helper
INFO - 2016-08-23 04:41:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:41:01 --> Database Driver Class Initialized
INFO - 2016-08-23 04:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:41:01 --> Form Validation Class Initialized
INFO - 2016-08-23 04:41:01 --> Email Class Initialized
INFO - 2016-08-23 04:41:01 --> Controller Class Initialized
INFO - 2016-08-23 04:41:01 --> Model Class Initialized
ERROR - 2016-08-23 04:41:01 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:43:42 --> Config Class Initialized
INFO - 2016-08-23 04:43:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:43:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:43:42 --> Utf8 Class Initialized
INFO - 2016-08-23 04:43:42 --> URI Class Initialized
INFO - 2016-08-23 04:43:42 --> Router Class Initialized
INFO - 2016-08-23 04:43:42 --> Output Class Initialized
INFO - 2016-08-23 04:43:42 --> Security Class Initialized
DEBUG - 2016-08-23 04:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:43:42 --> Input Class Initialized
INFO - 2016-08-23 04:43:42 --> Language Class Initialized
INFO - 2016-08-23 04:43:42 --> Loader Class Initialized
INFO - 2016-08-23 04:43:42 --> Helper loaded: url_helper
INFO - 2016-08-23 04:43:42 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:43:42 --> Helper loaded: html_helper
INFO - 2016-08-23 04:43:42 --> Helper loaded: form_helper
INFO - 2016-08-23 04:43:42 --> Helper loaded: file_helper
INFO - 2016-08-23 04:43:42 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:43:42 --> Database Driver Class Initialized
INFO - 2016-08-23 04:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:43:42 --> Form Validation Class Initialized
INFO - 2016-08-23 04:43:42 --> Email Class Initialized
INFO - 2016-08-23 04:43:42 --> Controller Class Initialized
INFO - 2016-08-23 04:43:42 --> Model Class Initialized
ERROR - 2016-08-23 04:43:42 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:43:45 --> Config Class Initialized
INFO - 2016-08-23 04:43:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:43:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:43:45 --> Utf8 Class Initialized
INFO - 2016-08-23 04:43:45 --> URI Class Initialized
DEBUG - 2016-08-23 04:43:45 --> No URI present. Default controller set.
INFO - 2016-08-23 04:43:45 --> Router Class Initialized
INFO - 2016-08-23 04:43:45 --> Output Class Initialized
INFO - 2016-08-23 04:43:45 --> Security Class Initialized
DEBUG - 2016-08-23 04:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:43:45 --> Input Class Initialized
INFO - 2016-08-23 04:43:45 --> Language Class Initialized
INFO - 2016-08-23 04:43:45 --> Loader Class Initialized
INFO - 2016-08-23 04:43:45 --> Helper loaded: url_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: html_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: form_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: file_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:43:45 --> Database Driver Class Initialized
INFO - 2016-08-23 04:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:43:45 --> Form Validation Class Initialized
INFO - 2016-08-23 04:43:45 --> Email Class Initialized
INFO - 2016-08-23 04:43:45 --> Controller Class Initialized
INFO - 2016-08-23 04:43:45 --> Config Class Initialized
INFO - 2016-08-23 04:43:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:43:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:43:45 --> Utf8 Class Initialized
INFO - 2016-08-23 04:43:45 --> URI Class Initialized
INFO - 2016-08-23 04:43:45 --> Router Class Initialized
INFO - 2016-08-23 04:43:45 --> Output Class Initialized
INFO - 2016-08-23 04:43:45 --> Security Class Initialized
DEBUG - 2016-08-23 04:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:43:45 --> Input Class Initialized
INFO - 2016-08-23 04:43:45 --> Language Class Initialized
INFO - 2016-08-23 04:43:45 --> Loader Class Initialized
INFO - 2016-08-23 04:43:45 --> Helper loaded: url_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: html_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: form_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: file_helper
INFO - 2016-08-23 04:43:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:43:45 --> Database Driver Class Initialized
INFO - 2016-08-23 04:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:43:45 --> Form Validation Class Initialized
INFO - 2016-08-23 04:43:45 --> Email Class Initialized
INFO - 2016-08-23 04:43:45 --> Controller Class Initialized
INFO - 2016-08-23 04:43:45 --> Model Class Initialized
DEBUG - 2016-08-23 04:43:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 04:43:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 04:43:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 04:43:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 04:43:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 04:43:45 --> Final output sent to browser
DEBUG - 2016-08-23 04:43:45 --> Total execution time: 0.2439
INFO - 2016-08-23 04:43:47 --> Config Class Initialized
INFO - 2016-08-23 04:43:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:43:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:43:47 --> Utf8 Class Initialized
INFO - 2016-08-23 04:43:47 --> URI Class Initialized
INFO - 2016-08-23 04:43:47 --> Router Class Initialized
INFO - 2016-08-23 04:43:47 --> Output Class Initialized
INFO - 2016-08-23 04:43:47 --> Security Class Initialized
DEBUG - 2016-08-23 04:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:43:47 --> Input Class Initialized
INFO - 2016-08-23 04:43:47 --> Language Class Initialized
ERROR - 2016-08-23 04:43:47 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 04:44:21 --> Config Class Initialized
INFO - 2016-08-23 04:44:21 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:44:21 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:44:21 --> Utf8 Class Initialized
INFO - 2016-08-23 04:44:21 --> URI Class Initialized
INFO - 2016-08-23 04:44:21 --> Router Class Initialized
INFO - 2016-08-23 04:44:21 --> Output Class Initialized
INFO - 2016-08-23 04:44:21 --> Security Class Initialized
DEBUG - 2016-08-23 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:44:21 --> Input Class Initialized
INFO - 2016-08-23 04:44:21 --> Language Class Initialized
ERROR - 2016-08-23 04:44:21 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 04:44:24 --> Config Class Initialized
INFO - 2016-08-23 04:44:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:44:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:44:24 --> Utf8 Class Initialized
INFO - 2016-08-23 04:44:24 --> URI Class Initialized
INFO - 2016-08-23 04:44:24 --> Router Class Initialized
INFO - 2016-08-23 04:44:24 --> Output Class Initialized
INFO - 2016-08-23 04:44:24 --> Security Class Initialized
DEBUG - 2016-08-23 04:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:44:24 --> Input Class Initialized
INFO - 2016-08-23 04:44:24 --> Language Class Initialized
INFO - 2016-08-23 04:44:24 --> Loader Class Initialized
INFO - 2016-08-23 04:44:24 --> Helper loaded: url_helper
INFO - 2016-08-23 04:44:24 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:44:24 --> Helper loaded: html_helper
INFO - 2016-08-23 04:44:24 --> Helper loaded: form_helper
INFO - 2016-08-23 04:44:24 --> Helper loaded: file_helper
INFO - 2016-08-23 04:44:24 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:44:24 --> Database Driver Class Initialized
INFO - 2016-08-23 04:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:44:24 --> Form Validation Class Initialized
INFO - 2016-08-23 04:44:24 --> Email Class Initialized
INFO - 2016-08-23 04:44:24 --> Controller Class Initialized
INFO - 2016-08-23 04:44:24 --> Model Class Initialized
ERROR - 2016-08-23 04:44:24 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:50:19 --> Config Class Initialized
INFO - 2016-08-23 04:50:19 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:50:19 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:50:19 --> Utf8 Class Initialized
INFO - 2016-08-23 04:50:19 --> URI Class Initialized
INFO - 2016-08-23 04:50:19 --> Router Class Initialized
INFO - 2016-08-23 04:50:19 --> Output Class Initialized
INFO - 2016-08-23 04:50:19 --> Security Class Initialized
DEBUG - 2016-08-23 04:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:50:19 --> Input Class Initialized
INFO - 2016-08-23 04:50:19 --> Language Class Initialized
INFO - 2016-08-23 04:50:19 --> Loader Class Initialized
INFO - 2016-08-23 04:50:19 --> Helper loaded: url_helper
INFO - 2016-08-23 04:50:19 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:50:19 --> Helper loaded: html_helper
INFO - 2016-08-23 04:50:19 --> Helper loaded: form_helper
INFO - 2016-08-23 04:50:19 --> Helper loaded: file_helper
INFO - 2016-08-23 04:50:19 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:50:19 --> Database Driver Class Initialized
INFO - 2016-08-23 04:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:50:19 --> Form Validation Class Initialized
INFO - 2016-08-23 04:50:19 --> Email Class Initialized
INFO - 2016-08-23 04:50:19 --> Controller Class Initialized
INFO - 2016-08-23 04:50:19 --> Model Class Initialized
ERROR - 2016-08-23 04:50:19 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 29
INFO - 2016-08-23 04:50:26 --> Config Class Initialized
INFO - 2016-08-23 04:50:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:50:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:50:26 --> Utf8 Class Initialized
INFO - 2016-08-23 04:50:26 --> URI Class Initialized
INFO - 2016-08-23 04:50:26 --> Router Class Initialized
INFO - 2016-08-23 04:50:26 --> Output Class Initialized
INFO - 2016-08-23 04:50:26 --> Security Class Initialized
DEBUG - 2016-08-23 04:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:50:26 --> Input Class Initialized
INFO - 2016-08-23 04:50:26 --> Language Class Initialized
INFO - 2016-08-23 04:50:26 --> Loader Class Initialized
INFO - 2016-08-23 04:50:26 --> Helper loaded: url_helper
INFO - 2016-08-23 04:50:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:50:26 --> Helper loaded: html_helper
INFO - 2016-08-23 04:50:26 --> Helper loaded: form_helper
INFO - 2016-08-23 04:50:26 --> Helper loaded: file_helper
INFO - 2016-08-23 04:50:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:50:26 --> Database Driver Class Initialized
INFO - 2016-08-23 04:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:50:26 --> Form Validation Class Initialized
INFO - 2016-08-23 04:50:26 --> Email Class Initialized
INFO - 2016-08-23 04:50:26 --> Controller Class Initialized
INFO - 2016-08-23 04:50:26 --> Model Class Initialized
ERROR - 2016-08-23 04:50:27 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:52:11 --> Config Class Initialized
INFO - 2016-08-23 04:52:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:52:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:52:11 --> Utf8 Class Initialized
INFO - 2016-08-23 04:52:11 --> URI Class Initialized
INFO - 2016-08-23 04:52:11 --> Router Class Initialized
INFO - 2016-08-23 04:52:11 --> Output Class Initialized
INFO - 2016-08-23 04:52:11 --> Security Class Initialized
DEBUG - 2016-08-23 04:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:52:11 --> Input Class Initialized
INFO - 2016-08-23 04:52:11 --> Language Class Initialized
INFO - 2016-08-23 04:52:11 --> Loader Class Initialized
INFO - 2016-08-23 04:52:11 --> Helper loaded: url_helper
INFO - 2016-08-23 04:52:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:52:11 --> Helper loaded: html_helper
INFO - 2016-08-23 04:52:11 --> Helper loaded: form_helper
INFO - 2016-08-23 04:52:11 --> Helper loaded: file_helper
INFO - 2016-08-23 04:52:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:52:11 --> Database Driver Class Initialized
INFO - 2016-08-23 04:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:52:11 --> Form Validation Class Initialized
INFO - 2016-08-23 04:52:11 --> Email Class Initialized
INFO - 2016-08-23 04:52:11 --> Controller Class Initialized
INFO - 2016-08-23 04:52:11 --> Model Class Initialized
ERROR - 2016-08-23 04:52:11 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:53:04 --> Config Class Initialized
INFO - 2016-08-23 04:53:04 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:53:04 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:53:04 --> Utf8 Class Initialized
INFO - 2016-08-23 04:53:04 --> URI Class Initialized
INFO - 2016-08-23 04:53:04 --> Router Class Initialized
INFO - 2016-08-23 04:53:04 --> Output Class Initialized
INFO - 2016-08-23 04:53:04 --> Security Class Initialized
DEBUG - 2016-08-23 04:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:53:04 --> Input Class Initialized
INFO - 2016-08-23 04:53:04 --> Language Class Initialized
INFO - 2016-08-23 04:53:04 --> Loader Class Initialized
INFO - 2016-08-23 04:53:04 --> Helper loaded: url_helper
INFO - 2016-08-23 04:53:04 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:53:04 --> Helper loaded: html_helper
INFO - 2016-08-23 04:53:04 --> Helper loaded: form_helper
INFO - 2016-08-23 04:53:04 --> Helper loaded: file_helper
INFO - 2016-08-23 04:53:04 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:53:04 --> Database Driver Class Initialized
INFO - 2016-08-23 04:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:53:05 --> Form Validation Class Initialized
INFO - 2016-08-23 04:53:05 --> Email Class Initialized
INFO - 2016-08-23 04:53:05 --> Controller Class Initialized
INFO - 2016-08-23 04:53:05 --> Model Class Initialized
ERROR - 2016-08-23 04:53:05 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:53:09 --> Config Class Initialized
INFO - 2016-08-23 04:53:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:53:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:53:09 --> Utf8 Class Initialized
INFO - 2016-08-23 04:53:09 --> URI Class Initialized
INFO - 2016-08-23 04:53:09 --> Router Class Initialized
INFO - 2016-08-23 04:53:09 --> Output Class Initialized
INFO - 2016-08-23 04:53:09 --> Security Class Initialized
DEBUG - 2016-08-23 04:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:53:09 --> Input Class Initialized
INFO - 2016-08-23 04:53:09 --> Language Class Initialized
INFO - 2016-08-23 04:53:09 --> Loader Class Initialized
INFO - 2016-08-23 04:53:09 --> Helper loaded: url_helper
INFO - 2016-08-23 04:53:09 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:53:09 --> Helper loaded: html_helper
INFO - 2016-08-23 04:53:09 --> Helper loaded: form_helper
INFO - 2016-08-23 04:53:09 --> Helper loaded: file_helper
INFO - 2016-08-23 04:53:09 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:53:09 --> Database Driver Class Initialized
INFO - 2016-08-23 04:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:53:09 --> Form Validation Class Initialized
INFO - 2016-08-23 04:53:09 --> Email Class Initialized
INFO - 2016-08-23 04:53:09 --> Controller Class Initialized
INFO - 2016-08-23 04:53:09 --> Model Class Initialized
ERROR - 2016-08-23 04:53:09 --> Severity: Error --> Class 'Google_ServiceResource' not found D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\contrib\Google_Oauth2Service.php 25
INFO - 2016-08-23 04:53:34 --> Config Class Initialized
INFO - 2016-08-23 04:53:34 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:53:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:53:34 --> Utf8 Class Initialized
INFO - 2016-08-23 04:53:34 --> URI Class Initialized
INFO - 2016-08-23 04:53:34 --> Router Class Initialized
INFO - 2016-08-23 04:53:34 --> Output Class Initialized
INFO - 2016-08-23 04:53:34 --> Security Class Initialized
DEBUG - 2016-08-23 04:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:53:34 --> Input Class Initialized
INFO - 2016-08-23 04:53:34 --> Language Class Initialized
INFO - 2016-08-23 04:53:34 --> Loader Class Initialized
INFO - 2016-08-23 04:53:34 --> Helper loaded: url_helper
INFO - 2016-08-23 04:53:34 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:53:34 --> Helper loaded: html_helper
INFO - 2016-08-23 04:53:34 --> Helper loaded: form_helper
INFO - 2016-08-23 04:53:34 --> Helper loaded: file_helper
INFO - 2016-08-23 04:53:34 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:53:34 --> Database Driver Class Initialized
INFO - 2016-08-23 04:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:53:34 --> Form Validation Class Initialized
INFO - 2016-08-23 04:53:34 --> Email Class Initialized
INFO - 2016-08-23 04:53:34 --> Controller Class Initialized
INFO - 2016-08-23 04:53:34 --> Model Class Initialized
ERROR - 2016-08-23 04:53:34 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\User_authentication.php 29
INFO - 2016-08-23 04:56:43 --> Config Class Initialized
INFO - 2016-08-23 04:56:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:56:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:56:43 --> Utf8 Class Initialized
INFO - 2016-08-23 04:56:43 --> URI Class Initialized
INFO - 2016-08-23 04:56:43 --> Router Class Initialized
INFO - 2016-08-23 04:56:43 --> Output Class Initialized
INFO - 2016-08-23 04:56:43 --> Security Class Initialized
DEBUG - 2016-08-23 04:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:56:43 --> Input Class Initialized
INFO - 2016-08-23 04:56:43 --> Language Class Initialized
INFO - 2016-08-23 04:56:43 --> Loader Class Initialized
INFO - 2016-08-23 04:56:43 --> Helper loaded: url_helper
INFO - 2016-08-23 04:56:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:56:43 --> Helper loaded: html_helper
INFO - 2016-08-23 04:56:43 --> Helper loaded: form_helper
INFO - 2016-08-23 04:56:43 --> Helper loaded: file_helper
INFO - 2016-08-23 04:56:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:56:43 --> Database Driver Class Initialized
INFO - 2016-08-23 04:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:56:43 --> Form Validation Class Initialized
INFO - 2016-08-23 04:56:43 --> Email Class Initialized
INFO - 2016-08-23 04:56:43 --> Controller Class Initialized
INFO - 2016-08-23 04:56:43 --> Model Class Initialized
ERROR - 2016-08-23 04:56:43 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 04:57:50 --> Config Class Initialized
INFO - 2016-08-23 04:57:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 04:57:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 04:57:50 --> Utf8 Class Initialized
INFO - 2016-08-23 04:57:50 --> URI Class Initialized
INFO - 2016-08-23 04:57:50 --> Router Class Initialized
INFO - 2016-08-23 04:57:50 --> Output Class Initialized
INFO - 2016-08-23 04:57:50 --> Security Class Initialized
DEBUG - 2016-08-23 04:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 04:57:50 --> Input Class Initialized
INFO - 2016-08-23 04:57:50 --> Language Class Initialized
INFO - 2016-08-23 04:57:50 --> Loader Class Initialized
INFO - 2016-08-23 04:57:50 --> Helper loaded: url_helper
INFO - 2016-08-23 04:57:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 04:57:50 --> Helper loaded: html_helper
INFO - 2016-08-23 04:57:50 --> Helper loaded: form_helper
INFO - 2016-08-23 04:57:50 --> Helper loaded: file_helper
INFO - 2016-08-23 04:57:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 04:57:50 --> Database Driver Class Initialized
INFO - 2016-08-23 04:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 04:57:50 --> Form Validation Class Initialized
INFO - 2016-08-23 04:57:50 --> Email Class Initialized
INFO - 2016-08-23 04:57:50 --> Controller Class Initialized
INFO - 2016-08-23 04:57:50 --> Model Class Initialized
ERROR - 2016-08-23 04:57:50 --> Severity: error --> Exception: Google PHP API Client requires the CURL PHP extension D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\Google_Client.php 21
INFO - 2016-08-23 05:02:27 --> Config Class Initialized
INFO - 2016-08-23 05:02:27 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:02:27 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:02:27 --> Utf8 Class Initialized
INFO - 2016-08-23 05:02:27 --> URI Class Initialized
INFO - 2016-08-23 05:02:27 --> Router Class Initialized
INFO - 2016-08-23 05:02:27 --> Output Class Initialized
INFO - 2016-08-23 05:02:27 --> Security Class Initialized
DEBUG - 2016-08-23 05:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:02:27 --> Input Class Initialized
INFO - 2016-08-23 05:02:27 --> Language Class Initialized
INFO - 2016-08-23 05:02:27 --> Loader Class Initialized
INFO - 2016-08-23 05:02:27 --> Helper loaded: url_helper
INFO - 2016-08-23 05:02:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:02:27 --> Helper loaded: html_helper
INFO - 2016-08-23 05:02:27 --> Helper loaded: form_helper
INFO - 2016-08-23 05:02:27 --> Helper loaded: file_helper
INFO - 2016-08-23 05:02:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:02:27 --> Database Driver Class Initialized
INFO - 2016-08-23 05:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:02:27 --> Form Validation Class Initialized
INFO - 2016-08-23 05:02:27 --> Email Class Initialized
INFO - 2016-08-23 05:02:27 --> Controller Class Initialized
INFO - 2016-08-23 05:02:27 --> Model Class Initialized
ERROR - 2016-08-23 05:02:28 --> Severity: 4096 --> Argument 1 passed to Google_Oauth2Service::__construct() must be an instance of Google_Client, none given, called in D:\wamp\www\library.pnc.lan\system\core\Loader.php on line 1247 and defined D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\contrib\Google_Oauth2Service.php 110
ERROR - 2016-08-23 05:02:28 --> Severity: Notice --> Undefined variable: client D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\contrib\Google_Oauth2Service.php 115
ERROR - 2016-08-23 05:02:28 --> Severity: Error --> Call to a member function addService() on a non-object D:\wamp\www\library.pnc.lan\application\libraries\google-api-php-client\contrib\Google_Oauth2Service.php 115
INFO - 2016-08-23 05:03:11 --> Config Class Initialized
INFO - 2016-08-23 05:03:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:03:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:03:11 --> Utf8 Class Initialized
INFO - 2016-08-23 05:03:11 --> URI Class Initialized
INFO - 2016-08-23 05:03:11 --> Router Class Initialized
INFO - 2016-08-23 05:03:11 --> Output Class Initialized
INFO - 2016-08-23 05:03:11 --> Security Class Initialized
DEBUG - 2016-08-23 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:03:11 --> Input Class Initialized
INFO - 2016-08-23 05:03:11 --> Language Class Initialized
INFO - 2016-08-23 05:03:11 --> Loader Class Initialized
INFO - 2016-08-23 05:03:11 --> Helper loaded: url_helper
INFO - 2016-08-23 05:03:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:03:11 --> Helper loaded: html_helper
INFO - 2016-08-23 05:03:11 --> Helper loaded: form_helper
INFO - 2016-08-23 05:03:11 --> Helper loaded: file_helper
INFO - 2016-08-23 05:03:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:03:11 --> Database Driver Class Initialized
INFO - 2016-08-23 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:03:11 --> Form Validation Class Initialized
INFO - 2016-08-23 05:03:11 --> Email Class Initialized
INFO - 2016-08-23 05:03:11 --> Controller Class Initialized
INFO - 2016-08-23 05:03:11 --> Model Class Initialized
INFO - 2016-08-23 05:03:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 05:03:11 --> Final output sent to browser
DEBUG - 2016-08-23 05:03:11 --> Total execution time: 0.2575
INFO - 2016-08-23 05:03:12 --> Config Class Initialized
INFO - 2016-08-23 05:03:12 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:03:12 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:03:12 --> Utf8 Class Initialized
INFO - 2016-08-23 05:03:12 --> URI Class Initialized
INFO - 2016-08-23 05:03:12 --> Router Class Initialized
INFO - 2016-08-23 05:03:12 --> Output Class Initialized
INFO - 2016-08-23 05:03:12 --> Security Class Initialized
DEBUG - 2016-08-23 05:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:03:12 --> Input Class Initialized
INFO - 2016-08-23 05:03:12 --> Language Class Initialized
ERROR - 2016-08-23 05:03:12 --> 404 Page Not Found: Assets/images
INFO - 2016-08-23 05:03:18 --> Config Class Initialized
INFO - 2016-08-23 05:03:18 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:03:18 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:03:18 --> Utf8 Class Initialized
INFO - 2016-08-23 05:03:18 --> URI Class Initialized
INFO - 2016-08-23 05:03:18 --> Router Class Initialized
INFO - 2016-08-23 05:03:18 --> Output Class Initialized
INFO - 2016-08-23 05:03:18 --> Security Class Initialized
DEBUG - 2016-08-23 05:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:03:18 --> Input Class Initialized
INFO - 2016-08-23 05:03:18 --> Language Class Initialized
INFO - 2016-08-23 05:03:18 --> Loader Class Initialized
INFO - 2016-08-23 05:03:18 --> Helper loaded: url_helper
INFO - 2016-08-23 05:03:18 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:03:18 --> Helper loaded: html_helper
INFO - 2016-08-23 05:03:18 --> Helper loaded: form_helper
INFO - 2016-08-23 05:03:18 --> Helper loaded: file_helper
INFO - 2016-08-23 05:03:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:03:18 --> Database Driver Class Initialized
INFO - 2016-08-23 05:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:03:18 --> Form Validation Class Initialized
INFO - 2016-08-23 05:03:18 --> Email Class Initialized
INFO - 2016-08-23 05:03:18 --> Controller Class Initialized
INFO - 2016-08-23 05:03:18 --> Model Class Initialized
INFO - 2016-08-23 05:03:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 05:03:18 --> Final output sent to browser
DEBUG - 2016-08-23 05:03:18 --> Total execution time: 0.2369
INFO - 2016-08-23 05:03:18 --> Config Class Initialized
INFO - 2016-08-23 05:03:18 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:03:18 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:03:18 --> Utf8 Class Initialized
INFO - 2016-08-23 05:03:18 --> URI Class Initialized
INFO - 2016-08-23 05:03:18 --> Router Class Initialized
INFO - 2016-08-23 05:03:18 --> Output Class Initialized
INFO - 2016-08-23 05:03:18 --> Security Class Initialized
DEBUG - 2016-08-23 05:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:03:18 --> Input Class Initialized
INFO - 2016-08-23 05:03:18 --> Language Class Initialized
ERROR - 2016-08-23 05:03:18 --> 404 Page Not Found: Assets/images
INFO - 2016-08-23 05:04:37 --> Config Class Initialized
INFO - 2016-08-23 05:04:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:04:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:04:37 --> Utf8 Class Initialized
INFO - 2016-08-23 05:04:37 --> URI Class Initialized
DEBUG - 2016-08-23 05:04:37 --> No URI present. Default controller set.
INFO - 2016-08-23 05:04:37 --> Router Class Initialized
INFO - 2016-08-23 05:04:37 --> Output Class Initialized
INFO - 2016-08-23 05:04:37 --> Security Class Initialized
DEBUG - 2016-08-23 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:04:37 --> Input Class Initialized
INFO - 2016-08-23 05:04:37 --> Language Class Initialized
INFO - 2016-08-23 05:04:37 --> Loader Class Initialized
INFO - 2016-08-23 05:04:37 --> Helper loaded: url_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: html_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: form_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: file_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:04:37 --> Database Driver Class Initialized
INFO - 2016-08-23 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:04:37 --> Form Validation Class Initialized
INFO - 2016-08-23 05:04:37 --> Email Class Initialized
INFO - 2016-08-23 05:04:37 --> Controller Class Initialized
INFO - 2016-08-23 05:04:37 --> Config Class Initialized
INFO - 2016-08-23 05:04:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:04:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:04:37 --> Utf8 Class Initialized
INFO - 2016-08-23 05:04:37 --> URI Class Initialized
INFO - 2016-08-23 05:04:37 --> Router Class Initialized
INFO - 2016-08-23 05:04:37 --> Output Class Initialized
INFO - 2016-08-23 05:04:37 --> Security Class Initialized
DEBUG - 2016-08-23 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:04:37 --> Input Class Initialized
INFO - 2016-08-23 05:04:37 --> Language Class Initialized
INFO - 2016-08-23 05:04:37 --> Loader Class Initialized
INFO - 2016-08-23 05:04:37 --> Helper loaded: url_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: html_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: form_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: file_helper
INFO - 2016-08-23 05:04:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:04:37 --> Database Driver Class Initialized
INFO - 2016-08-23 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:04:37 --> Form Validation Class Initialized
INFO - 2016-08-23 05:04:37 --> Email Class Initialized
INFO - 2016-08-23 05:04:37 --> Controller Class Initialized
INFO - 2016-08-23 05:04:37 --> Model Class Initialized
DEBUG - 2016-08-23 05:04:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 05:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 05:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 05:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 05:04:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 05:04:37 --> Final output sent to browser
DEBUG - 2016-08-23 05:04:37 --> Total execution time: 0.3255
INFO - 2016-08-23 05:04:42 --> Config Class Initialized
INFO - 2016-08-23 05:04:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:04:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:04:42 --> Utf8 Class Initialized
INFO - 2016-08-23 05:04:42 --> URI Class Initialized
INFO - 2016-08-23 05:04:42 --> Router Class Initialized
INFO - 2016-08-23 05:04:42 --> Output Class Initialized
INFO - 2016-08-23 05:04:42 --> Security Class Initialized
DEBUG - 2016-08-23 05:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:04:42 --> Input Class Initialized
INFO - 2016-08-23 05:04:42 --> Language Class Initialized
ERROR - 2016-08-23 05:04:42 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 05:04:46 --> Config Class Initialized
INFO - 2016-08-23 05:04:46 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:04:46 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:04:46 --> Utf8 Class Initialized
INFO - 2016-08-23 05:04:46 --> URI Class Initialized
INFO - 2016-08-23 05:04:46 --> Router Class Initialized
INFO - 2016-08-23 05:04:46 --> Output Class Initialized
INFO - 2016-08-23 05:04:46 --> Security Class Initialized
DEBUG - 2016-08-23 05:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:04:46 --> Input Class Initialized
INFO - 2016-08-23 05:04:46 --> Language Class Initialized
INFO - 2016-08-23 05:04:46 --> Loader Class Initialized
INFO - 2016-08-23 05:04:46 --> Helper loaded: url_helper
INFO - 2016-08-23 05:04:46 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:04:46 --> Helper loaded: html_helper
INFO - 2016-08-23 05:04:46 --> Helper loaded: form_helper
INFO - 2016-08-23 05:04:46 --> Helper loaded: file_helper
INFO - 2016-08-23 05:04:46 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:04:46 --> Database Driver Class Initialized
INFO - 2016-08-23 05:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:04:46 --> Form Validation Class Initialized
INFO - 2016-08-23 05:04:46 --> Email Class Initialized
INFO - 2016-08-23 05:04:46 --> Controller Class Initialized
INFO - 2016-08-23 05:04:46 --> Model Class Initialized
DEBUG - 2016-08-23 05:04:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 05:04:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 05:04:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 05:04:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 05:04:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 05:04:46 --> Final output sent to browser
DEBUG - 2016-08-23 05:04:46 --> Total execution time: 0.2722
INFO - 2016-08-23 05:05:00 --> Config Class Initialized
INFO - 2016-08-23 05:05:00 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:05:00 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:05:00 --> Utf8 Class Initialized
INFO - 2016-08-23 05:05:00 --> URI Class Initialized
INFO - 2016-08-23 05:05:00 --> Router Class Initialized
INFO - 2016-08-23 05:05:00 --> Output Class Initialized
INFO - 2016-08-23 05:05:00 --> Security Class Initialized
DEBUG - 2016-08-23 05:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:05:00 --> Input Class Initialized
INFO - 2016-08-23 05:05:00 --> Language Class Initialized
INFO - 2016-08-23 05:05:00 --> Loader Class Initialized
INFO - 2016-08-23 05:05:00 --> Helper loaded: url_helper
INFO - 2016-08-23 05:05:00 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:05:00 --> Helper loaded: html_helper
INFO - 2016-08-23 05:05:00 --> Helper loaded: form_helper
INFO - 2016-08-23 05:05:00 --> Helper loaded: file_helper
INFO - 2016-08-23 05:05:00 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:05:00 --> Database Driver Class Initialized
INFO - 2016-08-23 05:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:05:00 --> Form Validation Class Initialized
INFO - 2016-08-23 05:05:00 --> Email Class Initialized
INFO - 2016-08-23 05:05:00 --> Controller Class Initialized
INFO - 2016-08-23 05:05:00 --> Model Class Initialized
DEBUG - 2016-08-23 05:05:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 05:05:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 05:05:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 05:05:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 05:05:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 05:05:00 --> Final output sent to browser
DEBUG - 2016-08-23 05:05:00 --> Total execution time: 0.2591
INFO - 2016-08-23 05:05:01 --> Config Class Initialized
INFO - 2016-08-23 05:05:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:05:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:05:01 --> Utf8 Class Initialized
INFO - 2016-08-23 05:05:01 --> URI Class Initialized
INFO - 2016-08-23 05:05:01 --> Router Class Initialized
INFO - 2016-08-23 05:05:01 --> Output Class Initialized
INFO - 2016-08-23 05:05:01 --> Security Class Initialized
DEBUG - 2016-08-23 05:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:05:01 --> Input Class Initialized
INFO - 2016-08-23 05:05:01 --> Language Class Initialized
INFO - 2016-08-23 05:05:01 --> Loader Class Initialized
INFO - 2016-08-23 05:05:01 --> Helper loaded: url_helper
INFO - 2016-08-23 05:05:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:05:01 --> Helper loaded: html_helper
INFO - 2016-08-23 05:05:01 --> Helper loaded: form_helper
INFO - 2016-08-23 05:05:01 --> Helper loaded: file_helper
INFO - 2016-08-23 05:05:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:05:01 --> Database Driver Class Initialized
INFO - 2016-08-23 05:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:05:01 --> Form Validation Class Initialized
INFO - 2016-08-23 05:05:01 --> Email Class Initialized
INFO - 2016-08-23 05:05:01 --> Controller Class Initialized
INFO - 2016-08-23 05:05:01 --> Model Class Initialized
INFO - 2016-08-23 05:05:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 05:05:01 --> Final output sent to browser
DEBUG - 2016-08-23 05:05:01 --> Total execution time: 0.2540
INFO - 2016-08-23 05:05:02 --> Config Class Initialized
INFO - 2016-08-23 05:05:02 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:05:02 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:05:02 --> Utf8 Class Initialized
INFO - 2016-08-23 05:05:02 --> URI Class Initialized
INFO - 2016-08-23 05:05:02 --> Router Class Initialized
INFO - 2016-08-23 05:05:02 --> Output Class Initialized
INFO - 2016-08-23 05:05:02 --> Security Class Initialized
DEBUG - 2016-08-23 05:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:05:02 --> Input Class Initialized
INFO - 2016-08-23 05:05:02 --> Language Class Initialized
ERROR - 2016-08-23 05:05:02 --> 404 Page Not Found: Assets/images
INFO - 2016-08-23 05:06:34 --> Config Class Initialized
INFO - 2016-08-23 05:06:34 --> Hooks Class Initialized
DEBUG - 2016-08-23 05:06:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 05:06:34 --> Utf8 Class Initialized
INFO - 2016-08-23 05:06:34 --> URI Class Initialized
INFO - 2016-08-23 05:06:34 --> Router Class Initialized
INFO - 2016-08-23 05:06:34 --> Output Class Initialized
INFO - 2016-08-23 05:06:35 --> Security Class Initialized
DEBUG - 2016-08-23 05:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 05:06:35 --> Input Class Initialized
INFO - 2016-08-23 05:06:35 --> Language Class Initialized
INFO - 2016-08-23 05:06:35 --> Loader Class Initialized
INFO - 2016-08-23 05:06:35 --> Helper loaded: url_helper
INFO - 2016-08-23 05:06:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 05:06:35 --> Helper loaded: html_helper
INFO - 2016-08-23 05:06:35 --> Helper loaded: form_helper
INFO - 2016-08-23 05:06:35 --> Helper loaded: file_helper
INFO - 2016-08-23 05:06:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 05:06:35 --> Database Driver Class Initialized
INFO - 2016-08-23 05:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 05:06:35 --> Form Validation Class Initialized
INFO - 2016-08-23 05:06:35 --> Email Class Initialized
INFO - 2016-08-23 05:06:35 --> Controller Class Initialized
INFO - 2016-08-23 05:06:35 --> Model Class Initialized
INFO - 2016-08-23 05:06:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 05:06:35 --> Final output sent to browser
DEBUG - 2016-08-23 05:06:35 --> Total execution time: 0.2398
INFO - 2016-08-23 06:10:50 --> Config Class Initialized
INFO - 2016-08-23 06:10:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:10:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:10:50 --> Utf8 Class Initialized
INFO - 2016-08-23 06:10:50 --> URI Class Initialized
INFO - 2016-08-23 06:10:50 --> Router Class Initialized
INFO - 2016-08-23 06:10:50 --> Output Class Initialized
INFO - 2016-08-23 06:10:50 --> Security Class Initialized
DEBUG - 2016-08-23 06:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:10:50 --> Input Class Initialized
INFO - 2016-08-23 06:10:50 --> Language Class Initialized
INFO - 2016-08-23 06:10:50 --> Loader Class Initialized
INFO - 2016-08-23 06:10:50 --> Helper loaded: url_helper
INFO - 2016-08-23 06:10:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:10:50 --> Helper loaded: html_helper
INFO - 2016-08-23 06:10:50 --> Helper loaded: form_helper
INFO - 2016-08-23 06:10:50 --> Helper loaded: file_helper
INFO - 2016-08-23 06:10:51 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:10:51 --> Database Driver Class Initialized
INFO - 2016-08-23 06:10:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:10:51 --> Form Validation Class Initialized
INFO - 2016-08-23 06:10:51 --> Email Class Initialized
INFO - 2016-08-23 06:10:51 --> Controller Class Initialized
INFO - 2016-08-23 06:10:51 --> Model Class Initialized
INFO - 2016-08-23 06:10:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 06:10:51 --> Final output sent to browser
DEBUG - 2016-08-23 06:10:51 --> Total execution time: 1.2873
INFO - 2016-08-23 06:10:55 --> Config Class Initialized
INFO - 2016-08-23 06:10:55 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:10:55 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:10:55 --> Utf8 Class Initialized
INFO - 2016-08-23 06:10:55 --> URI Class Initialized
DEBUG - 2016-08-23 06:10:55 --> No URI present. Default controller set.
INFO - 2016-08-23 06:10:55 --> Router Class Initialized
INFO - 2016-08-23 06:10:55 --> Output Class Initialized
INFO - 2016-08-23 06:10:55 --> Security Class Initialized
DEBUG - 2016-08-23 06:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:10:55 --> Input Class Initialized
INFO - 2016-08-23 06:10:55 --> Language Class Initialized
INFO - 2016-08-23 06:10:55 --> Loader Class Initialized
INFO - 2016-08-23 06:10:55 --> Helper loaded: url_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: html_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: form_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: file_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:10:55 --> Database Driver Class Initialized
INFO - 2016-08-23 06:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:10:55 --> Form Validation Class Initialized
INFO - 2016-08-23 06:10:55 --> Email Class Initialized
INFO - 2016-08-23 06:10:55 --> Controller Class Initialized
INFO - 2016-08-23 06:10:55 --> Config Class Initialized
INFO - 2016-08-23 06:10:55 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:10:55 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:10:55 --> Utf8 Class Initialized
INFO - 2016-08-23 06:10:55 --> URI Class Initialized
INFO - 2016-08-23 06:10:55 --> Router Class Initialized
INFO - 2016-08-23 06:10:55 --> Output Class Initialized
INFO - 2016-08-23 06:10:55 --> Security Class Initialized
DEBUG - 2016-08-23 06:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:10:55 --> Input Class Initialized
INFO - 2016-08-23 06:10:55 --> Language Class Initialized
INFO - 2016-08-23 06:10:55 --> Loader Class Initialized
INFO - 2016-08-23 06:10:55 --> Helper loaded: url_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: html_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: form_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: file_helper
INFO - 2016-08-23 06:10:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:10:55 --> Database Driver Class Initialized
INFO - 2016-08-23 06:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:10:55 --> Form Validation Class Initialized
INFO - 2016-08-23 06:10:55 --> Email Class Initialized
INFO - 2016-08-23 06:10:55 --> Controller Class Initialized
INFO - 2016-08-23 06:10:55 --> Model Class Initialized
DEBUG - 2016-08-23 06:10:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 06:10:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 06:10:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:10:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 06:10:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:10:55 --> Final output sent to browser
DEBUG - 2016-08-23 06:10:55 --> Total execution time: 0.3352
INFO - 2016-08-23 06:10:59 --> Config Class Initialized
INFO - 2016-08-23 06:10:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:10:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:10:59 --> Utf8 Class Initialized
INFO - 2016-08-23 06:10:59 --> URI Class Initialized
INFO - 2016-08-23 06:10:59 --> Router Class Initialized
INFO - 2016-08-23 06:10:59 --> Output Class Initialized
INFO - 2016-08-23 06:10:59 --> Security Class Initialized
DEBUG - 2016-08-23 06:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:10:59 --> Input Class Initialized
INFO - 2016-08-23 06:10:59 --> Language Class Initialized
INFO - 2016-08-23 06:10:59 --> Loader Class Initialized
INFO - 2016-08-23 06:10:59 --> Helper loaded: url_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: html_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: form_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: file_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:10:59 --> Database Driver Class Initialized
INFO - 2016-08-23 06:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:10:59 --> Form Validation Class Initialized
INFO - 2016-08-23 06:10:59 --> Email Class Initialized
INFO - 2016-08-23 06:10:59 --> Controller Class Initialized
INFO - 2016-08-23 06:10:59 --> Model Class Initialized
DEBUG - 2016-08-23 06:10:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 06:10:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 06:10:59 --> Config Class Initialized
INFO - 2016-08-23 06:10:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:10:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:10:59 --> Utf8 Class Initialized
INFO - 2016-08-23 06:10:59 --> URI Class Initialized
DEBUG - 2016-08-23 06:10:59 --> No URI present. Default controller set.
INFO - 2016-08-23 06:10:59 --> Router Class Initialized
INFO - 2016-08-23 06:10:59 --> Output Class Initialized
INFO - 2016-08-23 06:10:59 --> Security Class Initialized
DEBUG - 2016-08-23 06:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:10:59 --> Input Class Initialized
INFO - 2016-08-23 06:10:59 --> Language Class Initialized
INFO - 2016-08-23 06:10:59 --> Loader Class Initialized
INFO - 2016-08-23 06:10:59 --> Helper loaded: url_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: html_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: form_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: file_helper
INFO - 2016-08-23 06:10:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:10:59 --> Database Driver Class Initialized
INFO - 2016-08-23 06:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:10:59 --> Form Validation Class Initialized
INFO - 2016-08-23 06:10:59 --> Email Class Initialized
INFO - 2016-08-23 06:10:59 --> Controller Class Initialized
INFO - 2016-08-23 06:10:59 --> Model Class Initialized
INFO - 2016-08-23 06:10:59 --> Model Class Initialized
INFO - 2016-08-23 06:10:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:10:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 06:10:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-23 06:10:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:10:59 --> Final output sent to browser
DEBUG - 2016-08-23 06:10:59 --> Total execution time: 0.2922
INFO - 2016-08-23 06:12:49 --> Config Class Initialized
INFO - 2016-08-23 06:12:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:12:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:12:50 --> Utf8 Class Initialized
INFO - 2016-08-23 06:12:50 --> URI Class Initialized
INFO - 2016-08-23 06:12:50 --> Router Class Initialized
INFO - 2016-08-23 06:12:50 --> Output Class Initialized
INFO - 2016-08-23 06:12:50 --> Security Class Initialized
DEBUG - 2016-08-23 06:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:12:50 --> Input Class Initialized
INFO - 2016-08-23 06:12:50 --> Language Class Initialized
INFO - 2016-08-23 06:12:50 --> Loader Class Initialized
INFO - 2016-08-23 06:12:50 --> Helper loaded: url_helper
INFO - 2016-08-23 06:12:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:12:50 --> Helper loaded: html_helper
INFO - 2016-08-23 06:12:50 --> Helper loaded: form_helper
INFO - 2016-08-23 06:12:50 --> Helper loaded: file_helper
INFO - 2016-08-23 06:12:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:12:50 --> Database Driver Class Initialized
INFO - 2016-08-23 06:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:12:50 --> Form Validation Class Initialized
INFO - 2016-08-23 06:12:50 --> Email Class Initialized
INFO - 2016-08-23 06:12:50 --> Controller Class Initialized
INFO - 2016-08-23 06:12:50 --> Model Class Initialized
INFO - 2016-08-23 06:12:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:12:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 06:12:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 06:12:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:12:50 --> Final output sent to browser
DEBUG - 2016-08-23 06:12:50 --> Total execution time: 0.2895
INFO - 2016-08-23 06:12:55 --> Config Class Initialized
INFO - 2016-08-23 06:12:55 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:12:55 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:12:55 --> Utf8 Class Initialized
INFO - 2016-08-23 06:12:55 --> URI Class Initialized
INFO - 2016-08-23 06:12:55 --> Router Class Initialized
INFO - 2016-08-23 06:12:55 --> Output Class Initialized
INFO - 2016-08-23 06:12:55 --> Security Class Initialized
DEBUG - 2016-08-23 06:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:12:55 --> Input Class Initialized
INFO - 2016-08-23 06:12:55 --> Language Class Initialized
INFO - 2016-08-23 06:12:55 --> Loader Class Initialized
INFO - 2016-08-23 06:12:55 --> Helper loaded: url_helper
INFO - 2016-08-23 06:12:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:12:55 --> Helper loaded: html_helper
INFO - 2016-08-23 06:12:55 --> Helper loaded: form_helper
INFO - 2016-08-23 06:12:55 --> Helper loaded: file_helper
INFO - 2016-08-23 06:12:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:12:55 --> Database Driver Class Initialized
INFO - 2016-08-23 06:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:12:55 --> Form Validation Class Initialized
INFO - 2016-08-23 06:12:55 --> Email Class Initialized
INFO - 2016-08-23 06:12:55 --> Controller Class Initialized
INFO - 2016-08-23 06:12:55 --> Model Class Initialized
DEBUG - 2016-08-23 06:12:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 06:12:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:12:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 06:12:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-23 06:12:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:12:55 --> Final output sent to browser
DEBUG - 2016-08-23 06:12:55 --> Total execution time: 0.2798
INFO - 2016-08-23 06:12:59 --> Config Class Initialized
INFO - 2016-08-23 06:12:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:12:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:12:59 --> Utf8 Class Initialized
INFO - 2016-08-23 06:12:59 --> URI Class Initialized
INFO - 2016-08-23 06:12:59 --> Router Class Initialized
INFO - 2016-08-23 06:12:59 --> Output Class Initialized
INFO - 2016-08-23 06:12:59 --> Security Class Initialized
DEBUG - 2016-08-23 06:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:12:59 --> Input Class Initialized
INFO - 2016-08-23 06:12:59 --> Language Class Initialized
INFO - 2016-08-23 06:12:59 --> Loader Class Initialized
INFO - 2016-08-23 06:12:59 --> Helper loaded: url_helper
INFO - 2016-08-23 06:12:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:12:59 --> Helper loaded: html_helper
INFO - 2016-08-23 06:12:59 --> Helper loaded: form_helper
INFO - 2016-08-23 06:12:59 --> Helper loaded: file_helper
INFO - 2016-08-23 06:12:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:12:59 --> Database Driver Class Initialized
INFO - 2016-08-23 06:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:12:59 --> Form Validation Class Initialized
INFO - 2016-08-23 06:12:59 --> Email Class Initialized
INFO - 2016-08-23 06:12:59 --> Controller Class Initialized
INFO - 2016-08-23 06:12:59 --> Model Class Initialized
INFO - 2016-08-23 06:12:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:12:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 06:12:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 06:12:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:12:59 --> Final output sent to browser
DEBUG - 2016-08-23 06:12:59 --> Total execution time: 0.2668
INFO - 2016-08-23 06:17:11 --> Config Class Initialized
INFO - 2016-08-23 06:17:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:17:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:17:11 --> Utf8 Class Initialized
INFO - 2016-08-23 06:17:11 --> URI Class Initialized
INFO - 2016-08-23 06:17:11 --> Router Class Initialized
INFO - 2016-08-23 06:17:11 --> Output Class Initialized
INFO - 2016-08-23 06:17:11 --> Security Class Initialized
DEBUG - 2016-08-23 06:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:17:11 --> Input Class Initialized
INFO - 2016-08-23 06:17:11 --> Language Class Initialized
INFO - 2016-08-23 06:17:11 --> Loader Class Initialized
INFO - 2016-08-23 06:17:11 --> Helper loaded: url_helper
INFO - 2016-08-23 06:17:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:17:11 --> Helper loaded: html_helper
INFO - 2016-08-23 06:17:11 --> Helper loaded: form_helper
INFO - 2016-08-23 06:17:11 --> Helper loaded: file_helper
INFO - 2016-08-23 06:17:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:17:11 --> Database Driver Class Initialized
INFO - 2016-08-23 06:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:17:11 --> Form Validation Class Initialized
INFO - 2016-08-23 06:17:11 --> Email Class Initialized
INFO - 2016-08-23 06:17:11 --> Controller Class Initialized
INFO - 2016-08-23 06:17:11 --> Model Class Initialized
INFO - 2016-08-23 06:17:11 --> Model Class Initialized
INFO - 2016-08-23 06:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 06:17:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 06:17:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 06:17:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 06:17:12 --> Final output sent to browser
DEBUG - 2016-08-23 06:17:12 --> Total execution time: 0.3134
INFO - 2016-08-23 06:19:19 --> Config Class Initialized
INFO - 2016-08-23 06:19:19 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:19:19 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:19:19 --> Utf8 Class Initialized
INFO - 2016-08-23 06:19:19 --> URI Class Initialized
INFO - 2016-08-23 06:19:19 --> Router Class Initialized
INFO - 2016-08-23 06:19:19 --> Output Class Initialized
INFO - 2016-08-23 06:19:19 --> Security Class Initialized
DEBUG - 2016-08-23 06:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:19:19 --> Input Class Initialized
INFO - 2016-08-23 06:19:19 --> Language Class Initialized
INFO - 2016-08-23 06:19:19 --> Loader Class Initialized
INFO - 2016-08-23 06:19:19 --> Helper loaded: url_helper
INFO - 2016-08-23 06:19:19 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:19:19 --> Helper loaded: html_helper
INFO - 2016-08-23 06:19:19 --> Helper loaded: form_helper
INFO - 2016-08-23 06:19:19 --> Helper loaded: file_helper
INFO - 2016-08-23 06:19:19 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:19:19 --> Database Driver Class Initialized
INFO - 2016-08-23 06:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:19:19 --> Form Validation Class Initialized
INFO - 2016-08-23 06:19:19 --> Email Class Initialized
INFO - 2016-08-23 06:19:19 --> Controller Class Initialized
INFO - 2016-08-23 06:19:19 --> Model Class Initialized
INFO - 2016-08-23 06:19:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 06:19:19 --> Final output sent to browser
DEBUG - 2016-08-23 06:19:19 --> Total execution time: 0.2569
INFO - 2016-08-23 06:23:31 --> Config Class Initialized
INFO - 2016-08-23 06:23:31 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:23:31 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:23:31 --> Utf8 Class Initialized
INFO - 2016-08-23 06:23:31 --> URI Class Initialized
INFO - 2016-08-23 06:23:31 --> Router Class Initialized
INFO - 2016-08-23 06:23:31 --> Output Class Initialized
INFO - 2016-08-23 06:23:31 --> Security Class Initialized
DEBUG - 2016-08-23 06:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:23:31 --> Input Class Initialized
INFO - 2016-08-23 06:23:31 --> Language Class Initialized
INFO - 2016-08-23 06:23:31 --> Loader Class Initialized
INFO - 2016-08-23 06:23:31 --> Helper loaded: url_helper
INFO - 2016-08-23 06:23:31 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:23:31 --> Helper loaded: html_helper
INFO - 2016-08-23 06:23:31 --> Helper loaded: form_helper
INFO - 2016-08-23 06:23:31 --> Helper loaded: file_helper
INFO - 2016-08-23 06:23:31 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:23:31 --> Database Driver Class Initialized
INFO - 2016-08-23 06:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:23:31 --> Form Validation Class Initialized
INFO - 2016-08-23 06:23:31 --> Email Class Initialized
INFO - 2016-08-23 06:23:31 --> Controller Class Initialized
INFO - 2016-08-23 06:23:31 --> Model Class Initialized
INFO - 2016-08-23 06:23:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 06:23:31 --> Final output sent to browser
DEBUG - 2016-08-23 06:23:31 --> Total execution time: 0.2829
INFO - 2016-08-23 06:44:57 --> Config Class Initialized
INFO - 2016-08-23 06:44:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 06:44:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 06:44:57 --> Utf8 Class Initialized
INFO - 2016-08-23 06:44:57 --> URI Class Initialized
INFO - 2016-08-23 06:44:57 --> Router Class Initialized
INFO - 2016-08-23 06:44:57 --> Output Class Initialized
INFO - 2016-08-23 06:44:57 --> Security Class Initialized
DEBUG - 2016-08-23 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 06:44:57 --> Input Class Initialized
INFO - 2016-08-23 06:44:57 --> Language Class Initialized
INFO - 2016-08-23 06:44:57 --> Loader Class Initialized
INFO - 2016-08-23 06:44:57 --> Helper loaded: url_helper
INFO - 2016-08-23 06:44:57 --> Helper loaded: utils_helper
INFO - 2016-08-23 06:44:57 --> Helper loaded: html_helper
INFO - 2016-08-23 06:44:57 --> Helper loaded: form_helper
INFO - 2016-08-23 06:44:57 --> Helper loaded: file_helper
INFO - 2016-08-23 06:44:57 --> Helper loaded: myemail_helper
INFO - 2016-08-23 06:44:57 --> Database Driver Class Initialized
INFO - 2016-08-23 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 06:44:57 --> Form Validation Class Initialized
INFO - 2016-08-23 06:44:57 --> Email Class Initialized
INFO - 2016-08-23 06:44:57 --> Controller Class Initialized
INFO - 2016-08-23 06:44:57 --> Model Class Initialized
INFO - 2016-08-23 06:44:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 06:44:57 --> Final output sent to browser
DEBUG - 2016-08-23 06:44:57 --> Total execution time: 0.2915
INFO - 2016-08-23 07:45:10 --> Config Class Initialized
INFO - 2016-08-23 07:45:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:45:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:45:10 --> Utf8 Class Initialized
INFO - 2016-08-23 07:45:10 --> URI Class Initialized
INFO - 2016-08-23 07:45:10 --> Router Class Initialized
INFO - 2016-08-23 07:45:10 --> Output Class Initialized
INFO - 2016-08-23 07:45:10 --> Security Class Initialized
DEBUG - 2016-08-23 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:45:10 --> Input Class Initialized
INFO - 2016-08-23 07:45:10 --> Language Class Initialized
INFO - 2016-08-23 07:45:10 --> Loader Class Initialized
INFO - 2016-08-23 07:45:10 --> Helper loaded: url_helper
INFO - 2016-08-23 07:45:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:45:10 --> Helper loaded: html_helper
INFO - 2016-08-23 07:45:10 --> Helper loaded: form_helper
INFO - 2016-08-23 07:45:10 --> Helper loaded: file_helper
INFO - 2016-08-23 07:45:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:45:10 --> Database Driver Class Initialized
INFO - 2016-08-23 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:45:10 --> Form Validation Class Initialized
INFO - 2016-08-23 07:45:10 --> Email Class Initialized
INFO - 2016-08-23 07:45:10 --> Controller Class Initialized
INFO - 2016-08-23 07:45:10 --> Model Class Initialized
INFO - 2016-08-23 07:45:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:45:10 --> Final output sent to browser
DEBUG - 2016-08-23 07:45:10 --> Total execution time: 0.3203
INFO - 2016-08-23 07:46:43 --> Config Class Initialized
INFO - 2016-08-23 07:46:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:46:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:46:43 --> Utf8 Class Initialized
INFO - 2016-08-23 07:46:43 --> URI Class Initialized
INFO - 2016-08-23 07:46:43 --> Router Class Initialized
INFO - 2016-08-23 07:46:43 --> Output Class Initialized
INFO - 2016-08-23 07:46:43 --> Security Class Initialized
DEBUG - 2016-08-23 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:46:43 --> Input Class Initialized
INFO - 2016-08-23 07:46:43 --> Language Class Initialized
INFO - 2016-08-23 07:46:43 --> Loader Class Initialized
INFO - 2016-08-23 07:46:43 --> Helper loaded: url_helper
INFO - 2016-08-23 07:46:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:46:43 --> Helper loaded: html_helper
INFO - 2016-08-23 07:46:43 --> Helper loaded: form_helper
INFO - 2016-08-23 07:46:43 --> Helper loaded: file_helper
INFO - 2016-08-23 07:46:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:46:43 --> Database Driver Class Initialized
INFO - 2016-08-23 07:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:46:43 --> Form Validation Class Initialized
INFO - 2016-08-23 07:46:43 --> Email Class Initialized
INFO - 2016-08-23 07:46:43 --> Controller Class Initialized
INFO - 2016-08-23 07:46:43 --> Model Class Initialized
INFO - 2016-08-23 07:46:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:46:43 --> Final output sent to browser
DEBUG - 2016-08-23 07:46:43 --> Total execution time: 0.2813
INFO - 2016-08-23 07:47:04 --> Config Class Initialized
INFO - 2016-08-23 07:47:04 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:47:04 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:47:04 --> Utf8 Class Initialized
INFO - 2016-08-23 07:47:04 --> URI Class Initialized
INFO - 2016-08-23 07:47:04 --> Router Class Initialized
INFO - 2016-08-23 07:47:04 --> Output Class Initialized
INFO - 2016-08-23 07:47:04 --> Security Class Initialized
DEBUG - 2016-08-23 07:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:47:04 --> Input Class Initialized
INFO - 2016-08-23 07:47:04 --> Language Class Initialized
INFO - 2016-08-23 07:47:04 --> Loader Class Initialized
INFO - 2016-08-23 07:47:04 --> Helper loaded: url_helper
INFO - 2016-08-23 07:47:04 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:47:04 --> Helper loaded: html_helper
INFO - 2016-08-23 07:47:04 --> Helper loaded: form_helper
INFO - 2016-08-23 07:47:04 --> Helper loaded: file_helper
INFO - 2016-08-23 07:47:04 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:47:05 --> Database Driver Class Initialized
INFO - 2016-08-23 07:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:47:05 --> Form Validation Class Initialized
INFO - 2016-08-23 07:47:05 --> Email Class Initialized
INFO - 2016-08-23 07:47:05 --> Controller Class Initialized
INFO - 2016-08-23 07:47:05 --> Model Class Initialized
INFO - 2016-08-23 07:47:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:47:05 --> Final output sent to browser
DEBUG - 2016-08-23 07:47:05 --> Total execution time: 0.2954
INFO - 2016-08-23 07:47:06 --> Config Class Initialized
INFO - 2016-08-23 07:47:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:47:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:47:06 --> Utf8 Class Initialized
INFO - 2016-08-23 07:47:06 --> URI Class Initialized
INFO - 2016-08-23 07:47:06 --> Router Class Initialized
INFO - 2016-08-23 07:47:06 --> Output Class Initialized
INFO - 2016-08-23 07:47:07 --> Security Class Initialized
DEBUG - 2016-08-23 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:47:07 --> Input Class Initialized
INFO - 2016-08-23 07:47:07 --> Language Class Initialized
INFO - 2016-08-23 07:47:07 --> Loader Class Initialized
INFO - 2016-08-23 07:47:07 --> Helper loaded: url_helper
INFO - 2016-08-23 07:47:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:47:07 --> Helper loaded: html_helper
INFO - 2016-08-23 07:47:07 --> Helper loaded: form_helper
INFO - 2016-08-23 07:47:07 --> Helper loaded: file_helper
INFO - 2016-08-23 07:47:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:47:07 --> Database Driver Class Initialized
INFO - 2016-08-23 07:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:47:07 --> Form Validation Class Initialized
INFO - 2016-08-23 07:47:07 --> Email Class Initialized
INFO - 2016-08-23 07:47:07 --> Controller Class Initialized
INFO - 2016-08-23 07:47:07 --> Model Class Initialized
INFO - 2016-08-23 07:47:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:47:07 --> Final output sent to browser
DEBUG - 2016-08-23 07:47:07 --> Total execution time: 0.2545
INFO - 2016-08-23 07:48:56 --> Config Class Initialized
INFO - 2016-08-23 07:48:56 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:48:56 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:48:56 --> Utf8 Class Initialized
INFO - 2016-08-23 07:48:56 --> URI Class Initialized
INFO - 2016-08-23 07:48:56 --> Router Class Initialized
INFO - 2016-08-23 07:48:56 --> Output Class Initialized
INFO - 2016-08-23 07:48:56 --> Security Class Initialized
DEBUG - 2016-08-23 07:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:48:56 --> Input Class Initialized
INFO - 2016-08-23 07:48:56 --> Language Class Initialized
INFO - 2016-08-23 07:48:56 --> Loader Class Initialized
INFO - 2016-08-23 07:48:56 --> Helper loaded: url_helper
INFO - 2016-08-23 07:48:56 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:48:56 --> Helper loaded: html_helper
INFO - 2016-08-23 07:48:56 --> Helper loaded: form_helper
INFO - 2016-08-23 07:48:56 --> Helper loaded: file_helper
INFO - 2016-08-23 07:48:56 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:48:56 --> Database Driver Class Initialized
INFO - 2016-08-23 07:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:48:56 --> Form Validation Class Initialized
INFO - 2016-08-23 07:48:56 --> Email Class Initialized
INFO - 2016-08-23 07:48:56 --> Controller Class Initialized
INFO - 2016-08-23 07:48:56 --> Model Class Initialized
INFO - 2016-08-23 07:48:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:48:56 --> Final output sent to browser
DEBUG - 2016-08-23 07:48:56 --> Total execution time: 0.2793
INFO - 2016-08-23 07:48:59 --> Config Class Initialized
INFO - 2016-08-23 07:48:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:48:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:48:59 --> Utf8 Class Initialized
INFO - 2016-08-23 07:48:59 --> URI Class Initialized
INFO - 2016-08-23 07:48:59 --> Router Class Initialized
INFO - 2016-08-23 07:48:59 --> Output Class Initialized
INFO - 2016-08-23 07:48:59 --> Security Class Initialized
DEBUG - 2016-08-23 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:48:59 --> Input Class Initialized
INFO - 2016-08-23 07:48:59 --> Language Class Initialized
INFO - 2016-08-23 07:48:59 --> Loader Class Initialized
INFO - 2016-08-23 07:48:59 --> Helper loaded: url_helper
INFO - 2016-08-23 07:48:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:48:59 --> Helper loaded: html_helper
INFO - 2016-08-23 07:48:59 --> Helper loaded: form_helper
INFO - 2016-08-23 07:48:59 --> Helper loaded: file_helper
INFO - 2016-08-23 07:48:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:48:59 --> Database Driver Class Initialized
INFO - 2016-08-23 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:48:59 --> Form Validation Class Initialized
INFO - 2016-08-23 07:48:59 --> Email Class Initialized
INFO - 2016-08-23 07:48:59 --> Controller Class Initialized
INFO - 2016-08-23 07:48:59 --> Model Class Initialized
INFO - 2016-08-23 07:48:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:48:59 --> Final output sent to browser
DEBUG - 2016-08-23 07:48:59 --> Total execution time: 0.2683
INFO - 2016-08-23 07:49:47 --> Config Class Initialized
INFO - 2016-08-23 07:49:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:49:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:49:47 --> Utf8 Class Initialized
INFO - 2016-08-23 07:49:47 --> URI Class Initialized
INFO - 2016-08-23 07:49:47 --> Router Class Initialized
INFO - 2016-08-23 07:49:47 --> Output Class Initialized
INFO - 2016-08-23 07:49:47 --> Security Class Initialized
DEBUG - 2016-08-23 07:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:49:47 --> Input Class Initialized
INFO - 2016-08-23 07:49:47 --> Language Class Initialized
INFO - 2016-08-23 07:49:47 --> Loader Class Initialized
INFO - 2016-08-23 07:49:47 --> Helper loaded: url_helper
INFO - 2016-08-23 07:49:47 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:49:47 --> Helper loaded: html_helper
INFO - 2016-08-23 07:49:47 --> Helper loaded: form_helper
INFO - 2016-08-23 07:49:47 --> Helper loaded: file_helper
INFO - 2016-08-23 07:49:47 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:49:48 --> Database Driver Class Initialized
INFO - 2016-08-23 07:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:49:48 --> Form Validation Class Initialized
INFO - 2016-08-23 07:49:48 --> Email Class Initialized
INFO - 2016-08-23 07:49:48 --> Controller Class Initialized
INFO - 2016-08-23 07:49:48 --> Model Class Initialized
INFO - 2016-08-23 07:49:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:49:48 --> Final output sent to browser
DEBUG - 2016-08-23 07:49:48 --> Total execution time: 0.2741
INFO - 2016-08-23 07:49:49 --> Config Class Initialized
INFO - 2016-08-23 07:49:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:49:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:49:49 --> Utf8 Class Initialized
INFO - 2016-08-23 07:49:49 --> URI Class Initialized
INFO - 2016-08-23 07:49:49 --> Router Class Initialized
INFO - 2016-08-23 07:49:49 --> Output Class Initialized
INFO - 2016-08-23 07:49:49 --> Security Class Initialized
DEBUG - 2016-08-23 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:49:49 --> Input Class Initialized
INFO - 2016-08-23 07:49:49 --> Language Class Initialized
INFO - 2016-08-23 07:49:49 --> Loader Class Initialized
INFO - 2016-08-23 07:49:49 --> Helper loaded: url_helper
INFO - 2016-08-23 07:49:49 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:49:50 --> Helper loaded: html_helper
INFO - 2016-08-23 07:49:50 --> Helper loaded: form_helper
INFO - 2016-08-23 07:49:50 --> Helper loaded: file_helper
INFO - 2016-08-23 07:49:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:49:50 --> Database Driver Class Initialized
INFO - 2016-08-23 07:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:49:50 --> Form Validation Class Initialized
INFO - 2016-08-23 07:49:50 --> Email Class Initialized
INFO - 2016-08-23 07:49:50 --> Controller Class Initialized
INFO - 2016-08-23 07:49:50 --> Model Class Initialized
INFO - 2016-08-23 07:49:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:49:50 --> Final output sent to browser
DEBUG - 2016-08-23 07:49:50 --> Total execution time: 0.2624
INFO - 2016-08-23 07:50:30 --> Config Class Initialized
INFO - 2016-08-23 07:50:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:50:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:50:30 --> Utf8 Class Initialized
INFO - 2016-08-23 07:50:30 --> URI Class Initialized
INFO - 2016-08-23 07:50:30 --> Router Class Initialized
INFO - 2016-08-23 07:50:30 --> Output Class Initialized
INFO - 2016-08-23 07:50:30 --> Security Class Initialized
DEBUG - 2016-08-23 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:50:30 --> Input Class Initialized
INFO - 2016-08-23 07:50:30 --> Language Class Initialized
INFO - 2016-08-23 07:50:30 --> Loader Class Initialized
INFO - 2016-08-23 07:50:30 --> Helper loaded: url_helper
INFO - 2016-08-23 07:50:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:50:30 --> Helper loaded: html_helper
INFO - 2016-08-23 07:50:30 --> Helper loaded: form_helper
INFO - 2016-08-23 07:50:30 --> Helper loaded: file_helper
INFO - 2016-08-23 07:50:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:50:30 --> Database Driver Class Initialized
INFO - 2016-08-23 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:50:30 --> Form Validation Class Initialized
INFO - 2016-08-23 07:50:30 --> Email Class Initialized
INFO - 2016-08-23 07:50:30 --> Controller Class Initialized
INFO - 2016-08-23 07:50:30 --> Model Class Initialized
INFO - 2016-08-23 07:50:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:50:30 --> Final output sent to browser
DEBUG - 2016-08-23 07:50:30 --> Total execution time: 0.2850
INFO - 2016-08-23 07:50:32 --> Config Class Initialized
INFO - 2016-08-23 07:50:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:50:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:50:32 --> Utf8 Class Initialized
INFO - 2016-08-23 07:50:32 --> URI Class Initialized
INFO - 2016-08-23 07:50:32 --> Router Class Initialized
INFO - 2016-08-23 07:50:32 --> Output Class Initialized
INFO - 2016-08-23 07:50:32 --> Security Class Initialized
DEBUG - 2016-08-23 07:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:50:32 --> Input Class Initialized
INFO - 2016-08-23 07:50:32 --> Language Class Initialized
INFO - 2016-08-23 07:50:32 --> Loader Class Initialized
INFO - 2016-08-23 07:50:32 --> Helper loaded: url_helper
INFO - 2016-08-23 07:50:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:50:32 --> Helper loaded: html_helper
INFO - 2016-08-23 07:50:32 --> Helper loaded: form_helper
INFO - 2016-08-23 07:50:32 --> Helper loaded: file_helper
INFO - 2016-08-23 07:50:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:50:32 --> Database Driver Class Initialized
INFO - 2016-08-23 07:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:50:32 --> Form Validation Class Initialized
INFO - 2016-08-23 07:50:32 --> Email Class Initialized
INFO - 2016-08-23 07:50:32 --> Controller Class Initialized
INFO - 2016-08-23 07:50:32 --> Model Class Initialized
INFO - 2016-08-23 07:50:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:50:32 --> Final output sent to browser
DEBUG - 2016-08-23 07:50:32 --> Total execution time: 0.2645
INFO - 2016-08-23 07:50:44 --> Config Class Initialized
INFO - 2016-08-23 07:50:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 07:50:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 07:50:44 --> Utf8 Class Initialized
INFO - 2016-08-23 07:50:44 --> URI Class Initialized
INFO - 2016-08-23 07:50:44 --> Router Class Initialized
INFO - 2016-08-23 07:50:44 --> Output Class Initialized
INFO - 2016-08-23 07:50:44 --> Security Class Initialized
DEBUG - 2016-08-23 07:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 07:50:44 --> Input Class Initialized
INFO - 2016-08-23 07:50:44 --> Language Class Initialized
INFO - 2016-08-23 07:50:44 --> Loader Class Initialized
INFO - 2016-08-23 07:50:44 --> Helper loaded: url_helper
INFO - 2016-08-23 07:50:45 --> Helper loaded: utils_helper
INFO - 2016-08-23 07:50:45 --> Helper loaded: html_helper
INFO - 2016-08-23 07:50:45 --> Helper loaded: form_helper
INFO - 2016-08-23 07:50:45 --> Helper loaded: file_helper
INFO - 2016-08-23 07:50:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 07:50:45 --> Database Driver Class Initialized
INFO - 2016-08-23 07:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 07:50:45 --> Form Validation Class Initialized
INFO - 2016-08-23 07:50:45 --> Email Class Initialized
INFO - 2016-08-23 07:50:45 --> Controller Class Initialized
INFO - 2016-08-23 07:50:45 --> Model Class Initialized
INFO - 2016-08-23 07:50:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 07:50:45 --> Final output sent to browser
DEBUG - 2016-08-23 07:50:45 --> Total execution time: 0.2805
INFO - 2016-08-23 08:05:12 --> Config Class Initialized
INFO - 2016-08-23 08:05:12 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:05:12 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:05:13 --> Utf8 Class Initialized
INFO - 2016-08-23 08:05:13 --> URI Class Initialized
INFO - 2016-08-23 08:05:13 --> Router Class Initialized
INFO - 2016-08-23 08:05:13 --> Output Class Initialized
INFO - 2016-08-23 08:05:13 --> Security Class Initialized
DEBUG - 2016-08-23 08:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:05:13 --> Input Class Initialized
INFO - 2016-08-23 08:05:13 --> Language Class Initialized
INFO - 2016-08-23 08:05:13 --> Loader Class Initialized
INFO - 2016-08-23 08:05:13 --> Helper loaded: url_helper
INFO - 2016-08-23 08:05:13 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:05:13 --> Helper loaded: html_helper
INFO - 2016-08-23 08:05:13 --> Helper loaded: form_helper
INFO - 2016-08-23 08:05:13 --> Helper loaded: file_helper
INFO - 2016-08-23 08:05:13 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:05:13 --> Database Driver Class Initialized
INFO - 2016-08-23 08:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:05:13 --> Form Validation Class Initialized
INFO - 2016-08-23 08:05:13 --> Email Class Initialized
INFO - 2016-08-23 08:05:13 --> Controller Class Initialized
INFO - 2016-08-23 08:05:13 --> Model Class Initialized
INFO - 2016-08-23 08:05:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:05:13 --> Final output sent to browser
DEBUG - 2016-08-23 08:05:13 --> Total execution time: 0.3222
INFO - 2016-08-23 08:05:15 --> Config Class Initialized
INFO - 2016-08-23 08:05:15 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:05:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:05:15 --> Utf8 Class Initialized
INFO - 2016-08-23 08:05:15 --> URI Class Initialized
INFO - 2016-08-23 08:05:15 --> Router Class Initialized
INFO - 2016-08-23 08:05:15 --> Output Class Initialized
INFO - 2016-08-23 08:05:15 --> Security Class Initialized
DEBUG - 2016-08-23 08:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:05:15 --> Input Class Initialized
INFO - 2016-08-23 08:05:15 --> Language Class Initialized
INFO - 2016-08-23 08:05:15 --> Loader Class Initialized
INFO - 2016-08-23 08:05:15 --> Helper loaded: url_helper
INFO - 2016-08-23 08:05:15 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:05:15 --> Helper loaded: html_helper
INFO - 2016-08-23 08:05:15 --> Helper loaded: form_helper
INFO - 2016-08-23 08:05:15 --> Helper loaded: file_helper
INFO - 2016-08-23 08:05:15 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:05:15 --> Database Driver Class Initialized
INFO - 2016-08-23 08:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:05:15 --> Form Validation Class Initialized
INFO - 2016-08-23 08:05:15 --> Email Class Initialized
INFO - 2016-08-23 08:05:15 --> Controller Class Initialized
INFO - 2016-08-23 08:05:15 --> Model Class Initialized
INFO - 2016-08-23 08:05:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:05:15 --> Final output sent to browser
DEBUG - 2016-08-23 08:05:15 --> Total execution time: 0.2613
INFO - 2016-08-23 08:14:22 --> Config Class Initialized
INFO - 2016-08-23 08:14:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:22 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:22 --> URI Class Initialized
DEBUG - 2016-08-23 08:14:22 --> No URI present. Default controller set.
INFO - 2016-08-23 08:14:22 --> Router Class Initialized
INFO - 2016-08-23 08:14:23 --> Output Class Initialized
INFO - 2016-08-23 08:14:23 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:23 --> Input Class Initialized
INFO - 2016-08-23 08:14:23 --> Language Class Initialized
INFO - 2016-08-23 08:14:23 --> Loader Class Initialized
INFO - 2016-08-23 08:14:23 --> Helper loaded: url_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: html_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: form_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: file_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:14:23 --> Database Driver Class Initialized
INFO - 2016-08-23 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:14:23 --> Form Validation Class Initialized
INFO - 2016-08-23 08:14:23 --> Email Class Initialized
INFO - 2016-08-23 08:14:23 --> Controller Class Initialized
INFO - 2016-08-23 08:14:23 --> Config Class Initialized
INFO - 2016-08-23 08:14:23 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:23 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:23 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:23 --> URI Class Initialized
INFO - 2016-08-23 08:14:23 --> Router Class Initialized
INFO - 2016-08-23 08:14:23 --> Output Class Initialized
INFO - 2016-08-23 08:14:23 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:23 --> Input Class Initialized
INFO - 2016-08-23 08:14:23 --> Language Class Initialized
INFO - 2016-08-23 08:14:23 --> Loader Class Initialized
INFO - 2016-08-23 08:14:23 --> Helper loaded: url_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: html_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: form_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: file_helper
INFO - 2016-08-23 08:14:23 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:14:23 --> Database Driver Class Initialized
INFO - 2016-08-23 08:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:14:23 --> Form Validation Class Initialized
INFO - 2016-08-23 08:14:23 --> Email Class Initialized
INFO - 2016-08-23 08:14:23 --> Controller Class Initialized
INFO - 2016-08-23 08:14:23 --> Model Class Initialized
DEBUG - 2016-08-23 08:14:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 08:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 08:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 08:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 08:14:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 08:14:23 --> Final output sent to browser
DEBUG - 2016-08-23 08:14:23 --> Total execution time: 0.3119
INFO - 2016-08-23 08:14:24 --> Config Class Initialized
INFO - 2016-08-23 08:14:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:24 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:24 --> URI Class Initialized
INFO - 2016-08-23 08:14:24 --> Router Class Initialized
INFO - 2016-08-23 08:14:24 --> Output Class Initialized
INFO - 2016-08-23 08:14:24 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:24 --> Input Class Initialized
INFO - 2016-08-23 08:14:24 --> Language Class Initialized
ERROR - 2016-08-23 08:14:24 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 08:14:24 --> Config Class Initialized
INFO - 2016-08-23 08:14:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:24 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:24 --> URI Class Initialized
INFO - 2016-08-23 08:14:24 --> Router Class Initialized
INFO - 2016-08-23 08:14:24 --> Output Class Initialized
INFO - 2016-08-23 08:14:24 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:24 --> Input Class Initialized
INFO - 2016-08-23 08:14:24 --> Language Class Initialized
ERROR - 2016-08-23 08:14:24 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 08:14:26 --> Config Class Initialized
INFO - 2016-08-23 08:14:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:26 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:26 --> URI Class Initialized
INFO - 2016-08-23 08:14:26 --> Router Class Initialized
INFO - 2016-08-23 08:14:26 --> Output Class Initialized
INFO - 2016-08-23 08:14:26 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:26 --> Input Class Initialized
INFO - 2016-08-23 08:14:26 --> Language Class Initialized
ERROR - 2016-08-23 08:14:26 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 08:14:40 --> Config Class Initialized
INFO - 2016-08-23 08:14:40 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:14:40 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:14:40 --> Utf8 Class Initialized
INFO - 2016-08-23 08:14:40 --> URI Class Initialized
INFO - 2016-08-23 08:14:40 --> Router Class Initialized
INFO - 2016-08-23 08:14:40 --> Output Class Initialized
INFO - 2016-08-23 08:14:40 --> Security Class Initialized
DEBUG - 2016-08-23 08:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:14:40 --> Input Class Initialized
INFO - 2016-08-23 08:14:40 --> Language Class Initialized
INFO - 2016-08-23 08:14:40 --> Loader Class Initialized
INFO - 2016-08-23 08:14:40 --> Helper loaded: url_helper
INFO - 2016-08-23 08:14:40 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:14:40 --> Helper loaded: html_helper
INFO - 2016-08-23 08:14:40 --> Helper loaded: form_helper
INFO - 2016-08-23 08:14:40 --> Helper loaded: file_helper
INFO - 2016-08-23 08:14:40 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:14:40 --> Database Driver Class Initialized
INFO - 2016-08-23 08:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:14:40 --> Form Validation Class Initialized
INFO - 2016-08-23 08:14:40 --> Email Class Initialized
INFO - 2016-08-23 08:14:40 --> Controller Class Initialized
INFO - 2016-08-23 08:14:40 --> Model Class Initialized
INFO - 2016-08-23 08:14:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:14:40 --> Final output sent to browser
DEBUG - 2016-08-23 08:14:40 --> Total execution time: 0.2802
INFO - 2016-08-23 08:15:48 --> Config Class Initialized
INFO - 2016-08-23 08:15:48 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:15:48 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:15:48 --> Utf8 Class Initialized
INFO - 2016-08-23 08:15:48 --> URI Class Initialized
INFO - 2016-08-23 08:15:48 --> Router Class Initialized
INFO - 2016-08-23 08:15:48 --> Output Class Initialized
INFO - 2016-08-23 08:15:48 --> Security Class Initialized
DEBUG - 2016-08-23 08:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:15:48 --> Input Class Initialized
INFO - 2016-08-23 08:15:48 --> Language Class Initialized
INFO - 2016-08-23 08:15:48 --> Loader Class Initialized
INFO - 2016-08-23 08:15:48 --> Helper loaded: url_helper
INFO - 2016-08-23 08:15:48 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:15:48 --> Helper loaded: html_helper
INFO - 2016-08-23 08:15:48 --> Helper loaded: form_helper
INFO - 2016-08-23 08:15:48 --> Helper loaded: file_helper
INFO - 2016-08-23 08:15:48 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:15:48 --> Database Driver Class Initialized
INFO - 2016-08-23 08:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:15:48 --> Form Validation Class Initialized
INFO - 2016-08-23 08:15:48 --> Email Class Initialized
INFO - 2016-08-23 08:15:49 --> Controller Class Initialized
INFO - 2016-08-23 08:15:49 --> Model Class Initialized
INFO - 2016-08-23 08:15:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:15:49 --> Final output sent to browser
DEBUG - 2016-08-23 08:15:49 --> Total execution time: 0.2972
INFO - 2016-08-23 08:15:50 --> Config Class Initialized
INFO - 2016-08-23 08:15:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:15:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:15:50 --> Utf8 Class Initialized
INFO - 2016-08-23 08:15:50 --> URI Class Initialized
INFO - 2016-08-23 08:15:50 --> Router Class Initialized
INFO - 2016-08-23 08:15:50 --> Output Class Initialized
INFO - 2016-08-23 08:15:50 --> Security Class Initialized
DEBUG - 2016-08-23 08:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:15:50 --> Input Class Initialized
INFO - 2016-08-23 08:15:50 --> Language Class Initialized
INFO - 2016-08-23 08:15:50 --> Loader Class Initialized
INFO - 2016-08-23 08:15:50 --> Helper loaded: url_helper
INFO - 2016-08-23 08:15:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:15:50 --> Helper loaded: html_helper
INFO - 2016-08-23 08:15:50 --> Helper loaded: form_helper
INFO - 2016-08-23 08:15:50 --> Helper loaded: file_helper
INFO - 2016-08-23 08:15:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:15:50 --> Database Driver Class Initialized
INFO - 2016-08-23 08:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:15:50 --> Form Validation Class Initialized
INFO - 2016-08-23 08:15:50 --> Email Class Initialized
INFO - 2016-08-23 08:15:50 --> Controller Class Initialized
INFO - 2016-08-23 08:15:50 --> Model Class Initialized
INFO - 2016-08-23 08:15:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:15:50 --> Final output sent to browser
DEBUG - 2016-08-23 08:15:50 --> Total execution time: 0.2744
INFO - 2016-08-23 08:19:34 --> Config Class Initialized
INFO - 2016-08-23 08:19:34 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:19:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:19:34 --> Utf8 Class Initialized
INFO - 2016-08-23 08:19:34 --> URI Class Initialized
INFO - 2016-08-23 08:19:34 --> Router Class Initialized
INFO - 2016-08-23 08:19:35 --> Output Class Initialized
INFO - 2016-08-23 08:19:35 --> Security Class Initialized
DEBUG - 2016-08-23 08:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:19:35 --> Input Class Initialized
INFO - 2016-08-23 08:19:35 --> Language Class Initialized
INFO - 2016-08-23 08:19:35 --> Loader Class Initialized
INFO - 2016-08-23 08:19:35 --> Helper loaded: url_helper
INFO - 2016-08-23 08:19:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:19:35 --> Helper loaded: html_helper
INFO - 2016-08-23 08:19:35 --> Helper loaded: form_helper
INFO - 2016-08-23 08:19:35 --> Helper loaded: file_helper
INFO - 2016-08-23 08:19:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:19:35 --> Database Driver Class Initialized
INFO - 2016-08-23 08:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:19:35 --> Form Validation Class Initialized
INFO - 2016-08-23 08:19:35 --> Email Class Initialized
INFO - 2016-08-23 08:19:35 --> Controller Class Initialized
INFO - 2016-08-23 08:19:35 --> Model Class Initialized
INFO - 2016-08-23 08:19:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:19:35 --> Final output sent to browser
DEBUG - 2016-08-23 08:19:35 --> Total execution time: 0.2942
INFO - 2016-08-23 08:19:36 --> Config Class Initialized
INFO - 2016-08-23 08:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:19:36 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:19:36 --> Utf8 Class Initialized
INFO - 2016-08-23 08:19:36 --> URI Class Initialized
INFO - 2016-08-23 08:19:36 --> Router Class Initialized
INFO - 2016-08-23 08:19:36 --> Output Class Initialized
INFO - 2016-08-23 08:19:36 --> Security Class Initialized
DEBUG - 2016-08-23 08:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:19:36 --> Input Class Initialized
INFO - 2016-08-23 08:19:36 --> Language Class Initialized
INFO - 2016-08-23 08:19:36 --> Loader Class Initialized
INFO - 2016-08-23 08:19:36 --> Helper loaded: url_helper
INFO - 2016-08-23 08:19:36 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:19:36 --> Helper loaded: html_helper
INFO - 2016-08-23 08:19:36 --> Helper loaded: form_helper
INFO - 2016-08-23 08:19:36 --> Helper loaded: file_helper
INFO - 2016-08-23 08:19:36 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:19:36 --> Database Driver Class Initialized
INFO - 2016-08-23 08:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:19:36 --> Form Validation Class Initialized
INFO - 2016-08-23 08:19:36 --> Email Class Initialized
INFO - 2016-08-23 08:19:36 --> Controller Class Initialized
INFO - 2016-08-23 08:19:36 --> Model Class Initialized
INFO - 2016-08-23 08:19:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:19:36 --> Final output sent to browser
DEBUG - 2016-08-23 08:19:36 --> Total execution time: 0.2661
INFO - 2016-08-23 08:19:53 --> Config Class Initialized
INFO - 2016-08-23 08:19:53 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:19:53 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:19:53 --> Utf8 Class Initialized
INFO - 2016-08-23 08:19:53 --> URI Class Initialized
INFO - 2016-08-23 08:19:53 --> Router Class Initialized
INFO - 2016-08-23 08:19:53 --> Output Class Initialized
INFO - 2016-08-23 08:19:53 --> Security Class Initialized
DEBUG - 2016-08-23 08:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:19:53 --> Input Class Initialized
INFO - 2016-08-23 08:19:53 --> Language Class Initialized
INFO - 2016-08-23 08:19:53 --> Loader Class Initialized
INFO - 2016-08-23 08:19:53 --> Helper loaded: url_helper
INFO - 2016-08-23 08:19:53 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:19:53 --> Helper loaded: html_helper
INFO - 2016-08-23 08:19:53 --> Helper loaded: form_helper
INFO - 2016-08-23 08:19:53 --> Helper loaded: file_helper
INFO - 2016-08-23 08:19:53 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:19:53 --> Database Driver Class Initialized
INFO - 2016-08-23 08:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:19:53 --> Form Validation Class Initialized
INFO - 2016-08-23 08:19:53 --> Email Class Initialized
INFO - 2016-08-23 08:19:53 --> Controller Class Initialized
INFO - 2016-08-23 08:19:53 --> Model Class Initialized
INFO - 2016-08-23 08:19:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:19:53 --> Final output sent to browser
DEBUG - 2016-08-23 08:19:53 --> Total execution time: 0.2872
INFO - 2016-08-23 08:19:54 --> Config Class Initialized
INFO - 2016-08-23 08:19:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:19:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:19:54 --> Utf8 Class Initialized
INFO - 2016-08-23 08:19:54 --> URI Class Initialized
INFO - 2016-08-23 08:19:54 --> Router Class Initialized
INFO - 2016-08-23 08:19:54 --> Output Class Initialized
INFO - 2016-08-23 08:19:54 --> Security Class Initialized
DEBUG - 2016-08-23 08:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:19:54 --> Input Class Initialized
INFO - 2016-08-23 08:19:54 --> Language Class Initialized
INFO - 2016-08-23 08:19:54 --> Loader Class Initialized
INFO - 2016-08-23 08:19:55 --> Helper loaded: url_helper
INFO - 2016-08-23 08:19:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:19:55 --> Helper loaded: html_helper
INFO - 2016-08-23 08:19:55 --> Helper loaded: form_helper
INFO - 2016-08-23 08:19:55 --> Helper loaded: file_helper
INFO - 2016-08-23 08:19:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:19:55 --> Database Driver Class Initialized
INFO - 2016-08-23 08:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:19:55 --> Form Validation Class Initialized
INFO - 2016-08-23 08:19:55 --> Email Class Initialized
INFO - 2016-08-23 08:19:55 --> Controller Class Initialized
INFO - 2016-08-23 08:19:55 --> Model Class Initialized
INFO - 2016-08-23 08:19:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:19:55 --> Final output sent to browser
DEBUG - 2016-08-23 08:19:55 --> Total execution time: 0.2671
INFO - 2016-08-23 08:20:06 --> Config Class Initialized
INFO - 2016-08-23 08:20:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:20:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:20:06 --> Utf8 Class Initialized
INFO - 2016-08-23 08:20:06 --> URI Class Initialized
INFO - 2016-08-23 08:20:06 --> Router Class Initialized
INFO - 2016-08-23 08:20:06 --> Output Class Initialized
INFO - 2016-08-23 08:20:06 --> Security Class Initialized
DEBUG - 2016-08-23 08:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:20:07 --> Input Class Initialized
INFO - 2016-08-23 08:20:07 --> Language Class Initialized
INFO - 2016-08-23 08:20:07 --> Loader Class Initialized
INFO - 2016-08-23 08:20:07 --> Helper loaded: url_helper
INFO - 2016-08-23 08:20:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:20:07 --> Helper loaded: html_helper
INFO - 2016-08-23 08:20:07 --> Helper loaded: form_helper
INFO - 2016-08-23 08:20:07 --> Helper loaded: file_helper
INFO - 2016-08-23 08:20:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:20:07 --> Database Driver Class Initialized
INFO - 2016-08-23 08:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:20:07 --> Form Validation Class Initialized
INFO - 2016-08-23 08:20:07 --> Email Class Initialized
INFO - 2016-08-23 08:20:07 --> Controller Class Initialized
INFO - 2016-08-23 08:20:07 --> Model Class Initialized
INFO - 2016-08-23 08:20:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:20:07 --> Final output sent to browser
DEBUG - 2016-08-23 08:20:07 --> Total execution time: 0.3035
INFO - 2016-08-23 08:20:15 --> Config Class Initialized
INFO - 2016-08-23 08:20:15 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:20:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:20:15 --> Utf8 Class Initialized
INFO - 2016-08-23 08:20:15 --> URI Class Initialized
INFO - 2016-08-23 08:20:15 --> Router Class Initialized
INFO - 2016-08-23 08:20:15 --> Output Class Initialized
INFO - 2016-08-23 08:20:15 --> Security Class Initialized
DEBUG - 2016-08-23 08:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:20:15 --> Input Class Initialized
INFO - 2016-08-23 08:20:15 --> Language Class Initialized
INFO - 2016-08-23 08:20:15 --> Loader Class Initialized
INFO - 2016-08-23 08:20:15 --> Helper loaded: url_helper
INFO - 2016-08-23 08:20:15 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:20:15 --> Helper loaded: html_helper
INFO - 2016-08-23 08:20:15 --> Helper loaded: form_helper
INFO - 2016-08-23 08:20:15 --> Helper loaded: file_helper
INFO - 2016-08-23 08:20:15 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:20:15 --> Database Driver Class Initialized
INFO - 2016-08-23 08:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:20:15 --> Form Validation Class Initialized
INFO - 2016-08-23 08:20:15 --> Email Class Initialized
INFO - 2016-08-23 08:20:15 --> Controller Class Initialized
INFO - 2016-08-23 08:20:15 --> Model Class Initialized
INFO - 2016-08-23 08:20:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:20:15 --> Final output sent to browser
DEBUG - 2016-08-23 08:20:15 --> Total execution time: 0.3051
INFO - 2016-08-23 08:21:56 --> Config Class Initialized
INFO - 2016-08-23 08:21:56 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:21:56 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:21:56 --> Utf8 Class Initialized
INFO - 2016-08-23 08:21:56 --> URI Class Initialized
INFO - 2016-08-23 08:21:56 --> Router Class Initialized
INFO - 2016-08-23 08:21:56 --> Output Class Initialized
INFO - 2016-08-23 08:21:56 --> Security Class Initialized
DEBUG - 2016-08-23 08:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:21:56 --> Input Class Initialized
INFO - 2016-08-23 08:21:56 --> Language Class Initialized
INFO - 2016-08-23 08:21:56 --> Loader Class Initialized
INFO - 2016-08-23 08:21:56 --> Helper loaded: url_helper
INFO - 2016-08-23 08:21:56 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:21:56 --> Helper loaded: html_helper
INFO - 2016-08-23 08:21:56 --> Helper loaded: form_helper
INFO - 2016-08-23 08:21:56 --> Helper loaded: file_helper
INFO - 2016-08-23 08:21:56 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:21:56 --> Database Driver Class Initialized
INFO - 2016-08-23 08:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:21:56 --> Form Validation Class Initialized
INFO - 2016-08-23 08:21:56 --> Email Class Initialized
INFO - 2016-08-23 08:21:57 --> Controller Class Initialized
INFO - 2016-08-23 08:21:57 --> Model Class Initialized
INFO - 2016-08-23 08:21:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:21:57 --> Final output sent to browser
DEBUG - 2016-08-23 08:21:57 --> Total execution time: 0.2841
INFO - 2016-08-23 08:22:01 --> Config Class Initialized
INFO - 2016-08-23 08:22:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:22:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:22:01 --> Utf8 Class Initialized
INFO - 2016-08-23 08:22:01 --> URI Class Initialized
INFO - 2016-08-23 08:22:01 --> Router Class Initialized
INFO - 2016-08-23 08:22:01 --> Output Class Initialized
INFO - 2016-08-23 08:22:01 --> Security Class Initialized
DEBUG - 2016-08-23 08:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:22:01 --> Input Class Initialized
INFO - 2016-08-23 08:22:01 --> Language Class Initialized
INFO - 2016-08-23 08:22:01 --> Loader Class Initialized
INFO - 2016-08-23 08:22:01 --> Helper loaded: url_helper
INFO - 2016-08-23 08:22:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:22:01 --> Helper loaded: html_helper
INFO - 2016-08-23 08:22:01 --> Helper loaded: form_helper
INFO - 2016-08-23 08:22:01 --> Helper loaded: file_helper
INFO - 2016-08-23 08:22:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:22:01 --> Database Driver Class Initialized
INFO - 2016-08-23 08:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:22:01 --> Form Validation Class Initialized
INFO - 2016-08-23 08:22:01 --> Email Class Initialized
INFO - 2016-08-23 08:22:01 --> Controller Class Initialized
INFO - 2016-08-23 08:22:01 --> Model Class Initialized
INFO - 2016-08-23 08:22:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:22:01 --> Final output sent to browser
DEBUG - 2016-08-23 08:22:01 --> Total execution time: 0.2723
INFO - 2016-08-23 08:30:10 --> Config Class Initialized
INFO - 2016-08-23 08:30:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:30:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:30:10 --> Utf8 Class Initialized
INFO - 2016-08-23 08:30:10 --> URI Class Initialized
INFO - 2016-08-23 08:30:10 --> Router Class Initialized
INFO - 2016-08-23 08:30:10 --> Output Class Initialized
INFO - 2016-08-23 08:30:10 --> Security Class Initialized
DEBUG - 2016-08-23 08:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:30:10 --> Input Class Initialized
INFO - 2016-08-23 08:30:10 --> Language Class Initialized
INFO - 2016-08-23 08:30:10 --> Loader Class Initialized
INFO - 2016-08-23 08:30:10 --> Helper loaded: url_helper
INFO - 2016-08-23 08:30:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:30:10 --> Helper loaded: html_helper
INFO - 2016-08-23 08:30:10 --> Helper loaded: form_helper
INFO - 2016-08-23 08:30:10 --> Helper loaded: file_helper
INFO - 2016-08-23 08:30:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:30:10 --> Database Driver Class Initialized
INFO - 2016-08-23 08:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:30:10 --> Form Validation Class Initialized
INFO - 2016-08-23 08:30:10 --> Email Class Initialized
INFO - 2016-08-23 08:30:10 --> Controller Class Initialized
INFO - 2016-08-23 08:30:10 --> Model Class Initialized
INFO - 2016-08-23 08:30:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:30:10 --> Final output sent to browser
DEBUG - 2016-08-23 08:30:10 --> Total execution time: 0.3491
INFO - 2016-08-23 08:31:09 --> Config Class Initialized
INFO - 2016-08-23 08:31:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:31:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:31:09 --> Utf8 Class Initialized
INFO - 2016-08-23 08:31:09 --> URI Class Initialized
INFO - 2016-08-23 08:31:09 --> Router Class Initialized
INFO - 2016-08-23 08:31:09 --> Output Class Initialized
INFO - 2016-08-23 08:31:09 --> Security Class Initialized
DEBUG - 2016-08-23 08:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:31:09 --> Input Class Initialized
INFO - 2016-08-23 08:31:09 --> Language Class Initialized
INFO - 2016-08-23 08:31:09 --> Loader Class Initialized
INFO - 2016-08-23 08:31:09 --> Helper loaded: url_helper
INFO - 2016-08-23 08:31:09 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:31:09 --> Helper loaded: html_helper
INFO - 2016-08-23 08:31:09 --> Helper loaded: form_helper
INFO - 2016-08-23 08:31:09 --> Helper loaded: file_helper
INFO - 2016-08-23 08:31:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:31:10 --> Database Driver Class Initialized
INFO - 2016-08-23 08:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:31:10 --> Form Validation Class Initialized
INFO - 2016-08-23 08:31:10 --> Email Class Initialized
INFO - 2016-08-23 08:31:10 --> Controller Class Initialized
INFO - 2016-08-23 08:31:10 --> Model Class Initialized
INFO - 2016-08-23 08:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:31:10 --> Final output sent to browser
DEBUG - 2016-08-23 08:31:10 --> Total execution time: 0.2913
INFO - 2016-08-23 08:31:30 --> Config Class Initialized
INFO - 2016-08-23 08:31:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:31:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:31:30 --> Utf8 Class Initialized
INFO - 2016-08-23 08:31:30 --> URI Class Initialized
INFO - 2016-08-23 08:31:30 --> Router Class Initialized
INFO - 2016-08-23 08:31:30 --> Output Class Initialized
INFO - 2016-08-23 08:31:30 --> Security Class Initialized
DEBUG - 2016-08-23 08:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:31:30 --> Input Class Initialized
INFO - 2016-08-23 08:31:30 --> Language Class Initialized
INFO - 2016-08-23 08:31:30 --> Loader Class Initialized
INFO - 2016-08-23 08:31:30 --> Helper loaded: url_helper
INFO - 2016-08-23 08:31:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:31:30 --> Helper loaded: html_helper
INFO - 2016-08-23 08:31:30 --> Helper loaded: form_helper
INFO - 2016-08-23 08:31:30 --> Helper loaded: file_helper
INFO - 2016-08-23 08:31:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:31:30 --> Database Driver Class Initialized
INFO - 2016-08-23 08:31:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:31:30 --> Form Validation Class Initialized
INFO - 2016-08-23 08:31:30 --> Email Class Initialized
INFO - 2016-08-23 08:31:30 --> Controller Class Initialized
INFO - 2016-08-23 08:31:30 --> Model Class Initialized
INFO - 2016-08-23 08:31:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:31:30 --> Final output sent to browser
DEBUG - 2016-08-23 08:31:30 --> Total execution time: 0.3099
INFO - 2016-08-23 08:31:31 --> Config Class Initialized
INFO - 2016-08-23 08:31:31 --> Hooks Class Initialized
DEBUG - 2016-08-23 08:31:31 --> UTF-8 Support Enabled
INFO - 2016-08-23 08:31:31 --> Utf8 Class Initialized
INFO - 2016-08-23 08:31:31 --> URI Class Initialized
INFO - 2016-08-23 08:31:31 --> Router Class Initialized
INFO - 2016-08-23 08:31:31 --> Output Class Initialized
INFO - 2016-08-23 08:31:31 --> Security Class Initialized
DEBUG - 2016-08-23 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 08:31:31 --> Input Class Initialized
INFO - 2016-08-23 08:31:31 --> Language Class Initialized
INFO - 2016-08-23 08:31:31 --> Loader Class Initialized
INFO - 2016-08-23 08:31:31 --> Helper loaded: url_helper
INFO - 2016-08-23 08:31:31 --> Helper loaded: utils_helper
INFO - 2016-08-23 08:31:31 --> Helper loaded: html_helper
INFO - 2016-08-23 08:31:31 --> Helper loaded: form_helper
INFO - 2016-08-23 08:31:31 --> Helper loaded: file_helper
INFO - 2016-08-23 08:31:31 --> Helper loaded: myemail_helper
INFO - 2016-08-23 08:31:31 --> Database Driver Class Initialized
INFO - 2016-08-23 08:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 08:31:32 --> Form Validation Class Initialized
INFO - 2016-08-23 08:31:32 --> Email Class Initialized
INFO - 2016-08-23 08:31:32 --> Controller Class Initialized
INFO - 2016-08-23 08:31:32 --> Model Class Initialized
INFO - 2016-08-23 08:31:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 08:31:32 --> Final output sent to browser
DEBUG - 2016-08-23 08:31:32 --> Total execution time: 0.2822
INFO - 2016-08-23 09:07:12 --> Config Class Initialized
INFO - 2016-08-23 09:07:12 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:07:12 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:07:12 --> Utf8 Class Initialized
INFO - 2016-08-23 09:07:12 --> URI Class Initialized
INFO - 2016-08-23 09:07:12 --> Router Class Initialized
INFO - 2016-08-23 09:07:12 --> Output Class Initialized
INFO - 2016-08-23 09:07:12 --> Security Class Initialized
DEBUG - 2016-08-23 09:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:07:12 --> Input Class Initialized
INFO - 2016-08-23 09:07:12 --> Language Class Initialized
INFO - 2016-08-23 09:07:12 --> Loader Class Initialized
INFO - 2016-08-23 09:07:12 --> Helper loaded: url_helper
INFO - 2016-08-23 09:07:12 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:07:12 --> Helper loaded: html_helper
INFO - 2016-08-23 09:07:12 --> Helper loaded: form_helper
INFO - 2016-08-23 09:07:12 --> Helper loaded: file_helper
INFO - 2016-08-23 09:07:12 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:07:12 --> Database Driver Class Initialized
INFO - 2016-08-23 09:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:07:12 --> Form Validation Class Initialized
INFO - 2016-08-23 09:07:12 --> Email Class Initialized
INFO - 2016-08-23 09:07:12 --> Controller Class Initialized
INFO - 2016-08-23 09:07:12 --> Model Class Initialized
INFO - 2016-08-23 09:07:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\user_authentication/index.php
INFO - 2016-08-23 09:07:12 --> Final output sent to browser
DEBUG - 2016-08-23 09:07:12 --> Total execution time: 0.2981
INFO - 2016-08-23 09:07:14 --> Config Class Initialized
INFO - 2016-08-23 09:07:14 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:07:14 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:07:14 --> Utf8 Class Initialized
INFO - 2016-08-23 09:07:14 --> URI Class Initialized
INFO - 2016-08-23 09:07:14 --> Router Class Initialized
INFO - 2016-08-23 09:07:14 --> Output Class Initialized
INFO - 2016-08-23 09:07:14 --> Security Class Initialized
DEBUG - 2016-08-23 09:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:07:14 --> Input Class Initialized
INFO - 2016-08-23 09:07:14 --> Language Class Initialized
INFO - 2016-08-23 09:07:14 --> Loader Class Initialized
INFO - 2016-08-23 09:07:14 --> Helper loaded: url_helper
INFO - 2016-08-23 09:07:14 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:07:14 --> Helper loaded: html_helper
INFO - 2016-08-23 09:07:14 --> Helper loaded: form_helper
INFO - 2016-08-23 09:07:14 --> Helper loaded: file_helper
INFO - 2016-08-23 09:07:14 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:07:14 --> Database Driver Class Initialized
INFO - 2016-08-23 09:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:07:14 --> Form Validation Class Initialized
INFO - 2016-08-23 09:07:14 --> Email Class Initialized
INFO - 2016-08-23 09:07:14 --> Controller Class Initialized
INFO - 2016-08-23 09:07:14 --> Model Class Initialized
DEBUG - 2016-08-23 09:07:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:07:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:07:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:07:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:07:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:07:14 --> Final output sent to browser
DEBUG - 2016-08-23 09:07:14 --> Total execution time: 0.3138
INFO - 2016-08-23 09:07:16 --> Config Class Initialized
INFO - 2016-08-23 09:07:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:07:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:07:16 --> Utf8 Class Initialized
INFO - 2016-08-23 09:07:16 --> URI Class Initialized
INFO - 2016-08-23 09:07:16 --> Router Class Initialized
INFO - 2016-08-23 09:07:16 --> Output Class Initialized
INFO - 2016-08-23 09:07:16 --> Security Class Initialized
DEBUG - 2016-08-23 09:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:07:16 --> Input Class Initialized
INFO - 2016-08-23 09:07:16 --> Language Class Initialized
ERROR - 2016-08-23 09:07:16 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 09:30:42 --> Config Class Initialized
INFO - 2016-08-23 09:30:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:30:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:30:42 --> Utf8 Class Initialized
INFO - 2016-08-23 09:30:42 --> URI Class Initialized
INFO - 2016-08-23 09:30:42 --> Router Class Initialized
INFO - 2016-08-23 09:30:42 --> Output Class Initialized
INFO - 2016-08-23 09:30:42 --> Security Class Initialized
DEBUG - 2016-08-23 09:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:30:42 --> Input Class Initialized
INFO - 2016-08-23 09:30:42 --> Language Class Initialized
INFO - 2016-08-23 09:30:42 --> Loader Class Initialized
INFO - 2016-08-23 09:30:42 --> Helper loaded: url_helper
INFO - 2016-08-23 09:30:42 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:30:42 --> Helper loaded: html_helper
INFO - 2016-08-23 09:30:42 --> Helper loaded: form_helper
INFO - 2016-08-23 09:30:42 --> Helper loaded: file_helper
INFO - 2016-08-23 09:30:42 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:30:42 --> Database Driver Class Initialized
INFO - 2016-08-23 09:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:30:42 --> Form Validation Class Initialized
INFO - 2016-08-23 09:30:42 --> Email Class Initialized
INFO - 2016-08-23 09:30:42 --> Controller Class Initialized
INFO - 2016-08-23 09:30:42 --> Model Class Initialized
DEBUG - 2016-08-23 09:30:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:30:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:30:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:30:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:30:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:30:43 --> Final output sent to browser
DEBUG - 2016-08-23 09:30:43 --> Total execution time: 0.3262
INFO - 2016-08-23 09:30:46 --> Config Class Initialized
INFO - 2016-08-23 09:30:46 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:30:46 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:30:46 --> Utf8 Class Initialized
INFO - 2016-08-23 09:30:46 --> URI Class Initialized
INFO - 2016-08-23 09:30:46 --> Router Class Initialized
INFO - 2016-08-23 09:30:46 --> Output Class Initialized
INFO - 2016-08-23 09:30:46 --> Security Class Initialized
DEBUG - 2016-08-23 09:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:30:46 --> Input Class Initialized
INFO - 2016-08-23 09:30:46 --> Language Class Initialized
INFO - 2016-08-23 09:30:46 --> Loader Class Initialized
INFO - 2016-08-23 09:30:46 --> Helper loaded: url_helper
INFO - 2016-08-23 09:30:46 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:30:46 --> Helper loaded: html_helper
INFO - 2016-08-23 09:30:46 --> Helper loaded: form_helper
INFO - 2016-08-23 09:30:46 --> Helper loaded: file_helper
INFO - 2016-08-23 09:30:46 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:30:46 --> Database Driver Class Initialized
INFO - 2016-08-23 09:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:30:46 --> Form Validation Class Initialized
INFO - 2016-08-23 09:30:46 --> Email Class Initialized
INFO - 2016-08-23 09:30:46 --> Controller Class Initialized
INFO - 2016-08-23 09:30:46 --> Model Class Initialized
DEBUG - 2016-08-23 09:30:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:30:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:30:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:30:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:30:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:30:46 --> Final output sent to browser
DEBUG - 2016-08-23 09:30:46 --> Total execution time: 0.3249
INFO - 2016-08-23 09:31:09 --> Config Class Initialized
INFO - 2016-08-23 09:31:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:31:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:31:09 --> Utf8 Class Initialized
INFO - 2016-08-23 09:31:09 --> URI Class Initialized
INFO - 2016-08-23 09:31:09 --> Router Class Initialized
INFO - 2016-08-23 09:31:09 --> Output Class Initialized
INFO - 2016-08-23 09:31:09 --> Security Class Initialized
DEBUG - 2016-08-23 09:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:31:09 --> Input Class Initialized
INFO - 2016-08-23 09:31:09 --> Language Class Initialized
INFO - 2016-08-23 09:31:09 --> Loader Class Initialized
INFO - 2016-08-23 09:31:09 --> Helper loaded: url_helper
INFO - 2016-08-23 09:31:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:31:10 --> Helper loaded: html_helper
INFO - 2016-08-23 09:31:10 --> Helper loaded: form_helper
INFO - 2016-08-23 09:31:10 --> Helper loaded: file_helper
INFO - 2016-08-23 09:31:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:31:10 --> Database Driver Class Initialized
INFO - 2016-08-23 09:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:31:10 --> Form Validation Class Initialized
INFO - 2016-08-23 09:31:10 --> Email Class Initialized
INFO - 2016-08-23 09:31:10 --> Controller Class Initialized
INFO - 2016-08-23 09:31:10 --> Model Class Initialized
DEBUG - 2016-08-23 09:31:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:31:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:31:10 --> Final output sent to browser
DEBUG - 2016-08-23 09:31:10 --> Total execution time: 0.3206
INFO - 2016-08-23 09:32:26 --> Config Class Initialized
INFO - 2016-08-23 09:32:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:32:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:32:26 --> Utf8 Class Initialized
INFO - 2016-08-23 09:32:26 --> URI Class Initialized
INFO - 2016-08-23 09:32:26 --> Router Class Initialized
INFO - 2016-08-23 09:32:26 --> Output Class Initialized
INFO - 2016-08-23 09:32:26 --> Security Class Initialized
DEBUG - 2016-08-23 09:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:32:26 --> Input Class Initialized
INFO - 2016-08-23 09:32:26 --> Language Class Initialized
INFO - 2016-08-23 09:32:26 --> Loader Class Initialized
INFO - 2016-08-23 09:32:26 --> Helper loaded: url_helper
INFO - 2016-08-23 09:32:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:32:26 --> Helper loaded: html_helper
INFO - 2016-08-23 09:32:26 --> Helper loaded: form_helper
INFO - 2016-08-23 09:32:26 --> Helper loaded: file_helper
INFO - 2016-08-23 09:32:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:32:26 --> Database Driver Class Initialized
INFO - 2016-08-23 09:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:32:26 --> Form Validation Class Initialized
INFO - 2016-08-23 09:32:26 --> Email Class Initialized
INFO - 2016-08-23 09:32:26 --> Controller Class Initialized
INFO - 2016-08-23 09:32:26 --> Model Class Initialized
DEBUG - 2016-08-23 09:32:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:32:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:32:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:32:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:32:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:32:27 --> Final output sent to browser
DEBUG - 2016-08-23 09:32:27 --> Total execution time: 0.3313
INFO - 2016-08-23 09:32:32 --> Config Class Initialized
INFO - 2016-08-23 09:32:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:32:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:32:32 --> Utf8 Class Initialized
INFO - 2016-08-23 09:32:32 --> URI Class Initialized
INFO - 2016-08-23 09:32:32 --> Router Class Initialized
INFO - 2016-08-23 09:32:32 --> Output Class Initialized
INFO - 2016-08-23 09:32:32 --> Security Class Initialized
DEBUG - 2016-08-23 09:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:32:32 --> Input Class Initialized
INFO - 2016-08-23 09:32:32 --> Language Class Initialized
INFO - 2016-08-23 09:32:32 --> Loader Class Initialized
INFO - 2016-08-23 09:32:32 --> Helper loaded: url_helper
INFO - 2016-08-23 09:32:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:32:32 --> Helper loaded: html_helper
INFO - 2016-08-23 09:32:32 --> Helper loaded: form_helper
INFO - 2016-08-23 09:32:32 --> Helper loaded: file_helper
INFO - 2016-08-23 09:32:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:32:32 --> Database Driver Class Initialized
INFO - 2016-08-23 09:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:32:32 --> Form Validation Class Initialized
INFO - 2016-08-23 09:32:32 --> Email Class Initialized
INFO - 2016-08-23 09:32:32 --> Controller Class Initialized
INFO - 2016-08-23 09:32:32 --> Model Class Initialized
DEBUG - 2016-08-23 09:32:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:32:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:32:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:32:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:32:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:32:32 --> Final output sent to browser
DEBUG - 2016-08-23 09:32:32 --> Total execution time: 0.3224
INFO - 2016-08-23 09:33:08 --> Config Class Initialized
INFO - 2016-08-23 09:33:08 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:33:08 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:33:08 --> Utf8 Class Initialized
INFO - 2016-08-23 09:33:08 --> URI Class Initialized
INFO - 2016-08-23 09:33:08 --> Router Class Initialized
INFO - 2016-08-23 09:33:08 --> Output Class Initialized
INFO - 2016-08-23 09:33:08 --> Security Class Initialized
DEBUG - 2016-08-23 09:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:33:08 --> Input Class Initialized
INFO - 2016-08-23 09:33:08 --> Language Class Initialized
ERROR - 2016-08-23 09:33:08 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 09:33:11 --> Config Class Initialized
INFO - 2016-08-23 09:33:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:33:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:33:11 --> Utf8 Class Initialized
INFO - 2016-08-23 09:33:11 --> URI Class Initialized
INFO - 2016-08-23 09:33:11 --> Router Class Initialized
INFO - 2016-08-23 09:33:11 --> Output Class Initialized
INFO - 2016-08-23 09:33:11 --> Security Class Initialized
DEBUG - 2016-08-23 09:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:33:11 --> Input Class Initialized
INFO - 2016-08-23 09:33:11 --> Language Class Initialized
INFO - 2016-08-23 09:33:11 --> Loader Class Initialized
INFO - 2016-08-23 09:33:11 --> Helper loaded: url_helper
INFO - 2016-08-23 09:33:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:33:11 --> Helper loaded: html_helper
INFO - 2016-08-23 09:33:11 --> Helper loaded: form_helper
INFO - 2016-08-23 09:33:11 --> Helper loaded: file_helper
INFO - 2016-08-23 09:33:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:33:11 --> Database Driver Class Initialized
INFO - 2016-08-23 09:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:33:11 --> Form Validation Class Initialized
INFO - 2016-08-23 09:33:11 --> Email Class Initialized
INFO - 2016-08-23 09:33:11 --> Controller Class Initialized
INFO - 2016-08-23 09:33:11 --> Model Class Initialized
DEBUG - 2016-08-23 09:33:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:33:11 --> Final output sent to browser
DEBUG - 2016-08-23 09:33:11 --> Total execution time: 0.3563
INFO - 2016-08-23 09:34:17 --> Config Class Initialized
INFO - 2016-08-23 09:34:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:34:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:34:17 --> Utf8 Class Initialized
INFO - 2016-08-23 09:34:17 --> URI Class Initialized
INFO - 2016-08-23 09:34:17 --> Router Class Initialized
INFO - 2016-08-23 09:34:17 --> Output Class Initialized
INFO - 2016-08-23 09:34:17 --> Security Class Initialized
DEBUG - 2016-08-23 09:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:34:17 --> Input Class Initialized
INFO - 2016-08-23 09:34:17 --> Language Class Initialized
INFO - 2016-08-23 09:34:17 --> Loader Class Initialized
INFO - 2016-08-23 09:34:17 --> Helper loaded: url_helper
INFO - 2016-08-23 09:34:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:34:17 --> Helper loaded: html_helper
INFO - 2016-08-23 09:34:17 --> Helper loaded: form_helper
INFO - 2016-08-23 09:34:17 --> Helper loaded: file_helper
INFO - 2016-08-23 09:34:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:34:17 --> Database Driver Class Initialized
INFO - 2016-08-23 09:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:34:17 --> Form Validation Class Initialized
INFO - 2016-08-23 09:34:17 --> Email Class Initialized
INFO - 2016-08-23 09:34:17 --> Controller Class Initialized
INFO - 2016-08-23 09:34:17 --> Model Class Initialized
DEBUG - 2016-08-23 09:34:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:34:17 --> Final output sent to browser
DEBUG - 2016-08-23 09:34:17 --> Total execution time: 0.3269
INFO - 2016-08-23 09:34:24 --> Config Class Initialized
INFO - 2016-08-23 09:34:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:34:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:34:24 --> Utf8 Class Initialized
INFO - 2016-08-23 09:34:24 --> URI Class Initialized
INFO - 2016-08-23 09:34:24 --> Router Class Initialized
INFO - 2016-08-23 09:34:24 --> Output Class Initialized
INFO - 2016-08-23 09:34:24 --> Security Class Initialized
DEBUG - 2016-08-23 09:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:34:24 --> Input Class Initialized
INFO - 2016-08-23 09:34:24 --> Language Class Initialized
ERROR - 2016-08-23 09:34:24 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 09:34:25 --> Config Class Initialized
INFO - 2016-08-23 09:34:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 09:34:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 09:34:25 --> Utf8 Class Initialized
INFO - 2016-08-23 09:34:25 --> URI Class Initialized
INFO - 2016-08-23 09:34:25 --> Router Class Initialized
INFO - 2016-08-23 09:34:25 --> Output Class Initialized
INFO - 2016-08-23 09:34:25 --> Security Class Initialized
DEBUG - 2016-08-23 09:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 09:34:26 --> Input Class Initialized
INFO - 2016-08-23 09:34:26 --> Language Class Initialized
INFO - 2016-08-23 09:34:26 --> Loader Class Initialized
INFO - 2016-08-23 09:34:26 --> Helper loaded: url_helper
INFO - 2016-08-23 09:34:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 09:34:26 --> Helper loaded: html_helper
INFO - 2016-08-23 09:34:26 --> Helper loaded: form_helper
INFO - 2016-08-23 09:34:26 --> Helper loaded: file_helper
INFO - 2016-08-23 09:34:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 09:34:26 --> Database Driver Class Initialized
INFO - 2016-08-23 09:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 09:34:26 --> Form Validation Class Initialized
INFO - 2016-08-23 09:34:26 --> Email Class Initialized
INFO - 2016-08-23 09:34:26 --> Controller Class Initialized
INFO - 2016-08-23 09:34:26 --> Model Class Initialized
DEBUG - 2016-08-23 09:34:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 09:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 09:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 09:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 09:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 09:34:26 --> Final output sent to browser
DEBUG - 2016-08-23 09:34:26 --> Total execution time: 0.3450
INFO - 2016-08-23 10:07:06 --> Config Class Initialized
INFO - 2016-08-23 10:07:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:07:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:07:06 --> Utf8 Class Initialized
INFO - 2016-08-23 10:07:06 --> URI Class Initialized
INFO - 2016-08-23 10:07:06 --> Router Class Initialized
INFO - 2016-08-23 10:07:06 --> Output Class Initialized
INFO - 2016-08-23 10:07:06 --> Security Class Initialized
DEBUG - 2016-08-23 10:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:07:06 --> Input Class Initialized
INFO - 2016-08-23 10:07:06 --> Language Class Initialized
INFO - 2016-08-23 10:07:06 --> Loader Class Initialized
INFO - 2016-08-23 10:07:06 --> Helper loaded: url_helper
INFO - 2016-08-23 10:07:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:07:06 --> Helper loaded: html_helper
INFO - 2016-08-23 10:07:06 --> Helper loaded: form_helper
INFO - 2016-08-23 10:07:06 --> Helper loaded: file_helper
INFO - 2016-08-23 10:07:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:07:06 --> Database Driver Class Initialized
INFO - 2016-08-23 10:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:07:06 --> Form Validation Class Initialized
INFO - 2016-08-23 10:07:06 --> Email Class Initialized
INFO - 2016-08-23 10:07:06 --> Controller Class Initialized
INFO - 2016-08-23 10:07:06 --> Model Class Initialized
DEBUG - 2016-08-23 10:07:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:07:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:07:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:07:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:07:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:07:06 --> Final output sent to browser
DEBUG - 2016-08-23 10:07:06 --> Total execution time: 0.3247
INFO - 2016-08-23 10:08:30 --> Config Class Initialized
INFO - 2016-08-23 10:08:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:08:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:08:30 --> Utf8 Class Initialized
INFO - 2016-08-23 10:08:30 --> URI Class Initialized
INFO - 2016-08-23 10:08:30 --> Router Class Initialized
INFO - 2016-08-23 10:08:30 --> Output Class Initialized
INFO - 2016-08-23 10:08:30 --> Security Class Initialized
DEBUG - 2016-08-23 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:08:30 --> Input Class Initialized
INFO - 2016-08-23 10:08:30 --> Language Class Initialized
INFO - 2016-08-23 10:08:30 --> Loader Class Initialized
INFO - 2016-08-23 10:08:30 --> Helper loaded: url_helper
INFO - 2016-08-23 10:08:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:08:30 --> Helper loaded: html_helper
INFO - 2016-08-23 10:08:30 --> Helper loaded: form_helper
INFO - 2016-08-23 10:08:30 --> Helper loaded: file_helper
INFO - 2016-08-23 10:08:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:08:30 --> Database Driver Class Initialized
INFO - 2016-08-23 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:08:30 --> Form Validation Class Initialized
INFO - 2016-08-23 10:08:30 --> Email Class Initialized
INFO - 2016-08-23 10:08:30 --> Controller Class Initialized
INFO - 2016-08-23 10:08:30 --> Model Class Initialized
DEBUG - 2016-08-23 10:08:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:08:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:08:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:08:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:08:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:08:30 --> Final output sent to browser
DEBUG - 2016-08-23 10:08:30 --> Total execution time: 0.3245
INFO - 2016-08-23 10:08:40 --> Config Class Initialized
INFO - 2016-08-23 10:08:40 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:08:40 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:08:40 --> Utf8 Class Initialized
INFO - 2016-08-23 10:08:40 --> URI Class Initialized
INFO - 2016-08-23 10:08:40 --> Router Class Initialized
INFO - 2016-08-23 10:08:40 --> Output Class Initialized
INFO - 2016-08-23 10:08:40 --> Security Class Initialized
DEBUG - 2016-08-23 10:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:08:41 --> Input Class Initialized
INFO - 2016-08-23 10:08:41 --> Language Class Initialized
INFO - 2016-08-23 10:08:41 --> Loader Class Initialized
INFO - 2016-08-23 10:08:41 --> Helper loaded: url_helper
INFO - 2016-08-23 10:08:41 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:08:41 --> Helper loaded: html_helper
INFO - 2016-08-23 10:08:41 --> Helper loaded: form_helper
INFO - 2016-08-23 10:08:41 --> Helper loaded: file_helper
INFO - 2016-08-23 10:08:41 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:08:41 --> Database Driver Class Initialized
INFO - 2016-08-23 10:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:08:41 --> Form Validation Class Initialized
INFO - 2016-08-23 10:08:41 --> Email Class Initialized
INFO - 2016-08-23 10:08:41 --> Controller Class Initialized
INFO - 2016-08-23 10:08:41 --> Model Class Initialized
DEBUG - 2016-08-23 10:08:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:08:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:08:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:08:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:08:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:08:41 --> Final output sent to browser
DEBUG - 2016-08-23 10:08:41 --> Total execution time: 0.3183
INFO - 2016-08-23 10:09:04 --> Config Class Initialized
INFO - 2016-08-23 10:09:04 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:09:04 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:09:04 --> Utf8 Class Initialized
INFO - 2016-08-23 10:09:04 --> URI Class Initialized
INFO - 2016-08-23 10:09:04 --> Router Class Initialized
INFO - 2016-08-23 10:09:04 --> Output Class Initialized
INFO - 2016-08-23 10:09:04 --> Security Class Initialized
DEBUG - 2016-08-23 10:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:09:04 --> Input Class Initialized
INFO - 2016-08-23 10:09:04 --> Language Class Initialized
INFO - 2016-08-23 10:09:04 --> Loader Class Initialized
INFO - 2016-08-23 10:09:04 --> Helper loaded: url_helper
INFO - 2016-08-23 10:09:04 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:09:04 --> Helper loaded: html_helper
INFO - 2016-08-23 10:09:04 --> Helper loaded: form_helper
INFO - 2016-08-23 10:09:04 --> Helper loaded: file_helper
INFO - 2016-08-23 10:09:04 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:09:04 --> Database Driver Class Initialized
INFO - 2016-08-23 10:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:09:04 --> Form Validation Class Initialized
INFO - 2016-08-23 10:09:04 --> Email Class Initialized
INFO - 2016-08-23 10:09:04 --> Controller Class Initialized
INFO - 2016-08-23 10:09:04 --> Model Class Initialized
DEBUG - 2016-08-23 10:09:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:09:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:09:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:09:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:09:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:09:04 --> Final output sent to browser
DEBUG - 2016-08-23 10:09:04 --> Total execution time: 0.3230
INFO - 2016-08-23 10:09:10 --> Config Class Initialized
INFO - 2016-08-23 10:09:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:09:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:09:10 --> Utf8 Class Initialized
INFO - 2016-08-23 10:09:10 --> URI Class Initialized
INFO - 2016-08-23 10:09:10 --> Router Class Initialized
INFO - 2016-08-23 10:09:10 --> Output Class Initialized
INFO - 2016-08-23 10:09:10 --> Security Class Initialized
DEBUG - 2016-08-23 10:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:09:10 --> Input Class Initialized
INFO - 2016-08-23 10:09:10 --> Language Class Initialized
INFO - 2016-08-23 10:09:10 --> Loader Class Initialized
INFO - 2016-08-23 10:09:10 --> Helper loaded: url_helper
INFO - 2016-08-23 10:09:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:09:10 --> Helper loaded: html_helper
INFO - 2016-08-23 10:09:10 --> Helper loaded: form_helper
INFO - 2016-08-23 10:09:10 --> Helper loaded: file_helper
INFO - 2016-08-23 10:09:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:09:10 --> Database Driver Class Initialized
INFO - 2016-08-23 10:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:09:10 --> Form Validation Class Initialized
INFO - 2016-08-23 10:09:10 --> Email Class Initialized
INFO - 2016-08-23 10:09:10 --> Controller Class Initialized
INFO - 2016-08-23 10:09:10 --> Model Class Initialized
DEBUG - 2016-08-23 10:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:09:10 --> Final output sent to browser
DEBUG - 2016-08-23 10:09:10 --> Total execution time: 0.3330
INFO - 2016-08-23 10:09:50 --> Config Class Initialized
INFO - 2016-08-23 10:09:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:09:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:09:50 --> Utf8 Class Initialized
INFO - 2016-08-23 10:09:50 --> URI Class Initialized
INFO - 2016-08-23 10:09:50 --> Router Class Initialized
INFO - 2016-08-23 10:09:50 --> Output Class Initialized
INFO - 2016-08-23 10:09:50 --> Security Class Initialized
DEBUG - 2016-08-23 10:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:09:51 --> Input Class Initialized
INFO - 2016-08-23 10:09:51 --> Language Class Initialized
ERROR - 2016-08-23 10:09:51 --> 404 Page Not Found: Connection/googleLogin
INFO - 2016-08-23 10:10:36 --> Config Class Initialized
INFO - 2016-08-23 10:10:36 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:10:36 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:10:36 --> Utf8 Class Initialized
INFO - 2016-08-23 10:10:36 --> URI Class Initialized
INFO - 2016-08-23 10:10:36 --> Router Class Initialized
INFO - 2016-08-23 10:10:36 --> Output Class Initialized
INFO - 2016-08-23 10:10:36 --> Security Class Initialized
DEBUG - 2016-08-23 10:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:10:36 --> Input Class Initialized
INFO - 2016-08-23 10:10:36 --> Language Class Initialized
INFO - 2016-08-23 10:10:36 --> Loader Class Initialized
INFO - 2016-08-23 10:10:36 --> Helper loaded: url_helper
INFO - 2016-08-23 10:10:36 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:10:36 --> Helper loaded: html_helper
INFO - 2016-08-23 10:10:36 --> Helper loaded: form_helper
INFO - 2016-08-23 10:10:36 --> Helper loaded: file_helper
INFO - 2016-08-23 10:10:36 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:10:36 --> Database Driver Class Initialized
INFO - 2016-08-23 10:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:10:36 --> Form Validation Class Initialized
INFO - 2016-08-23 10:10:36 --> Email Class Initialized
INFO - 2016-08-23 10:10:36 --> Controller Class Initialized
INFO - 2016-08-23 10:10:36 --> Model Class Initialized
DEBUG - 2016-08-23 10:10:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:10:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:10:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:10:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:10:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:10:36 --> Final output sent to browser
DEBUG - 2016-08-23 10:10:36 --> Total execution time: 0.3465
INFO - 2016-08-23 10:10:39 --> Config Class Initialized
INFO - 2016-08-23 10:10:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:10:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:10:39 --> Utf8 Class Initialized
INFO - 2016-08-23 10:10:39 --> URI Class Initialized
INFO - 2016-08-23 10:10:39 --> Router Class Initialized
INFO - 2016-08-23 10:10:39 --> Output Class Initialized
INFO - 2016-08-23 10:10:39 --> Security Class Initialized
DEBUG - 2016-08-23 10:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:10:39 --> Input Class Initialized
INFO - 2016-08-23 10:10:39 --> Language Class Initialized
INFO - 2016-08-23 10:10:39 --> Loader Class Initialized
INFO - 2016-08-23 10:10:39 --> Helper loaded: url_helper
INFO - 2016-08-23 10:10:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:10:39 --> Helper loaded: html_helper
INFO - 2016-08-23 10:10:39 --> Helper loaded: form_helper
INFO - 2016-08-23 10:10:39 --> Helper loaded: file_helper
INFO - 2016-08-23 10:10:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:10:39 --> Database Driver Class Initialized
INFO - 2016-08-23 10:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:10:39 --> Form Validation Class Initialized
INFO - 2016-08-23 10:10:39 --> Email Class Initialized
INFO - 2016-08-23 10:10:39 --> Controller Class Initialized
INFO - 2016-08-23 10:10:39 --> Model Class Initialized
DEBUG - 2016-08-23 10:10:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:10:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:10:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:10:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:10:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:10:39 --> Final output sent to browser
DEBUG - 2016-08-23 10:10:39 --> Total execution time: 0.3196
INFO - 2016-08-23 10:10:40 --> Config Class Initialized
INFO - 2016-08-23 10:10:41 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:10:41 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:10:41 --> Utf8 Class Initialized
INFO - 2016-08-23 10:10:41 --> URI Class Initialized
INFO - 2016-08-23 10:10:41 --> Router Class Initialized
INFO - 2016-08-23 10:10:41 --> Output Class Initialized
INFO - 2016-08-23 10:10:41 --> Security Class Initialized
DEBUG - 2016-08-23 10:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:10:41 --> Input Class Initialized
INFO - 2016-08-23 10:10:41 --> Language Class Initialized
INFO - 2016-08-23 10:10:41 --> Loader Class Initialized
INFO - 2016-08-23 10:10:41 --> Helper loaded: url_helper
INFO - 2016-08-23 10:10:41 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:10:41 --> Helper loaded: html_helper
INFO - 2016-08-23 10:10:41 --> Helper loaded: form_helper
INFO - 2016-08-23 10:10:41 --> Helper loaded: file_helper
INFO - 2016-08-23 10:10:41 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:10:41 --> Database Driver Class Initialized
INFO - 2016-08-23 10:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:10:41 --> Form Validation Class Initialized
INFO - 2016-08-23 10:10:41 --> Email Class Initialized
INFO - 2016-08-23 10:10:41 --> Controller Class Initialized
INFO - 2016-08-23 10:10:41 --> Model Class Initialized
INFO - 2016-08-23 10:19:55 --> Config Class Initialized
INFO - 2016-08-23 10:19:55 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:19:55 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:19:55 --> Utf8 Class Initialized
INFO - 2016-08-23 10:19:55 --> URI Class Initialized
INFO - 2016-08-23 10:19:55 --> Router Class Initialized
INFO - 2016-08-23 10:19:55 --> Output Class Initialized
INFO - 2016-08-23 10:19:55 --> Security Class Initialized
DEBUG - 2016-08-23 10:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:19:55 --> Input Class Initialized
INFO - 2016-08-23 10:19:55 --> Language Class Initialized
INFO - 2016-08-23 10:19:55 --> Loader Class Initialized
INFO - 2016-08-23 10:19:55 --> Helper loaded: url_helper
INFO - 2016-08-23 10:19:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:19:55 --> Helper loaded: html_helper
INFO - 2016-08-23 10:19:55 --> Helper loaded: form_helper
INFO - 2016-08-23 10:19:55 --> Helper loaded: file_helper
INFO - 2016-08-23 10:19:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:19:55 --> Database Driver Class Initialized
INFO - 2016-08-23 10:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:19:55 --> Form Validation Class Initialized
INFO - 2016-08-23 10:19:55 --> Email Class Initialized
INFO - 2016-08-23 10:19:55 --> Controller Class Initialized
INFO - 2016-08-23 10:19:55 --> Model Class Initialized
DEBUG - 2016-08-23 10:19:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:19:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:19:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:19:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:19:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:19:55 --> Final output sent to browser
DEBUG - 2016-08-23 10:19:55 --> Total execution time: 0.3493
INFO - 2016-08-23 10:21:17 --> Config Class Initialized
INFO - 2016-08-23 10:21:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:21:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:21:17 --> Utf8 Class Initialized
INFO - 2016-08-23 10:21:17 --> URI Class Initialized
INFO - 2016-08-23 10:21:17 --> Router Class Initialized
INFO - 2016-08-23 10:21:17 --> Output Class Initialized
INFO - 2016-08-23 10:21:17 --> Security Class Initialized
DEBUG - 2016-08-23 10:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:21:17 --> Input Class Initialized
INFO - 2016-08-23 10:21:17 --> Language Class Initialized
INFO - 2016-08-23 10:21:17 --> Loader Class Initialized
INFO - 2016-08-23 10:21:17 --> Helper loaded: url_helper
INFO - 2016-08-23 10:21:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:21:17 --> Helper loaded: html_helper
INFO - 2016-08-23 10:21:17 --> Helper loaded: form_helper
INFO - 2016-08-23 10:21:17 --> Helper loaded: file_helper
INFO - 2016-08-23 10:21:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:21:17 --> Database Driver Class Initialized
INFO - 2016-08-23 10:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:21:17 --> Form Validation Class Initialized
INFO - 2016-08-23 10:21:17 --> Email Class Initialized
INFO - 2016-08-23 10:21:17 --> Controller Class Initialized
INFO - 2016-08-23 10:21:17 --> Model Class Initialized
DEBUG - 2016-08-23 10:21:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:21:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:21:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:21:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:21:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:21:17 --> Final output sent to browser
DEBUG - 2016-08-23 10:21:17 --> Total execution time: 0.3596
INFO - 2016-08-23 10:21:19 --> Config Class Initialized
INFO - 2016-08-23 10:21:19 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:21:19 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:21:19 --> Utf8 Class Initialized
INFO - 2016-08-23 10:21:19 --> URI Class Initialized
INFO - 2016-08-23 10:21:19 --> Router Class Initialized
INFO - 2016-08-23 10:21:19 --> Output Class Initialized
INFO - 2016-08-23 10:21:19 --> Security Class Initialized
DEBUG - 2016-08-23 10:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:21:19 --> Input Class Initialized
INFO - 2016-08-23 10:21:19 --> Language Class Initialized
INFO - 2016-08-23 10:21:20 --> Loader Class Initialized
INFO - 2016-08-23 10:21:20 --> Helper loaded: url_helper
INFO - 2016-08-23 10:21:20 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:21:20 --> Helper loaded: html_helper
INFO - 2016-08-23 10:21:20 --> Helper loaded: form_helper
INFO - 2016-08-23 10:21:20 --> Helper loaded: file_helper
INFO - 2016-08-23 10:21:20 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:21:20 --> Database Driver Class Initialized
INFO - 2016-08-23 10:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:21:20 --> Form Validation Class Initialized
INFO - 2016-08-23 10:21:20 --> Email Class Initialized
INFO - 2016-08-23 10:21:20 --> Controller Class Initialized
INFO - 2016-08-23 10:21:20 --> Model Class Initialized
INFO - 2016-08-23 10:22:05 --> Config Class Initialized
INFO - 2016-08-23 10:22:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:22:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:22:05 --> Utf8 Class Initialized
INFO - 2016-08-23 10:22:05 --> URI Class Initialized
INFO - 2016-08-23 10:22:05 --> Router Class Initialized
INFO - 2016-08-23 10:22:05 --> Output Class Initialized
INFO - 2016-08-23 10:22:05 --> Security Class Initialized
DEBUG - 2016-08-23 10:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:22:05 --> Input Class Initialized
INFO - 2016-08-23 10:22:05 --> Language Class Initialized
INFO - 2016-08-23 10:22:05 --> Loader Class Initialized
INFO - 2016-08-23 10:22:05 --> Helper loaded: url_helper
INFO - 2016-08-23 10:22:05 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:22:05 --> Helper loaded: html_helper
INFO - 2016-08-23 10:22:05 --> Helper loaded: form_helper
INFO - 2016-08-23 10:22:05 --> Helper loaded: file_helper
INFO - 2016-08-23 10:22:05 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:22:05 --> Database Driver Class Initialized
INFO - 2016-08-23 10:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:22:05 --> Form Validation Class Initialized
INFO - 2016-08-23 10:22:05 --> Email Class Initialized
INFO - 2016-08-23 10:22:05 --> Controller Class Initialized
INFO - 2016-08-23 10:22:05 --> Model Class Initialized
DEBUG - 2016-08-23 10:22:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:22:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:22:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:22:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:22:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:22:05 --> Final output sent to browser
DEBUG - 2016-08-23 10:22:05 --> Total execution time: 0.3555
INFO - 2016-08-23 10:22:07 --> Config Class Initialized
INFO - 2016-08-23 10:22:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:22:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:22:07 --> Utf8 Class Initialized
INFO - 2016-08-23 10:22:07 --> URI Class Initialized
INFO - 2016-08-23 10:22:07 --> Router Class Initialized
INFO - 2016-08-23 10:22:07 --> Output Class Initialized
INFO - 2016-08-23 10:22:07 --> Security Class Initialized
DEBUG - 2016-08-23 10:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:22:07 --> Input Class Initialized
INFO - 2016-08-23 10:22:07 --> Language Class Initialized
INFO - 2016-08-23 10:22:07 --> Loader Class Initialized
INFO - 2016-08-23 10:22:07 --> Helper loaded: url_helper
INFO - 2016-08-23 10:22:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:22:07 --> Helper loaded: html_helper
INFO - 2016-08-23 10:22:07 --> Helper loaded: form_helper
INFO - 2016-08-23 10:22:07 --> Helper loaded: file_helper
INFO - 2016-08-23 10:22:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:22:07 --> Database Driver Class Initialized
INFO - 2016-08-23 10:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:22:07 --> Form Validation Class Initialized
INFO - 2016-08-23 10:22:07 --> Email Class Initialized
INFO - 2016-08-23 10:22:07 --> Controller Class Initialized
INFO - 2016-08-23 10:22:07 --> Model Class Initialized
DEBUG - 2016-08-23 10:22:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:22:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:22:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:22:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:22:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:22:07 --> Final output sent to browser
DEBUG - 2016-08-23 10:22:07 --> Total execution time: 0.3508
INFO - 2016-08-23 10:22:10 --> Config Class Initialized
INFO - 2016-08-23 10:22:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:22:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:22:10 --> Utf8 Class Initialized
INFO - 2016-08-23 10:22:10 --> URI Class Initialized
INFO - 2016-08-23 10:22:10 --> Router Class Initialized
INFO - 2016-08-23 10:22:10 --> Output Class Initialized
INFO - 2016-08-23 10:22:10 --> Security Class Initialized
DEBUG - 2016-08-23 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:22:10 --> Input Class Initialized
INFO - 2016-08-23 10:22:10 --> Language Class Initialized
INFO - 2016-08-23 10:22:10 --> Loader Class Initialized
INFO - 2016-08-23 10:22:10 --> Helper loaded: url_helper
INFO - 2016-08-23 10:22:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:22:10 --> Helper loaded: html_helper
INFO - 2016-08-23 10:22:10 --> Helper loaded: form_helper
INFO - 2016-08-23 10:22:10 --> Helper loaded: file_helper
INFO - 2016-08-23 10:22:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:22:10 --> Database Driver Class Initialized
INFO - 2016-08-23 10:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:22:10 --> Form Validation Class Initialized
INFO - 2016-08-23 10:22:10 --> Email Class Initialized
INFO - 2016-08-23 10:22:10 --> Controller Class Initialized
INFO - 2016-08-23 10:22:10 --> Model Class Initialized
INFO - 2016-08-23 10:39:36 --> Config Class Initialized
INFO - 2016-08-23 10:39:36 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:39:36 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:39:36 --> Utf8 Class Initialized
INFO - 2016-08-23 10:39:36 --> URI Class Initialized
DEBUG - 2016-08-23 10:39:36 --> No URI present. Default controller set.
INFO - 2016-08-23 10:39:36 --> Router Class Initialized
INFO - 2016-08-23 10:39:36 --> Output Class Initialized
INFO - 2016-08-23 10:39:36 --> Security Class Initialized
DEBUG - 2016-08-23 10:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:39:36 --> Input Class Initialized
INFO - 2016-08-23 10:39:36 --> Language Class Initialized
INFO - 2016-08-23 10:39:36 --> Loader Class Initialized
INFO - 2016-08-23 10:39:36 --> Helper loaded: url_helper
INFO - 2016-08-23 10:39:36 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:39:36 --> Helper loaded: html_helper
INFO - 2016-08-23 10:39:36 --> Helper loaded: form_helper
INFO - 2016-08-23 10:39:36 --> Helper loaded: file_helper
INFO - 2016-08-23 10:39:36 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:39:36 --> Database Driver Class Initialized
INFO - 2016-08-23 10:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:39:36 --> Form Validation Class Initialized
INFO - 2016-08-23 10:39:36 --> Email Class Initialized
INFO - 2016-08-23 10:39:36 --> Controller Class Initialized
INFO - 2016-08-23 10:39:37 --> Config Class Initialized
INFO - 2016-08-23 10:39:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:39:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:39:37 --> Utf8 Class Initialized
INFO - 2016-08-23 10:39:37 --> URI Class Initialized
INFO - 2016-08-23 10:39:37 --> Router Class Initialized
INFO - 2016-08-23 10:39:37 --> Output Class Initialized
INFO - 2016-08-23 10:39:37 --> Security Class Initialized
DEBUG - 2016-08-23 10:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:39:37 --> Input Class Initialized
INFO - 2016-08-23 10:39:37 --> Language Class Initialized
INFO - 2016-08-23 10:39:37 --> Loader Class Initialized
INFO - 2016-08-23 10:39:37 --> Helper loaded: url_helper
INFO - 2016-08-23 10:39:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:39:37 --> Helper loaded: html_helper
INFO - 2016-08-23 10:39:37 --> Helper loaded: form_helper
INFO - 2016-08-23 10:39:37 --> Helper loaded: file_helper
INFO - 2016-08-23 10:39:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:39:37 --> Database Driver Class Initialized
INFO - 2016-08-23 10:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:39:37 --> Form Validation Class Initialized
INFO - 2016-08-23 10:39:37 --> Email Class Initialized
INFO - 2016-08-23 10:39:37 --> Controller Class Initialized
INFO - 2016-08-23 10:39:37 --> Model Class Initialized
DEBUG - 2016-08-23 10:39:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:39:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:39:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:39:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:39:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:39:37 --> Final output sent to browser
DEBUG - 2016-08-23 10:39:37 --> Total execution time: 0.3378
INFO - 2016-08-23 10:39:43 --> Config Class Initialized
INFO - 2016-08-23 10:39:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:39:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:39:43 --> Utf8 Class Initialized
INFO - 2016-08-23 10:39:43 --> URI Class Initialized
INFO - 2016-08-23 10:39:43 --> Router Class Initialized
INFO - 2016-08-23 10:39:43 --> Output Class Initialized
INFO - 2016-08-23 10:39:43 --> Security Class Initialized
DEBUG - 2016-08-23 10:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:39:44 --> Input Class Initialized
INFO - 2016-08-23 10:39:44 --> Language Class Initialized
INFO - 2016-08-23 10:39:44 --> Loader Class Initialized
INFO - 2016-08-23 10:39:44 --> Helper loaded: url_helper
INFO - 2016-08-23 10:39:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:39:44 --> Helper loaded: html_helper
INFO - 2016-08-23 10:39:44 --> Helper loaded: form_helper
INFO - 2016-08-23 10:39:44 --> Helper loaded: file_helper
INFO - 2016-08-23 10:39:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:39:44 --> Database Driver Class Initialized
INFO - 2016-08-23 10:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:39:44 --> Form Validation Class Initialized
INFO - 2016-08-23 10:39:44 --> Email Class Initialized
INFO - 2016-08-23 10:39:44 --> Controller Class Initialized
INFO - 2016-08-23 10:39:44 --> Model Class Initialized
INFO - 2016-08-23 10:40:24 --> Config Class Initialized
INFO - 2016-08-23 10:40:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:40:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:40:24 --> Utf8 Class Initialized
INFO - 2016-08-23 10:40:24 --> URI Class Initialized
INFO - 2016-08-23 10:40:24 --> Router Class Initialized
INFO - 2016-08-23 10:40:24 --> Output Class Initialized
INFO - 2016-08-23 10:40:24 --> Security Class Initialized
DEBUG - 2016-08-23 10:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:40:24 --> Input Class Initialized
INFO - 2016-08-23 10:40:24 --> Language Class Initialized
INFO - 2016-08-23 10:40:24 --> Loader Class Initialized
INFO - 2016-08-23 10:40:24 --> Helper loaded: url_helper
INFO - 2016-08-23 10:40:24 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:40:24 --> Helper loaded: html_helper
INFO - 2016-08-23 10:40:24 --> Helper loaded: form_helper
INFO - 2016-08-23 10:40:24 --> Helper loaded: file_helper
INFO - 2016-08-23 10:40:24 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:40:24 --> Database Driver Class Initialized
INFO - 2016-08-23 10:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:40:24 --> Form Validation Class Initialized
INFO - 2016-08-23 10:40:24 --> Email Class Initialized
INFO - 2016-08-23 10:40:24 --> Controller Class Initialized
INFO - 2016-08-23 10:40:24 --> Model Class Initialized
DEBUG - 2016-08-23 10:40:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:40:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:40:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:40:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:40:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:40:24 --> Final output sent to browser
DEBUG - 2016-08-23 10:40:24 --> Total execution time: 0.3810
INFO - 2016-08-23 10:40:26 --> Config Class Initialized
INFO - 2016-08-23 10:40:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:40:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:40:26 --> Utf8 Class Initialized
INFO - 2016-08-23 10:40:26 --> URI Class Initialized
INFO - 2016-08-23 10:40:26 --> Router Class Initialized
INFO - 2016-08-23 10:40:26 --> Output Class Initialized
INFO - 2016-08-23 10:40:26 --> Security Class Initialized
DEBUG - 2016-08-23 10:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:40:26 --> Input Class Initialized
INFO - 2016-08-23 10:40:26 --> Language Class Initialized
INFO - 2016-08-23 10:40:26 --> Loader Class Initialized
INFO - 2016-08-23 10:40:26 --> Helper loaded: url_helper
INFO - 2016-08-23 10:40:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:40:26 --> Helper loaded: html_helper
INFO - 2016-08-23 10:40:26 --> Helper loaded: form_helper
INFO - 2016-08-23 10:40:26 --> Helper loaded: file_helper
INFO - 2016-08-23 10:40:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:40:26 --> Database Driver Class Initialized
INFO - 2016-08-23 10:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:40:26 --> Form Validation Class Initialized
INFO - 2016-08-23 10:40:26 --> Email Class Initialized
INFO - 2016-08-23 10:40:26 --> Controller Class Initialized
INFO - 2016-08-23 10:40:26 --> Model Class Initialized
DEBUG - 2016-08-23 10:40:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:40:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:40:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:40:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:40:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:40:26 --> Final output sent to browser
DEBUG - 2016-08-23 10:40:26 --> Total execution time: 0.3702
INFO - 2016-08-23 10:40:30 --> Config Class Initialized
INFO - 2016-08-23 10:40:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:40:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:40:30 --> Utf8 Class Initialized
INFO - 2016-08-23 10:40:30 --> URI Class Initialized
INFO - 2016-08-23 10:40:30 --> Router Class Initialized
INFO - 2016-08-23 10:40:30 --> Output Class Initialized
INFO - 2016-08-23 10:40:30 --> Security Class Initialized
DEBUG - 2016-08-23 10:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:40:30 --> Input Class Initialized
INFO - 2016-08-23 10:40:30 --> Language Class Initialized
INFO - 2016-08-23 10:40:30 --> Loader Class Initialized
INFO - 2016-08-23 10:40:30 --> Helper loaded: url_helper
INFO - 2016-08-23 10:40:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:40:30 --> Helper loaded: html_helper
INFO - 2016-08-23 10:40:30 --> Helper loaded: form_helper
INFO - 2016-08-23 10:40:30 --> Helper loaded: file_helper
INFO - 2016-08-23 10:40:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:40:30 --> Database Driver Class Initialized
INFO - 2016-08-23 10:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:40:30 --> Form Validation Class Initialized
INFO - 2016-08-23 10:40:30 --> Email Class Initialized
INFO - 2016-08-23 10:40:30 --> Controller Class Initialized
INFO - 2016-08-23 10:40:30 --> Model Class Initialized
INFO - 2016-08-23 10:41:07 --> Config Class Initialized
INFO - 2016-08-23 10:41:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:41:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:41:07 --> Utf8 Class Initialized
INFO - 2016-08-23 10:41:07 --> URI Class Initialized
INFO - 2016-08-23 10:41:07 --> Router Class Initialized
INFO - 2016-08-23 10:41:07 --> Output Class Initialized
INFO - 2016-08-23 10:41:07 --> Security Class Initialized
DEBUG - 2016-08-23 10:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:41:07 --> Input Class Initialized
INFO - 2016-08-23 10:41:07 --> Language Class Initialized
INFO - 2016-08-23 10:41:07 --> Loader Class Initialized
INFO - 2016-08-23 10:41:07 --> Helper loaded: url_helper
INFO - 2016-08-23 10:41:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:41:07 --> Helper loaded: html_helper
INFO - 2016-08-23 10:41:07 --> Helper loaded: form_helper
INFO - 2016-08-23 10:41:07 --> Helper loaded: file_helper
INFO - 2016-08-23 10:41:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:41:07 --> Database Driver Class Initialized
INFO - 2016-08-23 10:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:41:07 --> Form Validation Class Initialized
INFO - 2016-08-23 10:41:07 --> Email Class Initialized
INFO - 2016-08-23 10:41:07 --> Controller Class Initialized
INFO - 2016-08-23 10:41:07 --> Model Class Initialized
INFO - 2016-08-23 10:44:44 --> Config Class Initialized
INFO - 2016-08-23 10:44:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:44:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:44:44 --> Utf8 Class Initialized
INFO - 2016-08-23 10:44:44 --> URI Class Initialized
INFO - 2016-08-23 10:44:44 --> Router Class Initialized
INFO - 2016-08-23 10:44:44 --> Output Class Initialized
INFO - 2016-08-23 10:44:44 --> Security Class Initialized
DEBUG - 2016-08-23 10:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:44:44 --> Input Class Initialized
INFO - 2016-08-23 10:44:44 --> Language Class Initialized
INFO - 2016-08-23 10:44:44 --> Loader Class Initialized
INFO - 2016-08-23 10:44:44 --> Helper loaded: url_helper
INFO - 2016-08-23 10:44:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:44:44 --> Helper loaded: html_helper
INFO - 2016-08-23 10:44:45 --> Helper loaded: form_helper
INFO - 2016-08-23 10:44:45 --> Helper loaded: file_helper
INFO - 2016-08-23 10:44:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:44:45 --> Database Driver Class Initialized
INFO - 2016-08-23 10:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:44:45 --> Form Validation Class Initialized
INFO - 2016-08-23 10:44:45 --> Email Class Initialized
INFO - 2016-08-23 10:44:45 --> Controller Class Initialized
INFO - 2016-08-23 10:44:45 --> Model Class Initialized
DEBUG - 2016-08-23 10:44:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:44:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:44:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:44:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:44:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:44:45 --> Final output sent to browser
DEBUG - 2016-08-23 10:44:45 --> Total execution time: 0.3679
INFO - 2016-08-23 10:50:14 --> Config Class Initialized
INFO - 2016-08-23 10:50:14 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:50:14 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:50:14 --> Utf8 Class Initialized
INFO - 2016-08-23 10:50:15 --> URI Class Initialized
INFO - 2016-08-23 10:50:15 --> Router Class Initialized
INFO - 2016-08-23 10:50:15 --> Output Class Initialized
INFO - 2016-08-23 10:50:15 --> Security Class Initialized
DEBUG - 2016-08-23 10:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:50:15 --> Input Class Initialized
INFO - 2016-08-23 10:50:15 --> Language Class Initialized
INFO - 2016-08-23 10:50:15 --> Loader Class Initialized
INFO - 2016-08-23 10:50:15 --> Helper loaded: url_helper
INFO - 2016-08-23 10:50:15 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:50:15 --> Helper loaded: html_helper
INFO - 2016-08-23 10:50:15 --> Helper loaded: form_helper
INFO - 2016-08-23 10:50:15 --> Helper loaded: file_helper
INFO - 2016-08-23 10:50:15 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:50:15 --> Database Driver Class Initialized
INFO - 2016-08-23 10:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:50:15 --> Form Validation Class Initialized
INFO - 2016-08-23 10:50:15 --> Email Class Initialized
INFO - 2016-08-23 10:50:15 --> Controller Class Initialized
INFO - 2016-08-23 10:50:15 --> Model Class Initialized
DEBUG - 2016-08-23 10:50:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:50:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:50:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:50:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:50:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:50:15 --> Final output sent to browser
DEBUG - 2016-08-23 10:50:15 --> Total execution time: 0.5815
INFO - 2016-08-23 10:50:35 --> Config Class Initialized
INFO - 2016-08-23 10:50:35 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:50:35 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:50:35 --> Utf8 Class Initialized
INFO - 2016-08-23 10:50:35 --> URI Class Initialized
INFO - 2016-08-23 10:50:35 --> Router Class Initialized
INFO - 2016-08-23 10:50:35 --> Output Class Initialized
INFO - 2016-08-23 10:50:35 --> Security Class Initialized
DEBUG - 2016-08-23 10:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:50:35 --> Input Class Initialized
INFO - 2016-08-23 10:50:35 --> Language Class Initialized
INFO - 2016-08-23 10:50:35 --> Loader Class Initialized
INFO - 2016-08-23 10:50:35 --> Helper loaded: url_helper
INFO - 2016-08-23 10:50:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:50:35 --> Helper loaded: html_helper
INFO - 2016-08-23 10:50:35 --> Helper loaded: form_helper
INFO - 2016-08-23 10:50:35 --> Helper loaded: file_helper
INFO - 2016-08-23 10:50:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:50:35 --> Database Driver Class Initialized
INFO - 2016-08-23 10:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:50:35 --> Form Validation Class Initialized
INFO - 2016-08-23 10:50:35 --> Email Class Initialized
INFO - 2016-08-23 10:50:35 --> Controller Class Initialized
INFO - 2016-08-23 10:50:35 --> Model Class Initialized
DEBUG - 2016-08-23 10:50:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:50:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:50:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:50:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:50:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:50:35 --> Final output sent to browser
DEBUG - 2016-08-23 10:50:35 --> Total execution time: 0.3584
INFO - 2016-08-23 10:50:44 --> Config Class Initialized
INFO - 2016-08-23 10:50:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:50:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:50:44 --> Utf8 Class Initialized
INFO - 2016-08-23 10:50:44 --> URI Class Initialized
INFO - 2016-08-23 10:50:44 --> Router Class Initialized
INFO - 2016-08-23 10:50:44 --> Output Class Initialized
INFO - 2016-08-23 10:50:44 --> Security Class Initialized
DEBUG - 2016-08-23 10:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:50:44 --> Input Class Initialized
INFO - 2016-08-23 10:50:44 --> Language Class Initialized
INFO - 2016-08-23 10:50:44 --> Loader Class Initialized
INFO - 2016-08-23 10:50:44 --> Helper loaded: url_helper
INFO - 2016-08-23 10:50:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:50:44 --> Helper loaded: html_helper
INFO - 2016-08-23 10:50:44 --> Helper loaded: form_helper
INFO - 2016-08-23 10:50:44 --> Helper loaded: file_helper
INFO - 2016-08-23 10:50:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:50:44 --> Database Driver Class Initialized
INFO - 2016-08-23 10:50:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:50:44 --> Form Validation Class Initialized
INFO - 2016-08-23 10:50:44 --> Email Class Initialized
INFO - 2016-08-23 10:50:44 --> Controller Class Initialized
INFO - 2016-08-23 10:50:44 --> Model Class Initialized
DEBUG - 2016-08-23 10:50:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:50:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:50:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:50:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:50:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:50:44 --> Final output sent to browser
DEBUG - 2016-08-23 10:50:44 --> Total execution time: 0.3735
INFO - 2016-08-23 10:50:49 --> Config Class Initialized
INFO - 2016-08-23 10:50:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:50:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:50:49 --> Utf8 Class Initialized
INFO - 2016-08-23 10:50:49 --> URI Class Initialized
INFO - 2016-08-23 10:50:50 --> Router Class Initialized
INFO - 2016-08-23 10:50:50 --> Output Class Initialized
INFO - 2016-08-23 10:50:50 --> Security Class Initialized
DEBUG - 2016-08-23 10:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:50:50 --> Input Class Initialized
INFO - 2016-08-23 10:50:50 --> Language Class Initialized
INFO - 2016-08-23 10:50:50 --> Loader Class Initialized
INFO - 2016-08-23 10:50:50 --> Helper loaded: url_helper
INFO - 2016-08-23 10:50:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:50:50 --> Helper loaded: html_helper
INFO - 2016-08-23 10:50:50 --> Helper loaded: form_helper
INFO - 2016-08-23 10:50:50 --> Helper loaded: file_helper
INFO - 2016-08-23 10:50:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:50:50 --> Database Driver Class Initialized
INFO - 2016-08-23 10:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:50:50 --> Form Validation Class Initialized
INFO - 2016-08-23 10:50:50 --> Email Class Initialized
INFO - 2016-08-23 10:50:50 --> Controller Class Initialized
INFO - 2016-08-23 10:50:50 --> Model Class Initialized
INFO - 2016-08-23 10:51:15 --> Config Class Initialized
INFO - 2016-08-23 10:51:15 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:15 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:15 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:15 --> URI Class Initialized
INFO - 2016-08-23 10:51:15 --> Router Class Initialized
INFO - 2016-08-23 10:51:15 --> Output Class Initialized
INFO - 2016-08-23 10:51:15 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:15 --> Input Class Initialized
INFO - 2016-08-23 10:51:15 --> Language Class Initialized
INFO - 2016-08-23 10:51:15 --> Loader Class Initialized
INFO - 2016-08-23 10:51:15 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:15 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:15 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:15 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:15 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:15 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:15 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:15 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:15 --> Email Class Initialized
INFO - 2016-08-23 10:51:15 --> Controller Class Initialized
INFO - 2016-08-23 10:51:15 --> Model Class Initialized
DEBUG - 2016-08-23 10:51:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:51:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:51:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:51:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:51:15 --> Final output sent to browser
DEBUG - 2016-08-23 10:51:15 --> Total execution time: 0.3633
INFO - 2016-08-23 10:51:25 --> Config Class Initialized
INFO - 2016-08-23 10:51:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:25 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:25 --> URI Class Initialized
INFO - 2016-08-23 10:51:25 --> Router Class Initialized
INFO - 2016-08-23 10:51:25 --> Output Class Initialized
INFO - 2016-08-23 10:51:25 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:25 --> Input Class Initialized
INFO - 2016-08-23 10:51:25 --> Language Class Initialized
INFO - 2016-08-23 10:51:25 --> Loader Class Initialized
INFO - 2016-08-23 10:51:25 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:25 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:25 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:25 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:25 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:25 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:25 --> Email Class Initialized
INFO - 2016-08-23 10:51:25 --> Controller Class Initialized
INFO - 2016-08-23 10:51:25 --> Model Class Initialized
DEBUG - 2016-08-23 10:51:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:51:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:51:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:51:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:51:25 --> Final output sent to browser
DEBUG - 2016-08-23 10:51:25 --> Total execution time: 0.3673
INFO - 2016-08-23 10:51:35 --> Config Class Initialized
INFO - 2016-08-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:35 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:35 --> URI Class Initialized
INFO - 2016-08-23 10:51:35 --> Router Class Initialized
INFO - 2016-08-23 10:51:35 --> Output Class Initialized
INFO - 2016-08-23 10:51:35 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:35 --> Input Class Initialized
INFO - 2016-08-23 10:51:35 --> Language Class Initialized
INFO - 2016-08-23 10:51:35 --> Loader Class Initialized
INFO - 2016-08-23 10:51:35 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:35 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:35 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:35 --> Email Class Initialized
INFO - 2016-08-23 10:51:35 --> Controller Class Initialized
INFO - 2016-08-23 10:51:35 --> Model Class Initialized
DEBUG - 2016-08-23 10:51:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 10:51:35 --> Config Class Initialized
INFO - 2016-08-23 10:51:35 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:35 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:35 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:35 --> URI Class Initialized
DEBUG - 2016-08-23 10:51:35 --> No URI present. Default controller set.
INFO - 2016-08-23 10:51:35 --> Router Class Initialized
INFO - 2016-08-23 10:51:35 --> Output Class Initialized
INFO - 2016-08-23 10:51:35 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:35 --> Input Class Initialized
INFO - 2016-08-23 10:51:35 --> Language Class Initialized
INFO - 2016-08-23 10:51:35 --> Loader Class Initialized
INFO - 2016-08-23 10:51:35 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:35 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:35 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:35 --> Email Class Initialized
INFO - 2016-08-23 10:51:35 --> Controller Class Initialized
INFO - 2016-08-23 10:51:36 --> Model Class Initialized
INFO - 2016-08-23 10:51:36 --> Model Class Initialized
INFO - 2016-08-23 10:51:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:51:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 10:51:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-23 10:51:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:51:36 --> Final output sent to browser
DEBUG - 2016-08-23 10:51:36 --> Total execution time: 0.4385
INFO - 2016-08-23 10:51:51 --> Config Class Initialized
INFO - 2016-08-23 10:51:51 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:51 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:51 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:51 --> URI Class Initialized
INFO - 2016-08-23 10:51:51 --> Router Class Initialized
INFO - 2016-08-23 10:51:51 --> Output Class Initialized
INFO - 2016-08-23 10:51:51 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:51 --> Input Class Initialized
INFO - 2016-08-23 10:51:51 --> Language Class Initialized
INFO - 2016-08-23 10:51:51 --> Loader Class Initialized
INFO - 2016-08-23 10:51:51 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:51 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:51 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:51 --> Email Class Initialized
INFO - 2016-08-23 10:51:51 --> Controller Class Initialized
INFO - 2016-08-23 10:51:51 --> Model Class Initialized
INFO - 2016-08-23 10:51:51 --> Config Class Initialized
INFO - 2016-08-23 10:51:51 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:51 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:51 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:51 --> URI Class Initialized
INFO - 2016-08-23 10:51:51 --> Router Class Initialized
INFO - 2016-08-23 10:51:51 --> Output Class Initialized
INFO - 2016-08-23 10:51:51 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:51 --> Input Class Initialized
INFO - 2016-08-23 10:51:51 --> Language Class Initialized
INFO - 2016-08-23 10:51:51 --> Loader Class Initialized
INFO - 2016-08-23 10:51:51 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:51 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:51 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:51 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:51 --> Email Class Initialized
INFO - 2016-08-23 10:51:51 --> Controller Class Initialized
INFO - 2016-08-23 10:51:51 --> Model Class Initialized
DEBUG - 2016-08-23 10:51:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:51:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:51:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:51:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:51:51 --> Final output sent to browser
DEBUG - 2016-08-23 10:51:51 --> Total execution time: 0.3543
INFO - 2016-08-23 10:51:58 --> Config Class Initialized
INFO - 2016-08-23 10:51:58 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:58 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:58 --> URI Class Initialized
INFO - 2016-08-23 10:51:58 --> Router Class Initialized
INFO - 2016-08-23 10:51:58 --> Output Class Initialized
INFO - 2016-08-23 10:51:58 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:58 --> Input Class Initialized
INFO - 2016-08-23 10:51:58 --> Language Class Initialized
INFO - 2016-08-23 10:51:58 --> Loader Class Initialized
INFO - 2016-08-23 10:51:59 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:59 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:59 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:59 --> Email Class Initialized
INFO - 2016-08-23 10:51:59 --> Controller Class Initialized
INFO - 2016-08-23 10:51:59 --> Model Class Initialized
DEBUG - 2016-08-23 10:51:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:59 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 10:51:59 --> Config Class Initialized
INFO - 2016-08-23 10:51:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:51:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:51:59 --> Utf8 Class Initialized
INFO - 2016-08-23 10:51:59 --> URI Class Initialized
INFO - 2016-08-23 10:51:59 --> Router Class Initialized
INFO - 2016-08-23 10:51:59 --> Output Class Initialized
INFO - 2016-08-23 10:51:59 --> Security Class Initialized
DEBUG - 2016-08-23 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:51:59 --> Input Class Initialized
INFO - 2016-08-23 10:51:59 --> Language Class Initialized
INFO - 2016-08-23 10:51:59 --> Loader Class Initialized
INFO - 2016-08-23 10:51:59 --> Helper loaded: url_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: html_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: form_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: file_helper
INFO - 2016-08-23 10:51:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:51:59 --> Database Driver Class Initialized
INFO - 2016-08-23 10:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:51:59 --> Form Validation Class Initialized
INFO - 2016-08-23 10:51:59 --> Email Class Initialized
INFO - 2016-08-23 10:51:59 --> Controller Class Initialized
DEBUG - 2016-08-23 10:51:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 10:51:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:51:59 --> Model Class Initialized
INFO - 2016-08-23 10:51:59 --> Model Class Initialized
INFO - 2016-08-23 10:51:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:51:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 10:51:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 10:51:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:51:59 --> Final output sent to browser
DEBUG - 2016-08-23 10:51:59 --> Total execution time: 0.4600
INFO - 2016-08-23 10:54:48 --> Config Class Initialized
INFO - 2016-08-23 10:54:48 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:54:48 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:54:48 --> Utf8 Class Initialized
INFO - 2016-08-23 10:54:48 --> URI Class Initialized
INFO - 2016-08-23 10:54:48 --> Router Class Initialized
INFO - 2016-08-23 10:54:48 --> Output Class Initialized
INFO - 2016-08-23 10:54:48 --> Security Class Initialized
DEBUG - 2016-08-23 10:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:54:48 --> Input Class Initialized
INFO - 2016-08-23 10:54:48 --> Language Class Initialized
INFO - 2016-08-23 10:54:48 --> Loader Class Initialized
INFO - 2016-08-23 10:54:48 --> Helper loaded: url_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: html_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: form_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: file_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:54:48 --> Database Driver Class Initialized
INFO - 2016-08-23 10:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:54:48 --> Form Validation Class Initialized
INFO - 2016-08-23 10:54:48 --> Email Class Initialized
INFO - 2016-08-23 10:54:48 --> Controller Class Initialized
INFO - 2016-08-23 10:54:48 --> Model Class Initialized
INFO - 2016-08-23 10:54:48 --> Config Class Initialized
INFO - 2016-08-23 10:54:48 --> Hooks Class Initialized
DEBUG - 2016-08-23 10:54:48 --> UTF-8 Support Enabled
INFO - 2016-08-23 10:54:48 --> Utf8 Class Initialized
INFO - 2016-08-23 10:54:48 --> URI Class Initialized
INFO - 2016-08-23 10:54:48 --> Router Class Initialized
INFO - 2016-08-23 10:54:48 --> Output Class Initialized
INFO - 2016-08-23 10:54:48 --> Security Class Initialized
DEBUG - 2016-08-23 10:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 10:54:48 --> Input Class Initialized
INFO - 2016-08-23 10:54:48 --> Language Class Initialized
INFO - 2016-08-23 10:54:48 --> Loader Class Initialized
INFO - 2016-08-23 10:54:48 --> Helper loaded: url_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: utils_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: html_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: form_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: file_helper
INFO - 2016-08-23 10:54:48 --> Helper loaded: myemail_helper
INFO - 2016-08-23 10:54:48 --> Database Driver Class Initialized
INFO - 2016-08-23 10:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 10:54:48 --> Form Validation Class Initialized
INFO - 2016-08-23 10:54:48 --> Email Class Initialized
INFO - 2016-08-23 10:54:48 --> Controller Class Initialized
INFO - 2016-08-23 10:54:48 --> Model Class Initialized
DEBUG - 2016-08-23 10:54:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 10:54:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 10:54:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 10:54:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 10:54:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 10:54:48 --> Final output sent to browser
DEBUG - 2016-08-23 10:54:48 --> Total execution time: 0.3630
INFO - 2016-08-23 22:02:26 --> Config Class Initialized
INFO - 2016-08-23 22:02:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:02:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:02:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:02:26 --> URI Class Initialized
INFO - 2016-08-23 22:02:26 --> Router Class Initialized
INFO - 2016-08-23 22:02:26 --> Output Class Initialized
INFO - 2016-08-23 22:02:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:02:26 --> Input Class Initialized
INFO - 2016-08-23 22:02:26 --> Language Class Initialized
INFO - 2016-08-23 22:02:26 --> Loader Class Initialized
INFO - 2016-08-23 22:02:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:02:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:02:26 --> Helper loaded: html_helper
INFO - 2016-08-23 22:02:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:02:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:02:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:02:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:02:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:02:27 --> Email Class Initialized
INFO - 2016-08-23 22:02:27 --> Controller Class Initialized
INFO - 2016-08-23 22:02:27 --> Model Class Initialized
DEBUG - 2016-08-23 22:02:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 22:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 22:02:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:02:27 --> Final output sent to browser
DEBUG - 2016-08-23 22:02:27 --> Total execution time: 1.9513
INFO - 2016-08-23 22:02:29 --> Config Class Initialized
INFO - 2016-08-23 22:02:29 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:02:29 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:02:29 --> Utf8 Class Initialized
INFO - 2016-08-23 22:02:29 --> URI Class Initialized
INFO - 2016-08-23 22:02:29 --> Router Class Initialized
INFO - 2016-08-23 22:02:29 --> Output Class Initialized
INFO - 2016-08-23 22:02:29 --> Security Class Initialized
DEBUG - 2016-08-23 22:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:02:29 --> Input Class Initialized
INFO - 2016-08-23 22:02:29 --> Language Class Initialized
ERROR - 2016-08-23 22:02:29 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 22:02:30 --> Config Class Initialized
INFO - 2016-08-23 22:02:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:02:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:02:30 --> Utf8 Class Initialized
INFO - 2016-08-23 22:02:30 --> URI Class Initialized
INFO - 2016-08-23 22:02:30 --> Router Class Initialized
INFO - 2016-08-23 22:02:30 --> Output Class Initialized
INFO - 2016-08-23 22:02:30 --> Security Class Initialized
DEBUG - 2016-08-23 22:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:02:30 --> Input Class Initialized
INFO - 2016-08-23 22:02:30 --> Language Class Initialized
ERROR - 2016-08-23 22:02:30 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 22:02:42 --> Config Class Initialized
INFO - 2016-08-23 22:02:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:02:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:02:42 --> Utf8 Class Initialized
INFO - 2016-08-23 22:02:42 --> URI Class Initialized
INFO - 2016-08-23 22:02:42 --> Router Class Initialized
INFO - 2016-08-23 22:02:42 --> Output Class Initialized
INFO - 2016-08-23 22:02:42 --> Security Class Initialized
DEBUG - 2016-08-23 22:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:02:42 --> Input Class Initialized
INFO - 2016-08-23 22:02:42 --> Language Class Initialized
INFO - 2016-08-23 22:02:42 --> Loader Class Initialized
INFO - 2016-08-23 22:02:42 --> Helper loaded: url_helper
INFO - 2016-08-23 22:02:42 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:02:42 --> Helper loaded: html_helper
INFO - 2016-08-23 22:02:42 --> Helper loaded: form_helper
INFO - 2016-08-23 22:02:42 --> Helper loaded: file_helper
INFO - 2016-08-23 22:02:42 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:02:42 --> Database Driver Class Initialized
INFO - 2016-08-23 22:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:02:42 --> Form Validation Class Initialized
INFO - 2016-08-23 22:02:42 --> Email Class Initialized
INFO - 2016-08-23 22:02:42 --> Controller Class Initialized
INFO - 2016-08-23 22:02:42 --> Model Class Initialized
DEBUG - 2016-08-23 22:02:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:02:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 22:02:42 --> Config Class Initialized
INFO - 2016-08-23 22:02:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:02:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:02:43 --> Utf8 Class Initialized
INFO - 2016-08-23 22:02:43 --> URI Class Initialized
INFO - 2016-08-23 22:02:43 --> Router Class Initialized
INFO - 2016-08-23 22:02:43 --> Output Class Initialized
INFO - 2016-08-23 22:02:43 --> Security Class Initialized
DEBUG - 2016-08-23 22:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:02:43 --> Input Class Initialized
INFO - 2016-08-23 22:02:43 --> Language Class Initialized
INFO - 2016-08-23 22:02:43 --> Loader Class Initialized
INFO - 2016-08-23 22:02:43 --> Helper loaded: url_helper
INFO - 2016-08-23 22:02:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:02:43 --> Helper loaded: html_helper
INFO - 2016-08-23 22:02:43 --> Helper loaded: form_helper
INFO - 2016-08-23 22:02:43 --> Helper loaded: file_helper
INFO - 2016-08-23 22:02:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:02:43 --> Database Driver Class Initialized
INFO - 2016-08-23 22:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:02:43 --> Form Validation Class Initialized
INFO - 2016-08-23 22:02:43 --> Email Class Initialized
INFO - 2016-08-23 22:02:43 --> Controller Class Initialized
DEBUG - 2016-08-23 22:02:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:02:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:02:43 --> Model Class Initialized
INFO - 2016-08-23 22:02:43 --> Model Class Initialized
INFO - 2016-08-23 22:02:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:02:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:02:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:02:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:02:43 --> Final output sent to browser
DEBUG - 2016-08-23 22:02:43 --> Total execution time: 0.7226
INFO - 2016-08-23 22:03:06 --> Config Class Initialized
INFO - 2016-08-23 22:03:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:06 --> URI Class Initialized
INFO - 2016-08-23 22:03:06 --> Router Class Initialized
INFO - 2016-08-23 22:03:06 --> Output Class Initialized
INFO - 2016-08-23 22:03:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:06 --> Input Class Initialized
INFO - 2016-08-23 22:03:06 --> Language Class Initialized
INFO - 2016-08-23 22:03:06 --> Loader Class Initialized
INFO - 2016-08-23 22:03:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:06 --> Email Class Initialized
INFO - 2016-08-23 22:03:06 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:06 --> Model Class Initialized
INFO - 2016-08-23 22:03:06 --> Model Class Initialized
INFO - 2016-08-23 22:03:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:03:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:03:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-23 22:03:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:03:06 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:06 --> Total execution time: 0.4447
INFO - 2016-08-23 22:03:09 --> Config Class Initialized
INFO - 2016-08-23 22:03:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:09 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:09 --> URI Class Initialized
INFO - 2016-08-23 22:03:09 --> Router Class Initialized
INFO - 2016-08-23 22:03:09 --> Output Class Initialized
INFO - 2016-08-23 22:03:09 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:09 --> Input Class Initialized
INFO - 2016-08-23 22:03:09 --> Language Class Initialized
INFO - 2016-08-23 22:03:09 --> Loader Class Initialized
INFO - 2016-08-23 22:03:09 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:09 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:09 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:09 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:09 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:09 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:09 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:09 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:09 --> Email Class Initialized
INFO - 2016-08-23 22:03:09 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:10 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:10 --> Total execution time: 0.6060
INFO - 2016-08-23 22:03:12 --> Config Class Initialized
INFO - 2016-08-23 22:03:12 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:12 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:12 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:12 --> URI Class Initialized
INFO - 2016-08-23 22:03:12 --> Router Class Initialized
INFO - 2016-08-23 22:03:12 --> Output Class Initialized
INFO - 2016-08-23 22:03:12 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:12 --> Input Class Initialized
INFO - 2016-08-23 22:03:12 --> Language Class Initialized
INFO - 2016-08-23 22:03:12 --> Loader Class Initialized
INFO - 2016-08-23 22:03:12 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:12 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:12 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:12 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:12 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:13 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:13 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:13 --> Email Class Initialized
INFO - 2016-08-23 22:03:13 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:13 --> Config Class Initialized
INFO - 2016-08-23 22:03:13 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:13 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:13 --> URI Class Initialized
INFO - 2016-08-23 22:03:13 --> Router Class Initialized
INFO - 2016-08-23 22:03:13 --> Output Class Initialized
INFO - 2016-08-23 22:03:13 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:13 --> Input Class Initialized
INFO - 2016-08-23 22:03:13 --> Language Class Initialized
INFO - 2016-08-23 22:03:13 --> Loader Class Initialized
INFO - 2016-08-23 22:03:13 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:13 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:13 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:13 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:13 --> Email Class Initialized
INFO - 2016-08-23 22:03:13 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:13 --> Model Class Initialized
INFO - 2016-08-23 22:03:13 --> Model Class Initialized
INFO - 2016-08-23 22:03:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:03:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:03:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-23 22:03:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:03:13 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:13 --> Total execution time: 0.5991
INFO - 2016-08-23 22:03:18 --> Config Class Initialized
INFO - 2016-08-23 22:03:18 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:18 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:18 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:18 --> URI Class Initialized
INFO - 2016-08-23 22:03:18 --> Router Class Initialized
INFO - 2016-08-23 22:03:18 --> Output Class Initialized
INFO - 2016-08-23 22:03:18 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:18 --> Input Class Initialized
INFO - 2016-08-23 22:03:18 --> Language Class Initialized
INFO - 2016-08-23 22:03:18 --> Loader Class Initialized
INFO - 2016-08-23 22:03:18 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:18 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:18 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:18 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:18 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:18 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:18 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:18 --> Email Class Initialized
INFO - 2016-08-23 22:03:18 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:03:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:18 --> Model Class Initialized
INFO - 2016-08-23 22:03:18 --> Model Class Initialized
INFO - 2016-08-23 22:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:03:19 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:19 --> Total execution time: 0.6118
INFO - 2016-08-23 22:03:32 --> Config Class Initialized
INFO - 2016-08-23 22:03:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:32 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:32 --> URI Class Initialized
INFO - 2016-08-23 22:03:32 --> Router Class Initialized
INFO - 2016-08-23 22:03:32 --> Output Class Initialized
INFO - 2016-08-23 22:03:32 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:32 --> Input Class Initialized
INFO - 2016-08-23 22:03:32 --> Language Class Initialized
INFO - 2016-08-23 22:03:32 --> Loader Class Initialized
INFO - 2016-08-23 22:03:32 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:32 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:32 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:32 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:33 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:33 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:33 --> Email Class Initialized
INFO - 2016-08-23 22:03:33 --> Controller Class Initialized
DEBUG - 2016-08-23 22:03:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:03:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:03:33 --> Model Class Initialized
INFO - 2016-08-23 22:03:33 --> Model Class Initialized
INFO - 2016-08-23 22:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/book_in_store.php
INFO - 2016-08-23 22:03:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:03:33 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:33 --> Total execution time: 0.4459
INFO - 2016-08-23 22:03:57 --> Config Class Initialized
INFO - 2016-08-23 22:03:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:03:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:03:57 --> Utf8 Class Initialized
INFO - 2016-08-23 22:03:57 --> URI Class Initialized
INFO - 2016-08-23 22:03:57 --> Router Class Initialized
INFO - 2016-08-23 22:03:57 --> Output Class Initialized
INFO - 2016-08-23 22:03:57 --> Security Class Initialized
DEBUG - 2016-08-23 22:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:03:57 --> Input Class Initialized
INFO - 2016-08-23 22:03:57 --> Language Class Initialized
INFO - 2016-08-23 22:03:57 --> Loader Class Initialized
INFO - 2016-08-23 22:03:57 --> Helper loaded: url_helper
INFO - 2016-08-23 22:03:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:03:58 --> Helper loaded: html_helper
INFO - 2016-08-23 22:03:58 --> Helper loaded: form_helper
INFO - 2016-08-23 22:03:58 --> Helper loaded: file_helper
INFO - 2016-08-23 22:03:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:03:58 --> Database Driver Class Initialized
INFO - 2016-08-23 22:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:03:58 --> Form Validation Class Initialized
INFO - 2016-08-23 22:03:58 --> Email Class Initialized
INFO - 2016-08-23 22:03:58 --> Controller Class Initialized
INFO - 2016-08-23 22:03:58 --> Model Class Initialized
INFO - 2016-08-23 22:03:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:03:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:03:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:03:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:03:58 --> Final output sent to browser
DEBUG - 2016-08-23 22:03:58 --> Total execution time: 0.4652
INFO - 2016-08-23 22:04:06 --> Config Class Initialized
INFO - 2016-08-23 22:04:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:04:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:04:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:04:06 --> URI Class Initialized
INFO - 2016-08-23 22:04:06 --> Router Class Initialized
INFO - 2016-08-23 22:04:06 --> Output Class Initialized
INFO - 2016-08-23 22:04:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:04:06 --> Input Class Initialized
INFO - 2016-08-23 22:04:06 --> Language Class Initialized
INFO - 2016-08-23 22:04:06 --> Loader Class Initialized
INFO - 2016-08-23 22:04:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:04:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:04:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:04:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:04:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:04:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:04:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:04:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:04:06 --> Email Class Initialized
INFO - 2016-08-23 22:04:07 --> Controller Class Initialized
DEBUG - 2016-08-23 22:04:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:04:07 --> Model Class Initialized
INFO - 2016-08-23 22:04:07 --> Model Class Initialized
INFO - 2016-08-23 22:04:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:04:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:04:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:04:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:04:07 --> Final output sent to browser
DEBUG - 2016-08-23 22:04:07 --> Total execution time: 0.4427
INFO - 2016-08-23 22:04:10 --> Config Class Initialized
INFO - 2016-08-23 22:04:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:04:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:04:10 --> Utf8 Class Initialized
INFO - 2016-08-23 22:04:10 --> URI Class Initialized
INFO - 2016-08-23 22:04:10 --> Router Class Initialized
INFO - 2016-08-23 22:04:10 --> Output Class Initialized
INFO - 2016-08-23 22:04:10 --> Security Class Initialized
DEBUG - 2016-08-23 22:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:04:10 --> Input Class Initialized
INFO - 2016-08-23 22:04:10 --> Language Class Initialized
INFO - 2016-08-23 22:04:10 --> Loader Class Initialized
INFO - 2016-08-23 22:04:10 --> Helper loaded: url_helper
INFO - 2016-08-23 22:04:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:04:10 --> Helper loaded: html_helper
INFO - 2016-08-23 22:04:10 --> Helper loaded: form_helper
INFO - 2016-08-23 22:04:10 --> Helper loaded: file_helper
INFO - 2016-08-23 22:04:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:04:10 --> Database Driver Class Initialized
INFO - 2016-08-23 22:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:04:10 --> Form Validation Class Initialized
INFO - 2016-08-23 22:04:10 --> Email Class Initialized
INFO - 2016-08-23 22:04:10 --> Controller Class Initialized
DEBUG - 2016-08-23 22:04:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:04:10 --> Model Class Initialized
INFO - 2016-08-23 22:04:10 --> Model Class Initialized
INFO - 2016-08-23 22:04:10 --> Model Class Initialized
INFO - 2016-08-23 22:04:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:04:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:04:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:04:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:04:10 --> Final output sent to browser
DEBUG - 2016-08-23 22:04:10 --> Total execution time: 0.4845
INFO - 2016-08-23 22:11:59 --> Config Class Initialized
INFO - 2016-08-23 22:11:59 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:11:59 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:11:59 --> Utf8 Class Initialized
INFO - 2016-08-23 22:11:59 --> URI Class Initialized
INFO - 2016-08-23 22:11:59 --> Router Class Initialized
INFO - 2016-08-23 22:11:59 --> Output Class Initialized
INFO - 2016-08-23 22:11:59 --> Security Class Initialized
DEBUG - 2016-08-23 22:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:11:59 --> Input Class Initialized
INFO - 2016-08-23 22:11:59 --> Language Class Initialized
INFO - 2016-08-23 22:11:59 --> Loader Class Initialized
INFO - 2016-08-23 22:11:59 --> Helper loaded: url_helper
INFO - 2016-08-23 22:11:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:11:59 --> Helper loaded: html_helper
INFO - 2016-08-23 22:11:59 --> Helper loaded: form_helper
INFO - 2016-08-23 22:11:59 --> Helper loaded: file_helper
INFO - 2016-08-23 22:11:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:11:59 --> Database Driver Class Initialized
INFO - 2016-08-23 22:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:11:59 --> Form Validation Class Initialized
INFO - 2016-08-23 22:11:59 --> Email Class Initialized
INFO - 2016-08-23 22:11:59 --> Controller Class Initialized
DEBUG - 2016-08-23 22:11:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:00 --> Model Class Initialized
INFO - 2016-08-23 22:12:00 --> Model Class Initialized
INFO - 2016-08-23 22:12:00 --> Model Class Initialized
INFO - 2016-08-23 22:12:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:12:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:12:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:00 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:00 --> Total execution time: 0.6099
INFO - 2016-08-23 22:12:06 --> Config Class Initialized
INFO - 2016-08-23 22:12:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:06 --> URI Class Initialized
INFO - 2016-08-23 22:12:06 --> Router Class Initialized
INFO - 2016-08-23 22:12:06 --> Output Class Initialized
INFO - 2016-08-23 22:12:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:06 --> Input Class Initialized
INFO - 2016-08-23 22:12:06 --> Language Class Initialized
INFO - 2016-08-23 22:12:06 --> Loader Class Initialized
INFO - 2016-08-23 22:12:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:06 --> Email Class Initialized
INFO - 2016-08-23 22:12:06 --> Controller Class Initialized
INFO - 2016-08-23 22:12:06 --> Model Class Initialized
INFO - 2016-08-23 22:12:06 --> Config Class Initialized
INFO - 2016-08-23 22:12:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:06 --> URI Class Initialized
INFO - 2016-08-23 22:12:06 --> Router Class Initialized
INFO - 2016-08-23 22:12:06 --> Output Class Initialized
INFO - 2016-08-23 22:12:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:06 --> Input Class Initialized
INFO - 2016-08-23 22:12:06 --> Language Class Initialized
INFO - 2016-08-23 22:12:06 --> Loader Class Initialized
INFO - 2016-08-23 22:12:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:06 --> Email Class Initialized
INFO - 2016-08-23 22:12:06 --> Controller Class Initialized
INFO - 2016-08-23 22:12:06 --> Model Class Initialized
DEBUG - 2016-08-23 22:12:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 22:12:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 22:12:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:06 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:07 --> Total execution time: 0.3625
INFO - 2016-08-23 22:12:20 --> Config Class Initialized
INFO - 2016-08-23 22:12:20 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:20 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:20 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:20 --> URI Class Initialized
INFO - 2016-08-23 22:12:20 --> Router Class Initialized
INFO - 2016-08-23 22:12:20 --> Output Class Initialized
INFO - 2016-08-23 22:12:20 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:20 --> Input Class Initialized
INFO - 2016-08-23 22:12:20 --> Language Class Initialized
INFO - 2016-08-23 22:12:20 --> Loader Class Initialized
INFO - 2016-08-23 22:12:20 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:20 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:20 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:20 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:20 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:20 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:20 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:20 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:20 --> Email Class Initialized
INFO - 2016-08-23 22:12:20 --> Controller Class Initialized
INFO - 2016-08-23 22:12:20 --> Model Class Initialized
DEBUG - 2016-08-23 22:12:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 22:12:20 --> Config Class Initialized
INFO - 2016-08-23 22:12:20 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:20 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:20 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:20 --> URI Class Initialized
INFO - 2016-08-23 22:12:20 --> Router Class Initialized
INFO - 2016-08-23 22:12:20 --> Output Class Initialized
INFO - 2016-08-23 22:12:20 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:20 --> Input Class Initialized
INFO - 2016-08-23 22:12:20 --> Language Class Initialized
INFO - 2016-08-23 22:12:20 --> Loader Class Initialized
INFO - 2016-08-23 22:12:20 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:21 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:21 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:21 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:21 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:21 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:21 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:21 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:21 --> Email Class Initialized
INFO - 2016-08-23 22:12:21 --> Controller Class Initialized
DEBUG - 2016-08-23 22:12:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:12:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:21 --> Model Class Initialized
INFO - 2016-08-23 22:12:21 --> Model Class Initialized
INFO - 2016-08-23 22:12:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:12:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:12:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:21 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:21 --> Total execution time: 0.4507
INFO - 2016-08-23 22:12:39 --> Config Class Initialized
INFO - 2016-08-23 22:12:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:39 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:39 --> URI Class Initialized
INFO - 2016-08-23 22:12:39 --> Router Class Initialized
INFO - 2016-08-23 22:12:39 --> Output Class Initialized
INFO - 2016-08-23 22:12:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:39 --> Input Class Initialized
INFO - 2016-08-23 22:12:39 --> Language Class Initialized
INFO - 2016-08-23 22:12:39 --> Loader Class Initialized
INFO - 2016-08-23 22:12:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:39 --> Email Class Initialized
INFO - 2016-08-23 22:12:39 --> Controller Class Initialized
INFO - 2016-08-23 22:12:39 --> Model Class Initialized
INFO - 2016-08-23 22:12:39 --> Config Class Initialized
INFO - 2016-08-23 22:12:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:39 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:39 --> URI Class Initialized
INFO - 2016-08-23 22:12:39 --> Router Class Initialized
INFO - 2016-08-23 22:12:39 --> Output Class Initialized
INFO - 2016-08-23 22:12:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:39 --> Input Class Initialized
INFO - 2016-08-23 22:12:39 --> Language Class Initialized
INFO - 2016-08-23 22:12:39 --> Loader Class Initialized
INFO - 2016-08-23 22:12:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:39 --> Email Class Initialized
INFO - 2016-08-23 22:12:39 --> Controller Class Initialized
INFO - 2016-08-23 22:12:39 --> Model Class Initialized
DEBUG - 2016-08-23 22:12:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 22:12:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 22:12:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:39 --> Total execution time: 0.3695
INFO - 2016-08-23 22:12:47 --> Config Class Initialized
INFO - 2016-08-23 22:12:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:47 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:47 --> URI Class Initialized
INFO - 2016-08-23 22:12:47 --> Router Class Initialized
INFO - 2016-08-23 22:12:47 --> Output Class Initialized
INFO - 2016-08-23 22:12:47 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:47 --> Input Class Initialized
INFO - 2016-08-23 22:12:47 --> Language Class Initialized
INFO - 2016-08-23 22:12:47 --> Loader Class Initialized
INFO - 2016-08-23 22:12:47 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:47 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:47 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:47 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:47 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:47 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:47 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:47 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:47 --> Email Class Initialized
INFO - 2016-08-23 22:12:47 --> Controller Class Initialized
INFO - 2016-08-23 22:12:47 --> Model Class Initialized
DEBUG - 2016-08-23 22:12:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 22:12:48 --> Config Class Initialized
INFO - 2016-08-23 22:12:48 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:48 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:48 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:48 --> URI Class Initialized
INFO - 2016-08-23 22:12:48 --> Router Class Initialized
INFO - 2016-08-23 22:12:48 --> Output Class Initialized
INFO - 2016-08-23 22:12:48 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:48 --> Input Class Initialized
INFO - 2016-08-23 22:12:48 --> Language Class Initialized
INFO - 2016-08-23 22:12:48 --> Loader Class Initialized
INFO - 2016-08-23 22:12:48 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:48 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:48 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:48 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:48 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:48 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:48 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:48 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:48 --> Email Class Initialized
INFO - 2016-08-23 22:12:48 --> Controller Class Initialized
INFO - 2016-08-23 22:12:48 --> Model Class Initialized
INFO - 2016-08-23 22:12:48 --> Model Class Initialized
INFO - 2016-08-23 22:12:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:12:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-23 22:12:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:48 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:48 --> Total execution time: 0.6334
INFO - 2016-08-23 22:12:57 --> Config Class Initialized
INFO - 2016-08-23 22:12:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:57 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:57 --> URI Class Initialized
INFO - 2016-08-23 22:12:57 --> Router Class Initialized
INFO - 2016-08-23 22:12:57 --> Output Class Initialized
INFO - 2016-08-23 22:12:57 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:57 --> Input Class Initialized
INFO - 2016-08-23 22:12:57 --> Language Class Initialized
INFO - 2016-08-23 22:12:57 --> Loader Class Initialized
INFO - 2016-08-23 22:12:57 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:57 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:57 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:57 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:57 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:57 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:57 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:57 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:57 --> Email Class Initialized
INFO - 2016-08-23 22:12:57 --> Controller Class Initialized
DEBUG - 2016-08-23 22:12:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:12:57 --> Model Class Initialized
INFO - 2016-08-23 22:12:57 --> Model Class Initialized
INFO - 2016-08-23 22:12:57 --> Config Class Initialized
INFO - 2016-08-23 22:12:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:12:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:12:57 --> Utf8 Class Initialized
INFO - 2016-08-23 22:12:57 --> URI Class Initialized
INFO - 2016-08-23 22:12:58 --> Router Class Initialized
INFO - 2016-08-23 22:12:58 --> Output Class Initialized
INFO - 2016-08-23 22:12:58 --> Security Class Initialized
DEBUG - 2016-08-23 22:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:12:58 --> Input Class Initialized
INFO - 2016-08-23 22:12:58 --> Language Class Initialized
INFO - 2016-08-23 22:12:58 --> Loader Class Initialized
INFO - 2016-08-23 22:12:58 --> Helper loaded: url_helper
INFO - 2016-08-23 22:12:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:12:58 --> Helper loaded: html_helper
INFO - 2016-08-23 22:12:58 --> Helper loaded: form_helper
INFO - 2016-08-23 22:12:58 --> Helper loaded: file_helper
INFO - 2016-08-23 22:12:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:12:58 --> Database Driver Class Initialized
INFO - 2016-08-23 22:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:12:58 --> Form Validation Class Initialized
INFO - 2016-08-23 22:12:58 --> Email Class Initialized
INFO - 2016-08-23 22:12:58 --> Controller Class Initialized
INFO - 2016-08-23 22:12:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:12:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:12:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-23 22:12:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:12:58 --> Final output sent to browser
DEBUG - 2016-08-23 22:12:58 --> Total execution time: 0.3394
INFO - 2016-08-23 22:14:20 --> Config Class Initialized
INFO - 2016-08-23 22:14:20 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:14:20 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:14:20 --> Utf8 Class Initialized
INFO - 2016-08-23 22:14:20 --> URI Class Initialized
INFO - 2016-08-23 22:14:20 --> Router Class Initialized
INFO - 2016-08-23 22:14:20 --> Output Class Initialized
INFO - 2016-08-23 22:14:20 --> Security Class Initialized
DEBUG - 2016-08-23 22:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:14:20 --> Input Class Initialized
INFO - 2016-08-23 22:14:20 --> Language Class Initialized
INFO - 2016-08-23 22:14:20 --> Loader Class Initialized
INFO - 2016-08-23 22:14:20 --> Helper loaded: url_helper
INFO - 2016-08-23 22:14:20 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:14:20 --> Helper loaded: html_helper
INFO - 2016-08-23 22:14:20 --> Helper loaded: form_helper
INFO - 2016-08-23 22:14:20 --> Helper loaded: file_helper
INFO - 2016-08-23 22:14:20 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:14:20 --> Database Driver Class Initialized
INFO - 2016-08-23 22:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:14:20 --> Form Validation Class Initialized
INFO - 2016-08-23 22:14:20 --> Email Class Initialized
INFO - 2016-08-23 22:14:20 --> Controller Class Initialized
INFO - 2016-08-23 22:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-23 22:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:14:20 --> Final output sent to browser
DEBUG - 2016-08-23 22:14:20 --> Total execution time: 0.3663
INFO - 2016-08-23 22:15:26 --> Config Class Initialized
INFO - 2016-08-23 22:15:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:26 --> URI Class Initialized
INFO - 2016-08-23 22:15:26 --> Router Class Initialized
INFO - 2016-08-23 22:15:26 --> Output Class Initialized
INFO - 2016-08-23 22:15:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:26 --> Input Class Initialized
INFO - 2016-08-23 22:15:26 --> Language Class Initialized
INFO - 2016-08-23 22:15:26 --> Loader Class Initialized
INFO - 2016-08-23 22:15:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:26 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:26 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:26 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:26 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:26 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:26 --> Email Class Initialized
INFO - 2016-08-23 22:15:26 --> Controller Class Initialized
DEBUG - 2016-08-23 22:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:15:26 --> Model Class Initialized
INFO - 2016-08-23 22:15:26 --> Model Class Initialized
INFO - 2016-08-23 22:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-23 22:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:15:26 --> Final output sent to browser
DEBUG - 2016-08-23 22:15:26 --> Total execution time: 0.3789
INFO - 2016-08-23 22:15:29 --> Config Class Initialized
INFO - 2016-08-23 22:15:29 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:29 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:29 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:29 --> URI Class Initialized
INFO - 2016-08-23 22:15:29 --> Router Class Initialized
INFO - 2016-08-23 22:15:29 --> Output Class Initialized
INFO - 2016-08-23 22:15:29 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:29 --> Input Class Initialized
INFO - 2016-08-23 22:15:29 --> Language Class Initialized
INFO - 2016-08-23 22:15:29 --> Loader Class Initialized
INFO - 2016-08-23 22:15:30 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:30 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:30 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:30 --> Email Class Initialized
INFO - 2016-08-23 22:15:30 --> Controller Class Initialized
INFO - 2016-08-23 22:15:30 --> Model Class Initialized
INFO - 2016-08-23 22:15:30 --> Config Class Initialized
INFO - 2016-08-23 22:15:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:30 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:30 --> URI Class Initialized
INFO - 2016-08-23 22:15:30 --> Router Class Initialized
INFO - 2016-08-23 22:15:30 --> Output Class Initialized
INFO - 2016-08-23 22:15:30 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:30 --> Input Class Initialized
INFO - 2016-08-23 22:15:30 --> Language Class Initialized
INFO - 2016-08-23 22:15:30 --> Loader Class Initialized
INFO - 2016-08-23 22:15:30 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:30 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:30 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:30 --> Email Class Initialized
INFO - 2016-08-23 22:15:30 --> Controller Class Initialized
INFO - 2016-08-23 22:15:30 --> Model Class Initialized
DEBUG - 2016-08-23 22:15:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:15:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 22:15:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:15:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 22:15:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:15:30 --> Final output sent to browser
DEBUG - 2016-08-23 22:15:30 --> Total execution time: 0.3770
INFO - 2016-08-23 22:15:38 --> Config Class Initialized
INFO - 2016-08-23 22:15:38 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:38 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:38 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:38 --> URI Class Initialized
INFO - 2016-08-23 22:15:38 --> Router Class Initialized
INFO - 2016-08-23 22:15:38 --> Output Class Initialized
INFO - 2016-08-23 22:15:38 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:38 --> Input Class Initialized
INFO - 2016-08-23 22:15:38 --> Language Class Initialized
INFO - 2016-08-23 22:15:38 --> Loader Class Initialized
INFO - 2016-08-23 22:15:38 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:38 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:38 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:38 --> Email Class Initialized
INFO - 2016-08-23 22:15:38 --> Controller Class Initialized
INFO - 2016-08-23 22:15:38 --> Model Class Initialized
DEBUG - 2016-08-23 22:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:15:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 22:15:38 --> Config Class Initialized
INFO - 2016-08-23 22:15:38 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:38 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:38 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:38 --> URI Class Initialized
INFO - 2016-08-23 22:15:38 --> Router Class Initialized
INFO - 2016-08-23 22:15:38 --> Output Class Initialized
INFO - 2016-08-23 22:15:38 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:38 --> Input Class Initialized
INFO - 2016-08-23 22:15:38 --> Language Class Initialized
INFO - 2016-08-23 22:15:38 --> Loader Class Initialized
INFO - 2016-08-23 22:15:38 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:38 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:38 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:38 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:38 --> Email Class Initialized
INFO - 2016-08-23 22:15:38 --> Controller Class Initialized
DEBUG - 2016-08-23 22:15:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:15:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:15:38 --> Model Class Initialized
INFO - 2016-08-23 22:15:38 --> Model Class Initialized
INFO - 2016-08-23 22:15:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:15:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:15:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:15:39 --> Total execution time: 0.4609
INFO - 2016-08-23 22:15:50 --> Config Class Initialized
INFO - 2016-08-23 22:15:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:50 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:50 --> URI Class Initialized
INFO - 2016-08-23 22:15:50 --> Router Class Initialized
INFO - 2016-08-23 22:15:50 --> Output Class Initialized
INFO - 2016-08-23 22:15:50 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:50 --> Input Class Initialized
INFO - 2016-08-23 22:15:50 --> Language Class Initialized
INFO - 2016-08-23 22:15:50 --> Loader Class Initialized
INFO - 2016-08-23 22:15:50 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:50 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:50 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:50 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:51 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:51 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:51 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:51 --> Email Class Initialized
INFO - 2016-08-23 22:15:51 --> Controller Class Initialized
INFO - 2016-08-23 22:15:51 --> Model Class Initialized
INFO - 2016-08-23 22:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:15:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:15:51 --> Final output sent to browser
DEBUG - 2016-08-23 22:15:51 --> Total execution time: 0.3704
INFO - 2016-08-23 22:15:56 --> Config Class Initialized
INFO - 2016-08-23 22:15:56 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:15:56 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:15:56 --> Utf8 Class Initialized
INFO - 2016-08-23 22:15:56 --> URI Class Initialized
INFO - 2016-08-23 22:15:56 --> Router Class Initialized
INFO - 2016-08-23 22:15:56 --> Output Class Initialized
INFO - 2016-08-23 22:15:56 --> Security Class Initialized
DEBUG - 2016-08-23 22:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:15:56 --> Input Class Initialized
INFO - 2016-08-23 22:15:56 --> Language Class Initialized
INFO - 2016-08-23 22:15:56 --> Loader Class Initialized
INFO - 2016-08-23 22:15:56 --> Helper loaded: url_helper
INFO - 2016-08-23 22:15:56 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:15:56 --> Helper loaded: html_helper
INFO - 2016-08-23 22:15:56 --> Helper loaded: form_helper
INFO - 2016-08-23 22:15:56 --> Helper loaded: file_helper
INFO - 2016-08-23 22:15:56 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:15:56 --> Database Driver Class Initialized
INFO - 2016-08-23 22:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:15:56 --> Form Validation Class Initialized
INFO - 2016-08-23 22:15:56 --> Email Class Initialized
INFO - 2016-08-23 22:15:56 --> Controller Class Initialized
INFO - 2016-08-23 22:15:56 --> Model Class Initialized
DEBUG - 2016-08-23 22:15:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-23 22:15:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:15:56 --> Final output sent to browser
DEBUG - 2016-08-23 22:15:56 --> Total execution time: 0.4520
INFO - 2016-08-23 22:16:19 --> Config Class Initialized
INFO - 2016-08-23 22:16:19 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:16:19 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:16:19 --> Utf8 Class Initialized
INFO - 2016-08-23 22:16:19 --> URI Class Initialized
INFO - 2016-08-23 22:16:19 --> Router Class Initialized
INFO - 2016-08-23 22:16:19 --> Output Class Initialized
INFO - 2016-08-23 22:16:19 --> Security Class Initialized
DEBUG - 2016-08-23 22:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:16:19 --> Input Class Initialized
INFO - 2016-08-23 22:16:19 --> Language Class Initialized
INFO - 2016-08-23 22:16:19 --> Loader Class Initialized
INFO - 2016-08-23 22:16:19 --> Helper loaded: url_helper
INFO - 2016-08-23 22:16:19 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:16:19 --> Helper loaded: html_helper
INFO - 2016-08-23 22:16:19 --> Helper loaded: form_helper
INFO - 2016-08-23 22:16:19 --> Helper loaded: file_helper
INFO - 2016-08-23 22:16:19 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:16:19 --> Database Driver Class Initialized
INFO - 2016-08-23 22:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:16:19 --> Form Validation Class Initialized
INFO - 2016-08-23 22:16:19 --> Email Class Initialized
INFO - 2016-08-23 22:16:19 --> Controller Class Initialized
INFO - 2016-08-23 22:16:19 --> Model Class Initialized
INFO - 2016-08-23 22:16:19 --> Model Class Initialized
DEBUG - 2016-08-23 22:16:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:16:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:16:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:16:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:16:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:16:19 --> Final output sent to browser
DEBUG - 2016-08-23 22:16:19 --> Total execution time: 0.4873
INFO - 2016-08-23 22:16:22 --> Config Class Initialized
INFO - 2016-08-23 22:16:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:16:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:16:22 --> Utf8 Class Initialized
INFO - 2016-08-23 22:16:22 --> URI Class Initialized
INFO - 2016-08-23 22:16:22 --> Router Class Initialized
INFO - 2016-08-23 22:16:22 --> Output Class Initialized
INFO - 2016-08-23 22:16:22 --> Security Class Initialized
DEBUG - 2016-08-23 22:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:16:22 --> Input Class Initialized
INFO - 2016-08-23 22:16:22 --> Language Class Initialized
INFO - 2016-08-23 22:16:22 --> Loader Class Initialized
INFO - 2016-08-23 22:16:22 --> Helper loaded: url_helper
INFO - 2016-08-23 22:16:22 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:16:22 --> Helper loaded: html_helper
INFO - 2016-08-23 22:16:22 --> Helper loaded: form_helper
INFO - 2016-08-23 22:16:22 --> Helper loaded: file_helper
INFO - 2016-08-23 22:16:22 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:16:22 --> Database Driver Class Initialized
INFO - 2016-08-23 22:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:16:22 --> Form Validation Class Initialized
INFO - 2016-08-23 22:16:22 --> Email Class Initialized
INFO - 2016-08-23 22:16:22 --> Controller Class Initialized
INFO - 2016-08-23 22:16:22 --> Model Class Initialized
INFO - 2016-08-23 22:16:22 --> Model Class Initialized
DEBUG - 2016-08-23 22:16:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:16:22 --> Final output sent to browser
DEBUG - 2016-08-23 22:16:22 --> Total execution time: 0.3906
INFO - 2016-08-23 22:18:33 --> Config Class Initialized
INFO - 2016-08-23 22:18:33 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:18:33 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:18:33 --> Utf8 Class Initialized
INFO - 2016-08-23 22:18:33 --> URI Class Initialized
INFO - 2016-08-23 22:18:33 --> Router Class Initialized
INFO - 2016-08-23 22:18:33 --> Output Class Initialized
INFO - 2016-08-23 22:18:33 --> Security Class Initialized
DEBUG - 2016-08-23 22:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:18:33 --> Input Class Initialized
INFO - 2016-08-23 22:18:33 --> Language Class Initialized
INFO - 2016-08-23 22:18:33 --> Loader Class Initialized
INFO - 2016-08-23 22:18:33 --> Helper loaded: url_helper
INFO - 2016-08-23 22:18:33 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:18:33 --> Helper loaded: html_helper
INFO - 2016-08-23 22:18:33 --> Helper loaded: form_helper
INFO - 2016-08-23 22:18:33 --> Helper loaded: file_helper
INFO - 2016-08-23 22:18:33 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:18:33 --> Database Driver Class Initialized
INFO - 2016-08-23 22:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:18:33 --> Form Validation Class Initialized
INFO - 2016-08-23 22:18:33 --> Email Class Initialized
INFO - 2016-08-23 22:18:33 --> Controller Class Initialized
DEBUG - 2016-08-23 22:18:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:18:33 --> Model Class Initialized
INFO - 2016-08-23 22:18:33 --> Model Class Initialized
INFO - 2016-08-23 22:18:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:18:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:18:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:18:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:18:33 --> Final output sent to browser
DEBUG - 2016-08-23 22:18:33 --> Total execution time: 0.4008
INFO - 2016-08-23 22:18:36 --> Config Class Initialized
INFO - 2016-08-23 22:18:36 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:18:36 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:18:36 --> Utf8 Class Initialized
INFO - 2016-08-23 22:18:36 --> URI Class Initialized
INFO - 2016-08-23 22:18:36 --> Router Class Initialized
INFO - 2016-08-23 22:18:36 --> Output Class Initialized
INFO - 2016-08-23 22:18:36 --> Security Class Initialized
DEBUG - 2016-08-23 22:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:18:36 --> Input Class Initialized
INFO - 2016-08-23 22:18:36 --> Language Class Initialized
INFO - 2016-08-23 22:18:36 --> Loader Class Initialized
INFO - 2016-08-23 22:18:36 --> Helper loaded: url_helper
INFO - 2016-08-23 22:18:36 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:18:36 --> Helper loaded: html_helper
INFO - 2016-08-23 22:18:36 --> Helper loaded: form_helper
INFO - 2016-08-23 22:18:36 --> Helper loaded: file_helper
INFO - 2016-08-23 22:18:36 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:18:36 --> Database Driver Class Initialized
INFO - 2016-08-23 22:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:18:36 --> Form Validation Class Initialized
INFO - 2016-08-23 22:18:36 --> Email Class Initialized
INFO - 2016-08-23 22:18:37 --> Controller Class Initialized
DEBUG - 2016-08-23 22:18:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:18:37 --> Model Class Initialized
INFO - 2016-08-23 22:18:37 --> Model Class Initialized
INFO - 2016-08-23 22:18:37 --> Model Class Initialized
INFO - 2016-08-23 22:18:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:18:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:18:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:18:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:18:37 --> Final output sent to browser
DEBUG - 2016-08-23 22:18:37 --> Total execution time: 0.5546
INFO - 2016-08-23 22:18:42 --> Config Class Initialized
INFO - 2016-08-23 22:18:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:18:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:18:42 --> Utf8 Class Initialized
INFO - 2016-08-23 22:18:42 --> URI Class Initialized
INFO - 2016-08-23 22:18:42 --> Router Class Initialized
INFO - 2016-08-23 22:18:42 --> Output Class Initialized
INFO - 2016-08-23 22:18:42 --> Security Class Initialized
DEBUG - 2016-08-23 22:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:18:42 --> Input Class Initialized
INFO - 2016-08-23 22:18:42 --> Language Class Initialized
INFO - 2016-08-23 22:18:42 --> Loader Class Initialized
INFO - 2016-08-23 22:18:42 --> Helper loaded: url_helper
INFO - 2016-08-23 22:18:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:18:43 --> Helper loaded: html_helper
INFO - 2016-08-23 22:18:43 --> Helper loaded: form_helper
INFO - 2016-08-23 22:18:43 --> Helper loaded: file_helper
INFO - 2016-08-23 22:18:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:18:43 --> Database Driver Class Initialized
INFO - 2016-08-23 22:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:18:43 --> Form Validation Class Initialized
INFO - 2016-08-23 22:18:43 --> Email Class Initialized
INFO - 2016-08-23 22:18:43 --> Controller Class Initialized
DEBUG - 2016-08-23 22:18:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:18:43 --> Model Class Initialized
INFO - 2016-08-23 22:18:43 --> Model Class Initialized
INFO - 2016-08-23 22:18:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:18:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:18:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:18:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:18:43 --> Final output sent to browser
DEBUG - 2016-08-23 22:18:43 --> Total execution time: 0.4271
INFO - 2016-08-23 22:20:05 --> Config Class Initialized
INFO - 2016-08-23 22:20:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:20:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:20:05 --> Utf8 Class Initialized
INFO - 2016-08-23 22:20:05 --> URI Class Initialized
INFO - 2016-08-23 22:20:05 --> Router Class Initialized
INFO - 2016-08-23 22:20:05 --> Output Class Initialized
INFO - 2016-08-23 22:20:05 --> Security Class Initialized
DEBUG - 2016-08-23 22:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:20:05 --> Input Class Initialized
INFO - 2016-08-23 22:20:05 --> Language Class Initialized
INFO - 2016-08-23 22:20:05 --> Loader Class Initialized
INFO - 2016-08-23 22:20:05 --> Helper loaded: url_helper
INFO - 2016-08-23 22:20:05 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:20:05 --> Helper loaded: html_helper
INFO - 2016-08-23 22:20:05 --> Helper loaded: form_helper
INFO - 2016-08-23 22:20:05 --> Helper loaded: file_helper
INFO - 2016-08-23 22:20:05 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:20:05 --> Database Driver Class Initialized
INFO - 2016-08-23 22:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:20:05 --> Form Validation Class Initialized
INFO - 2016-08-23 22:20:05 --> Email Class Initialized
INFO - 2016-08-23 22:20:05 --> Controller Class Initialized
DEBUG - 2016-08-23 22:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:20:05 --> Model Class Initialized
INFO - 2016-08-23 22:20:05 --> Model Class Initialized
INFO - 2016-08-23 22:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:20:05 --> Final output sent to browser
DEBUG - 2016-08-23 22:20:05 --> Total execution time: 0.4056
INFO - 2016-08-23 22:20:19 --> Config Class Initialized
INFO - 2016-08-23 22:20:19 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:20:19 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:20:19 --> Utf8 Class Initialized
INFO - 2016-08-23 22:20:19 --> URI Class Initialized
INFO - 2016-08-23 22:20:19 --> Router Class Initialized
INFO - 2016-08-23 22:20:19 --> Output Class Initialized
INFO - 2016-08-23 22:20:19 --> Security Class Initialized
DEBUG - 2016-08-23 22:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:20:19 --> Input Class Initialized
INFO - 2016-08-23 22:20:19 --> Language Class Initialized
INFO - 2016-08-23 22:20:20 --> Loader Class Initialized
INFO - 2016-08-23 22:20:20 --> Helper loaded: url_helper
INFO - 2016-08-23 22:20:20 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:20:20 --> Helper loaded: html_helper
INFO - 2016-08-23 22:20:20 --> Helper loaded: form_helper
INFO - 2016-08-23 22:20:20 --> Helper loaded: file_helper
INFO - 2016-08-23 22:20:20 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:20:20 --> Database Driver Class Initialized
INFO - 2016-08-23 22:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:20:20 --> Form Validation Class Initialized
INFO - 2016-08-23 22:20:20 --> Email Class Initialized
INFO - 2016-08-23 22:20:20 --> Controller Class Initialized
DEBUG - 2016-08-23 22:20:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:20:20 --> Model Class Initialized
INFO - 2016-08-23 22:20:20 --> Model Class Initialized
INFO - 2016-08-23 22:20:20 --> Model Class Initialized
INFO - 2016-08-23 22:20:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:20:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:20:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:20:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:20:20 --> Final output sent to browser
DEBUG - 2016-08-23 22:20:20 --> Total execution time: 0.4162
INFO - 2016-08-23 22:21:13 --> Config Class Initialized
INFO - 2016-08-23 22:21:13 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:21:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:21:13 --> Utf8 Class Initialized
INFO - 2016-08-23 22:21:13 --> URI Class Initialized
INFO - 2016-08-23 22:21:13 --> Router Class Initialized
INFO - 2016-08-23 22:21:13 --> Output Class Initialized
INFO - 2016-08-23 22:21:13 --> Security Class Initialized
DEBUG - 2016-08-23 22:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:21:13 --> Input Class Initialized
INFO - 2016-08-23 22:21:13 --> Language Class Initialized
INFO - 2016-08-23 22:21:13 --> Loader Class Initialized
INFO - 2016-08-23 22:21:13 --> Helper loaded: url_helper
INFO - 2016-08-23 22:21:13 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:21:13 --> Helper loaded: html_helper
INFO - 2016-08-23 22:21:13 --> Helper loaded: form_helper
INFO - 2016-08-23 22:21:13 --> Helper loaded: file_helper
INFO - 2016-08-23 22:21:13 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:21:13 --> Database Driver Class Initialized
INFO - 2016-08-23 22:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:21:13 --> Form Validation Class Initialized
INFO - 2016-08-23 22:21:13 --> Email Class Initialized
INFO - 2016-08-23 22:21:13 --> Controller Class Initialized
DEBUG - 2016-08-23 22:21:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:21:13 --> Model Class Initialized
INFO - 2016-08-23 22:21:13 --> Model Class Initialized
INFO - 2016-08-23 22:21:13 --> Model Class Initialized
INFO - 2016-08-23 22:21:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:21:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:21:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:21:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:21:13 --> Final output sent to browser
DEBUG - 2016-08-23 22:21:13 --> Total execution time: 0.4188
INFO - 2016-08-23 22:21:18 --> Config Class Initialized
INFO - 2016-08-23 22:21:18 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:21:18 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:21:18 --> Utf8 Class Initialized
INFO - 2016-08-23 22:21:18 --> URI Class Initialized
INFO - 2016-08-23 22:21:18 --> Router Class Initialized
INFO - 2016-08-23 22:21:18 --> Output Class Initialized
INFO - 2016-08-23 22:21:18 --> Security Class Initialized
DEBUG - 2016-08-23 22:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:21:18 --> Input Class Initialized
INFO - 2016-08-23 22:21:18 --> Language Class Initialized
INFO - 2016-08-23 22:21:18 --> Loader Class Initialized
INFO - 2016-08-23 22:21:18 --> Helper loaded: url_helper
INFO - 2016-08-23 22:21:18 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:21:18 --> Helper loaded: html_helper
INFO - 2016-08-23 22:21:18 --> Helper loaded: form_helper
INFO - 2016-08-23 22:21:18 --> Helper loaded: file_helper
INFO - 2016-08-23 22:21:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:21:18 --> Database Driver Class Initialized
INFO - 2016-08-23 22:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:21:18 --> Form Validation Class Initialized
INFO - 2016-08-23 22:21:18 --> Email Class Initialized
INFO - 2016-08-23 22:21:18 --> Controller Class Initialized
DEBUG - 2016-08-23 22:21:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:21:18 --> Model Class Initialized
INFO - 2016-08-23 22:21:18 --> Model Class Initialized
INFO - 2016-08-23 22:21:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:21:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:21:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:21:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:21:18 --> Final output sent to browser
DEBUG - 2016-08-23 22:21:18 --> Total execution time: 0.4087
INFO - 2016-08-23 22:22:24 --> Config Class Initialized
INFO - 2016-08-23 22:22:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:22:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:22:24 --> Utf8 Class Initialized
INFO - 2016-08-23 22:22:24 --> URI Class Initialized
INFO - 2016-08-23 22:22:24 --> Router Class Initialized
INFO - 2016-08-23 22:22:24 --> Output Class Initialized
INFO - 2016-08-23 22:22:24 --> Security Class Initialized
DEBUG - 2016-08-23 22:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:22:24 --> Input Class Initialized
INFO - 2016-08-23 22:22:24 --> Language Class Initialized
INFO - 2016-08-23 22:22:24 --> Loader Class Initialized
INFO - 2016-08-23 22:22:24 --> Helper loaded: url_helper
INFO - 2016-08-23 22:22:24 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:22:24 --> Helper loaded: html_helper
INFO - 2016-08-23 22:22:24 --> Helper loaded: form_helper
INFO - 2016-08-23 22:22:24 --> Helper loaded: file_helper
INFO - 2016-08-23 22:22:24 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:22:24 --> Database Driver Class Initialized
INFO - 2016-08-23 22:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:22:24 --> Form Validation Class Initialized
INFO - 2016-08-23 22:22:24 --> Email Class Initialized
INFO - 2016-08-23 22:22:24 --> Controller Class Initialized
DEBUG - 2016-08-23 22:22:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:22:24 --> Model Class Initialized
INFO - 2016-08-23 22:22:24 --> Model Class Initialized
INFO - 2016-08-23 22:22:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:22:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:22:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:22:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:22:24 --> Final output sent to browser
DEBUG - 2016-08-23 22:22:24 --> Total execution time: 0.6470
INFO - 2016-08-23 22:22:26 --> Config Class Initialized
INFO - 2016-08-23 22:22:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:22:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:22:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:22:26 --> URI Class Initialized
INFO - 2016-08-23 22:22:26 --> Router Class Initialized
INFO - 2016-08-23 22:22:26 --> Output Class Initialized
INFO - 2016-08-23 22:22:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:22:26 --> Input Class Initialized
INFO - 2016-08-23 22:22:26 --> Language Class Initialized
INFO - 2016-08-23 22:22:26 --> Loader Class Initialized
INFO - 2016-08-23 22:22:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:22:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:22:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:22:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:22:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:22:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:22:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:22:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:22:27 --> Email Class Initialized
INFO - 2016-08-23 22:22:27 --> Controller Class Initialized
DEBUG - 2016-08-23 22:22:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:22:27 --> Model Class Initialized
INFO - 2016-08-23 22:22:27 --> Model Class Initialized
INFO - 2016-08-23 22:22:27 --> Model Class Initialized
INFO - 2016-08-23 22:22:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:22:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:22:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:22:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:22:27 --> Final output sent to browser
DEBUG - 2016-08-23 22:22:27 --> Total execution time: 0.5062
INFO - 2016-08-23 22:23:06 --> Config Class Initialized
INFO - 2016-08-23 22:23:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:06 --> URI Class Initialized
INFO - 2016-08-23 22:23:06 --> Router Class Initialized
INFO - 2016-08-23 22:23:06 --> Output Class Initialized
INFO - 2016-08-23 22:23:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:06 --> Input Class Initialized
INFO - 2016-08-23 22:23:06 --> Language Class Initialized
INFO - 2016-08-23 22:23:06 --> Loader Class Initialized
INFO - 2016-08-23 22:23:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:06 --> Email Class Initialized
INFO - 2016-08-23 22:23:06 --> Controller Class Initialized
DEBUG - 2016-08-23 22:23:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:23:06 --> Model Class Initialized
INFO - 2016-08-23 22:23:07 --> Model Class Initialized
INFO - 2016-08-23 22:23:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:23:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:07 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:07 --> Total execution time: 0.4110
INFO - 2016-08-23 22:23:09 --> Config Class Initialized
INFO - 2016-08-23 22:23:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:09 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:09 --> URI Class Initialized
INFO - 2016-08-23 22:23:09 --> Router Class Initialized
INFO - 2016-08-23 22:23:09 --> Output Class Initialized
INFO - 2016-08-23 22:23:10 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:10 --> Input Class Initialized
INFO - 2016-08-23 22:23:10 --> Language Class Initialized
INFO - 2016-08-23 22:23:10 --> Loader Class Initialized
INFO - 2016-08-23 22:23:10 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:10 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:10 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:10 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:10 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:10 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:10 --> Email Class Initialized
INFO - 2016-08-23 22:23:10 --> Controller Class Initialized
DEBUG - 2016-08-23 22:23:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:23:10 --> Model Class Initialized
INFO - 2016-08-23 22:23:10 --> Model Class Initialized
INFO - 2016-08-23 22:23:10 --> Model Class Initialized
INFO - 2016-08-23 22:23:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:23:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:10 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:10 --> Total execution time: 0.5723
INFO - 2016-08-23 22:23:17 --> Config Class Initialized
INFO - 2016-08-23 22:23:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:17 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:17 --> URI Class Initialized
INFO - 2016-08-23 22:23:17 --> Router Class Initialized
INFO - 2016-08-23 22:23:17 --> Output Class Initialized
INFO - 2016-08-23 22:23:17 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:17 --> Input Class Initialized
INFO - 2016-08-23 22:23:17 --> Language Class Initialized
INFO - 2016-08-23 22:23:17 --> Loader Class Initialized
INFO - 2016-08-23 22:23:17 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:17 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:17 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:18 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:18 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:18 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:18 --> Email Class Initialized
INFO - 2016-08-23 22:23:18 --> Controller Class Initialized
INFO - 2016-08-23 22:23:18 --> Model Class Initialized
INFO - 2016-08-23 22:23:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:23:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:18 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:18 --> Total execution time: 0.6481
INFO - 2016-08-23 22:23:22 --> Config Class Initialized
INFO - 2016-08-23 22:23:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:22 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:22 --> URI Class Initialized
INFO - 2016-08-23 22:23:22 --> Router Class Initialized
INFO - 2016-08-23 22:23:22 --> Output Class Initialized
INFO - 2016-08-23 22:23:22 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:22 --> Input Class Initialized
INFO - 2016-08-23 22:23:22 --> Language Class Initialized
INFO - 2016-08-23 22:23:22 --> Loader Class Initialized
INFO - 2016-08-23 22:23:22 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:22 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:22 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:22 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:22 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:22 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:22 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:22 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:22 --> Email Class Initialized
INFO - 2016-08-23 22:23:22 --> Controller Class Initialized
INFO - 2016-08-23 22:23:22 --> Model Class Initialized
INFO - 2016-08-23 22:23:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-23 22:23:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:22 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:22 --> Total execution time: 0.4507
INFO - 2016-08-23 22:23:24 --> Config Class Initialized
INFO - 2016-08-23 22:23:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:24 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:24 --> URI Class Initialized
INFO - 2016-08-23 22:23:24 --> Router Class Initialized
INFO - 2016-08-23 22:23:24 --> Output Class Initialized
INFO - 2016-08-23 22:23:24 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:25 --> Input Class Initialized
INFO - 2016-08-23 22:23:25 --> Language Class Initialized
INFO - 2016-08-23 22:23:25 --> Loader Class Initialized
INFO - 2016-08-23 22:23:25 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:25 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:25 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:25 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:25 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:25 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:25 --> Email Class Initialized
INFO - 2016-08-23 22:23:25 --> Controller Class Initialized
INFO - 2016-08-23 22:23:25 --> Model Class Initialized
INFO - 2016-08-23 22:23:25 --> Model Class Initialized
INFO - 2016-08-23 22:23:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:23:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:25 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:25 --> Total execution time: 0.5198
INFO - 2016-08-23 22:23:58 --> Config Class Initialized
INFO - 2016-08-23 22:23:58 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:23:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:23:58 --> Utf8 Class Initialized
INFO - 2016-08-23 22:23:58 --> URI Class Initialized
INFO - 2016-08-23 22:23:58 --> Router Class Initialized
INFO - 2016-08-23 22:23:58 --> Output Class Initialized
INFO - 2016-08-23 22:23:58 --> Security Class Initialized
DEBUG - 2016-08-23 22:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:23:58 --> Input Class Initialized
INFO - 2016-08-23 22:23:58 --> Language Class Initialized
INFO - 2016-08-23 22:23:58 --> Loader Class Initialized
INFO - 2016-08-23 22:23:58 --> Helper loaded: url_helper
INFO - 2016-08-23 22:23:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:23:58 --> Helper loaded: html_helper
INFO - 2016-08-23 22:23:58 --> Helper loaded: form_helper
INFO - 2016-08-23 22:23:58 --> Helper loaded: file_helper
INFO - 2016-08-23 22:23:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:23:58 --> Database Driver Class Initialized
INFO - 2016-08-23 22:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:23:58 --> Form Validation Class Initialized
INFO - 2016-08-23 22:23:58 --> Email Class Initialized
INFO - 2016-08-23 22:23:58 --> Controller Class Initialized
DEBUG - 2016-08-23 22:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:23:58 --> Model Class Initialized
INFO - 2016-08-23 22:23:58 --> Model Class Initialized
INFO - 2016-08-23 22:23:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:23:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:23:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:23:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:23:59 --> Final output sent to browser
DEBUG - 2016-08-23 22:23:59 --> Total execution time: 0.4889
INFO - 2016-08-23 22:24:01 --> Config Class Initialized
INFO - 2016-08-23 22:24:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:24:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:24:01 --> Utf8 Class Initialized
INFO - 2016-08-23 22:24:01 --> URI Class Initialized
INFO - 2016-08-23 22:24:01 --> Router Class Initialized
INFO - 2016-08-23 22:24:01 --> Output Class Initialized
INFO - 2016-08-23 22:24:01 --> Security Class Initialized
DEBUG - 2016-08-23 22:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:24:01 --> Input Class Initialized
INFO - 2016-08-23 22:24:01 --> Language Class Initialized
INFO - 2016-08-23 22:24:01 --> Loader Class Initialized
INFO - 2016-08-23 22:24:01 --> Helper loaded: url_helper
INFO - 2016-08-23 22:24:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:24:01 --> Helper loaded: html_helper
INFO - 2016-08-23 22:24:01 --> Helper loaded: form_helper
INFO - 2016-08-23 22:24:01 --> Helper loaded: file_helper
INFO - 2016-08-23 22:24:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:24:01 --> Database Driver Class Initialized
INFO - 2016-08-23 22:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:24:01 --> Form Validation Class Initialized
INFO - 2016-08-23 22:24:01 --> Email Class Initialized
INFO - 2016-08-23 22:24:01 --> Controller Class Initialized
DEBUG - 2016-08-23 22:24:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:24:01 --> Model Class Initialized
INFO - 2016-08-23 22:24:01 --> Model Class Initialized
INFO - 2016-08-23 22:24:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:24:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:24:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:24:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:24:01 --> Final output sent to browser
DEBUG - 2016-08-23 22:24:01 --> Total execution time: 0.4407
INFO - 2016-08-23 22:24:06 --> Config Class Initialized
INFO - 2016-08-23 22:24:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:24:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:24:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:24:06 --> URI Class Initialized
INFO - 2016-08-23 22:24:06 --> Router Class Initialized
INFO - 2016-08-23 22:24:06 --> Output Class Initialized
INFO - 2016-08-23 22:24:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:24:06 --> Input Class Initialized
INFO - 2016-08-23 22:24:06 --> Language Class Initialized
INFO - 2016-08-23 22:24:06 --> Loader Class Initialized
INFO - 2016-08-23 22:24:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:24:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:24:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:24:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:24:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:24:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:24:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:24:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:24:06 --> Email Class Initialized
INFO - 2016-08-23 22:24:06 --> Controller Class Initialized
DEBUG - 2016-08-23 22:24:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:24:06 --> Model Class Initialized
INFO - 2016-08-23 22:24:06 --> Model Class Initialized
INFO - 2016-08-23 22:24:06 --> Model Class Initialized
INFO - 2016-08-23 22:24:06 --> Model Class Initialized
INFO - 2016-08-23 22:24:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:24:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:24:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:24:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:24:06 --> Final output sent to browser
DEBUG - 2016-08-23 22:24:06 --> Total execution time: 0.4349
INFO - 2016-08-23 22:25:07 --> Config Class Initialized
INFO - 2016-08-23 22:25:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:25:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:25:07 --> Utf8 Class Initialized
INFO - 2016-08-23 22:25:07 --> URI Class Initialized
INFO - 2016-08-23 22:25:07 --> Router Class Initialized
INFO - 2016-08-23 22:25:07 --> Output Class Initialized
INFO - 2016-08-23 22:25:07 --> Security Class Initialized
DEBUG - 2016-08-23 22:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:25:07 --> Input Class Initialized
INFO - 2016-08-23 22:25:07 --> Language Class Initialized
INFO - 2016-08-23 22:25:07 --> Loader Class Initialized
INFO - 2016-08-23 22:25:07 --> Helper loaded: url_helper
INFO - 2016-08-23 22:25:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:25:07 --> Helper loaded: html_helper
INFO - 2016-08-23 22:25:07 --> Helper loaded: form_helper
INFO - 2016-08-23 22:25:07 --> Helper loaded: file_helper
INFO - 2016-08-23 22:25:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:25:07 --> Database Driver Class Initialized
INFO - 2016-08-23 22:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:25:07 --> Form Validation Class Initialized
INFO - 2016-08-23 22:25:07 --> Email Class Initialized
INFO - 2016-08-23 22:25:07 --> Controller Class Initialized
DEBUG - 2016-08-23 22:25:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:25:07 --> Model Class Initialized
INFO - 2016-08-23 22:25:07 --> Model Class Initialized
INFO - 2016-08-23 22:25:07 --> Model Class Initialized
INFO - 2016-08-23 22:25:07 --> Model Class Initialized
INFO - 2016-08-23 22:25:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:25:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:25:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:25:07 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:25:07 --> Final output sent to browser
DEBUG - 2016-08-23 22:25:07 --> Total execution time: 0.5592
INFO - 2016-08-23 22:25:45 --> Config Class Initialized
INFO - 2016-08-23 22:25:45 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:25:45 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:25:45 --> Utf8 Class Initialized
INFO - 2016-08-23 22:25:45 --> URI Class Initialized
INFO - 2016-08-23 22:25:45 --> Router Class Initialized
INFO - 2016-08-23 22:25:45 --> Output Class Initialized
INFO - 2016-08-23 22:25:45 --> Security Class Initialized
DEBUG - 2016-08-23 22:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:25:45 --> Input Class Initialized
INFO - 2016-08-23 22:25:45 --> Language Class Initialized
INFO - 2016-08-23 22:25:45 --> Loader Class Initialized
INFO - 2016-08-23 22:25:45 --> Helper loaded: url_helper
INFO - 2016-08-23 22:25:45 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:25:45 --> Helper loaded: html_helper
INFO - 2016-08-23 22:25:45 --> Helper loaded: form_helper
INFO - 2016-08-23 22:25:45 --> Helper loaded: file_helper
INFO - 2016-08-23 22:25:45 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:25:45 --> Database Driver Class Initialized
INFO - 2016-08-23 22:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:25:45 --> Form Validation Class Initialized
INFO - 2016-08-23 22:25:45 --> Email Class Initialized
INFO - 2016-08-23 22:25:45 --> Controller Class Initialized
DEBUG - 2016-08-23 22:25:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:25:45 --> Model Class Initialized
INFO - 2016-08-23 22:25:45 --> Model Class Initialized
INFO - 2016-08-23 22:25:45 --> Model Class Initialized
INFO - 2016-08-23 22:25:45 --> Model Class Initialized
INFO - 2016-08-23 22:25:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:25:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:25:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:25:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:25:45 --> Final output sent to browser
DEBUG - 2016-08-23 22:25:45 --> Total execution time: 0.4506
INFO - 2016-08-23 22:25:58 --> Config Class Initialized
INFO - 2016-08-23 22:25:58 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:25:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:25:58 --> Utf8 Class Initialized
INFO - 2016-08-23 22:25:58 --> URI Class Initialized
INFO - 2016-08-23 22:25:58 --> Router Class Initialized
INFO - 2016-08-23 22:25:58 --> Output Class Initialized
INFO - 2016-08-23 22:25:58 --> Security Class Initialized
DEBUG - 2016-08-23 22:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:25:58 --> Input Class Initialized
INFO - 2016-08-23 22:25:58 --> Language Class Initialized
INFO - 2016-08-23 22:25:58 --> Loader Class Initialized
INFO - 2016-08-23 22:25:58 --> Helper loaded: url_helper
INFO - 2016-08-23 22:25:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:25:58 --> Helper loaded: html_helper
INFO - 2016-08-23 22:25:58 --> Helper loaded: form_helper
INFO - 2016-08-23 22:25:58 --> Helper loaded: file_helper
INFO - 2016-08-23 22:25:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:25:58 --> Database Driver Class Initialized
INFO - 2016-08-23 22:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:25:58 --> Form Validation Class Initialized
INFO - 2016-08-23 22:25:58 --> Email Class Initialized
INFO - 2016-08-23 22:25:58 --> Controller Class Initialized
DEBUG - 2016-08-23 22:25:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:25:58 --> Model Class Initialized
INFO - 2016-08-23 22:25:58 --> Model Class Initialized
INFO - 2016-08-23 22:25:58 --> Model Class Initialized
INFO - 2016-08-23 22:25:58 --> Model Class Initialized
INFO - 2016-08-23 22:25:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:25:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:25:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:25:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:25:58 --> Final output sent to browser
DEBUG - 2016-08-23 22:25:58 --> Total execution time: 0.4566
INFO - 2016-08-23 22:26:12 --> Config Class Initialized
INFO - 2016-08-23 22:26:12 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:26:12 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:26:12 --> Utf8 Class Initialized
INFO - 2016-08-23 22:26:12 --> URI Class Initialized
INFO - 2016-08-23 22:26:12 --> Router Class Initialized
INFO - 2016-08-23 22:26:12 --> Output Class Initialized
INFO - 2016-08-23 22:26:12 --> Security Class Initialized
DEBUG - 2016-08-23 22:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:26:12 --> Input Class Initialized
INFO - 2016-08-23 22:26:12 --> Language Class Initialized
INFO - 2016-08-23 22:26:12 --> Loader Class Initialized
INFO - 2016-08-23 22:26:12 --> Helper loaded: url_helper
INFO - 2016-08-23 22:26:12 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:26:12 --> Helper loaded: html_helper
INFO - 2016-08-23 22:26:12 --> Helper loaded: form_helper
INFO - 2016-08-23 22:26:12 --> Helper loaded: file_helper
INFO - 2016-08-23 22:26:12 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:26:12 --> Database Driver Class Initialized
INFO - 2016-08-23 22:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:26:12 --> Form Validation Class Initialized
INFO - 2016-08-23 22:26:12 --> Email Class Initialized
INFO - 2016-08-23 22:26:12 --> Controller Class Initialized
INFO - 2016-08-23 22:26:12 --> Model Class Initialized
INFO - 2016-08-23 22:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:26:12 --> Final output sent to browser
DEBUG - 2016-08-23 22:26:12 --> Total execution time: 0.4180
INFO - 2016-08-23 22:27:32 --> Config Class Initialized
INFO - 2016-08-23 22:27:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:27:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:27:32 --> Utf8 Class Initialized
INFO - 2016-08-23 22:27:32 --> URI Class Initialized
INFO - 2016-08-23 22:27:33 --> Router Class Initialized
INFO - 2016-08-23 22:27:33 --> Output Class Initialized
INFO - 2016-08-23 22:27:33 --> Security Class Initialized
DEBUG - 2016-08-23 22:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:27:33 --> Input Class Initialized
INFO - 2016-08-23 22:27:33 --> Language Class Initialized
INFO - 2016-08-23 22:27:33 --> Loader Class Initialized
INFO - 2016-08-23 22:27:33 --> Helper loaded: url_helper
INFO - 2016-08-23 22:27:33 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:27:33 --> Helper loaded: html_helper
INFO - 2016-08-23 22:27:33 --> Helper loaded: form_helper
INFO - 2016-08-23 22:27:33 --> Helper loaded: file_helper
INFO - 2016-08-23 22:27:33 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:27:33 --> Database Driver Class Initialized
INFO - 2016-08-23 22:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:27:33 --> Form Validation Class Initialized
INFO - 2016-08-23 22:27:33 --> Email Class Initialized
INFO - 2016-08-23 22:27:33 --> Controller Class Initialized
DEBUG - 2016-08-23 22:27:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:27:33 --> Model Class Initialized
INFO - 2016-08-23 22:27:33 --> Model Class Initialized
INFO - 2016-08-23 22:27:33 --> Model Class Initialized
INFO - 2016-08-23 22:27:33 --> Model Class Initialized
INFO - 2016-08-23 22:27:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:27:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:27:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:27:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:27:33 --> Final output sent to browser
DEBUG - 2016-08-23 22:27:33 --> Total execution time: 0.4641
INFO - 2016-08-23 22:28:03 --> Config Class Initialized
INFO - 2016-08-23 22:28:03 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:03 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:03 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:03 --> URI Class Initialized
INFO - 2016-08-23 22:28:03 --> Router Class Initialized
INFO - 2016-08-23 22:28:03 --> Output Class Initialized
INFO - 2016-08-23 22:28:03 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:03 --> Input Class Initialized
INFO - 2016-08-23 22:28:03 --> Language Class Initialized
INFO - 2016-08-23 22:28:03 --> Loader Class Initialized
INFO - 2016-08-23 22:28:03 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:03 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:03 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:03 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:03 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:03 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:03 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:03 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:03 --> Email Class Initialized
INFO - 2016-08-23 22:28:03 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:03 --> Model Class Initialized
INFO - 2016-08-23 22:28:03 --> Model Class Initialized
INFO - 2016-08-23 22:28:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:28:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:03 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:03 --> Total execution time: 0.4218
INFO - 2016-08-23 22:28:06 --> Config Class Initialized
INFO - 2016-08-23 22:28:06 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:06 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:06 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:06 --> URI Class Initialized
INFO - 2016-08-23 22:28:06 --> Router Class Initialized
INFO - 2016-08-23 22:28:06 --> Output Class Initialized
INFO - 2016-08-23 22:28:06 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:06 --> Input Class Initialized
INFO - 2016-08-23 22:28:06 --> Language Class Initialized
INFO - 2016-08-23 22:28:06 --> Loader Class Initialized
INFO - 2016-08-23 22:28:06 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:06 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:06 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:06 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:06 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:06 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:06 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:06 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:06 --> Email Class Initialized
INFO - 2016-08-23 22:28:06 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:06 --> Model Class Initialized
INFO - 2016-08-23 22:28:06 --> Model Class Initialized
INFO - 2016-08-23 22:28:06 --> Model Class Initialized
INFO - 2016-08-23 22:28:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:28:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:06 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:06 --> Total execution time: 0.4423
INFO - 2016-08-23 22:28:10 --> Config Class Initialized
INFO - 2016-08-23 22:28:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:10 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:10 --> URI Class Initialized
INFO - 2016-08-23 22:28:10 --> Router Class Initialized
INFO - 2016-08-23 22:28:10 --> Output Class Initialized
INFO - 2016-08-23 22:28:10 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:10 --> Input Class Initialized
INFO - 2016-08-23 22:28:10 --> Language Class Initialized
INFO - 2016-08-23 22:28:10 --> Loader Class Initialized
INFO - 2016-08-23 22:28:10 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:10 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:10 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:10 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:10 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:10 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:10 --> Email Class Initialized
INFO - 2016-08-23 22:28:10 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:10 --> Model Class Initialized
INFO - 2016-08-23 22:28:10 --> Model Class Initialized
INFO - 2016-08-23 22:28:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:28:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:11 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:11 --> Total execution time: 0.4311
INFO - 2016-08-23 22:28:16 --> Config Class Initialized
INFO - 2016-08-23 22:28:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:16 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:16 --> URI Class Initialized
INFO - 2016-08-23 22:28:16 --> Router Class Initialized
INFO - 2016-08-23 22:28:16 --> Output Class Initialized
INFO - 2016-08-23 22:28:16 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:16 --> Input Class Initialized
INFO - 2016-08-23 22:28:16 --> Language Class Initialized
INFO - 2016-08-23 22:28:16 --> Loader Class Initialized
INFO - 2016-08-23 22:28:16 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:16 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:16 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:16 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:16 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:16 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:16 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:16 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:16 --> Email Class Initialized
INFO - 2016-08-23 22:28:16 --> Controller Class Initialized
INFO - 2016-08-23 22:28:17 --> Model Class Initialized
INFO - 2016-08-23 22:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:28:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:17 --> Total execution time: 0.5834
INFO - 2016-08-23 22:28:21 --> Config Class Initialized
INFO - 2016-08-23 22:28:21 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:21 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:21 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:21 --> URI Class Initialized
INFO - 2016-08-23 22:28:21 --> Router Class Initialized
INFO - 2016-08-23 22:28:21 --> Output Class Initialized
INFO - 2016-08-23 22:28:21 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:21 --> Input Class Initialized
INFO - 2016-08-23 22:28:21 --> Language Class Initialized
INFO - 2016-08-23 22:28:21 --> Loader Class Initialized
INFO - 2016-08-23 22:28:21 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:21 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:21 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:21 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:21 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:21 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:21 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:21 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:21 --> Email Class Initialized
INFO - 2016-08-23 22:28:21 --> Controller Class Initialized
INFO - 2016-08-23 22:28:21 --> Model Class Initialized
INFO - 2016-08-23 22:28:21 --> Model Class Initialized
INFO - 2016-08-23 22:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:28:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:21 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:21 --> Total execution time: 0.4211
INFO - 2016-08-23 22:28:25 --> Config Class Initialized
INFO - 2016-08-23 22:28:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:25 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:25 --> URI Class Initialized
INFO - 2016-08-23 22:28:25 --> Router Class Initialized
INFO - 2016-08-23 22:28:25 --> Output Class Initialized
INFO - 2016-08-23 22:28:25 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:25 --> Input Class Initialized
INFO - 2016-08-23 22:28:25 --> Language Class Initialized
INFO - 2016-08-23 22:28:25 --> Loader Class Initialized
INFO - 2016-08-23 22:28:25 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:25 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:25 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:25 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:25 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:25 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:25 --> Email Class Initialized
INFO - 2016-08-23 22:28:25 --> Controller Class Initialized
INFO - 2016-08-23 22:28:25 --> Model Class Initialized
INFO - 2016-08-23 22:28:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:28:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:25 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:25 --> Total execution time: 0.4104
INFO - 2016-08-23 22:28:27 --> Config Class Initialized
INFO - 2016-08-23 22:28:27 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:27 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:27 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:27 --> URI Class Initialized
INFO - 2016-08-23 22:28:27 --> Router Class Initialized
INFO - 2016-08-23 22:28:27 --> Output Class Initialized
INFO - 2016-08-23 22:28:27 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:27 --> Input Class Initialized
INFO - 2016-08-23 22:28:27 --> Language Class Initialized
INFO - 2016-08-23 22:28:27 --> Loader Class Initialized
INFO - 2016-08-23 22:28:27 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:28 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:28 --> Email Class Initialized
INFO - 2016-08-23 22:28:28 --> Controller Class Initialized
INFO - 2016-08-23 22:28:28 --> Model Class Initialized
INFO - 2016-08-23 22:28:28 --> Model Class Initialized
DEBUG - 2016-08-23 22:28:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:28:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:28 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:28 --> Total execution time: 0.4424
INFO - 2016-08-23 22:28:32 --> Config Class Initialized
INFO - 2016-08-23 22:28:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:32 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:32 --> URI Class Initialized
INFO - 2016-08-23 22:28:32 --> Router Class Initialized
INFO - 2016-08-23 22:28:32 --> Output Class Initialized
INFO - 2016-08-23 22:28:32 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:32 --> Input Class Initialized
INFO - 2016-08-23 22:28:32 --> Language Class Initialized
INFO - 2016-08-23 22:28:32 --> Loader Class Initialized
INFO - 2016-08-23 22:28:32 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:32 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:32 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:32 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:32 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:32 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:32 --> Email Class Initialized
INFO - 2016-08-23 22:28:32 --> Controller Class Initialized
INFO - 2016-08-23 22:28:32 --> Model Class Initialized
INFO - 2016-08-23 22:28:32 --> Model Class Initialized
DEBUG - 2016-08-23 22:28:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:28:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:32 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:32 --> Total execution time: 0.4271
INFO - 2016-08-23 22:28:35 --> Config Class Initialized
INFO - 2016-08-23 22:28:35 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:35 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:35 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:35 --> URI Class Initialized
INFO - 2016-08-23 22:28:35 --> Router Class Initialized
INFO - 2016-08-23 22:28:35 --> Output Class Initialized
INFO - 2016-08-23 22:28:35 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:35 --> Input Class Initialized
INFO - 2016-08-23 22:28:35 --> Language Class Initialized
INFO - 2016-08-23 22:28:35 --> Loader Class Initialized
INFO - 2016-08-23 22:28:35 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:35 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:35 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:35 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:35 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:35 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:35 --> Email Class Initialized
INFO - 2016-08-23 22:28:35 --> Controller Class Initialized
INFO - 2016-08-23 22:28:35 --> Model Class Initialized
INFO - 2016-08-23 22:28:35 --> Model Class Initialized
DEBUG - 2016-08-23 22:28:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:28:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:35 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:35 --> Total execution time: 0.4482
INFO - 2016-08-23 22:28:37 --> Config Class Initialized
INFO - 2016-08-23 22:28:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:37 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:37 --> URI Class Initialized
INFO - 2016-08-23 22:28:37 --> Router Class Initialized
INFO - 2016-08-23 22:28:37 --> Output Class Initialized
INFO - 2016-08-23 22:28:37 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:37 --> Input Class Initialized
INFO - 2016-08-23 22:28:37 --> Language Class Initialized
INFO - 2016-08-23 22:28:38 --> Loader Class Initialized
INFO - 2016-08-23 22:28:38 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:38 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:38 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:38 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:38 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:38 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:38 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:38 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:38 --> Email Class Initialized
INFO - 2016-08-23 22:28:38 --> Controller Class Initialized
INFO - 2016-08-23 22:28:38 --> Model Class Initialized
INFO - 2016-08-23 22:28:38 --> Model Class Initialized
DEBUG - 2016-08-23 22:28:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:28:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:38 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:38 --> Total execution time: 0.4400
INFO - 2016-08-23 22:28:40 --> Config Class Initialized
INFO - 2016-08-23 22:28:40 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:40 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:40 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:40 --> URI Class Initialized
INFO - 2016-08-23 22:28:40 --> Router Class Initialized
INFO - 2016-08-23 22:28:41 --> Output Class Initialized
INFO - 2016-08-23 22:28:41 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:41 --> Input Class Initialized
INFO - 2016-08-23 22:28:41 --> Language Class Initialized
INFO - 2016-08-23 22:28:41 --> Loader Class Initialized
INFO - 2016-08-23 22:28:41 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:41 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:41 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:41 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:41 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:41 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:41 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:41 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:41 --> Email Class Initialized
INFO - 2016-08-23 22:28:41 --> Controller Class Initialized
INFO - 2016-08-23 22:28:41 --> Model Class Initialized
INFO - 2016-08-23 22:28:41 --> Model Class Initialized
DEBUG - 2016-08-23 22:28:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:28:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:41 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:41 --> Total execution time: 0.4297
INFO - 2016-08-23 22:28:44 --> Config Class Initialized
INFO - 2016-08-23 22:28:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:44 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:44 --> URI Class Initialized
INFO - 2016-08-23 22:28:44 --> Router Class Initialized
INFO - 2016-08-23 22:28:44 --> Output Class Initialized
INFO - 2016-08-23 22:28:44 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:44 --> Input Class Initialized
INFO - 2016-08-23 22:28:44 --> Language Class Initialized
INFO - 2016-08-23 22:28:44 --> Loader Class Initialized
INFO - 2016-08-23 22:28:44 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:44 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:44 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:44 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:44 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:44 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:44 --> Email Class Initialized
INFO - 2016-08-23 22:28:44 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:44 --> Model Class Initialized
INFO - 2016-08-23 22:28:44 --> Model Class Initialized
INFO - 2016-08-23 22:28:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:28:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:44 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:44 --> Total execution time: 0.4827
INFO - 2016-08-23 22:28:50 --> Config Class Initialized
INFO - 2016-08-23 22:28:50 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:50 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:50 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:50 --> URI Class Initialized
INFO - 2016-08-23 22:28:50 --> Router Class Initialized
INFO - 2016-08-23 22:28:50 --> Output Class Initialized
INFO - 2016-08-23 22:28:50 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:50 --> Input Class Initialized
INFO - 2016-08-23 22:28:50 --> Language Class Initialized
INFO - 2016-08-23 22:28:50 --> Loader Class Initialized
INFO - 2016-08-23 22:28:50 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:50 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:50 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:50 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:50 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:50 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:50 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:50 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:50 --> Email Class Initialized
INFO - 2016-08-23 22:28:50 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:50 --> Model Class Initialized
INFO - 2016-08-23 22:28:50 --> Model Class Initialized
INFO - 2016-08-23 22:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:28:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:51 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:51 --> Total execution time: 0.4630
INFO - 2016-08-23 22:28:54 --> Config Class Initialized
INFO - 2016-08-23 22:28:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:28:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:28:54 --> Utf8 Class Initialized
INFO - 2016-08-23 22:28:54 --> URI Class Initialized
INFO - 2016-08-23 22:28:54 --> Router Class Initialized
INFO - 2016-08-23 22:28:54 --> Output Class Initialized
INFO - 2016-08-23 22:28:54 --> Security Class Initialized
DEBUG - 2016-08-23 22:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:28:54 --> Input Class Initialized
INFO - 2016-08-23 22:28:54 --> Language Class Initialized
INFO - 2016-08-23 22:28:54 --> Loader Class Initialized
INFO - 2016-08-23 22:28:54 --> Helper loaded: url_helper
INFO - 2016-08-23 22:28:54 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:28:54 --> Helper loaded: html_helper
INFO - 2016-08-23 22:28:54 --> Helper loaded: form_helper
INFO - 2016-08-23 22:28:54 --> Helper loaded: file_helper
INFO - 2016-08-23 22:28:54 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:28:54 --> Database Driver Class Initialized
INFO - 2016-08-23 22:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:28:54 --> Form Validation Class Initialized
INFO - 2016-08-23 22:28:54 --> Email Class Initialized
INFO - 2016-08-23 22:28:54 --> Controller Class Initialized
DEBUG - 2016-08-23 22:28:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:28:54 --> Model Class Initialized
INFO - 2016-08-23 22:28:54 --> Model Class Initialized
INFO - 2016-08-23 22:28:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:28:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:28:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:28:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:28:55 --> Final output sent to browser
DEBUG - 2016-08-23 22:28:55 --> Total execution time: 0.5735
INFO - 2016-08-23 22:29:04 --> Config Class Initialized
INFO - 2016-08-23 22:29:04 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:29:04 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:29:04 --> Utf8 Class Initialized
INFO - 2016-08-23 22:29:04 --> URI Class Initialized
INFO - 2016-08-23 22:29:04 --> Router Class Initialized
INFO - 2016-08-23 22:29:04 --> Output Class Initialized
INFO - 2016-08-23 22:29:04 --> Security Class Initialized
DEBUG - 2016-08-23 22:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:29:04 --> Input Class Initialized
INFO - 2016-08-23 22:29:04 --> Language Class Initialized
INFO - 2016-08-23 22:29:04 --> Loader Class Initialized
INFO - 2016-08-23 22:29:04 --> Helper loaded: url_helper
INFO - 2016-08-23 22:29:04 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:29:04 --> Helper loaded: html_helper
INFO - 2016-08-23 22:29:04 --> Helper loaded: form_helper
INFO - 2016-08-23 22:29:04 --> Helper loaded: file_helper
INFO - 2016-08-23 22:29:04 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:29:04 --> Database Driver Class Initialized
INFO - 2016-08-23 22:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:29:04 --> Form Validation Class Initialized
INFO - 2016-08-23 22:29:04 --> Email Class Initialized
INFO - 2016-08-23 22:29:04 --> Controller Class Initialized
INFO - 2016-08-23 22:29:04 --> Model Class Initialized
INFO - 2016-08-23 22:29:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:29:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:29:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:29:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:29:04 --> Final output sent to browser
DEBUG - 2016-08-23 22:29:04 --> Total execution time: 0.4178
INFO - 2016-08-23 22:29:43 --> Config Class Initialized
INFO - 2016-08-23 22:29:43 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:29:43 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:29:43 --> Utf8 Class Initialized
INFO - 2016-08-23 22:29:43 --> URI Class Initialized
INFO - 2016-08-23 22:29:43 --> Router Class Initialized
INFO - 2016-08-23 22:29:43 --> Output Class Initialized
INFO - 2016-08-23 22:29:43 --> Security Class Initialized
DEBUG - 2016-08-23 22:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:29:43 --> Input Class Initialized
INFO - 2016-08-23 22:29:43 --> Language Class Initialized
INFO - 2016-08-23 22:29:43 --> Loader Class Initialized
INFO - 2016-08-23 22:29:43 --> Helper loaded: url_helper
INFO - 2016-08-23 22:29:43 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:29:43 --> Helper loaded: html_helper
INFO - 2016-08-23 22:29:43 --> Helper loaded: form_helper
INFO - 2016-08-23 22:29:43 --> Helper loaded: file_helper
INFO - 2016-08-23 22:29:43 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:29:43 --> Database Driver Class Initialized
INFO - 2016-08-23 22:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:29:43 --> Form Validation Class Initialized
INFO - 2016-08-23 22:29:44 --> Email Class Initialized
INFO - 2016-08-23 22:29:44 --> Controller Class Initialized
DEBUG - 2016-08-23 22:29:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:29:44 --> Model Class Initialized
INFO - 2016-08-23 22:29:44 --> Model Class Initialized
INFO - 2016-08-23 22:29:44 --> Model Class Initialized
INFO - 2016-08-23 22:29:44 --> Model Class Initialized
INFO - 2016-08-23 22:29:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:29:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:29:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:29:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:29:44 --> Final output sent to browser
DEBUG - 2016-08-23 22:29:44 --> Total execution time: 0.4874
INFO - 2016-08-23 22:30:16 --> Config Class Initialized
INFO - 2016-08-23 22:30:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:30:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:30:16 --> Utf8 Class Initialized
INFO - 2016-08-23 22:30:16 --> URI Class Initialized
INFO - 2016-08-23 22:30:16 --> Router Class Initialized
INFO - 2016-08-23 22:30:16 --> Output Class Initialized
INFO - 2016-08-23 22:30:17 --> Security Class Initialized
DEBUG - 2016-08-23 22:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:30:17 --> Input Class Initialized
INFO - 2016-08-23 22:30:17 --> Language Class Initialized
INFO - 2016-08-23 22:30:17 --> Loader Class Initialized
INFO - 2016-08-23 22:30:17 --> Helper loaded: url_helper
INFO - 2016-08-23 22:30:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:30:17 --> Helper loaded: html_helper
INFO - 2016-08-23 22:30:17 --> Helper loaded: form_helper
INFO - 2016-08-23 22:30:17 --> Helper loaded: file_helper
INFO - 2016-08-23 22:30:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:30:17 --> Database Driver Class Initialized
INFO - 2016-08-23 22:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:30:17 --> Form Validation Class Initialized
INFO - 2016-08-23 22:30:17 --> Email Class Initialized
INFO - 2016-08-23 22:30:17 --> Controller Class Initialized
DEBUG - 2016-08-23 22:30:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:30:17 --> Model Class Initialized
INFO - 2016-08-23 22:30:17 --> Model Class Initialized
INFO - 2016-08-23 22:30:17 --> Model Class Initialized
INFO - 2016-08-23 22:30:17 --> Model Class Initialized
INFO - 2016-08-23 22:30:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:30:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:30:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:30:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:30:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:30:17 --> Total execution time: 0.4969
INFO - 2016-08-23 22:30:32 --> Config Class Initialized
INFO - 2016-08-23 22:30:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:30:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:30:32 --> Utf8 Class Initialized
INFO - 2016-08-23 22:30:32 --> URI Class Initialized
INFO - 2016-08-23 22:30:32 --> Router Class Initialized
INFO - 2016-08-23 22:30:32 --> Output Class Initialized
INFO - 2016-08-23 22:30:32 --> Security Class Initialized
DEBUG - 2016-08-23 22:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:30:32 --> Input Class Initialized
INFO - 2016-08-23 22:30:32 --> Language Class Initialized
INFO - 2016-08-23 22:30:32 --> Loader Class Initialized
INFO - 2016-08-23 22:30:32 --> Helper loaded: url_helper
INFO - 2016-08-23 22:30:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:30:32 --> Helper loaded: html_helper
INFO - 2016-08-23 22:30:32 --> Helper loaded: form_helper
INFO - 2016-08-23 22:30:32 --> Helper loaded: file_helper
INFO - 2016-08-23 22:30:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:30:32 --> Database Driver Class Initialized
INFO - 2016-08-23 22:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:30:32 --> Form Validation Class Initialized
INFO - 2016-08-23 22:30:32 --> Email Class Initialized
INFO - 2016-08-23 22:30:32 --> Controller Class Initialized
INFO - 2016-08-23 22:30:32 --> Model Class Initialized
INFO - 2016-08-23 22:30:32 --> Model Class Initialized
INFO - 2016-08-23 22:30:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:30:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:30:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-23 22:30:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:30:33 --> Final output sent to browser
DEBUG - 2016-08-23 22:30:33 --> Total execution time: 0.6462
INFO - 2016-08-23 22:30:37 --> Config Class Initialized
INFO - 2016-08-23 22:30:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:30:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:30:37 --> Utf8 Class Initialized
INFO - 2016-08-23 22:30:37 --> URI Class Initialized
INFO - 2016-08-23 22:30:37 --> Router Class Initialized
INFO - 2016-08-23 22:30:37 --> Output Class Initialized
INFO - 2016-08-23 22:30:37 --> Security Class Initialized
DEBUG - 2016-08-23 22:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:30:37 --> Input Class Initialized
INFO - 2016-08-23 22:30:37 --> Language Class Initialized
INFO - 2016-08-23 22:30:37 --> Loader Class Initialized
INFO - 2016-08-23 22:30:37 --> Helper loaded: url_helper
INFO - 2016-08-23 22:30:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:30:37 --> Helper loaded: html_helper
INFO - 2016-08-23 22:30:37 --> Helper loaded: form_helper
INFO - 2016-08-23 22:30:37 --> Helper loaded: file_helper
INFO - 2016-08-23 22:30:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:30:37 --> Database Driver Class Initialized
INFO - 2016-08-23 22:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:30:37 --> Form Validation Class Initialized
INFO - 2016-08-23 22:30:37 --> Email Class Initialized
INFO - 2016-08-23 22:30:37 --> Controller Class Initialized
DEBUG - 2016-08-23 22:30:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:30:37 --> Model Class Initialized
INFO - 2016-08-23 22:30:37 --> Model Class Initialized
INFO - 2016-08-23 22:30:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:30:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:30:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:30:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:30:37 --> Final output sent to browser
DEBUG - 2016-08-23 22:30:37 --> Total execution time: 0.4528
INFO - 2016-08-23 22:30:41 --> Config Class Initialized
INFO - 2016-08-23 22:30:41 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:30:41 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:30:41 --> Utf8 Class Initialized
INFO - 2016-08-23 22:30:41 --> URI Class Initialized
INFO - 2016-08-23 22:30:41 --> Router Class Initialized
INFO - 2016-08-23 22:30:41 --> Output Class Initialized
INFO - 2016-08-23 22:30:41 --> Security Class Initialized
DEBUG - 2016-08-23 22:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:30:41 --> Input Class Initialized
INFO - 2016-08-23 22:30:41 --> Language Class Initialized
INFO - 2016-08-23 22:30:41 --> Loader Class Initialized
INFO - 2016-08-23 22:30:41 --> Helper loaded: url_helper
INFO - 2016-08-23 22:30:41 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:30:41 --> Helper loaded: html_helper
INFO - 2016-08-23 22:30:41 --> Helper loaded: form_helper
INFO - 2016-08-23 22:30:41 --> Helper loaded: file_helper
INFO - 2016-08-23 22:30:41 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:30:41 --> Database Driver Class Initialized
INFO - 2016-08-23 22:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:30:41 --> Form Validation Class Initialized
INFO - 2016-08-23 22:30:41 --> Email Class Initialized
INFO - 2016-08-23 22:30:41 --> Controller Class Initialized
DEBUG - 2016-08-23 22:30:41 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:30:41 --> Model Class Initialized
INFO - 2016-08-23 22:30:41 --> Model Class Initialized
INFO - 2016-08-23 22:30:41 --> Model Class Initialized
INFO - 2016-08-23 22:30:41 --> Model Class Initialized
INFO - 2016-08-23 22:30:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:30:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:30:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:30:41 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:30:41 --> Final output sent to browser
DEBUG - 2016-08-23 22:30:41 --> Total execution time: 0.5388
INFO - 2016-08-23 22:30:44 --> Config Class Initialized
INFO - 2016-08-23 22:30:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:30:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:30:44 --> Utf8 Class Initialized
INFO - 2016-08-23 22:30:44 --> URI Class Initialized
INFO - 2016-08-23 22:30:44 --> Router Class Initialized
INFO - 2016-08-23 22:30:44 --> Output Class Initialized
INFO - 2016-08-23 22:30:44 --> Security Class Initialized
DEBUG - 2016-08-23 22:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:30:44 --> Input Class Initialized
INFO - 2016-08-23 22:30:44 --> Language Class Initialized
INFO - 2016-08-23 22:30:44 --> Loader Class Initialized
INFO - 2016-08-23 22:30:44 --> Helper loaded: url_helper
INFO - 2016-08-23 22:30:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:30:44 --> Helper loaded: html_helper
INFO - 2016-08-23 22:30:44 --> Helper loaded: form_helper
INFO - 2016-08-23 22:30:44 --> Helper loaded: file_helper
INFO - 2016-08-23 22:30:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:30:44 --> Database Driver Class Initialized
INFO - 2016-08-23 22:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:30:44 --> Form Validation Class Initialized
INFO - 2016-08-23 22:30:44 --> Email Class Initialized
INFO - 2016-08-23 22:30:44 --> Controller Class Initialized
DEBUG - 2016-08-23 22:30:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:30:44 --> Model Class Initialized
INFO - 2016-08-23 22:30:44 --> Model Class Initialized
INFO - 2016-08-23 22:30:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:30:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:30:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:30:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:30:44 --> Final output sent to browser
DEBUG - 2016-08-23 22:30:44 --> Total execution time: 0.4608
INFO - 2016-08-23 22:31:32 --> Config Class Initialized
INFO - 2016-08-23 22:31:32 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:31:32 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:31:32 --> Utf8 Class Initialized
INFO - 2016-08-23 22:31:32 --> URI Class Initialized
INFO - 2016-08-23 22:31:32 --> Router Class Initialized
INFO - 2016-08-23 22:31:32 --> Output Class Initialized
INFO - 2016-08-23 22:31:32 --> Security Class Initialized
DEBUG - 2016-08-23 22:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:31:32 --> Input Class Initialized
INFO - 2016-08-23 22:31:32 --> Language Class Initialized
INFO - 2016-08-23 22:31:32 --> Loader Class Initialized
INFO - 2016-08-23 22:31:32 --> Helper loaded: url_helper
INFO - 2016-08-23 22:31:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:31:32 --> Helper loaded: html_helper
INFO - 2016-08-23 22:31:32 --> Helper loaded: form_helper
INFO - 2016-08-23 22:31:32 --> Helper loaded: file_helper
INFO - 2016-08-23 22:31:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:31:32 --> Database Driver Class Initialized
INFO - 2016-08-23 22:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:31:32 --> Form Validation Class Initialized
INFO - 2016-08-23 22:31:32 --> Email Class Initialized
INFO - 2016-08-23 22:31:32 --> Controller Class Initialized
DEBUG - 2016-08-23 22:31:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:31:32 --> Model Class Initialized
INFO - 2016-08-23 22:31:32 --> Model Class Initialized
INFO - 2016-08-23 22:31:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:31:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:31:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:31:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:31:32 --> Final output sent to browser
DEBUG - 2016-08-23 22:31:32 --> Total execution time: 0.4802
INFO - 2016-08-23 22:31:36 --> Config Class Initialized
INFO - 2016-08-23 22:31:36 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:31:36 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:31:36 --> Utf8 Class Initialized
INFO - 2016-08-23 22:31:36 --> URI Class Initialized
INFO - 2016-08-23 22:31:36 --> Router Class Initialized
INFO - 2016-08-23 22:31:36 --> Output Class Initialized
INFO - 2016-08-23 22:31:36 --> Security Class Initialized
DEBUG - 2016-08-23 22:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:31:36 --> Input Class Initialized
INFO - 2016-08-23 22:31:36 --> Language Class Initialized
INFO - 2016-08-23 22:31:36 --> Loader Class Initialized
INFO - 2016-08-23 22:31:36 --> Helper loaded: url_helper
INFO - 2016-08-23 22:31:36 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:31:36 --> Helper loaded: html_helper
INFO - 2016-08-23 22:31:36 --> Helper loaded: form_helper
INFO - 2016-08-23 22:31:36 --> Helper loaded: file_helper
INFO - 2016-08-23 22:31:36 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:31:36 --> Database Driver Class Initialized
INFO - 2016-08-23 22:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:31:36 --> Form Validation Class Initialized
INFO - 2016-08-23 22:31:36 --> Email Class Initialized
INFO - 2016-08-23 22:31:36 --> Controller Class Initialized
DEBUG - 2016-08-23 22:31:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:31:36 --> Model Class Initialized
INFO - 2016-08-23 22:31:36 --> Model Class Initialized
INFO - 2016-08-23 22:31:36 --> Model Class Initialized
INFO - 2016-08-23 22:31:36 --> Model Class Initialized
INFO - 2016-08-23 22:31:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:31:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:31:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:31:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:31:36 --> Final output sent to browser
DEBUG - 2016-08-23 22:31:36 --> Total execution time: 0.5084
INFO - 2016-08-23 22:33:25 --> Config Class Initialized
INFO - 2016-08-23 22:33:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:33:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:33:25 --> Utf8 Class Initialized
INFO - 2016-08-23 22:33:25 --> URI Class Initialized
INFO - 2016-08-23 22:33:25 --> Router Class Initialized
INFO - 2016-08-23 22:33:25 --> Output Class Initialized
INFO - 2016-08-23 22:33:25 --> Security Class Initialized
DEBUG - 2016-08-23 22:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:33:25 --> Input Class Initialized
INFO - 2016-08-23 22:33:25 --> Language Class Initialized
INFO - 2016-08-23 22:33:25 --> Loader Class Initialized
INFO - 2016-08-23 22:33:25 --> Helper loaded: url_helper
INFO - 2016-08-23 22:33:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:33:25 --> Helper loaded: html_helper
INFO - 2016-08-23 22:33:25 --> Helper loaded: form_helper
INFO - 2016-08-23 22:33:25 --> Helper loaded: file_helper
INFO - 2016-08-23 22:33:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:33:25 --> Database Driver Class Initialized
INFO - 2016-08-23 22:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:33:25 --> Form Validation Class Initialized
INFO - 2016-08-23 22:33:25 --> Email Class Initialized
INFO - 2016-08-23 22:33:25 --> Controller Class Initialized
DEBUG - 2016-08-23 22:33:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:33:25 --> Model Class Initialized
INFO - 2016-08-23 22:33:25 --> Model Class Initialized
INFO - 2016-08-23 22:33:25 --> Model Class Initialized
INFO - 2016-08-23 22:33:25 --> Model Class Initialized
INFO - 2016-08-23 22:33:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:33:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:33:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:33:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:33:26 --> Final output sent to browser
DEBUG - 2016-08-23 22:33:26 --> Total execution time: 0.4975
INFO - 2016-08-23 22:33:30 --> Config Class Initialized
INFO - 2016-08-23 22:33:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:33:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:33:30 --> Utf8 Class Initialized
INFO - 2016-08-23 22:33:30 --> URI Class Initialized
INFO - 2016-08-23 22:33:30 --> Router Class Initialized
INFO - 2016-08-23 22:33:30 --> Output Class Initialized
INFO - 2016-08-23 22:33:30 --> Security Class Initialized
DEBUG - 2016-08-23 22:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:33:30 --> Input Class Initialized
INFO - 2016-08-23 22:33:30 --> Language Class Initialized
INFO - 2016-08-23 22:33:30 --> Loader Class Initialized
INFO - 2016-08-23 22:33:30 --> Helper loaded: url_helper
INFO - 2016-08-23 22:33:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:33:30 --> Helper loaded: html_helper
INFO - 2016-08-23 22:33:30 --> Helper loaded: form_helper
INFO - 2016-08-23 22:33:30 --> Helper loaded: file_helper
INFO - 2016-08-23 22:33:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:33:30 --> Database Driver Class Initialized
INFO - 2016-08-23 22:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:33:30 --> Form Validation Class Initialized
INFO - 2016-08-23 22:33:30 --> Email Class Initialized
INFO - 2016-08-23 22:33:30 --> Controller Class Initialized
DEBUG - 2016-08-23 22:33:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:33:30 --> Model Class Initialized
INFO - 2016-08-23 22:33:30 --> Model Class Initialized
INFO - 2016-08-23 22:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:33:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:33:30 --> Final output sent to browser
DEBUG - 2016-08-23 22:33:30 --> Total execution time: 0.4607
INFO - 2016-08-23 22:33:33 --> Config Class Initialized
INFO - 2016-08-23 22:33:33 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:33:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:33:34 --> Utf8 Class Initialized
INFO - 2016-08-23 22:33:34 --> URI Class Initialized
INFO - 2016-08-23 22:33:34 --> Router Class Initialized
INFO - 2016-08-23 22:33:34 --> Output Class Initialized
INFO - 2016-08-23 22:33:34 --> Security Class Initialized
DEBUG - 2016-08-23 22:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:33:34 --> Input Class Initialized
INFO - 2016-08-23 22:33:34 --> Language Class Initialized
INFO - 2016-08-23 22:33:34 --> Loader Class Initialized
INFO - 2016-08-23 22:33:34 --> Helper loaded: url_helper
INFO - 2016-08-23 22:33:34 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:33:34 --> Helper loaded: html_helper
INFO - 2016-08-23 22:33:34 --> Helper loaded: form_helper
INFO - 2016-08-23 22:33:34 --> Helper loaded: file_helper
INFO - 2016-08-23 22:33:34 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:33:34 --> Database Driver Class Initialized
INFO - 2016-08-23 22:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:33:34 --> Form Validation Class Initialized
INFO - 2016-08-23 22:33:34 --> Email Class Initialized
INFO - 2016-08-23 22:33:34 --> Controller Class Initialized
DEBUG - 2016-08-23 22:33:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:33:34 --> Model Class Initialized
INFO - 2016-08-23 22:33:34 --> Model Class Initialized
INFO - 2016-08-23 22:33:34 --> Model Class Initialized
INFO - 2016-08-23 22:33:34 --> Model Class Initialized
INFO - 2016-08-23 22:33:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:33:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:33:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:33:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:33:34 --> Final output sent to browser
DEBUG - 2016-08-23 22:33:34 --> Total execution time: 0.4844
INFO - 2016-08-23 22:34:17 --> Config Class Initialized
INFO - 2016-08-23 22:34:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:34:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:34:17 --> Utf8 Class Initialized
INFO - 2016-08-23 22:34:17 --> URI Class Initialized
INFO - 2016-08-23 22:34:17 --> Router Class Initialized
INFO - 2016-08-23 22:34:17 --> Output Class Initialized
INFO - 2016-08-23 22:34:17 --> Security Class Initialized
DEBUG - 2016-08-23 22:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:34:17 --> Input Class Initialized
INFO - 2016-08-23 22:34:17 --> Language Class Initialized
INFO - 2016-08-23 22:34:17 --> Loader Class Initialized
INFO - 2016-08-23 22:34:17 --> Helper loaded: url_helper
INFO - 2016-08-23 22:34:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:34:17 --> Helper loaded: html_helper
INFO - 2016-08-23 22:34:17 --> Helper loaded: form_helper
INFO - 2016-08-23 22:34:17 --> Helper loaded: file_helper
INFO - 2016-08-23 22:34:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:34:17 --> Database Driver Class Initialized
INFO - 2016-08-23 22:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:34:17 --> Form Validation Class Initialized
INFO - 2016-08-23 22:34:17 --> Email Class Initialized
INFO - 2016-08-23 22:34:17 --> Controller Class Initialized
INFO - 2016-08-23 22:34:17 --> Model Class Initialized
INFO - 2016-08-23 22:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:34:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:34:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:34:17 --> Total execution time: 0.4904
INFO - 2016-08-23 22:34:21 --> Config Class Initialized
INFO - 2016-08-23 22:34:21 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:34:21 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:34:21 --> Utf8 Class Initialized
INFO - 2016-08-23 22:34:21 --> URI Class Initialized
INFO - 2016-08-23 22:34:21 --> Router Class Initialized
INFO - 2016-08-23 22:34:21 --> Output Class Initialized
INFO - 2016-08-23 22:34:21 --> Security Class Initialized
DEBUG - 2016-08-23 22:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:34:21 --> Input Class Initialized
INFO - 2016-08-23 22:34:21 --> Language Class Initialized
INFO - 2016-08-23 22:34:21 --> Loader Class Initialized
INFO - 2016-08-23 22:34:21 --> Helper loaded: url_helper
INFO - 2016-08-23 22:34:21 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:34:21 --> Helper loaded: html_helper
INFO - 2016-08-23 22:34:21 --> Helper loaded: form_helper
INFO - 2016-08-23 22:34:21 --> Helper loaded: file_helper
INFO - 2016-08-23 22:34:21 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:34:21 --> Database Driver Class Initialized
INFO - 2016-08-23 22:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:34:21 --> Form Validation Class Initialized
INFO - 2016-08-23 22:34:21 --> Email Class Initialized
INFO - 2016-08-23 22:34:21 --> Controller Class Initialized
DEBUG - 2016-08-23 22:34:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:34:21 --> Model Class Initialized
INFO - 2016-08-23 22:34:22 --> Model Class Initialized
INFO - 2016-08-23 22:34:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:34:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:34:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:34:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:34:22 --> Final output sent to browser
DEBUG - 2016-08-23 22:34:22 --> Total execution time: 0.5969
INFO - 2016-08-23 22:34:25 --> Config Class Initialized
INFO - 2016-08-23 22:34:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:34:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:34:25 --> Utf8 Class Initialized
INFO - 2016-08-23 22:34:25 --> URI Class Initialized
INFO - 2016-08-23 22:34:25 --> Router Class Initialized
INFO - 2016-08-23 22:34:25 --> Output Class Initialized
INFO - 2016-08-23 22:34:25 --> Security Class Initialized
DEBUG - 2016-08-23 22:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:34:25 --> Input Class Initialized
INFO - 2016-08-23 22:34:25 --> Language Class Initialized
INFO - 2016-08-23 22:34:25 --> Loader Class Initialized
INFO - 2016-08-23 22:34:25 --> Helper loaded: url_helper
INFO - 2016-08-23 22:34:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:34:25 --> Helper loaded: html_helper
INFO - 2016-08-23 22:34:25 --> Helper loaded: form_helper
INFO - 2016-08-23 22:34:25 --> Helper loaded: file_helper
INFO - 2016-08-23 22:34:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:34:25 --> Database Driver Class Initialized
INFO - 2016-08-23 22:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:34:25 --> Form Validation Class Initialized
INFO - 2016-08-23 22:34:25 --> Email Class Initialized
INFO - 2016-08-23 22:34:25 --> Controller Class Initialized
DEBUG - 2016-08-23 22:34:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:34:25 --> Model Class Initialized
INFO - 2016-08-23 22:34:25 --> Model Class Initialized
INFO - 2016-08-23 22:34:25 --> Model Class Initialized
INFO - 2016-08-23 22:34:25 --> Model Class Initialized
INFO - 2016-08-23 22:34:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:34:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:34:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:34:26 --> Final output sent to browser
DEBUG - 2016-08-23 22:34:26 --> Total execution time: 0.5014
INFO - 2016-08-23 22:35:07 --> Config Class Initialized
INFO - 2016-08-23 22:35:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:35:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:35:07 --> Utf8 Class Initialized
INFO - 2016-08-23 22:35:07 --> URI Class Initialized
INFO - 2016-08-23 22:35:07 --> Router Class Initialized
INFO - 2016-08-23 22:35:07 --> Output Class Initialized
INFO - 2016-08-23 22:35:07 --> Security Class Initialized
DEBUG - 2016-08-23 22:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:35:07 --> Input Class Initialized
INFO - 2016-08-23 22:35:07 --> Language Class Initialized
INFO - 2016-08-23 22:35:07 --> Loader Class Initialized
INFO - 2016-08-23 22:35:07 --> Helper loaded: url_helper
INFO - 2016-08-23 22:35:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:35:07 --> Helper loaded: html_helper
INFO - 2016-08-23 22:35:07 --> Helper loaded: form_helper
INFO - 2016-08-23 22:35:08 --> Helper loaded: file_helper
INFO - 2016-08-23 22:35:08 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:35:08 --> Database Driver Class Initialized
INFO - 2016-08-23 22:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:35:08 --> Form Validation Class Initialized
INFO - 2016-08-23 22:35:08 --> Email Class Initialized
INFO - 2016-08-23 22:35:08 --> Controller Class Initialized
DEBUG - 2016-08-23 22:35:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:35:08 --> Model Class Initialized
INFO - 2016-08-23 22:35:08 --> Model Class Initialized
INFO - 2016-08-23 22:35:08 --> Model Class Initialized
INFO - 2016-08-23 22:35:08 --> Model Class Initialized
INFO - 2016-08-23 22:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:35:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:35:08 --> Final output sent to browser
DEBUG - 2016-08-23 22:35:08 --> Total execution time: 0.4896
INFO - 2016-08-23 22:35:24 --> Config Class Initialized
INFO - 2016-08-23 22:35:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:35:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:35:24 --> Utf8 Class Initialized
INFO - 2016-08-23 22:35:24 --> URI Class Initialized
INFO - 2016-08-23 22:35:24 --> Router Class Initialized
INFO - 2016-08-23 22:35:24 --> Output Class Initialized
INFO - 2016-08-23 22:35:24 --> Security Class Initialized
DEBUG - 2016-08-23 22:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:35:24 --> Input Class Initialized
INFO - 2016-08-23 22:35:24 --> Language Class Initialized
INFO - 2016-08-23 22:35:24 --> Loader Class Initialized
INFO - 2016-08-23 22:35:24 --> Helper loaded: url_helper
INFO - 2016-08-23 22:35:24 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:35:24 --> Helper loaded: html_helper
INFO - 2016-08-23 22:35:24 --> Helper loaded: form_helper
INFO - 2016-08-23 22:35:24 --> Helper loaded: file_helper
INFO - 2016-08-23 22:35:24 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:35:24 --> Database Driver Class Initialized
INFO - 2016-08-23 22:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:35:24 --> Form Validation Class Initialized
INFO - 2016-08-23 22:35:24 --> Email Class Initialized
INFO - 2016-08-23 22:35:24 --> Controller Class Initialized
DEBUG - 2016-08-23 22:35:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:35:24 --> Model Class Initialized
INFO - 2016-08-23 22:35:24 --> Model Class Initialized
INFO - 2016-08-23 22:35:24 --> Model Class Initialized
INFO - 2016-08-23 22:35:24 --> Model Class Initialized
INFO - 2016-08-23 22:35:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:35:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:35:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-23 22:35:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:35:24 --> Final output sent to browser
DEBUG - 2016-08-23 22:35:24 --> Total execution time: 0.5096
INFO - 2016-08-23 22:35:31 --> Config Class Initialized
INFO - 2016-08-23 22:35:31 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:35:31 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:35:31 --> Utf8 Class Initialized
INFO - 2016-08-23 22:35:31 --> URI Class Initialized
INFO - 2016-08-23 22:35:31 --> Router Class Initialized
INFO - 2016-08-23 22:35:31 --> Output Class Initialized
INFO - 2016-08-23 22:35:32 --> Security Class Initialized
DEBUG - 2016-08-23 22:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:35:32 --> Input Class Initialized
INFO - 2016-08-23 22:35:32 --> Language Class Initialized
INFO - 2016-08-23 22:35:32 --> Loader Class Initialized
INFO - 2016-08-23 22:35:32 --> Helper loaded: url_helper
INFO - 2016-08-23 22:35:32 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:35:32 --> Helper loaded: html_helper
INFO - 2016-08-23 22:35:32 --> Helper loaded: form_helper
INFO - 2016-08-23 22:35:32 --> Helper loaded: file_helper
INFO - 2016-08-23 22:35:32 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:35:32 --> Database Driver Class Initialized
INFO - 2016-08-23 22:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:35:32 --> Form Validation Class Initialized
INFO - 2016-08-23 22:35:32 --> Email Class Initialized
INFO - 2016-08-23 22:35:32 --> Controller Class Initialized
INFO - 2016-08-23 22:35:32 --> Model Class Initialized
INFO - 2016-08-23 22:35:32 --> Model Class Initialized
DEBUG - 2016-08-23 22:35:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:35:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:35:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:35:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:35:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:35:32 --> Final output sent to browser
DEBUG - 2016-08-23 22:35:32 --> Total execution time: 0.4894
INFO - 2016-08-23 22:36:00 --> Config Class Initialized
INFO - 2016-08-23 22:36:00 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:00 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:00 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:00 --> URI Class Initialized
INFO - 2016-08-23 22:36:00 --> Router Class Initialized
INFO - 2016-08-23 22:36:00 --> Output Class Initialized
INFO - 2016-08-23 22:36:00 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:00 --> Input Class Initialized
INFO - 2016-08-23 22:36:00 --> Language Class Initialized
INFO - 2016-08-23 22:36:00 --> Loader Class Initialized
INFO - 2016-08-23 22:36:00 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:00 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:00 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:00 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:00 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:00 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:00 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:00 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:00 --> Email Class Initialized
INFO - 2016-08-23 22:36:00 --> Controller Class Initialized
DEBUG - 2016-08-23 22:36:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:36:00 --> Model Class Initialized
INFO - 2016-08-23 22:36:00 --> Model Class Initialized
INFO - 2016-08-23 22:36:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:36:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:00 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:00 --> Total execution time: 0.4788
INFO - 2016-08-23 22:36:26 --> Config Class Initialized
INFO - 2016-08-23 22:36:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:26 --> URI Class Initialized
INFO - 2016-08-23 22:36:26 --> Router Class Initialized
INFO - 2016-08-23 22:36:26 --> Output Class Initialized
INFO - 2016-08-23 22:36:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:26 --> Input Class Initialized
INFO - 2016-08-23 22:36:26 --> Language Class Initialized
INFO - 2016-08-23 22:36:26 --> Loader Class Initialized
INFO - 2016-08-23 22:36:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:26 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:26 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:26 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:27 --> Email Class Initialized
INFO - 2016-08-23 22:36:27 --> Controller Class Initialized
DEBUG - 2016-08-23 22:36:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:36:27 --> Model Class Initialized
INFO - 2016-08-23 22:36:27 --> Model Class Initialized
INFO - 2016-08-23 22:36:27 --> Model Class Initialized
INFO - 2016-08-23 22:36:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:36:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:27 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:27 --> Total execution time: 0.4804
INFO - 2016-08-23 22:36:30 --> Config Class Initialized
INFO - 2016-08-23 22:36:30 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:30 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:30 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:30 --> URI Class Initialized
INFO - 2016-08-23 22:36:30 --> Router Class Initialized
INFO - 2016-08-23 22:36:30 --> Output Class Initialized
INFO - 2016-08-23 22:36:30 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:30 --> Input Class Initialized
INFO - 2016-08-23 22:36:30 --> Language Class Initialized
INFO - 2016-08-23 22:36:30 --> Loader Class Initialized
INFO - 2016-08-23 22:36:30 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:30 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:30 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:30 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:30 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:30 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:30 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:30 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:31 --> Email Class Initialized
INFO - 2016-08-23 22:36:31 --> Controller Class Initialized
DEBUG - 2016-08-23 22:36:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:36:31 --> Model Class Initialized
INFO - 2016-08-23 22:36:31 --> Model Class Initialized
INFO - 2016-08-23 22:36:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:36:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:31 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:31 --> Total execution time: 0.5328
INFO - 2016-08-23 22:36:37 --> Config Class Initialized
INFO - 2016-08-23 22:36:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:37 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:37 --> URI Class Initialized
INFO - 2016-08-23 22:36:37 --> Router Class Initialized
INFO - 2016-08-23 22:36:37 --> Output Class Initialized
INFO - 2016-08-23 22:36:37 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:37 --> Input Class Initialized
INFO - 2016-08-23 22:36:37 --> Language Class Initialized
INFO - 2016-08-23 22:36:37 --> Loader Class Initialized
INFO - 2016-08-23 22:36:37 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:37 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:37 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:37 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:37 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:37 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:37 --> Email Class Initialized
INFO - 2016-08-23 22:36:37 --> Controller Class Initialized
DEBUG - 2016-08-23 22:36:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:36:37 --> Model Class Initialized
INFO - 2016-08-23 22:36:37 --> Model Class Initialized
INFO - 2016-08-23 22:36:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:36:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:37 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:37 --> Total execution time: 0.5114
INFO - 2016-08-23 22:36:44 --> Config Class Initialized
INFO - 2016-08-23 22:36:44 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:44 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:44 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:44 --> URI Class Initialized
INFO - 2016-08-23 22:36:44 --> Router Class Initialized
INFO - 2016-08-23 22:36:44 --> Output Class Initialized
INFO - 2016-08-23 22:36:44 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:44 --> Input Class Initialized
INFO - 2016-08-23 22:36:44 --> Language Class Initialized
INFO - 2016-08-23 22:36:44 --> Loader Class Initialized
INFO - 2016-08-23 22:36:44 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:44 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:44 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:44 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:44 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:44 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:44 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:44 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:44 --> Email Class Initialized
INFO - 2016-08-23 22:36:44 --> Controller Class Initialized
DEBUG - 2016-08-23 22:36:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:36:44 --> Model Class Initialized
INFO - 2016-08-23 22:36:44 --> Model Class Initialized
INFO - 2016-08-23 22:36:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:36:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:44 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:44 --> Total execution time: 0.5182
INFO - 2016-08-23 22:36:47 --> Config Class Initialized
INFO - 2016-08-23 22:36:47 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:36:47 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:36:47 --> Utf8 Class Initialized
INFO - 2016-08-23 22:36:47 --> URI Class Initialized
INFO - 2016-08-23 22:36:47 --> Router Class Initialized
INFO - 2016-08-23 22:36:47 --> Output Class Initialized
INFO - 2016-08-23 22:36:47 --> Security Class Initialized
DEBUG - 2016-08-23 22:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:36:47 --> Input Class Initialized
INFO - 2016-08-23 22:36:47 --> Language Class Initialized
INFO - 2016-08-23 22:36:47 --> Loader Class Initialized
INFO - 2016-08-23 22:36:47 --> Helper loaded: url_helper
INFO - 2016-08-23 22:36:47 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:36:47 --> Helper loaded: html_helper
INFO - 2016-08-23 22:36:47 --> Helper loaded: form_helper
INFO - 2016-08-23 22:36:47 --> Helper loaded: file_helper
INFO - 2016-08-23 22:36:47 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:36:47 --> Database Driver Class Initialized
INFO - 2016-08-23 22:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:36:47 --> Form Validation Class Initialized
INFO - 2016-08-23 22:36:47 --> Email Class Initialized
INFO - 2016-08-23 22:36:47 --> Controller Class Initialized
INFO - 2016-08-23 22:36:47 --> Model Class Initialized
INFO - 2016-08-23 22:36:47 --> Model Class Initialized
INFO - 2016-08-23 22:36:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:36:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:36:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:36:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:36:47 --> Final output sent to browser
DEBUG - 2016-08-23 22:36:47 --> Total execution time: 0.6176
INFO - 2016-08-23 22:38:16 --> Config Class Initialized
INFO - 2016-08-23 22:38:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:38:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:38:16 --> Utf8 Class Initialized
INFO - 2016-08-23 22:38:16 --> URI Class Initialized
INFO - 2016-08-23 22:38:16 --> Router Class Initialized
INFO - 2016-08-23 22:38:16 --> Output Class Initialized
INFO - 2016-08-23 22:38:16 --> Security Class Initialized
DEBUG - 2016-08-23 22:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:38:16 --> Input Class Initialized
INFO - 2016-08-23 22:38:16 --> Language Class Initialized
INFO - 2016-08-23 22:38:16 --> Loader Class Initialized
INFO - 2016-08-23 22:38:16 --> Helper loaded: url_helper
INFO - 2016-08-23 22:38:16 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:38:16 --> Helper loaded: html_helper
INFO - 2016-08-23 22:38:16 --> Helper loaded: form_helper
INFO - 2016-08-23 22:38:16 --> Helper loaded: file_helper
INFO - 2016-08-23 22:38:16 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:38:17 --> Database Driver Class Initialized
INFO - 2016-08-23 22:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:38:17 --> Form Validation Class Initialized
INFO - 2016-08-23 22:38:17 --> Email Class Initialized
INFO - 2016-08-23 22:38:17 --> Controller Class Initialized
INFO - 2016-08-23 22:38:17 --> Model Class Initialized
INFO - 2016-08-23 22:38:17 --> Model Class Initialized
INFO - 2016-08-23 22:38:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:38:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:38:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:38:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:38:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:38:17 --> Total execution time: 0.4767
INFO - 2016-08-23 22:38:39 --> Config Class Initialized
INFO - 2016-08-23 22:38:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:38:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:38:39 --> Utf8 Class Initialized
INFO - 2016-08-23 22:38:39 --> URI Class Initialized
INFO - 2016-08-23 22:38:39 --> Router Class Initialized
INFO - 2016-08-23 22:38:39 --> Output Class Initialized
INFO - 2016-08-23 22:38:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:38:39 --> Input Class Initialized
INFO - 2016-08-23 22:38:39 --> Language Class Initialized
INFO - 2016-08-23 22:38:39 --> Loader Class Initialized
INFO - 2016-08-23 22:38:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:38:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:38:40 --> Helper loaded: html_helper
INFO - 2016-08-23 22:38:40 --> Helper loaded: form_helper
INFO - 2016-08-23 22:38:40 --> Helper loaded: file_helper
INFO - 2016-08-23 22:38:40 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:38:40 --> Database Driver Class Initialized
INFO - 2016-08-23 22:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:38:40 --> Form Validation Class Initialized
INFO - 2016-08-23 22:38:40 --> Email Class Initialized
INFO - 2016-08-23 22:38:40 --> Controller Class Initialized
INFO - 2016-08-23 22:38:40 --> Model Class Initialized
INFO - 2016-08-23 22:38:40 --> Model Class Initialized
INFO - 2016-08-23 22:38:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:38:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:38:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:38:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:38:40 --> Final output sent to browser
DEBUG - 2016-08-23 22:38:40 --> Total execution time: 0.4741
INFO - 2016-08-23 22:38:46 --> Config Class Initialized
INFO - 2016-08-23 22:38:46 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:38:46 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:38:46 --> Utf8 Class Initialized
INFO - 2016-08-23 22:38:46 --> URI Class Initialized
INFO - 2016-08-23 22:38:46 --> Router Class Initialized
INFO - 2016-08-23 22:38:46 --> Output Class Initialized
INFO - 2016-08-23 22:38:46 --> Security Class Initialized
DEBUG - 2016-08-23 22:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:38:46 --> Input Class Initialized
INFO - 2016-08-23 22:38:46 --> Language Class Initialized
INFO - 2016-08-23 22:38:46 --> Loader Class Initialized
INFO - 2016-08-23 22:38:46 --> Helper loaded: url_helper
INFO - 2016-08-23 22:38:46 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:38:46 --> Helper loaded: html_helper
INFO - 2016-08-23 22:38:46 --> Helper loaded: form_helper
INFO - 2016-08-23 22:38:46 --> Helper loaded: file_helper
INFO - 2016-08-23 22:38:46 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:38:46 --> Database Driver Class Initialized
INFO - 2016-08-23 22:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:38:46 --> Form Validation Class Initialized
INFO - 2016-08-23 22:38:46 --> Email Class Initialized
INFO - 2016-08-23 22:38:46 --> Controller Class Initialized
DEBUG - 2016-08-23 22:38:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:38:46 --> Model Class Initialized
INFO - 2016-08-23 22:38:46 --> Model Class Initialized
INFO - 2016-08-23 22:38:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:38:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:38:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:38:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:38:46 --> Final output sent to browser
DEBUG - 2016-08-23 22:38:46 --> Total execution time: 0.4774
INFO - 2016-08-23 22:38:52 --> Config Class Initialized
INFO - 2016-08-23 22:38:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:38:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:38:52 --> Utf8 Class Initialized
INFO - 2016-08-23 22:38:52 --> URI Class Initialized
INFO - 2016-08-23 22:38:52 --> Router Class Initialized
INFO - 2016-08-23 22:38:52 --> Output Class Initialized
INFO - 2016-08-23 22:38:52 --> Security Class Initialized
DEBUG - 2016-08-23 22:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:38:53 --> Input Class Initialized
INFO - 2016-08-23 22:38:53 --> Language Class Initialized
INFO - 2016-08-23 22:38:53 --> Loader Class Initialized
INFO - 2016-08-23 22:38:53 --> Helper loaded: url_helper
INFO - 2016-08-23 22:38:53 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:38:53 --> Helper loaded: html_helper
INFO - 2016-08-23 22:38:53 --> Helper loaded: form_helper
INFO - 2016-08-23 22:38:53 --> Helper loaded: file_helper
INFO - 2016-08-23 22:38:53 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:38:53 --> Database Driver Class Initialized
INFO - 2016-08-23 22:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:38:53 --> Form Validation Class Initialized
INFO - 2016-08-23 22:38:53 --> Email Class Initialized
INFO - 2016-08-23 22:38:53 --> Controller Class Initialized
INFO - 2016-08-23 22:38:53 --> Model Class Initialized
INFO - 2016-08-23 22:38:53 --> Model Class Initialized
INFO - 2016-08-23 22:38:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:38:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:38:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:38:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:38:53 --> Final output sent to browser
DEBUG - 2016-08-23 22:38:53 --> Total execution time: 0.5407
INFO - 2016-08-23 22:38:57 --> Config Class Initialized
INFO - 2016-08-23 22:38:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:38:57 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:38:57 --> Utf8 Class Initialized
INFO - 2016-08-23 22:38:57 --> URI Class Initialized
INFO - 2016-08-23 22:38:57 --> Router Class Initialized
INFO - 2016-08-23 22:38:57 --> Output Class Initialized
INFO - 2016-08-23 22:38:57 --> Security Class Initialized
DEBUG - 2016-08-23 22:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:38:57 --> Input Class Initialized
INFO - 2016-08-23 22:38:57 --> Language Class Initialized
INFO - 2016-08-23 22:38:57 --> Loader Class Initialized
INFO - 2016-08-23 22:38:57 --> Helper loaded: url_helper
INFO - 2016-08-23 22:38:57 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:38:57 --> Helper loaded: html_helper
INFO - 2016-08-23 22:38:57 --> Helper loaded: form_helper
INFO - 2016-08-23 22:38:57 --> Helper loaded: file_helper
INFO - 2016-08-23 22:38:57 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:38:57 --> Database Driver Class Initialized
INFO - 2016-08-23 22:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:38:57 --> Form Validation Class Initialized
INFO - 2016-08-23 22:38:57 --> Email Class Initialized
INFO - 2016-08-23 22:38:57 --> Controller Class Initialized
DEBUG - 2016-08-23 22:38:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:38:57 --> Model Class Initialized
INFO - 2016-08-23 22:38:57 --> Model Class Initialized
INFO - 2016-08-23 22:38:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:38:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:38:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:38:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:38:57 --> Final output sent to browser
DEBUG - 2016-08-23 22:38:57 --> Total execution time: 0.4919
INFO - 2016-08-23 22:39:03 --> Config Class Initialized
INFO - 2016-08-23 22:39:03 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:03 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:03 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:03 --> URI Class Initialized
INFO - 2016-08-23 22:39:03 --> Router Class Initialized
INFO - 2016-08-23 22:39:03 --> Output Class Initialized
INFO - 2016-08-23 22:39:03 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:03 --> Input Class Initialized
INFO - 2016-08-23 22:39:03 --> Language Class Initialized
INFO - 2016-08-23 22:39:03 --> Loader Class Initialized
INFO - 2016-08-23 22:39:03 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:03 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:03 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:03 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:03 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:03 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:03 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:03 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:03 --> Email Class Initialized
INFO - 2016-08-23 22:39:03 --> Controller Class Initialized
INFO - 2016-08-23 22:39:03 --> Model Class Initialized
INFO - 2016-08-23 22:39:03 --> Model Class Initialized
INFO - 2016-08-23 22:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:39:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:03 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:03 --> Total execution time: 0.4583
INFO - 2016-08-23 22:39:07 --> Config Class Initialized
INFO - 2016-08-23 22:39:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:07 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:07 --> URI Class Initialized
INFO - 2016-08-23 22:39:07 --> Router Class Initialized
INFO - 2016-08-23 22:39:07 --> Output Class Initialized
INFO - 2016-08-23 22:39:07 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:07 --> Input Class Initialized
INFO - 2016-08-23 22:39:07 --> Language Class Initialized
INFO - 2016-08-23 22:39:07 --> Loader Class Initialized
INFO - 2016-08-23 22:39:07 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:07 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:07 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:07 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:07 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:08 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:08 --> Email Class Initialized
INFO - 2016-08-23 22:39:08 --> Controller Class Initialized
INFO - 2016-08-23 22:39:08 --> Model Class Initialized
INFO - 2016-08-23 22:39:08 --> Model Class Initialized
INFO - 2016-08-23 22:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-23 22:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:08 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:08 --> Total execution time: 0.4579
INFO - 2016-08-23 22:39:09 --> Config Class Initialized
INFO - 2016-08-23 22:39:09 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:09 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:09 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:09 --> URI Class Initialized
INFO - 2016-08-23 22:39:09 --> Router Class Initialized
INFO - 2016-08-23 22:39:09 --> Output Class Initialized
INFO - 2016-08-23 22:39:09 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:09 --> Input Class Initialized
INFO - 2016-08-23 22:39:09 --> Language Class Initialized
INFO - 2016-08-23 22:39:09 --> Loader Class Initialized
INFO - 2016-08-23 22:39:09 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:09 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:09 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:09 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:10 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:10 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:10 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:10 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:10 --> Email Class Initialized
INFO - 2016-08-23 22:39:10 --> Controller Class Initialized
INFO - 2016-08-23 22:39:10 --> Model Class Initialized
INFO - 2016-08-23 22:39:10 --> Model Class Initialized
INFO - 2016-08-23 22:39:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:39:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:10 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:10 --> Total execution time: 0.4921
INFO - 2016-08-23 22:39:13 --> Config Class Initialized
INFO - 2016-08-23 22:39:13 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:13 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:13 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:13 --> URI Class Initialized
INFO - 2016-08-23 22:39:13 --> Router Class Initialized
INFO - 2016-08-23 22:39:13 --> Output Class Initialized
INFO - 2016-08-23 22:39:13 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:13 --> Input Class Initialized
INFO - 2016-08-23 22:39:13 --> Language Class Initialized
INFO - 2016-08-23 22:39:13 --> Loader Class Initialized
INFO - 2016-08-23 22:39:13 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:13 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:13 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:13 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:13 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:13 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:13 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:13 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:13 --> Email Class Initialized
INFO - 2016-08-23 22:39:13 --> Controller Class Initialized
INFO - 2016-08-23 22:39:13 --> Model Class Initialized
INFO - 2016-08-23 22:39:13 --> Model Class Initialized
INFO - 2016-08-23 22:39:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-23 22:39:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:13 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:13 --> Total execution time: 0.4976
INFO - 2016-08-23 22:39:17 --> Config Class Initialized
INFO - 2016-08-23 22:39:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:17 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:17 --> URI Class Initialized
INFO - 2016-08-23 22:39:17 --> Router Class Initialized
INFO - 2016-08-23 22:39:17 --> Output Class Initialized
INFO - 2016-08-23 22:39:17 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:17 --> Input Class Initialized
INFO - 2016-08-23 22:39:17 --> Language Class Initialized
INFO - 2016-08-23 22:39:17 --> Loader Class Initialized
INFO - 2016-08-23 22:39:17 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:17 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:17 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:17 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:17 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:17 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:17 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:17 --> Email Class Initialized
INFO - 2016-08-23 22:39:17 --> Controller Class Initialized
DEBUG - 2016-08-23 22:39:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:39:17 --> Model Class Initialized
INFO - 2016-08-23 22:39:17 --> Model Class Initialized
INFO - 2016-08-23 22:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-23 22:39:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:17 --> Total execution time: 0.4830
INFO - 2016-08-23 22:39:41 --> Config Class Initialized
INFO - 2016-08-23 22:39:41 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:41 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:41 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:41 --> URI Class Initialized
INFO - 2016-08-23 22:39:41 --> Router Class Initialized
INFO - 2016-08-23 22:39:41 --> Output Class Initialized
INFO - 2016-08-23 22:39:41 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:41 --> Input Class Initialized
INFO - 2016-08-23 22:39:41 --> Language Class Initialized
INFO - 2016-08-23 22:39:41 --> Loader Class Initialized
INFO - 2016-08-23 22:39:42 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:42 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:42 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:42 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:42 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:42 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:42 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:42 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:42 --> Email Class Initialized
INFO - 2016-08-23 22:39:42 --> Controller Class Initialized
INFO - 2016-08-23 22:39:42 --> Model Class Initialized
INFO - 2016-08-23 22:39:42 --> Model Class Initialized
INFO - 2016-08-23 22:39:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:39:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:42 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:42 --> Total execution time: 0.7613
INFO - 2016-08-23 22:39:54 --> Config Class Initialized
INFO - 2016-08-23 22:39:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:54 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:54 --> URI Class Initialized
INFO - 2016-08-23 22:39:54 --> Router Class Initialized
INFO - 2016-08-23 22:39:54 --> Output Class Initialized
INFO - 2016-08-23 22:39:54 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:54 --> Input Class Initialized
INFO - 2016-08-23 22:39:54 --> Language Class Initialized
INFO - 2016-08-23 22:39:54 --> Loader Class Initialized
INFO - 2016-08-23 22:39:54 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:54 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:54 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:54 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:54 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:54 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:54 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:54 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:54 --> Email Class Initialized
INFO - 2016-08-23 22:39:54 --> Controller Class Initialized
INFO - 2016-08-23 22:39:54 --> Model Class Initialized
INFO - 2016-08-23 22:39:54 --> Model Class Initialized
DEBUG - 2016-08-23 22:39:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:39:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:54 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:54 --> Total execution time: 0.4837
INFO - 2016-08-23 22:39:58 --> Config Class Initialized
INFO - 2016-08-23 22:39:58 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:39:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:39:58 --> Utf8 Class Initialized
INFO - 2016-08-23 22:39:58 --> URI Class Initialized
INFO - 2016-08-23 22:39:58 --> Router Class Initialized
INFO - 2016-08-23 22:39:58 --> Output Class Initialized
INFO - 2016-08-23 22:39:58 --> Security Class Initialized
DEBUG - 2016-08-23 22:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:39:59 --> Input Class Initialized
INFO - 2016-08-23 22:39:59 --> Language Class Initialized
INFO - 2016-08-23 22:39:59 --> Loader Class Initialized
INFO - 2016-08-23 22:39:59 --> Helper loaded: url_helper
INFO - 2016-08-23 22:39:59 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:39:59 --> Helper loaded: html_helper
INFO - 2016-08-23 22:39:59 --> Helper loaded: form_helper
INFO - 2016-08-23 22:39:59 --> Helper loaded: file_helper
INFO - 2016-08-23 22:39:59 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:39:59 --> Database Driver Class Initialized
INFO - 2016-08-23 22:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:39:59 --> Form Validation Class Initialized
INFO - 2016-08-23 22:39:59 --> Email Class Initialized
INFO - 2016-08-23 22:39:59 --> Controller Class Initialized
INFO - 2016-08-23 22:39:59 --> Model Class Initialized
INFO - 2016-08-23 22:39:59 --> Model Class Initialized
DEBUG - 2016-08-23 22:39:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:39:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:39:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:39:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:39:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:39:59 --> Final output sent to browser
DEBUG - 2016-08-23 22:39:59 --> Total execution time: 0.5236
INFO - 2016-08-23 22:40:11 --> Config Class Initialized
INFO - 2016-08-23 22:40:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:40:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:40:11 --> Utf8 Class Initialized
INFO - 2016-08-23 22:40:11 --> URI Class Initialized
INFO - 2016-08-23 22:40:11 --> Router Class Initialized
INFO - 2016-08-23 22:40:11 --> Output Class Initialized
INFO - 2016-08-23 22:40:11 --> Security Class Initialized
DEBUG - 2016-08-23 22:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:40:11 --> Input Class Initialized
INFO - 2016-08-23 22:40:11 --> Language Class Initialized
INFO - 2016-08-23 22:40:11 --> Loader Class Initialized
INFO - 2016-08-23 22:40:11 --> Helper loaded: url_helper
INFO - 2016-08-23 22:40:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:40:11 --> Helper loaded: html_helper
INFO - 2016-08-23 22:40:11 --> Helper loaded: form_helper
INFO - 2016-08-23 22:40:11 --> Helper loaded: file_helper
INFO - 2016-08-23 22:40:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:40:11 --> Database Driver Class Initialized
INFO - 2016-08-23 22:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:40:11 --> Form Validation Class Initialized
INFO - 2016-08-23 22:40:11 --> Email Class Initialized
INFO - 2016-08-23 22:40:11 --> Controller Class Initialized
INFO - 2016-08-23 22:40:11 --> Model Class Initialized
INFO - 2016-08-23 22:40:11 --> Model Class Initialized
DEBUG - 2016-08-23 22:40:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:40:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:40:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:40:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:40:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:40:11 --> Final output sent to browser
DEBUG - 2016-08-23 22:40:11 --> Total execution time: 0.5491
INFO - 2016-08-23 22:40:27 --> Config Class Initialized
INFO - 2016-08-23 22:40:27 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:40:27 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:40:27 --> Utf8 Class Initialized
INFO - 2016-08-23 22:40:27 --> URI Class Initialized
INFO - 2016-08-23 22:40:27 --> Router Class Initialized
INFO - 2016-08-23 22:40:27 --> Output Class Initialized
INFO - 2016-08-23 22:40:27 --> Security Class Initialized
DEBUG - 2016-08-23 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:40:27 --> Input Class Initialized
INFO - 2016-08-23 22:40:27 --> Language Class Initialized
INFO - 2016-08-23 22:40:27 --> Loader Class Initialized
INFO - 2016-08-23 22:40:27 --> Helper loaded: url_helper
INFO - 2016-08-23 22:40:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:40:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:40:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:40:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:40:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:40:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:40:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:40:27 --> Email Class Initialized
INFO - 2016-08-23 22:40:27 --> Controller Class Initialized
DEBUG - 2016-08-23 22:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:40:27 --> Model Class Initialized
INFO - 2016-08-23 22:40:28 --> Model Class Initialized
INFO - 2016-08-23 22:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:40:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:40:28 --> Final output sent to browser
DEBUG - 2016-08-23 22:40:28 --> Total execution time: 0.4886
INFO - 2016-08-23 22:41:17 --> Config Class Initialized
INFO - 2016-08-23 22:41:17 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:41:17 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:41:17 --> Utf8 Class Initialized
INFO - 2016-08-23 22:41:17 --> URI Class Initialized
INFO - 2016-08-23 22:41:18 --> Router Class Initialized
INFO - 2016-08-23 22:41:18 --> Output Class Initialized
INFO - 2016-08-23 22:41:18 --> Security Class Initialized
DEBUG - 2016-08-23 22:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:41:18 --> Input Class Initialized
INFO - 2016-08-23 22:41:18 --> Language Class Initialized
INFO - 2016-08-23 22:41:18 --> Loader Class Initialized
INFO - 2016-08-23 22:41:18 --> Helper loaded: url_helper
INFO - 2016-08-23 22:41:18 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:41:18 --> Helper loaded: html_helper
INFO - 2016-08-23 22:41:18 --> Helper loaded: form_helper
INFO - 2016-08-23 22:41:18 --> Helper loaded: file_helper
INFO - 2016-08-23 22:41:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:41:18 --> Database Driver Class Initialized
INFO - 2016-08-23 22:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:41:18 --> Form Validation Class Initialized
INFO - 2016-08-23 22:41:18 --> Email Class Initialized
INFO - 2016-08-23 22:41:18 --> Controller Class Initialized
INFO - 2016-08-23 22:41:18 --> Model Class Initialized
INFO - 2016-08-23 22:41:18 --> Model Class Initialized
DEBUG - 2016-08-23 22:41:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:41:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:41:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:41:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:41:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:41:18 --> Final output sent to browser
DEBUG - 2016-08-23 22:41:18 --> Total execution time: 0.4953
INFO - 2016-08-23 22:41:22 --> Config Class Initialized
INFO - 2016-08-23 22:41:22 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:41:22 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:41:22 --> Utf8 Class Initialized
INFO - 2016-08-23 22:41:22 --> URI Class Initialized
INFO - 2016-08-23 22:41:22 --> Router Class Initialized
INFO - 2016-08-23 22:41:22 --> Output Class Initialized
INFO - 2016-08-23 22:41:22 --> Security Class Initialized
DEBUG - 2016-08-23 22:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:41:22 --> Input Class Initialized
INFO - 2016-08-23 22:41:22 --> Language Class Initialized
INFO - 2016-08-23 22:41:22 --> Loader Class Initialized
INFO - 2016-08-23 22:41:22 --> Helper loaded: url_helper
INFO - 2016-08-23 22:41:23 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:41:23 --> Helper loaded: html_helper
INFO - 2016-08-23 22:41:23 --> Helper loaded: form_helper
INFO - 2016-08-23 22:41:23 --> Helper loaded: file_helper
INFO - 2016-08-23 22:41:23 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:41:23 --> Database Driver Class Initialized
INFO - 2016-08-23 22:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:41:23 --> Form Validation Class Initialized
INFO - 2016-08-23 22:41:23 --> Email Class Initialized
INFO - 2016-08-23 22:41:23 --> Controller Class Initialized
INFO - 2016-08-23 22:41:23 --> Model Class Initialized
INFO - 2016-08-23 22:41:23 --> Model Class Initialized
DEBUG - 2016-08-23 22:41:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:41:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:41:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:41:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:41:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:41:23 --> Final output sent to browser
DEBUG - 2016-08-23 22:41:23 --> Total execution time: 0.5019
INFO - 2016-08-23 22:41:24 --> Config Class Initialized
INFO - 2016-08-23 22:41:24 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:41:24 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:41:24 --> Utf8 Class Initialized
INFO - 2016-08-23 22:41:24 --> URI Class Initialized
INFO - 2016-08-23 22:41:24 --> Router Class Initialized
INFO - 2016-08-23 22:41:24 --> Output Class Initialized
INFO - 2016-08-23 22:41:24 --> Security Class Initialized
DEBUG - 2016-08-23 22:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:41:24 --> Input Class Initialized
INFO - 2016-08-23 22:41:24 --> Language Class Initialized
INFO - 2016-08-23 22:41:24 --> Loader Class Initialized
INFO - 2016-08-23 22:41:24 --> Helper loaded: url_helper
INFO - 2016-08-23 22:41:24 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:41:24 --> Helper loaded: html_helper
INFO - 2016-08-23 22:41:24 --> Helper loaded: form_helper
INFO - 2016-08-23 22:41:24 --> Helper loaded: file_helper
INFO - 2016-08-23 22:41:24 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:41:24 --> Database Driver Class Initialized
INFO - 2016-08-23 22:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:41:24 --> Form Validation Class Initialized
INFO - 2016-08-23 22:41:24 --> Email Class Initialized
INFO - 2016-08-23 22:41:24 --> Controller Class Initialized
INFO - 2016-08-23 22:41:24 --> Model Class Initialized
INFO - 2016-08-23 22:41:24 --> Model Class Initialized
DEBUG - 2016-08-23 22:41:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:41:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:41:24 --> Final output sent to browser
DEBUG - 2016-08-23 22:41:24 --> Total execution time: 0.5233
INFO - 2016-08-23 22:41:31 --> Config Class Initialized
INFO - 2016-08-23 22:41:31 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:41:31 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:41:31 --> Utf8 Class Initialized
INFO - 2016-08-23 22:41:31 --> URI Class Initialized
INFO - 2016-08-23 22:41:31 --> Router Class Initialized
INFO - 2016-08-23 22:41:31 --> Output Class Initialized
INFO - 2016-08-23 22:41:31 --> Security Class Initialized
DEBUG - 2016-08-23 22:41:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:41:31 --> Input Class Initialized
INFO - 2016-08-23 22:41:31 --> Language Class Initialized
INFO - 2016-08-23 22:41:31 --> Loader Class Initialized
INFO - 2016-08-23 22:41:31 --> Helper loaded: url_helper
INFO - 2016-08-23 22:41:31 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:41:31 --> Helper loaded: html_helper
INFO - 2016-08-23 22:41:31 --> Helper loaded: form_helper
INFO - 2016-08-23 22:41:31 --> Helper loaded: file_helper
INFO - 2016-08-23 22:41:31 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:41:31 --> Database Driver Class Initialized
INFO - 2016-08-23 22:41:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:41:31 --> Form Validation Class Initialized
INFO - 2016-08-23 22:41:31 --> Email Class Initialized
INFO - 2016-08-23 22:41:31 --> Controller Class Initialized
INFO - 2016-08-23 22:41:31 --> Model Class Initialized
INFO - 2016-08-23 22:41:31 --> Model Class Initialized
DEBUG - 2016-08-23 22:41:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:41:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:41:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:41:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:41:32 --> Final output sent to browser
DEBUG - 2016-08-23 22:41:32 --> Total execution time: 0.4958
INFO - 2016-08-23 22:42:00 --> Config Class Initialized
INFO - 2016-08-23 22:42:00 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:42:00 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:42:00 --> Utf8 Class Initialized
INFO - 2016-08-23 22:42:00 --> URI Class Initialized
INFO - 2016-08-23 22:42:00 --> Router Class Initialized
INFO - 2016-08-23 22:42:00 --> Output Class Initialized
INFO - 2016-08-23 22:42:00 --> Security Class Initialized
DEBUG - 2016-08-23 22:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:42:00 --> Input Class Initialized
INFO - 2016-08-23 22:42:00 --> Language Class Initialized
INFO - 2016-08-23 22:42:00 --> Loader Class Initialized
INFO - 2016-08-23 22:42:00 --> Helper loaded: url_helper
INFO - 2016-08-23 22:42:00 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:42:00 --> Helper loaded: html_helper
INFO - 2016-08-23 22:42:00 --> Helper loaded: form_helper
INFO - 2016-08-23 22:42:00 --> Helper loaded: file_helper
INFO - 2016-08-23 22:42:00 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:42:00 --> Database Driver Class Initialized
INFO - 2016-08-23 22:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:42:00 --> Form Validation Class Initialized
INFO - 2016-08-23 22:42:00 --> Email Class Initialized
INFO - 2016-08-23 22:42:00 --> Controller Class Initialized
INFO - 2016-08-23 22:42:00 --> Model Class Initialized
INFO - 2016-08-23 22:42:00 --> Model Class Initialized
DEBUG - 2016-08-23 22:42:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:42:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:42:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:42:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:42:00 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:42:00 --> Final output sent to browser
DEBUG - 2016-08-23 22:42:01 --> Total execution time: 0.5012
INFO - 2016-08-23 22:42:18 --> Config Class Initialized
INFO - 2016-08-23 22:42:18 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:42:18 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:42:18 --> Utf8 Class Initialized
INFO - 2016-08-23 22:42:18 --> URI Class Initialized
INFO - 2016-08-23 22:42:18 --> Router Class Initialized
INFO - 2016-08-23 22:42:18 --> Output Class Initialized
INFO - 2016-08-23 22:42:18 --> Security Class Initialized
DEBUG - 2016-08-23 22:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:42:18 --> Input Class Initialized
INFO - 2016-08-23 22:42:18 --> Language Class Initialized
INFO - 2016-08-23 22:42:18 --> Loader Class Initialized
INFO - 2016-08-23 22:42:18 --> Helper loaded: url_helper
INFO - 2016-08-23 22:42:18 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:42:18 --> Helper loaded: html_helper
INFO - 2016-08-23 22:42:18 --> Helper loaded: form_helper
INFO - 2016-08-23 22:42:18 --> Helper loaded: file_helper
INFO - 2016-08-23 22:42:18 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:42:18 --> Database Driver Class Initialized
INFO - 2016-08-23 22:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:42:18 --> Form Validation Class Initialized
INFO - 2016-08-23 22:42:18 --> Email Class Initialized
INFO - 2016-08-23 22:42:18 --> Controller Class Initialized
INFO - 2016-08-23 22:42:18 --> Model Class Initialized
INFO - 2016-08-23 22:42:18 --> Model Class Initialized
DEBUG - 2016-08-23 22:42:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:42:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:42:18 --> Final output sent to browser
DEBUG - 2016-08-23 22:42:18 --> Total execution time: 0.5050
INFO - 2016-08-23 22:42:39 --> Config Class Initialized
INFO - 2016-08-23 22:42:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:42:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:42:39 --> Utf8 Class Initialized
INFO - 2016-08-23 22:42:39 --> URI Class Initialized
INFO - 2016-08-23 22:42:39 --> Router Class Initialized
INFO - 2016-08-23 22:42:39 --> Output Class Initialized
INFO - 2016-08-23 22:42:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:42:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:42:39 --> Input Class Initialized
INFO - 2016-08-23 22:42:39 --> Language Class Initialized
INFO - 2016-08-23 22:42:39 --> Loader Class Initialized
INFO - 2016-08-23 22:42:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:42:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:42:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:42:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:42:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:42:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:42:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:42:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:42:39 --> Email Class Initialized
INFO - 2016-08-23 22:42:39 --> Controller Class Initialized
INFO - 2016-08-23 22:42:39 --> Model Class Initialized
INFO - 2016-08-23 22:42:39 --> Model Class Initialized
DEBUG - 2016-08-23 22:42:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:42:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:42:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:42:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:42:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:42:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:42:39 --> Total execution time: 0.4982
INFO - 2016-08-23 22:44:05 --> Config Class Initialized
INFO - 2016-08-23 22:44:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:44:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:44:05 --> Utf8 Class Initialized
INFO - 2016-08-23 22:44:05 --> URI Class Initialized
INFO - 2016-08-23 22:44:05 --> Router Class Initialized
INFO - 2016-08-23 22:44:05 --> Output Class Initialized
INFO - 2016-08-23 22:44:05 --> Security Class Initialized
DEBUG - 2016-08-23 22:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:44:05 --> Input Class Initialized
INFO - 2016-08-23 22:44:05 --> Language Class Initialized
INFO - 2016-08-23 22:44:05 --> Loader Class Initialized
INFO - 2016-08-23 22:44:05 --> Helper loaded: url_helper
INFO - 2016-08-23 22:44:05 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:44:05 --> Helper loaded: html_helper
INFO - 2016-08-23 22:44:05 --> Helper loaded: form_helper
INFO - 2016-08-23 22:44:05 --> Helper loaded: file_helper
INFO - 2016-08-23 22:44:05 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:44:05 --> Database Driver Class Initialized
INFO - 2016-08-23 22:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:44:05 --> Form Validation Class Initialized
INFO - 2016-08-23 22:44:05 --> Email Class Initialized
INFO - 2016-08-23 22:44:05 --> Controller Class Initialized
INFO - 2016-08-23 22:44:05 --> Model Class Initialized
INFO - 2016-08-23 22:44:05 --> Model Class Initialized
DEBUG - 2016-08-23 22:44:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:44:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:44:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:44:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:44:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:44:06 --> Final output sent to browser
DEBUG - 2016-08-23 22:44:06 --> Total execution time: 0.6904
INFO - 2016-08-23 22:44:29 --> Config Class Initialized
INFO - 2016-08-23 22:44:29 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:44:29 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:44:29 --> Utf8 Class Initialized
INFO - 2016-08-23 22:44:29 --> URI Class Initialized
INFO - 2016-08-23 22:44:29 --> Router Class Initialized
INFO - 2016-08-23 22:44:29 --> Output Class Initialized
INFO - 2016-08-23 22:44:29 --> Security Class Initialized
DEBUG - 2016-08-23 22:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:44:29 --> Input Class Initialized
INFO - 2016-08-23 22:44:29 --> Language Class Initialized
INFO - 2016-08-23 22:44:29 --> Loader Class Initialized
INFO - 2016-08-23 22:44:29 --> Helper loaded: url_helper
INFO - 2016-08-23 22:44:29 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:44:29 --> Helper loaded: html_helper
INFO - 2016-08-23 22:44:29 --> Helper loaded: form_helper
INFO - 2016-08-23 22:44:29 --> Helper loaded: file_helper
INFO - 2016-08-23 22:44:29 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:44:29 --> Database Driver Class Initialized
INFO - 2016-08-23 22:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:44:29 --> Form Validation Class Initialized
INFO - 2016-08-23 22:44:29 --> Email Class Initialized
INFO - 2016-08-23 22:44:29 --> Controller Class Initialized
INFO - 2016-08-23 22:44:29 --> Model Class Initialized
INFO - 2016-08-23 22:44:29 --> Model Class Initialized
DEBUG - 2016-08-23 22:44:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:44:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:44:29 --> Final output sent to browser
DEBUG - 2016-08-23 22:44:29 --> Total execution time: 0.5088
INFO - 2016-08-23 22:45:05 --> Config Class Initialized
INFO - 2016-08-23 22:45:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:45:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:45:05 --> Utf8 Class Initialized
INFO - 2016-08-23 22:45:05 --> URI Class Initialized
INFO - 2016-08-23 22:45:05 --> Router Class Initialized
INFO - 2016-08-23 22:45:05 --> Output Class Initialized
INFO - 2016-08-23 22:45:05 --> Security Class Initialized
DEBUG - 2016-08-23 22:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:45:05 --> Input Class Initialized
INFO - 2016-08-23 22:45:05 --> Language Class Initialized
INFO - 2016-08-23 22:45:05 --> Loader Class Initialized
INFO - 2016-08-23 22:45:05 --> Helper loaded: url_helper
INFO - 2016-08-23 22:45:05 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:45:05 --> Helper loaded: html_helper
INFO - 2016-08-23 22:45:05 --> Helper loaded: form_helper
INFO - 2016-08-23 22:45:05 --> Helper loaded: file_helper
INFO - 2016-08-23 22:45:05 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:45:05 --> Database Driver Class Initialized
INFO - 2016-08-23 22:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:45:05 --> Form Validation Class Initialized
INFO - 2016-08-23 22:45:05 --> Email Class Initialized
INFO - 2016-08-23 22:45:05 --> Controller Class Initialized
INFO - 2016-08-23 22:45:05 --> Model Class Initialized
INFO - 2016-08-23 22:45:05 --> Model Class Initialized
DEBUG - 2016-08-23 22:45:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:45:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:45:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:45:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:45:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:45:05 --> Final output sent to browser
DEBUG - 2016-08-23 22:45:05 --> Total execution time: 0.4986
INFO - 2016-08-23 22:45:16 --> Config Class Initialized
INFO - 2016-08-23 22:45:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:45:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:45:16 --> Utf8 Class Initialized
INFO - 2016-08-23 22:45:16 --> URI Class Initialized
INFO - 2016-08-23 22:45:16 --> Router Class Initialized
INFO - 2016-08-23 22:45:16 --> Output Class Initialized
INFO - 2016-08-23 22:45:16 --> Security Class Initialized
DEBUG - 2016-08-23 22:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:45:16 --> Input Class Initialized
INFO - 2016-08-23 22:45:16 --> Language Class Initialized
INFO - 2016-08-23 22:45:16 --> Loader Class Initialized
INFO - 2016-08-23 22:45:16 --> Helper loaded: url_helper
INFO - 2016-08-23 22:45:16 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:45:16 --> Helper loaded: html_helper
INFO - 2016-08-23 22:45:16 --> Helper loaded: form_helper
INFO - 2016-08-23 22:45:16 --> Helper loaded: file_helper
INFO - 2016-08-23 22:45:17 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:45:17 --> Database Driver Class Initialized
INFO - 2016-08-23 22:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:45:17 --> Form Validation Class Initialized
INFO - 2016-08-23 22:45:17 --> Email Class Initialized
INFO - 2016-08-23 22:45:17 --> Controller Class Initialized
INFO - 2016-08-23 22:45:17 --> Model Class Initialized
INFO - 2016-08-23 22:45:17 --> Model Class Initialized
DEBUG - 2016-08-23 22:45:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:45:17 --> Final output sent to browser
DEBUG - 2016-08-23 22:45:17 --> Total execution time: 0.5093
INFO - 2016-08-23 22:45:27 --> Config Class Initialized
INFO - 2016-08-23 22:45:27 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:45:27 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:45:27 --> Utf8 Class Initialized
INFO - 2016-08-23 22:45:27 --> URI Class Initialized
INFO - 2016-08-23 22:45:27 --> Router Class Initialized
INFO - 2016-08-23 22:45:27 --> Output Class Initialized
INFO - 2016-08-23 22:45:27 --> Security Class Initialized
DEBUG - 2016-08-23 22:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:45:27 --> Input Class Initialized
INFO - 2016-08-23 22:45:27 --> Language Class Initialized
INFO - 2016-08-23 22:45:27 --> Loader Class Initialized
INFO - 2016-08-23 22:45:27 --> Helper loaded: url_helper
INFO - 2016-08-23 22:45:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:45:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:45:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:45:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:45:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:45:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:45:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:45:27 --> Email Class Initialized
INFO - 2016-08-23 22:45:27 --> Controller Class Initialized
INFO - 2016-08-23 22:45:27 --> Model Class Initialized
INFO - 2016-08-23 22:45:27 --> Model Class Initialized
DEBUG - 2016-08-23 22:45:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:45:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:45:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:45:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:45:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:45:28 --> Final output sent to browser
DEBUG - 2016-08-23 22:45:28 --> Total execution time: 0.5399
INFO - 2016-08-23 22:46:16 --> Config Class Initialized
INFO - 2016-08-23 22:46:16 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:46:16 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:46:16 --> Utf8 Class Initialized
INFO - 2016-08-23 22:46:16 --> URI Class Initialized
INFO - 2016-08-23 22:46:16 --> Router Class Initialized
INFO - 2016-08-23 22:46:16 --> Output Class Initialized
INFO - 2016-08-23 22:46:16 --> Security Class Initialized
DEBUG - 2016-08-23 22:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:46:16 --> Input Class Initialized
INFO - 2016-08-23 22:46:16 --> Language Class Initialized
INFO - 2016-08-23 22:46:16 --> Loader Class Initialized
INFO - 2016-08-23 22:46:16 --> Helper loaded: url_helper
INFO - 2016-08-23 22:46:16 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:46:16 --> Helper loaded: html_helper
INFO - 2016-08-23 22:46:16 --> Helper loaded: form_helper
INFO - 2016-08-23 22:46:16 --> Helper loaded: file_helper
INFO - 2016-08-23 22:46:16 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:46:16 --> Database Driver Class Initialized
INFO - 2016-08-23 22:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:46:16 --> Form Validation Class Initialized
INFO - 2016-08-23 22:46:16 --> Email Class Initialized
INFO - 2016-08-23 22:46:16 --> Controller Class Initialized
INFO - 2016-08-23 22:46:16 --> Model Class Initialized
INFO - 2016-08-23 22:46:16 --> Model Class Initialized
DEBUG - 2016-08-23 22:46:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:46:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:46:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:46:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:46:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:46:16 --> Final output sent to browser
DEBUG - 2016-08-23 22:46:16 --> Total execution time: 0.6306
INFO - 2016-08-23 22:46:37 --> Config Class Initialized
INFO - 2016-08-23 22:46:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:46:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:46:37 --> Utf8 Class Initialized
INFO - 2016-08-23 22:46:37 --> URI Class Initialized
INFO - 2016-08-23 22:46:37 --> Router Class Initialized
INFO - 2016-08-23 22:46:37 --> Output Class Initialized
INFO - 2016-08-23 22:46:37 --> Security Class Initialized
DEBUG - 2016-08-23 22:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:46:37 --> Input Class Initialized
INFO - 2016-08-23 22:46:37 --> Language Class Initialized
INFO - 2016-08-23 22:46:37 --> Loader Class Initialized
INFO - 2016-08-23 22:46:37 --> Helper loaded: url_helper
INFO - 2016-08-23 22:46:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:46:37 --> Helper loaded: html_helper
INFO - 2016-08-23 22:46:37 --> Helper loaded: form_helper
INFO - 2016-08-23 22:46:37 --> Helper loaded: file_helper
INFO - 2016-08-23 22:46:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:46:37 --> Database Driver Class Initialized
INFO - 2016-08-23 22:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:46:37 --> Form Validation Class Initialized
INFO - 2016-08-23 22:46:37 --> Email Class Initialized
INFO - 2016-08-23 22:46:37 --> Controller Class Initialized
DEBUG - 2016-08-23 22:46:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:46:37 --> Model Class Initialized
INFO - 2016-08-23 22:46:37 --> Model Class Initialized
INFO - 2016-08-23 22:46:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:46:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:46:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/edit.php
INFO - 2016-08-23 22:46:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:46:38 --> Final output sent to browser
DEBUG - 2016-08-23 22:46:38 --> Total execution time: 0.5152
INFO - 2016-08-23 22:47:38 --> Config Class Initialized
INFO - 2016-08-23 22:47:38 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:47:38 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:47:38 --> Utf8 Class Initialized
INFO - 2016-08-23 22:47:38 --> URI Class Initialized
INFO - 2016-08-23 22:47:38 --> Router Class Initialized
INFO - 2016-08-23 22:47:38 --> Output Class Initialized
INFO - 2016-08-23 22:47:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:47:39 --> Input Class Initialized
INFO - 2016-08-23 22:47:39 --> Language Class Initialized
INFO - 2016-08-23 22:47:39 --> Loader Class Initialized
INFO - 2016-08-23 22:47:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:47:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:47:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:47:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:47:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:47:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:47:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:47:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:47:39 --> Email Class Initialized
INFO - 2016-08-23 22:47:39 --> Controller Class Initialized
INFO - 2016-08-23 22:47:39 --> Model Class Initialized
INFO - 2016-08-23 22:47:39 --> Model Class Initialized
DEBUG - 2016-08-23 22:47:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:47:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:47:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:47:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:47:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:47:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:47:39 --> Total execution time: 0.5428
INFO - 2016-08-23 22:47:54 --> Config Class Initialized
INFO - 2016-08-23 22:47:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:47:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:47:54 --> Utf8 Class Initialized
INFO - 2016-08-23 22:47:54 --> URI Class Initialized
INFO - 2016-08-23 22:47:54 --> Router Class Initialized
INFO - 2016-08-23 22:47:54 --> Output Class Initialized
INFO - 2016-08-23 22:47:54 --> Security Class Initialized
DEBUG - 2016-08-23 22:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:47:54 --> Input Class Initialized
INFO - 2016-08-23 22:47:54 --> Language Class Initialized
INFO - 2016-08-23 22:47:54 --> Loader Class Initialized
INFO - 2016-08-23 22:47:54 --> Helper loaded: url_helper
INFO - 2016-08-23 22:47:54 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:47:54 --> Helper loaded: html_helper
INFO - 2016-08-23 22:47:54 --> Helper loaded: form_helper
INFO - 2016-08-23 22:47:54 --> Helper loaded: file_helper
INFO - 2016-08-23 22:47:54 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:47:54 --> Database Driver Class Initialized
INFO - 2016-08-23 22:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:47:54 --> Form Validation Class Initialized
INFO - 2016-08-23 22:47:54 --> Email Class Initialized
INFO - 2016-08-23 22:47:54 --> Controller Class Initialized
INFO - 2016-08-23 22:47:54 --> Model Class Initialized
INFO - 2016-08-23 22:47:54 --> Model Class Initialized
DEBUG - 2016-08-23 22:47:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:47:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:47:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:47:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:47:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:47:54 --> Final output sent to browser
DEBUG - 2016-08-23 22:47:54 --> Total execution time: 0.5275
INFO - 2016-08-23 22:48:00 --> Config Class Initialized
INFO - 2016-08-23 22:48:00 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:48:00 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:48:00 --> Utf8 Class Initialized
INFO - 2016-08-23 22:48:00 --> URI Class Initialized
INFO - 2016-08-23 22:48:00 --> Router Class Initialized
INFO - 2016-08-23 22:48:00 --> Output Class Initialized
INFO - 2016-08-23 22:48:00 --> Security Class Initialized
DEBUG - 2016-08-23 22:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:48:00 --> Input Class Initialized
INFO - 2016-08-23 22:48:00 --> Language Class Initialized
INFO - 2016-08-23 22:48:00 --> Loader Class Initialized
INFO - 2016-08-23 22:48:00 --> Helper loaded: url_helper
INFO - 2016-08-23 22:48:00 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:48:00 --> Helper loaded: html_helper
INFO - 2016-08-23 22:48:00 --> Helper loaded: form_helper
INFO - 2016-08-23 22:48:00 --> Helper loaded: file_helper
INFO - 2016-08-23 22:48:00 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:48:00 --> Database Driver Class Initialized
INFO - 2016-08-23 22:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:48:01 --> Form Validation Class Initialized
INFO - 2016-08-23 22:48:01 --> Email Class Initialized
INFO - 2016-08-23 22:48:01 --> Controller Class Initialized
INFO - 2016-08-23 22:48:01 --> Model Class Initialized
INFO - 2016-08-23 22:48:01 --> Model Class Initialized
DEBUG - 2016-08-23 22:48:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:48:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:48:01 --> Final output sent to browser
DEBUG - 2016-08-23 22:48:01 --> Total execution time: 0.5245
INFO - 2016-08-23 22:48:08 --> Config Class Initialized
INFO - 2016-08-23 22:48:08 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:48:08 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:48:08 --> Utf8 Class Initialized
INFO - 2016-08-23 22:48:08 --> URI Class Initialized
INFO - 2016-08-23 22:48:08 --> Router Class Initialized
INFO - 2016-08-23 22:48:08 --> Output Class Initialized
INFO - 2016-08-23 22:48:08 --> Security Class Initialized
DEBUG - 2016-08-23 22:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:48:08 --> Input Class Initialized
INFO - 2016-08-23 22:48:08 --> Language Class Initialized
INFO - 2016-08-23 22:48:08 --> Loader Class Initialized
INFO - 2016-08-23 22:48:08 --> Helper loaded: url_helper
INFO - 2016-08-23 22:48:08 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:48:08 --> Helper loaded: html_helper
INFO - 2016-08-23 22:48:08 --> Helper loaded: form_helper
INFO - 2016-08-23 22:48:08 --> Helper loaded: file_helper
INFO - 2016-08-23 22:48:08 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:48:08 --> Database Driver Class Initialized
INFO - 2016-08-23 22:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:48:08 --> Form Validation Class Initialized
INFO - 2016-08-23 22:48:08 --> Email Class Initialized
INFO - 2016-08-23 22:48:08 --> Controller Class Initialized
INFO - 2016-08-23 22:48:08 --> Model Class Initialized
INFO - 2016-08-23 22:48:08 --> Model Class Initialized
DEBUG - 2016-08-23 22:48:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:48:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:48:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:48:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:48:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:48:08 --> Final output sent to browser
DEBUG - 2016-08-23 22:48:08 --> Total execution time: 0.6298
INFO - 2016-08-23 22:48:10 --> Config Class Initialized
INFO - 2016-08-23 22:48:10 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:48:10 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:48:10 --> Utf8 Class Initialized
INFO - 2016-08-23 22:48:10 --> URI Class Initialized
INFO - 2016-08-23 22:48:10 --> Router Class Initialized
INFO - 2016-08-23 22:48:10 --> Output Class Initialized
INFO - 2016-08-23 22:48:10 --> Security Class Initialized
DEBUG - 2016-08-23 22:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:48:10 --> Input Class Initialized
INFO - 2016-08-23 22:48:10 --> Language Class Initialized
INFO - 2016-08-23 22:48:10 --> Loader Class Initialized
INFO - 2016-08-23 22:48:10 --> Helper loaded: url_helper
INFO - 2016-08-23 22:48:10 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:48:11 --> Helper loaded: html_helper
INFO - 2016-08-23 22:48:11 --> Helper loaded: form_helper
INFO - 2016-08-23 22:48:11 --> Helper loaded: file_helper
INFO - 2016-08-23 22:48:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:48:11 --> Database Driver Class Initialized
INFO - 2016-08-23 22:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:48:11 --> Form Validation Class Initialized
INFO - 2016-08-23 22:48:11 --> Email Class Initialized
INFO - 2016-08-23 22:48:11 --> Controller Class Initialized
INFO - 2016-08-23 22:48:11 --> Model Class Initialized
INFO - 2016-08-23 22:48:11 --> Model Class Initialized
DEBUG - 2016-08-23 22:48:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:48:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:48:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:48:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:48:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:48:11 --> Final output sent to browser
DEBUG - 2016-08-23 22:48:11 --> Total execution time: 0.5306
INFO - 2016-08-23 22:48:34 --> Config Class Initialized
INFO - 2016-08-23 22:48:34 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:48:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:48:35 --> Utf8 Class Initialized
INFO - 2016-08-23 22:48:35 --> URI Class Initialized
INFO - 2016-08-23 22:48:35 --> Router Class Initialized
INFO - 2016-08-23 22:48:35 --> Output Class Initialized
INFO - 2016-08-23 22:48:35 --> Security Class Initialized
DEBUG - 2016-08-23 22:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:48:35 --> Input Class Initialized
INFO - 2016-08-23 22:48:35 --> Language Class Initialized
INFO - 2016-08-23 22:48:35 --> Loader Class Initialized
INFO - 2016-08-23 22:48:35 --> Helper loaded: url_helper
INFO - 2016-08-23 22:48:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:48:35 --> Helper loaded: html_helper
INFO - 2016-08-23 22:48:35 --> Helper loaded: form_helper
INFO - 2016-08-23 22:48:35 --> Helper loaded: file_helper
INFO - 2016-08-23 22:48:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:48:35 --> Database Driver Class Initialized
INFO - 2016-08-23 22:48:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:48:35 --> Form Validation Class Initialized
INFO - 2016-08-23 22:48:35 --> Email Class Initialized
INFO - 2016-08-23 22:48:35 --> Controller Class Initialized
INFO - 2016-08-23 22:48:35 --> Model Class Initialized
INFO - 2016-08-23 22:48:35 --> Model Class Initialized
DEBUG - 2016-08-23 22:48:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:48:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:48:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:48:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:48:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:48:35 --> Final output sent to browser
DEBUG - 2016-08-23 22:48:35 --> Total execution time: 0.5287
INFO - 2016-08-23 22:48:38 --> Config Class Initialized
INFO - 2016-08-23 22:48:38 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:48:38 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:48:38 --> Utf8 Class Initialized
INFO - 2016-08-23 22:48:38 --> URI Class Initialized
INFO - 2016-08-23 22:48:38 --> Router Class Initialized
INFO - 2016-08-23 22:48:38 --> Output Class Initialized
INFO - 2016-08-23 22:48:38 --> Security Class Initialized
DEBUG - 2016-08-23 22:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:48:38 --> Input Class Initialized
INFO - 2016-08-23 22:48:38 --> Language Class Initialized
INFO - 2016-08-23 22:48:38 --> Loader Class Initialized
INFO - 2016-08-23 22:48:38 --> Helper loaded: url_helper
INFO - 2016-08-23 22:48:38 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:48:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:48:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:48:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:48:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:48:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:48:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:48:39 --> Email Class Initialized
INFO - 2016-08-23 22:48:39 --> Controller Class Initialized
INFO - 2016-08-23 22:48:39 --> Model Class Initialized
INFO - 2016-08-23 22:48:39 --> Model Class Initialized
DEBUG - 2016-08-23 22:48:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/edit_category.php
INFO - 2016-08-23 22:48:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:48:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:48:39 --> Total execution time: 0.5219
INFO - 2016-08-23 22:50:25 --> Config Class Initialized
INFO - 2016-08-23 22:50:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:50:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:50:25 --> Utf8 Class Initialized
INFO - 2016-08-23 22:50:25 --> URI Class Initialized
INFO - 2016-08-23 22:50:25 --> Router Class Initialized
INFO - 2016-08-23 22:50:25 --> Output Class Initialized
INFO - 2016-08-23 22:50:25 --> Security Class Initialized
DEBUG - 2016-08-23 22:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:50:25 --> Input Class Initialized
INFO - 2016-08-23 22:50:25 --> Language Class Initialized
INFO - 2016-08-23 22:50:25 --> Loader Class Initialized
INFO - 2016-08-23 22:50:25 --> Helper loaded: url_helper
INFO - 2016-08-23 22:50:25 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:50:25 --> Helper loaded: html_helper
INFO - 2016-08-23 22:50:25 --> Helper loaded: form_helper
INFO - 2016-08-23 22:50:25 --> Helper loaded: file_helper
INFO - 2016-08-23 22:50:25 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:50:26 --> Database Driver Class Initialized
INFO - 2016-08-23 22:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:50:26 --> Form Validation Class Initialized
INFO - 2016-08-23 22:50:26 --> Email Class Initialized
INFO - 2016-08-23 22:50:26 --> Controller Class Initialized
DEBUG - 2016-08-23 22:50:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:50:26 --> Model Class Initialized
INFO - 2016-08-23 22:50:26 --> Model Class Initialized
INFO - 2016-08-23 22:50:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:50:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:50:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:50:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:50:26 --> Final output sent to browser
DEBUG - 2016-08-23 22:50:26 --> Total execution time: 0.5296
INFO - 2016-08-23 22:50:28 --> Config Class Initialized
INFO - 2016-08-23 22:50:28 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:50:28 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:50:28 --> Utf8 Class Initialized
INFO - 2016-08-23 22:50:28 --> URI Class Initialized
INFO - 2016-08-23 22:50:28 --> Router Class Initialized
INFO - 2016-08-23 22:50:28 --> Output Class Initialized
INFO - 2016-08-23 22:50:28 --> Security Class Initialized
DEBUG - 2016-08-23 22:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:50:28 --> Input Class Initialized
INFO - 2016-08-23 22:50:28 --> Language Class Initialized
INFO - 2016-08-23 22:50:28 --> Loader Class Initialized
INFO - 2016-08-23 22:50:29 --> Helper loaded: url_helper
INFO - 2016-08-23 22:50:29 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:50:29 --> Helper loaded: html_helper
INFO - 2016-08-23 22:50:29 --> Helper loaded: form_helper
INFO - 2016-08-23 22:50:29 --> Helper loaded: file_helper
INFO - 2016-08-23 22:50:29 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:50:29 --> Database Driver Class Initialized
INFO - 2016-08-23 22:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:50:29 --> Form Validation Class Initialized
INFO - 2016-08-23 22:50:29 --> Email Class Initialized
INFO - 2016-08-23 22:50:29 --> Controller Class Initialized
DEBUG - 2016-08-23 22:50:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:50:29 --> Model Class Initialized
INFO - 2016-08-23 22:50:29 --> Model Class Initialized
INFO - 2016-08-23 22:50:29 --> Model Class Initialized
INFO - 2016-08-23 22:50:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:50:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:50:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-23 22:50:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:50:29 --> Final output sent to browser
DEBUG - 2016-08-23 22:50:29 --> Total execution time: 0.5586
INFO - 2016-08-23 22:50:32 --> Config Class Initialized
INFO - 2016-08-23 22:50:33 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:50:33 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:50:33 --> Utf8 Class Initialized
INFO - 2016-08-23 22:50:33 --> URI Class Initialized
INFO - 2016-08-23 22:50:33 --> Router Class Initialized
INFO - 2016-08-23 22:50:33 --> Output Class Initialized
INFO - 2016-08-23 22:50:33 --> Security Class Initialized
DEBUG - 2016-08-23 22:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:50:33 --> Input Class Initialized
INFO - 2016-08-23 22:50:33 --> Language Class Initialized
INFO - 2016-08-23 22:50:33 --> Loader Class Initialized
INFO - 2016-08-23 22:50:33 --> Helper loaded: url_helper
INFO - 2016-08-23 22:50:33 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:50:33 --> Helper loaded: html_helper
INFO - 2016-08-23 22:50:33 --> Helper loaded: form_helper
INFO - 2016-08-23 22:50:33 --> Helper loaded: file_helper
INFO - 2016-08-23 22:50:33 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:50:33 --> Database Driver Class Initialized
INFO - 2016-08-23 22:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:50:33 --> Form Validation Class Initialized
INFO - 2016-08-23 22:50:33 --> Email Class Initialized
INFO - 2016-08-23 22:50:33 --> Controller Class Initialized
DEBUG - 2016-08-23 22:50:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:50:33 --> Model Class Initialized
INFO - 2016-08-23 22:50:33 --> Model Class Initialized
INFO - 2016-08-23 22:50:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:50:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:50:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:50:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:50:33 --> Final output sent to browser
DEBUG - 2016-08-23 22:50:33 --> Total execution time: 0.6200
INFO - 2016-08-23 22:51:01 --> Config Class Initialized
INFO - 2016-08-23 22:51:01 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:01 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:01 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:01 --> URI Class Initialized
INFO - 2016-08-23 22:51:01 --> Router Class Initialized
INFO - 2016-08-23 22:51:01 --> Output Class Initialized
INFO - 2016-08-23 22:51:01 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:01 --> Input Class Initialized
INFO - 2016-08-23 22:51:01 --> Language Class Initialized
INFO - 2016-08-23 22:51:01 --> Loader Class Initialized
INFO - 2016-08-23 22:51:01 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:01 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:01 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:01 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:01 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:01 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:01 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:02 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:02 --> Email Class Initialized
INFO - 2016-08-23 22:51:02 --> Controller Class Initialized
INFO - 2016-08-23 22:51:02 --> Model Class Initialized
INFO - 2016-08-23 22:51:02 --> Model Class Initialized
DEBUG - 2016-08-23 22:51:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:51:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/add_category.php
INFO - 2016-08-23 22:51:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:02 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:02 --> Total execution time: 0.5254
INFO - 2016-08-23 22:51:08 --> Config Class Initialized
INFO - 2016-08-23 22:51:08 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:08 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:08 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:08 --> URI Class Initialized
INFO - 2016-08-23 22:51:08 --> Router Class Initialized
INFO - 2016-08-23 22:51:08 --> Output Class Initialized
INFO - 2016-08-23 22:51:08 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:08 --> Input Class Initialized
INFO - 2016-08-23 22:51:08 --> Language Class Initialized
INFO - 2016-08-23 22:51:08 --> Loader Class Initialized
INFO - 2016-08-23 22:51:08 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:08 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:08 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:08 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:08 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:08 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:08 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:08 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:08 --> Email Class Initialized
INFO - 2016-08-23 22:51:09 --> Controller Class Initialized
INFO - 2016-08-23 22:51:09 --> Model Class Initialized
INFO - 2016-08-23 22:51:09 --> Model Class Initialized
DEBUG - 2016-08-23 22:51:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:51:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:51:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:09 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:09 --> Total execution time: 0.6684
INFO - 2016-08-23 22:51:21 --> Config Class Initialized
INFO - 2016-08-23 22:51:21 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:21 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:21 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:21 --> URI Class Initialized
INFO - 2016-08-23 22:51:21 --> Router Class Initialized
INFO - 2016-08-23 22:51:21 --> Output Class Initialized
INFO - 2016-08-23 22:51:21 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:22 --> Input Class Initialized
INFO - 2016-08-23 22:51:22 --> Language Class Initialized
INFO - 2016-08-23 22:51:22 --> Loader Class Initialized
INFO - 2016-08-23 22:51:22 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:22 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:22 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:22 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:22 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:22 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:22 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:22 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:22 --> Email Class Initialized
INFO - 2016-08-23 22:51:22 --> Controller Class Initialized
DEBUG - 2016-08-23 22:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:51:22 --> Model Class Initialized
INFO - 2016-08-23 22:51:22 --> Model Class Initialized
INFO - 2016-08-23 22:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-23 22:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:22 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:22 --> Total execution time: 0.5510
INFO - 2016-08-23 22:51:27 --> Config Class Initialized
INFO - 2016-08-23 22:51:27 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:27 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:27 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:27 --> URI Class Initialized
INFO - 2016-08-23 22:51:27 --> Router Class Initialized
INFO - 2016-08-23 22:51:27 --> Output Class Initialized
INFO - 2016-08-23 22:51:27 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:27 --> Input Class Initialized
INFO - 2016-08-23 22:51:27 --> Language Class Initialized
INFO - 2016-08-23 22:51:27 --> Loader Class Initialized
INFO - 2016-08-23 22:51:27 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:27 --> Email Class Initialized
INFO - 2016-08-23 22:51:27 --> Controller Class Initialized
INFO - 2016-08-23 22:51:27 --> Model Class Initialized
INFO - 2016-08-23 22:51:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:51:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:28 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:28 --> Total execution time: 0.6042
INFO - 2016-08-23 22:51:35 --> Config Class Initialized
INFO - 2016-08-23 22:51:35 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:35 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:35 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:35 --> URI Class Initialized
INFO - 2016-08-23 22:51:35 --> Router Class Initialized
INFO - 2016-08-23 22:51:35 --> Output Class Initialized
INFO - 2016-08-23 22:51:35 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:35 --> Input Class Initialized
INFO - 2016-08-23 22:51:35 --> Language Class Initialized
INFO - 2016-08-23 22:51:35 --> Loader Class Initialized
INFO - 2016-08-23 22:51:35 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:35 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:35 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:35 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:35 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:35 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:35 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:35 --> Email Class Initialized
INFO - 2016-08-23 22:51:35 --> Controller Class Initialized
INFO - 2016-08-23 22:51:35 --> Model Class Initialized
INFO - 2016-08-23 22:51:35 --> Model Class Initialized
DEBUG - 2016-08-23 22:51:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:51:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-23 22:51:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:35 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:35 --> Total execution time: 0.5735
INFO - 2016-08-23 22:51:37 --> Config Class Initialized
INFO - 2016-08-23 22:51:37 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:51:37 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:51:37 --> Utf8 Class Initialized
INFO - 2016-08-23 22:51:37 --> URI Class Initialized
INFO - 2016-08-23 22:51:37 --> Router Class Initialized
INFO - 2016-08-23 22:51:37 --> Output Class Initialized
INFO - 2016-08-23 22:51:37 --> Security Class Initialized
DEBUG - 2016-08-23 22:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:51:37 --> Input Class Initialized
INFO - 2016-08-23 22:51:37 --> Language Class Initialized
INFO - 2016-08-23 22:51:37 --> Loader Class Initialized
INFO - 2016-08-23 22:51:37 --> Helper loaded: url_helper
INFO - 2016-08-23 22:51:37 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:51:37 --> Helper loaded: html_helper
INFO - 2016-08-23 22:51:37 --> Helper loaded: form_helper
INFO - 2016-08-23 22:51:37 --> Helper loaded: file_helper
INFO - 2016-08-23 22:51:37 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:51:37 --> Database Driver Class Initialized
INFO - 2016-08-23 22:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:51:37 --> Form Validation Class Initialized
INFO - 2016-08-23 22:51:37 --> Email Class Initialized
INFO - 2016-08-23 22:51:37 --> Controller Class Initialized
INFO - 2016-08-23 22:51:38 --> Model Class Initialized
INFO - 2016-08-23 22:51:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:51:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:51:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-23 22:51:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:51:38 --> Final output sent to browser
DEBUG - 2016-08-23 22:51:38 --> Total execution time: 0.5155
INFO - 2016-08-23 22:52:33 --> Config Class Initialized
INFO - 2016-08-23 22:52:33 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:52:33 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:52:33 --> Utf8 Class Initialized
INFO - 2016-08-23 22:52:33 --> URI Class Initialized
INFO - 2016-08-23 22:52:33 --> Router Class Initialized
INFO - 2016-08-23 22:52:33 --> Output Class Initialized
INFO - 2016-08-23 22:52:33 --> Security Class Initialized
DEBUG - 2016-08-23 22:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:52:33 --> Input Class Initialized
INFO - 2016-08-23 22:52:33 --> Language Class Initialized
INFO - 2016-08-23 22:52:33 --> Loader Class Initialized
INFO - 2016-08-23 22:52:33 --> Helper loaded: url_helper
INFO - 2016-08-23 22:52:33 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:52:33 --> Helper loaded: html_helper
INFO - 2016-08-23 22:52:33 --> Helper loaded: form_helper
INFO - 2016-08-23 22:52:33 --> Helper loaded: file_helper
INFO - 2016-08-23 22:52:33 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:52:34 --> Database Driver Class Initialized
INFO - 2016-08-23 22:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:52:34 --> Form Validation Class Initialized
INFO - 2016-08-23 22:52:34 --> Email Class Initialized
INFO - 2016-08-23 22:52:34 --> Controller Class Initialized
DEBUG - 2016-08-23 22:52:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:52:34 --> Model Class Initialized
INFO - 2016-08-23 22:52:34 --> Model Class Initialized
INFO - 2016-08-23 22:52:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:52:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:52:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-23 22:52:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:52:34 --> Final output sent to browser
DEBUG - 2016-08-23 22:52:34 --> Total execution time: 0.7756
INFO - 2016-08-23 22:52:39 --> Config Class Initialized
INFO - 2016-08-23 22:52:39 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:52:39 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:52:39 --> Utf8 Class Initialized
INFO - 2016-08-23 22:52:39 --> URI Class Initialized
INFO - 2016-08-23 22:52:39 --> Router Class Initialized
INFO - 2016-08-23 22:52:39 --> Output Class Initialized
INFO - 2016-08-23 22:52:39 --> Security Class Initialized
DEBUG - 2016-08-23 22:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:52:39 --> Input Class Initialized
INFO - 2016-08-23 22:52:39 --> Language Class Initialized
INFO - 2016-08-23 22:52:39 --> Loader Class Initialized
INFO - 2016-08-23 22:52:39 --> Helper loaded: url_helper
INFO - 2016-08-23 22:52:39 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:52:39 --> Helper loaded: html_helper
INFO - 2016-08-23 22:52:39 --> Helper loaded: form_helper
INFO - 2016-08-23 22:52:39 --> Helper loaded: file_helper
INFO - 2016-08-23 22:52:39 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:52:39 --> Database Driver Class Initialized
INFO - 2016-08-23 22:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:52:39 --> Form Validation Class Initialized
INFO - 2016-08-23 22:52:39 --> Email Class Initialized
INFO - 2016-08-23 22:52:39 --> Controller Class Initialized
INFO - 2016-08-23 22:52:39 --> Model Class Initialized
INFO - 2016-08-23 22:52:39 --> Model Class Initialized
INFO - 2016-08-23 22:52:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:52:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:52:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-23 22:52:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:52:39 --> Final output sent to browser
DEBUG - 2016-08-23 22:52:39 --> Total execution time: 0.5042
INFO - 2016-08-23 22:52:42 --> Config Class Initialized
INFO - 2016-08-23 22:52:42 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:52:42 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:52:42 --> Utf8 Class Initialized
INFO - 2016-08-23 22:52:42 --> URI Class Initialized
INFO - 2016-08-23 22:52:42 --> Router Class Initialized
INFO - 2016-08-23 22:52:42 --> Output Class Initialized
INFO - 2016-08-23 22:52:42 --> Security Class Initialized
DEBUG - 2016-08-23 22:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:52:42 --> Input Class Initialized
INFO - 2016-08-23 22:52:42 --> Language Class Initialized
INFO - 2016-08-23 22:52:42 --> Loader Class Initialized
INFO - 2016-08-23 22:52:42 --> Helper loaded: url_helper
INFO - 2016-08-23 22:52:42 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:52:42 --> Helper loaded: html_helper
INFO - 2016-08-23 22:52:42 --> Helper loaded: form_helper
INFO - 2016-08-23 22:52:42 --> Helper loaded: file_helper
INFO - 2016-08-23 22:52:42 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:52:42 --> Database Driver Class Initialized
INFO - 2016-08-23 22:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:52:42 --> Form Validation Class Initialized
INFO - 2016-08-23 22:52:42 --> Email Class Initialized
INFO - 2016-08-23 22:52:42 --> Controller Class Initialized
INFO - 2016-08-23 22:52:42 --> Model Class Initialized
INFO - 2016-08-23 22:52:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:52:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:52:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-23 22:52:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:52:42 --> Final output sent to browser
DEBUG - 2016-08-23 22:52:42 --> Total execution time: 0.5484
INFO - 2016-08-23 22:52:52 --> Config Class Initialized
INFO - 2016-08-23 22:52:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:52:53 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:52:53 --> Utf8 Class Initialized
INFO - 2016-08-23 22:52:53 --> URI Class Initialized
INFO - 2016-08-23 22:52:53 --> Router Class Initialized
INFO - 2016-08-23 22:52:53 --> Output Class Initialized
INFO - 2016-08-23 22:52:53 --> Security Class Initialized
DEBUG - 2016-08-23 22:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:52:53 --> Input Class Initialized
INFO - 2016-08-23 22:52:53 --> Language Class Initialized
INFO - 2016-08-23 22:52:53 --> Loader Class Initialized
INFO - 2016-08-23 22:52:53 --> Helper loaded: url_helper
INFO - 2016-08-23 22:52:53 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:52:53 --> Helper loaded: html_helper
INFO - 2016-08-23 22:52:53 --> Helper loaded: form_helper
INFO - 2016-08-23 22:52:53 --> Helper loaded: file_helper
INFO - 2016-08-23 22:52:53 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:52:53 --> Database Driver Class Initialized
INFO - 2016-08-23 22:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:52:53 --> Form Validation Class Initialized
INFO - 2016-08-23 22:52:53 --> Email Class Initialized
INFO - 2016-08-23 22:52:53 --> Controller Class Initialized
DEBUG - 2016-08-23 22:52:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:52:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:52:53 --> Model Class Initialized
INFO - 2016-08-23 22:52:53 --> Model Class Initialized
INFO - 2016-08-23 22:52:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:52:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:52:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:52:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:52:53 --> Final output sent to browser
DEBUG - 2016-08-23 22:52:53 --> Total execution time: 0.5874
INFO - 2016-08-23 22:52:57 --> Config Class Initialized
INFO - 2016-08-23 22:52:57 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:52:58 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:52:58 --> Utf8 Class Initialized
INFO - 2016-08-23 22:52:58 --> URI Class Initialized
INFO - 2016-08-23 22:52:58 --> Router Class Initialized
INFO - 2016-08-23 22:52:58 --> Output Class Initialized
INFO - 2016-08-23 22:52:58 --> Security Class Initialized
DEBUG - 2016-08-23 22:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:52:58 --> Input Class Initialized
INFO - 2016-08-23 22:52:58 --> Language Class Initialized
INFO - 2016-08-23 22:52:58 --> Loader Class Initialized
INFO - 2016-08-23 22:52:58 --> Helper loaded: url_helper
INFO - 2016-08-23 22:52:58 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:52:58 --> Helper loaded: html_helper
INFO - 2016-08-23 22:52:58 --> Helper loaded: form_helper
INFO - 2016-08-23 22:52:58 --> Helper loaded: file_helper
INFO - 2016-08-23 22:52:58 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:52:58 --> Database Driver Class Initialized
INFO - 2016-08-23 22:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:52:58 --> Form Validation Class Initialized
INFO - 2016-08-23 22:52:58 --> Email Class Initialized
INFO - 2016-08-23 22:52:58 --> Controller Class Initialized
DEBUG - 2016-08-23 22:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:52:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:52:58 --> Model Class Initialized
INFO - 2016-08-23 22:52:58 --> Model Class Initialized
INFO - 2016-08-23 22:52:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:52:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:52:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/borrowing.php
INFO - 2016-08-23 22:52:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:52:58 --> Final output sent to browser
DEBUG - 2016-08-23 22:52:58 --> Total execution time: 0.8870
INFO - 2016-08-23 22:53:54 --> Config Class Initialized
INFO - 2016-08-23 22:53:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:53:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:53:54 --> Utf8 Class Initialized
INFO - 2016-08-23 22:53:54 --> URI Class Initialized
DEBUG - 2016-08-23 22:53:54 --> No URI present. Default controller set.
INFO - 2016-08-23 22:53:54 --> Router Class Initialized
INFO - 2016-08-23 22:53:54 --> Output Class Initialized
INFO - 2016-08-23 22:53:54 --> Security Class Initialized
DEBUG - 2016-08-23 22:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:53:54 --> Input Class Initialized
INFO - 2016-08-23 22:53:54 --> Language Class Initialized
INFO - 2016-08-23 22:53:54 --> Loader Class Initialized
INFO - 2016-08-23 22:53:54 --> Helper loaded: url_helper
INFO - 2016-08-23 22:53:54 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:53:54 --> Helper loaded: html_helper
INFO - 2016-08-23 22:53:54 --> Helper loaded: form_helper
INFO - 2016-08-23 22:53:54 --> Helper loaded: file_helper
INFO - 2016-08-23 22:53:54 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:53:54 --> Database Driver Class Initialized
INFO - 2016-08-23 22:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:53:54 --> Form Validation Class Initialized
INFO - 2016-08-23 22:53:54 --> Email Class Initialized
INFO - 2016-08-23 22:53:54 --> Controller Class Initialized
INFO - 2016-08-23 22:53:54 --> Config Class Initialized
INFO - 2016-08-23 22:53:54 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:53:54 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:53:54 --> Utf8 Class Initialized
INFO - 2016-08-23 22:53:54 --> URI Class Initialized
INFO - 2016-08-23 22:53:54 --> Router Class Initialized
INFO - 2016-08-23 22:53:54 --> Output Class Initialized
INFO - 2016-08-23 22:53:54 --> Security Class Initialized
DEBUG - 2016-08-23 22:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:53:55 --> Input Class Initialized
INFO - 2016-08-23 22:53:55 --> Language Class Initialized
INFO - 2016-08-23 22:53:55 --> Loader Class Initialized
INFO - 2016-08-23 22:53:55 --> Helper loaded: url_helper
INFO - 2016-08-23 22:53:55 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:53:55 --> Helper loaded: html_helper
INFO - 2016-08-23 22:53:55 --> Helper loaded: form_helper
INFO - 2016-08-23 22:53:55 --> Helper loaded: file_helper
INFO - 2016-08-23 22:53:55 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:53:55 --> Database Driver Class Initialized
INFO - 2016-08-23 22:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:53:55 --> Form Validation Class Initialized
INFO - 2016-08-23 22:53:55 --> Email Class Initialized
INFO - 2016-08-23 22:53:55 --> Controller Class Initialized
INFO - 2016-08-23 22:53:55 --> Model Class Initialized
DEBUG - 2016-08-23 22:53:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:53:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-23 22:53:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:53:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-23 22:53:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:53:55 --> Final output sent to browser
DEBUG - 2016-08-23 22:53:55 --> Total execution time: 0.5083
INFO - 2016-08-23 22:54:05 --> Config Class Initialized
INFO - 2016-08-23 22:54:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:05 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:05 --> URI Class Initialized
INFO - 2016-08-23 22:54:05 --> Router Class Initialized
INFO - 2016-08-23 22:54:05 --> Output Class Initialized
INFO - 2016-08-23 22:54:05 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:05 --> Input Class Initialized
INFO - 2016-08-23 22:54:05 --> Language Class Initialized
ERROR - 2016-08-23 22:54:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-23 22:54:11 --> Config Class Initialized
INFO - 2016-08-23 22:54:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:11 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:11 --> URI Class Initialized
INFO - 2016-08-23 22:54:11 --> Router Class Initialized
INFO - 2016-08-23 22:54:11 --> Output Class Initialized
INFO - 2016-08-23 22:54:11 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:11 --> Input Class Initialized
INFO - 2016-08-23 22:54:11 --> Language Class Initialized
INFO - 2016-08-23 22:54:11 --> Loader Class Initialized
INFO - 2016-08-23 22:54:11 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:11 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:11 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:11 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:11 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:11 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:11 --> Email Class Initialized
INFO - 2016-08-23 22:54:12 --> Controller Class Initialized
INFO - 2016-08-23 22:54:12 --> Model Class Initialized
INFO - 2016-08-23 22:54:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-23 22:54:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:12 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:12 --> Total execution time: 0.5314
INFO - 2016-08-23 22:54:25 --> Config Class Initialized
INFO - 2016-08-23 22:54:25 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:25 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:25 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:25 --> URI Class Initialized
INFO - 2016-08-23 22:54:26 --> Router Class Initialized
INFO - 2016-08-23 22:54:26 --> Output Class Initialized
INFO - 2016-08-23 22:54:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:26 --> Input Class Initialized
INFO - 2016-08-23 22:54:26 --> Language Class Initialized
INFO - 2016-08-23 22:54:26 --> Loader Class Initialized
INFO - 2016-08-23 22:54:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:26 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:26 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:26 --> Email Class Initialized
INFO - 2016-08-23 22:54:26 --> Controller Class Initialized
INFO - 2016-08-23 22:54:26 --> Model Class Initialized
DEBUG - 2016-08-23 22:54:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-23 22:54:26 --> Config Class Initialized
INFO - 2016-08-23 22:54:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:26 --> URI Class Initialized
DEBUG - 2016-08-23 22:54:26 --> No URI present. Default controller set.
INFO - 2016-08-23 22:54:26 --> Router Class Initialized
INFO - 2016-08-23 22:54:26 --> Output Class Initialized
INFO - 2016-08-23 22:54:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:26 --> Input Class Initialized
INFO - 2016-08-23 22:54:26 --> Language Class Initialized
INFO - 2016-08-23 22:54:26 --> Loader Class Initialized
INFO - 2016-08-23 22:54:26 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:26 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:26 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:26 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:26 --> Email Class Initialized
INFO - 2016-08-23 22:54:26 --> Controller Class Initialized
INFO - 2016-08-23 22:54:26 --> Config Class Initialized
INFO - 2016-08-23 22:54:26 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:26 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:26 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:26 --> URI Class Initialized
INFO - 2016-08-23 22:54:26 --> Router Class Initialized
INFO - 2016-08-23 22:54:26 --> Output Class Initialized
INFO - 2016-08-23 22:54:26 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:27 --> Input Class Initialized
INFO - 2016-08-23 22:54:27 --> Language Class Initialized
INFO - 2016-08-23 22:54:27 --> Loader Class Initialized
INFO - 2016-08-23 22:54:27 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:27 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:27 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:27 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:27 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:27 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:27 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:27 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:27 --> Email Class Initialized
INFO - 2016-08-23 22:54:27 --> Controller Class Initialized
INFO - 2016-08-23 22:54:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-23 22:54:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:27 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:27 --> Total execution time: 0.4750
INFO - 2016-08-23 22:54:34 --> Config Class Initialized
INFO - 2016-08-23 22:54:34 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:34 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:34 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:34 --> URI Class Initialized
INFO - 2016-08-23 22:54:34 --> Router Class Initialized
INFO - 2016-08-23 22:54:34 --> Output Class Initialized
INFO - 2016-08-23 22:54:34 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:34 --> Input Class Initialized
INFO - 2016-08-23 22:54:34 --> Language Class Initialized
INFO - 2016-08-23 22:54:34 --> Loader Class Initialized
INFO - 2016-08-23 22:54:34 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:34 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:34 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:34 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:34 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:35 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:35 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:35 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:35 --> Email Class Initialized
INFO - 2016-08-23 22:54:35 --> Controller Class Initialized
DEBUG - 2016-08-23 22:54:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:35 --> Model Class Initialized
INFO - 2016-08-23 22:54:35 --> Model Class Initialized
INFO - 2016-08-23 22:54:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-23 22:54:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:35 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:35 --> Total execution time: 0.7597
INFO - 2016-08-23 22:54:41 --> Config Class Initialized
INFO - 2016-08-23 22:54:41 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:41 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:41 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:41 --> URI Class Initialized
INFO - 2016-08-23 22:54:41 --> Router Class Initialized
INFO - 2016-08-23 22:54:41 --> Output Class Initialized
INFO - 2016-08-23 22:54:41 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:41 --> Input Class Initialized
INFO - 2016-08-23 22:54:41 --> Language Class Initialized
INFO - 2016-08-23 22:54:41 --> Loader Class Initialized
INFO - 2016-08-23 22:54:41 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:41 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:41 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:41 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:41 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:41 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:41 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:41 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:41 --> Email Class Initialized
INFO - 2016-08-23 22:54:41 --> Controller Class Initialized
DEBUG - 2016-08-23 22:54:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:42 --> Model Class Initialized
INFO - 2016-08-23 22:54:42 --> Model Class Initialized
INFO - 2016-08-23 22:54:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-23 22:54:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:42 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:42 --> Total execution time: 0.5852
INFO - 2016-08-23 22:54:49 --> Config Class Initialized
INFO - 2016-08-23 22:54:49 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:49 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:49 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:49 --> URI Class Initialized
INFO - 2016-08-23 22:54:49 --> Router Class Initialized
INFO - 2016-08-23 22:54:49 --> Output Class Initialized
INFO - 2016-08-23 22:54:49 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:49 --> Input Class Initialized
INFO - 2016-08-23 22:54:49 --> Language Class Initialized
INFO - 2016-08-23 22:54:49 --> Loader Class Initialized
INFO - 2016-08-23 22:54:49 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:49 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:49 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:49 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:49 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:49 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:49 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:49 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:49 --> Email Class Initialized
INFO - 2016-08-23 22:54:49 --> Controller Class Initialized
DEBUG - 2016-08-23 22:54:49 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:49 --> Model Class Initialized
INFO - 2016-08-23 22:54:49 --> Model Class Initialized
INFO - 2016-08-23 22:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-23 22:54:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:49 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:49 --> Total execution time: 0.5709
INFO - 2016-08-23 22:54:52 --> Config Class Initialized
INFO - 2016-08-23 22:54:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:52 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:52 --> URI Class Initialized
INFO - 2016-08-23 22:54:52 --> Router Class Initialized
INFO - 2016-08-23 22:54:52 --> Output Class Initialized
INFO - 2016-08-23 22:54:52 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:52 --> Input Class Initialized
INFO - 2016-08-23 22:54:52 --> Language Class Initialized
INFO - 2016-08-23 22:54:52 --> Loader Class Initialized
INFO - 2016-08-23 22:54:52 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:52 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:52 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:52 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:52 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:52 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:52 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:52 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:52 --> Email Class Initialized
INFO - 2016-08-23 22:54:52 --> Controller Class Initialized
DEBUG - 2016-08-23 22:54:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:52 --> Model Class Initialized
INFO - 2016-08-23 22:54:52 --> Model Class Initialized
INFO - 2016-08-23 22:54:52 --> Config Class Initialized
INFO - 2016-08-23 22:54:52 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:54:52 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:54:52 --> Utf8 Class Initialized
INFO - 2016-08-23 22:54:52 --> URI Class Initialized
INFO - 2016-08-23 22:54:52 --> Router Class Initialized
INFO - 2016-08-23 22:54:52 --> Output Class Initialized
INFO - 2016-08-23 22:54:53 --> Security Class Initialized
DEBUG - 2016-08-23 22:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:54:53 --> Input Class Initialized
INFO - 2016-08-23 22:54:53 --> Language Class Initialized
INFO - 2016-08-23 22:54:53 --> Loader Class Initialized
INFO - 2016-08-23 22:54:53 --> Helper loaded: url_helper
INFO - 2016-08-23 22:54:53 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:54:53 --> Helper loaded: html_helper
INFO - 2016-08-23 22:54:53 --> Helper loaded: form_helper
INFO - 2016-08-23 22:54:53 --> Helper loaded: file_helper
INFO - 2016-08-23 22:54:53 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:54:53 --> Database Driver Class Initialized
INFO - 2016-08-23 22:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:54:53 --> Form Validation Class Initialized
INFO - 2016-08-23 22:54:53 --> Email Class Initialized
INFO - 2016-08-23 22:54:53 --> Controller Class Initialized
DEBUG - 2016-08-23 22:54:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:54:53 --> Model Class Initialized
INFO - 2016-08-23 22:54:53 --> Model Class Initialized
INFO - 2016-08-23 22:54:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:54:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:54:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-23 22:54:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:54:53 --> Final output sent to browser
DEBUG - 2016-08-23 22:54:53 --> Total execution time: 0.5751
INFO - 2016-08-23 22:55:07 --> Config Class Initialized
INFO - 2016-08-23 22:55:07 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:55:07 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:55:07 --> Utf8 Class Initialized
INFO - 2016-08-23 22:55:07 --> URI Class Initialized
INFO - 2016-08-23 22:55:07 --> Router Class Initialized
INFO - 2016-08-23 22:55:07 --> Output Class Initialized
INFO - 2016-08-23 22:55:07 --> Security Class Initialized
DEBUG - 2016-08-23 22:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:55:07 --> Input Class Initialized
INFO - 2016-08-23 22:55:07 --> Language Class Initialized
INFO - 2016-08-23 22:55:07 --> Loader Class Initialized
INFO - 2016-08-23 22:55:07 --> Helper loaded: url_helper
INFO - 2016-08-23 22:55:07 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:55:07 --> Helper loaded: html_helper
INFO - 2016-08-23 22:55:07 --> Helper loaded: form_helper
INFO - 2016-08-23 22:55:07 --> Helper loaded: file_helper
INFO - 2016-08-23 22:55:07 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:55:07 --> Database Driver Class Initialized
INFO - 2016-08-23 22:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:55:08 --> Form Validation Class Initialized
INFO - 2016-08-23 22:55:08 --> Email Class Initialized
INFO - 2016-08-23 22:55:08 --> Controller Class Initialized
DEBUG - 2016-08-23 22:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:55:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:55:08 --> Model Class Initialized
INFO - 2016-08-23 22:55:08 --> Model Class Initialized
INFO - 2016-08-23 22:55:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:55:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:55:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-23 22:55:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:55:08 --> Final output sent to browser
DEBUG - 2016-08-23 22:55:08 --> Total execution time: 0.5987
INFO - 2016-08-23 22:55:11 --> Config Class Initialized
INFO - 2016-08-23 22:55:11 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:55:11 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:55:11 --> Utf8 Class Initialized
INFO - 2016-08-23 22:55:11 --> URI Class Initialized
INFO - 2016-08-23 22:55:11 --> Router Class Initialized
INFO - 2016-08-23 22:55:11 --> Output Class Initialized
INFO - 2016-08-23 22:55:11 --> Security Class Initialized
DEBUG - 2016-08-23 22:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:55:11 --> Input Class Initialized
INFO - 2016-08-23 22:55:11 --> Language Class Initialized
INFO - 2016-08-23 22:55:11 --> Loader Class Initialized
INFO - 2016-08-23 22:55:11 --> Helper loaded: url_helper
INFO - 2016-08-23 22:55:11 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:55:11 --> Helper loaded: html_helper
INFO - 2016-08-23 22:55:11 --> Helper loaded: form_helper
INFO - 2016-08-23 22:55:11 --> Helper loaded: file_helper
INFO - 2016-08-23 22:55:11 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:55:11 --> Database Driver Class Initialized
INFO - 2016-08-23 22:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:55:11 --> Form Validation Class Initialized
INFO - 2016-08-23 22:55:11 --> Email Class Initialized
INFO - 2016-08-23 22:55:11 --> Controller Class Initialized
DEBUG - 2016-08-23 22:55:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-23 22:55:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:55:11 --> Model Class Initialized
INFO - 2016-08-23 22:55:11 --> Model Class Initialized
INFO - 2016-08-23 22:55:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:55:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:55:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/borrowing.php
INFO - 2016-08-23 22:55:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:55:11 --> Final output sent to browser
DEBUG - 2016-08-23 22:55:11 --> Total execution time: 0.5480
INFO - 2016-08-23 22:56:02 --> Config Class Initialized
INFO - 2016-08-23 22:56:02 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:56:02 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:56:02 --> Utf8 Class Initialized
INFO - 2016-08-23 22:56:02 --> URI Class Initialized
INFO - 2016-08-23 22:56:02 --> Router Class Initialized
INFO - 2016-08-23 22:56:02 --> Output Class Initialized
INFO - 2016-08-23 22:56:02 --> Security Class Initialized
DEBUG - 2016-08-23 22:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:56:02 --> Input Class Initialized
INFO - 2016-08-23 22:56:02 --> Language Class Initialized
INFO - 2016-08-23 22:56:02 --> Loader Class Initialized
INFO - 2016-08-23 22:56:02 --> Helper loaded: url_helper
INFO - 2016-08-23 22:56:02 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:56:02 --> Helper loaded: html_helper
INFO - 2016-08-23 22:56:02 --> Helper loaded: form_helper
INFO - 2016-08-23 22:56:02 --> Helper loaded: file_helper
INFO - 2016-08-23 22:56:02 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:56:02 --> Database Driver Class Initialized
INFO - 2016-08-23 22:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:56:02 --> Form Validation Class Initialized
INFO - 2016-08-23 22:56:02 --> Email Class Initialized
INFO - 2016-08-23 22:56:02 --> Controller Class Initialized
INFO - 2016-08-23 22:56:02 --> Model Class Initialized
INFO - 2016-08-23 22:56:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:56:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:56:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-23 22:56:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:56:02 --> Final output sent to browser
DEBUG - 2016-08-23 22:56:02 --> Total execution time: 0.5055
INFO - 2016-08-23 22:56:05 --> Config Class Initialized
INFO - 2016-08-23 22:56:05 --> Hooks Class Initialized
DEBUG - 2016-08-23 22:56:05 --> UTF-8 Support Enabled
INFO - 2016-08-23 22:56:05 --> Utf8 Class Initialized
INFO - 2016-08-23 22:56:05 --> URI Class Initialized
INFO - 2016-08-23 22:56:05 --> Router Class Initialized
INFO - 2016-08-23 22:56:05 --> Output Class Initialized
INFO - 2016-08-23 22:56:05 --> Security Class Initialized
DEBUG - 2016-08-23 22:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-23 22:56:05 --> Input Class Initialized
INFO - 2016-08-23 22:56:05 --> Language Class Initialized
INFO - 2016-08-23 22:56:05 --> Loader Class Initialized
INFO - 2016-08-23 22:56:05 --> Helper loaded: url_helper
INFO - 2016-08-23 22:56:05 --> Helper loaded: utils_helper
INFO - 2016-08-23 22:56:05 --> Helper loaded: html_helper
INFO - 2016-08-23 22:56:05 --> Helper loaded: form_helper
INFO - 2016-08-23 22:56:05 --> Helper loaded: file_helper
INFO - 2016-08-23 22:56:05 --> Helper loaded: myemail_helper
INFO - 2016-08-23 22:56:05 --> Database Driver Class Initialized
INFO - 2016-08-23 22:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-23 22:56:05 --> Form Validation Class Initialized
INFO - 2016-08-23 22:56:05 --> Email Class Initialized
INFO - 2016-08-23 22:56:05 --> Controller Class Initialized
DEBUG - 2016-08-23 22:56:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-23 22:56:05 --> Model Class Initialized
INFO - 2016-08-23 22:56:05 --> Model Class Initialized
INFO - 2016-08-23 22:56:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-23 22:56:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-23 22:56:05 --> Model Class Initialized
INFO - 2016-08-23 22:56:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-23 22:56:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-23 22:56:05 --> Final output sent to browser
DEBUG - 2016-08-23 22:56:06 --> Total execution time: 0.7269
