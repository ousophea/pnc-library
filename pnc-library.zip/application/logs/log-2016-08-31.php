<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-31 02:15:27 --> Config Class Initialized
INFO - 2016-08-31 02:15:27 --> Hooks Class Initialized
DEBUG - 2016-08-31 02:15:28 --> UTF-8 Support Enabled
INFO - 2016-08-31 02:15:28 --> Utf8 Class Initialized
INFO - 2016-08-31 02:15:28 --> URI Class Initialized
INFO - 2016-08-31 02:15:28 --> Router Class Initialized
INFO - 2016-08-31 02:15:28 --> Output Class Initialized
INFO - 2016-08-31 02:15:28 --> Security Class Initialized
DEBUG - 2016-08-31 02:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 02:15:28 --> Input Class Initialized
INFO - 2016-08-31 02:15:28 --> Language Class Initialized
INFO - 2016-08-31 02:15:28 --> Loader Class Initialized
INFO - 2016-08-31 02:15:28 --> Helper loaded: url_helper
INFO - 2016-08-31 02:15:28 --> Helper loaded: utils_helper
INFO - 2016-08-31 02:15:28 --> Helper loaded: html_helper
INFO - 2016-08-31 02:15:28 --> Helper loaded: form_helper
INFO - 2016-08-31 02:15:28 --> Helper loaded: file_helper
INFO - 2016-08-31 02:15:28 --> Helper loaded: myemail_helper
INFO - 2016-08-31 02:15:28 --> Database Driver Class Initialized
INFO - 2016-08-31 02:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 02:15:28 --> Form Validation Class Initialized
INFO - 2016-08-31 02:15:28 --> Email Class Initialized
INFO - 2016-08-31 02:15:28 --> Controller Class Initialized
INFO - 2016-08-31 02:15:28 --> Config Class Initialized
INFO - 2016-08-31 02:15:28 --> Hooks Class Initialized
DEBUG - 2016-08-31 02:15:28 --> UTF-8 Support Enabled
INFO - 2016-08-31 02:15:28 --> Utf8 Class Initialized
INFO - 2016-08-31 02:15:28 --> URI Class Initialized
INFO - 2016-08-31 02:15:28 --> Router Class Initialized
INFO - 2016-08-31 02:15:28 --> Output Class Initialized
INFO - 2016-08-31 02:15:28 --> Security Class Initialized
DEBUG - 2016-08-31 02:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 02:15:28 --> Input Class Initialized
INFO - 2016-08-31 02:15:28 --> Language Class Initialized
INFO - 2016-08-31 02:15:29 --> Loader Class Initialized
INFO - 2016-08-31 02:15:29 --> Helper loaded: url_helper
INFO - 2016-08-31 02:15:29 --> Helper loaded: utils_helper
INFO - 2016-08-31 02:15:29 --> Helper loaded: html_helper
INFO - 2016-08-31 02:15:29 --> Helper loaded: form_helper
INFO - 2016-08-31 02:15:29 --> Helper loaded: file_helper
INFO - 2016-08-31 02:15:29 --> Helper loaded: myemail_helper
INFO - 2016-08-31 02:15:29 --> Database Driver Class Initialized
INFO - 2016-08-31 02:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 02:15:29 --> Form Validation Class Initialized
INFO - 2016-08-31 02:15:29 --> Email Class Initialized
INFO - 2016-08-31 02:15:29 --> Controller Class Initialized
INFO - 2016-08-31 02:15:29 --> Model Class Initialized
DEBUG - 2016-08-31 02:15:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 02:15:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-31 02:15:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 02:15:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-31 02:15:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 02:15:29 --> Final output sent to browser
DEBUG - 2016-08-31 02:15:29 --> Total execution time: 0.4392
INFO - 2016-08-31 02:15:30 --> Config Class Initialized
INFO - 2016-08-31 02:15:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 02:15:30 --> UTF-8 Support Enabled
INFO - 2016-08-31 02:15:30 --> Utf8 Class Initialized
INFO - 2016-08-31 02:15:30 --> URI Class Initialized
INFO - 2016-08-31 02:15:30 --> Router Class Initialized
INFO - 2016-08-31 02:15:30 --> Output Class Initialized
INFO - 2016-08-31 02:15:30 --> Security Class Initialized
DEBUG - 2016-08-31 02:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 02:15:30 --> Input Class Initialized
INFO - 2016-08-31 02:15:30 --> Language Class Initialized
ERROR - 2016-08-31 02:15:30 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 02:15:30 --> Config Class Initialized
INFO - 2016-08-31 02:15:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 02:15:30 --> UTF-8 Support Enabled
INFO - 2016-08-31 02:15:30 --> Utf8 Class Initialized
INFO - 2016-08-31 02:15:30 --> URI Class Initialized
INFO - 2016-08-31 02:15:30 --> Router Class Initialized
INFO - 2016-08-31 02:15:30 --> Output Class Initialized
INFO - 2016-08-31 02:15:30 --> Security Class Initialized
DEBUG - 2016-08-31 02:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 02:15:30 --> Input Class Initialized
INFO - 2016-08-31 02:15:30 --> Language Class Initialized
ERROR - 2016-08-31 02:15:30 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 03:34:54 --> Config Class Initialized
INFO - 2016-08-31 03:34:54 --> Hooks Class Initialized
DEBUG - 2016-08-31 03:34:54 --> UTF-8 Support Enabled
INFO - 2016-08-31 03:34:54 --> Utf8 Class Initialized
INFO - 2016-08-31 03:34:54 --> URI Class Initialized
INFO - 2016-08-31 03:34:54 --> Router Class Initialized
INFO - 2016-08-31 03:34:54 --> Output Class Initialized
INFO - 2016-08-31 03:34:54 --> Security Class Initialized
DEBUG - 2016-08-31 03:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 03:34:54 --> Input Class Initialized
INFO - 2016-08-31 03:34:54 --> Language Class Initialized
INFO - 2016-08-31 03:34:54 --> Loader Class Initialized
INFO - 2016-08-31 03:34:54 --> Helper loaded: url_helper
INFO - 2016-08-31 03:34:54 --> Helper loaded: utils_helper
INFO - 2016-08-31 03:34:54 --> Helper loaded: html_helper
INFO - 2016-08-31 03:34:54 --> Helper loaded: form_helper
INFO - 2016-08-31 03:34:54 --> Helper loaded: file_helper
INFO - 2016-08-31 03:34:54 --> Helper loaded: myemail_helper
INFO - 2016-08-31 03:34:55 --> Database Driver Class Initialized
INFO - 2016-08-31 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 03:34:55 --> Form Validation Class Initialized
INFO - 2016-08-31 03:34:55 --> Email Class Initialized
INFO - 2016-08-31 03:34:55 --> Controller Class Initialized
INFO - 2016-08-31 03:34:55 --> Model Class Initialized
DEBUG - 2016-08-31 03:34:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 03:34:55 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-31 03:34:55 --> Config Class Initialized
INFO - 2016-08-31 03:34:55 --> Hooks Class Initialized
DEBUG - 2016-08-31 03:34:55 --> UTF-8 Support Enabled
INFO - 2016-08-31 03:34:55 --> Utf8 Class Initialized
INFO - 2016-08-31 03:34:55 --> URI Class Initialized
INFO - 2016-08-31 03:34:55 --> Router Class Initialized
INFO - 2016-08-31 03:34:55 --> Output Class Initialized
INFO - 2016-08-31 03:34:55 --> Security Class Initialized
DEBUG - 2016-08-31 03:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 03:34:55 --> Input Class Initialized
INFO - 2016-08-31 03:34:55 --> Language Class Initialized
INFO - 2016-08-31 03:34:55 --> Loader Class Initialized
INFO - 2016-08-31 03:34:55 --> Helper loaded: url_helper
INFO - 2016-08-31 03:34:55 --> Helper loaded: utils_helper
INFO - 2016-08-31 03:34:55 --> Helper loaded: html_helper
INFO - 2016-08-31 03:34:55 --> Helper loaded: form_helper
INFO - 2016-08-31 03:34:55 --> Helper loaded: file_helper
INFO - 2016-08-31 03:34:55 --> Helper loaded: myemail_helper
INFO - 2016-08-31 03:34:55 --> Database Driver Class Initialized
INFO - 2016-08-31 03:34:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 03:34:55 --> Form Validation Class Initialized
INFO - 2016-08-31 03:34:55 --> Email Class Initialized
INFO - 2016-08-31 03:34:55 --> Controller Class Initialized
DEBUG - 2016-08-31 03:34:55 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 03:34:55 --> Model Class Initialized
INFO - 2016-08-31 03:34:55 --> Model Class Initialized
INFO - 2016-08-31 03:34:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 03:34:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-31 03:34:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-31 03:34:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 03:34:55 --> Final output sent to browser
DEBUG - 2016-08-31 03:34:55 --> Total execution time: 0.3737
INFO - 2016-08-31 03:34:59 --> Config Class Initialized
INFO - 2016-08-31 03:34:59 --> Hooks Class Initialized
DEBUG - 2016-08-31 03:34:59 --> UTF-8 Support Enabled
INFO - 2016-08-31 03:34:59 --> Utf8 Class Initialized
INFO - 2016-08-31 03:34:59 --> URI Class Initialized
INFO - 2016-08-31 03:34:59 --> Router Class Initialized
INFO - 2016-08-31 03:34:59 --> Output Class Initialized
INFO - 2016-08-31 03:34:59 --> Security Class Initialized
DEBUG - 2016-08-31 03:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 03:34:59 --> Input Class Initialized
INFO - 2016-08-31 03:34:59 --> Language Class Initialized
INFO - 2016-08-31 03:34:59 --> Loader Class Initialized
INFO - 2016-08-31 03:34:59 --> Helper loaded: url_helper
INFO - 2016-08-31 03:34:59 --> Helper loaded: utils_helper
INFO - 2016-08-31 03:34:59 --> Helper loaded: html_helper
INFO - 2016-08-31 03:34:59 --> Helper loaded: form_helper
INFO - 2016-08-31 03:34:59 --> Helper loaded: file_helper
INFO - 2016-08-31 03:34:59 --> Helper loaded: myemail_helper
INFO - 2016-08-31 03:34:59 --> Database Driver Class Initialized
INFO - 2016-08-31 03:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 03:34:59 --> Form Validation Class Initialized
INFO - 2016-08-31 03:34:59 --> Email Class Initialized
INFO - 2016-08-31 03:34:59 --> Controller Class Initialized
DEBUG - 2016-08-31 03:34:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 03:34:59 --> Model Class Initialized
INFO - 2016-08-31 03:34:59 --> Model Class Initialized
INFO - 2016-08-31 03:34:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 03:34:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-31 03:34:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-31 03:34:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 03:34:59 --> Final output sent to browser
DEBUG - 2016-08-31 03:34:59 --> Total execution time: 0.2365
INFO - 2016-08-31 03:35:02 --> Config Class Initialized
INFO - 2016-08-31 03:35:02 --> Hooks Class Initialized
DEBUG - 2016-08-31 03:35:02 --> UTF-8 Support Enabled
INFO - 2016-08-31 03:35:02 --> Utf8 Class Initialized
INFO - 2016-08-31 03:35:02 --> URI Class Initialized
INFO - 2016-08-31 03:35:02 --> Router Class Initialized
INFO - 2016-08-31 03:35:02 --> Output Class Initialized
INFO - 2016-08-31 03:35:02 --> Security Class Initialized
DEBUG - 2016-08-31 03:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 03:35:02 --> Input Class Initialized
INFO - 2016-08-31 03:35:02 --> Language Class Initialized
INFO - 2016-08-31 03:35:02 --> Loader Class Initialized
INFO - 2016-08-31 03:35:02 --> Helper loaded: url_helper
INFO - 2016-08-31 03:35:02 --> Helper loaded: utils_helper
INFO - 2016-08-31 03:35:02 --> Helper loaded: html_helper
INFO - 2016-08-31 03:35:02 --> Helper loaded: form_helper
INFO - 2016-08-31 03:35:02 --> Helper loaded: file_helper
INFO - 2016-08-31 03:35:02 --> Helper loaded: myemail_helper
INFO - 2016-08-31 03:35:02 --> Database Driver Class Initialized
INFO - 2016-08-31 03:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 03:35:02 --> Form Validation Class Initialized
INFO - 2016-08-31 03:35:02 --> Email Class Initialized
INFO - 2016-08-31 03:35:02 --> Controller Class Initialized
DEBUG - 2016-08-31 03:35:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 03:35:02 --> Model Class Initialized
INFO - 2016-08-31 03:35:02 --> Model Class Initialized
INFO - 2016-08-31 03:35:02 --> Model Class Initialized
INFO - 2016-08-31 03:35:02 --> Final output sent to browser
DEBUG - 2016-08-31 03:35:02 --> Total execution time: 0.3037
INFO - 2016-08-31 03:35:06 --> Config Class Initialized
INFO - 2016-08-31 03:35:06 --> Hooks Class Initialized
DEBUG - 2016-08-31 03:35:06 --> UTF-8 Support Enabled
INFO - 2016-08-31 03:35:06 --> Utf8 Class Initialized
INFO - 2016-08-31 03:35:06 --> URI Class Initialized
INFO - 2016-08-31 03:35:06 --> Router Class Initialized
INFO - 2016-08-31 03:35:06 --> Output Class Initialized
INFO - 2016-08-31 03:35:06 --> Security Class Initialized
DEBUG - 2016-08-31 03:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 03:35:06 --> Input Class Initialized
INFO - 2016-08-31 03:35:06 --> Language Class Initialized
INFO - 2016-08-31 03:35:06 --> Loader Class Initialized
INFO - 2016-08-31 03:35:06 --> Helper loaded: url_helper
INFO - 2016-08-31 03:35:06 --> Helper loaded: utils_helper
INFO - 2016-08-31 03:35:06 --> Helper loaded: html_helper
INFO - 2016-08-31 03:35:06 --> Helper loaded: form_helper
INFO - 2016-08-31 03:35:06 --> Helper loaded: file_helper
INFO - 2016-08-31 03:35:06 --> Helper loaded: myemail_helper
INFO - 2016-08-31 03:35:06 --> Database Driver Class Initialized
INFO - 2016-08-31 03:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 03:35:06 --> Form Validation Class Initialized
INFO - 2016-08-31 03:35:06 --> Email Class Initialized
INFO - 2016-08-31 03:35:06 --> Controller Class Initialized
DEBUG - 2016-08-31 03:35:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 03:35:06 --> Model Class Initialized
INFO - 2016-08-31 03:35:06 --> Model Class Initialized
INFO - 2016-08-31 03:35:06 --> Model Class Initialized
INFO - 2016-08-31 03:35:06 --> Model Class Initialized
INFO - 2016-08-31 03:35:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 03:35:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-31 03:35:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-31 03:35:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 03:35:06 --> Final output sent to browser
DEBUG - 2016-08-31 03:35:06 --> Total execution time: 0.2518
INFO - 2016-08-31 07:08:33 --> Config Class Initialized
INFO - 2016-08-31 07:08:33 --> Hooks Class Initialized
DEBUG - 2016-08-31 07:08:33 --> UTF-8 Support Enabled
INFO - 2016-08-31 07:08:33 --> Utf8 Class Initialized
INFO - 2016-08-31 07:08:33 --> URI Class Initialized
INFO - 2016-08-31 07:08:33 --> Router Class Initialized
INFO - 2016-08-31 07:08:33 --> Output Class Initialized
INFO - 2016-08-31 07:08:34 --> Security Class Initialized
DEBUG - 2016-08-31 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 07:08:34 --> Input Class Initialized
INFO - 2016-08-31 07:08:34 --> Language Class Initialized
INFO - 2016-08-31 07:08:34 --> Loader Class Initialized
INFO - 2016-08-31 07:08:34 --> Helper loaded: url_helper
INFO - 2016-08-31 07:08:34 --> Helper loaded: utils_helper
INFO - 2016-08-31 07:08:34 --> Helper loaded: html_helper
INFO - 2016-08-31 07:08:34 --> Helper loaded: form_helper
INFO - 2016-08-31 07:08:34 --> Helper loaded: file_helper
INFO - 2016-08-31 07:08:34 --> Helper loaded: myemail_helper
INFO - 2016-08-31 07:08:34 --> Database Driver Class Initialized
INFO - 2016-08-31 07:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 07:08:34 --> Form Validation Class Initialized
INFO - 2016-08-31 07:08:34 --> Email Class Initialized
INFO - 2016-08-31 07:08:34 --> Controller Class Initialized
INFO - 2016-08-31 07:08:35 --> Config Class Initialized
INFO - 2016-08-31 07:08:35 --> Hooks Class Initialized
DEBUG - 2016-08-31 07:08:35 --> UTF-8 Support Enabled
INFO - 2016-08-31 07:08:35 --> Utf8 Class Initialized
INFO - 2016-08-31 07:08:35 --> URI Class Initialized
INFO - 2016-08-31 07:08:35 --> Router Class Initialized
INFO - 2016-08-31 07:08:35 --> Output Class Initialized
INFO - 2016-08-31 07:08:35 --> Security Class Initialized
DEBUG - 2016-08-31 07:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 07:08:35 --> Input Class Initialized
INFO - 2016-08-31 07:08:35 --> Language Class Initialized
INFO - 2016-08-31 07:08:35 --> Loader Class Initialized
INFO - 2016-08-31 07:08:35 --> Helper loaded: url_helper
INFO - 2016-08-31 07:08:35 --> Helper loaded: utils_helper
INFO - 2016-08-31 07:08:35 --> Helper loaded: html_helper
INFO - 2016-08-31 07:08:35 --> Helper loaded: form_helper
INFO - 2016-08-31 07:08:35 --> Helper loaded: file_helper
INFO - 2016-08-31 07:08:35 --> Helper loaded: myemail_helper
INFO - 2016-08-31 07:08:35 --> Database Driver Class Initialized
INFO - 2016-08-31 07:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 07:08:35 --> Form Validation Class Initialized
INFO - 2016-08-31 07:08:35 --> Email Class Initialized
INFO - 2016-08-31 07:08:35 --> Controller Class Initialized
INFO - 2016-08-31 07:08:35 --> Model Class Initialized
DEBUG - 2016-08-31 07:08:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 07:08:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-31 07:08:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 07:08:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-31 07:08:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 07:08:36 --> Final output sent to browser
DEBUG - 2016-08-31 07:08:36 --> Total execution time: 0.3905
INFO - 2016-08-31 07:08:37 --> Config Class Initialized
INFO - 2016-08-31 07:08:37 --> Hooks Class Initialized
DEBUG - 2016-08-31 07:08:37 --> UTF-8 Support Enabled
INFO - 2016-08-31 07:08:37 --> Utf8 Class Initialized
INFO - 2016-08-31 07:08:37 --> URI Class Initialized
INFO - 2016-08-31 07:08:37 --> Router Class Initialized
INFO - 2016-08-31 07:08:37 --> Output Class Initialized
INFO - 2016-08-31 07:08:37 --> Security Class Initialized
DEBUG - 2016-08-31 07:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 07:08:37 --> Input Class Initialized
INFO - 2016-08-31 07:08:37 --> Language Class Initialized
ERROR - 2016-08-31 07:08:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 07:08:37 --> Config Class Initialized
INFO - 2016-08-31 07:08:37 --> Hooks Class Initialized
DEBUG - 2016-08-31 07:08:37 --> UTF-8 Support Enabled
INFO - 2016-08-31 07:08:37 --> Utf8 Class Initialized
INFO - 2016-08-31 07:08:37 --> URI Class Initialized
INFO - 2016-08-31 07:08:37 --> Router Class Initialized
INFO - 2016-08-31 07:08:37 --> Output Class Initialized
INFO - 2016-08-31 07:08:37 --> Security Class Initialized
DEBUG - 2016-08-31 07:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 07:08:37 --> Input Class Initialized
INFO - 2016-08-31 07:08:37 --> Language Class Initialized
ERROR - 2016-08-31 07:08:37 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 10:14:30 --> Config Class Initialized
INFO - 2016-08-31 10:14:30 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:14:30 --> UTF-8 Support Enabled
INFO - 2016-08-31 10:14:30 --> Utf8 Class Initialized
INFO - 2016-08-31 10:14:30 --> URI Class Initialized
INFO - 2016-08-31 10:14:30 --> Router Class Initialized
INFO - 2016-08-31 10:14:30 --> Output Class Initialized
INFO - 2016-08-31 10:14:30 --> Security Class Initialized
DEBUG - 2016-08-31 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 10:14:30 --> Input Class Initialized
INFO - 2016-08-31 10:14:30 --> Language Class Initialized
ERROR - 2016-08-31 10:14:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 10:14:31 --> Config Class Initialized
INFO - 2016-08-31 10:14:31 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:14:31 --> UTF-8 Support Enabled
INFO - 2016-08-31 10:14:31 --> Utf8 Class Initialized
INFO - 2016-08-31 10:14:31 --> URI Class Initialized
INFO - 2016-08-31 10:14:31 --> Router Class Initialized
INFO - 2016-08-31 10:14:31 --> Output Class Initialized
INFO - 2016-08-31 10:14:31 --> Security Class Initialized
DEBUG - 2016-08-31 10:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 10:14:31 --> Input Class Initialized
INFO - 2016-08-31 10:14:31 --> Language Class Initialized
ERROR - 2016-08-31 10:14:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-31 10:34:34 --> Config Class Initialized
INFO - 2016-08-31 10:34:34 --> Hooks Class Initialized
DEBUG - 2016-08-31 10:34:34 --> UTF-8 Support Enabled
INFO - 2016-08-31 10:34:34 --> Utf8 Class Initialized
INFO - 2016-08-31 10:34:34 --> URI Class Initialized
INFO - 2016-08-31 10:34:34 --> Router Class Initialized
INFO - 2016-08-31 10:34:34 --> Output Class Initialized
INFO - 2016-08-31 10:34:34 --> Security Class Initialized
DEBUG - 2016-08-31 10:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-31 10:34:34 --> Input Class Initialized
INFO - 2016-08-31 10:34:34 --> Language Class Initialized
INFO - 2016-08-31 10:34:35 --> Loader Class Initialized
INFO - 2016-08-31 10:34:35 --> Helper loaded: url_helper
INFO - 2016-08-31 10:34:35 --> Helper loaded: utils_helper
INFO - 2016-08-31 10:34:35 --> Helper loaded: html_helper
INFO - 2016-08-31 10:34:35 --> Helper loaded: form_helper
INFO - 2016-08-31 10:34:35 --> Helper loaded: file_helper
INFO - 2016-08-31 10:34:35 --> Helper loaded: myemail_helper
INFO - 2016-08-31 10:34:35 --> Database Driver Class Initialized
INFO - 2016-08-31 10:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-31 10:34:35 --> Form Validation Class Initialized
INFO - 2016-08-31 10:34:35 --> Email Class Initialized
INFO - 2016-08-31 10:34:35 --> Controller Class Initialized
INFO - 2016-08-31 10:34:35 --> Model Class Initialized
DEBUG - 2016-08-31 10:34:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-31 10:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-31 10:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-31 10:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-31 10:34:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-31 10:34:35 --> Final output sent to browser
DEBUG - 2016-08-31 10:34:35 --> Total execution time: 1.0687
