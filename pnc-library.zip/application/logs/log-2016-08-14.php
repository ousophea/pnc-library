<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-14 15:00:04 --> Config Class Initialized
INFO - 2016-08-14 15:00:04 --> Hooks Class Initialized
DEBUG - 2016-08-14 15:00:05 --> UTF-8 Support Enabled
INFO - 2016-08-14 15:00:05 --> Utf8 Class Initialized
INFO - 2016-08-14 15:00:05 --> URI Class Initialized
DEBUG - 2016-08-14 15:00:05 --> No URI present. Default controller set.
INFO - 2016-08-14 15:00:05 --> Router Class Initialized
INFO - 2016-08-14 15:00:05 --> Output Class Initialized
INFO - 2016-08-14 15:00:05 --> Security Class Initialized
DEBUG - 2016-08-14 15:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-14 15:00:05 --> Input Class Initialized
INFO - 2016-08-14 15:00:06 --> Language Class Initialized
INFO - 2016-08-14 15:00:06 --> Loader Class Initialized
INFO - 2016-08-14 15:00:06 --> Helper loaded: url_helper
INFO - 2016-08-14 15:00:06 --> Helper loaded: utils_helper
INFO - 2016-08-14 15:00:06 --> Helper loaded: html_helper
INFO - 2016-08-14 15:00:06 --> Helper loaded: form_helper
INFO - 2016-08-14 15:00:06 --> Helper loaded: file_helper
INFO - 2016-08-14 15:00:07 --> Helper loaded: myemail_helper
INFO - 2016-08-14 15:00:07 --> Database Driver Class Initialized
INFO - 2016-08-14 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-14 15:00:08 --> Form Validation Class Initialized
INFO - 2016-08-14 15:00:09 --> Email Class Initialized
INFO - 2016-08-14 15:00:09 --> Controller Class Initialized
INFO - 2016-08-14 15:00:09 --> Config Class Initialized
INFO - 2016-08-14 15:00:09 --> Hooks Class Initialized
DEBUG - 2016-08-14 15:00:09 --> UTF-8 Support Enabled
INFO - 2016-08-14 15:00:09 --> Utf8 Class Initialized
INFO - 2016-08-14 15:00:09 --> URI Class Initialized
INFO - 2016-08-14 15:00:09 --> Router Class Initialized
INFO - 2016-08-14 15:00:09 --> Output Class Initialized
INFO - 2016-08-14 15:00:09 --> Security Class Initialized
DEBUG - 2016-08-14 15:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-14 15:00:09 --> Input Class Initialized
INFO - 2016-08-14 15:00:09 --> Language Class Initialized
INFO - 2016-08-14 15:00:10 --> Loader Class Initialized
INFO - 2016-08-14 15:00:10 --> Helper loaded: url_helper
INFO - 2016-08-14 15:00:10 --> Helper loaded: utils_helper
INFO - 2016-08-14 15:00:10 --> Helper loaded: html_helper
INFO - 2016-08-14 15:00:10 --> Helper loaded: form_helper
INFO - 2016-08-14 15:00:10 --> Helper loaded: file_helper
INFO - 2016-08-14 15:00:10 --> Helper loaded: myemail_helper
INFO - 2016-08-14 15:00:10 --> Database Driver Class Initialized
INFO - 2016-08-14 15:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-14 15:00:10 --> Form Validation Class Initialized
INFO - 2016-08-14 15:00:10 --> Email Class Initialized
INFO - 2016-08-14 15:00:10 --> Controller Class Initialized
INFO - 2016-08-14 15:00:10 --> Model Class Initialized
DEBUG - 2016-08-14 15:00:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-14 15:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-14 15:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-14 15:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-14 15:00:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-14 15:00:10 --> Final output sent to browser
DEBUG - 2016-08-14 15:00:10 --> Total execution time: 1.0807
INFO - 2016-08-14 15:00:15 --> Config Class Initialized
INFO - 2016-08-14 15:00:15 --> Hooks Class Initialized
DEBUG - 2016-08-14 15:00:15 --> UTF-8 Support Enabled
INFO - 2016-08-14 15:00:15 --> Utf8 Class Initialized
INFO - 2016-08-14 15:00:15 --> URI Class Initialized
INFO - 2016-08-14 15:00:15 --> Router Class Initialized
INFO - 2016-08-14 15:00:15 --> Output Class Initialized
INFO - 2016-08-14 15:00:15 --> Security Class Initialized
DEBUG - 2016-08-14 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-14 15:00:15 --> Input Class Initialized
INFO - 2016-08-14 15:00:15 --> Language Class Initialized
ERROR - 2016-08-14 15:00:15 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-14 15:00:15 --> Config Class Initialized
INFO - 2016-08-14 15:00:15 --> Hooks Class Initialized
DEBUG - 2016-08-14 15:00:15 --> UTF-8 Support Enabled
INFO - 2016-08-14 15:00:15 --> Utf8 Class Initialized
INFO - 2016-08-14 15:00:15 --> URI Class Initialized
INFO - 2016-08-14 15:00:15 --> Router Class Initialized
INFO - 2016-08-14 15:00:15 --> Output Class Initialized
INFO - 2016-08-14 15:00:15 --> Security Class Initialized
DEBUG - 2016-08-14 15:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-14 15:00:15 --> Input Class Initialized
INFO - 2016-08-14 15:00:15 --> Language Class Initialized
ERROR - 2016-08-14 15:00:15 --> 404 Page Not Found: Faviconico/index
