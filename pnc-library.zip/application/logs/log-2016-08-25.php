<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-25 07:55:14 --> Config Class Initialized
INFO - 2016-08-25 07:55:14 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:14 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:14 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:14 --> URI Class Initialized
INFO - 2016-08-25 07:55:14 --> Router Class Initialized
INFO - 2016-08-25 07:55:14 --> Output Class Initialized
INFO - 2016-08-25 07:55:15 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:15 --> Input Class Initialized
INFO - 2016-08-25 07:55:15 --> Language Class Initialized
INFO - 2016-08-25 07:55:15 --> Loader Class Initialized
INFO - 2016-08-25 07:55:15 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:15 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:15 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:15 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:15 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:15 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:15 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:15 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:15 --> Email Class Initialized
INFO - 2016-08-25 07:55:15 --> Controller Class Initialized
INFO - 2016-08-25 07:55:15 --> Model Class Initialized
DEBUG - 2016-08-25 07:55:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 07:55:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 07:55:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 07:55:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 07:55:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 07:55:15 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:15 --> Total execution time: 0.9587
INFO - 2016-08-25 07:55:16 --> Config Class Initialized
INFO - 2016-08-25 07:55:16 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:16 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:16 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:16 --> URI Class Initialized
INFO - 2016-08-25 07:55:16 --> Router Class Initialized
INFO - 2016-08-25 07:55:16 --> Output Class Initialized
INFO - 2016-08-25 07:55:16 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:16 --> Input Class Initialized
INFO - 2016-08-25 07:55:16 --> Language Class Initialized
ERROR - 2016-08-25 07:55:16 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-25 07:55:16 --> Config Class Initialized
INFO - 2016-08-25 07:55:16 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:16 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:16 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:16 --> URI Class Initialized
INFO - 2016-08-25 07:55:16 --> Router Class Initialized
INFO - 2016-08-25 07:55:16 --> Output Class Initialized
INFO - 2016-08-25 07:55:16 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:16 --> Input Class Initialized
INFO - 2016-08-25 07:55:16 --> Language Class Initialized
ERROR - 2016-08-25 07:55:16 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-25 07:55:23 --> Config Class Initialized
INFO - 2016-08-25 07:55:23 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:23 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:23 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:23 --> URI Class Initialized
INFO - 2016-08-25 07:55:23 --> Router Class Initialized
INFO - 2016-08-25 07:55:23 --> Output Class Initialized
INFO - 2016-08-25 07:55:23 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:23 --> Input Class Initialized
INFO - 2016-08-25 07:55:23 --> Language Class Initialized
INFO - 2016-08-25 07:55:23 --> Loader Class Initialized
INFO - 2016-08-25 07:55:23 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:23 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:23 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:23 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:23 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:23 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:23 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:23 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:23 --> Email Class Initialized
INFO - 2016-08-25 07:55:23 --> Controller Class Initialized
INFO - 2016-08-25 07:55:23 --> Model Class Initialized
INFO - 2016-08-25 07:55:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-25 07:55:24 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:24 --> Total execution time: 0.5911
INFO - 2016-08-25 07:55:29 --> Config Class Initialized
INFO - 2016-08-25 07:55:29 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:29 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:29 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:29 --> URI Class Initialized
INFO - 2016-08-25 07:55:29 --> Router Class Initialized
INFO - 2016-08-25 07:55:29 --> Output Class Initialized
INFO - 2016-08-25 07:55:29 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:29 --> Input Class Initialized
INFO - 2016-08-25 07:55:29 --> Language Class Initialized
INFO - 2016-08-25 07:55:29 --> Loader Class Initialized
INFO - 2016-08-25 07:55:29 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:29 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:29 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:29 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:29 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:29 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:29 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:29 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:29 --> Email Class Initialized
INFO - 2016-08-25 07:55:29 --> Controller Class Initialized
INFO - 2016-08-25 07:55:29 --> Model Class Initialized
INFO - 2016-08-25 07:55:31 --> Config Class Initialized
INFO - 2016-08-25 07:55:31 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:31 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:31 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:31 --> URI Class Initialized
DEBUG - 2016-08-25 07:55:31 --> No URI present. Default controller set.
INFO - 2016-08-25 07:55:31 --> Router Class Initialized
INFO - 2016-08-25 07:55:31 --> Output Class Initialized
INFO - 2016-08-25 07:55:31 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:31 --> Input Class Initialized
INFO - 2016-08-25 07:55:31 --> Language Class Initialized
INFO - 2016-08-25 07:55:31 --> Loader Class Initialized
INFO - 2016-08-25 07:55:31 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:31 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:31 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:31 --> Email Class Initialized
INFO - 2016-08-25 07:55:31 --> Controller Class Initialized
INFO - 2016-08-25 07:55:31 --> Config Class Initialized
INFO - 2016-08-25 07:55:31 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:31 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:31 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:31 --> URI Class Initialized
INFO - 2016-08-25 07:55:31 --> Router Class Initialized
INFO - 2016-08-25 07:55:31 --> Output Class Initialized
INFO - 2016-08-25 07:55:31 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:31 --> Input Class Initialized
INFO - 2016-08-25 07:55:31 --> Language Class Initialized
INFO - 2016-08-25 07:55:31 --> Loader Class Initialized
INFO - 2016-08-25 07:55:31 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:31 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:31 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:31 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:31 --> Email Class Initialized
INFO - 2016-08-25 07:55:31 --> Controller Class Initialized
INFO - 2016-08-25 07:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 07:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 07:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 07:55:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 07:55:31 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:31 --> Total execution time: 0.2162
INFO - 2016-08-25 07:55:44 --> Config Class Initialized
INFO - 2016-08-25 07:55:44 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:44 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:44 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:44 --> URI Class Initialized
DEBUG - 2016-08-25 07:55:44 --> No URI present. Default controller set.
INFO - 2016-08-25 07:55:44 --> Router Class Initialized
INFO - 2016-08-25 07:55:44 --> Output Class Initialized
INFO - 2016-08-25 07:55:44 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:44 --> Input Class Initialized
INFO - 2016-08-25 07:55:44 --> Language Class Initialized
INFO - 2016-08-25 07:55:44 --> Loader Class Initialized
INFO - 2016-08-25 07:55:44 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:44 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:44 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:44 --> Email Class Initialized
INFO - 2016-08-25 07:55:44 --> Controller Class Initialized
INFO - 2016-08-25 07:55:44 --> Config Class Initialized
INFO - 2016-08-25 07:55:44 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:44 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:44 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:44 --> URI Class Initialized
INFO - 2016-08-25 07:55:44 --> Router Class Initialized
INFO - 2016-08-25 07:55:44 --> Output Class Initialized
INFO - 2016-08-25 07:55:44 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:44 --> Input Class Initialized
INFO - 2016-08-25 07:55:44 --> Language Class Initialized
INFO - 2016-08-25 07:55:44 --> Loader Class Initialized
INFO - 2016-08-25 07:55:44 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:44 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:44 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:44 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:44 --> Email Class Initialized
INFO - 2016-08-25 07:55:44 --> Controller Class Initialized
INFO - 2016-08-25 07:55:44 --> Model Class Initialized
DEBUG - 2016-08-25 07:55:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 07:55:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 07:55:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 07:55:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 07:55:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 07:55:44 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:44 --> Total execution time: 0.2136
INFO - 2016-08-25 07:55:47 --> Config Class Initialized
INFO - 2016-08-25 07:55:47 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:47 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:47 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:47 --> URI Class Initialized
INFO - 2016-08-25 07:55:47 --> Router Class Initialized
INFO - 2016-08-25 07:55:47 --> Output Class Initialized
INFO - 2016-08-25 07:55:47 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:47 --> Input Class Initialized
INFO - 2016-08-25 07:55:47 --> Language Class Initialized
INFO - 2016-08-25 07:55:47 --> Loader Class Initialized
INFO - 2016-08-25 07:55:47 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:47 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:47 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:47 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:47 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:47 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:47 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:47 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:47 --> Email Class Initialized
INFO - 2016-08-25 07:55:47 --> Controller Class Initialized
INFO - 2016-08-25 07:55:47 --> Model Class Initialized
INFO - 2016-08-25 07:55:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/user_authentication.php
INFO - 2016-08-25 07:55:47 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:47 --> Total execution time: 0.2087
INFO - 2016-08-25 07:55:52 --> Config Class Initialized
INFO - 2016-08-25 07:55:52 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:52 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:52 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:52 --> URI Class Initialized
INFO - 2016-08-25 07:55:52 --> Router Class Initialized
INFO - 2016-08-25 07:55:52 --> Output Class Initialized
INFO - 2016-08-25 07:55:52 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:52 --> Input Class Initialized
INFO - 2016-08-25 07:55:52 --> Language Class Initialized
INFO - 2016-08-25 07:55:52 --> Loader Class Initialized
INFO - 2016-08-25 07:55:52 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:52 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:52 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:52 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:52 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:52 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:52 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:52 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:52 --> Email Class Initialized
INFO - 2016-08-25 07:55:52 --> Controller Class Initialized
INFO - 2016-08-25 07:55:52 --> Model Class Initialized
INFO - 2016-08-25 07:55:54 --> Config Class Initialized
INFO - 2016-08-25 07:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:54 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:54 --> URI Class Initialized
DEBUG - 2016-08-25 07:55:54 --> No URI present. Default controller set.
INFO - 2016-08-25 07:55:54 --> Router Class Initialized
INFO - 2016-08-25 07:55:54 --> Output Class Initialized
INFO - 2016-08-25 07:55:54 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:54 --> Input Class Initialized
INFO - 2016-08-25 07:55:54 --> Language Class Initialized
INFO - 2016-08-25 07:55:54 --> Loader Class Initialized
INFO - 2016-08-25 07:55:54 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:54 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:54 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:54 --> Email Class Initialized
INFO - 2016-08-25 07:55:54 --> Controller Class Initialized
INFO - 2016-08-25 07:55:54 --> Config Class Initialized
INFO - 2016-08-25 07:55:54 --> Hooks Class Initialized
DEBUG - 2016-08-25 07:55:54 --> UTF-8 Support Enabled
INFO - 2016-08-25 07:55:54 --> Utf8 Class Initialized
INFO - 2016-08-25 07:55:54 --> URI Class Initialized
INFO - 2016-08-25 07:55:54 --> Router Class Initialized
INFO - 2016-08-25 07:55:54 --> Output Class Initialized
INFO - 2016-08-25 07:55:54 --> Security Class Initialized
DEBUG - 2016-08-25 07:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 07:55:54 --> Input Class Initialized
INFO - 2016-08-25 07:55:54 --> Language Class Initialized
INFO - 2016-08-25 07:55:54 --> Loader Class Initialized
INFO - 2016-08-25 07:55:54 --> Helper loaded: url_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: utils_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: html_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: form_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: file_helper
INFO - 2016-08-25 07:55:54 --> Helper loaded: myemail_helper
INFO - 2016-08-25 07:55:54 --> Database Driver Class Initialized
INFO - 2016-08-25 07:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 07:55:54 --> Form Validation Class Initialized
INFO - 2016-08-25 07:55:54 --> Email Class Initialized
INFO - 2016-08-25 07:55:54 --> Controller Class Initialized
INFO - 2016-08-25 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 07:55:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 07:55:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 07:55:55 --> Final output sent to browser
DEBUG - 2016-08-25 07:55:55 --> Total execution time: 0.2046
INFO - 2016-08-25 08:03:06 --> Config Class Initialized
INFO - 2016-08-25 08:03:06 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:06 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:06 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:06 --> URI Class Initialized
INFO - 2016-08-25 08:03:06 --> Router Class Initialized
INFO - 2016-08-25 08:03:06 --> Output Class Initialized
INFO - 2016-08-25 08:03:06 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:06 --> Input Class Initialized
INFO - 2016-08-25 08:03:06 --> Language Class Initialized
INFO - 2016-08-25 08:03:06 --> Loader Class Initialized
INFO - 2016-08-25 08:03:06 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:06 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:06 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:06 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:06 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:06 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:07 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:07 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:07 --> Email Class Initialized
INFO - 2016-08-25 08:03:07 --> Controller Class Initialized
INFO - 2016-08-25 08:03:07 --> Model Class Initialized
INFO - 2016-08-25 08:03:12 --> Config Class Initialized
INFO - 2016-08-25 08:03:12 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:12 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:12 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:12 --> URI Class Initialized
DEBUG - 2016-08-25 08:03:12 --> No URI present. Default controller set.
INFO - 2016-08-25 08:03:12 --> Router Class Initialized
INFO - 2016-08-25 08:03:12 --> Output Class Initialized
INFO - 2016-08-25 08:03:12 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:12 --> Input Class Initialized
INFO - 2016-08-25 08:03:12 --> Language Class Initialized
INFO - 2016-08-25 08:03:12 --> Loader Class Initialized
INFO - 2016-08-25 08:03:12 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:12 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:12 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:12 --> Email Class Initialized
INFO - 2016-08-25 08:03:12 --> Controller Class Initialized
INFO - 2016-08-25 08:03:12 --> Config Class Initialized
INFO - 2016-08-25 08:03:12 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:12 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:12 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:12 --> URI Class Initialized
INFO - 2016-08-25 08:03:12 --> Router Class Initialized
INFO - 2016-08-25 08:03:12 --> Output Class Initialized
INFO - 2016-08-25 08:03:12 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:12 --> Input Class Initialized
INFO - 2016-08-25 08:03:12 --> Language Class Initialized
INFO - 2016-08-25 08:03:12 --> Loader Class Initialized
INFO - 2016-08-25 08:03:12 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:12 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:12 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:12 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:12 --> Email Class Initialized
INFO - 2016-08-25 08:03:12 --> Controller Class Initialized
INFO - 2016-08-25 08:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 08:03:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:03:12 --> Final output sent to browser
DEBUG - 2016-08-25 08:03:12 --> Total execution time: 0.2082
INFO - 2016-08-25 08:03:17 --> Config Class Initialized
INFO - 2016-08-25 08:03:17 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:17 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:17 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:17 --> URI Class Initialized
INFO - 2016-08-25 08:03:17 --> Router Class Initialized
INFO - 2016-08-25 08:03:17 --> Output Class Initialized
INFO - 2016-08-25 08:03:17 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:17 --> Input Class Initialized
INFO - 2016-08-25 08:03:17 --> Language Class Initialized
INFO - 2016-08-25 08:03:17 --> Loader Class Initialized
INFO - 2016-08-25 08:03:17 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:17 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:17 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:17 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:17 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:17 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:17 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:17 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:17 --> Email Class Initialized
INFO - 2016-08-25 08:03:17 --> Controller Class Initialized
INFO - 2016-08-25 08:03:17 --> Model Class Initialized
INFO - 2016-08-25 08:03:17 --> Model Class Initialized
INFO - 2016-08-25 08:03:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:03:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:03:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-25 08:03:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:03:17 --> Final output sent to browser
DEBUG - 2016-08-25 08:03:17 --> Total execution time: 0.2307
INFO - 2016-08-25 08:03:18 --> Config Class Initialized
INFO - 2016-08-25 08:03:18 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:18 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:18 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:18 --> URI Class Initialized
INFO - 2016-08-25 08:03:18 --> Router Class Initialized
INFO - 2016-08-25 08:03:18 --> Output Class Initialized
INFO - 2016-08-25 08:03:18 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:18 --> Input Class Initialized
INFO - 2016-08-25 08:03:18 --> Language Class Initialized
INFO - 2016-08-25 08:03:18 --> Loader Class Initialized
INFO - 2016-08-25 08:03:18 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:18 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:18 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:18 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:18 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:18 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:18 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:18 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:19 --> Email Class Initialized
INFO - 2016-08-25 08:03:19 --> Controller Class Initialized
INFO - 2016-08-25 08:03:19 --> Config Class Initialized
INFO - 2016-08-25 08:03:19 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:19 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:19 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:19 --> URI Class Initialized
INFO - 2016-08-25 08:03:19 --> Router Class Initialized
INFO - 2016-08-25 08:03:19 --> Output Class Initialized
INFO - 2016-08-25 08:03:19 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:19 --> Input Class Initialized
INFO - 2016-08-25 08:03:19 --> Language Class Initialized
INFO - 2016-08-25 08:03:19 --> Loader Class Initialized
INFO - 2016-08-25 08:03:19 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:19 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:19 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:19 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:19 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:19 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:19 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:19 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:19 --> Email Class Initialized
INFO - 2016-08-25 08:03:19 --> Controller Class Initialized
INFO - 2016-08-25 08:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 08:03:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:03:19 --> Final output sent to browser
DEBUG - 2016-08-25 08:03:19 --> Total execution time: 0.2079
INFO - 2016-08-25 08:03:27 --> Config Class Initialized
INFO - 2016-08-25 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:27 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:27 --> URI Class Initialized
INFO - 2016-08-25 08:03:27 --> Router Class Initialized
INFO - 2016-08-25 08:03:27 --> Output Class Initialized
INFO - 2016-08-25 08:03:27 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:27 --> Input Class Initialized
INFO - 2016-08-25 08:03:27 --> Language Class Initialized
INFO - 2016-08-25 08:03:27 --> Loader Class Initialized
INFO - 2016-08-25 08:03:27 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:27 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:27 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:27 --> Email Class Initialized
INFO - 2016-08-25 08:03:27 --> Controller Class Initialized
INFO - 2016-08-25 08:03:27 --> Config Class Initialized
INFO - 2016-08-25 08:03:27 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:03:27 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:03:27 --> Utf8 Class Initialized
INFO - 2016-08-25 08:03:27 --> URI Class Initialized
INFO - 2016-08-25 08:03:27 --> Router Class Initialized
INFO - 2016-08-25 08:03:27 --> Output Class Initialized
INFO - 2016-08-25 08:03:27 --> Security Class Initialized
DEBUG - 2016-08-25 08:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:03:27 --> Input Class Initialized
INFO - 2016-08-25 08:03:27 --> Language Class Initialized
INFO - 2016-08-25 08:03:27 --> Loader Class Initialized
INFO - 2016-08-25 08:03:27 --> Helper loaded: url_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: html_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: form_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: file_helper
INFO - 2016-08-25 08:03:27 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:03:27 --> Database Driver Class Initialized
INFO - 2016-08-25 08:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:03:27 --> Form Validation Class Initialized
INFO - 2016-08-25 08:03:27 --> Email Class Initialized
INFO - 2016-08-25 08:03:27 --> Controller Class Initialized
INFO - 2016-08-25 08:03:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:03:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:03:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 08:03:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:03:27 --> Final output sent to browser
DEBUG - 2016-08-25 08:03:27 --> Total execution time: 0.2208
INFO - 2016-08-25 08:04:05 --> Config Class Initialized
INFO - 2016-08-25 08:04:05 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:05 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:05 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:05 --> URI Class Initialized
INFO - 2016-08-25 08:04:05 --> Router Class Initialized
INFO - 2016-08-25 08:04:05 --> Output Class Initialized
INFO - 2016-08-25 08:04:05 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:05 --> Input Class Initialized
INFO - 2016-08-25 08:04:05 --> Language Class Initialized
INFO - 2016-08-25 08:04:05 --> Loader Class Initialized
INFO - 2016-08-25 08:04:05 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:05 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:05 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:05 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:05 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:05 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:05 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:05 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:05 --> Email Class Initialized
INFO - 2016-08-25 08:04:05 --> Controller Class Initialized
INFO - 2016-08-25 08:04:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 08:04:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:05 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:05 --> Total execution time: 0.2250
INFO - 2016-08-25 08:04:08 --> Config Class Initialized
INFO - 2016-08-25 08:04:08 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:08 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:08 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:08 --> URI Class Initialized
INFO - 2016-08-25 08:04:08 --> Router Class Initialized
INFO - 2016-08-25 08:04:08 --> Output Class Initialized
INFO - 2016-08-25 08:04:08 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:08 --> Input Class Initialized
INFO - 2016-08-25 08:04:08 --> Language Class Initialized
INFO - 2016-08-25 08:04:08 --> Loader Class Initialized
INFO - 2016-08-25 08:04:08 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:08 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:08 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:08 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:08 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:08 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:08 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:08 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:08 --> Email Class Initialized
INFO - 2016-08-25 08:04:08 --> Controller Class Initialized
INFO - 2016-08-25 08:04:08 --> Model Class Initialized
INFO - 2016-08-25 08:04:08 --> Model Class Initialized
INFO - 2016-08-25 08:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/book_request.php
INFO - 2016-08-25 08:04:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:08 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:08 --> Total execution time: 0.2358
INFO - 2016-08-25 08:04:11 --> Config Class Initialized
INFO - 2016-08-25 08:04:11 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:11 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:11 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:11 --> URI Class Initialized
INFO - 2016-08-25 08:04:11 --> Router Class Initialized
INFO - 2016-08-25 08:04:11 --> Output Class Initialized
INFO - 2016-08-25 08:04:11 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:11 --> Input Class Initialized
INFO - 2016-08-25 08:04:11 --> Language Class Initialized
INFO - 2016-08-25 08:04:11 --> Loader Class Initialized
INFO - 2016-08-25 08:04:11 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:11 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:11 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:11 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:11 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:11 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:11 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:11 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:11 --> Email Class Initialized
INFO - 2016-08-25 08:04:11 --> Controller Class Initialized
INFO - 2016-08-25 08:04:11 --> Model Class Initialized
INFO - 2016-08-25 08:04:11 --> Model Class Initialized
INFO - 2016-08-25 08:04:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-25 08:04:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:11 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:11 --> Total execution time: 0.2412
INFO - 2016-08-25 08:04:13 --> Config Class Initialized
INFO - 2016-08-25 08:04:13 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:13 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:13 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:13 --> URI Class Initialized
INFO - 2016-08-25 08:04:13 --> Router Class Initialized
INFO - 2016-08-25 08:04:13 --> Output Class Initialized
INFO - 2016-08-25 08:04:13 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:13 --> Input Class Initialized
INFO - 2016-08-25 08:04:13 --> Language Class Initialized
INFO - 2016-08-25 08:04:13 --> Loader Class Initialized
INFO - 2016-08-25 08:04:13 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:13 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:13 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:13 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:13 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:13 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:13 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:13 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:13 --> Email Class Initialized
INFO - 2016-08-25 08:04:13 --> Controller Class Initialized
INFO - 2016-08-25 08:04:13 --> Model Class Initialized
INFO - 2016-08-25 08:04:13 --> Model Class Initialized
INFO - 2016-08-25 08:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-25 08:04:13 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:13 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:13 --> Total execution time: 0.2431
INFO - 2016-08-25 08:04:18 --> Config Class Initialized
INFO - 2016-08-25 08:04:18 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:18 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:18 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:18 --> URI Class Initialized
INFO - 2016-08-25 08:04:18 --> Router Class Initialized
INFO - 2016-08-25 08:04:18 --> Output Class Initialized
INFO - 2016-08-25 08:04:18 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:18 --> Input Class Initialized
INFO - 2016-08-25 08:04:18 --> Language Class Initialized
INFO - 2016-08-25 08:04:18 --> Loader Class Initialized
INFO - 2016-08-25 08:04:18 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:18 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:18 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:18 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:18 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:18 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:18 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:18 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:18 --> Email Class Initialized
INFO - 2016-08-25 08:04:18 --> Controller Class Initialized
DEBUG - 2016-08-25 08:04:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:04:18 --> Model Class Initialized
INFO - 2016-08-25 08:04:18 --> Model Class Initialized
INFO - 2016-08-25 08:04:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-25 08:04:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:18 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:18 --> Total execution time: 0.2462
INFO - 2016-08-25 08:04:21 --> Config Class Initialized
INFO - 2016-08-25 08:04:21 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:21 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:21 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:21 --> URI Class Initialized
INFO - 2016-08-25 08:04:21 --> Router Class Initialized
INFO - 2016-08-25 08:04:21 --> Output Class Initialized
INFO - 2016-08-25 08:04:21 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:21 --> Input Class Initialized
INFO - 2016-08-25 08:04:21 --> Language Class Initialized
INFO - 2016-08-25 08:04:21 --> Loader Class Initialized
INFO - 2016-08-25 08:04:21 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:21 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:21 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:21 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:21 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:21 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:21 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:21 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:21 --> Email Class Initialized
INFO - 2016-08-25 08:04:21 --> Controller Class Initialized
INFO - 2016-08-25 08:04:21 --> Model Class Initialized
DEBUG - 2016-08-25 08:04:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-25 08:04:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:21 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:21 --> Total execution time: 0.2425
INFO - 2016-08-25 08:04:24 --> Config Class Initialized
INFO - 2016-08-25 08:04:24 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:24 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:24 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:24 --> URI Class Initialized
INFO - 2016-08-25 08:04:24 --> Router Class Initialized
INFO - 2016-08-25 08:04:24 --> Output Class Initialized
INFO - 2016-08-25 08:04:24 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:24 --> Input Class Initialized
INFO - 2016-08-25 08:04:24 --> Language Class Initialized
INFO - 2016-08-25 08:04:24 --> Loader Class Initialized
INFO - 2016-08-25 08:04:24 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:24 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:24 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:24 --> Email Class Initialized
INFO - 2016-08-25 08:04:24 --> Controller Class Initialized
INFO - 2016-08-25 08:04:24 --> Model Class Initialized
INFO - 2016-08-25 08:04:24 --> Config Class Initialized
INFO - 2016-08-25 08:04:24 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:04:24 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:04:24 --> Utf8 Class Initialized
INFO - 2016-08-25 08:04:24 --> URI Class Initialized
INFO - 2016-08-25 08:04:24 --> Router Class Initialized
INFO - 2016-08-25 08:04:24 --> Output Class Initialized
INFO - 2016-08-25 08:04:24 --> Security Class Initialized
DEBUG - 2016-08-25 08:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:04:24 --> Input Class Initialized
INFO - 2016-08-25 08:04:24 --> Language Class Initialized
INFO - 2016-08-25 08:04:24 --> Loader Class Initialized
INFO - 2016-08-25 08:04:24 --> Helper loaded: url_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: html_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: form_helper
INFO - 2016-08-25 08:04:24 --> Helper loaded: file_helper
INFO - 2016-08-25 08:04:25 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:04:25 --> Database Driver Class Initialized
INFO - 2016-08-25 08:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:04:25 --> Form Validation Class Initialized
INFO - 2016-08-25 08:04:25 --> Email Class Initialized
INFO - 2016-08-25 08:04:25 --> Controller Class Initialized
INFO - 2016-08-25 08:04:25 --> Model Class Initialized
DEBUG - 2016-08-25 08:04:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:04:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 08:04:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:04:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 08:04:25 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:04:25 --> Final output sent to browser
DEBUG - 2016-08-25 08:04:25 --> Total execution time: 0.2371
INFO - 2016-08-25 08:05:03 --> Config Class Initialized
INFO - 2016-08-25 08:05:03 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:03 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:03 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:03 --> URI Class Initialized
INFO - 2016-08-25 08:05:03 --> Router Class Initialized
INFO - 2016-08-25 08:05:03 --> Output Class Initialized
INFO - 2016-08-25 08:05:03 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:03 --> Input Class Initialized
INFO - 2016-08-25 08:05:03 --> Language Class Initialized
INFO - 2016-08-25 08:05:03 --> Loader Class Initialized
INFO - 2016-08-25 08:05:03 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:03 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:03 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:03 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:03 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:03 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:03 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:03 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:03 --> Email Class Initialized
INFO - 2016-08-25 08:05:03 --> Controller Class Initialized
INFO - 2016-08-25 08:05:03 --> Model Class Initialized
INFO - 2016-08-25 08:05:03 --> Final output sent to browser
DEBUG - 2016-08-25 08:05:03 --> Total execution time: 0.2294
INFO - 2016-08-25 08:05:06 --> Config Class Initialized
INFO - 2016-08-25 08:05:06 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:06 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:06 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:06 --> URI Class Initialized
INFO - 2016-08-25 08:05:06 --> Router Class Initialized
INFO - 2016-08-25 08:05:06 --> Output Class Initialized
INFO - 2016-08-25 08:05:06 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:06 --> Input Class Initialized
INFO - 2016-08-25 08:05:06 --> Language Class Initialized
INFO - 2016-08-25 08:05:06 --> Loader Class Initialized
INFO - 2016-08-25 08:05:06 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:06 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:06 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:06 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:06 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:06 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:06 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:06 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:06 --> Email Class Initialized
INFO - 2016-08-25 08:05:06 --> Controller Class Initialized
INFO - 2016-08-25 08:05:06 --> Model Class Initialized
INFO - 2016-08-25 08:05:08 --> Config Class Initialized
INFO - 2016-08-25 08:05:08 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:08 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:08 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:08 --> URI Class Initialized
DEBUG - 2016-08-25 08:05:08 --> No URI present. Default controller set.
INFO - 2016-08-25 08:05:08 --> Router Class Initialized
INFO - 2016-08-25 08:05:08 --> Output Class Initialized
INFO - 2016-08-25 08:05:08 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:08 --> Input Class Initialized
INFO - 2016-08-25 08:05:08 --> Language Class Initialized
INFO - 2016-08-25 08:05:08 --> Loader Class Initialized
INFO - 2016-08-25 08:05:08 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:08 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:08 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:08 --> Email Class Initialized
INFO - 2016-08-25 08:05:08 --> Controller Class Initialized
INFO - 2016-08-25 08:05:08 --> Config Class Initialized
INFO - 2016-08-25 08:05:08 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:08 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:08 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:08 --> URI Class Initialized
INFO - 2016-08-25 08:05:08 --> Router Class Initialized
INFO - 2016-08-25 08:05:08 --> Output Class Initialized
INFO - 2016-08-25 08:05:08 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:08 --> Input Class Initialized
INFO - 2016-08-25 08:05:08 --> Language Class Initialized
INFO - 2016-08-25 08:05:08 --> Loader Class Initialized
INFO - 2016-08-25 08:05:08 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:08 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:08 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:08 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:08 --> Email Class Initialized
INFO - 2016-08-25 08:05:08 --> Controller Class Initialized
INFO - 2016-08-25 08:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-25 08:05:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:05:08 --> Final output sent to browser
DEBUG - 2016-08-25 08:05:08 --> Total execution time: 0.2272
INFO - 2016-08-25 08:05:51 --> Config Class Initialized
INFO - 2016-08-25 08:05:51 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:51 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:51 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:51 --> URI Class Initialized
INFO - 2016-08-25 08:05:51 --> Router Class Initialized
INFO - 2016-08-25 08:05:51 --> Output Class Initialized
INFO - 2016-08-25 08:05:51 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:51 --> Input Class Initialized
INFO - 2016-08-25 08:05:51 --> Language Class Initialized
INFO - 2016-08-25 08:05:51 --> Loader Class Initialized
INFO - 2016-08-25 08:05:51 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:51 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:51 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:51 --> Email Class Initialized
INFO - 2016-08-25 08:05:51 --> Controller Class Initialized
INFO - 2016-08-25 08:05:51 --> Model Class Initialized
INFO - 2016-08-25 08:05:51 --> Config Class Initialized
INFO - 2016-08-25 08:05:51 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:51 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:51 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:51 --> URI Class Initialized
INFO - 2016-08-25 08:05:51 --> Router Class Initialized
INFO - 2016-08-25 08:05:51 --> Output Class Initialized
INFO - 2016-08-25 08:05:51 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:51 --> Input Class Initialized
INFO - 2016-08-25 08:05:51 --> Language Class Initialized
INFO - 2016-08-25 08:05:51 --> Loader Class Initialized
INFO - 2016-08-25 08:05:51 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:51 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:51 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:51 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:51 --> Email Class Initialized
INFO - 2016-08-25 08:05:51 --> Controller Class Initialized
INFO - 2016-08-25 08:05:51 --> Model Class Initialized
DEBUG - 2016-08-25 08:05:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 08:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 08:05:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:05:51 --> Final output sent to browser
DEBUG - 2016-08-25 08:05:51 --> Total execution time: 0.2524
INFO - 2016-08-25 08:05:53 --> Config Class Initialized
INFO - 2016-08-25 08:05:53 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:53 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:53 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:53 --> URI Class Initialized
INFO - 2016-08-25 08:05:53 --> Router Class Initialized
INFO - 2016-08-25 08:05:53 --> Output Class Initialized
INFO - 2016-08-25 08:05:53 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:53 --> Input Class Initialized
INFO - 2016-08-25 08:05:53 --> Language Class Initialized
INFO - 2016-08-25 08:05:53 --> Loader Class Initialized
INFO - 2016-08-25 08:05:53 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:53 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:53 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:53 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:53 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:53 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:53 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:53 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:53 --> Email Class Initialized
INFO - 2016-08-25 08:05:53 --> Controller Class Initialized
INFO - 2016-08-25 08:05:53 --> Model Class Initialized
INFO - 2016-08-25 08:05:53 --> Final output sent to browser
DEBUG - 2016-08-25 08:05:53 --> Total execution time: 0.2373
INFO - 2016-08-25 08:05:56 --> Config Class Initialized
INFO - 2016-08-25 08:05:56 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:05:56 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:05:56 --> Utf8 Class Initialized
INFO - 2016-08-25 08:05:56 --> URI Class Initialized
INFO - 2016-08-25 08:05:56 --> Router Class Initialized
INFO - 2016-08-25 08:05:56 --> Output Class Initialized
INFO - 2016-08-25 08:05:56 --> Security Class Initialized
DEBUG - 2016-08-25 08:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:05:56 --> Input Class Initialized
INFO - 2016-08-25 08:05:56 --> Language Class Initialized
INFO - 2016-08-25 08:05:56 --> Loader Class Initialized
INFO - 2016-08-25 08:05:56 --> Helper loaded: url_helper
INFO - 2016-08-25 08:05:56 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:05:56 --> Helper loaded: html_helper
INFO - 2016-08-25 08:05:56 --> Helper loaded: form_helper
INFO - 2016-08-25 08:05:56 --> Helper loaded: file_helper
INFO - 2016-08-25 08:05:56 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:05:56 --> Database Driver Class Initialized
INFO - 2016-08-25 08:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:05:56 --> Form Validation Class Initialized
INFO - 2016-08-25 08:05:56 --> Email Class Initialized
INFO - 2016-08-25 08:05:56 --> Controller Class Initialized
INFO - 2016-08-25 08:05:56 --> Model Class Initialized
INFO - 2016-08-25 08:06:29 --> Config Class Initialized
INFO - 2016-08-25 08:06:29 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:06:29 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:06:29 --> Utf8 Class Initialized
INFO - 2016-08-25 08:06:29 --> URI Class Initialized
INFO - 2016-08-25 08:06:29 --> Router Class Initialized
INFO - 2016-08-25 08:06:29 --> Output Class Initialized
INFO - 2016-08-25 08:06:29 --> Security Class Initialized
DEBUG - 2016-08-25 08:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:06:29 --> Input Class Initialized
INFO - 2016-08-25 08:06:29 --> Language Class Initialized
INFO - 2016-08-25 08:06:29 --> Loader Class Initialized
INFO - 2016-08-25 08:06:29 --> Helper loaded: url_helper
INFO - 2016-08-25 08:06:29 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:06:29 --> Helper loaded: html_helper
INFO - 2016-08-25 08:06:29 --> Helper loaded: form_helper
INFO - 2016-08-25 08:06:29 --> Helper loaded: file_helper
INFO - 2016-08-25 08:06:29 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:06:29 --> Database Driver Class Initialized
INFO - 2016-08-25 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:06:29 --> Form Validation Class Initialized
INFO - 2016-08-25 08:06:29 --> Email Class Initialized
INFO - 2016-08-25 08:06:29 --> Controller Class Initialized
INFO - 2016-08-25 08:06:29 --> Model Class Initialized
INFO - 2016-08-25 08:06:31 --> Config Class Initialized
INFO - 2016-08-25 08:06:31 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:06:31 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:06:31 --> Utf8 Class Initialized
INFO - 2016-08-25 08:06:31 --> URI Class Initialized
INFO - 2016-08-25 08:06:31 --> Router Class Initialized
INFO - 2016-08-25 08:06:31 --> Output Class Initialized
INFO - 2016-08-25 08:06:31 --> Security Class Initialized
DEBUG - 2016-08-25 08:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:06:31 --> Input Class Initialized
INFO - 2016-08-25 08:06:31 --> Language Class Initialized
INFO - 2016-08-25 08:06:31 --> Loader Class Initialized
INFO - 2016-08-25 08:06:31 --> Helper loaded: url_helper
INFO - 2016-08-25 08:06:31 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:06:31 --> Helper loaded: html_helper
INFO - 2016-08-25 08:06:31 --> Helper loaded: form_helper
INFO - 2016-08-25 08:06:31 --> Helper loaded: file_helper
INFO - 2016-08-25 08:06:31 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:06:31 --> Database Driver Class Initialized
INFO - 2016-08-25 08:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:06:31 --> Form Validation Class Initialized
INFO - 2016-08-25 08:06:31 --> Email Class Initialized
INFO - 2016-08-25 08:06:31 --> Controller Class Initialized
DEBUG - 2016-08-25 08:06:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-25 08:06:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:06:31 --> Model Class Initialized
INFO - 2016-08-25 08:06:31 --> Model Class Initialized
INFO - 2016-08-25 08:06:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:06:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 08:06:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-25 08:06:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:06:31 --> Final output sent to browser
DEBUG - 2016-08-25 08:06:31 --> Total execution time: 0.3277
INFO - 2016-08-25 08:08:16 --> Config Class Initialized
INFO - 2016-08-25 08:08:16 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:08:16 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:08:16 --> Utf8 Class Initialized
INFO - 2016-08-25 08:08:16 --> URI Class Initialized
INFO - 2016-08-25 08:08:16 --> Router Class Initialized
INFO - 2016-08-25 08:08:16 --> Output Class Initialized
INFO - 2016-08-25 08:08:16 --> Security Class Initialized
DEBUG - 2016-08-25 08:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:08:16 --> Input Class Initialized
INFO - 2016-08-25 08:08:16 --> Language Class Initialized
INFO - 2016-08-25 08:08:16 --> Loader Class Initialized
INFO - 2016-08-25 08:08:16 --> Helper loaded: url_helper
INFO - 2016-08-25 08:08:16 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:08:16 --> Helper loaded: html_helper
INFO - 2016-08-25 08:08:16 --> Helper loaded: form_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: file_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:08:17 --> Database Driver Class Initialized
INFO - 2016-08-25 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:08:17 --> Form Validation Class Initialized
INFO - 2016-08-25 08:08:17 --> Email Class Initialized
INFO - 2016-08-25 08:08:17 --> Controller Class Initialized
INFO - 2016-08-25 08:08:17 --> Model Class Initialized
INFO - 2016-08-25 08:08:17 --> Config Class Initialized
INFO - 2016-08-25 08:08:17 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:08:17 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:08:17 --> Utf8 Class Initialized
INFO - 2016-08-25 08:08:17 --> URI Class Initialized
INFO - 2016-08-25 08:08:17 --> Router Class Initialized
INFO - 2016-08-25 08:08:17 --> Output Class Initialized
INFO - 2016-08-25 08:08:17 --> Security Class Initialized
DEBUG - 2016-08-25 08:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:08:17 --> Input Class Initialized
INFO - 2016-08-25 08:08:17 --> Language Class Initialized
INFO - 2016-08-25 08:08:17 --> Loader Class Initialized
INFO - 2016-08-25 08:08:17 --> Helper loaded: url_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: html_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: form_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: file_helper
INFO - 2016-08-25 08:08:17 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:08:17 --> Database Driver Class Initialized
INFO - 2016-08-25 08:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:08:17 --> Form Validation Class Initialized
INFO - 2016-08-25 08:08:17 --> Email Class Initialized
INFO - 2016-08-25 08:08:17 --> Controller Class Initialized
INFO - 2016-08-25 08:08:17 --> Model Class Initialized
DEBUG - 2016-08-25 08:08:17 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 08:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 08:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 08:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 08:08:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 08:08:17 --> Final output sent to browser
DEBUG - 2016-08-25 08:08:17 --> Total execution time: 0.3623
INFO - 2016-08-25 08:08:19 --> Config Class Initialized
INFO - 2016-08-25 08:08:19 --> Hooks Class Initialized
DEBUG - 2016-08-25 08:08:19 --> UTF-8 Support Enabled
INFO - 2016-08-25 08:08:19 --> Utf8 Class Initialized
INFO - 2016-08-25 08:08:19 --> URI Class Initialized
INFO - 2016-08-25 08:08:19 --> Router Class Initialized
INFO - 2016-08-25 08:08:19 --> Output Class Initialized
INFO - 2016-08-25 08:08:19 --> Security Class Initialized
DEBUG - 2016-08-25 08:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 08:08:19 --> Input Class Initialized
INFO - 2016-08-25 08:08:19 --> Language Class Initialized
INFO - 2016-08-25 08:08:19 --> Loader Class Initialized
INFO - 2016-08-25 08:08:19 --> Helper loaded: url_helper
INFO - 2016-08-25 08:08:19 --> Helper loaded: utils_helper
INFO - 2016-08-25 08:08:19 --> Helper loaded: html_helper
INFO - 2016-08-25 08:08:19 --> Helper loaded: form_helper
INFO - 2016-08-25 08:08:19 --> Helper loaded: file_helper
INFO - 2016-08-25 08:08:19 --> Helper loaded: myemail_helper
INFO - 2016-08-25 08:08:19 --> Database Driver Class Initialized
INFO - 2016-08-25 08:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 08:08:19 --> Form Validation Class Initialized
INFO - 2016-08-25 08:08:19 --> Email Class Initialized
INFO - 2016-08-25 08:08:19 --> Controller Class Initialized
INFO - 2016-08-25 08:08:19 --> Model Class Initialized
INFO - 2016-08-25 08:08:19 --> Final output sent to browser
DEBUG - 2016-08-25 08:08:19 --> Total execution time: 0.3135
INFO - 2016-08-25 09:33:08 --> Config Class Initialized
INFO - 2016-08-25 09:33:08 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:08 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:08 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:08 --> URI Class Initialized
INFO - 2016-08-25 09:33:08 --> Router Class Initialized
INFO - 2016-08-25 09:33:08 --> Output Class Initialized
INFO - 2016-08-25 09:33:08 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:08 --> Input Class Initialized
INFO - 2016-08-25 09:33:08 --> Language Class Initialized
INFO - 2016-08-25 09:33:08 --> Loader Class Initialized
INFO - 2016-08-25 09:33:08 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:08 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:08 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:08 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:08 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:08 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:08 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:08 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:08 --> Email Class Initialized
INFO - 2016-08-25 09:33:08 --> Controller Class Initialized
INFO - 2016-08-25 09:33:08 --> Model Class Initialized
INFO - 2016-08-25 09:33:11 --> Config Class Initialized
INFO - 2016-08-25 09:33:11 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:11 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:11 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:11 --> URI Class Initialized
INFO - 2016-08-25 09:33:11 --> Router Class Initialized
INFO - 2016-08-25 09:33:11 --> Output Class Initialized
INFO - 2016-08-25 09:33:11 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:11 --> Input Class Initialized
INFO - 2016-08-25 09:33:11 --> Language Class Initialized
INFO - 2016-08-25 09:33:11 --> Loader Class Initialized
INFO - 2016-08-25 09:33:11 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:11 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:11 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:11 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:11 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:11 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:11 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:11 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:11 --> Email Class Initialized
INFO - 2016-08-25 09:33:11 --> Controller Class Initialized
INFO - 2016-08-25 09:33:11 --> Model Class Initialized
INFO - 2016-08-25 09:33:11 --> Model Class Initialized
INFO - 2016-08-25 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-25 09:33:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:11 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:11 --> Total execution time: 0.3701
INFO - 2016-08-25 09:33:20 --> Config Class Initialized
INFO - 2016-08-25 09:33:20 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:20 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:20 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:20 --> URI Class Initialized
INFO - 2016-08-25 09:33:20 --> Router Class Initialized
INFO - 2016-08-25 09:33:20 --> Output Class Initialized
INFO - 2016-08-25 09:33:20 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:20 --> Input Class Initialized
INFO - 2016-08-25 09:33:20 --> Language Class Initialized
INFO - 2016-08-25 09:33:20 --> Loader Class Initialized
INFO - 2016-08-25 09:33:20 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:20 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:20 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:20 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:20 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:20 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:20 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:20 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:20 --> Email Class Initialized
INFO - 2016-08-25 09:33:20 --> Controller Class Initialized
INFO - 2016-08-25 09:33:20 --> Model Class Initialized
INFO - 2016-08-25 09:33:20 --> Config Class Initialized
INFO - 2016-08-25 09:33:20 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:20 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:20 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:20 --> URI Class Initialized
INFO - 2016-08-25 09:33:20 --> Router Class Initialized
INFO - 2016-08-25 09:33:20 --> Output Class Initialized
INFO - 2016-08-25 09:33:20 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:20 --> Input Class Initialized
INFO - 2016-08-25 09:33:20 --> Language Class Initialized
INFO - 2016-08-25 09:33:20 --> Loader Class Initialized
INFO - 2016-08-25 09:33:20 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:21 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:21 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:21 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:21 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:21 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:21 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:21 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:21 --> Email Class Initialized
INFO - 2016-08-25 09:33:21 --> Controller Class Initialized
INFO - 2016-08-25 09:33:21 --> Model Class Initialized
DEBUG - 2016-08-25 09:33:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 09:33:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 09:33:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:21 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:21 --> Total execution time: 0.3564
INFO - 2016-08-25 09:33:31 --> Config Class Initialized
INFO - 2016-08-25 09:33:31 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:31 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:31 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:31 --> URI Class Initialized
INFO - 2016-08-25 09:33:31 --> Router Class Initialized
INFO - 2016-08-25 09:33:31 --> Output Class Initialized
INFO - 2016-08-25 09:33:31 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:31 --> Input Class Initialized
INFO - 2016-08-25 09:33:31 --> Language Class Initialized
INFO - 2016-08-25 09:33:31 --> Loader Class Initialized
INFO - 2016-08-25 09:33:31 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:31 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:31 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:31 --> Email Class Initialized
INFO - 2016-08-25 09:33:31 --> Controller Class Initialized
INFO - 2016-08-25 09:33:31 --> Model Class Initialized
DEBUG - 2016-08-25 09:33:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-25 09:33:31 --> Config Class Initialized
INFO - 2016-08-25 09:33:31 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:31 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:31 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:31 --> URI Class Initialized
INFO - 2016-08-25 09:33:31 --> Router Class Initialized
INFO - 2016-08-25 09:33:31 --> Output Class Initialized
INFO - 2016-08-25 09:33:31 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:31 --> Input Class Initialized
INFO - 2016-08-25 09:33:31 --> Language Class Initialized
INFO - 2016-08-25 09:33:31 --> Loader Class Initialized
INFO - 2016-08-25 09:33:31 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:31 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:32 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:32 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:32 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:32 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:32 --> Email Class Initialized
INFO - 2016-08-25 09:33:32 --> Controller Class Initialized
DEBUG - 2016-08-25 09:33:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-25 09:33:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:32 --> Model Class Initialized
INFO - 2016-08-25 09:33:32 --> Model Class Initialized
INFO - 2016-08-25 09:33:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:33:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-25 09:33:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:32 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:32 --> Total execution time: 0.4291
INFO - 2016-08-25 09:33:37 --> Config Class Initialized
INFO - 2016-08-25 09:33:37 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:37 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:37 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:37 --> URI Class Initialized
INFO - 2016-08-25 09:33:37 --> Router Class Initialized
INFO - 2016-08-25 09:33:37 --> Output Class Initialized
INFO - 2016-08-25 09:33:37 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:37 --> Input Class Initialized
INFO - 2016-08-25 09:33:37 --> Language Class Initialized
INFO - 2016-08-25 09:33:37 --> Loader Class Initialized
INFO - 2016-08-25 09:33:37 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:37 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:37 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:37 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:37 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:37 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:37 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:37 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:37 --> Email Class Initialized
INFO - 2016-08-25 09:33:37 --> Controller Class Initialized
INFO - 2016-08-25 09:33:37 --> Model Class Initialized
INFO - 2016-08-25 09:33:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:33:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-25 09:33:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:37 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:37 --> Total execution time: 0.3374
INFO - 2016-08-25 09:33:42 --> Config Class Initialized
INFO - 2016-08-25 09:33:42 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:42 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:42 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:42 --> URI Class Initialized
INFO - 2016-08-25 09:33:42 --> Router Class Initialized
INFO - 2016-08-25 09:33:42 --> Output Class Initialized
INFO - 2016-08-25 09:33:42 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:42 --> Input Class Initialized
INFO - 2016-08-25 09:33:42 --> Language Class Initialized
INFO - 2016-08-25 09:33:42 --> Loader Class Initialized
INFO - 2016-08-25 09:33:42 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:42 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:42 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:42 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:42 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:42 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:42 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:42 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:42 --> Email Class Initialized
INFO - 2016-08-25 09:33:42 --> Controller Class Initialized
INFO - 2016-08-25 09:33:42 --> Model Class Initialized
DEBUG - 2016-08-25 09:33:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:33:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-25 09:33:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:42 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:42 --> Total execution time: 0.3580
INFO - 2016-08-25 09:33:48 --> Config Class Initialized
INFO - 2016-08-25 09:33:48 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:48 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:48 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:48 --> URI Class Initialized
INFO - 2016-08-25 09:33:48 --> Router Class Initialized
INFO - 2016-08-25 09:33:48 --> Output Class Initialized
INFO - 2016-08-25 09:33:48 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:48 --> Input Class Initialized
INFO - 2016-08-25 09:33:48 --> Language Class Initialized
INFO - 2016-08-25 09:33:48 --> Loader Class Initialized
INFO - 2016-08-25 09:33:48 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:48 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:48 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:48 --> Email Class Initialized
INFO - 2016-08-25 09:33:48 --> Controller Class Initialized
INFO - 2016-08-25 09:33:48 --> Model Class Initialized
DEBUG - 2016-08-25 09:33:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-25 09:33:48 --> Config Class Initialized
INFO - 2016-08-25 09:33:48 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:48 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:48 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:48 --> URI Class Initialized
DEBUG - 2016-08-25 09:33:48 --> No URI present. Default controller set.
INFO - 2016-08-25 09:33:48 --> Router Class Initialized
INFO - 2016-08-25 09:33:48 --> Output Class Initialized
INFO - 2016-08-25 09:33:48 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:48 --> Input Class Initialized
INFO - 2016-08-25 09:33:48 --> Language Class Initialized
INFO - 2016-08-25 09:33:48 --> Loader Class Initialized
INFO - 2016-08-25 09:33:48 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:48 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:49 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:49 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:49 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:49 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:49 --> Email Class Initialized
INFO - 2016-08-25 09:33:49 --> Controller Class Initialized
INFO - 2016-08-25 09:33:49 --> Model Class Initialized
INFO - 2016-08-25 09:33:49 --> Model Class Initialized
INFO - 2016-08-25 09:33:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:33:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-25 09:33:49 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:49 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:49 --> Total execution time: 0.3811
INFO - 2016-08-25 09:33:51 --> Config Class Initialized
INFO - 2016-08-25 09:33:51 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:51 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:51 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:51 --> URI Class Initialized
INFO - 2016-08-25 09:33:51 --> Router Class Initialized
INFO - 2016-08-25 09:33:51 --> Output Class Initialized
INFO - 2016-08-25 09:33:51 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:51 --> Input Class Initialized
INFO - 2016-08-25 09:33:51 --> Language Class Initialized
INFO - 2016-08-25 09:33:51 --> Loader Class Initialized
INFO - 2016-08-25 09:33:51 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:51 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:52 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:52 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:52 --> Email Class Initialized
INFO - 2016-08-25 09:33:52 --> Controller Class Initialized
INFO - 2016-08-25 09:33:52 --> Model Class Initialized
INFO - 2016-08-25 09:33:52 --> Config Class Initialized
INFO - 2016-08-25 09:33:52 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:52 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:52 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:52 --> URI Class Initialized
INFO - 2016-08-25 09:33:52 --> Router Class Initialized
INFO - 2016-08-25 09:33:52 --> Output Class Initialized
INFO - 2016-08-25 09:33:52 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:52 --> Input Class Initialized
INFO - 2016-08-25 09:33:52 --> Language Class Initialized
INFO - 2016-08-25 09:33:52 --> Loader Class Initialized
INFO - 2016-08-25 09:33:52 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:52 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:52 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:52 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:52 --> Email Class Initialized
INFO - 2016-08-25 09:33:52 --> Controller Class Initialized
INFO - 2016-08-25 09:33:52 --> Model Class Initialized
DEBUG - 2016-08-25 09:33:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 09:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 09:33:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:33:52 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:52 --> Total execution time: 0.3611
INFO - 2016-08-25 09:33:55 --> Config Class Initialized
INFO - 2016-08-25 09:33:55 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:55 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:55 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:55 --> URI Class Initialized
INFO - 2016-08-25 09:33:55 --> Router Class Initialized
INFO - 2016-08-25 09:33:55 --> Output Class Initialized
INFO - 2016-08-25 09:33:55 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:55 --> Input Class Initialized
INFO - 2016-08-25 09:33:55 --> Language Class Initialized
INFO - 2016-08-25 09:33:55 --> Loader Class Initialized
INFO - 2016-08-25 09:33:55 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:55 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:55 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:55 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:55 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:55 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:55 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:55 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:55 --> Email Class Initialized
INFO - 2016-08-25 09:33:55 --> Controller Class Initialized
INFO - 2016-08-25 09:33:55 --> Model Class Initialized
INFO - 2016-08-25 09:33:55 --> Final output sent to browser
DEBUG - 2016-08-25 09:33:55 --> Total execution time: 0.3113
INFO - 2016-08-25 09:33:58 --> Config Class Initialized
INFO - 2016-08-25 09:33:58 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:33:58 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:33:58 --> Utf8 Class Initialized
INFO - 2016-08-25 09:33:58 --> URI Class Initialized
INFO - 2016-08-25 09:33:58 --> Router Class Initialized
INFO - 2016-08-25 09:33:58 --> Output Class Initialized
INFO - 2016-08-25 09:33:58 --> Security Class Initialized
DEBUG - 2016-08-25 09:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:33:58 --> Input Class Initialized
INFO - 2016-08-25 09:33:58 --> Language Class Initialized
INFO - 2016-08-25 09:33:58 --> Loader Class Initialized
INFO - 2016-08-25 09:33:58 --> Helper loaded: url_helper
INFO - 2016-08-25 09:33:58 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:33:58 --> Helper loaded: html_helper
INFO - 2016-08-25 09:33:58 --> Helper loaded: form_helper
INFO - 2016-08-25 09:33:58 --> Helper loaded: file_helper
INFO - 2016-08-25 09:33:58 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:33:58 --> Database Driver Class Initialized
INFO - 2016-08-25 09:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:33:58 --> Form Validation Class Initialized
INFO - 2016-08-25 09:33:59 --> Email Class Initialized
INFO - 2016-08-25 09:33:59 --> Controller Class Initialized
INFO - 2016-08-25 09:33:59 --> Model Class Initialized
INFO - 2016-08-25 09:34:00 --> Config Class Initialized
INFO - 2016-08-25 09:34:00 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:00 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:00 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:00 --> URI Class Initialized
INFO - 2016-08-25 09:34:00 --> Router Class Initialized
INFO - 2016-08-25 09:34:00 --> Output Class Initialized
INFO - 2016-08-25 09:34:00 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:00 --> Input Class Initialized
INFO - 2016-08-25 09:34:00 --> Language Class Initialized
INFO - 2016-08-25 09:34:00 --> Loader Class Initialized
INFO - 2016-08-25 09:34:00 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:00 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:00 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:00 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:00 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:00 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:01 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:01 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:01 --> Email Class Initialized
INFO - 2016-08-25 09:34:01 --> Controller Class Initialized
INFO - 2016-08-25 09:34:01 --> Model Class Initialized
INFO - 2016-08-25 09:34:01 --> Model Class Initialized
INFO - 2016-08-25 09:34:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:34:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:34:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-25 09:34:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:34:01 --> Final output sent to browser
DEBUG - 2016-08-25 09:34:01 --> Total execution time: 0.3865
INFO - 2016-08-25 09:34:32 --> Config Class Initialized
INFO - 2016-08-25 09:34:32 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:32 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:32 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:32 --> URI Class Initialized
INFO - 2016-08-25 09:34:32 --> Router Class Initialized
INFO - 2016-08-25 09:34:32 --> Output Class Initialized
INFO - 2016-08-25 09:34:32 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:32 --> Input Class Initialized
INFO - 2016-08-25 09:34:32 --> Language Class Initialized
INFO - 2016-08-25 09:34:32 --> Loader Class Initialized
INFO - 2016-08-25 09:34:32 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:32 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:32 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:32 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:32 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:32 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:32 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:33 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:33 --> Email Class Initialized
INFO - 2016-08-25 09:34:33 --> Controller Class Initialized
INFO - 2016-08-25 09:34:33 --> Model Class Initialized
DEBUG - 2016-08-25 09:34:33 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:34:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:34:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:34:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-08-25 09:34:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:34:33 --> Final output sent to browser
DEBUG - 2016-08-25 09:34:33 --> Total execution time: 0.3643
INFO - 2016-08-25 09:34:43 --> Config Class Initialized
INFO - 2016-08-25 09:34:43 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:43 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:43 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:43 --> URI Class Initialized
INFO - 2016-08-25 09:34:43 --> Router Class Initialized
INFO - 2016-08-25 09:34:43 --> Output Class Initialized
INFO - 2016-08-25 09:34:43 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:43 --> Input Class Initialized
INFO - 2016-08-25 09:34:43 --> Language Class Initialized
INFO - 2016-08-25 09:34:43 --> Loader Class Initialized
INFO - 2016-08-25 09:34:43 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:43 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:43 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:43 --> Email Class Initialized
INFO - 2016-08-25 09:34:43 --> Controller Class Initialized
INFO - 2016-08-25 09:34:43 --> Model Class Initialized
INFO - 2016-08-25 09:34:43 --> Config Class Initialized
INFO - 2016-08-25 09:34:43 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:43 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:43 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:43 --> URI Class Initialized
INFO - 2016-08-25 09:34:43 --> Router Class Initialized
INFO - 2016-08-25 09:34:43 --> Output Class Initialized
INFO - 2016-08-25 09:34:43 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:43 --> Input Class Initialized
INFO - 2016-08-25 09:34:43 --> Language Class Initialized
INFO - 2016-08-25 09:34:43 --> Loader Class Initialized
INFO - 2016-08-25 09:34:43 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:43 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:43 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:43 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:43 --> Email Class Initialized
INFO - 2016-08-25 09:34:43 --> Controller Class Initialized
INFO - 2016-08-25 09:34:43 --> Model Class Initialized
DEBUG - 2016-08-25 09:34:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:34:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 09:34:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:34:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 09:34:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:34:43 --> Final output sent to browser
DEBUG - 2016-08-25 09:34:43 --> Total execution time: 0.3940
INFO - 2016-08-25 09:34:55 --> Config Class Initialized
INFO - 2016-08-25 09:34:55 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:55 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:55 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:55 --> URI Class Initialized
INFO - 2016-08-25 09:34:55 --> Router Class Initialized
INFO - 2016-08-25 09:34:55 --> Output Class Initialized
INFO - 2016-08-25 09:34:55 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:55 --> Input Class Initialized
INFO - 2016-08-25 09:34:55 --> Language Class Initialized
INFO - 2016-08-25 09:34:56 --> Loader Class Initialized
INFO - 2016-08-25 09:34:56 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:56 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:56 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:56 --> Email Class Initialized
INFO - 2016-08-25 09:34:56 --> Controller Class Initialized
INFO - 2016-08-25 09:34:56 --> Model Class Initialized
INFO - 2016-08-25 09:34:56 --> Config Class Initialized
INFO - 2016-08-25 09:34:56 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:56 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:56 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:56 --> URI Class Initialized
INFO - 2016-08-25 09:34:56 --> Router Class Initialized
INFO - 2016-08-25 09:34:56 --> Output Class Initialized
INFO - 2016-08-25 09:34:56 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:56 --> Input Class Initialized
INFO - 2016-08-25 09:34:56 --> Language Class Initialized
INFO - 2016-08-25 09:34:56 --> Loader Class Initialized
INFO - 2016-08-25 09:34:56 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:56 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:56 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:56 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:56 --> Email Class Initialized
INFO - 2016-08-25 09:34:56 --> Controller Class Initialized
INFO - 2016-08-25 09:34:56 --> Model Class Initialized
DEBUG - 2016-08-25 09:34:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:34:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-25 09:34:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:34:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-25 09:34:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:34:56 --> Final output sent to browser
DEBUG - 2016-08-25 09:34:56 --> Total execution time: 0.3579
INFO - 2016-08-25 09:34:58 --> Config Class Initialized
INFO - 2016-08-25 09:34:58 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:34:58 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:34:58 --> Utf8 Class Initialized
INFO - 2016-08-25 09:34:58 --> URI Class Initialized
INFO - 2016-08-25 09:34:58 --> Router Class Initialized
INFO - 2016-08-25 09:34:58 --> Output Class Initialized
INFO - 2016-08-25 09:34:58 --> Security Class Initialized
DEBUG - 2016-08-25 09:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:34:58 --> Input Class Initialized
INFO - 2016-08-25 09:34:58 --> Language Class Initialized
INFO - 2016-08-25 09:34:58 --> Loader Class Initialized
INFO - 2016-08-25 09:34:58 --> Helper loaded: url_helper
INFO - 2016-08-25 09:34:58 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:34:58 --> Helper loaded: html_helper
INFO - 2016-08-25 09:34:58 --> Helper loaded: form_helper
INFO - 2016-08-25 09:34:58 --> Helper loaded: file_helper
INFO - 2016-08-25 09:34:58 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:34:58 --> Database Driver Class Initialized
INFO - 2016-08-25 09:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:34:58 --> Form Validation Class Initialized
INFO - 2016-08-25 09:34:58 --> Email Class Initialized
INFO - 2016-08-25 09:34:58 --> Controller Class Initialized
INFO - 2016-08-25 09:34:58 --> Model Class Initialized
INFO - 2016-08-25 09:34:58 --> Final output sent to browser
DEBUG - 2016-08-25 09:34:58 --> Total execution time: 0.3373
INFO - 2016-08-25 09:35:02 --> Config Class Initialized
INFO - 2016-08-25 09:35:02 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:35:02 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:35:02 --> Utf8 Class Initialized
INFO - 2016-08-25 09:35:02 --> URI Class Initialized
INFO - 2016-08-25 09:35:02 --> Router Class Initialized
INFO - 2016-08-25 09:35:02 --> Output Class Initialized
INFO - 2016-08-25 09:35:02 --> Security Class Initialized
DEBUG - 2016-08-25 09:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:35:02 --> Input Class Initialized
INFO - 2016-08-25 09:35:02 --> Language Class Initialized
INFO - 2016-08-25 09:35:02 --> Loader Class Initialized
INFO - 2016-08-25 09:35:02 --> Helper loaded: url_helper
INFO - 2016-08-25 09:35:02 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:35:02 --> Helper loaded: html_helper
INFO - 2016-08-25 09:35:02 --> Helper loaded: form_helper
INFO - 2016-08-25 09:35:02 --> Helper loaded: file_helper
INFO - 2016-08-25 09:35:02 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:35:02 --> Database Driver Class Initialized
INFO - 2016-08-25 09:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:35:02 --> Form Validation Class Initialized
INFO - 2016-08-25 09:35:02 --> Email Class Initialized
INFO - 2016-08-25 09:35:02 --> Controller Class Initialized
INFO - 2016-08-25 09:35:02 --> Model Class Initialized
INFO - 2016-08-25 09:35:04 --> Config Class Initialized
INFO - 2016-08-25 09:35:04 --> Hooks Class Initialized
DEBUG - 2016-08-25 09:35:04 --> UTF-8 Support Enabled
INFO - 2016-08-25 09:35:04 --> Utf8 Class Initialized
INFO - 2016-08-25 09:35:04 --> URI Class Initialized
INFO - 2016-08-25 09:35:04 --> Router Class Initialized
INFO - 2016-08-25 09:35:04 --> Output Class Initialized
INFO - 2016-08-25 09:35:04 --> Security Class Initialized
DEBUG - 2016-08-25 09:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-25 09:35:04 --> Input Class Initialized
INFO - 2016-08-25 09:35:04 --> Language Class Initialized
INFO - 2016-08-25 09:35:04 --> Loader Class Initialized
INFO - 2016-08-25 09:35:04 --> Helper loaded: url_helper
INFO - 2016-08-25 09:35:04 --> Helper loaded: utils_helper
INFO - 2016-08-25 09:35:04 --> Helper loaded: html_helper
INFO - 2016-08-25 09:35:04 --> Helper loaded: form_helper
INFO - 2016-08-25 09:35:04 --> Helper loaded: file_helper
INFO - 2016-08-25 09:35:04 --> Helper loaded: myemail_helper
INFO - 2016-08-25 09:35:04 --> Database Driver Class Initialized
INFO - 2016-08-25 09:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-25 09:35:04 --> Form Validation Class Initialized
INFO - 2016-08-25 09:35:04 --> Email Class Initialized
INFO - 2016-08-25 09:35:04 --> Controller Class Initialized
DEBUG - 2016-08-25 09:35:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-25 09:35:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-25 09:35:04 --> Model Class Initialized
INFO - 2016-08-25 09:35:04 --> Model Class Initialized
INFO - 2016-08-25 09:35:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-25 09:35:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-25 09:35:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-25 09:35:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-25 09:35:04 --> Final output sent to browser
DEBUG - 2016-08-25 09:35:04 --> Total execution time: 0.4687
