<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-10 04:09:41 --> Config Class Initialized
INFO - 2016-08-10 04:09:41 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:41 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:41 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:41 --> URI Class Initialized
DEBUG - 2016-08-10 04:09:41 --> No URI present. Default controller set.
INFO - 2016-08-10 04:09:41 --> Router Class Initialized
INFO - 2016-08-10 04:09:41 --> Output Class Initialized
INFO - 2016-08-10 04:09:41 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:41 --> Input Class Initialized
INFO - 2016-08-10 04:09:41 --> Language Class Initialized
INFO - 2016-08-10 04:09:41 --> Loader Class Initialized
INFO - 2016-08-10 04:09:41 --> Helper loaded: url_helper
INFO - 2016-08-10 04:09:41 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:09:41 --> Helper loaded: html_helper
INFO - 2016-08-10 04:09:41 --> Helper loaded: form_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: file_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:09:42 --> Database Driver Class Initialized
INFO - 2016-08-10 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:09:42 --> Form Validation Class Initialized
INFO - 2016-08-10 04:09:42 --> Email Class Initialized
INFO - 2016-08-10 04:09:42 --> Controller Class Initialized
INFO - 2016-08-10 04:09:42 --> Config Class Initialized
INFO - 2016-08-10 04:09:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:42 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:42 --> URI Class Initialized
INFO - 2016-08-10 04:09:42 --> Router Class Initialized
INFO - 2016-08-10 04:09:42 --> Output Class Initialized
INFO - 2016-08-10 04:09:42 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:42 --> Input Class Initialized
INFO - 2016-08-10 04:09:42 --> Language Class Initialized
INFO - 2016-08-10 04:09:42 --> Loader Class Initialized
INFO - 2016-08-10 04:09:42 --> Helper loaded: url_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: html_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: form_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: file_helper
INFO - 2016-08-10 04:09:42 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:09:42 --> Database Driver Class Initialized
INFO - 2016-08-10 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:09:42 --> Form Validation Class Initialized
INFO - 2016-08-10 04:09:42 --> Email Class Initialized
INFO - 2016-08-10 04:09:42 --> Controller Class Initialized
INFO - 2016-08-10 04:09:42 --> Model Class Initialized
DEBUG - 2016-08-10 04:09:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 04:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 04:09:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:09:42 --> Final output sent to browser
DEBUG - 2016-08-10 04:09:42 --> Total execution time: 0.3833
INFO - 2016-08-10 04:09:43 --> Config Class Initialized
INFO - 2016-08-10 04:09:43 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:43 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:43 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:43 --> URI Class Initialized
INFO - 2016-08-10 04:09:43 --> Router Class Initialized
INFO - 2016-08-10 04:09:43 --> Output Class Initialized
INFO - 2016-08-10 04:09:43 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:43 --> Input Class Initialized
INFO - 2016-08-10 04:09:43 --> Language Class Initialized
ERROR - 2016-08-10 04:09:43 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 04:09:43 --> Config Class Initialized
INFO - 2016-08-10 04:09:43 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:43 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:43 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:43 --> URI Class Initialized
INFO - 2016-08-10 04:09:43 --> Router Class Initialized
INFO - 2016-08-10 04:09:43 --> Output Class Initialized
INFO - 2016-08-10 04:09:43 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:43 --> Input Class Initialized
INFO - 2016-08-10 04:09:43 --> Language Class Initialized
ERROR - 2016-08-10 04:09:43 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 04:09:51 --> Config Class Initialized
INFO - 2016-08-10 04:09:51 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:51 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:51 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:51 --> URI Class Initialized
INFO - 2016-08-10 04:09:51 --> Router Class Initialized
INFO - 2016-08-10 04:09:51 --> Output Class Initialized
INFO - 2016-08-10 04:09:51 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:52 --> Input Class Initialized
INFO - 2016-08-10 04:09:52 --> Language Class Initialized
INFO - 2016-08-10 04:09:52 --> Loader Class Initialized
INFO - 2016-08-10 04:09:52 --> Helper loaded: url_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: html_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: form_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: file_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:09:52 --> Database Driver Class Initialized
INFO - 2016-08-10 04:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:09:52 --> Form Validation Class Initialized
INFO - 2016-08-10 04:09:52 --> Email Class Initialized
INFO - 2016-08-10 04:09:52 --> Controller Class Initialized
INFO - 2016-08-10 04:09:52 --> Model Class Initialized
DEBUG - 2016-08-10 04:09:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:09:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 04:09:52 --> Config Class Initialized
INFO - 2016-08-10 04:09:52 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:52 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:52 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:52 --> URI Class Initialized
DEBUG - 2016-08-10 04:09:52 --> No URI present. Default controller set.
INFO - 2016-08-10 04:09:52 --> Router Class Initialized
INFO - 2016-08-10 04:09:52 --> Output Class Initialized
INFO - 2016-08-10 04:09:52 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:52 --> Input Class Initialized
INFO - 2016-08-10 04:09:52 --> Language Class Initialized
INFO - 2016-08-10 04:09:52 --> Loader Class Initialized
INFO - 2016-08-10 04:09:52 --> Helper loaded: url_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: html_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: form_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: file_helper
INFO - 2016-08-10 04:09:52 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:09:52 --> Database Driver Class Initialized
INFO - 2016-08-10 04:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:09:52 --> Form Validation Class Initialized
INFO - 2016-08-10 04:09:52 --> Email Class Initialized
INFO - 2016-08-10 04:09:52 --> Controller Class Initialized
INFO - 2016-08-10 04:09:52 --> Model Class Initialized
INFO - 2016-08-10 04:09:52 --> Model Class Initialized
INFO - 2016-08-10 04:09:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:09:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:09:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-10 04:09:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:09:52 --> Final output sent to browser
DEBUG - 2016-08-10 04:09:52 --> Total execution time: 0.3014
INFO - 2016-08-10 04:09:56 --> Config Class Initialized
INFO - 2016-08-10 04:09:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:09:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:09:56 --> Utf8 Class Initialized
INFO - 2016-08-10 04:09:56 --> URI Class Initialized
INFO - 2016-08-10 04:09:56 --> Router Class Initialized
INFO - 2016-08-10 04:09:56 --> Output Class Initialized
INFO - 2016-08-10 04:09:56 --> Security Class Initialized
DEBUG - 2016-08-10 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:09:56 --> Input Class Initialized
INFO - 2016-08-10 04:09:56 --> Language Class Initialized
INFO - 2016-08-10 04:09:56 --> Loader Class Initialized
INFO - 2016-08-10 04:09:56 --> Helper loaded: url_helper
INFO - 2016-08-10 04:09:56 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:09:56 --> Helper loaded: html_helper
INFO - 2016-08-10 04:09:56 --> Helper loaded: form_helper
INFO - 2016-08-10 04:09:56 --> Helper loaded: file_helper
INFO - 2016-08-10 04:09:56 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:09:56 --> Database Driver Class Initialized
INFO - 2016-08-10 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:09:56 --> Form Validation Class Initialized
INFO - 2016-08-10 04:09:56 --> Email Class Initialized
INFO - 2016-08-10 04:09:56 --> Controller Class Initialized
DEBUG - 2016-08-10 04:09:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 04:09:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:09:56 --> Model Class Initialized
INFO - 2016-08-10 04:09:57 --> Model Class Initialized
INFO - 2016-08-10 04:09:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:09:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:09:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 04:09:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:09:57 --> Final output sent to browser
DEBUG - 2016-08-10 04:09:57 --> Total execution time: 0.6060
INFO - 2016-08-10 04:12:38 --> Config Class Initialized
INFO - 2016-08-10 04:12:38 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:12:38 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:12:38 --> Utf8 Class Initialized
INFO - 2016-08-10 04:12:38 --> URI Class Initialized
INFO - 2016-08-10 04:12:38 --> Router Class Initialized
INFO - 2016-08-10 04:12:38 --> Output Class Initialized
INFO - 2016-08-10 04:12:38 --> Security Class Initialized
DEBUG - 2016-08-10 04:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:12:38 --> Input Class Initialized
INFO - 2016-08-10 04:12:38 --> Language Class Initialized
INFO - 2016-08-10 04:12:38 --> Loader Class Initialized
INFO - 2016-08-10 04:12:38 --> Helper loaded: url_helper
INFO - 2016-08-10 04:12:38 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:12:38 --> Helper loaded: html_helper
INFO - 2016-08-10 04:12:38 --> Helper loaded: form_helper
INFO - 2016-08-10 04:12:38 --> Helper loaded: file_helper
INFO - 2016-08-10 04:12:38 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:12:38 --> Database Driver Class Initialized
INFO - 2016-08-10 04:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:12:38 --> Form Validation Class Initialized
INFO - 2016-08-10 04:12:38 --> Email Class Initialized
INFO - 2016-08-10 04:12:38 --> Controller Class Initialized
DEBUG - 2016-08-10 04:12:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 04:12:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:12:38 --> Model Class Initialized
INFO - 2016-08-10 04:12:38 --> Model Class Initialized
INFO - 2016-08-10 04:12:38 --> Model Class Initialized
INFO - 2016-08-10 04:12:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:12:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:12:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/all_books.php
INFO - 2016-08-10 04:12:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:12:38 --> Final output sent to browser
DEBUG - 2016-08-10 04:12:38 --> Total execution time: 0.3741
INFO - 2016-08-10 04:12:40 --> Config Class Initialized
INFO - 2016-08-10 04:12:40 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:12:40 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:12:40 --> Utf8 Class Initialized
INFO - 2016-08-10 04:12:40 --> URI Class Initialized
INFO - 2016-08-10 04:12:40 --> Router Class Initialized
INFO - 2016-08-10 04:12:40 --> Output Class Initialized
INFO - 2016-08-10 04:12:40 --> Security Class Initialized
DEBUG - 2016-08-10 04:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:12:40 --> Input Class Initialized
INFO - 2016-08-10 04:12:40 --> Language Class Initialized
INFO - 2016-08-10 04:12:40 --> Loader Class Initialized
INFO - 2016-08-10 04:12:40 --> Helper loaded: url_helper
INFO - 2016-08-10 04:12:40 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:12:40 --> Helper loaded: html_helper
INFO - 2016-08-10 04:12:40 --> Helper loaded: form_helper
INFO - 2016-08-10 04:12:40 --> Helper loaded: file_helper
INFO - 2016-08-10 04:12:40 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:12:40 --> Database Driver Class Initialized
INFO - 2016-08-10 04:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:12:40 --> Form Validation Class Initialized
INFO - 2016-08-10 04:12:40 --> Email Class Initialized
INFO - 2016-08-10 04:12:40 --> Controller Class Initialized
DEBUG - 2016-08-10 04:12:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 04:12:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:12:40 --> Model Class Initialized
INFO - 2016-08-10 04:12:40 --> Model Class Initialized
INFO - 2016-08-10 04:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 04:12:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:12:40 --> Final output sent to browser
DEBUG - 2016-08-10 04:12:40 --> Total execution time: 0.2757
INFO - 2016-08-10 04:16:22 --> Config Class Initialized
INFO - 2016-08-10 04:16:22 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:22 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:22 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:22 --> URI Class Initialized
DEBUG - 2016-08-10 04:16:22 --> No URI present. Default controller set.
INFO - 2016-08-10 04:16:22 --> Router Class Initialized
INFO - 2016-08-10 04:16:22 --> Output Class Initialized
INFO - 2016-08-10 04:16:22 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:22 --> Input Class Initialized
INFO - 2016-08-10 04:16:22 --> Language Class Initialized
INFO - 2016-08-10 04:16:22 --> Loader Class Initialized
INFO - 2016-08-10 04:16:22 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:22 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:22 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:22 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:22 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:22 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:22 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:22 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:22 --> Email Class Initialized
INFO - 2016-08-10 04:16:22 --> Controller Class Initialized
INFO - 2016-08-10 04:16:22 --> Model Class Initialized
INFO - 2016-08-10 04:16:22 --> Model Class Initialized
INFO - 2016-08-10 04:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-10 04:16:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:22 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:22 --> Total execution time: 0.2297
INFO - 2016-08-10 04:16:24 --> Config Class Initialized
INFO - 2016-08-10 04:16:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:24 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:24 --> URI Class Initialized
INFO - 2016-08-10 04:16:24 --> Router Class Initialized
INFO - 2016-08-10 04:16:24 --> Output Class Initialized
INFO - 2016-08-10 04:16:24 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:24 --> Input Class Initialized
INFO - 2016-08-10 04:16:24 --> Language Class Initialized
INFO - 2016-08-10 04:16:24 --> Loader Class Initialized
INFO - 2016-08-10 04:16:24 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:24 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:24 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:24 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:24 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:24 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:24 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:24 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:24 --> Email Class Initialized
INFO - 2016-08-10 04:16:24 --> Controller Class Initialized
DEBUG - 2016-08-10 04:16:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:24 --> Model Class Initialized
INFO - 2016-08-10 04:16:24 --> Model Class Initialized
INFO - 2016-08-10 04:16:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-10 04:16:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:24 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:24 --> Total execution time: 0.4093
INFO - 2016-08-10 04:16:32 --> Config Class Initialized
INFO - 2016-08-10 04:16:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:32 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:32 --> URI Class Initialized
INFO - 2016-08-10 04:16:32 --> Router Class Initialized
INFO - 2016-08-10 04:16:32 --> Output Class Initialized
INFO - 2016-08-10 04:16:32 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:32 --> Input Class Initialized
INFO - 2016-08-10 04:16:32 --> Language Class Initialized
INFO - 2016-08-10 04:16:32 --> Loader Class Initialized
INFO - 2016-08-10 04:16:32 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:32 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:32 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:32 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:32 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:32 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:32 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:32 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:32 --> Email Class Initialized
INFO - 2016-08-10 04:16:32 --> Controller Class Initialized
DEBUG - 2016-08-10 04:16:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:32 --> Model Class Initialized
INFO - 2016-08-10 04:16:32 --> Model Class Initialized
INFO - 2016-08-10 04:16:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 04:16:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:32 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:32 --> Total execution time: 0.3182
INFO - 2016-08-10 04:16:38 --> Config Class Initialized
INFO - 2016-08-10 04:16:38 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:38 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:38 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:38 --> URI Class Initialized
INFO - 2016-08-10 04:16:38 --> Router Class Initialized
INFO - 2016-08-10 04:16:38 --> Output Class Initialized
INFO - 2016-08-10 04:16:38 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:38 --> Input Class Initialized
INFO - 2016-08-10 04:16:38 --> Language Class Initialized
INFO - 2016-08-10 04:16:38 --> Loader Class Initialized
INFO - 2016-08-10 04:16:38 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:38 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:38 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:38 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:38 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:38 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:38 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:38 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:38 --> Email Class Initialized
INFO - 2016-08-10 04:16:38 --> Controller Class Initialized
INFO - 2016-08-10 04:16:38 --> Model Class Initialized
INFO - 2016-08-10 04:16:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-10 04:16:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:38 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:38 --> Total execution time: 0.2935
INFO - 2016-08-10 04:16:39 --> Config Class Initialized
INFO - 2016-08-10 04:16:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:39 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:39 --> URI Class Initialized
INFO - 2016-08-10 04:16:39 --> Router Class Initialized
INFO - 2016-08-10 04:16:39 --> Output Class Initialized
INFO - 2016-08-10 04:16:39 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:39 --> Input Class Initialized
INFO - 2016-08-10 04:16:39 --> Language Class Initialized
INFO - 2016-08-10 04:16:39 --> Loader Class Initialized
INFO - 2016-08-10 04:16:39 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:39 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:39 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:39 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:39 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:39 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:39 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:39 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:39 --> Email Class Initialized
INFO - 2016-08-10 04:16:39 --> Controller Class Initialized
INFO - 2016-08-10 04:16:39 --> Model Class Initialized
INFO - 2016-08-10 04:16:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-10 04:16:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:39 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:39 --> Total execution time: 0.2708
INFO - 2016-08-10 04:16:45 --> Config Class Initialized
INFO - 2016-08-10 04:16:45 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:45 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:45 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:45 --> URI Class Initialized
INFO - 2016-08-10 04:16:45 --> Router Class Initialized
INFO - 2016-08-10 04:16:45 --> Output Class Initialized
INFO - 2016-08-10 04:16:45 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:45 --> Input Class Initialized
INFO - 2016-08-10 04:16:45 --> Language Class Initialized
INFO - 2016-08-10 04:16:45 --> Loader Class Initialized
INFO - 2016-08-10 04:16:45 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:45 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:45 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:45 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:45 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:45 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:45 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:45 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:45 --> Email Class Initialized
INFO - 2016-08-10 04:16:45 --> Controller Class Initialized
DEBUG - 2016-08-10 04:16:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:45 --> Model Class Initialized
INFO - 2016-08-10 04:16:45 --> Model Class Initialized
INFO - 2016-08-10 04:16:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 04:16:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:45 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:45 --> Total execution time: 0.2335
INFO - 2016-08-10 04:16:47 --> Config Class Initialized
INFO - 2016-08-10 04:16:47 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:47 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:47 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:47 --> URI Class Initialized
INFO - 2016-08-10 04:16:47 --> Router Class Initialized
INFO - 2016-08-10 04:16:47 --> Output Class Initialized
INFO - 2016-08-10 04:16:47 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:47 --> Input Class Initialized
INFO - 2016-08-10 04:16:47 --> Language Class Initialized
INFO - 2016-08-10 04:16:47 --> Loader Class Initialized
INFO - 2016-08-10 04:16:47 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:47 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:47 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:47 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:47 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:47 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:47 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:47 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:47 --> Email Class Initialized
INFO - 2016-08-10 04:16:47 --> Controller Class Initialized
DEBUG - 2016-08-10 04:16:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:47 --> Model Class Initialized
INFO - 2016-08-10 04:16:47 --> Model Class Initialized
INFO - 2016-08-10 04:16:47 --> Model Class Initialized
INFO - 2016-08-10 04:16:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:16:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-10 04:16:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:47 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:47 --> Total execution time: 0.2908
INFO - 2016-08-10 04:16:53 --> Config Class Initialized
INFO - 2016-08-10 04:16:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:53 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:53 --> URI Class Initialized
INFO - 2016-08-10 04:16:53 --> Router Class Initialized
INFO - 2016-08-10 04:16:53 --> Output Class Initialized
INFO - 2016-08-10 04:16:53 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:53 --> Input Class Initialized
INFO - 2016-08-10 04:16:53 --> Language Class Initialized
INFO - 2016-08-10 04:16:53 --> Loader Class Initialized
INFO - 2016-08-10 04:16:53 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:53 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:53 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:53 --> Email Class Initialized
INFO - 2016-08-10 04:16:53 --> Controller Class Initialized
INFO - 2016-08-10 04:16:53 --> Model Class Initialized
INFO - 2016-08-10 04:16:53 --> Config Class Initialized
INFO - 2016-08-10 04:16:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:53 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:53 --> URI Class Initialized
INFO - 2016-08-10 04:16:53 --> Router Class Initialized
INFO - 2016-08-10 04:16:53 --> Output Class Initialized
INFO - 2016-08-10 04:16:53 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:53 --> Input Class Initialized
INFO - 2016-08-10 04:16:53 --> Language Class Initialized
INFO - 2016-08-10 04:16:53 --> Loader Class Initialized
INFO - 2016-08-10 04:16:53 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:53 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:53 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:53 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:53 --> Email Class Initialized
INFO - 2016-08-10 04:16:53 --> Controller Class Initialized
INFO - 2016-08-10 04:16:53 --> Model Class Initialized
DEBUG - 2016-08-10 04:16:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 04:16:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 04:16:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:53 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:53 --> Total execution time: 0.2260
INFO - 2016-08-10 04:16:59 --> Config Class Initialized
INFO - 2016-08-10 04:16:59 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:16:59 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:16:59 --> Utf8 Class Initialized
INFO - 2016-08-10 04:16:59 --> URI Class Initialized
INFO - 2016-08-10 04:16:59 --> Router Class Initialized
INFO - 2016-08-10 04:16:59 --> Output Class Initialized
INFO - 2016-08-10 04:16:59 --> Security Class Initialized
DEBUG - 2016-08-10 04:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:16:59 --> Input Class Initialized
INFO - 2016-08-10 04:16:59 --> Language Class Initialized
INFO - 2016-08-10 04:16:59 --> Loader Class Initialized
INFO - 2016-08-10 04:16:59 --> Helper loaded: url_helper
INFO - 2016-08-10 04:16:59 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:16:59 --> Helper loaded: html_helper
INFO - 2016-08-10 04:16:59 --> Helper loaded: form_helper
INFO - 2016-08-10 04:16:59 --> Helper loaded: file_helper
INFO - 2016-08-10 04:16:59 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:16:59 --> Database Driver Class Initialized
INFO - 2016-08-10 04:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:16:59 --> Form Validation Class Initialized
INFO - 2016-08-10 04:16:59 --> Email Class Initialized
INFO - 2016-08-10 04:16:59 --> Controller Class Initialized
INFO - 2016-08-10 04:16:59 --> Model Class Initialized
DEBUG - 2016-08-10 04:16:59 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:16:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-10 04:16:59 --> {controllers/session/login} Invalid login id or password for user=bpitet
INFO - 2016-08-10 04:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 04:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 04:16:59 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:16:59 --> Final output sent to browser
DEBUG - 2016-08-10 04:16:59 --> Total execution time: 0.2613
INFO - 2016-08-10 04:17:03 --> Config Class Initialized
INFO - 2016-08-10 04:17:03 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:03 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:03 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:03 --> URI Class Initialized
INFO - 2016-08-10 04:17:03 --> Router Class Initialized
INFO - 2016-08-10 04:17:03 --> Output Class Initialized
INFO - 2016-08-10 04:17:03 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:03 --> Input Class Initialized
INFO - 2016-08-10 04:17:03 --> Language Class Initialized
INFO - 2016-08-10 04:17:03 --> Loader Class Initialized
INFO - 2016-08-10 04:17:03 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:03 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:03 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:03 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:03 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:03 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:03 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:03 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:03 --> Email Class Initialized
INFO - 2016-08-10 04:17:03 --> Controller Class Initialized
INFO - 2016-08-10 04:17:03 --> Model Class Initialized
DEBUG - 2016-08-10 04:17:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 04:17:03 --> Config Class Initialized
INFO - 2016-08-10 04:17:03 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:03 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:03 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:03 --> URI Class Initialized
INFO - 2016-08-10 04:17:03 --> Router Class Initialized
INFO - 2016-08-10 04:17:03 --> Output Class Initialized
INFO - 2016-08-10 04:17:03 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:03 --> Input Class Initialized
INFO - 2016-08-10 04:17:04 --> Language Class Initialized
INFO - 2016-08-10 04:17:04 --> Loader Class Initialized
INFO - 2016-08-10 04:17:04 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:04 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:04 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:04 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:04 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:04 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:04 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:04 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:04 --> Email Class Initialized
INFO - 2016-08-10 04:17:04 --> Controller Class Initialized
DEBUG - 2016-08-10 04:17:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 04:17:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:04 --> Model Class Initialized
INFO - 2016-08-10 04:17:04 --> Model Class Initialized
INFO - 2016-08-10 04:17:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 04:17:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:04 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:04 --> Total execution time: 0.3101
INFO - 2016-08-10 04:17:09 --> Config Class Initialized
INFO - 2016-08-10 04:17:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:09 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:09 --> URI Class Initialized
INFO - 2016-08-10 04:17:09 --> Router Class Initialized
INFO - 2016-08-10 04:17:09 --> Output Class Initialized
INFO - 2016-08-10 04:17:09 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:09 --> Input Class Initialized
INFO - 2016-08-10 04:17:09 --> Language Class Initialized
INFO - 2016-08-10 04:17:09 --> Loader Class Initialized
INFO - 2016-08-10 04:17:09 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:09 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:09 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:09 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:09 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:09 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:09 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:09 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:09 --> Email Class Initialized
INFO - 2016-08-10 04:17:09 --> Controller Class Initialized
INFO - 2016-08-10 04:17:09 --> Model Class Initialized
INFO - 2016-08-10 04:17:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-10 04:17:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:09 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:09 --> Total execution time: 0.2377
INFO - 2016-08-10 04:17:21 --> Config Class Initialized
INFO - 2016-08-10 04:17:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:21 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:21 --> URI Class Initialized
INFO - 2016-08-10 04:17:21 --> Router Class Initialized
INFO - 2016-08-10 04:17:21 --> Output Class Initialized
INFO - 2016-08-10 04:17:21 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:21 --> Input Class Initialized
INFO - 2016-08-10 04:17:21 --> Language Class Initialized
INFO - 2016-08-10 04:17:21 --> Loader Class Initialized
INFO - 2016-08-10 04:17:21 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:21 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:21 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:21 --> Email Class Initialized
INFO - 2016-08-10 04:17:21 --> Controller Class Initialized
INFO - 2016-08-10 04:17:21 --> Model Class Initialized
INFO - 2016-08-10 04:17:21 --> Config Class Initialized
INFO - 2016-08-10 04:17:21 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:21 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:21 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:21 --> URI Class Initialized
INFO - 2016-08-10 04:17:21 --> Router Class Initialized
INFO - 2016-08-10 04:17:21 --> Output Class Initialized
INFO - 2016-08-10 04:17:21 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:21 --> Input Class Initialized
INFO - 2016-08-10 04:17:21 --> Language Class Initialized
INFO - 2016-08-10 04:17:21 --> Loader Class Initialized
INFO - 2016-08-10 04:17:21 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:21 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:21 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:21 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:21 --> Email Class Initialized
INFO - 2016-08-10 04:17:21 --> Controller Class Initialized
INFO - 2016-08-10 04:17:21 --> Model Class Initialized
DEBUG - 2016-08-10 04:17:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 04:17:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 04:17:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:21 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:21 --> Total execution time: 0.2401
INFO - 2016-08-10 04:17:28 --> Config Class Initialized
INFO - 2016-08-10 04:17:28 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:28 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:28 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:28 --> URI Class Initialized
INFO - 2016-08-10 04:17:28 --> Router Class Initialized
INFO - 2016-08-10 04:17:28 --> Output Class Initialized
INFO - 2016-08-10 04:17:28 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:28 --> Input Class Initialized
INFO - 2016-08-10 04:17:28 --> Language Class Initialized
INFO - 2016-08-10 04:17:28 --> Loader Class Initialized
INFO - 2016-08-10 04:17:28 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:28 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:28 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:28 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:28 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:28 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:28 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:28 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:28 --> Email Class Initialized
INFO - 2016-08-10 04:17:28 --> Controller Class Initialized
INFO - 2016-08-10 04:17:28 --> Model Class Initialized
DEBUG - 2016-08-10 04:17:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2016-08-10 04:17:28 --> {controllers/session/login} Invalid login id or password for user=sophea.ou
INFO - 2016-08-10 04:17:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 04:17:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 04:17:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:28 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:28 --> Total execution time: 0.2874
INFO - 2016-08-10 04:17:32 --> Config Class Initialized
INFO - 2016-08-10 04:17:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:32 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:32 --> URI Class Initialized
INFO - 2016-08-10 04:17:32 --> Router Class Initialized
INFO - 2016-08-10 04:17:32 --> Output Class Initialized
INFO - 2016-08-10 04:17:32 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:32 --> Input Class Initialized
INFO - 2016-08-10 04:17:32 --> Language Class Initialized
INFO - 2016-08-10 04:17:32 --> Loader Class Initialized
INFO - 2016-08-10 04:17:32 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:32 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:32 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:32 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:32 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:32 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:32 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:32 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:32 --> Email Class Initialized
INFO - 2016-08-10 04:17:32 --> Controller Class Initialized
INFO - 2016-08-10 04:17:32 --> Model Class Initialized
DEBUG - 2016-08-10 04:17:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 04:17:32 --> Config Class Initialized
INFO - 2016-08-10 04:17:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:33 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:33 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:33 --> URI Class Initialized
INFO - 2016-08-10 04:17:33 --> Router Class Initialized
INFO - 2016-08-10 04:17:33 --> Output Class Initialized
INFO - 2016-08-10 04:17:33 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:33 --> Input Class Initialized
INFO - 2016-08-10 04:17:33 --> Language Class Initialized
INFO - 2016-08-10 04:17:33 --> Loader Class Initialized
INFO - 2016-08-10 04:17:33 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:33 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:33 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:33 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:33 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:33 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:33 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:33 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:33 --> Email Class Initialized
INFO - 2016-08-10 04:17:33 --> Controller Class Initialized
INFO - 2016-08-10 04:17:33 --> Model Class Initialized
INFO - 2016-08-10 04:17:33 --> Model Class Initialized
INFO - 2016-08-10 04:17:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-10 04:17:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:33 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:33 --> Total execution time: 0.2837
INFO - 2016-08-10 04:17:37 --> Config Class Initialized
INFO - 2016-08-10 04:17:37 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:37 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:37 --> URI Class Initialized
INFO - 2016-08-10 04:17:37 --> Router Class Initialized
INFO - 2016-08-10 04:17:37 --> Output Class Initialized
INFO - 2016-08-10 04:17:37 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:37 --> Input Class Initialized
INFO - 2016-08-10 04:17:37 --> Language Class Initialized
INFO - 2016-08-10 04:17:37 --> Loader Class Initialized
INFO - 2016-08-10 04:17:37 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:37 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:37 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:37 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:37 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:38 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:38 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:38 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:38 --> Email Class Initialized
INFO - 2016-08-10 04:17:38 --> Controller Class Initialized
INFO - 2016-08-10 04:17:38 --> Model Class Initialized
INFO - 2016-08-10 04:17:38 --> Model Class Initialized
INFO - 2016-08-10 04:17:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-10 04:17:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:38 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:38 --> Total execution time: 0.3684
INFO - 2016-08-10 04:17:40 --> Config Class Initialized
INFO - 2016-08-10 04:17:40 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:40 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:40 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:40 --> URI Class Initialized
INFO - 2016-08-10 04:17:40 --> Router Class Initialized
INFO - 2016-08-10 04:17:40 --> Output Class Initialized
INFO - 2016-08-10 04:17:40 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:40 --> Input Class Initialized
INFO - 2016-08-10 04:17:40 --> Language Class Initialized
INFO - 2016-08-10 04:17:40 --> Loader Class Initialized
INFO - 2016-08-10 04:17:40 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:40 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:40 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:40 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:40 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:40 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:40 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:40 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:40 --> Email Class Initialized
INFO - 2016-08-10 04:17:40 --> Controller Class Initialized
INFO - 2016-08-10 04:17:40 --> Model Class Initialized
INFO - 2016-08-10 04:17:40 --> Model Class Initialized
INFO - 2016-08-10 04:17:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-10 04:17:40 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:40 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:40 --> Total execution time: 0.2624
INFO - 2016-08-10 04:17:42 --> Config Class Initialized
INFO - 2016-08-10 04:17:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:17:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:17:42 --> Utf8 Class Initialized
INFO - 2016-08-10 04:17:42 --> URI Class Initialized
INFO - 2016-08-10 04:17:42 --> Router Class Initialized
INFO - 2016-08-10 04:17:42 --> Output Class Initialized
INFO - 2016-08-10 04:17:42 --> Security Class Initialized
DEBUG - 2016-08-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:17:42 --> Input Class Initialized
INFO - 2016-08-10 04:17:42 --> Language Class Initialized
INFO - 2016-08-10 04:17:42 --> Loader Class Initialized
INFO - 2016-08-10 04:17:42 --> Helper loaded: url_helper
INFO - 2016-08-10 04:17:42 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:17:42 --> Helper loaded: html_helper
INFO - 2016-08-10 04:17:42 --> Helper loaded: form_helper
INFO - 2016-08-10 04:17:42 --> Helper loaded: file_helper
INFO - 2016-08-10 04:17:42 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:17:42 --> Database Driver Class Initialized
INFO - 2016-08-10 04:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:17:42 --> Form Validation Class Initialized
INFO - 2016-08-10 04:17:42 --> Email Class Initialized
INFO - 2016-08-10 04:17:42 --> Controller Class Initialized
DEBUG - 2016-08-10 04:17:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:17:42 --> Model Class Initialized
INFO - 2016-08-10 04:17:42 --> Model Class Initialized
INFO - 2016-08-10 04:17:42 --> Model Class Initialized
INFO - 2016-08-10 04:17:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:17:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:17:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-10 04:17:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:17:42 --> Final output sent to browser
DEBUG - 2016-08-10 04:17:42 --> Total execution time: 0.2694
INFO - 2016-08-10 04:39:02 --> Config Class Initialized
INFO - 2016-08-10 04:39:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:39:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:39:02 --> Utf8 Class Initialized
INFO - 2016-08-10 04:39:02 --> URI Class Initialized
INFO - 2016-08-10 04:39:02 --> Router Class Initialized
INFO - 2016-08-10 04:39:03 --> Output Class Initialized
INFO - 2016-08-10 04:39:03 --> Security Class Initialized
DEBUG - 2016-08-10 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:39:03 --> Input Class Initialized
INFO - 2016-08-10 04:39:03 --> Language Class Initialized
INFO - 2016-08-10 04:39:03 --> Loader Class Initialized
INFO - 2016-08-10 04:39:03 --> Helper loaded: url_helper
INFO - 2016-08-10 04:39:03 --> Helper loaded: utils_helper
INFO - 2016-08-10 04:39:03 --> Helper loaded: html_helper
INFO - 2016-08-10 04:39:03 --> Helper loaded: form_helper
INFO - 2016-08-10 04:39:03 --> Helper loaded: file_helper
INFO - 2016-08-10 04:39:03 --> Helper loaded: myemail_helper
INFO - 2016-08-10 04:39:03 --> Database Driver Class Initialized
INFO - 2016-08-10 04:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 04:39:04 --> Form Validation Class Initialized
INFO - 2016-08-10 04:39:04 --> Email Class Initialized
INFO - 2016-08-10 04:39:04 --> Controller Class Initialized
DEBUG - 2016-08-10 04:39:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 04:39:04 --> Model Class Initialized
INFO - 2016-08-10 04:39:04 --> Model Class Initialized
INFO - 2016-08-10 04:39:04 --> Model Class Initialized
INFO - 2016-08-10 04:39:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 04:39:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 04:39:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/add.php
INFO - 2016-08-10 04:39:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 04:39:05 --> Final output sent to browser
DEBUG - 2016-08-10 04:39:05 --> Total execution time: 3.1901
INFO - 2016-08-10 04:39:07 --> Config Class Initialized
INFO - 2016-08-10 04:39:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:39:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:39:07 --> Utf8 Class Initialized
INFO - 2016-08-10 04:39:07 --> URI Class Initialized
INFO - 2016-08-10 04:39:07 --> Router Class Initialized
INFO - 2016-08-10 04:39:07 --> Output Class Initialized
INFO - 2016-08-10 04:39:07 --> Security Class Initialized
DEBUG - 2016-08-10 04:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:39:07 --> Input Class Initialized
INFO - 2016-08-10 04:39:07 --> Language Class Initialized
ERROR - 2016-08-10 04:39:07 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 04:39:07 --> Config Class Initialized
INFO - 2016-08-10 04:39:07 --> Hooks Class Initialized
DEBUG - 2016-08-10 04:39:07 --> UTF-8 Support Enabled
INFO - 2016-08-10 04:39:07 --> Utf8 Class Initialized
INFO - 2016-08-10 04:39:07 --> URI Class Initialized
INFO - 2016-08-10 04:39:07 --> Router Class Initialized
INFO - 2016-08-10 04:39:07 --> Output Class Initialized
INFO - 2016-08-10 04:39:07 --> Security Class Initialized
DEBUG - 2016-08-10 04:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 04:39:07 --> Input Class Initialized
INFO - 2016-08-10 04:39:07 --> Language Class Initialized
ERROR - 2016-08-10 04:39:07 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 18:12:27 --> Config Class Initialized
INFO - 2016-08-10 18:12:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:27 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:27 --> URI Class Initialized
DEBUG - 2016-08-10 18:12:27 --> No URI present. Default controller set.
INFO - 2016-08-10 18:12:27 --> Router Class Initialized
INFO - 2016-08-10 18:12:28 --> Output Class Initialized
INFO - 2016-08-10 18:12:28 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:28 --> Input Class Initialized
INFO - 2016-08-10 18:12:28 --> Language Class Initialized
INFO - 2016-08-10 18:12:28 --> Loader Class Initialized
INFO - 2016-08-10 18:12:28 --> Helper loaded: url_helper
INFO - 2016-08-10 18:12:28 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:12:28 --> Helper loaded: html_helper
INFO - 2016-08-10 18:12:28 --> Helper loaded: form_helper
INFO - 2016-08-10 18:12:28 --> Helper loaded: file_helper
INFO - 2016-08-10 18:12:28 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:12:28 --> Database Driver Class Initialized
INFO - 2016-08-10 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:12:29 --> Form Validation Class Initialized
INFO - 2016-08-10 18:12:29 --> Email Class Initialized
INFO - 2016-08-10 18:12:29 --> Controller Class Initialized
INFO - 2016-08-10 18:12:29 --> Config Class Initialized
INFO - 2016-08-10 18:12:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:29 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:29 --> URI Class Initialized
INFO - 2016-08-10 18:12:29 --> Router Class Initialized
INFO - 2016-08-10 18:12:29 --> Output Class Initialized
INFO - 2016-08-10 18:12:29 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:29 --> Input Class Initialized
INFO - 2016-08-10 18:12:29 --> Language Class Initialized
INFO - 2016-08-10 18:12:29 --> Loader Class Initialized
INFO - 2016-08-10 18:12:29 --> Helper loaded: url_helper
INFO - 2016-08-10 18:12:29 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:12:29 --> Helper loaded: html_helper
INFO - 2016-08-10 18:12:29 --> Helper loaded: form_helper
INFO - 2016-08-10 18:12:29 --> Helper loaded: file_helper
INFO - 2016-08-10 18:12:29 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:12:29 --> Database Driver Class Initialized
INFO - 2016-08-10 18:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:12:29 --> Form Validation Class Initialized
INFO - 2016-08-10 18:12:29 --> Email Class Initialized
INFO - 2016-08-10 18:12:29 --> Controller Class Initialized
INFO - 2016-08-10 18:12:29 --> Model Class Initialized
DEBUG - 2016-08-10 18:12:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:12:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 18:12:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:12:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 18:12:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:12:29 --> Final output sent to browser
DEBUG - 2016-08-10 18:12:29 --> Total execution time: 0.6915
INFO - 2016-08-10 18:12:31 --> Config Class Initialized
INFO - 2016-08-10 18:12:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:31 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:31 --> URI Class Initialized
INFO - 2016-08-10 18:12:31 --> Router Class Initialized
INFO - 2016-08-10 18:12:31 --> Output Class Initialized
INFO - 2016-08-10 18:12:31 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:31 --> Input Class Initialized
INFO - 2016-08-10 18:12:31 --> Language Class Initialized
ERROR - 2016-08-10 18:12:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 18:12:31 --> Config Class Initialized
INFO - 2016-08-10 18:12:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:31 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:31 --> URI Class Initialized
INFO - 2016-08-10 18:12:31 --> Router Class Initialized
INFO - 2016-08-10 18:12:31 --> Output Class Initialized
INFO - 2016-08-10 18:12:31 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:31 --> Input Class Initialized
INFO - 2016-08-10 18:12:31 --> Language Class Initialized
ERROR - 2016-08-10 18:12:31 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-10 18:12:35 --> Config Class Initialized
INFO - 2016-08-10 18:12:35 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:35 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:35 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:35 --> URI Class Initialized
INFO - 2016-08-10 18:12:35 --> Router Class Initialized
INFO - 2016-08-10 18:12:35 --> Output Class Initialized
INFO - 2016-08-10 18:12:35 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:35 --> Input Class Initialized
INFO - 2016-08-10 18:12:35 --> Language Class Initialized
INFO - 2016-08-10 18:12:35 --> Loader Class Initialized
INFO - 2016-08-10 18:12:35 --> Helper loaded: url_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: html_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: form_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: file_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:12:35 --> Database Driver Class Initialized
INFO - 2016-08-10 18:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:12:35 --> Form Validation Class Initialized
INFO - 2016-08-10 18:12:35 --> Email Class Initialized
INFO - 2016-08-10 18:12:35 --> Controller Class Initialized
INFO - 2016-08-10 18:12:35 --> Model Class Initialized
DEBUG - 2016-08-10 18:12:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:12:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 18:12:35 --> Config Class Initialized
INFO - 2016-08-10 18:12:35 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:12:35 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:12:35 --> Utf8 Class Initialized
INFO - 2016-08-10 18:12:35 --> URI Class Initialized
DEBUG - 2016-08-10 18:12:35 --> No URI present. Default controller set.
INFO - 2016-08-10 18:12:35 --> Router Class Initialized
INFO - 2016-08-10 18:12:35 --> Output Class Initialized
INFO - 2016-08-10 18:12:35 --> Security Class Initialized
DEBUG - 2016-08-10 18:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:12:35 --> Input Class Initialized
INFO - 2016-08-10 18:12:35 --> Language Class Initialized
INFO - 2016-08-10 18:12:35 --> Loader Class Initialized
INFO - 2016-08-10 18:12:35 --> Helper loaded: url_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: html_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: form_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: file_helper
INFO - 2016-08-10 18:12:35 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:12:35 --> Database Driver Class Initialized
INFO - 2016-08-10 18:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:12:35 --> Form Validation Class Initialized
INFO - 2016-08-10 18:12:35 --> Email Class Initialized
INFO - 2016-08-10 18:12:35 --> Controller Class Initialized
INFO - 2016-08-10 18:12:35 --> Model Class Initialized
INFO - 2016-08-10 18:12:36 --> Model Class Initialized
INFO - 2016-08-10 18:12:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:12:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:12:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-10 18:12:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:12:36 --> Final output sent to browser
DEBUG - 2016-08-10 18:12:36 --> Total execution time: 0.4071
INFO - 2016-08-10 18:18:05 --> Config Class Initialized
INFO - 2016-08-10 18:18:05 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:18:05 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:18:05 --> Utf8 Class Initialized
INFO - 2016-08-10 18:18:05 --> URI Class Initialized
INFO - 2016-08-10 18:18:05 --> Router Class Initialized
INFO - 2016-08-10 18:18:05 --> Output Class Initialized
INFO - 2016-08-10 18:18:05 --> Security Class Initialized
DEBUG - 2016-08-10 18:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:18:05 --> Input Class Initialized
INFO - 2016-08-10 18:18:05 --> Language Class Initialized
INFO - 2016-08-10 18:18:05 --> Loader Class Initialized
INFO - 2016-08-10 18:18:05 --> Helper loaded: url_helper
INFO - 2016-08-10 18:18:05 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:18:05 --> Helper loaded: html_helper
INFO - 2016-08-10 18:18:05 --> Helper loaded: form_helper
INFO - 2016-08-10 18:18:05 --> Helper loaded: file_helper
INFO - 2016-08-10 18:18:05 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:18:05 --> Database Driver Class Initialized
INFO - 2016-08-10 18:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:18:05 --> Form Validation Class Initialized
INFO - 2016-08-10 18:18:05 --> Email Class Initialized
INFO - 2016-08-10 18:18:05 --> Controller Class Initialized
DEBUG - 2016-08-10 18:18:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 18:18:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:18:05 --> Model Class Initialized
INFO - 2016-08-10 18:18:05 --> Model Class Initialized
INFO - 2016-08-10 18:18:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:18:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:18:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 18:18:06 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:18:06 --> Final output sent to browser
DEBUG - 2016-08-10 18:18:06 --> Total execution time: 0.6817
INFO - 2016-08-10 18:19:10 --> Config Class Initialized
INFO - 2016-08-10 18:19:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:11 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:11 --> URI Class Initialized
INFO - 2016-08-10 18:19:11 --> Router Class Initialized
INFO - 2016-08-10 18:19:11 --> Output Class Initialized
INFO - 2016-08-10 18:19:11 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:11 --> Input Class Initialized
INFO - 2016-08-10 18:19:11 --> Language Class Initialized
INFO - 2016-08-10 18:19:11 --> Loader Class Initialized
INFO - 2016-08-10 18:19:11 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:11 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:11 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:11 --> Email Class Initialized
INFO - 2016-08-10 18:19:11 --> Controller Class Initialized
INFO - 2016-08-10 18:19:11 --> Model Class Initialized
INFO - 2016-08-10 18:19:11 --> Config Class Initialized
INFO - 2016-08-10 18:19:11 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:11 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:11 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:11 --> URI Class Initialized
INFO - 2016-08-10 18:19:11 --> Router Class Initialized
INFO - 2016-08-10 18:19:11 --> Output Class Initialized
INFO - 2016-08-10 18:19:11 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:11 --> Input Class Initialized
INFO - 2016-08-10 18:19:11 --> Language Class Initialized
INFO - 2016-08-10 18:19:11 --> Loader Class Initialized
INFO - 2016-08-10 18:19:11 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:11 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:11 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:11 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:11 --> Email Class Initialized
INFO - 2016-08-10 18:19:11 --> Controller Class Initialized
INFO - 2016-08-10 18:19:11 --> Model Class Initialized
DEBUG - 2016-08-10 18:19:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:19:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 18:19:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:19:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 18:19:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:19:11 --> Final output sent to browser
DEBUG - 2016-08-10 18:19:11 --> Total execution time: 0.2957
INFO - 2016-08-10 18:19:19 --> Config Class Initialized
INFO - 2016-08-10 18:19:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:19 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:19 --> URI Class Initialized
INFO - 2016-08-10 18:19:19 --> Router Class Initialized
INFO - 2016-08-10 18:19:19 --> Output Class Initialized
INFO - 2016-08-10 18:19:19 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:19 --> Input Class Initialized
INFO - 2016-08-10 18:19:19 --> Language Class Initialized
INFO - 2016-08-10 18:19:19 --> Loader Class Initialized
INFO - 2016-08-10 18:19:19 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:19 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:19 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:19 --> Email Class Initialized
INFO - 2016-08-10 18:19:19 --> Controller Class Initialized
INFO - 2016-08-10 18:19:19 --> Model Class Initialized
DEBUG - 2016-08-10 18:19:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:19:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 18:19:19 --> Config Class Initialized
INFO - 2016-08-10 18:19:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:19 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:19 --> URI Class Initialized
INFO - 2016-08-10 18:19:19 --> Router Class Initialized
INFO - 2016-08-10 18:19:19 --> Output Class Initialized
INFO - 2016-08-10 18:19:19 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:19 --> Input Class Initialized
INFO - 2016-08-10 18:19:19 --> Language Class Initialized
INFO - 2016-08-10 18:19:19 --> Loader Class Initialized
INFO - 2016-08-10 18:19:19 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:19 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:20 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:20 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:20 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:20 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:20 --> Email Class Initialized
INFO - 2016-08-10 18:19:20 --> Controller Class Initialized
INFO - 2016-08-10 18:19:20 --> Model Class Initialized
INFO - 2016-08-10 18:19:20 --> Model Class Initialized
INFO - 2016-08-10 18:19:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:19:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:19:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-10 18:19:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:19:20 --> Final output sent to browser
DEBUG - 2016-08-10 18:19:20 --> Total execution time: 0.2825
INFO - 2016-08-10 18:19:30 --> Config Class Initialized
INFO - 2016-08-10 18:19:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:30 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:30 --> URI Class Initialized
INFO - 2016-08-10 18:19:30 --> Router Class Initialized
INFO - 2016-08-10 18:19:30 --> Output Class Initialized
INFO - 2016-08-10 18:19:30 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:30 --> Input Class Initialized
INFO - 2016-08-10 18:19:30 --> Language Class Initialized
INFO - 2016-08-10 18:19:30 --> Loader Class Initialized
INFO - 2016-08-10 18:19:30 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:30 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:30 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:30 --> Email Class Initialized
INFO - 2016-08-10 18:19:30 --> Controller Class Initialized
INFO - 2016-08-10 18:19:30 --> Model Class Initialized
INFO - 2016-08-10 18:19:30 --> Config Class Initialized
INFO - 2016-08-10 18:19:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:30 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:30 --> URI Class Initialized
INFO - 2016-08-10 18:19:30 --> Router Class Initialized
INFO - 2016-08-10 18:19:30 --> Output Class Initialized
INFO - 2016-08-10 18:19:30 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:30 --> Input Class Initialized
INFO - 2016-08-10 18:19:30 --> Language Class Initialized
INFO - 2016-08-10 18:19:30 --> Loader Class Initialized
INFO - 2016-08-10 18:19:30 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:30 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:30 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:30 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:30 --> Email Class Initialized
INFO - 2016-08-10 18:19:30 --> Controller Class Initialized
INFO - 2016-08-10 18:19:30 --> Model Class Initialized
DEBUG - 2016-08-10 18:19:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 18:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 18:19:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:19:30 --> Final output sent to browser
DEBUG - 2016-08-10 18:19:30 --> Total execution time: 0.2928
INFO - 2016-08-10 18:19:36 --> Config Class Initialized
INFO - 2016-08-10 18:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:36 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:36 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:36 --> URI Class Initialized
INFO - 2016-08-10 18:19:36 --> Router Class Initialized
INFO - 2016-08-10 18:19:36 --> Output Class Initialized
INFO - 2016-08-10 18:19:36 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:36 --> Input Class Initialized
INFO - 2016-08-10 18:19:36 --> Language Class Initialized
INFO - 2016-08-10 18:19:36 --> Loader Class Initialized
INFO - 2016-08-10 18:19:36 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:36 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:36 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:36 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:36 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:36 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:36 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:36 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:36 --> Email Class Initialized
INFO - 2016-08-10 18:19:36 --> Controller Class Initialized
INFO - 2016-08-10 18:19:36 --> Model Class Initialized
DEBUG - 2016-08-10 18:19:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:19:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 18:19:36 --> Config Class Initialized
INFO - 2016-08-10 18:19:36 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:19:36 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:19:36 --> Utf8 Class Initialized
INFO - 2016-08-10 18:19:36 --> URI Class Initialized
INFO - 2016-08-10 18:19:36 --> Router Class Initialized
INFO - 2016-08-10 18:19:36 --> Output Class Initialized
INFO - 2016-08-10 18:19:36 --> Security Class Initialized
DEBUG - 2016-08-10 18:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:19:36 --> Input Class Initialized
INFO - 2016-08-10 18:19:36 --> Language Class Initialized
INFO - 2016-08-10 18:19:37 --> Loader Class Initialized
INFO - 2016-08-10 18:19:37 --> Helper loaded: url_helper
INFO - 2016-08-10 18:19:37 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:19:37 --> Helper loaded: html_helper
INFO - 2016-08-10 18:19:37 --> Helper loaded: form_helper
INFO - 2016-08-10 18:19:37 --> Helper loaded: file_helper
INFO - 2016-08-10 18:19:37 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:19:37 --> Database Driver Class Initialized
INFO - 2016-08-10 18:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:19:37 --> Form Validation Class Initialized
INFO - 2016-08-10 18:19:37 --> Email Class Initialized
INFO - 2016-08-10 18:19:37 --> Controller Class Initialized
DEBUG - 2016-08-10 18:19:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 18:19:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:19:37 --> Model Class Initialized
INFO - 2016-08-10 18:19:37 --> Model Class Initialized
INFO - 2016-08-10 18:19:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:19:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:19:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 18:19:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:19:37 --> Final output sent to browser
DEBUG - 2016-08-10 18:19:37 --> Total execution time: 0.3396
INFO - 2016-08-10 18:23:58 --> Config Class Initialized
INFO - 2016-08-10 18:23:58 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:23:58 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:23:58 --> Utf8 Class Initialized
INFO - 2016-08-10 18:23:58 --> URI Class Initialized
INFO - 2016-08-10 18:23:58 --> Router Class Initialized
INFO - 2016-08-10 18:23:58 --> Output Class Initialized
INFO - 2016-08-10 18:23:58 --> Security Class Initialized
DEBUG - 2016-08-10 18:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:23:58 --> Input Class Initialized
INFO - 2016-08-10 18:23:58 --> Language Class Initialized
INFO - 2016-08-10 18:23:58 --> Loader Class Initialized
INFO - 2016-08-10 18:23:58 --> Helper loaded: url_helper
INFO - 2016-08-10 18:23:58 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:23:58 --> Helper loaded: html_helper
INFO - 2016-08-10 18:23:58 --> Helper loaded: form_helper
INFO - 2016-08-10 18:23:58 --> Helper loaded: file_helper
INFO - 2016-08-10 18:23:58 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:23:58 --> Database Driver Class Initialized
INFO - 2016-08-10 18:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:23:58 --> Form Validation Class Initialized
INFO - 2016-08-10 18:23:58 --> Email Class Initialized
INFO - 2016-08-10 18:23:58 --> Controller Class Initialized
DEBUG - 2016-08-10 18:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 18:23:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:23:58 --> Model Class Initialized
INFO - 2016-08-10 18:23:58 --> Model Class Initialized
INFO - 2016-08-10 18:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 18:23:58 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:23:58 --> Final output sent to browser
DEBUG - 2016-08-10 18:23:58 --> Total execution time: 0.3852
INFO - 2016-08-10 18:24:24 --> Config Class Initialized
INFO - 2016-08-10 18:24:24 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:24:24 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:24:24 --> Utf8 Class Initialized
INFO - 2016-08-10 18:24:24 --> URI Class Initialized
INFO - 2016-08-10 18:24:24 --> Router Class Initialized
INFO - 2016-08-10 18:24:24 --> Output Class Initialized
INFO - 2016-08-10 18:24:24 --> Security Class Initialized
DEBUG - 2016-08-10 18:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:24:24 --> Input Class Initialized
INFO - 2016-08-10 18:24:24 --> Language Class Initialized
INFO - 2016-08-10 18:24:24 --> Loader Class Initialized
INFO - 2016-08-10 18:24:24 --> Helper loaded: url_helper
INFO - 2016-08-10 18:24:24 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:24:24 --> Helper loaded: html_helper
INFO - 2016-08-10 18:24:24 --> Helper loaded: form_helper
INFO - 2016-08-10 18:24:24 --> Helper loaded: file_helper
INFO - 2016-08-10 18:24:24 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:24:24 --> Database Driver Class Initialized
INFO - 2016-08-10 18:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:24:24 --> Form Validation Class Initialized
INFO - 2016-08-10 18:24:24 --> Email Class Initialized
INFO - 2016-08-10 18:24:24 --> Controller Class Initialized
DEBUG - 2016-08-10 18:24:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 18:24:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:24:24 --> Model Class Initialized
INFO - 2016-08-10 18:24:24 --> Model Class Initialized
INFO - 2016-08-10 18:24:24 --> Model Class Initialized
INFO - 2016-08-10 18:24:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:24:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:24:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/all_books.php
INFO - 2016-08-10 18:24:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:24:24 --> Final output sent to browser
DEBUG - 2016-08-10 18:24:24 --> Total execution time: 0.3749
INFO - 2016-08-10 18:25:19 --> Config Class Initialized
INFO - 2016-08-10 18:25:19 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:25:19 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:25:19 --> Utf8 Class Initialized
INFO - 2016-08-10 18:25:19 --> URI Class Initialized
INFO - 2016-08-10 18:25:19 --> Router Class Initialized
INFO - 2016-08-10 18:25:19 --> Output Class Initialized
INFO - 2016-08-10 18:25:19 --> Security Class Initialized
DEBUG - 2016-08-10 18:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:25:19 --> Input Class Initialized
INFO - 2016-08-10 18:25:19 --> Language Class Initialized
INFO - 2016-08-10 18:25:19 --> Loader Class Initialized
INFO - 2016-08-10 18:25:19 --> Helper loaded: url_helper
INFO - 2016-08-10 18:25:19 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:25:19 --> Helper loaded: html_helper
INFO - 2016-08-10 18:25:19 --> Helper loaded: form_helper
INFO - 2016-08-10 18:25:19 --> Helper loaded: file_helper
INFO - 2016-08-10 18:25:19 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:25:19 --> Database Driver Class Initialized
INFO - 2016-08-10 18:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:25:20 --> Form Validation Class Initialized
INFO - 2016-08-10 18:25:20 --> Email Class Initialized
INFO - 2016-08-10 18:25:20 --> Controller Class Initialized
DEBUG - 2016-08-10 18:25:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:25:20 --> Model Class Initialized
INFO - 2016-08-10 18:25:20 --> Model Class Initialized
INFO - 2016-08-10 18:25:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:25:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:25:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 18:25:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:25:20 --> Final output sent to browser
DEBUG - 2016-08-10 18:25:20 --> Total execution time: 0.3012
INFO - 2016-08-10 18:25:29 --> Config Class Initialized
INFO - 2016-08-10 18:25:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:25:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:25:29 --> Utf8 Class Initialized
INFO - 2016-08-10 18:25:29 --> URI Class Initialized
INFO - 2016-08-10 18:25:29 --> Router Class Initialized
INFO - 2016-08-10 18:25:29 --> Output Class Initialized
INFO - 2016-08-10 18:25:29 --> Security Class Initialized
DEBUG - 2016-08-10 18:25:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:25:29 --> Input Class Initialized
INFO - 2016-08-10 18:25:29 --> Language Class Initialized
INFO - 2016-08-10 18:25:29 --> Loader Class Initialized
INFO - 2016-08-10 18:25:29 --> Helper loaded: url_helper
INFO - 2016-08-10 18:25:29 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:25:29 --> Helper loaded: html_helper
INFO - 2016-08-10 18:25:29 --> Helper loaded: form_helper
INFO - 2016-08-10 18:25:29 --> Helper loaded: file_helper
INFO - 2016-08-10 18:25:29 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:25:29 --> Database Driver Class Initialized
INFO - 2016-08-10 18:25:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:25:29 --> Form Validation Class Initialized
INFO - 2016-08-10 18:25:29 --> Email Class Initialized
INFO - 2016-08-10 18:25:29 --> Controller Class Initialized
DEBUG - 2016-08-10 18:25:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:25:29 --> Model Class Initialized
INFO - 2016-08-10 18:25:29 --> Model Class Initialized
INFO - 2016-08-10 18:25:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:25:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:25:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-10 18:25:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:25:29 --> Final output sent to browser
DEBUG - 2016-08-10 18:25:29 --> Total execution time: 0.2883
INFO - 2016-08-10 18:26:11 --> Config Class Initialized
INFO - 2016-08-10 18:26:11 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:26:11 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:26:11 --> Utf8 Class Initialized
INFO - 2016-08-10 18:26:11 --> URI Class Initialized
INFO - 2016-08-10 18:26:12 --> Router Class Initialized
INFO - 2016-08-10 18:26:12 --> Output Class Initialized
INFO - 2016-08-10 18:26:12 --> Security Class Initialized
DEBUG - 2016-08-10 18:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:26:12 --> Input Class Initialized
INFO - 2016-08-10 18:26:12 --> Language Class Initialized
INFO - 2016-08-10 18:26:12 --> Loader Class Initialized
INFO - 2016-08-10 18:26:12 --> Helper loaded: url_helper
INFO - 2016-08-10 18:26:12 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:26:12 --> Helper loaded: html_helper
INFO - 2016-08-10 18:26:12 --> Helper loaded: form_helper
INFO - 2016-08-10 18:26:12 --> Helper loaded: file_helper
INFO - 2016-08-10 18:26:12 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:26:12 --> Database Driver Class Initialized
INFO - 2016-08-10 18:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:26:12 --> Form Validation Class Initialized
INFO - 2016-08-10 18:26:12 --> Email Class Initialized
INFO - 2016-08-10 18:26:12 --> Controller Class Initialized
INFO - 2016-08-10 18:26:12 --> Model Class Initialized
INFO - 2016-08-10 18:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-10 18:26:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:26:12 --> Final output sent to browser
DEBUG - 2016-08-10 18:26:12 --> Total execution time: 0.2838
INFO - 2016-08-10 18:26:15 --> Config Class Initialized
INFO - 2016-08-10 18:26:15 --> Hooks Class Initialized
DEBUG - 2016-08-10 18:26:15 --> UTF-8 Support Enabled
INFO - 2016-08-10 18:26:15 --> Utf8 Class Initialized
INFO - 2016-08-10 18:26:15 --> URI Class Initialized
INFO - 2016-08-10 18:26:15 --> Router Class Initialized
INFO - 2016-08-10 18:26:15 --> Output Class Initialized
INFO - 2016-08-10 18:26:15 --> Security Class Initialized
DEBUG - 2016-08-10 18:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 18:26:15 --> Input Class Initialized
INFO - 2016-08-10 18:26:15 --> Language Class Initialized
INFO - 2016-08-10 18:26:15 --> Loader Class Initialized
INFO - 2016-08-10 18:26:15 --> Helper loaded: url_helper
INFO - 2016-08-10 18:26:15 --> Helper loaded: utils_helper
INFO - 2016-08-10 18:26:15 --> Helper loaded: html_helper
INFO - 2016-08-10 18:26:15 --> Helper loaded: form_helper
INFO - 2016-08-10 18:26:15 --> Helper loaded: file_helper
INFO - 2016-08-10 18:26:15 --> Helper loaded: myemail_helper
INFO - 2016-08-10 18:26:15 --> Database Driver Class Initialized
INFO - 2016-08-10 18:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 18:26:15 --> Form Validation Class Initialized
INFO - 2016-08-10 18:26:15 --> Email Class Initialized
INFO - 2016-08-10 18:26:15 --> Controller Class Initialized
DEBUG - 2016-08-10 18:26:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 18:26:15 --> Model Class Initialized
INFO - 2016-08-10 18:26:15 --> Model Class Initialized
INFO - 2016-08-10 18:26:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 18:26:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 18:26:15 --> Model Class Initialized
INFO - 2016-08-10 18:26:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/borrow_list.php
INFO - 2016-08-10 18:26:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 18:26:15 --> Final output sent to browser
DEBUG - 2016-08-10 18:26:15 --> Total execution time: 0.2942
INFO - 2016-08-10 19:18:57 --> Config Class Initialized
INFO - 2016-08-10 19:18:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:18:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:18:57 --> Utf8 Class Initialized
INFO - 2016-08-10 19:18:57 --> URI Class Initialized
INFO - 2016-08-10 19:18:57 --> Router Class Initialized
INFO - 2016-08-10 19:18:57 --> Output Class Initialized
INFO - 2016-08-10 19:18:57 --> Security Class Initialized
DEBUG - 2016-08-10 19:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:18:57 --> Input Class Initialized
INFO - 2016-08-10 19:18:57 --> Language Class Initialized
INFO - 2016-08-10 19:18:57 --> Loader Class Initialized
INFO - 2016-08-10 19:18:57 --> Helper loaded: url_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: html_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: form_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: file_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:18:57 --> Database Driver Class Initialized
INFO - 2016-08-10 19:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:18:57 --> Form Validation Class Initialized
INFO - 2016-08-10 19:18:57 --> Email Class Initialized
INFO - 2016-08-10 19:18:57 --> Controller Class Initialized
DEBUG - 2016-08-10 19:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:18:57 --> Model Class Initialized
INFO - 2016-08-10 19:18:57 --> Model Class Initialized
ERROR - 2016-08-10 19:18:57 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:18:57 --> Config Class Initialized
INFO - 2016-08-10 19:18:57 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:18:57 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:18:57 --> Utf8 Class Initialized
INFO - 2016-08-10 19:18:57 --> URI Class Initialized
INFO - 2016-08-10 19:18:57 --> Router Class Initialized
INFO - 2016-08-10 19:18:57 --> Output Class Initialized
INFO - 2016-08-10 19:18:57 --> Security Class Initialized
DEBUG - 2016-08-10 19:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:18:57 --> Input Class Initialized
INFO - 2016-08-10 19:18:57 --> Language Class Initialized
INFO - 2016-08-10 19:18:57 --> Loader Class Initialized
INFO - 2016-08-10 19:18:57 --> Helper loaded: url_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: html_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: form_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: file_helper
INFO - 2016-08-10 19:18:57 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:18:57 --> Database Driver Class Initialized
INFO - 2016-08-10 19:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:18:57 --> Form Validation Class Initialized
INFO - 2016-08-10 19:18:57 --> Email Class Initialized
INFO - 2016-08-10 19:18:57 --> Controller Class Initialized
DEBUG - 2016-08-10 19:18:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:18:57 --> Model Class Initialized
INFO - 2016-08-10 19:18:57 --> Model Class Initialized
INFO - 2016-08-10 19:18:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:18:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:18:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-10 19:18:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:18:57 --> Final output sent to browser
DEBUG - 2016-08-10 19:18:57 --> Total execution time: 0.2883
INFO - 2016-08-10 19:19:02 --> Config Class Initialized
INFO - 2016-08-10 19:19:02 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:02 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:02 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:02 --> URI Class Initialized
INFO - 2016-08-10 19:19:02 --> Router Class Initialized
INFO - 2016-08-10 19:19:02 --> Output Class Initialized
INFO - 2016-08-10 19:19:02 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:02 --> Input Class Initialized
INFO - 2016-08-10 19:19:02 --> Language Class Initialized
INFO - 2016-08-10 19:19:02 --> Loader Class Initialized
INFO - 2016-08-10 19:19:02 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:02 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:02 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:02 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:02 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:02 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:02 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:02 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:02 --> Email Class Initialized
INFO - 2016-08-10 19:19:02 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 19:19:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:03 --> Model Class Initialized
INFO - 2016-08-10 19:19:03 --> Model Class Initialized
INFO - 2016-08-10 19:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 19:19:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:03 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:03 --> Total execution time: 0.3572
INFO - 2016-08-10 19:19:09 --> Config Class Initialized
INFO - 2016-08-10 19:19:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:09 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:09 --> URI Class Initialized
INFO - 2016-08-10 19:19:09 --> Router Class Initialized
INFO - 2016-08-10 19:19:09 --> Output Class Initialized
INFO - 2016-08-10 19:19:09 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:09 --> Input Class Initialized
INFO - 2016-08-10 19:19:09 --> Language Class Initialized
INFO - 2016-08-10 19:19:09 --> Loader Class Initialized
INFO - 2016-08-10 19:19:09 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:09 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:09 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:09 --> Email Class Initialized
INFO - 2016-08-10 19:19:09 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:09 --> Model Class Initialized
INFO - 2016-08-10 19:19:09 --> Model Class Initialized
ERROR - 2016-08-10 19:19:09 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:19:09 --> Config Class Initialized
INFO - 2016-08-10 19:19:09 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:09 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:09 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:09 --> URI Class Initialized
INFO - 2016-08-10 19:19:09 --> Router Class Initialized
INFO - 2016-08-10 19:19:09 --> Output Class Initialized
INFO - 2016-08-10 19:19:09 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:09 --> Input Class Initialized
INFO - 2016-08-10 19:19:09 --> Language Class Initialized
INFO - 2016-08-10 19:19:09 --> Loader Class Initialized
INFO - 2016-08-10 19:19:09 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:09 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:09 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:09 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:09 --> Email Class Initialized
INFO - 2016-08-10 19:19:09 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:09 --> Model Class Initialized
INFO - 2016-08-10 19:19:09 --> Model Class Initialized
INFO - 2016-08-10 19:19:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:19:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-10 19:19:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:10 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:10 --> Total execution time: 0.2978
INFO - 2016-08-10 19:19:25 --> Config Class Initialized
INFO - 2016-08-10 19:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:25 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:25 --> URI Class Initialized
INFO - 2016-08-10 19:19:25 --> Router Class Initialized
INFO - 2016-08-10 19:19:25 --> Output Class Initialized
INFO - 2016-08-10 19:19:25 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:25 --> Input Class Initialized
INFO - 2016-08-10 19:19:25 --> Language Class Initialized
INFO - 2016-08-10 19:19:25 --> Loader Class Initialized
INFO - 2016-08-10 19:19:25 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:25 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:25 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:25 --> Email Class Initialized
INFO - 2016-08-10 19:19:25 --> Controller Class Initialized
INFO - 2016-08-10 19:19:25 --> Model Class Initialized
INFO - 2016-08-10 19:19:25 --> Config Class Initialized
INFO - 2016-08-10 19:19:25 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:25 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:25 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:25 --> URI Class Initialized
INFO - 2016-08-10 19:19:25 --> Router Class Initialized
INFO - 2016-08-10 19:19:25 --> Output Class Initialized
INFO - 2016-08-10 19:19:25 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:25 --> Input Class Initialized
INFO - 2016-08-10 19:19:25 --> Language Class Initialized
INFO - 2016-08-10 19:19:25 --> Loader Class Initialized
INFO - 2016-08-10 19:19:25 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:25 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:26 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:26 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:26 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:26 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:26 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:26 --> Email Class Initialized
INFO - 2016-08-10 19:19:26 --> Controller Class Initialized
INFO - 2016-08-10 19:19:26 --> Model Class Initialized
DEBUG - 2016-08-10 19:19:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 19:19:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 19:19:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:26 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:26 --> Total execution time: 0.3211
INFO - 2016-08-10 19:19:30 --> Config Class Initialized
INFO - 2016-08-10 19:19:30 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:30 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:30 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:30 --> URI Class Initialized
INFO - 2016-08-10 19:19:30 --> Router Class Initialized
INFO - 2016-08-10 19:19:30 --> Output Class Initialized
INFO - 2016-08-10 19:19:30 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:30 --> Input Class Initialized
INFO - 2016-08-10 19:19:30 --> Language Class Initialized
INFO - 2016-08-10 19:19:30 --> Loader Class Initialized
INFO - 2016-08-10 19:19:30 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:30 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:30 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:30 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:30 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:31 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:31 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:31 --> Email Class Initialized
INFO - 2016-08-10 19:19:31 --> Controller Class Initialized
INFO - 2016-08-10 19:19:31 --> Model Class Initialized
DEBUG - 2016-08-10 19:19:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 19:19:31 --> Config Class Initialized
INFO - 2016-08-10 19:19:31 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:31 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:31 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:31 --> URI Class Initialized
INFO - 2016-08-10 19:19:31 --> Router Class Initialized
INFO - 2016-08-10 19:19:31 --> Output Class Initialized
INFO - 2016-08-10 19:19:31 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:31 --> Input Class Initialized
INFO - 2016-08-10 19:19:31 --> Language Class Initialized
INFO - 2016-08-10 19:19:31 --> Loader Class Initialized
INFO - 2016-08-10 19:19:31 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:31 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:31 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:31 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:31 --> Email Class Initialized
INFO - 2016-08-10 19:19:31 --> Controller Class Initialized
INFO - 2016-08-10 19:19:31 --> Model Class Initialized
INFO - 2016-08-10 19:19:31 --> Model Class Initialized
INFO - 2016-08-10 19:19:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:19:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-10 19:19:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:31 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:31 --> Total execution time: 0.3033
INFO - 2016-08-10 19:19:39 --> Config Class Initialized
INFO - 2016-08-10 19:19:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:39 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:39 --> URI Class Initialized
INFO - 2016-08-10 19:19:39 --> Router Class Initialized
INFO - 2016-08-10 19:19:39 --> Output Class Initialized
INFO - 2016-08-10 19:19:39 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:39 --> Input Class Initialized
INFO - 2016-08-10 19:19:39 --> Language Class Initialized
INFO - 2016-08-10 19:19:39 --> Loader Class Initialized
INFO - 2016-08-10 19:19:39 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:39 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:39 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:39 --> Email Class Initialized
INFO - 2016-08-10 19:19:39 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:39 --> Model Class Initialized
INFO - 2016-08-10 19:19:39 --> Model Class Initialized
ERROR - 2016-08-10 19:19:39 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:19:39 --> Config Class Initialized
INFO - 2016-08-10 19:19:39 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:39 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:39 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:39 --> URI Class Initialized
INFO - 2016-08-10 19:19:39 --> Router Class Initialized
INFO - 2016-08-10 19:19:39 --> Output Class Initialized
INFO - 2016-08-10 19:19:39 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:39 --> Input Class Initialized
INFO - 2016-08-10 19:19:39 --> Language Class Initialized
INFO - 2016-08-10 19:19:39 --> Loader Class Initialized
INFO - 2016-08-10 19:19:39 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:39 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:39 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:39 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:39 --> Email Class Initialized
INFO - 2016-08-10 19:19:39 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:39 --> Model Class Initialized
INFO - 2016-08-10 19:19:39 --> Model Class Initialized
INFO - 2016-08-10 19:19:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:19:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-10 19:19:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:39 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:39 --> Total execution time: 0.3237
INFO - 2016-08-10 19:19:53 --> Config Class Initialized
INFO - 2016-08-10 19:19:53 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:19:53 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:19:53 --> Utf8 Class Initialized
INFO - 2016-08-10 19:19:53 --> URI Class Initialized
INFO - 2016-08-10 19:19:53 --> Router Class Initialized
INFO - 2016-08-10 19:19:53 --> Output Class Initialized
INFO - 2016-08-10 19:19:53 --> Security Class Initialized
DEBUG - 2016-08-10 19:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:19:53 --> Input Class Initialized
INFO - 2016-08-10 19:19:53 --> Language Class Initialized
INFO - 2016-08-10 19:19:53 --> Loader Class Initialized
INFO - 2016-08-10 19:19:53 --> Helper loaded: url_helper
INFO - 2016-08-10 19:19:53 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:19:53 --> Helper loaded: html_helper
INFO - 2016-08-10 19:19:53 --> Helper loaded: form_helper
INFO - 2016-08-10 19:19:54 --> Helper loaded: file_helper
INFO - 2016-08-10 19:19:54 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:19:54 --> Database Driver Class Initialized
INFO - 2016-08-10 19:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:19:54 --> Form Validation Class Initialized
INFO - 2016-08-10 19:19:54 --> Email Class Initialized
INFO - 2016-08-10 19:19:54 --> Controller Class Initialized
DEBUG - 2016-08-10 19:19:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:19:54 --> Model Class Initialized
INFO - 2016-08-10 19:19:54 --> Model Class Initialized
INFO - 2016-08-10 19:19:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:19:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:19:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\authorize/index.php
INFO - 2016-08-10 19:19:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:19:54 --> Final output sent to browser
DEBUG - 2016-08-10 19:19:54 --> Total execution time: 0.3258
INFO - 2016-08-10 19:20:00 --> Config Class Initialized
INFO - 2016-08-10 19:20:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:20:00 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:20:00 --> Utf8 Class Initialized
INFO - 2016-08-10 19:20:00 --> URI Class Initialized
INFO - 2016-08-10 19:20:00 --> Router Class Initialized
INFO - 2016-08-10 19:20:00 --> Output Class Initialized
INFO - 2016-08-10 19:20:00 --> Security Class Initialized
DEBUG - 2016-08-10 19:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:20:00 --> Input Class Initialized
INFO - 2016-08-10 19:20:00 --> Language Class Initialized
INFO - 2016-08-10 19:20:00 --> Loader Class Initialized
INFO - 2016-08-10 19:20:00 --> Helper loaded: url_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: html_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: form_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: file_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:20:00 --> Database Driver Class Initialized
INFO - 2016-08-10 19:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:20:00 --> Form Validation Class Initialized
INFO - 2016-08-10 19:20:00 --> Email Class Initialized
INFO - 2016-08-10 19:20:00 --> Controller Class Initialized
INFO - 2016-08-10 19:20:00 --> Model Class Initialized
INFO - 2016-08-10 19:20:00 --> Config Class Initialized
INFO - 2016-08-10 19:20:00 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:20:00 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:20:00 --> Utf8 Class Initialized
INFO - 2016-08-10 19:20:00 --> URI Class Initialized
INFO - 2016-08-10 19:20:00 --> Router Class Initialized
INFO - 2016-08-10 19:20:00 --> Output Class Initialized
INFO - 2016-08-10 19:20:00 --> Security Class Initialized
DEBUG - 2016-08-10 19:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:20:00 --> Input Class Initialized
INFO - 2016-08-10 19:20:00 --> Language Class Initialized
INFO - 2016-08-10 19:20:00 --> Loader Class Initialized
INFO - 2016-08-10 19:20:00 --> Helper loaded: url_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: html_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: form_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: file_helper
INFO - 2016-08-10 19:20:00 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:20:00 --> Database Driver Class Initialized
INFO - 2016-08-10 19:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:20:00 --> Form Validation Class Initialized
INFO - 2016-08-10 19:20:00 --> Email Class Initialized
INFO - 2016-08-10 19:20:00 --> Controller Class Initialized
INFO - 2016-08-10 19:20:00 --> Model Class Initialized
DEBUG - 2016-08-10 19:20:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:20:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 19:20:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:20:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 19:20:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:20:01 --> Final output sent to browser
DEBUG - 2016-08-10 19:20:01 --> Total execution time: 0.3170
INFO - 2016-08-10 19:20:05 --> Config Class Initialized
INFO - 2016-08-10 19:20:05 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:20:05 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:20:05 --> Utf8 Class Initialized
INFO - 2016-08-10 19:20:05 --> URI Class Initialized
INFO - 2016-08-10 19:20:05 --> Router Class Initialized
INFO - 2016-08-10 19:20:05 --> Output Class Initialized
INFO - 2016-08-10 19:20:05 --> Security Class Initialized
DEBUG - 2016-08-10 19:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:20:05 --> Input Class Initialized
INFO - 2016-08-10 19:20:05 --> Language Class Initialized
INFO - 2016-08-10 19:20:05 --> Loader Class Initialized
INFO - 2016-08-10 19:20:05 --> Helper loaded: url_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: html_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: form_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: file_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:20:05 --> Database Driver Class Initialized
INFO - 2016-08-10 19:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:20:05 --> Form Validation Class Initialized
INFO - 2016-08-10 19:20:05 --> Email Class Initialized
INFO - 2016-08-10 19:20:05 --> Controller Class Initialized
INFO - 2016-08-10 19:20:05 --> Model Class Initialized
DEBUG - 2016-08-10 19:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:20:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 19:20:05 --> Config Class Initialized
INFO - 2016-08-10 19:20:05 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:20:05 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:20:05 --> Utf8 Class Initialized
INFO - 2016-08-10 19:20:05 --> URI Class Initialized
INFO - 2016-08-10 19:20:05 --> Router Class Initialized
INFO - 2016-08-10 19:20:05 --> Output Class Initialized
INFO - 2016-08-10 19:20:05 --> Security Class Initialized
DEBUG - 2016-08-10 19:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:20:05 --> Input Class Initialized
INFO - 2016-08-10 19:20:05 --> Language Class Initialized
INFO - 2016-08-10 19:20:05 --> Loader Class Initialized
INFO - 2016-08-10 19:20:05 --> Helper loaded: url_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: html_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: form_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: file_helper
INFO - 2016-08-10 19:20:05 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:20:05 --> Database Driver Class Initialized
INFO - 2016-08-10 19:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:20:05 --> Form Validation Class Initialized
INFO - 2016-08-10 19:20:05 --> Email Class Initialized
INFO - 2016-08-10 19:20:05 --> Controller Class Initialized
DEBUG - 2016-08-10 19:20:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 19:20:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:20:05 --> Model Class Initialized
INFO - 2016-08-10 19:20:05 --> Model Class Initialized
INFO - 2016-08-10 19:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 19:20:05 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:20:05 --> Final output sent to browser
DEBUG - 2016-08-10 19:20:05 --> Total execution time: 0.3877
INFO - 2016-08-10 19:20:10 --> Config Class Initialized
INFO - 2016-08-10 19:20:10 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:20:10 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:20:10 --> Utf8 Class Initialized
INFO - 2016-08-10 19:20:10 --> URI Class Initialized
INFO - 2016-08-10 19:20:10 --> Router Class Initialized
INFO - 2016-08-10 19:20:10 --> Output Class Initialized
INFO - 2016-08-10 19:20:10 --> Security Class Initialized
DEBUG - 2016-08-10 19:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:20:10 --> Input Class Initialized
INFO - 2016-08-10 19:20:10 --> Language Class Initialized
INFO - 2016-08-10 19:20:10 --> Loader Class Initialized
INFO - 2016-08-10 19:20:10 --> Helper loaded: url_helper
INFO - 2016-08-10 19:20:10 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:20:10 --> Helper loaded: html_helper
INFO - 2016-08-10 19:20:10 --> Helper loaded: form_helper
INFO - 2016-08-10 19:20:10 --> Helper loaded: file_helper
INFO - 2016-08-10 19:20:10 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:20:10 --> Database Driver Class Initialized
INFO - 2016-08-10 19:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:20:10 --> Form Validation Class Initialized
INFO - 2016-08-10 19:20:10 --> Email Class Initialized
INFO - 2016-08-10 19:20:10 --> Controller Class Initialized
DEBUG - 2016-08-10 19:20:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:20:10 --> Model Class Initialized
INFO - 2016-08-10 19:20:10 --> Model Class Initialized
ERROR - 2016-08-10 19:20:10 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:20:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:20:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:20:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:20:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:20:10 --> Final output sent to browser
DEBUG - 2016-08-10 19:20:10 --> Total execution time: 0.3308
INFO - 2016-08-10 19:21:14 --> Config Class Initialized
INFO - 2016-08-10 19:21:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:14 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:14 --> URI Class Initialized
INFO - 2016-08-10 19:21:14 --> Router Class Initialized
INFO - 2016-08-10 19:21:14 --> Output Class Initialized
INFO - 2016-08-10 19:21:14 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:14 --> Input Class Initialized
INFO - 2016-08-10 19:21:14 --> Language Class Initialized
INFO - 2016-08-10 19:21:14 --> Loader Class Initialized
INFO - 2016-08-10 19:21:14 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:14 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:14 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:14 --> Email Class Initialized
INFO - 2016-08-10 19:21:14 --> Controller Class Initialized
INFO - 2016-08-10 19:21:14 --> Model Class Initialized
INFO - 2016-08-10 19:21:14 --> Config Class Initialized
INFO - 2016-08-10 19:21:14 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:14 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:14 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:14 --> URI Class Initialized
INFO - 2016-08-10 19:21:14 --> Router Class Initialized
INFO - 2016-08-10 19:21:14 --> Output Class Initialized
INFO - 2016-08-10 19:21:14 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:14 --> Input Class Initialized
INFO - 2016-08-10 19:21:14 --> Language Class Initialized
INFO - 2016-08-10 19:21:14 --> Loader Class Initialized
INFO - 2016-08-10 19:21:14 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:14 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:14 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:14 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:14 --> Email Class Initialized
INFO - 2016-08-10 19:21:14 --> Controller Class Initialized
INFO - 2016-08-10 19:21:14 --> Model Class Initialized
DEBUG - 2016-08-10 19:21:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 19:21:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 19:21:14 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:14 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:14 --> Total execution time: 0.4522
INFO - 2016-08-10 19:21:18 --> Config Class Initialized
INFO - 2016-08-10 19:21:18 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:18 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:18 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:18 --> URI Class Initialized
INFO - 2016-08-10 19:21:18 --> Router Class Initialized
INFO - 2016-08-10 19:21:18 --> Output Class Initialized
INFO - 2016-08-10 19:21:18 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:18 --> Input Class Initialized
INFO - 2016-08-10 19:21:18 --> Language Class Initialized
INFO - 2016-08-10 19:21:18 --> Loader Class Initialized
INFO - 2016-08-10 19:21:18 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:18 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:18 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:18 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:18 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:18 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:18 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:18 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:18 --> Email Class Initialized
INFO - 2016-08-10 19:21:18 --> Controller Class Initialized
INFO - 2016-08-10 19:21:18 --> Model Class Initialized
DEBUG - 2016-08-10 19:21:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 19:21:18 --> Config Class Initialized
INFO - 2016-08-10 19:21:18 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:18 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:18 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:18 --> URI Class Initialized
INFO - 2016-08-10 19:21:18 --> Router Class Initialized
INFO - 2016-08-10 19:21:18 --> Output Class Initialized
INFO - 2016-08-10 19:21:18 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:19 --> Input Class Initialized
INFO - 2016-08-10 19:21:19 --> Language Class Initialized
INFO - 2016-08-10 19:21:19 --> Loader Class Initialized
INFO - 2016-08-10 19:21:19 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:19 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:19 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:19 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:19 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:19 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:19 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:19 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:19 --> Email Class Initialized
INFO - 2016-08-10 19:21:19 --> Controller Class Initialized
DEBUG - 2016-08-10 19:21:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 19:21:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:19 --> Model Class Initialized
INFO - 2016-08-10 19:21:19 --> Model Class Initialized
INFO - 2016-08-10 19:21:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:21:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 19:21:19 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:19 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:19 --> Total execution time: 0.3861
INFO - 2016-08-10 19:21:22 --> Config Class Initialized
INFO - 2016-08-10 19:21:22 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:22 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:22 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:22 --> URI Class Initialized
INFO - 2016-08-10 19:21:22 --> Router Class Initialized
INFO - 2016-08-10 19:21:22 --> Output Class Initialized
INFO - 2016-08-10 19:21:22 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:22 --> Input Class Initialized
INFO - 2016-08-10 19:21:22 --> Language Class Initialized
INFO - 2016-08-10 19:21:22 --> Loader Class Initialized
INFO - 2016-08-10 19:21:22 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:22 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:22 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:22 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:22 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:22 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:22 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:22 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:22 --> Email Class Initialized
INFO - 2016-08-10 19:21:22 --> Controller Class Initialized
DEBUG - 2016-08-10 19:21:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:22 --> Model Class Initialized
INFO - 2016-08-10 19:21:22 --> Model Class Initialized
ERROR - 2016-08-10 19:21:22 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:21:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:21:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:21:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:22 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:22 --> Total execution time: 0.3312
INFO - 2016-08-10 19:21:45 --> Config Class Initialized
INFO - 2016-08-10 19:21:45 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:45 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:45 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:46 --> URI Class Initialized
INFO - 2016-08-10 19:21:46 --> Router Class Initialized
INFO - 2016-08-10 19:21:46 --> Output Class Initialized
INFO - 2016-08-10 19:21:46 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:46 --> Input Class Initialized
INFO - 2016-08-10 19:21:46 --> Language Class Initialized
INFO - 2016-08-10 19:21:46 --> Loader Class Initialized
INFO - 2016-08-10 19:21:46 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:46 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:46 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:46 --> Email Class Initialized
INFO - 2016-08-10 19:21:46 --> Controller Class Initialized
INFO - 2016-08-10 19:21:46 --> Model Class Initialized
INFO - 2016-08-10 19:21:46 --> Config Class Initialized
INFO - 2016-08-10 19:21:46 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:46 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:46 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:46 --> URI Class Initialized
INFO - 2016-08-10 19:21:46 --> Router Class Initialized
INFO - 2016-08-10 19:21:46 --> Output Class Initialized
INFO - 2016-08-10 19:21:46 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:46 --> Input Class Initialized
INFO - 2016-08-10 19:21:46 --> Language Class Initialized
INFO - 2016-08-10 19:21:46 --> Loader Class Initialized
INFO - 2016-08-10 19:21:46 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:46 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:46 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:46 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:46 --> Email Class Initialized
INFO - 2016-08-10 19:21:46 --> Controller Class Initialized
INFO - 2016-08-10 19:21:46 --> Model Class Initialized
DEBUG - 2016-08-10 19:21:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 19:21:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 19:21:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:46 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:46 --> Total execution time: 0.3210
INFO - 2016-08-10 19:21:50 --> Config Class Initialized
INFO - 2016-08-10 19:21:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:50 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:50 --> URI Class Initialized
INFO - 2016-08-10 19:21:50 --> Router Class Initialized
INFO - 2016-08-10 19:21:50 --> Output Class Initialized
INFO - 2016-08-10 19:21:50 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:50 --> Input Class Initialized
INFO - 2016-08-10 19:21:50 --> Language Class Initialized
INFO - 2016-08-10 19:21:50 --> Loader Class Initialized
INFO - 2016-08-10 19:21:50 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:50 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:50 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:50 --> Email Class Initialized
INFO - 2016-08-10 19:21:50 --> Controller Class Initialized
INFO - 2016-08-10 19:21:50 --> Model Class Initialized
DEBUG - 2016-08-10 19:21:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 19:21:50 --> Config Class Initialized
INFO - 2016-08-10 19:21:50 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:50 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:50 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:50 --> URI Class Initialized
INFO - 2016-08-10 19:21:50 --> Router Class Initialized
INFO - 2016-08-10 19:21:50 --> Output Class Initialized
INFO - 2016-08-10 19:21:50 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:50 --> Input Class Initialized
INFO - 2016-08-10 19:21:50 --> Language Class Initialized
INFO - 2016-08-10 19:21:50 --> Loader Class Initialized
INFO - 2016-08-10 19:21:50 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:50 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:50 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:50 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:50 --> Email Class Initialized
INFO - 2016-08-10 19:21:50 --> Controller Class Initialized
INFO - 2016-08-10 19:21:50 --> Model Class Initialized
INFO - 2016-08-10 19:21:50 --> Model Class Initialized
INFO - 2016-08-10 19:21:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:21:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/acount_state.php
INFO - 2016-08-10 19:21:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:50 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:50 --> Total execution time: 0.3341
INFO - 2016-08-10 19:21:56 --> Config Class Initialized
INFO - 2016-08-10 19:21:56 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:21:56 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:21:56 --> Utf8 Class Initialized
INFO - 2016-08-10 19:21:56 --> URI Class Initialized
INFO - 2016-08-10 19:21:56 --> Router Class Initialized
INFO - 2016-08-10 19:21:56 --> Output Class Initialized
INFO - 2016-08-10 19:21:56 --> Security Class Initialized
DEBUG - 2016-08-10 19:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:21:56 --> Input Class Initialized
INFO - 2016-08-10 19:21:56 --> Language Class Initialized
INFO - 2016-08-10 19:21:56 --> Loader Class Initialized
INFO - 2016-08-10 19:21:56 --> Helper loaded: url_helper
INFO - 2016-08-10 19:21:56 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:21:56 --> Helper loaded: html_helper
INFO - 2016-08-10 19:21:56 --> Helper loaded: form_helper
INFO - 2016-08-10 19:21:56 --> Helper loaded: file_helper
INFO - 2016-08-10 19:21:56 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:21:56 --> Database Driver Class Initialized
INFO - 2016-08-10 19:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:21:56 --> Form Validation Class Initialized
INFO - 2016-08-10 19:21:56 --> Email Class Initialized
INFO - 2016-08-10 19:21:56 --> Controller Class Initialized
DEBUG - 2016-08-10 19:21:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:21:56 --> Model Class Initialized
INFO - 2016-08-10 19:21:56 --> Model Class Initialized
ERROR - 2016-08-10 19:21:56 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 16
INFO - 2016-08-10 19:21:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:21:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:21:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:21:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:21:56 --> Final output sent to browser
DEBUG - 2016-08-10 19:21:56 --> Total execution time: 0.3568
INFO - 2016-08-10 19:22:29 --> Config Class Initialized
INFO - 2016-08-10 19:22:29 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:29 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:29 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:29 --> URI Class Initialized
INFO - 2016-08-10 19:22:29 --> Router Class Initialized
INFO - 2016-08-10 19:22:29 --> Output Class Initialized
INFO - 2016-08-10 19:22:29 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:29 --> Input Class Initialized
INFO - 2016-08-10 19:22:29 --> Language Class Initialized
INFO - 2016-08-10 19:22:29 --> Loader Class Initialized
INFO - 2016-08-10 19:22:29 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:29 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:29 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:29 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:29 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:29 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:29 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:29 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:29 --> Email Class Initialized
INFO - 2016-08-10 19:22:29 --> Controller Class Initialized
DEBUG - 2016-08-10 19:22:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:22:29 --> Model Class Initialized
INFO - 2016-08-10 19:22:29 --> Model Class Initialized
ERROR - 2016-08-10 19:22:29 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 17
INFO - 2016-08-10 19:22:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:22:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:22:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:22:29 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:22:29 --> Final output sent to browser
DEBUG - 2016-08-10 19:22:29 --> Total execution time: 0.3454
INFO - 2016-08-10 19:22:37 --> Config Class Initialized
INFO - 2016-08-10 19:22:37 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:37 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:37 --> URI Class Initialized
INFO - 2016-08-10 19:22:37 --> Router Class Initialized
INFO - 2016-08-10 19:22:37 --> Output Class Initialized
INFO - 2016-08-10 19:22:37 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:37 --> Input Class Initialized
INFO - 2016-08-10 19:22:37 --> Language Class Initialized
INFO - 2016-08-10 19:22:37 --> Loader Class Initialized
INFO - 2016-08-10 19:22:37 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:37 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:37 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:37 --> Email Class Initialized
INFO - 2016-08-10 19:22:37 --> Controller Class Initialized
INFO - 2016-08-10 19:22:37 --> Model Class Initialized
INFO - 2016-08-10 19:22:37 --> Config Class Initialized
INFO - 2016-08-10 19:22:37 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:37 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:37 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:37 --> URI Class Initialized
INFO - 2016-08-10 19:22:37 --> Router Class Initialized
INFO - 2016-08-10 19:22:37 --> Output Class Initialized
INFO - 2016-08-10 19:22:37 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:37 --> Input Class Initialized
INFO - 2016-08-10 19:22:37 --> Language Class Initialized
INFO - 2016-08-10 19:22:37 --> Loader Class Initialized
INFO - 2016-08-10 19:22:37 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:37 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:37 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:37 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:37 --> Email Class Initialized
INFO - 2016-08-10 19:22:37 --> Controller Class Initialized
INFO - 2016-08-10 19:22:37 --> Model Class Initialized
DEBUG - 2016-08-10 19:22:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:22:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-10 19:22:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:22:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-10 19:22:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:22:37 --> Final output sent to browser
DEBUG - 2016-08-10 19:22:37 --> Total execution time: 0.3244
INFO - 2016-08-10 19:22:42 --> Config Class Initialized
INFO - 2016-08-10 19:22:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:42 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:42 --> URI Class Initialized
INFO - 2016-08-10 19:22:42 --> Router Class Initialized
INFO - 2016-08-10 19:22:42 --> Output Class Initialized
INFO - 2016-08-10 19:22:42 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:42 --> Input Class Initialized
INFO - 2016-08-10 19:22:42 --> Language Class Initialized
INFO - 2016-08-10 19:22:42 --> Loader Class Initialized
INFO - 2016-08-10 19:22:42 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:42 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:42 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:42 --> Email Class Initialized
INFO - 2016-08-10 19:22:42 --> Controller Class Initialized
INFO - 2016-08-10 19:22:42 --> Model Class Initialized
DEBUG - 2016-08-10 19:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:22:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-10 19:22:42 --> Config Class Initialized
INFO - 2016-08-10 19:22:42 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:42 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:42 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:42 --> URI Class Initialized
INFO - 2016-08-10 19:22:42 --> Router Class Initialized
INFO - 2016-08-10 19:22:42 --> Output Class Initialized
INFO - 2016-08-10 19:22:42 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:42 --> Input Class Initialized
INFO - 2016-08-10 19:22:42 --> Language Class Initialized
INFO - 2016-08-10 19:22:42 --> Loader Class Initialized
INFO - 2016-08-10 19:22:42 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:42 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:42 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:42 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:42 --> Email Class Initialized
INFO - 2016-08-10 19:22:42 --> Controller Class Initialized
DEBUG - 2016-08-10 19:22:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-10 19:22:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:22:42 --> Model Class Initialized
INFO - 2016-08-10 19:22:42 --> Model Class Initialized
INFO - 2016-08-10 19:22:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:22:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:22:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-10 19:22:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:22:42 --> Final output sent to browser
DEBUG - 2016-08-10 19:22:42 --> Total execution time: 0.4027
INFO - 2016-08-10 19:22:48 --> Config Class Initialized
INFO - 2016-08-10 19:22:48 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:22:48 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:22:48 --> Utf8 Class Initialized
INFO - 2016-08-10 19:22:48 --> URI Class Initialized
INFO - 2016-08-10 19:22:48 --> Router Class Initialized
INFO - 2016-08-10 19:22:48 --> Output Class Initialized
INFO - 2016-08-10 19:22:48 --> Security Class Initialized
DEBUG - 2016-08-10 19:22:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:22:48 --> Input Class Initialized
INFO - 2016-08-10 19:22:48 --> Language Class Initialized
INFO - 2016-08-10 19:22:48 --> Loader Class Initialized
INFO - 2016-08-10 19:22:48 --> Helper loaded: url_helper
INFO - 2016-08-10 19:22:48 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:22:48 --> Helper loaded: html_helper
INFO - 2016-08-10 19:22:48 --> Helper loaded: form_helper
INFO - 2016-08-10 19:22:48 --> Helper loaded: file_helper
INFO - 2016-08-10 19:22:48 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:22:48 --> Database Driver Class Initialized
INFO - 2016-08-10 19:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:22:48 --> Form Validation Class Initialized
INFO - 2016-08-10 19:22:48 --> Email Class Initialized
INFO - 2016-08-10 19:22:48 --> Controller Class Initialized
DEBUG - 2016-08-10 19:22:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:22:48 --> Model Class Initialized
INFO - 2016-08-10 19:22:48 --> Model Class Initialized
ERROR - 2016-08-10 19:22:48 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 17
INFO - 2016-08-10 19:22:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:22:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:22:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:22:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:22:48 --> Final output sent to browser
DEBUG - 2016-08-10 19:22:48 --> Total execution time: 0.3537
INFO - 2016-08-10 19:23:27 --> Config Class Initialized
INFO - 2016-08-10 19:23:27 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:23:27 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:23:27 --> Utf8 Class Initialized
INFO - 2016-08-10 19:23:27 --> URI Class Initialized
INFO - 2016-08-10 19:23:27 --> Router Class Initialized
INFO - 2016-08-10 19:23:27 --> Output Class Initialized
INFO - 2016-08-10 19:23:28 --> Security Class Initialized
DEBUG - 2016-08-10 19:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:23:28 --> Input Class Initialized
INFO - 2016-08-10 19:23:28 --> Language Class Initialized
INFO - 2016-08-10 19:23:28 --> Loader Class Initialized
INFO - 2016-08-10 19:23:28 --> Helper loaded: url_helper
INFO - 2016-08-10 19:23:28 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:23:28 --> Helper loaded: html_helper
INFO - 2016-08-10 19:23:28 --> Helper loaded: form_helper
INFO - 2016-08-10 19:23:28 --> Helper loaded: file_helper
INFO - 2016-08-10 19:23:28 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:23:28 --> Database Driver Class Initialized
INFO - 2016-08-10 19:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:23:28 --> Form Validation Class Initialized
INFO - 2016-08-10 19:23:28 --> Email Class Initialized
INFO - 2016-08-10 19:23:28 --> Controller Class Initialized
DEBUG - 2016-08-10 19:23:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:23:28 --> Model Class Initialized
INFO - 2016-08-10 19:23:28 --> Model Class Initialized
ERROR - 2016-08-10 19:23:28 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 23
INFO - 2016-08-10 19:23:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:23:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:23:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:23:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:23:28 --> Final output sent to browser
DEBUG - 2016-08-10 19:23:28 --> Total execution time: 0.3554
INFO - 2016-08-10 19:23:32 --> Config Class Initialized
INFO - 2016-08-10 19:23:32 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:23:32 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:23:32 --> Utf8 Class Initialized
INFO - 2016-08-10 19:23:33 --> URI Class Initialized
DEBUG - 2016-08-10 19:23:33 --> No URI present. Default controller set.
INFO - 2016-08-10 19:23:33 --> Router Class Initialized
INFO - 2016-08-10 19:23:33 --> Output Class Initialized
INFO - 2016-08-10 19:23:33 --> Security Class Initialized
DEBUG - 2016-08-10 19:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:23:33 --> Input Class Initialized
INFO - 2016-08-10 19:23:33 --> Language Class Initialized
INFO - 2016-08-10 19:23:33 --> Loader Class Initialized
INFO - 2016-08-10 19:23:33 --> Helper loaded: url_helper
INFO - 2016-08-10 19:23:33 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:23:33 --> Helper loaded: html_helper
INFO - 2016-08-10 19:23:33 --> Helper loaded: form_helper
INFO - 2016-08-10 19:23:33 --> Helper loaded: file_helper
INFO - 2016-08-10 19:23:33 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:23:33 --> Database Driver Class Initialized
INFO - 2016-08-10 19:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:23:33 --> Form Validation Class Initialized
INFO - 2016-08-10 19:23:33 --> Email Class Initialized
INFO - 2016-08-10 19:23:33 --> Controller Class Initialized
INFO - 2016-08-10 19:23:33 --> Model Class Initialized
INFO - 2016-08-10 19:23:33 --> Model Class Initialized
INFO - 2016-08-10 19:23:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:23:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:23:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-10 19:23:33 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:23:33 --> Final output sent to browser
DEBUG - 2016-08-10 19:23:33 --> Total execution time: 0.3337
INFO - 2016-08-10 19:23:35 --> Config Class Initialized
INFO - 2016-08-10 19:23:35 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:23:35 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:23:35 --> Utf8 Class Initialized
INFO - 2016-08-10 19:23:35 --> URI Class Initialized
INFO - 2016-08-10 19:23:35 --> Router Class Initialized
INFO - 2016-08-10 19:23:35 --> Output Class Initialized
INFO - 2016-08-10 19:23:35 --> Security Class Initialized
DEBUG - 2016-08-10 19:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:23:35 --> Input Class Initialized
INFO - 2016-08-10 19:23:35 --> Language Class Initialized
INFO - 2016-08-10 19:23:35 --> Loader Class Initialized
INFO - 2016-08-10 19:23:35 --> Helper loaded: url_helper
INFO - 2016-08-10 19:23:35 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:23:35 --> Helper loaded: html_helper
INFO - 2016-08-10 19:23:35 --> Helper loaded: form_helper
INFO - 2016-08-10 19:23:35 --> Helper loaded: file_helper
INFO - 2016-08-10 19:23:35 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:23:35 --> Database Driver Class Initialized
INFO - 2016-08-10 19:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:23:35 --> Form Validation Class Initialized
INFO - 2016-08-10 19:23:35 --> Email Class Initialized
INFO - 2016-08-10 19:23:35 --> Controller Class Initialized
DEBUG - 2016-08-10 19:23:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:23:35 --> Model Class Initialized
INFO - 2016-08-10 19:23:35 --> Model Class Initialized
INFO - 2016-08-10 19:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-10 19:23:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:23:35 --> Final output sent to browser
DEBUG - 2016-08-10 19:23:35 --> Total execution time: 0.3768
INFO - 2016-08-10 19:23:38 --> Config Class Initialized
INFO - 2016-08-10 19:23:38 --> Hooks Class Initialized
DEBUG - 2016-08-10 19:23:38 --> UTF-8 Support Enabled
INFO - 2016-08-10 19:23:38 --> Utf8 Class Initialized
INFO - 2016-08-10 19:23:38 --> URI Class Initialized
INFO - 2016-08-10 19:23:38 --> Router Class Initialized
INFO - 2016-08-10 19:23:38 --> Output Class Initialized
INFO - 2016-08-10 19:23:38 --> Security Class Initialized
DEBUG - 2016-08-10 19:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-10 19:23:38 --> Input Class Initialized
INFO - 2016-08-10 19:23:38 --> Language Class Initialized
INFO - 2016-08-10 19:23:38 --> Loader Class Initialized
INFO - 2016-08-10 19:23:38 --> Helper loaded: url_helper
INFO - 2016-08-10 19:23:38 --> Helper loaded: utils_helper
INFO - 2016-08-10 19:23:38 --> Helper loaded: html_helper
INFO - 2016-08-10 19:23:38 --> Helper loaded: form_helper
INFO - 2016-08-10 19:23:38 --> Helper loaded: file_helper
INFO - 2016-08-10 19:23:38 --> Helper loaded: myemail_helper
INFO - 2016-08-10 19:23:38 --> Database Driver Class Initialized
INFO - 2016-08-10 19:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-10 19:23:38 --> Form Validation Class Initialized
INFO - 2016-08-10 19:23:38 --> Email Class Initialized
INFO - 2016-08-10 19:23:38 --> Controller Class Initialized
DEBUG - 2016-08-10 19:23:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-10 19:23:38 --> Model Class Initialized
INFO - 2016-08-10 19:23:38 --> Model Class Initialized
ERROR - 2016-08-10 19:23:38 --> Severity: Notice --> Undefined variable: is_admin D:\wamp\www\library.pnc.lan\application\controllers\Books.php 23
INFO - 2016-08-10 19:23:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-10 19:23:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-10 19:23:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-10 19:23:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-10 19:23:38 --> Final output sent to browser
DEBUG - 2016-08-10 19:23:38 --> Total execution time: 0.3534
