<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-07-11 01:45:36 --> Config Class Initialized
INFO - 2016-07-11 01:45:36 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:45:36 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:45:36 --> Utf8 Class Initialized
INFO - 2016-07-11 01:45:36 --> URI Class Initialized
INFO - 2016-07-11 01:45:36 --> Router Class Initialized
INFO - 2016-07-11 01:45:36 --> Output Class Initialized
INFO - 2016-07-11 01:45:36 --> Security Class Initialized
DEBUG - 2016-07-11 01:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:45:36 --> Input Class Initialized
INFO - 2016-07-11 01:45:36 --> Language Class Initialized
INFO - 2016-07-11 01:45:36 --> Loader Class Initialized
INFO - 2016-07-11 01:45:36 --> Helper loaded: url_helper
INFO - 2016-07-11 01:45:37 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:45:37 --> Helper loaded: html_helper
INFO - 2016-07-11 01:45:37 --> Helper loaded: form_helper
INFO - 2016-07-11 01:45:37 --> Helper loaded: file_helper
INFO - 2016-07-11 01:45:37 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:45:37 --> Database Driver Class Initialized
INFO - 2016-07-11 01:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:45:37 --> Form Validation Class Initialized
INFO - 2016-07-11 01:45:37 --> Email Class Initialized
INFO - 2016-07-11 01:45:37 --> Controller Class Initialized
INFO - 2016-07-11 01:45:37 --> Model Class Initialized
DEBUG - 2016-07-11 01:45:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:45:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:45:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:45:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:45:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:45:37 --> Final output sent to browser
DEBUG - 2016-07-11 01:45:37 --> Total execution time: 1.1347
INFO - 2016-07-11 01:45:39 --> Config Class Initialized
INFO - 2016-07-11 01:45:39 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:45:39 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:45:39 --> Utf8 Class Initialized
INFO - 2016-07-11 01:45:39 --> URI Class Initialized
INFO - 2016-07-11 01:45:39 --> Router Class Initialized
INFO - 2016-07-11 01:45:39 --> Output Class Initialized
INFO - 2016-07-11 01:45:39 --> Security Class Initialized
DEBUG - 2016-07-11 01:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:45:39 --> Input Class Initialized
INFO - 2016-07-11 01:45:39 --> Language Class Initialized
INFO - 2016-07-11 01:45:39 --> Loader Class Initialized
INFO - 2016-07-11 01:45:39 --> Helper loaded: url_helper
INFO - 2016-07-11 01:45:39 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:45:39 --> Helper loaded: html_helper
INFO - 2016-07-11 01:45:39 --> Helper loaded: form_helper
INFO - 2016-07-11 01:45:39 --> Helper loaded: file_helper
INFO - 2016-07-11 01:45:39 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:45:39 --> Database Driver Class Initialized
INFO - 2016-07-11 01:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:45:39 --> Form Validation Class Initialized
INFO - 2016-07-11 01:45:39 --> Email Class Initialized
INFO - 2016-07-11 01:45:39 --> Controller Class Initialized
INFO - 2016-07-11 01:45:39 --> Model Class Initialized
DEBUG - 2016-07-11 01:45:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:45:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:45:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:45:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:45:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:45:39 --> Final output sent to browser
DEBUG - 2016-07-11 01:45:39 --> Total execution time: 0.1817
INFO - 2016-07-11 01:45:41 --> Config Class Initialized
INFO - 2016-07-11 01:45:41 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:45:41 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:45:41 --> Utf8 Class Initialized
INFO - 2016-07-11 01:45:41 --> URI Class Initialized
INFO - 2016-07-11 01:45:41 --> Router Class Initialized
INFO - 2016-07-11 01:45:41 --> Output Class Initialized
INFO - 2016-07-11 01:45:41 --> Security Class Initialized
DEBUG - 2016-07-11 01:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:45:41 --> Input Class Initialized
INFO - 2016-07-11 01:45:41 --> Language Class Initialized
INFO - 2016-07-11 01:45:41 --> Loader Class Initialized
INFO - 2016-07-11 01:45:41 --> Helper loaded: url_helper
INFO - 2016-07-11 01:45:41 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:45:41 --> Helper loaded: html_helper
INFO - 2016-07-11 01:45:41 --> Helper loaded: form_helper
INFO - 2016-07-11 01:45:41 --> Helper loaded: file_helper
INFO - 2016-07-11 01:45:41 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:45:42 --> Database Driver Class Initialized
INFO - 2016-07-11 01:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:45:42 --> Form Validation Class Initialized
INFO - 2016-07-11 01:45:42 --> Email Class Initialized
INFO - 2016-07-11 01:45:42 --> Controller Class Initialized
INFO - 2016-07-11 01:45:42 --> Model Class Initialized
INFO - 2016-07-11 01:51:22 --> Config Class Initialized
INFO - 2016-07-11 01:51:22 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:51:22 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:51:22 --> Utf8 Class Initialized
INFO - 2016-07-11 01:51:22 --> URI Class Initialized
INFO - 2016-07-11 01:51:22 --> Router Class Initialized
INFO - 2016-07-11 01:51:22 --> Output Class Initialized
INFO - 2016-07-11 01:51:22 --> Security Class Initialized
DEBUG - 2016-07-11 01:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:51:22 --> Input Class Initialized
INFO - 2016-07-11 01:51:22 --> Language Class Initialized
INFO - 2016-07-11 01:51:22 --> Loader Class Initialized
INFO - 2016-07-11 01:51:22 --> Helper loaded: url_helper
INFO - 2016-07-11 01:51:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:51:22 --> Helper loaded: html_helper
INFO - 2016-07-11 01:51:22 --> Helper loaded: form_helper
INFO - 2016-07-11 01:51:22 --> Helper loaded: file_helper
INFO - 2016-07-11 01:51:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:51:22 --> Database Driver Class Initialized
INFO - 2016-07-11 01:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:51:22 --> Form Validation Class Initialized
INFO - 2016-07-11 01:51:22 --> Email Class Initialized
INFO - 2016-07-11 01:51:22 --> Controller Class Initialized
INFO - 2016-07-11 01:51:22 --> Model Class Initialized
DEBUG - 2016-07-11 01:51:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:51:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:51:22 --> Final output sent to browser
DEBUG - 2016-07-11 01:51:22 --> Total execution time: 0.2087
INFO - 2016-07-11 01:51:24 --> Config Class Initialized
INFO - 2016-07-11 01:51:24 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:51:24 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:51:24 --> Utf8 Class Initialized
INFO - 2016-07-11 01:51:24 --> URI Class Initialized
INFO - 2016-07-11 01:51:24 --> Router Class Initialized
INFO - 2016-07-11 01:51:24 --> Output Class Initialized
INFO - 2016-07-11 01:51:24 --> Security Class Initialized
DEBUG - 2016-07-11 01:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:51:24 --> Input Class Initialized
INFO - 2016-07-11 01:51:24 --> Language Class Initialized
INFO - 2016-07-11 01:51:24 --> Loader Class Initialized
INFO - 2016-07-11 01:51:24 --> Helper loaded: url_helper
INFO - 2016-07-11 01:51:24 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:51:24 --> Helper loaded: html_helper
INFO - 2016-07-11 01:51:24 --> Helper loaded: form_helper
INFO - 2016-07-11 01:51:24 --> Helper loaded: file_helper
INFO - 2016-07-11 01:51:24 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:51:24 --> Database Driver Class Initialized
INFO - 2016-07-11 01:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:51:24 --> Form Validation Class Initialized
INFO - 2016-07-11 01:51:24 --> Email Class Initialized
INFO - 2016-07-11 01:51:24 --> Controller Class Initialized
INFO - 2016-07-11 01:51:24 --> Model Class Initialized
DEBUG - 2016-07-11 01:51:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:51:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:51:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:51:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:51:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:51:24 --> Final output sent to browser
DEBUG - 2016-07-11 01:51:24 --> Total execution time: 0.1976
INFO - 2016-07-11 01:51:25 --> Config Class Initialized
INFO - 2016-07-11 01:51:25 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:51:25 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:51:25 --> Utf8 Class Initialized
INFO - 2016-07-11 01:51:25 --> URI Class Initialized
INFO - 2016-07-11 01:51:25 --> Router Class Initialized
INFO - 2016-07-11 01:51:25 --> Output Class Initialized
INFO - 2016-07-11 01:51:25 --> Security Class Initialized
DEBUG - 2016-07-11 01:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:51:25 --> Input Class Initialized
INFO - 2016-07-11 01:51:25 --> Language Class Initialized
INFO - 2016-07-11 01:51:26 --> Loader Class Initialized
INFO - 2016-07-11 01:51:26 --> Helper loaded: url_helper
INFO - 2016-07-11 01:51:26 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:51:26 --> Helper loaded: html_helper
INFO - 2016-07-11 01:51:26 --> Helper loaded: form_helper
INFO - 2016-07-11 01:51:26 --> Helper loaded: file_helper
INFO - 2016-07-11 01:51:26 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:51:26 --> Database Driver Class Initialized
INFO - 2016-07-11 01:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:51:26 --> Form Validation Class Initialized
INFO - 2016-07-11 01:51:26 --> Email Class Initialized
INFO - 2016-07-11 01:51:26 --> Controller Class Initialized
INFO - 2016-07-11 01:51:26 --> Model Class Initialized
INFO - 2016-07-11 01:51:56 --> Config Class Initialized
INFO - 2016-07-11 01:51:56 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:51:56 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:51:56 --> Utf8 Class Initialized
INFO - 2016-07-11 01:51:56 --> URI Class Initialized
INFO - 2016-07-11 01:51:56 --> Router Class Initialized
INFO - 2016-07-11 01:51:56 --> Output Class Initialized
INFO - 2016-07-11 01:51:56 --> Security Class Initialized
DEBUG - 2016-07-11 01:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:51:56 --> Input Class Initialized
INFO - 2016-07-11 01:51:56 --> Language Class Initialized
INFO - 2016-07-11 01:51:56 --> Loader Class Initialized
INFO - 2016-07-11 01:51:56 --> Helper loaded: url_helper
INFO - 2016-07-11 01:51:56 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:51:56 --> Helper loaded: html_helper
INFO - 2016-07-11 01:51:56 --> Helper loaded: form_helper
INFO - 2016-07-11 01:51:56 --> Helper loaded: file_helper
INFO - 2016-07-11 01:51:56 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:51:56 --> Database Driver Class Initialized
INFO - 2016-07-11 01:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:51:56 --> Form Validation Class Initialized
INFO - 2016-07-11 01:51:56 --> Email Class Initialized
INFO - 2016-07-11 01:51:56 --> Controller Class Initialized
INFO - 2016-07-11 01:51:56 --> Model Class Initialized
ERROR - 2016-07-11 01:51:56 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 01:52:21 --> Config Class Initialized
INFO - 2016-07-11 01:52:21 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:52:21 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:52:21 --> Utf8 Class Initialized
INFO - 2016-07-11 01:52:21 --> URI Class Initialized
INFO - 2016-07-11 01:52:21 --> Router Class Initialized
INFO - 2016-07-11 01:52:21 --> Output Class Initialized
INFO - 2016-07-11 01:52:21 --> Security Class Initialized
DEBUG - 2016-07-11 01:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:52:21 --> Input Class Initialized
INFO - 2016-07-11 01:52:21 --> Language Class Initialized
INFO - 2016-07-11 01:52:21 --> Loader Class Initialized
INFO - 2016-07-11 01:52:21 --> Helper loaded: url_helper
INFO - 2016-07-11 01:52:21 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:52:21 --> Helper loaded: html_helper
INFO - 2016-07-11 01:52:21 --> Helper loaded: form_helper
INFO - 2016-07-11 01:52:21 --> Helper loaded: file_helper
INFO - 2016-07-11 01:52:21 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:52:21 --> Database Driver Class Initialized
INFO - 2016-07-11 01:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:52:21 --> Form Validation Class Initialized
INFO - 2016-07-11 01:52:21 --> Email Class Initialized
INFO - 2016-07-11 01:52:21 --> Controller Class Initialized
INFO - 2016-07-11 01:52:21 --> Model Class Initialized
DEBUG - 2016-07-11 01:52:21 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:52:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:52:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:52:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:52:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:52:21 --> Final output sent to browser
DEBUG - 2016-07-11 01:52:21 --> Total execution time: 0.2172
INFO - 2016-07-11 01:52:22 --> Config Class Initialized
INFO - 2016-07-11 01:52:22 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:52:22 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:52:22 --> Utf8 Class Initialized
INFO - 2016-07-11 01:52:22 --> URI Class Initialized
INFO - 2016-07-11 01:52:22 --> Router Class Initialized
INFO - 2016-07-11 01:52:22 --> Output Class Initialized
INFO - 2016-07-11 01:52:22 --> Security Class Initialized
DEBUG - 2016-07-11 01:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:52:22 --> Input Class Initialized
INFO - 2016-07-11 01:52:22 --> Language Class Initialized
INFO - 2016-07-11 01:52:22 --> Loader Class Initialized
INFO - 2016-07-11 01:52:22 --> Helper loaded: url_helper
INFO - 2016-07-11 01:52:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:52:22 --> Helper loaded: html_helper
INFO - 2016-07-11 01:52:22 --> Helper loaded: form_helper
INFO - 2016-07-11 01:52:22 --> Helper loaded: file_helper
INFO - 2016-07-11 01:52:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:52:22 --> Database Driver Class Initialized
INFO - 2016-07-11 01:52:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:52:23 --> Form Validation Class Initialized
INFO - 2016-07-11 01:52:23 --> Email Class Initialized
INFO - 2016-07-11 01:52:23 --> Controller Class Initialized
INFO - 2016-07-11 01:52:23 --> Model Class Initialized
DEBUG - 2016-07-11 01:52:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:52:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:52:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:52:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:52:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:52:23 --> Final output sent to browser
DEBUG - 2016-07-11 01:52:23 --> Total execution time: 0.2157
INFO - 2016-07-11 01:52:25 --> Config Class Initialized
INFO - 2016-07-11 01:52:25 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:52:25 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:52:25 --> Utf8 Class Initialized
INFO - 2016-07-11 01:52:25 --> URI Class Initialized
INFO - 2016-07-11 01:52:25 --> Router Class Initialized
INFO - 2016-07-11 01:52:25 --> Output Class Initialized
INFO - 2016-07-11 01:52:25 --> Security Class Initialized
DEBUG - 2016-07-11 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:52:25 --> Input Class Initialized
INFO - 2016-07-11 01:52:25 --> Language Class Initialized
INFO - 2016-07-11 01:52:25 --> Loader Class Initialized
INFO - 2016-07-11 01:52:25 --> Helper loaded: url_helper
INFO - 2016-07-11 01:52:25 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:52:25 --> Helper loaded: html_helper
INFO - 2016-07-11 01:52:25 --> Helper loaded: form_helper
INFO - 2016-07-11 01:52:25 --> Helper loaded: file_helper
INFO - 2016-07-11 01:52:25 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:52:25 --> Database Driver Class Initialized
INFO - 2016-07-11 01:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:52:25 --> Form Validation Class Initialized
INFO - 2016-07-11 01:52:25 --> Email Class Initialized
INFO - 2016-07-11 01:52:25 --> Controller Class Initialized
INFO - 2016-07-11 01:52:25 --> Model Class Initialized
INFO - 2016-07-11 01:53:53 --> Config Class Initialized
INFO - 2016-07-11 01:53:53 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:53:53 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:53:53 --> Utf8 Class Initialized
INFO - 2016-07-11 01:53:53 --> URI Class Initialized
DEBUG - 2016-07-11 01:53:53 --> No URI present. Default controller set.
INFO - 2016-07-11 01:53:53 --> Router Class Initialized
INFO - 2016-07-11 01:53:53 --> Output Class Initialized
INFO - 2016-07-11 01:53:53 --> Security Class Initialized
DEBUG - 2016-07-11 01:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:53:53 --> Input Class Initialized
INFO - 2016-07-11 01:53:53 --> Language Class Initialized
INFO - 2016-07-11 01:53:53 --> Loader Class Initialized
INFO - 2016-07-11 01:53:53 --> Helper loaded: url_helper
INFO - 2016-07-11 01:53:53 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:53:53 --> Helper loaded: html_helper
INFO - 2016-07-11 01:53:53 --> Helper loaded: form_helper
INFO - 2016-07-11 01:53:53 --> Helper loaded: file_helper
INFO - 2016-07-11 01:53:53 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:53:53 --> Database Driver Class Initialized
INFO - 2016-07-11 01:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:53:53 --> Form Validation Class Initialized
INFO - 2016-07-11 01:53:53 --> Email Class Initialized
INFO - 2016-07-11 01:53:53 --> Controller Class Initialized
INFO - 2016-07-11 01:55:23 --> Config Class Initialized
INFO - 2016-07-11 01:55:23 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:55:23 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:55:23 --> Utf8 Class Initialized
INFO - 2016-07-11 01:55:23 --> URI Class Initialized
INFO - 2016-07-11 01:55:23 --> Router Class Initialized
INFO - 2016-07-11 01:55:23 --> Output Class Initialized
INFO - 2016-07-11 01:55:23 --> Security Class Initialized
DEBUG - 2016-07-11 01:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:55:23 --> Input Class Initialized
INFO - 2016-07-11 01:55:23 --> Language Class Initialized
INFO - 2016-07-11 01:55:23 --> Loader Class Initialized
INFO - 2016-07-11 01:55:23 --> Helper loaded: url_helper
INFO - 2016-07-11 01:55:23 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:55:23 --> Helper loaded: html_helper
INFO - 2016-07-11 01:55:23 --> Helper loaded: form_helper
INFO - 2016-07-11 01:55:23 --> Helper loaded: file_helper
INFO - 2016-07-11 01:55:23 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:55:23 --> Database Driver Class Initialized
INFO - 2016-07-11 01:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:55:23 --> Form Validation Class Initialized
INFO - 2016-07-11 01:55:23 --> Email Class Initialized
INFO - 2016-07-11 01:55:23 --> Controller Class Initialized
INFO - 2016-07-11 01:55:23 --> Model Class Initialized
DEBUG - 2016-07-11 01:55:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 01:55:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 01:55:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 01:55:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 01:55:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 01:55:23 --> Final output sent to browser
DEBUG - 2016-07-11 01:55:23 --> Total execution time: 0.2092
INFO - 2016-07-11 01:55:25 --> Config Class Initialized
INFO - 2016-07-11 01:55:25 --> Hooks Class Initialized
DEBUG - 2016-07-11 01:55:25 --> UTF-8 Support Enabled
INFO - 2016-07-11 01:55:25 --> Utf8 Class Initialized
INFO - 2016-07-11 01:55:25 --> URI Class Initialized
INFO - 2016-07-11 01:55:25 --> Router Class Initialized
INFO - 2016-07-11 01:55:25 --> Output Class Initialized
INFO - 2016-07-11 01:55:25 --> Security Class Initialized
DEBUG - 2016-07-11 01:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 01:55:25 --> Input Class Initialized
INFO - 2016-07-11 01:55:25 --> Language Class Initialized
INFO - 2016-07-11 01:55:25 --> Loader Class Initialized
INFO - 2016-07-11 01:55:25 --> Helper loaded: url_helper
INFO - 2016-07-11 01:55:25 --> Helper loaded: utils_helper
INFO - 2016-07-11 01:55:25 --> Helper loaded: html_helper
INFO - 2016-07-11 01:55:25 --> Helper loaded: form_helper
INFO - 2016-07-11 01:55:25 --> Helper loaded: file_helper
INFO - 2016-07-11 01:55:25 --> Helper loaded: myemail_helper
INFO - 2016-07-11 01:55:25 --> Database Driver Class Initialized
INFO - 2016-07-11 01:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 01:55:25 --> Form Validation Class Initialized
INFO - 2016-07-11 01:55:25 --> Email Class Initialized
INFO - 2016-07-11 01:55:25 --> Controller Class Initialized
INFO - 2016-07-11 01:55:25 --> Model Class Initialized
INFO - 2016-07-11 03:01:39 --> Config Class Initialized
INFO - 2016-07-11 03:01:39 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:01:39 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:01:39 --> Utf8 Class Initialized
INFO - 2016-07-11 03:01:39 --> URI Class Initialized
INFO - 2016-07-11 03:01:39 --> Router Class Initialized
INFO - 2016-07-11 03:01:39 --> Output Class Initialized
INFO - 2016-07-11 03:01:39 --> Security Class Initialized
DEBUG - 2016-07-11 03:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:01:39 --> Input Class Initialized
INFO - 2016-07-11 03:01:39 --> Language Class Initialized
INFO - 2016-07-11 03:01:39 --> Loader Class Initialized
INFO - 2016-07-11 03:01:39 --> Helper loaded: url_helper
INFO - 2016-07-11 03:01:39 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:01:39 --> Helper loaded: html_helper
INFO - 2016-07-11 03:01:39 --> Helper loaded: form_helper
INFO - 2016-07-11 03:01:39 --> Helper loaded: file_helper
INFO - 2016-07-11 03:01:39 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:01:39 --> Database Driver Class Initialized
INFO - 2016-07-11 03:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:01:39 --> Form Validation Class Initialized
INFO - 2016-07-11 03:01:39 --> Email Class Initialized
INFO - 2016-07-11 03:01:39 --> Controller Class Initialized
INFO - 2016-07-11 03:01:39 --> Model Class Initialized
DEBUG - 2016-07-11 03:01:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 03:01:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 03:01:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:01:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 03:01:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:01:39 --> Final output sent to browser
DEBUG - 2016-07-11 03:01:39 --> Total execution time: 0.2612
INFO - 2016-07-11 03:01:44 --> Config Class Initialized
INFO - 2016-07-11 03:01:44 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:01:44 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:01:44 --> Utf8 Class Initialized
INFO - 2016-07-11 03:01:44 --> URI Class Initialized
INFO - 2016-07-11 03:01:44 --> Router Class Initialized
INFO - 2016-07-11 03:01:44 --> Output Class Initialized
INFO - 2016-07-11 03:01:44 --> Security Class Initialized
DEBUG - 2016-07-11 03:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:01:44 --> Input Class Initialized
INFO - 2016-07-11 03:01:44 --> Language Class Initialized
INFO - 2016-07-11 03:01:44 --> Loader Class Initialized
INFO - 2016-07-11 03:01:44 --> Helper loaded: url_helper
INFO - 2016-07-11 03:01:44 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:01:44 --> Helper loaded: html_helper
INFO - 2016-07-11 03:01:44 --> Helper loaded: form_helper
INFO - 2016-07-11 03:01:44 --> Helper loaded: file_helper
INFO - 2016-07-11 03:01:44 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:01:44 --> Database Driver Class Initialized
INFO - 2016-07-11 03:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:01:45 --> Form Validation Class Initialized
INFO - 2016-07-11 03:01:45 --> Email Class Initialized
INFO - 2016-07-11 03:01:45 --> Controller Class Initialized
INFO - 2016-07-11 03:01:45 --> Model Class Initialized
DEBUG - 2016-07-11 03:01:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 03:01:45 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-11 03:02:26 --> Config Class Initialized
INFO - 2016-07-11 03:02:26 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:02:26 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:02:26 --> Utf8 Class Initialized
INFO - 2016-07-11 03:02:26 --> URI Class Initialized
INFO - 2016-07-11 03:02:26 --> Router Class Initialized
INFO - 2016-07-11 03:02:26 --> Output Class Initialized
INFO - 2016-07-11 03:02:26 --> Security Class Initialized
DEBUG - 2016-07-11 03:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:02:26 --> Input Class Initialized
INFO - 2016-07-11 03:02:26 --> Language Class Initialized
INFO - 2016-07-11 03:02:26 --> Loader Class Initialized
INFO - 2016-07-11 03:02:26 --> Helper loaded: url_helper
INFO - 2016-07-11 03:02:26 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:02:26 --> Helper loaded: html_helper
INFO - 2016-07-11 03:02:26 --> Helper loaded: form_helper
INFO - 2016-07-11 03:02:26 --> Helper loaded: file_helper
INFO - 2016-07-11 03:02:26 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:02:26 --> Database Driver Class Initialized
INFO - 2016-07-11 03:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:02:26 --> Form Validation Class Initialized
INFO - 2016-07-11 03:02:26 --> Email Class Initialized
INFO - 2016-07-11 03:02:26 --> Controller Class Initialized
INFO - 2016-07-11 03:02:26 --> Model Class Initialized
DEBUG - 2016-07-11 03:02:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 03:02:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 03:02:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:02:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 03:02:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:02:26 --> Final output sent to browser
DEBUG - 2016-07-11 03:02:26 --> Total execution time: 0.2301
INFO - 2016-07-11 03:02:32 --> Config Class Initialized
INFO - 2016-07-11 03:02:32 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:02:32 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:02:32 --> Utf8 Class Initialized
INFO - 2016-07-11 03:02:32 --> URI Class Initialized
INFO - 2016-07-11 03:02:32 --> Router Class Initialized
INFO - 2016-07-11 03:02:32 --> Output Class Initialized
INFO - 2016-07-11 03:02:32 --> Security Class Initialized
DEBUG - 2016-07-11 03:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:02:32 --> Input Class Initialized
INFO - 2016-07-11 03:02:32 --> Language Class Initialized
INFO - 2016-07-11 03:02:32 --> Loader Class Initialized
INFO - 2016-07-11 03:02:32 --> Helper loaded: url_helper
INFO - 2016-07-11 03:02:32 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:02:32 --> Helper loaded: html_helper
INFO - 2016-07-11 03:02:32 --> Helper loaded: form_helper
INFO - 2016-07-11 03:02:32 --> Helper loaded: file_helper
INFO - 2016-07-11 03:02:32 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:02:32 --> Database Driver Class Initialized
INFO - 2016-07-11 03:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:02:32 --> Form Validation Class Initialized
INFO - 2016-07-11 03:02:32 --> Email Class Initialized
INFO - 2016-07-11 03:02:32 --> Controller Class Initialized
INFO - 2016-07-11 03:02:32 --> Model Class Initialized
DEBUG - 2016-07-11 03:02:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 03:02:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-11 03:03:35 --> Config Class Initialized
INFO - 2016-07-11 03:03:35 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:03:35 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:03:35 --> Utf8 Class Initialized
INFO - 2016-07-11 03:03:35 --> URI Class Initialized
DEBUG - 2016-07-11 03:03:35 --> No URI present. Default controller set.
INFO - 2016-07-11 03:03:35 --> Router Class Initialized
INFO - 2016-07-11 03:03:35 --> Output Class Initialized
INFO - 2016-07-11 03:03:35 --> Security Class Initialized
DEBUG - 2016-07-11 03:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:03:35 --> Input Class Initialized
INFO - 2016-07-11 03:03:35 --> Language Class Initialized
INFO - 2016-07-11 03:03:35 --> Loader Class Initialized
INFO - 2016-07-11 03:03:35 --> Helper loaded: url_helper
INFO - 2016-07-11 03:03:35 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:03:35 --> Helper loaded: html_helper
INFO - 2016-07-11 03:03:35 --> Helper loaded: form_helper
INFO - 2016-07-11 03:03:35 --> Helper loaded: file_helper
INFO - 2016-07-11 03:03:35 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:03:35 --> Database Driver Class Initialized
INFO - 2016-07-11 03:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:03:35 --> Form Validation Class Initialized
INFO - 2016-07-11 03:03:35 --> Email Class Initialized
INFO - 2016-07-11 03:03:35 --> Controller Class Initialized
INFO - 2016-07-11 03:03:35 --> Model Class Initialized
INFO - 2016-07-11 03:03:35 --> Model Class Initialized
INFO - 2016-07-11 03:03:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:03:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 03:03:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-11 03:03:36 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:03:36 --> Final output sent to browser
DEBUG - 2016-07-11 03:03:36 --> Total execution time: 0.3943
INFO - 2016-07-11 03:03:42 --> Config Class Initialized
INFO - 2016-07-11 03:03:42 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:03:42 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:03:42 --> Utf8 Class Initialized
INFO - 2016-07-11 03:03:42 --> URI Class Initialized
INFO - 2016-07-11 03:03:42 --> Router Class Initialized
INFO - 2016-07-11 03:03:42 --> Output Class Initialized
INFO - 2016-07-11 03:03:42 --> Security Class Initialized
DEBUG - 2016-07-11 03:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:03:42 --> Input Class Initialized
INFO - 2016-07-11 03:03:42 --> Language Class Initialized
INFO - 2016-07-11 03:03:42 --> Loader Class Initialized
INFO - 2016-07-11 03:03:42 --> Helper loaded: url_helper
INFO - 2016-07-11 03:03:42 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:03:42 --> Helper loaded: html_helper
INFO - 2016-07-11 03:03:42 --> Helper loaded: form_helper
INFO - 2016-07-11 03:03:42 --> Helper loaded: file_helper
INFO - 2016-07-11 03:03:42 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:03:42 --> Database Driver Class Initialized
INFO - 2016-07-11 03:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:03:42 --> Form Validation Class Initialized
INFO - 2016-07-11 03:03:42 --> Email Class Initialized
INFO - 2016-07-11 03:03:42 --> Controller Class Initialized
INFO - 2016-07-11 03:03:42 --> Model Class Initialized
INFO - 2016-07-11 03:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:03:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 03:03:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-07-11 03:03:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:03:43 --> Final output sent to browser
DEBUG - 2016-07-11 03:03:43 --> Total execution time: 0.5703
INFO - 2016-07-11 03:03:46 --> Config Class Initialized
INFO - 2016-07-11 03:03:46 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:03:46 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:03:46 --> Utf8 Class Initialized
INFO - 2016-07-11 03:03:46 --> URI Class Initialized
INFO - 2016-07-11 03:03:46 --> Router Class Initialized
INFO - 2016-07-11 03:03:46 --> Output Class Initialized
INFO - 2016-07-11 03:03:46 --> Security Class Initialized
DEBUG - 2016-07-11 03:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:03:46 --> Input Class Initialized
INFO - 2016-07-11 03:03:46 --> Language Class Initialized
INFO - 2016-07-11 03:03:46 --> Loader Class Initialized
INFO - 2016-07-11 03:03:46 --> Helper loaded: url_helper
INFO - 2016-07-11 03:03:46 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:03:46 --> Helper loaded: html_helper
INFO - 2016-07-11 03:03:46 --> Helper loaded: form_helper
INFO - 2016-07-11 03:03:46 --> Helper loaded: file_helper
INFO - 2016-07-11 03:03:46 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:03:46 --> Database Driver Class Initialized
INFO - 2016-07-11 03:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:03:46 --> Form Validation Class Initialized
INFO - 2016-07-11 03:03:46 --> Email Class Initialized
INFO - 2016-07-11 03:03:46 --> Controller Class Initialized
INFO - 2016-07-11 03:03:46 --> Model Class Initialized
DEBUG - 2016-07-11 03:03:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 03:03:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:03:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 03:03:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/edit.php
INFO - 2016-07-11 03:03:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:03:47 --> Final output sent to browser
DEBUG - 2016-07-11 03:03:47 --> Total execution time: 0.3791
INFO - 2016-07-11 03:04:50 --> Config Class Initialized
INFO - 2016-07-11 03:04:50 --> Hooks Class Initialized
DEBUG - 2016-07-11 03:04:50 --> UTF-8 Support Enabled
INFO - 2016-07-11 03:04:50 --> Utf8 Class Initialized
INFO - 2016-07-11 03:04:50 --> URI Class Initialized
INFO - 2016-07-11 03:04:50 --> Router Class Initialized
INFO - 2016-07-11 03:04:50 --> Output Class Initialized
INFO - 2016-07-11 03:04:50 --> Security Class Initialized
DEBUG - 2016-07-11 03:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 03:04:50 --> Input Class Initialized
INFO - 2016-07-11 03:04:50 --> Language Class Initialized
INFO - 2016-07-11 03:04:50 --> Loader Class Initialized
INFO - 2016-07-11 03:04:50 --> Helper loaded: url_helper
INFO - 2016-07-11 03:04:50 --> Helper loaded: utils_helper
INFO - 2016-07-11 03:04:50 --> Helper loaded: html_helper
INFO - 2016-07-11 03:04:50 --> Helper loaded: form_helper
INFO - 2016-07-11 03:04:50 --> Helper loaded: file_helper
INFO - 2016-07-11 03:04:50 --> Helper loaded: myemail_helper
INFO - 2016-07-11 03:04:50 --> Database Driver Class Initialized
INFO - 2016-07-11 03:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 03:04:50 --> Form Validation Class Initialized
INFO - 2016-07-11 03:04:50 --> Email Class Initialized
INFO - 2016-07-11 03:04:50 --> Controller Class Initialized
INFO - 2016-07-11 03:04:50 --> Model Class Initialized
INFO - 2016-07-11 03:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 03:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 03:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-07-11 03:04:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 03:04:50 --> Final output sent to browser
DEBUG - 2016-07-11 03:04:50 --> Total execution time: 0.2440
INFO - 2016-07-11 04:45:17 --> Config Class Initialized
INFO - 2016-07-11 04:45:17 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:17 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:17 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:17 --> URI Class Initialized
DEBUG - 2016-07-11 04:45:17 --> No URI present. Default controller set.
INFO - 2016-07-11 04:45:17 --> Router Class Initialized
INFO - 2016-07-11 04:45:17 --> Output Class Initialized
INFO - 2016-07-11 04:45:17 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:17 --> Input Class Initialized
INFO - 2016-07-11 04:45:17 --> Language Class Initialized
INFO - 2016-07-11 04:45:17 --> Loader Class Initialized
INFO - 2016-07-11 04:45:17 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:17 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:17 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:17 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:17 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:17 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:17 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:17 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:17 --> Email Class Initialized
INFO - 2016-07-11 04:45:17 --> Controller Class Initialized
INFO - 2016-07-11 04:45:17 --> Model Class Initialized
INFO - 2016-07-11 04:45:17 --> Model Class Initialized
INFO - 2016-07-11 04:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 04:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 04:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-07-11 04:45:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 04:45:17 --> Final output sent to browser
DEBUG - 2016-07-11 04:45:17 --> Total execution time: 0.2294
INFO - 2016-07-11 04:45:21 --> Config Class Initialized
INFO - 2016-07-11 04:45:21 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:21 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:21 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:21 --> URI Class Initialized
INFO - 2016-07-11 04:45:21 --> Router Class Initialized
INFO - 2016-07-11 04:45:21 --> Output Class Initialized
INFO - 2016-07-11 04:45:21 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:21 --> Input Class Initialized
INFO - 2016-07-11 04:45:21 --> Language Class Initialized
INFO - 2016-07-11 04:45:21 --> Loader Class Initialized
INFO - 2016-07-11 04:45:21 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:21 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:21 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:21 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:21 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:21 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:21 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:21 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:21 --> Email Class Initialized
INFO - 2016-07-11 04:45:21 --> Controller Class Initialized
INFO - 2016-07-11 04:45:21 --> Model Class Initialized
INFO - 2016-07-11 04:45:21 --> Config Class Initialized
INFO - 2016-07-11 04:45:21 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:21 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:21 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:21 --> URI Class Initialized
INFO - 2016-07-11 04:45:21 --> Router Class Initialized
INFO - 2016-07-11 04:45:21 --> Output Class Initialized
INFO - 2016-07-11 04:45:21 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:22 --> Input Class Initialized
INFO - 2016-07-11 04:45:22 --> Language Class Initialized
INFO - 2016-07-11 04:45:22 --> Loader Class Initialized
INFO - 2016-07-11 04:45:22 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:22 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:22 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:22 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:22 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:22 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:22 --> Email Class Initialized
INFO - 2016-07-11 04:45:22 --> Controller Class Initialized
INFO - 2016-07-11 04:45:22 --> Model Class Initialized
DEBUG - 2016-07-11 04:45:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 04:45:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 04:45:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 04:45:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 04:45:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 04:45:22 --> Final output sent to browser
DEBUG - 2016-07-11 04:45:22 --> Total execution time: 0.2169
INFO - 2016-07-11 04:45:25 --> Config Class Initialized
INFO - 2016-07-11 04:45:25 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:25 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:25 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:25 --> URI Class Initialized
INFO - 2016-07-11 04:45:25 --> Router Class Initialized
INFO - 2016-07-11 04:45:25 --> Output Class Initialized
INFO - 2016-07-11 04:45:25 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:25 --> Input Class Initialized
INFO - 2016-07-11 04:45:25 --> Language Class Initialized
INFO - 2016-07-11 04:45:25 --> Loader Class Initialized
INFO - 2016-07-11 04:45:25 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:25 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:25 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:25 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:25 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:25 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:25 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:25 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:25 --> Email Class Initialized
INFO - 2016-07-11 04:45:25 --> Controller Class Initialized
INFO - 2016-07-11 04:45:25 --> Model Class Initialized
DEBUG - 2016-07-11 04:45:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 04:45:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-11 04:45:26 --> Config Class Initialized
INFO - 2016-07-11 04:45:26 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:26 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:26 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:26 --> URI Class Initialized
INFO - 2016-07-11 04:45:26 --> Router Class Initialized
INFO - 2016-07-11 04:45:26 --> Output Class Initialized
INFO - 2016-07-11 04:45:26 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:26 --> Input Class Initialized
INFO - 2016-07-11 04:45:26 --> Language Class Initialized
INFO - 2016-07-11 04:45:26 --> Loader Class Initialized
INFO - 2016-07-11 04:45:26 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:26 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:26 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:26 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:26 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:26 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:26 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:26 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:26 --> Email Class Initialized
INFO - 2016-07-11 04:45:26 --> Controller Class Initialized
DEBUG - 2016-07-11 04:45:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-07-11 04:45:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 04:45:26 --> Model Class Initialized
INFO - 2016-07-11 04:45:26 --> Model Class Initialized
INFO - 2016-07-11 04:45:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 04:45:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-07-11 04:45:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-07-11 04:45:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 04:45:26 --> Final output sent to browser
DEBUG - 2016-07-11 04:45:26 --> Total execution time: 0.6369
INFO - 2016-07-11 04:45:29 --> Config Class Initialized
INFO - 2016-07-11 04:45:29 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:29 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:29 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:29 --> URI Class Initialized
INFO - 2016-07-11 04:45:29 --> Router Class Initialized
INFO - 2016-07-11 04:45:30 --> Output Class Initialized
INFO - 2016-07-11 04:45:30 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:30 --> Input Class Initialized
INFO - 2016-07-11 04:45:30 --> Language Class Initialized
INFO - 2016-07-11 04:45:30 --> Loader Class Initialized
INFO - 2016-07-11 04:45:30 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:30 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:30 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:30 --> Email Class Initialized
INFO - 2016-07-11 04:45:30 --> Controller Class Initialized
INFO - 2016-07-11 04:45:30 --> Model Class Initialized
INFO - 2016-07-11 04:45:30 --> Config Class Initialized
INFO - 2016-07-11 04:45:30 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:30 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:30 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:30 --> URI Class Initialized
INFO - 2016-07-11 04:45:30 --> Router Class Initialized
INFO - 2016-07-11 04:45:30 --> Output Class Initialized
INFO - 2016-07-11 04:45:30 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:30 --> Input Class Initialized
INFO - 2016-07-11 04:45:30 --> Language Class Initialized
INFO - 2016-07-11 04:45:30 --> Loader Class Initialized
INFO - 2016-07-11 04:45:30 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:30 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:30 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:30 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:30 --> Email Class Initialized
INFO - 2016-07-11 04:45:30 --> Controller Class Initialized
INFO - 2016-07-11 04:45:30 --> Model Class Initialized
DEBUG - 2016-07-11 04:45:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 04:45:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 04:45:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 04:45:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 04:45:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 04:45:30 --> Final output sent to browser
DEBUG - 2016-07-11 04:45:30 --> Total execution time: 0.2689
INFO - 2016-07-11 04:45:31 --> Config Class Initialized
INFO - 2016-07-11 04:45:31 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:45:31 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:45:31 --> Utf8 Class Initialized
INFO - 2016-07-11 04:45:31 --> URI Class Initialized
INFO - 2016-07-11 04:45:31 --> Router Class Initialized
INFO - 2016-07-11 04:45:31 --> Output Class Initialized
INFO - 2016-07-11 04:45:31 --> Security Class Initialized
DEBUG - 2016-07-11 04:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:45:31 --> Input Class Initialized
INFO - 2016-07-11 04:45:31 --> Language Class Initialized
INFO - 2016-07-11 04:45:31 --> Loader Class Initialized
INFO - 2016-07-11 04:45:31 --> Helper loaded: url_helper
INFO - 2016-07-11 04:45:31 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:45:31 --> Helper loaded: html_helper
INFO - 2016-07-11 04:45:31 --> Helper loaded: form_helper
INFO - 2016-07-11 04:45:31 --> Helper loaded: file_helper
INFO - 2016-07-11 04:45:31 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:45:31 --> Database Driver Class Initialized
INFO - 2016-07-11 04:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:45:31 --> Form Validation Class Initialized
INFO - 2016-07-11 04:45:31 --> Email Class Initialized
INFO - 2016-07-11 04:45:31 --> Controller Class Initialized
INFO - 2016-07-11 04:45:31 --> Model Class Initialized
INFO - 2016-07-11 04:46:03 --> Config Class Initialized
INFO - 2016-07-11 04:46:03 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:46:03 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:46:03 --> Utf8 Class Initialized
INFO - 2016-07-11 04:46:03 --> URI Class Initialized
INFO - 2016-07-11 04:46:03 --> Router Class Initialized
INFO - 2016-07-11 04:46:03 --> Output Class Initialized
INFO - 2016-07-11 04:46:03 --> Security Class Initialized
DEBUG - 2016-07-11 04:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:46:03 --> Input Class Initialized
INFO - 2016-07-11 04:46:03 --> Language Class Initialized
INFO - 2016-07-11 04:46:03 --> Loader Class Initialized
INFO - 2016-07-11 04:46:03 --> Helper loaded: url_helper
INFO - 2016-07-11 04:46:03 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:46:03 --> Helper loaded: html_helper
INFO - 2016-07-11 04:46:03 --> Helper loaded: form_helper
INFO - 2016-07-11 04:46:03 --> Helper loaded: file_helper
INFO - 2016-07-11 04:46:03 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:46:03 --> Database Driver Class Initialized
INFO - 2016-07-11 04:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:46:03 --> Form Validation Class Initialized
INFO - 2016-07-11 04:46:03 --> Email Class Initialized
INFO - 2016-07-11 04:46:03 --> Controller Class Initialized
INFO - 2016-07-11 04:46:03 --> Model Class Initialized
DEBUG - 2016-07-11 04:46:03 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 04:46:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 04:46:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 04:46:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 04:46:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 04:46:03 --> Final output sent to browser
DEBUG - 2016-07-11 04:46:03 --> Total execution time: 0.2523
INFO - 2016-07-11 04:46:05 --> Config Class Initialized
INFO - 2016-07-11 04:46:05 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:46:05 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:46:05 --> Utf8 Class Initialized
INFO - 2016-07-11 04:46:05 --> URI Class Initialized
INFO - 2016-07-11 04:46:05 --> Router Class Initialized
INFO - 2016-07-11 04:46:05 --> Output Class Initialized
INFO - 2016-07-11 04:46:05 --> Security Class Initialized
DEBUG - 2016-07-11 04:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:46:05 --> Input Class Initialized
INFO - 2016-07-11 04:46:05 --> Language Class Initialized
INFO - 2016-07-11 04:46:05 --> Loader Class Initialized
INFO - 2016-07-11 04:46:05 --> Helper loaded: url_helper
INFO - 2016-07-11 04:46:05 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:46:05 --> Helper loaded: html_helper
INFO - 2016-07-11 04:46:05 --> Helper loaded: form_helper
INFO - 2016-07-11 04:46:05 --> Helper loaded: file_helper
INFO - 2016-07-11 04:46:05 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:46:05 --> Database Driver Class Initialized
INFO - 2016-07-11 04:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:46:05 --> Form Validation Class Initialized
INFO - 2016-07-11 04:46:05 --> Email Class Initialized
INFO - 2016-07-11 04:46:05 --> Controller Class Initialized
INFO - 2016-07-11 04:46:05 --> Model Class Initialized
INFO - 2016-07-11 04:46:22 --> Config Class Initialized
INFO - 2016-07-11 04:46:22 --> Hooks Class Initialized
DEBUG - 2016-07-11 04:46:22 --> UTF-8 Support Enabled
INFO - 2016-07-11 04:46:22 --> Utf8 Class Initialized
INFO - 2016-07-11 04:46:22 --> URI Class Initialized
INFO - 2016-07-11 04:46:22 --> Router Class Initialized
INFO - 2016-07-11 04:46:22 --> Output Class Initialized
INFO - 2016-07-11 04:46:22 --> Security Class Initialized
DEBUG - 2016-07-11 04:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 04:46:22 --> Input Class Initialized
INFO - 2016-07-11 04:46:22 --> Language Class Initialized
INFO - 2016-07-11 04:46:22 --> Loader Class Initialized
INFO - 2016-07-11 04:46:22 --> Helper loaded: url_helper
INFO - 2016-07-11 04:46:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 04:46:22 --> Helper loaded: html_helper
INFO - 2016-07-11 04:46:22 --> Helper loaded: form_helper
INFO - 2016-07-11 04:46:22 --> Helper loaded: file_helper
INFO - 2016-07-11 04:46:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 04:46:22 --> Database Driver Class Initialized
INFO - 2016-07-11 04:46:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 04:46:22 --> Form Validation Class Initialized
INFO - 2016-07-11 04:46:23 --> Email Class Initialized
INFO - 2016-07-11 04:46:23 --> Controller Class Initialized
INFO - 2016-07-11 04:46:23 --> Model Class Initialized
ERROR - 2016-07-11 04:46:23 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 05:00:31 --> Config Class Initialized
INFO - 2016-07-11 05:00:31 --> Hooks Class Initialized
DEBUG - 2016-07-11 05:00:31 --> UTF-8 Support Enabled
INFO - 2016-07-11 05:00:31 --> Utf8 Class Initialized
INFO - 2016-07-11 05:00:31 --> URI Class Initialized
INFO - 2016-07-11 05:00:31 --> Router Class Initialized
INFO - 2016-07-11 05:00:31 --> Output Class Initialized
INFO - 2016-07-11 05:00:31 --> Security Class Initialized
DEBUG - 2016-07-11 05:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 05:00:31 --> Input Class Initialized
INFO - 2016-07-11 05:00:31 --> Language Class Initialized
INFO - 2016-07-11 05:00:31 --> Loader Class Initialized
INFO - 2016-07-11 05:00:31 --> Helper loaded: url_helper
INFO - 2016-07-11 05:00:31 --> Helper loaded: utils_helper
INFO - 2016-07-11 05:00:31 --> Helper loaded: html_helper
INFO - 2016-07-11 05:00:31 --> Helper loaded: form_helper
INFO - 2016-07-11 05:00:31 --> Helper loaded: file_helper
INFO - 2016-07-11 05:00:31 --> Helper loaded: myemail_helper
INFO - 2016-07-11 05:00:31 --> Database Driver Class Initialized
INFO - 2016-07-11 05:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 05:00:31 --> Form Validation Class Initialized
INFO - 2016-07-11 05:00:31 --> Email Class Initialized
INFO - 2016-07-11 05:00:31 --> Controller Class Initialized
INFO - 2016-07-11 05:00:31 --> Model Class Initialized
ERROR - 2016-07-11 05:00:31 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 06:28:18 --> Config Class Initialized
INFO - 2016-07-11 06:28:18 --> Hooks Class Initialized
DEBUG - 2016-07-11 06:28:18 --> UTF-8 Support Enabled
INFO - 2016-07-11 06:28:18 --> Utf8 Class Initialized
INFO - 2016-07-11 06:28:18 --> URI Class Initialized
INFO - 2016-07-11 06:28:18 --> Router Class Initialized
INFO - 2016-07-11 06:28:18 --> Output Class Initialized
INFO - 2016-07-11 06:28:18 --> Security Class Initialized
DEBUG - 2016-07-11 06:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 06:28:18 --> Input Class Initialized
INFO - 2016-07-11 06:28:18 --> Language Class Initialized
INFO - 2016-07-11 06:28:18 --> Loader Class Initialized
INFO - 2016-07-11 06:28:18 --> Helper loaded: url_helper
INFO - 2016-07-11 06:28:18 --> Helper loaded: utils_helper
INFO - 2016-07-11 06:28:18 --> Helper loaded: html_helper
INFO - 2016-07-11 06:28:18 --> Helper loaded: form_helper
INFO - 2016-07-11 06:28:18 --> Helper loaded: file_helper
INFO - 2016-07-11 06:28:18 --> Helper loaded: myemail_helper
INFO - 2016-07-11 06:28:18 --> Database Driver Class Initialized
INFO - 2016-07-11 06:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 06:28:18 --> Form Validation Class Initialized
INFO - 2016-07-11 06:28:18 --> Email Class Initialized
INFO - 2016-07-11 06:28:18 --> Controller Class Initialized
INFO - 2016-07-11 06:28:18 --> Model Class Initialized
DEBUG - 2016-07-11 06:28:18 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 06:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 06:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 06:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 06:28:18 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 06:28:18 --> Final output sent to browser
DEBUG - 2016-07-11 06:28:18 --> Total execution time: 0.2628
INFO - 2016-07-11 06:28:22 --> Config Class Initialized
INFO - 2016-07-11 06:28:22 --> Hooks Class Initialized
DEBUG - 2016-07-11 06:28:22 --> UTF-8 Support Enabled
INFO - 2016-07-11 06:28:22 --> Utf8 Class Initialized
INFO - 2016-07-11 06:28:22 --> URI Class Initialized
INFO - 2016-07-11 06:28:22 --> Router Class Initialized
INFO - 2016-07-11 06:28:22 --> Output Class Initialized
INFO - 2016-07-11 06:28:22 --> Security Class Initialized
DEBUG - 2016-07-11 06:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 06:28:22 --> Input Class Initialized
INFO - 2016-07-11 06:28:22 --> Language Class Initialized
INFO - 2016-07-11 06:28:22 --> Loader Class Initialized
INFO - 2016-07-11 06:28:22 --> Helper loaded: url_helper
INFO - 2016-07-11 06:28:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 06:28:22 --> Helper loaded: html_helper
INFO - 2016-07-11 06:28:22 --> Helper loaded: form_helper
INFO - 2016-07-11 06:28:22 --> Helper loaded: file_helper
INFO - 2016-07-11 06:28:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 06:28:22 --> Database Driver Class Initialized
INFO - 2016-07-11 06:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 06:28:22 --> Form Validation Class Initialized
INFO - 2016-07-11 06:28:22 --> Email Class Initialized
INFO - 2016-07-11 06:28:22 --> Controller Class Initialized
INFO - 2016-07-11 06:28:22 --> Model Class Initialized
DEBUG - 2016-07-11 06:28:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 06:28:22 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-07-11 06:28:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 06:28:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 06:28:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 06:28:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 06:28:22 --> Final output sent to browser
DEBUG - 2016-07-11 06:28:22 --> Total execution time: 0.2667
INFO - 2016-07-11 06:28:23 --> Config Class Initialized
INFO - 2016-07-11 06:28:23 --> Hooks Class Initialized
DEBUG - 2016-07-11 06:28:23 --> UTF-8 Support Enabled
INFO - 2016-07-11 06:28:23 --> Utf8 Class Initialized
INFO - 2016-07-11 06:28:23 --> URI Class Initialized
INFO - 2016-07-11 06:28:23 --> Router Class Initialized
INFO - 2016-07-11 06:28:23 --> Output Class Initialized
INFO - 2016-07-11 06:28:23 --> Security Class Initialized
DEBUG - 2016-07-11 06:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 06:28:23 --> Input Class Initialized
INFO - 2016-07-11 06:28:23 --> Language Class Initialized
INFO - 2016-07-11 06:28:23 --> Loader Class Initialized
INFO - 2016-07-11 06:28:23 --> Helper loaded: url_helper
INFO - 2016-07-11 06:28:23 --> Helper loaded: utils_helper
INFO - 2016-07-11 06:28:23 --> Helper loaded: html_helper
INFO - 2016-07-11 06:28:23 --> Helper loaded: form_helper
INFO - 2016-07-11 06:28:24 --> Helper loaded: file_helper
INFO - 2016-07-11 06:28:24 --> Helper loaded: myemail_helper
INFO - 2016-07-11 06:28:24 --> Database Driver Class Initialized
INFO - 2016-07-11 06:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 06:28:24 --> Form Validation Class Initialized
INFO - 2016-07-11 06:28:24 --> Email Class Initialized
INFO - 2016-07-11 06:28:24 --> Controller Class Initialized
INFO - 2016-07-11 06:28:24 --> Model Class Initialized
INFO - 2016-07-11 06:28:44 --> Config Class Initialized
INFO - 2016-07-11 06:28:44 --> Hooks Class Initialized
DEBUG - 2016-07-11 06:28:44 --> UTF-8 Support Enabled
INFO - 2016-07-11 06:28:44 --> Utf8 Class Initialized
INFO - 2016-07-11 06:28:44 --> URI Class Initialized
INFO - 2016-07-11 06:28:44 --> Router Class Initialized
INFO - 2016-07-11 06:28:44 --> Output Class Initialized
INFO - 2016-07-11 06:28:44 --> Security Class Initialized
DEBUG - 2016-07-11 06:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 06:28:44 --> Input Class Initialized
INFO - 2016-07-11 06:28:44 --> Language Class Initialized
INFO - 2016-07-11 06:28:44 --> Loader Class Initialized
INFO - 2016-07-11 06:28:44 --> Helper loaded: url_helper
INFO - 2016-07-11 06:28:44 --> Helper loaded: utils_helper
INFO - 2016-07-11 06:28:44 --> Helper loaded: html_helper
INFO - 2016-07-11 06:28:44 --> Helper loaded: form_helper
INFO - 2016-07-11 06:28:44 --> Helper loaded: file_helper
INFO - 2016-07-11 06:28:44 --> Helper loaded: myemail_helper
INFO - 2016-07-11 06:28:44 --> Database Driver Class Initialized
INFO - 2016-07-11 06:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 06:28:44 --> Form Validation Class Initialized
INFO - 2016-07-11 06:28:44 --> Email Class Initialized
INFO - 2016-07-11 06:28:44 --> Controller Class Initialized
INFO - 2016-07-11 06:28:44 --> Model Class Initialized
ERROR - 2016-07-11 06:28:44 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 07:02:04 --> Config Class Initialized
INFO - 2016-07-11 07:02:04 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:02:04 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:02:04 --> Utf8 Class Initialized
INFO - 2016-07-11 07:02:04 --> URI Class Initialized
DEBUG - 2016-07-11 07:02:04 --> No URI present. Default controller set.
INFO - 2016-07-11 07:02:04 --> Router Class Initialized
INFO - 2016-07-11 07:02:04 --> Output Class Initialized
INFO - 2016-07-11 07:02:04 --> Security Class Initialized
DEBUG - 2016-07-11 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:02:04 --> Input Class Initialized
INFO - 2016-07-11 07:02:04 --> Language Class Initialized
INFO - 2016-07-11 07:02:04 --> Loader Class Initialized
INFO - 2016-07-11 07:02:04 --> Helper loaded: url_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: html_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: form_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: file_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:02:04 --> Database Driver Class Initialized
INFO - 2016-07-11 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:02:04 --> Form Validation Class Initialized
INFO - 2016-07-11 07:02:04 --> Email Class Initialized
INFO - 2016-07-11 07:02:04 --> Controller Class Initialized
INFO - 2016-07-11 07:02:04 --> Config Class Initialized
INFO - 2016-07-11 07:02:04 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:02:04 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:02:04 --> Utf8 Class Initialized
INFO - 2016-07-11 07:02:04 --> URI Class Initialized
INFO - 2016-07-11 07:02:04 --> Router Class Initialized
INFO - 2016-07-11 07:02:04 --> Output Class Initialized
INFO - 2016-07-11 07:02:04 --> Security Class Initialized
DEBUG - 2016-07-11 07:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:02:04 --> Input Class Initialized
INFO - 2016-07-11 07:02:04 --> Language Class Initialized
INFO - 2016-07-11 07:02:04 --> Loader Class Initialized
INFO - 2016-07-11 07:02:04 --> Helper loaded: url_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: html_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: form_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: file_helper
INFO - 2016-07-11 07:02:04 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:02:04 --> Database Driver Class Initialized
INFO - 2016-07-11 07:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:02:04 --> Form Validation Class Initialized
INFO - 2016-07-11 07:02:04 --> Email Class Initialized
INFO - 2016-07-11 07:02:04 --> Controller Class Initialized
INFO - 2016-07-11 07:02:04 --> Model Class Initialized
DEBUG - 2016-07-11 07:02:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:02:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:02:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:02:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:02:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:02:04 --> Final output sent to browser
DEBUG - 2016-07-11 07:02:04 --> Total execution time: 0.2443
INFO - 2016-07-11 07:02:07 --> Config Class Initialized
INFO - 2016-07-11 07:02:07 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:02:07 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:02:07 --> Utf8 Class Initialized
INFO - 2016-07-11 07:02:07 --> URI Class Initialized
INFO - 2016-07-11 07:02:07 --> Router Class Initialized
INFO - 2016-07-11 07:02:07 --> Output Class Initialized
INFO - 2016-07-11 07:02:07 --> Security Class Initialized
DEBUG - 2016-07-11 07:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:02:07 --> Input Class Initialized
INFO - 2016-07-11 07:02:07 --> Language Class Initialized
INFO - 2016-07-11 07:02:07 --> Loader Class Initialized
INFO - 2016-07-11 07:02:07 --> Helper loaded: url_helper
INFO - 2016-07-11 07:02:07 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:02:07 --> Helper loaded: html_helper
INFO - 2016-07-11 07:02:07 --> Helper loaded: form_helper
INFO - 2016-07-11 07:02:07 --> Helper loaded: file_helper
INFO - 2016-07-11 07:02:07 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:02:07 --> Database Driver Class Initialized
INFO - 2016-07-11 07:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:02:07 --> Form Validation Class Initialized
INFO - 2016-07-11 07:02:07 --> Email Class Initialized
INFO - 2016-07-11 07:02:07 --> Controller Class Initialized
INFO - 2016-07-11 07:02:07 --> Model Class Initialized
INFO - 2016-07-11 07:04:33 --> Config Class Initialized
INFO - 2016-07-11 07:04:33 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:04:33 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:04:33 --> Utf8 Class Initialized
INFO - 2016-07-11 07:04:33 --> URI Class Initialized
INFO - 2016-07-11 07:04:33 --> Router Class Initialized
INFO - 2016-07-11 07:04:33 --> Output Class Initialized
INFO - 2016-07-11 07:04:33 --> Security Class Initialized
DEBUG - 2016-07-11 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:04:33 --> Input Class Initialized
INFO - 2016-07-11 07:04:33 --> Language Class Initialized
INFO - 2016-07-11 07:04:33 --> Loader Class Initialized
INFO - 2016-07-11 07:04:34 --> Helper loaded: url_helper
INFO - 2016-07-11 07:04:34 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:04:34 --> Helper loaded: html_helper
INFO - 2016-07-11 07:04:34 --> Helper loaded: form_helper
INFO - 2016-07-11 07:04:34 --> Helper loaded: file_helper
INFO - 2016-07-11 07:04:34 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:04:34 --> Database Driver Class Initialized
INFO - 2016-07-11 07:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:04:34 --> Form Validation Class Initialized
INFO - 2016-07-11 07:04:34 --> Email Class Initialized
INFO - 2016-07-11 07:04:34 --> Controller Class Initialized
INFO - 2016-07-11 07:04:34 --> Model Class Initialized
DEBUG - 2016-07-11 07:04:34 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:04:34 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:04:34 --> Final output sent to browser
DEBUG - 2016-07-11 07:04:34 --> Total execution time: 0.2746
INFO - 2016-07-11 07:05:08 --> Config Class Initialized
INFO - 2016-07-11 07:05:08 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:05:08 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:05:08 --> Utf8 Class Initialized
INFO - 2016-07-11 07:05:08 --> URI Class Initialized
INFO - 2016-07-11 07:05:08 --> Router Class Initialized
INFO - 2016-07-11 07:05:08 --> Output Class Initialized
INFO - 2016-07-11 07:05:08 --> Security Class Initialized
DEBUG - 2016-07-11 07:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:05:08 --> Input Class Initialized
INFO - 2016-07-11 07:05:08 --> Language Class Initialized
INFO - 2016-07-11 07:05:08 --> Loader Class Initialized
INFO - 2016-07-11 07:05:08 --> Helper loaded: url_helper
INFO - 2016-07-11 07:05:08 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:05:08 --> Helper loaded: html_helper
INFO - 2016-07-11 07:05:08 --> Helper loaded: form_helper
INFO - 2016-07-11 07:05:08 --> Helper loaded: file_helper
INFO - 2016-07-11 07:05:08 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:05:08 --> Database Driver Class Initialized
INFO - 2016-07-11 07:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:05:09 --> Form Validation Class Initialized
INFO - 2016-07-11 07:05:09 --> Email Class Initialized
INFO - 2016-07-11 07:05:09 --> Controller Class Initialized
INFO - 2016-07-11 07:05:09 --> Model Class Initialized
DEBUG - 2016-07-11 07:05:09 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:05:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:05:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:05:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:05:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:05:09 --> Final output sent to browser
DEBUG - 2016-07-11 07:05:09 --> Total execution time: 0.2556
INFO - 2016-07-11 07:05:11 --> Config Class Initialized
INFO - 2016-07-11 07:05:11 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:05:11 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:05:11 --> Utf8 Class Initialized
INFO - 2016-07-11 07:05:11 --> URI Class Initialized
INFO - 2016-07-11 07:05:11 --> Router Class Initialized
INFO - 2016-07-11 07:05:11 --> Output Class Initialized
INFO - 2016-07-11 07:05:11 --> Security Class Initialized
DEBUG - 2016-07-11 07:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:05:11 --> Input Class Initialized
INFO - 2016-07-11 07:05:11 --> Language Class Initialized
INFO - 2016-07-11 07:05:11 --> Loader Class Initialized
INFO - 2016-07-11 07:05:11 --> Helper loaded: url_helper
INFO - 2016-07-11 07:05:11 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:05:11 --> Helper loaded: html_helper
INFO - 2016-07-11 07:05:11 --> Helper loaded: form_helper
INFO - 2016-07-11 07:05:11 --> Helper loaded: file_helper
INFO - 2016-07-11 07:05:11 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:05:11 --> Database Driver Class Initialized
INFO - 2016-07-11 07:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:05:11 --> Form Validation Class Initialized
INFO - 2016-07-11 07:05:11 --> Email Class Initialized
INFO - 2016-07-11 07:05:11 --> Controller Class Initialized
INFO - 2016-07-11 07:05:11 --> Model Class Initialized
INFO - 2016-07-11 07:05:23 --> Config Class Initialized
INFO - 2016-07-11 07:05:23 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:05:23 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:05:23 --> Utf8 Class Initialized
INFO - 2016-07-11 07:05:23 --> URI Class Initialized
INFO - 2016-07-11 07:05:23 --> Router Class Initialized
INFO - 2016-07-11 07:05:23 --> Output Class Initialized
INFO - 2016-07-11 07:05:24 --> Security Class Initialized
DEBUG - 2016-07-11 07:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:05:24 --> Input Class Initialized
INFO - 2016-07-11 07:05:24 --> Language Class Initialized
INFO - 2016-07-11 07:05:24 --> Loader Class Initialized
INFO - 2016-07-11 07:05:24 --> Helper loaded: url_helper
INFO - 2016-07-11 07:05:24 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:05:24 --> Helper loaded: html_helper
INFO - 2016-07-11 07:05:24 --> Helper loaded: form_helper
INFO - 2016-07-11 07:05:24 --> Helper loaded: file_helper
INFO - 2016-07-11 07:05:24 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:05:24 --> Database Driver Class Initialized
INFO - 2016-07-11 07:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:05:24 --> Form Validation Class Initialized
INFO - 2016-07-11 07:05:24 --> Email Class Initialized
INFO - 2016-07-11 07:05:24 --> Controller Class Initialized
INFO - 2016-07-11 07:05:24 --> Model Class Initialized
ERROR - 2016-07-11 07:05:24 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 07:05:30 --> Config Class Initialized
INFO - 2016-07-11 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:05:30 --> Utf8 Class Initialized
INFO - 2016-07-11 07:05:30 --> URI Class Initialized
DEBUG - 2016-07-11 07:05:30 --> No URI present. Default controller set.
INFO - 2016-07-11 07:05:30 --> Router Class Initialized
INFO - 2016-07-11 07:05:30 --> Output Class Initialized
INFO - 2016-07-11 07:05:30 --> Security Class Initialized
DEBUG - 2016-07-11 07:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:05:30 --> Input Class Initialized
INFO - 2016-07-11 07:05:30 --> Language Class Initialized
INFO - 2016-07-11 07:05:30 --> Loader Class Initialized
INFO - 2016-07-11 07:05:30 --> Helper loaded: url_helper
INFO - 2016-07-11 07:05:30 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:05:30 --> Helper loaded: html_helper
INFO - 2016-07-11 07:05:30 --> Helper loaded: form_helper
INFO - 2016-07-11 07:05:30 --> Helper loaded: file_helper
INFO - 2016-07-11 07:05:30 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:05:30 --> Database Driver Class Initialized
INFO - 2016-07-11 07:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:05:30 --> Form Validation Class Initialized
INFO - 2016-07-11 07:05:30 --> Email Class Initialized
INFO - 2016-07-11 07:05:30 --> Controller Class Initialized
INFO - 2016-07-11 07:05:30 --> Config Class Initialized
INFO - 2016-07-11 07:05:30 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:05:30 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:05:31 --> Utf8 Class Initialized
INFO - 2016-07-11 07:05:31 --> URI Class Initialized
INFO - 2016-07-11 07:05:31 --> Router Class Initialized
INFO - 2016-07-11 07:05:31 --> Output Class Initialized
INFO - 2016-07-11 07:05:31 --> Security Class Initialized
DEBUG - 2016-07-11 07:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:05:31 --> Input Class Initialized
INFO - 2016-07-11 07:05:31 --> Language Class Initialized
INFO - 2016-07-11 07:05:31 --> Loader Class Initialized
INFO - 2016-07-11 07:05:31 --> Helper loaded: url_helper
INFO - 2016-07-11 07:05:31 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:05:31 --> Helper loaded: html_helper
INFO - 2016-07-11 07:05:31 --> Helper loaded: form_helper
INFO - 2016-07-11 07:05:31 --> Helper loaded: file_helper
INFO - 2016-07-11 07:05:31 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:05:31 --> Database Driver Class Initialized
INFO - 2016-07-11 07:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:05:31 --> Form Validation Class Initialized
INFO - 2016-07-11 07:05:31 --> Email Class Initialized
INFO - 2016-07-11 07:05:31 --> Controller Class Initialized
INFO - 2016-07-11 07:05:31 --> Model Class Initialized
DEBUG - 2016-07-11 07:05:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:05:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:05:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:05:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:05:31 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:05:31 --> Final output sent to browser
DEBUG - 2016-07-11 07:05:31 --> Total execution time: 0.2551
INFO - 2016-07-11 07:06:53 --> Config Class Initialized
INFO - 2016-07-11 07:06:53 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:06:53 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:06:53 --> Utf8 Class Initialized
INFO - 2016-07-11 07:06:53 --> URI Class Initialized
INFO - 2016-07-11 07:06:53 --> Router Class Initialized
INFO - 2016-07-11 07:06:53 --> Output Class Initialized
INFO - 2016-07-11 07:06:53 --> Security Class Initialized
DEBUG - 2016-07-11 07:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:06:53 --> Input Class Initialized
INFO - 2016-07-11 07:06:53 --> Language Class Initialized
INFO - 2016-07-11 07:06:53 --> Loader Class Initialized
INFO - 2016-07-11 07:06:53 --> Helper loaded: url_helper
INFO - 2016-07-11 07:06:53 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:06:53 --> Helper loaded: html_helper
INFO - 2016-07-11 07:06:53 --> Helper loaded: form_helper
INFO - 2016-07-11 07:06:53 --> Helper loaded: file_helper
INFO - 2016-07-11 07:06:53 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:06:54 --> Database Driver Class Initialized
INFO - 2016-07-11 07:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:06:54 --> Form Validation Class Initialized
INFO - 2016-07-11 07:06:54 --> Email Class Initialized
INFO - 2016-07-11 07:06:54 --> Controller Class Initialized
INFO - 2016-07-11 07:06:54 --> Model Class Initialized
DEBUG - 2016-07-11 07:06:54 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:06:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:06:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:06:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:06:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:06:54 --> Final output sent to browser
DEBUG - 2016-07-11 07:06:54 --> Total execution time: 0.2717
INFO - 2016-07-11 07:06:55 --> Config Class Initialized
INFO - 2016-07-11 07:06:55 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:06:55 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:06:55 --> Utf8 Class Initialized
INFO - 2016-07-11 07:06:55 --> URI Class Initialized
INFO - 2016-07-11 07:06:56 --> Router Class Initialized
INFO - 2016-07-11 07:06:56 --> Output Class Initialized
INFO - 2016-07-11 07:06:56 --> Security Class Initialized
DEBUG - 2016-07-11 07:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:06:56 --> Input Class Initialized
INFO - 2016-07-11 07:06:56 --> Language Class Initialized
INFO - 2016-07-11 07:06:56 --> Loader Class Initialized
INFO - 2016-07-11 07:06:56 --> Helper loaded: url_helper
INFO - 2016-07-11 07:06:56 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:06:56 --> Helper loaded: html_helper
INFO - 2016-07-11 07:06:56 --> Helper loaded: form_helper
INFO - 2016-07-11 07:06:56 --> Helper loaded: file_helper
INFO - 2016-07-11 07:06:56 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:06:56 --> Database Driver Class Initialized
INFO - 2016-07-11 07:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:06:56 --> Form Validation Class Initialized
INFO - 2016-07-11 07:06:56 --> Email Class Initialized
INFO - 2016-07-11 07:06:56 --> Controller Class Initialized
INFO - 2016-07-11 07:06:56 --> Model Class Initialized
INFO - 2016-07-11 07:07:15 --> Config Class Initialized
INFO - 2016-07-11 07:07:15 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:07:16 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:07:16 --> Utf8 Class Initialized
INFO - 2016-07-11 07:07:16 --> URI Class Initialized
INFO - 2016-07-11 07:07:16 --> Router Class Initialized
INFO - 2016-07-11 07:07:16 --> Output Class Initialized
INFO - 2016-07-11 07:07:16 --> Security Class Initialized
DEBUG - 2016-07-11 07:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:07:16 --> Input Class Initialized
INFO - 2016-07-11 07:07:16 --> Language Class Initialized
INFO - 2016-07-11 07:07:16 --> Loader Class Initialized
INFO - 2016-07-11 07:07:16 --> Helper loaded: url_helper
INFO - 2016-07-11 07:07:16 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:07:16 --> Helper loaded: html_helper
INFO - 2016-07-11 07:07:16 --> Helper loaded: form_helper
INFO - 2016-07-11 07:07:16 --> Helper loaded: file_helper
INFO - 2016-07-11 07:07:16 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:07:16 --> Database Driver Class Initialized
INFO - 2016-07-11 07:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:07:16 --> Form Validation Class Initialized
INFO - 2016-07-11 07:07:16 --> Email Class Initialized
INFO - 2016-07-11 07:07:16 --> Controller Class Initialized
INFO - 2016-07-11 07:07:16 --> Model Class Initialized
ERROR - 2016-07-11 07:07:16 --> Severity: Error --> Access to undeclared static property: League\OAuth2\Client\Grant\AbstractGrant::$class D:\wamp\www\library.pnc.lan\application\third_party\OAuthClient\vendor\league\oauth2-client\src\Grant\GrantFactory.php 85
INFO - 2016-07-11 07:09:09 --> Config Class Initialized
INFO - 2016-07-11 07:09:09 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:09 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:09 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:09 --> URI Class Initialized
INFO - 2016-07-11 07:09:09 --> Router Class Initialized
INFO - 2016-07-11 07:09:09 --> Output Class Initialized
INFO - 2016-07-11 07:09:09 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:09 --> Input Class Initialized
INFO - 2016-07-11 07:09:09 --> Language Class Initialized
INFO - 2016-07-11 07:09:09 --> Loader Class Initialized
INFO - 2016-07-11 07:09:10 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:10 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:10 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:10 --> Email Class Initialized
INFO - 2016-07-11 07:09:10 --> Controller Class Initialized
INFO - 2016-07-11 07:09:10 --> Model Class Initialized
DEBUG - 2016-07-11 07:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:09:10 --> Final output sent to browser
DEBUG - 2016-07-11 07:09:10 --> Total execution time: 0.3299
INFO - 2016-07-11 07:09:10 --> Config Class Initialized
INFO - 2016-07-11 07:09:10 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:10 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:10 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:10 --> URI Class Initialized
INFO - 2016-07-11 07:09:10 --> Router Class Initialized
INFO - 2016-07-11 07:09:10 --> Output Class Initialized
INFO - 2016-07-11 07:09:10 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:10 --> Input Class Initialized
INFO - 2016-07-11 07:09:10 --> Language Class Initialized
INFO - 2016-07-11 07:09:10 --> Loader Class Initialized
INFO - 2016-07-11 07:09:10 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:10 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:10 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:10 --> Email Class Initialized
INFO - 2016-07-11 07:09:10 --> Controller Class Initialized
INFO - 2016-07-11 07:09:10 --> Model Class Initialized
DEBUG - 2016-07-11 07:09:10 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:09:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:09:10 --> Final output sent to browser
DEBUG - 2016-07-11 07:09:10 --> Total execution time: 0.2624
INFO - 2016-07-11 07:09:10 --> Config Class Initialized
INFO - 2016-07-11 07:09:10 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:10 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:10 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:10 --> URI Class Initialized
INFO - 2016-07-11 07:09:10 --> Router Class Initialized
INFO - 2016-07-11 07:09:10 --> Output Class Initialized
INFO - 2016-07-11 07:09:10 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:10 --> Input Class Initialized
INFO - 2016-07-11 07:09:10 --> Language Class Initialized
INFO - 2016-07-11 07:09:10 --> Loader Class Initialized
INFO - 2016-07-11 07:09:10 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:10 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:10 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:10 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:10 --> Email Class Initialized
INFO - 2016-07-11 07:09:10 --> Controller Class Initialized
INFO - 2016-07-11 07:09:10 --> Model Class Initialized
INFO - 2016-07-11 07:09:12 --> Config Class Initialized
INFO - 2016-07-11 07:09:12 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:12 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:12 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:12 --> URI Class Initialized
INFO - 2016-07-11 07:09:12 --> Router Class Initialized
INFO - 2016-07-11 07:09:12 --> Output Class Initialized
INFO - 2016-07-11 07:09:12 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:12 --> Input Class Initialized
INFO - 2016-07-11 07:09:12 --> Language Class Initialized
INFO - 2016-07-11 07:09:12 --> Loader Class Initialized
INFO - 2016-07-11 07:09:12 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:12 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:12 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:12 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:12 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:12 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:12 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:12 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:12 --> Email Class Initialized
INFO - 2016-07-11 07:09:12 --> Controller Class Initialized
INFO - 2016-07-11 07:09:12 --> Model Class Initialized
DEBUG - 2016-07-11 07:09:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:09:12 --> Final output sent to browser
DEBUG - 2016-07-11 07:09:12 --> Total execution time: 0.2668
INFO - 2016-07-11 07:09:16 --> Config Class Initialized
INFO - 2016-07-11 07:09:16 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:16 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:16 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:16 --> URI Class Initialized
DEBUG - 2016-07-11 07:09:16 --> No URI present. Default controller set.
INFO - 2016-07-11 07:09:16 --> Router Class Initialized
INFO - 2016-07-11 07:09:16 --> Output Class Initialized
INFO - 2016-07-11 07:09:16 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:16 --> Input Class Initialized
INFO - 2016-07-11 07:09:16 --> Language Class Initialized
INFO - 2016-07-11 07:09:16 --> Loader Class Initialized
INFO - 2016-07-11 07:09:16 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:16 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:16 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:16 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:16 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:16 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:16 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:16 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:16 --> Email Class Initialized
INFO - 2016-07-11 07:09:16 --> Controller Class Initialized
INFO - 2016-07-11 07:09:33 --> Config Class Initialized
INFO - 2016-07-11 07:09:33 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:33 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:33 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:33 --> URI Class Initialized
DEBUG - 2016-07-11 07:09:33 --> No URI present. Default controller set.
INFO - 2016-07-11 07:09:33 --> Router Class Initialized
INFO - 2016-07-11 07:09:33 --> Output Class Initialized
INFO - 2016-07-11 07:09:33 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:33 --> Input Class Initialized
INFO - 2016-07-11 07:09:33 --> Language Class Initialized
INFO - 2016-07-11 07:09:33 --> Loader Class Initialized
INFO - 2016-07-11 07:09:33 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:33 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:33 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:33 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:33 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:33 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:33 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:33 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:33 --> Email Class Initialized
INFO - 2016-07-11 07:09:34 --> Controller Class Initialized
INFO - 2016-07-11 07:09:55 --> Config Class Initialized
INFO - 2016-07-11 07:09:55 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:09:55 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:09:55 --> Utf8 Class Initialized
INFO - 2016-07-11 07:09:55 --> URI Class Initialized
DEBUG - 2016-07-11 07:09:55 --> No URI present. Default controller set.
INFO - 2016-07-11 07:09:55 --> Router Class Initialized
INFO - 2016-07-11 07:09:55 --> Output Class Initialized
INFO - 2016-07-11 07:09:55 --> Security Class Initialized
DEBUG - 2016-07-11 07:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:09:55 --> Input Class Initialized
INFO - 2016-07-11 07:09:55 --> Language Class Initialized
INFO - 2016-07-11 07:09:55 --> Loader Class Initialized
INFO - 2016-07-11 07:09:55 --> Helper loaded: url_helper
INFO - 2016-07-11 07:09:55 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:09:55 --> Helper loaded: html_helper
INFO - 2016-07-11 07:09:55 --> Helper loaded: form_helper
INFO - 2016-07-11 07:09:55 --> Helper loaded: file_helper
INFO - 2016-07-11 07:09:55 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:09:55 --> Database Driver Class Initialized
INFO - 2016-07-11 07:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:09:55 --> Form Validation Class Initialized
INFO - 2016-07-11 07:09:55 --> Email Class Initialized
INFO - 2016-07-11 07:09:55 --> Controller Class Initialized
INFO - 2016-07-11 07:10:01 --> Config Class Initialized
INFO - 2016-07-11 07:10:01 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:10:01 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:10:01 --> Utf8 Class Initialized
INFO - 2016-07-11 07:10:01 --> URI Class Initialized
INFO - 2016-07-11 07:10:01 --> Router Class Initialized
INFO - 2016-07-11 07:10:01 --> Output Class Initialized
INFO - 2016-07-11 07:10:01 --> Security Class Initialized
DEBUG - 2016-07-11 07:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:10:01 --> Input Class Initialized
INFO - 2016-07-11 07:10:01 --> Language Class Initialized
INFO - 2016-07-11 07:10:01 --> Loader Class Initialized
INFO - 2016-07-11 07:10:01 --> Helper loaded: url_helper
INFO - 2016-07-11 07:10:01 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:10:01 --> Helper loaded: html_helper
INFO - 2016-07-11 07:10:01 --> Helper loaded: form_helper
INFO - 2016-07-11 07:10:01 --> Helper loaded: file_helper
INFO - 2016-07-11 07:10:01 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:10:01 --> Database Driver Class Initialized
INFO - 2016-07-11 07:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:10:01 --> Form Validation Class Initialized
INFO - 2016-07-11 07:10:01 --> Email Class Initialized
INFO - 2016-07-11 07:10:02 --> Controller Class Initialized
INFO - 2016-07-11 07:10:02 --> Model Class Initialized
DEBUG - 2016-07-11 07:10:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:10:02 --> Final output sent to browser
DEBUG - 2016-07-11 07:10:02 --> Total execution time: 0.2752
INFO - 2016-07-11 07:10:14 --> Config Class Initialized
INFO - 2016-07-11 07:10:14 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:10:14 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:10:14 --> Utf8 Class Initialized
INFO - 2016-07-11 07:10:14 --> URI Class Initialized
INFO - 2016-07-11 07:10:14 --> Router Class Initialized
INFO - 2016-07-11 07:10:14 --> Output Class Initialized
INFO - 2016-07-11 07:10:14 --> Security Class Initialized
DEBUG - 2016-07-11 07:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:10:14 --> Input Class Initialized
INFO - 2016-07-11 07:10:14 --> Language Class Initialized
INFO - 2016-07-11 07:10:14 --> Loader Class Initialized
INFO - 2016-07-11 07:10:14 --> Helper loaded: url_helper
INFO - 2016-07-11 07:10:14 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:10:14 --> Helper loaded: html_helper
INFO - 2016-07-11 07:10:14 --> Helper loaded: form_helper
INFO - 2016-07-11 07:10:14 --> Helper loaded: file_helper
INFO - 2016-07-11 07:10:14 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:10:14 --> Database Driver Class Initialized
INFO - 2016-07-11 07:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:10:14 --> Form Validation Class Initialized
INFO - 2016-07-11 07:10:14 --> Email Class Initialized
INFO - 2016-07-11 07:10:14 --> Controller Class Initialized
INFO - 2016-07-11 07:23:39 --> Config Class Initialized
INFO - 2016-07-11 07:23:39 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:23:39 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:23:39 --> Utf8 Class Initialized
INFO - 2016-07-11 07:23:39 --> URI Class Initialized
DEBUG - 2016-07-11 07:23:39 --> No URI present. Default controller set.
INFO - 2016-07-11 07:23:39 --> Router Class Initialized
INFO - 2016-07-11 07:23:39 --> Output Class Initialized
INFO - 2016-07-11 07:23:39 --> Security Class Initialized
DEBUG - 2016-07-11 07:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:23:39 --> Input Class Initialized
INFO - 2016-07-11 07:23:39 --> Language Class Initialized
INFO - 2016-07-11 07:23:39 --> Loader Class Initialized
INFO - 2016-07-11 07:23:39 --> Helper loaded: url_helper
INFO - 2016-07-11 07:23:39 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:23:39 --> Helper loaded: html_helper
INFO - 2016-07-11 07:23:39 --> Helper loaded: form_helper
INFO - 2016-07-11 07:23:39 --> Helper loaded: file_helper
INFO - 2016-07-11 07:23:39 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:23:39 --> Database Driver Class Initialized
INFO - 2016-07-11 07:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:23:39 --> Form Validation Class Initialized
INFO - 2016-07-11 07:23:39 --> Email Class Initialized
INFO - 2016-07-11 07:23:39 --> Controller Class Initialized
INFO - 2016-07-11 07:23:58 --> Config Class Initialized
INFO - 2016-07-11 07:23:58 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:23:58 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:23:58 --> Utf8 Class Initialized
INFO - 2016-07-11 07:23:58 --> URI Class Initialized
INFO - 2016-07-11 07:23:58 --> Router Class Initialized
INFO - 2016-07-11 07:23:58 --> Output Class Initialized
INFO - 2016-07-11 07:23:58 --> Security Class Initialized
DEBUG - 2016-07-11 07:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:23:58 --> Input Class Initialized
INFO - 2016-07-11 07:23:58 --> Language Class Initialized
INFO - 2016-07-11 07:23:58 --> Loader Class Initialized
INFO - 2016-07-11 07:23:58 --> Helper loaded: url_helper
INFO - 2016-07-11 07:23:59 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:23:59 --> Helper loaded: html_helper
INFO - 2016-07-11 07:23:59 --> Helper loaded: form_helper
INFO - 2016-07-11 07:23:59 --> Helper loaded: file_helper
INFO - 2016-07-11 07:23:59 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:23:59 --> Database Driver Class Initialized
INFO - 2016-07-11 07:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:23:59 --> Form Validation Class Initialized
INFO - 2016-07-11 07:23:59 --> Email Class Initialized
INFO - 2016-07-11 07:23:59 --> Controller Class Initialized
INFO - 2016-07-11 07:24:22 --> Config Class Initialized
INFO - 2016-07-11 07:24:22 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:24:22 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:24:22 --> Utf8 Class Initialized
INFO - 2016-07-11 07:24:22 --> URI Class Initialized
INFO - 2016-07-11 07:24:22 --> Router Class Initialized
INFO - 2016-07-11 07:24:22 --> Output Class Initialized
INFO - 2016-07-11 07:24:22 --> Security Class Initialized
DEBUG - 2016-07-11 07:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:24:22 --> Input Class Initialized
INFO - 2016-07-11 07:24:22 --> Language Class Initialized
INFO - 2016-07-11 07:24:22 --> Loader Class Initialized
INFO - 2016-07-11 07:24:22 --> Helper loaded: url_helper
INFO - 2016-07-11 07:24:22 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:24:22 --> Helper loaded: html_helper
INFO - 2016-07-11 07:24:22 --> Helper loaded: form_helper
INFO - 2016-07-11 07:24:22 --> Helper loaded: file_helper
INFO - 2016-07-11 07:24:22 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:24:22 --> Database Driver Class Initialized
INFO - 2016-07-11 07:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:24:22 --> Form Validation Class Initialized
INFO - 2016-07-11 07:24:22 --> Email Class Initialized
INFO - 2016-07-11 07:24:22 --> Controller Class Initialized
INFO - 2016-07-11 07:24:22 --> Model Class Initialized
DEBUG - 2016-07-11 07:24:22 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:24:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:24:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:24:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:24:22 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:24:22 --> Final output sent to browser
DEBUG - 2016-07-11 07:24:22 --> Total execution time: 0.2787
INFO - 2016-07-11 07:25:51 --> Config Class Initialized
INFO - 2016-07-11 07:25:51 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:25:51 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:25:51 --> Utf8 Class Initialized
INFO - 2016-07-11 07:25:51 --> URI Class Initialized
INFO - 2016-07-11 07:25:51 --> Router Class Initialized
INFO - 2016-07-11 07:25:51 --> Output Class Initialized
INFO - 2016-07-11 07:25:51 --> Security Class Initialized
DEBUG - 2016-07-11 07:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:25:51 --> Input Class Initialized
INFO - 2016-07-11 07:25:51 --> Language Class Initialized
INFO - 2016-07-11 07:25:51 --> Loader Class Initialized
INFO - 2016-07-11 07:25:52 --> Helper loaded: url_helper
INFO - 2016-07-11 07:25:52 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:25:52 --> Helper loaded: html_helper
INFO - 2016-07-11 07:25:52 --> Helper loaded: form_helper
INFO - 2016-07-11 07:25:52 --> Helper loaded: file_helper
INFO - 2016-07-11 07:25:52 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:25:52 --> Database Driver Class Initialized
INFO - 2016-07-11 07:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:25:52 --> Form Validation Class Initialized
INFO - 2016-07-11 07:25:52 --> Email Class Initialized
INFO - 2016-07-11 07:25:52 --> Controller Class Initialized
INFO - 2016-07-11 07:25:52 --> Model Class Initialized
DEBUG - 2016-07-11 07:25:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:25:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:25:52 --> Final output sent to browser
DEBUG - 2016-07-11 07:25:52 --> Total execution time: 0.2832
INFO - 2016-07-11 07:26:42 --> Config Class Initialized
INFO - 2016-07-11 07:26:42 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:26:42 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:26:42 --> Utf8 Class Initialized
INFO - 2016-07-11 07:26:42 --> URI Class Initialized
INFO - 2016-07-11 07:26:43 --> Router Class Initialized
INFO - 2016-07-11 07:26:43 --> Output Class Initialized
INFO - 2016-07-11 07:26:43 --> Security Class Initialized
DEBUG - 2016-07-11 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:26:43 --> Input Class Initialized
INFO - 2016-07-11 07:26:43 --> Language Class Initialized
INFO - 2016-07-11 07:26:43 --> Loader Class Initialized
INFO - 2016-07-11 07:26:43 --> Helper loaded: url_helper
INFO - 2016-07-11 07:26:43 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:26:43 --> Helper loaded: html_helper
INFO - 2016-07-11 07:26:43 --> Helper loaded: form_helper
INFO - 2016-07-11 07:26:43 --> Helper loaded: file_helper
INFO - 2016-07-11 07:26:43 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:26:43 --> Database Driver Class Initialized
INFO - 2016-07-11 07:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:26:43 --> Form Validation Class Initialized
INFO - 2016-07-11 07:26:43 --> Email Class Initialized
INFO - 2016-07-11 07:26:43 --> Controller Class Initialized
INFO - 2016-07-11 07:26:43 --> Model Class Initialized
DEBUG - 2016-07-11 07:26:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 07:26:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 07:26:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 07:26:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 07:26:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 07:26:43 --> Final output sent to browser
DEBUG - 2016-07-11 07:26:43 --> Total execution time: 0.2796
INFO - 2016-07-11 07:26:45 --> Config Class Initialized
INFO - 2016-07-11 07:26:45 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:26:45 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:26:45 --> Utf8 Class Initialized
INFO - 2016-07-11 07:26:45 --> URI Class Initialized
INFO - 2016-07-11 07:26:45 --> Router Class Initialized
INFO - 2016-07-11 07:26:45 --> Output Class Initialized
INFO - 2016-07-11 07:26:45 --> Security Class Initialized
DEBUG - 2016-07-11 07:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:26:45 --> Input Class Initialized
INFO - 2016-07-11 07:26:45 --> Language Class Initialized
INFO - 2016-07-11 07:26:45 --> Loader Class Initialized
INFO - 2016-07-11 07:26:45 --> Helper loaded: url_helper
INFO - 2016-07-11 07:26:45 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:26:45 --> Helper loaded: html_helper
INFO - 2016-07-11 07:26:45 --> Helper loaded: form_helper
INFO - 2016-07-11 07:26:45 --> Helper loaded: file_helper
INFO - 2016-07-11 07:26:45 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:26:45 --> Database Driver Class Initialized
INFO - 2016-07-11 07:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:26:45 --> Form Validation Class Initialized
INFO - 2016-07-11 07:26:45 --> Email Class Initialized
INFO - 2016-07-11 07:26:45 --> Controller Class Initialized
INFO - 2016-07-11 07:26:45 --> Model Class Initialized
ERROR - 2016-07-11 07:26:45 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 318
ERROR - 2016-07-11 07:26:45 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Client.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 318
ERROR - 2016-07-11 07:26:45 --> Severity: Warning --> include_once(D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php): failed to open stream: No such file or directory D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 319
ERROR - 2016-07-11 07:26:45 --> Severity: Warning --> include_once(): Failed opening 'D:\wamp\www\library.pnc.lan\application\libraries/google-api-php-client-master/src/Google/Service/Oauth2.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 319
ERROR - 2016-07-11 07:26:45 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 329
INFO - 2016-07-11 07:27:01 --> Config Class Initialized
INFO - 2016-07-11 07:27:01 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:27:02 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:27:02 --> Utf8 Class Initialized
INFO - 2016-07-11 07:27:02 --> URI Class Initialized
INFO - 2016-07-11 07:27:02 --> Router Class Initialized
INFO - 2016-07-11 07:27:02 --> Output Class Initialized
INFO - 2016-07-11 07:27:02 --> Security Class Initialized
DEBUG - 2016-07-11 07:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:27:02 --> Input Class Initialized
INFO - 2016-07-11 07:27:02 --> Language Class Initialized
INFO - 2016-07-11 07:27:02 --> Loader Class Initialized
INFO - 2016-07-11 07:27:02 --> Helper loaded: url_helper
INFO - 2016-07-11 07:27:02 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:27:02 --> Helper loaded: html_helper
INFO - 2016-07-11 07:27:02 --> Helper loaded: form_helper
INFO - 2016-07-11 07:27:02 --> Helper loaded: file_helper
INFO - 2016-07-11 07:27:02 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:27:02 --> Database Driver Class Initialized
INFO - 2016-07-11 07:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:27:02 --> Form Validation Class Initialized
INFO - 2016-07-11 07:27:02 --> Email Class Initialized
INFO - 2016-07-11 07:27:02 --> Controller Class Initialized
INFO - 2016-07-11 07:27:02 --> Model Class Initialized
ERROR - 2016-07-11 07:27:02 --> Severity: Error --> Class 'Google_Client' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 329
INFO - 2016-07-11 07:31:31 --> Config Class Initialized
INFO - 2016-07-11 07:31:31 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:31:31 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:31:31 --> Utf8 Class Initialized
INFO - 2016-07-11 07:31:31 --> URI Class Initialized
INFO - 2016-07-11 07:31:31 --> Router Class Initialized
INFO - 2016-07-11 07:31:31 --> Output Class Initialized
INFO - 2016-07-11 07:31:31 --> Security Class Initialized
DEBUG - 2016-07-11 07:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:31:31 --> Input Class Initialized
INFO - 2016-07-11 07:31:32 --> Language Class Initialized
INFO - 2016-07-11 07:31:32 --> Loader Class Initialized
INFO - 2016-07-11 07:31:32 --> Helper loaded: url_helper
INFO - 2016-07-11 07:31:32 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:31:32 --> Helper loaded: html_helper
INFO - 2016-07-11 07:31:32 --> Helper loaded: form_helper
INFO - 2016-07-11 07:31:32 --> Helper loaded: file_helper
INFO - 2016-07-11 07:31:32 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:31:32 --> Database Driver Class Initialized
INFO - 2016-07-11 07:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:31:32 --> Form Validation Class Initialized
INFO - 2016-07-11 07:31:32 --> Email Class Initialized
INFO - 2016-07-11 07:31:32 --> Controller Class Initialized
INFO - 2016-07-11 07:31:32 --> Model Class Initialized
ERROR - 2016-07-11 07:31:32 --> Severity: Error --> Class 'Google_Service_Oauth2' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 337
INFO - 2016-07-11 07:36:37 --> Config Class Initialized
INFO - 2016-07-11 07:36:37 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:36:37 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:36:37 --> Utf8 Class Initialized
INFO - 2016-07-11 07:36:37 --> URI Class Initialized
INFO - 2016-07-11 07:36:37 --> Router Class Initialized
INFO - 2016-07-11 07:36:37 --> Output Class Initialized
INFO - 2016-07-11 07:36:37 --> Security Class Initialized
DEBUG - 2016-07-11 07:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:36:37 --> Input Class Initialized
INFO - 2016-07-11 07:36:37 --> Language Class Initialized
INFO - 2016-07-11 07:36:37 --> Loader Class Initialized
INFO - 2016-07-11 07:36:37 --> Helper loaded: url_helper
INFO - 2016-07-11 07:36:37 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:36:37 --> Helper loaded: html_helper
INFO - 2016-07-11 07:36:37 --> Helper loaded: form_helper
INFO - 2016-07-11 07:36:37 --> Helper loaded: file_helper
INFO - 2016-07-11 07:36:37 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:36:37 --> Database Driver Class Initialized
INFO - 2016-07-11 07:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:36:37 --> Form Validation Class Initialized
INFO - 2016-07-11 07:36:37 --> Email Class Initialized
INFO - 2016-07-11 07:36:37 --> Controller Class Initialized
INFO - 2016-07-11 07:36:37 --> Model Class Initialized
ERROR - 2016-07-11 07:36:37 --> Severity: Error --> Class 'Google_Service_Oauth2' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 338
INFO - 2016-07-11 07:48:24 --> Config Class Initialized
INFO - 2016-07-11 07:48:24 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:48:24 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:48:24 --> Utf8 Class Initialized
INFO - 2016-07-11 07:48:24 --> URI Class Initialized
INFO - 2016-07-11 07:48:24 --> Router Class Initialized
INFO - 2016-07-11 07:48:24 --> Output Class Initialized
INFO - 2016-07-11 07:48:24 --> Security Class Initialized
DEBUG - 2016-07-11 07:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:48:24 --> Input Class Initialized
INFO - 2016-07-11 07:48:24 --> Language Class Initialized
INFO - 2016-07-11 07:48:24 --> Loader Class Initialized
INFO - 2016-07-11 07:48:24 --> Helper loaded: url_helper
INFO - 2016-07-11 07:48:24 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:48:24 --> Helper loaded: html_helper
INFO - 2016-07-11 07:48:24 --> Helper loaded: form_helper
INFO - 2016-07-11 07:48:24 --> Helper loaded: file_helper
INFO - 2016-07-11 07:48:24 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:48:24 --> Database Driver Class Initialized
INFO - 2016-07-11 07:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:48:24 --> Form Validation Class Initialized
INFO - 2016-07-11 07:48:24 --> Email Class Initialized
INFO - 2016-07-11 07:48:24 --> Controller Class Initialized
INFO - 2016-07-11 07:48:24 --> Model Class Initialized
ERROR - 2016-07-11 07:48:24 --> Severity: 4096 --> Argument 1 passed to Google_Service::__construct() must be an instance of Google_Client, none given, called in D:\wamp\www\library.pnc.lan\system\core\Loader.php on line 1247 and defined D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 28
ERROR - 2016-07-11 07:48:24 --> Severity: Notice --> Undefined variable: client D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 30
ERROR - 2016-07-11 07:48:24 --> Severity: Error --> Class 'Google\Auth\OAuth2' not found D:\wamp\www\library.pnc.lan\application\third_party\Google\Client.php 923
INFO - 2016-07-11 07:50:07 --> Config Class Initialized
INFO - 2016-07-11 07:50:07 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:50:07 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:50:07 --> Utf8 Class Initialized
INFO - 2016-07-11 07:50:07 --> URI Class Initialized
INFO - 2016-07-11 07:50:07 --> Router Class Initialized
INFO - 2016-07-11 07:50:07 --> Output Class Initialized
INFO - 2016-07-11 07:50:07 --> Security Class Initialized
DEBUG - 2016-07-11 07:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:50:07 --> Input Class Initialized
INFO - 2016-07-11 07:50:07 --> Language Class Initialized
INFO - 2016-07-11 07:50:07 --> Loader Class Initialized
INFO - 2016-07-11 07:50:07 --> Helper loaded: url_helper
INFO - 2016-07-11 07:50:07 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:50:07 --> Helper loaded: html_helper
INFO - 2016-07-11 07:50:07 --> Helper loaded: form_helper
INFO - 2016-07-11 07:50:07 --> Helper loaded: file_helper
INFO - 2016-07-11 07:50:07 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:50:07 --> Database Driver Class Initialized
INFO - 2016-07-11 07:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:50:07 --> Form Validation Class Initialized
INFO - 2016-07-11 07:50:07 --> Email Class Initialized
INFO - 2016-07-11 07:50:07 --> Controller Class Initialized
INFO - 2016-07-11 07:50:07 --> Model Class Initialized
ERROR - 2016-07-11 07:50:07 --> Severity: 4096 --> Argument 1 passed to Google_Service::__construct() must be an instance of Google_Client, none given, called in D:\wamp\www\library.pnc.lan\system\core\Loader.php on line 1247 and defined D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 28
ERROR - 2016-07-11 07:50:07 --> Severity: Notice --> Undefined variable: client D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 30
ERROR - 2016-07-11 07:50:07 --> Severity: Error --> Class 'Google_Service_Oauth2' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 340
INFO - 2016-07-11 07:50:10 --> Config Class Initialized
INFO - 2016-07-11 07:50:10 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:50:10 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:50:10 --> Utf8 Class Initialized
INFO - 2016-07-11 07:50:10 --> URI Class Initialized
INFO - 2016-07-11 07:50:10 --> Router Class Initialized
INFO - 2016-07-11 07:50:10 --> Output Class Initialized
INFO - 2016-07-11 07:50:10 --> Security Class Initialized
DEBUG - 2016-07-11 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:50:10 --> Input Class Initialized
INFO - 2016-07-11 07:50:10 --> Language Class Initialized
INFO - 2016-07-11 07:50:10 --> Loader Class Initialized
INFO - 2016-07-11 07:50:10 --> Helper loaded: url_helper
INFO - 2016-07-11 07:50:10 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:50:10 --> Helper loaded: html_helper
INFO - 2016-07-11 07:50:10 --> Helper loaded: form_helper
INFO - 2016-07-11 07:50:10 --> Helper loaded: file_helper
INFO - 2016-07-11 07:50:10 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:50:10 --> Database Driver Class Initialized
INFO - 2016-07-11 07:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:50:10 --> Form Validation Class Initialized
INFO - 2016-07-11 07:50:10 --> Email Class Initialized
INFO - 2016-07-11 07:50:10 --> Controller Class Initialized
INFO - 2016-07-11 07:50:10 --> Model Class Initialized
ERROR - 2016-07-11 07:50:10 --> Severity: 4096 --> Argument 1 passed to Google_Service::__construct() must be an instance of Google_Client, none given, called in D:\wamp\www\library.pnc.lan\system\core\Loader.php on line 1247 and defined D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 28
ERROR - 2016-07-11 07:50:10 --> Severity: Notice --> Undefined variable: client D:\wamp\www\library.pnc.lan\application\third_party\Google\Service.php 30
ERROR - 2016-07-11 07:50:10 --> Severity: Error --> Class 'Google_Service_Oauth2' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 340
INFO - 2016-07-11 07:50:40 --> Config Class Initialized
INFO - 2016-07-11 07:50:40 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:50:40 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:50:40 --> Utf8 Class Initialized
INFO - 2016-07-11 07:50:40 --> URI Class Initialized
INFO - 2016-07-11 07:50:40 --> Router Class Initialized
INFO - 2016-07-11 07:50:40 --> Output Class Initialized
INFO - 2016-07-11 07:50:40 --> Security Class Initialized
DEBUG - 2016-07-11 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:50:40 --> Input Class Initialized
INFO - 2016-07-11 07:50:40 --> Language Class Initialized
INFO - 2016-07-11 07:50:40 --> Loader Class Initialized
INFO - 2016-07-11 07:50:40 --> Helper loaded: url_helper
INFO - 2016-07-11 07:50:40 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:50:40 --> Helper loaded: html_helper
INFO - 2016-07-11 07:50:40 --> Helper loaded: form_helper
INFO - 2016-07-11 07:50:40 --> Helper loaded: file_helper
INFO - 2016-07-11 07:50:40 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:50:40 --> Database Driver Class Initialized
INFO - 2016-07-11 07:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:50:41 --> Form Validation Class Initialized
INFO - 2016-07-11 07:50:41 --> Email Class Initialized
INFO - 2016-07-11 07:50:41 --> Controller Class Initialized
INFO - 2016-07-11 07:50:41 --> Model Class Initialized
ERROR - 2016-07-11 07:50:41 --> Severity: Error --> Class 'Google_Service_Oauth2' not found D:\wamp\www\library.pnc.lan\application\controllers\Connection.php 340
INFO - 2016-07-11 07:53:30 --> Config Class Initialized
INFO - 2016-07-11 07:53:30 --> Hooks Class Initialized
DEBUG - 2016-07-11 07:53:30 --> UTF-8 Support Enabled
INFO - 2016-07-11 07:53:30 --> Utf8 Class Initialized
INFO - 2016-07-11 07:53:30 --> URI Class Initialized
INFO - 2016-07-11 07:53:30 --> Router Class Initialized
INFO - 2016-07-11 07:53:30 --> Output Class Initialized
INFO - 2016-07-11 07:53:30 --> Security Class Initialized
DEBUG - 2016-07-11 07:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 07:53:30 --> Input Class Initialized
INFO - 2016-07-11 07:53:30 --> Language Class Initialized
INFO - 2016-07-11 07:53:30 --> Loader Class Initialized
INFO - 2016-07-11 07:53:30 --> Helper loaded: url_helper
INFO - 2016-07-11 07:53:30 --> Helper loaded: utils_helper
INFO - 2016-07-11 07:53:30 --> Helper loaded: html_helper
INFO - 2016-07-11 07:53:30 --> Helper loaded: form_helper
INFO - 2016-07-11 07:53:30 --> Helper loaded: file_helper
INFO - 2016-07-11 07:53:30 --> Helper loaded: myemail_helper
INFO - 2016-07-11 07:53:30 --> Database Driver Class Initialized
INFO - 2016-07-11 07:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 07:53:30 --> Form Validation Class Initialized
INFO - 2016-07-11 07:53:30 --> Email Class Initialized
INFO - 2016-07-11 07:53:30 --> Controller Class Initialized
INFO - 2016-07-11 07:53:30 --> Model Class Initialized
ERROR - 2016-07-11 07:53:30 --> Severity: Error --> Class 'Google\Auth\OAuth2' not found D:\wamp\www\library.pnc.lan\application\third_party\Google\Client.php 923
INFO - 2016-07-11 10:31:36 --> Config Class Initialized
INFO - 2016-07-11 10:31:36 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:31:36 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:31:36 --> Utf8 Class Initialized
INFO - 2016-07-11 10:31:36 --> URI Class Initialized
DEBUG - 2016-07-11 10:31:36 --> No URI present. Default controller set.
INFO - 2016-07-11 10:31:36 --> Router Class Initialized
INFO - 2016-07-11 10:31:36 --> Output Class Initialized
INFO - 2016-07-11 10:31:36 --> Security Class Initialized
DEBUG - 2016-07-11 10:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:31:36 --> Input Class Initialized
INFO - 2016-07-11 10:31:36 --> Language Class Initialized
INFO - 2016-07-11 10:31:36 --> Loader Class Initialized
INFO - 2016-07-11 10:31:36 --> Helper loaded: url_helper
INFO - 2016-07-11 10:31:36 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:31:36 --> Helper loaded: html_helper
INFO - 2016-07-11 10:31:36 --> Helper loaded: form_helper
INFO - 2016-07-11 10:31:36 --> Helper loaded: file_helper
INFO - 2016-07-11 10:31:36 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:31:36 --> Database Driver Class Initialized
INFO - 2016-07-11 10:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:31:36 --> Form Validation Class Initialized
INFO - 2016-07-11 10:31:36 --> Email Class Initialized
INFO - 2016-07-11 10:31:37 --> Controller Class Initialized
INFO - 2016-07-11 10:31:37 --> Config Class Initialized
INFO - 2016-07-11 10:31:37 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:31:37 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:31:37 --> Utf8 Class Initialized
INFO - 2016-07-11 10:31:37 --> URI Class Initialized
INFO - 2016-07-11 10:31:37 --> Router Class Initialized
INFO - 2016-07-11 10:31:37 --> Output Class Initialized
INFO - 2016-07-11 10:31:37 --> Security Class Initialized
DEBUG - 2016-07-11 10:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:31:37 --> Input Class Initialized
INFO - 2016-07-11 10:31:37 --> Language Class Initialized
INFO - 2016-07-11 10:31:37 --> Loader Class Initialized
INFO - 2016-07-11 10:31:37 --> Helper loaded: url_helper
INFO - 2016-07-11 10:31:37 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:31:37 --> Helper loaded: html_helper
INFO - 2016-07-11 10:31:37 --> Helper loaded: form_helper
INFO - 2016-07-11 10:31:37 --> Helper loaded: file_helper
INFO - 2016-07-11 10:31:37 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:31:37 --> Database Driver Class Initialized
INFO - 2016-07-11 10:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:31:37 --> Form Validation Class Initialized
INFO - 2016-07-11 10:31:37 --> Email Class Initialized
INFO - 2016-07-11 10:31:37 --> Controller Class Initialized
INFO - 2016-07-11 10:31:37 --> Model Class Initialized
DEBUG - 2016-07-11 10:31:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:31:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:31:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:31:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:31:37 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:31:37 --> Final output sent to browser
DEBUG - 2016-07-11 10:31:37 --> Total execution time: 0.2960
INFO - 2016-07-11 10:32:47 --> Config Class Initialized
INFO - 2016-07-11 10:32:47 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:32:47 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:32:47 --> Utf8 Class Initialized
INFO - 2016-07-11 10:32:47 --> URI Class Initialized
INFO - 2016-07-11 10:32:47 --> Router Class Initialized
INFO - 2016-07-11 10:32:47 --> Output Class Initialized
INFO - 2016-07-11 10:32:47 --> Security Class Initialized
DEBUG - 2016-07-11 10:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:32:47 --> Input Class Initialized
INFO - 2016-07-11 10:32:47 --> Language Class Initialized
INFO - 2016-07-11 10:32:47 --> Loader Class Initialized
INFO - 2016-07-11 10:32:47 --> Helper loaded: url_helper
INFO - 2016-07-11 10:32:47 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:32:47 --> Helper loaded: html_helper
INFO - 2016-07-11 10:32:47 --> Helper loaded: form_helper
INFO - 2016-07-11 10:32:47 --> Helper loaded: file_helper
INFO - 2016-07-11 10:32:47 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:32:47 --> Database Driver Class Initialized
INFO - 2016-07-11 10:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:32:47 --> Form Validation Class Initialized
INFO - 2016-07-11 10:32:47 --> Email Class Initialized
INFO - 2016-07-11 10:32:47 --> Controller Class Initialized
INFO - 2016-07-11 10:32:47 --> Model Class Initialized
DEBUG - 2016-07-11 10:32:47 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:32:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:32:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:32:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:32:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:32:47 --> Final output sent to browser
DEBUG - 2016-07-11 10:32:47 --> Total execution time: 0.3161
INFO - 2016-07-11 10:34:50 --> Config Class Initialized
INFO - 2016-07-11 10:34:50 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:34:50 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:34:50 --> Utf8 Class Initialized
INFO - 2016-07-11 10:34:50 --> URI Class Initialized
INFO - 2016-07-11 10:34:50 --> Router Class Initialized
INFO - 2016-07-11 10:34:50 --> Output Class Initialized
INFO - 2016-07-11 10:34:50 --> Security Class Initialized
DEBUG - 2016-07-11 10:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:34:50 --> Input Class Initialized
INFO - 2016-07-11 10:34:50 --> Language Class Initialized
INFO - 2016-07-11 10:34:50 --> Loader Class Initialized
INFO - 2016-07-11 10:34:50 --> Helper loaded: url_helper
INFO - 2016-07-11 10:34:50 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:34:50 --> Helper loaded: html_helper
INFO - 2016-07-11 10:34:50 --> Helper loaded: form_helper
INFO - 2016-07-11 10:34:50 --> Helper loaded: file_helper
INFO - 2016-07-11 10:34:50 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:34:50 --> Database Driver Class Initialized
INFO - 2016-07-11 10:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:34:51 --> Form Validation Class Initialized
INFO - 2016-07-11 10:34:51 --> Email Class Initialized
INFO - 2016-07-11 10:34:51 --> Controller Class Initialized
INFO - 2016-07-11 10:34:51 --> Model Class Initialized
DEBUG - 2016-07-11 10:34:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:34:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:34:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:34:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:34:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:34:51 --> Final output sent to browser
DEBUG - 2016-07-11 10:34:51 --> Total execution time: 0.2789
INFO - 2016-07-11 10:36:48 --> Config Class Initialized
INFO - 2016-07-11 10:36:48 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:36:48 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:36:48 --> Utf8 Class Initialized
INFO - 2016-07-11 10:36:48 --> URI Class Initialized
INFO - 2016-07-11 10:36:48 --> Router Class Initialized
INFO - 2016-07-11 10:36:48 --> Output Class Initialized
INFO - 2016-07-11 10:36:48 --> Security Class Initialized
DEBUG - 2016-07-11 10:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:36:48 --> Input Class Initialized
INFO - 2016-07-11 10:36:48 --> Language Class Initialized
INFO - 2016-07-11 10:36:48 --> Loader Class Initialized
INFO - 2016-07-11 10:36:48 --> Helper loaded: url_helper
INFO - 2016-07-11 10:36:48 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:36:48 --> Helper loaded: html_helper
INFO - 2016-07-11 10:36:48 --> Helper loaded: form_helper
INFO - 2016-07-11 10:36:48 --> Helper loaded: file_helper
INFO - 2016-07-11 10:36:48 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:36:48 --> Database Driver Class Initialized
INFO - 2016-07-11 10:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:36:48 --> Form Validation Class Initialized
INFO - 2016-07-11 10:36:48 --> Email Class Initialized
INFO - 2016-07-11 10:36:48 --> Controller Class Initialized
INFO - 2016-07-11 10:36:48 --> Model Class Initialized
DEBUG - 2016-07-11 10:36:48 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:36:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:36:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:36:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:36:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:36:48 --> Final output sent to browser
DEBUG - 2016-07-11 10:36:48 --> Total execution time: 0.2898
INFO - 2016-07-11 10:37:30 --> Config Class Initialized
INFO - 2016-07-11 10:37:30 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:37:30 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:37:30 --> Utf8 Class Initialized
INFO - 2016-07-11 10:37:30 --> URI Class Initialized
INFO - 2016-07-11 10:37:30 --> Router Class Initialized
INFO - 2016-07-11 10:37:30 --> Output Class Initialized
INFO - 2016-07-11 10:37:30 --> Security Class Initialized
DEBUG - 2016-07-11 10:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:37:30 --> Input Class Initialized
INFO - 2016-07-11 10:37:30 --> Language Class Initialized
INFO - 2016-07-11 10:37:30 --> Loader Class Initialized
INFO - 2016-07-11 10:37:30 --> Helper loaded: url_helper
INFO - 2016-07-11 10:37:30 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:37:30 --> Helper loaded: html_helper
INFO - 2016-07-11 10:37:30 --> Helper loaded: form_helper
INFO - 2016-07-11 10:37:30 --> Helper loaded: file_helper
INFO - 2016-07-11 10:37:30 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:37:30 --> Database Driver Class Initialized
INFO - 2016-07-11 10:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:37:30 --> Form Validation Class Initialized
INFO - 2016-07-11 10:37:30 --> Email Class Initialized
INFO - 2016-07-11 10:37:30 --> Controller Class Initialized
INFO - 2016-07-11 10:37:30 --> Model Class Initialized
DEBUG - 2016-07-11 10:37:30 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:37:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:37:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:37:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:37:30 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:37:30 --> Final output sent to browser
DEBUG - 2016-07-11 10:37:30 --> Total execution time: 0.3620
INFO - 2016-07-11 10:40:27 --> Config Class Initialized
INFO - 2016-07-11 10:40:27 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:40:27 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:40:27 --> Utf8 Class Initialized
INFO - 2016-07-11 10:40:27 --> URI Class Initialized
INFO - 2016-07-11 10:40:27 --> Router Class Initialized
INFO - 2016-07-11 10:40:27 --> Output Class Initialized
INFO - 2016-07-11 10:40:27 --> Security Class Initialized
DEBUG - 2016-07-11 10:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:40:27 --> Input Class Initialized
INFO - 2016-07-11 10:40:27 --> Language Class Initialized
INFO - 2016-07-11 10:40:27 --> Loader Class Initialized
INFO - 2016-07-11 10:40:27 --> Helper loaded: url_helper
INFO - 2016-07-11 10:40:27 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:40:27 --> Helper loaded: html_helper
INFO - 2016-07-11 10:40:27 --> Helper loaded: form_helper
INFO - 2016-07-11 10:40:27 --> Helper loaded: file_helper
INFO - 2016-07-11 10:40:27 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:40:27 --> Database Driver Class Initialized
INFO - 2016-07-11 10:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:40:27 --> Form Validation Class Initialized
INFO - 2016-07-11 10:40:27 --> Email Class Initialized
INFO - 2016-07-11 10:40:27 --> Controller Class Initialized
INFO - 2016-07-11 10:40:27 --> Model Class Initialized
DEBUG - 2016-07-11 10:40:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:40:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:40:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:40:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:40:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:40:27 --> Final output sent to browser
DEBUG - 2016-07-11 10:40:27 --> Total execution time: 0.2874
INFO - 2016-07-11 10:41:27 --> Config Class Initialized
INFO - 2016-07-11 10:41:27 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:41:27 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:41:27 --> Utf8 Class Initialized
INFO - 2016-07-11 10:41:27 --> URI Class Initialized
INFO - 2016-07-11 10:41:27 --> Router Class Initialized
INFO - 2016-07-11 10:41:27 --> Output Class Initialized
INFO - 2016-07-11 10:41:27 --> Security Class Initialized
DEBUG - 2016-07-11 10:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:41:27 --> Input Class Initialized
INFO - 2016-07-11 10:41:27 --> Language Class Initialized
INFO - 2016-07-11 10:41:27 --> Loader Class Initialized
INFO - 2016-07-11 10:41:27 --> Helper loaded: url_helper
INFO - 2016-07-11 10:41:27 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:41:27 --> Helper loaded: html_helper
INFO - 2016-07-11 10:41:27 --> Helper loaded: form_helper
INFO - 2016-07-11 10:41:27 --> Helper loaded: file_helper
INFO - 2016-07-11 10:41:27 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:41:27 --> Database Driver Class Initialized
INFO - 2016-07-11 10:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:41:27 --> Form Validation Class Initialized
INFO - 2016-07-11 10:41:27 --> Email Class Initialized
INFO - 2016-07-11 10:41:27 --> Controller Class Initialized
INFO - 2016-07-11 10:41:27 --> Model Class Initialized
DEBUG - 2016-07-11 10:41:27 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:41:27 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:41:27 --> Final output sent to browser
DEBUG - 2016-07-11 10:41:27 --> Total execution time: 0.2841
INFO - 2016-07-11 10:41:39 --> Config Class Initialized
INFO - 2016-07-11 10:41:39 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:41:39 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:41:39 --> Utf8 Class Initialized
INFO - 2016-07-11 10:41:39 --> URI Class Initialized
INFO - 2016-07-11 10:41:39 --> Router Class Initialized
INFO - 2016-07-11 10:41:39 --> Output Class Initialized
INFO - 2016-07-11 10:41:39 --> Security Class Initialized
DEBUG - 2016-07-11 10:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:41:39 --> Input Class Initialized
INFO - 2016-07-11 10:41:39 --> Language Class Initialized
INFO - 2016-07-11 10:41:39 --> Loader Class Initialized
INFO - 2016-07-11 10:41:39 --> Helper loaded: url_helper
INFO - 2016-07-11 10:41:39 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:41:39 --> Helper loaded: html_helper
INFO - 2016-07-11 10:41:39 --> Helper loaded: form_helper
INFO - 2016-07-11 10:41:39 --> Helper loaded: file_helper
INFO - 2016-07-11 10:41:39 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:41:39 --> Database Driver Class Initialized
INFO - 2016-07-11 10:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:41:39 --> Form Validation Class Initialized
INFO - 2016-07-11 10:41:39 --> Email Class Initialized
INFO - 2016-07-11 10:41:39 --> Controller Class Initialized
INFO - 2016-07-11 10:41:39 --> Model Class Initialized
DEBUG - 2016-07-11 10:41:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:41:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:41:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:41:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:41:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:41:39 --> Final output sent to browser
DEBUG - 2016-07-11 10:41:39 --> Total execution time: 0.2949
INFO - 2016-07-11 10:45:44 --> Config Class Initialized
INFO - 2016-07-11 10:45:44 --> Hooks Class Initialized
DEBUG - 2016-07-11 10:45:44 --> UTF-8 Support Enabled
INFO - 2016-07-11 10:45:44 --> Utf8 Class Initialized
INFO - 2016-07-11 10:45:44 --> URI Class Initialized
INFO - 2016-07-11 10:45:44 --> Router Class Initialized
INFO - 2016-07-11 10:45:44 --> Output Class Initialized
INFO - 2016-07-11 10:45:44 --> Security Class Initialized
DEBUG - 2016-07-11 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-07-11 10:45:44 --> Input Class Initialized
INFO - 2016-07-11 10:45:44 --> Language Class Initialized
INFO - 2016-07-11 10:45:44 --> Loader Class Initialized
INFO - 2016-07-11 10:45:44 --> Helper loaded: url_helper
INFO - 2016-07-11 10:45:44 --> Helper loaded: utils_helper
INFO - 2016-07-11 10:45:44 --> Helper loaded: html_helper
INFO - 2016-07-11 10:45:44 --> Helper loaded: form_helper
INFO - 2016-07-11 10:45:44 --> Helper loaded: file_helper
INFO - 2016-07-11 10:45:44 --> Helper loaded: myemail_helper
INFO - 2016-07-11 10:45:44 --> Database Driver Class Initialized
INFO - 2016-07-11 10:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2016-07-11 10:45:44 --> Form Validation Class Initialized
INFO - 2016-07-11 10:45:44 --> Email Class Initialized
INFO - 2016-07-11 10:45:44 --> Controller Class Initialized
INFO - 2016-07-11 10:45:44 --> Model Class Initialized
DEBUG - 2016-07-11 10:45:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-07-11 10:45:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-07-11 10:45:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-07-11 10:45:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-07-11 10:45:44 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-07-11 10:45:44 --> Final output sent to browser
DEBUG - 2016-07-11 10:45:44 --> Total execution time: 0.2826
