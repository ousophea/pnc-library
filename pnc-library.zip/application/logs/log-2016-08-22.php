<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-22 07:03:38 --> Config Class Initialized
INFO - 2016-08-22 07:03:38 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:38 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:38 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:38 --> URI Class Initialized
DEBUG - 2016-08-22 07:03:38 --> No URI present. Default controller set.
INFO - 2016-08-22 07:03:38 --> Router Class Initialized
INFO - 2016-08-22 07:03:38 --> Output Class Initialized
INFO - 2016-08-22 07:03:38 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:38 --> Input Class Initialized
INFO - 2016-08-22 07:03:38 --> Language Class Initialized
INFO - 2016-08-22 07:03:38 --> Loader Class Initialized
INFO - 2016-08-22 07:03:38 --> Helper loaded: url_helper
INFO - 2016-08-22 07:03:39 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:03:39 --> Helper loaded: html_helper
INFO - 2016-08-22 07:03:39 --> Helper loaded: form_helper
INFO - 2016-08-22 07:03:39 --> Helper loaded: file_helper
INFO - 2016-08-22 07:03:39 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:03:39 --> Database Driver Class Initialized
INFO - 2016-08-22 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:03:39 --> Form Validation Class Initialized
INFO - 2016-08-22 07:03:39 --> Email Class Initialized
INFO - 2016-08-22 07:03:39 --> Controller Class Initialized
INFO - 2016-08-22 07:03:39 --> Model Class Initialized
INFO - 2016-08-22 07:03:39 --> Model Class Initialized
INFO - 2016-08-22 07:03:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:03:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:03:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:03:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:03:39 --> Final output sent to browser
DEBUG - 2016-08-22 07:03:39 --> Total execution time: 0.9603
INFO - 2016-08-22 07:03:40 --> Config Class Initialized
INFO - 2016-08-22 07:03:40 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:40 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:40 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:40 --> URI Class Initialized
INFO - 2016-08-22 07:03:40 --> Router Class Initialized
INFO - 2016-08-22 07:03:40 --> Output Class Initialized
INFO - 2016-08-22 07:03:40 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:40 --> Input Class Initialized
INFO - 2016-08-22 07:03:40 --> Language Class Initialized
ERROR - 2016-08-22 07:03:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:03:40 --> Config Class Initialized
INFO - 2016-08-22 07:03:40 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:40 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:40 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:40 --> URI Class Initialized
INFO - 2016-08-22 07:03:40 --> Router Class Initialized
INFO - 2016-08-22 07:03:40 --> Output Class Initialized
INFO - 2016-08-22 07:03:40 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:40 --> Input Class Initialized
INFO - 2016-08-22 07:03:40 --> Language Class Initialized
ERROR - 2016-08-22 07:03:40 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:03:46 --> Config Class Initialized
INFO - 2016-08-22 07:03:46 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:46 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:46 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:46 --> URI Class Initialized
DEBUG - 2016-08-22 07:03:46 --> No URI present. Default controller set.
INFO - 2016-08-22 07:03:46 --> Router Class Initialized
INFO - 2016-08-22 07:03:46 --> Output Class Initialized
INFO - 2016-08-22 07:03:46 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:46 --> Input Class Initialized
INFO - 2016-08-22 07:03:46 --> Language Class Initialized
INFO - 2016-08-22 07:03:46 --> Loader Class Initialized
INFO - 2016-08-22 07:03:46 --> Helper loaded: url_helper
INFO - 2016-08-22 07:03:46 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:03:46 --> Helper loaded: html_helper
INFO - 2016-08-22 07:03:46 --> Helper loaded: form_helper
INFO - 2016-08-22 07:03:46 --> Helper loaded: file_helper
INFO - 2016-08-22 07:03:46 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:03:46 --> Database Driver Class Initialized
INFO - 2016-08-22 07:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:03:46 --> Form Validation Class Initialized
INFO - 2016-08-22 07:03:46 --> Email Class Initialized
INFO - 2016-08-22 07:03:46 --> Controller Class Initialized
INFO - 2016-08-22 07:03:46 --> Model Class Initialized
INFO - 2016-08-22 07:03:46 --> Model Class Initialized
INFO - 2016-08-22 07:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:03:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:03:46 --> Final output sent to browser
DEBUG - 2016-08-22 07:03:46 --> Total execution time: 0.2134
INFO - 2016-08-22 07:03:48 --> Config Class Initialized
INFO - 2016-08-22 07:03:48 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:48 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:48 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:48 --> URI Class Initialized
DEBUG - 2016-08-22 07:03:48 --> No URI present. Default controller set.
INFO - 2016-08-22 07:03:48 --> Router Class Initialized
INFO - 2016-08-22 07:03:48 --> Output Class Initialized
INFO - 2016-08-22 07:03:48 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:48 --> Input Class Initialized
INFO - 2016-08-22 07:03:48 --> Language Class Initialized
INFO - 2016-08-22 07:03:48 --> Loader Class Initialized
INFO - 2016-08-22 07:03:48 --> Helper loaded: url_helper
INFO - 2016-08-22 07:03:48 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:03:48 --> Helper loaded: html_helper
INFO - 2016-08-22 07:03:48 --> Helper loaded: form_helper
INFO - 2016-08-22 07:03:48 --> Helper loaded: file_helper
INFO - 2016-08-22 07:03:48 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:03:48 --> Database Driver Class Initialized
INFO - 2016-08-22 07:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:03:48 --> Form Validation Class Initialized
INFO - 2016-08-22 07:03:48 --> Email Class Initialized
INFO - 2016-08-22 07:03:48 --> Controller Class Initialized
INFO - 2016-08-22 07:03:48 --> Model Class Initialized
INFO - 2016-08-22 07:03:48 --> Model Class Initialized
INFO - 2016-08-22 07:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:03:48 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:03:48 --> Final output sent to browser
DEBUG - 2016-08-22 07:03:48 --> Total execution time: 0.2396
INFO - 2016-08-22 07:03:55 --> Config Class Initialized
INFO - 2016-08-22 07:03:55 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:03:55 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:03:55 --> Utf8 Class Initialized
INFO - 2016-08-22 07:03:55 --> URI Class Initialized
DEBUG - 2016-08-22 07:03:55 --> No URI present. Default controller set.
INFO - 2016-08-22 07:03:55 --> Router Class Initialized
INFO - 2016-08-22 07:03:55 --> Output Class Initialized
INFO - 2016-08-22 07:03:55 --> Security Class Initialized
DEBUG - 2016-08-22 07:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:03:55 --> Input Class Initialized
INFO - 2016-08-22 07:03:55 --> Language Class Initialized
INFO - 2016-08-22 07:03:55 --> Loader Class Initialized
INFO - 2016-08-22 07:03:55 --> Helper loaded: url_helper
INFO - 2016-08-22 07:03:55 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:03:55 --> Helper loaded: html_helper
INFO - 2016-08-22 07:03:55 --> Helper loaded: form_helper
INFO - 2016-08-22 07:03:55 --> Helper loaded: file_helper
INFO - 2016-08-22 07:03:55 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:03:55 --> Database Driver Class Initialized
INFO - 2016-08-22 07:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:03:55 --> Form Validation Class Initialized
INFO - 2016-08-22 07:03:55 --> Email Class Initialized
INFO - 2016-08-22 07:03:55 --> Controller Class Initialized
INFO - 2016-08-22 07:03:55 --> Model Class Initialized
INFO - 2016-08-22 07:03:55 --> Model Class Initialized
INFO - 2016-08-22 07:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:03:55 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:03:55 --> Final output sent to browser
DEBUG - 2016-08-22 07:03:55 --> Total execution time: 0.2311
INFO - 2016-08-22 07:09:12 --> Config Class Initialized
INFO - 2016-08-22 07:09:12 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:12 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:12 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:12 --> URI Class Initialized
INFO - 2016-08-22 07:09:12 --> Router Class Initialized
INFO - 2016-08-22 07:09:12 --> Output Class Initialized
INFO - 2016-08-22 07:09:12 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:12 --> Input Class Initialized
INFO - 2016-08-22 07:09:12 --> Language Class Initialized
INFO - 2016-08-22 07:09:12 --> Loader Class Initialized
INFO - 2016-08-22 07:09:12 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:12 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:12 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:12 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:12 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:12 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:12 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:12 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:12 --> Email Class Initialized
INFO - 2016-08-22 07:09:12 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:12 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:12 --> Model Class Initialized
INFO - 2016-08-22 07:09:12 --> Model Class Initialized
INFO - 2016-08-22 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:12 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:12 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:12 --> Total execution time: 0.3698
INFO - 2016-08-22 07:09:23 --> Config Class Initialized
INFO - 2016-08-22 07:09:23 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:23 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:23 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:23 --> URI Class Initialized
INFO - 2016-08-22 07:09:23 --> Router Class Initialized
INFO - 2016-08-22 07:09:23 --> Output Class Initialized
INFO - 2016-08-22 07:09:23 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:23 --> Input Class Initialized
INFO - 2016-08-22 07:09:23 --> Language Class Initialized
INFO - 2016-08-22 07:09:23 --> Loader Class Initialized
INFO - 2016-08-22 07:09:23 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:23 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:23 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:23 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:23 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:23 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:23 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:23 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:23 --> Email Class Initialized
INFO - 2016-08-22 07:09:23 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:23 --> Model Class Initialized
INFO - 2016-08-22 07:09:23 --> Model Class Initialized
INFO - 2016-08-22 07:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:23 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:23 --> Total execution time: 0.3255
INFO - 2016-08-22 07:09:28 --> Config Class Initialized
INFO - 2016-08-22 07:09:28 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:28 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:28 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:28 --> URI Class Initialized
INFO - 2016-08-22 07:09:28 --> Router Class Initialized
INFO - 2016-08-22 07:09:28 --> Output Class Initialized
INFO - 2016-08-22 07:09:28 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:28 --> Input Class Initialized
INFO - 2016-08-22 07:09:28 --> Language Class Initialized
INFO - 2016-08-22 07:09:28 --> Loader Class Initialized
INFO - 2016-08-22 07:09:28 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:28 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:28 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:28 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:28 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:28 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:28 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:28 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:28 --> Email Class Initialized
INFO - 2016-08-22 07:09:28 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:28 --> Model Class Initialized
INFO - 2016-08-22 07:09:28 --> Model Class Initialized
INFO - 2016-08-22 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:28 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:28 --> Total execution time: 0.3779
INFO - 2016-08-22 07:09:31 --> Config Class Initialized
INFO - 2016-08-22 07:09:31 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:31 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:31 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:31 --> URI Class Initialized
INFO - 2016-08-22 07:09:31 --> Router Class Initialized
INFO - 2016-08-22 07:09:31 --> Output Class Initialized
INFO - 2016-08-22 07:09:31 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:31 --> Input Class Initialized
INFO - 2016-08-22 07:09:31 --> Language Class Initialized
INFO - 2016-08-22 07:09:31 --> Loader Class Initialized
INFO - 2016-08-22 07:09:31 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:31 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:31 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:31 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:31 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:31 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:31 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:31 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:31 --> Email Class Initialized
INFO - 2016-08-22 07:09:31 --> Controller Class Initialized
INFO - 2016-08-22 07:09:31 --> Model Class Initialized
INFO - 2016-08-22 07:09:32 --> Config Class Initialized
INFO - 2016-08-22 07:09:32 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:32 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:32 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:32 --> URI Class Initialized
INFO - 2016-08-22 07:09:32 --> Router Class Initialized
INFO - 2016-08-22 07:09:32 --> Output Class Initialized
INFO - 2016-08-22 07:09:32 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:32 --> Input Class Initialized
INFO - 2016-08-22 07:09:32 --> Language Class Initialized
INFO - 2016-08-22 07:09:32 --> Loader Class Initialized
INFO - 2016-08-22 07:09:32 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:32 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:32 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:32 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:32 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:32 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:32 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:32 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:32 --> Email Class Initialized
INFO - 2016-08-22 07:09:32 --> Controller Class Initialized
INFO - 2016-08-22 07:09:32 --> Model Class Initialized
DEBUG - 2016-08-22 07:09:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 07:09:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 07:09:32 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:32 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:32 --> Total execution time: 0.2392
INFO - 2016-08-22 07:09:37 --> Config Class Initialized
INFO - 2016-08-22 07:09:37 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:37 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:37 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:37 --> URI Class Initialized
INFO - 2016-08-22 07:09:37 --> Router Class Initialized
INFO - 2016-08-22 07:09:37 --> Output Class Initialized
INFO - 2016-08-22 07:09:37 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:37 --> Input Class Initialized
INFO - 2016-08-22 07:09:37 --> Language Class Initialized
INFO - 2016-08-22 07:09:37 --> Loader Class Initialized
INFO - 2016-08-22 07:09:37 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:37 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:37 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:37 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:37 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:37 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:37 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:37 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:37 --> Email Class Initialized
INFO - 2016-08-22 07:09:37 --> Controller Class Initialized
INFO - 2016-08-22 07:09:37 --> Model Class Initialized
DEBUG - 2016-08-22 07:09:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-22 07:09:37 --> Config Class Initialized
INFO - 2016-08-22 07:09:37 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:37 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:37 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:37 --> URI Class Initialized
INFO - 2016-08-22 07:09:37 --> Router Class Initialized
INFO - 2016-08-22 07:09:37 --> Output Class Initialized
INFO - 2016-08-22 07:09:37 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:37 --> Input Class Initialized
INFO - 2016-08-22 07:09:37 --> Language Class Initialized
INFO - 2016-08-22 07:09:38 --> Loader Class Initialized
INFO - 2016-08-22 07:09:38 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:38 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:38 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:38 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:38 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:38 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:38 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:38 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:38 --> Email Class Initialized
INFO - 2016-08-22 07:09:38 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:38 --> Model Class Initialized
INFO - 2016-08-22 07:09:38 --> Model Class Initialized
INFO - 2016-08-22 07:09:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:38 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:38 --> Total execution time: 0.3317
INFO - 2016-08-22 07:09:46 --> Config Class Initialized
INFO - 2016-08-22 07:09:46 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:46 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:46 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:46 --> URI Class Initialized
INFO - 2016-08-22 07:09:46 --> Router Class Initialized
INFO - 2016-08-22 07:09:46 --> Output Class Initialized
INFO - 2016-08-22 07:09:46 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:46 --> Input Class Initialized
INFO - 2016-08-22 07:09:46 --> Language Class Initialized
INFO - 2016-08-22 07:09:46 --> Loader Class Initialized
INFO - 2016-08-22 07:09:46 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:46 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:46 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:46 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:46 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:46 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:46 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:46 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:46 --> Email Class Initialized
INFO - 2016-08-22 07:09:46 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:46 --> Model Class Initialized
INFO - 2016-08-22 07:09:46 --> Model Class Initialized
INFO - 2016-08-22 07:09:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:46 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:46 --> Total execution time: 0.3596
INFO - 2016-08-22 07:09:49 --> Config Class Initialized
INFO - 2016-08-22 07:09:49 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:49 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:49 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:50 --> URI Class Initialized
INFO - 2016-08-22 07:09:50 --> Router Class Initialized
INFO - 2016-08-22 07:09:50 --> Output Class Initialized
INFO - 2016-08-22 07:09:50 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:50 --> Input Class Initialized
INFO - 2016-08-22 07:09:50 --> Language Class Initialized
ERROR - 2016-08-22 07:09:50 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:09:50 --> Config Class Initialized
INFO - 2016-08-22 07:09:50 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:50 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:50 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:50 --> URI Class Initialized
INFO - 2016-08-22 07:09:50 --> Router Class Initialized
INFO - 2016-08-22 07:09:50 --> Output Class Initialized
INFO - 2016-08-22 07:09:50 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:50 --> Input Class Initialized
INFO - 2016-08-22 07:09:50 --> Language Class Initialized
ERROR - 2016-08-22 07:09:50 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:09:53 --> Config Class Initialized
INFO - 2016-08-22 07:09:53 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:09:53 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:09:53 --> Utf8 Class Initialized
INFO - 2016-08-22 07:09:53 --> URI Class Initialized
INFO - 2016-08-22 07:09:53 --> Router Class Initialized
INFO - 2016-08-22 07:09:53 --> Output Class Initialized
INFO - 2016-08-22 07:09:53 --> Security Class Initialized
DEBUG - 2016-08-22 07:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:09:53 --> Input Class Initialized
INFO - 2016-08-22 07:09:53 --> Language Class Initialized
INFO - 2016-08-22 07:09:53 --> Loader Class Initialized
INFO - 2016-08-22 07:09:53 --> Helper loaded: url_helper
INFO - 2016-08-22 07:09:53 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:09:53 --> Helper loaded: html_helper
INFO - 2016-08-22 07:09:53 --> Helper loaded: form_helper
INFO - 2016-08-22 07:09:53 --> Helper loaded: file_helper
INFO - 2016-08-22 07:09:53 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:09:53 --> Database Driver Class Initialized
INFO - 2016-08-22 07:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:09:53 --> Form Validation Class Initialized
INFO - 2016-08-22 07:09:53 --> Email Class Initialized
INFO - 2016-08-22 07:09:53 --> Controller Class Initialized
DEBUG - 2016-08-22 07:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:09:53 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:09:53 --> Model Class Initialized
INFO - 2016-08-22 07:09:53 --> Model Class Initialized
INFO - 2016-08-22 07:09:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:09:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:09:53 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:09:54 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:09:54 --> Final output sent to browser
DEBUG - 2016-08-22 07:09:54 --> Total execution time: 0.3569
INFO - 2016-08-22 07:10:02 --> Config Class Initialized
INFO - 2016-08-22 07:10:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:02 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:02 --> URI Class Initialized
INFO - 2016-08-22 07:10:02 --> Router Class Initialized
INFO - 2016-08-22 07:10:02 --> Output Class Initialized
INFO - 2016-08-22 07:10:02 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:02 --> Input Class Initialized
INFO - 2016-08-22 07:10:02 --> Language Class Initialized
INFO - 2016-08-22 07:10:02 --> Loader Class Initialized
INFO - 2016-08-22 07:10:02 --> Helper loaded: url_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: html_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: form_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: file_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:10:02 --> Database Driver Class Initialized
INFO - 2016-08-22 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:10:02 --> Form Validation Class Initialized
INFO - 2016-08-22 07:10:02 --> Email Class Initialized
INFO - 2016-08-22 07:10:02 --> Controller Class Initialized
INFO - 2016-08-22 07:10:02 --> Config Class Initialized
INFO - 2016-08-22 07:10:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:02 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:02 --> URI Class Initialized
INFO - 2016-08-22 07:10:02 --> Router Class Initialized
INFO - 2016-08-22 07:10:02 --> Output Class Initialized
INFO - 2016-08-22 07:10:02 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:02 --> Input Class Initialized
INFO - 2016-08-22 07:10:02 --> Language Class Initialized
INFO - 2016-08-22 07:10:02 --> Loader Class Initialized
INFO - 2016-08-22 07:10:02 --> Helper loaded: url_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: html_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: form_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: file_helper
INFO - 2016-08-22 07:10:02 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:10:02 --> Database Driver Class Initialized
INFO - 2016-08-22 07:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:10:02 --> Form Validation Class Initialized
INFO - 2016-08-22 07:10:02 --> Email Class Initialized
INFO - 2016-08-22 07:10:02 --> Controller Class Initialized
INFO - 2016-08-22 07:10:02 --> Model Class Initialized
DEBUG - 2016-08-22 07:10:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 07:10:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:10:02 --> Final output sent to browser
DEBUG - 2016-08-22 07:10:02 --> Total execution time: 0.2232
INFO - 2016-08-22 07:10:04 --> Config Class Initialized
INFO - 2016-08-22 07:10:04 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:04 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:04 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:04 --> URI Class Initialized
INFO - 2016-08-22 07:10:04 --> Router Class Initialized
INFO - 2016-08-22 07:10:04 --> Output Class Initialized
INFO - 2016-08-22 07:10:04 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:04 --> Input Class Initialized
INFO - 2016-08-22 07:10:04 --> Language Class Initialized
ERROR - 2016-08-22 07:10:04 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:10:11 --> Config Class Initialized
INFO - 2016-08-22 07:10:11 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:11 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:11 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:11 --> URI Class Initialized
INFO - 2016-08-22 07:10:11 --> Router Class Initialized
INFO - 2016-08-22 07:10:11 --> Output Class Initialized
INFO - 2016-08-22 07:10:11 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:11 --> Input Class Initialized
INFO - 2016-08-22 07:10:11 --> Language Class Initialized
INFO - 2016-08-22 07:10:11 --> Loader Class Initialized
INFO - 2016-08-22 07:10:11 --> Helper loaded: url_helper
INFO - 2016-08-22 07:10:11 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:10:11 --> Helper loaded: html_helper
INFO - 2016-08-22 07:10:11 --> Helper loaded: form_helper
INFO - 2016-08-22 07:10:11 --> Helper loaded: file_helper
INFO - 2016-08-22 07:10:11 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:10:11 --> Database Driver Class Initialized
INFO - 2016-08-22 07:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:10:11 --> Form Validation Class Initialized
INFO - 2016-08-22 07:10:11 --> Email Class Initialized
INFO - 2016-08-22 07:10:11 --> Controller Class Initialized
DEBUG - 2016-08-22 07:10:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 07:10:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:10:11 --> Model Class Initialized
INFO - 2016-08-22 07:10:11 --> Model Class Initialized
INFO - 2016-08-22 07:10:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:10:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:10:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 07:10:11 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:10:11 --> Final output sent to browser
DEBUG - 2016-08-22 07:10:11 --> Total execution time: 0.3126
INFO - 2016-08-22 07:10:38 --> Config Class Initialized
INFO - 2016-08-22 07:10:38 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:38 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:38 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:38 --> URI Class Initialized
DEBUG - 2016-08-22 07:10:38 --> No URI present. Default controller set.
INFO - 2016-08-22 07:10:38 --> Router Class Initialized
INFO - 2016-08-22 07:10:38 --> Output Class Initialized
INFO - 2016-08-22 07:10:38 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:38 --> Input Class Initialized
INFO - 2016-08-22 07:10:38 --> Language Class Initialized
INFO - 2016-08-22 07:10:38 --> Loader Class Initialized
INFO - 2016-08-22 07:10:38 --> Helper loaded: url_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: html_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: form_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: file_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:10:38 --> Database Driver Class Initialized
INFO - 2016-08-22 07:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:10:38 --> Form Validation Class Initialized
INFO - 2016-08-22 07:10:38 --> Email Class Initialized
INFO - 2016-08-22 07:10:38 --> Controller Class Initialized
INFO - 2016-08-22 07:10:38 --> Config Class Initialized
INFO - 2016-08-22 07:10:38 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:10:38 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:10:38 --> Utf8 Class Initialized
INFO - 2016-08-22 07:10:38 --> URI Class Initialized
INFO - 2016-08-22 07:10:38 --> Router Class Initialized
INFO - 2016-08-22 07:10:38 --> Output Class Initialized
INFO - 2016-08-22 07:10:38 --> Security Class Initialized
DEBUG - 2016-08-22 07:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:10:38 --> Input Class Initialized
INFO - 2016-08-22 07:10:38 --> Language Class Initialized
INFO - 2016-08-22 07:10:38 --> Loader Class Initialized
INFO - 2016-08-22 07:10:38 --> Helper loaded: url_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: html_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: form_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: file_helper
INFO - 2016-08-22 07:10:38 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:10:38 --> Database Driver Class Initialized
INFO - 2016-08-22 07:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:10:38 --> Form Validation Class Initialized
INFO - 2016-08-22 07:10:38 --> Email Class Initialized
INFO - 2016-08-22 07:10:38 --> Controller Class Initialized
INFO - 2016-08-22 07:10:38 --> Model Class Initialized
DEBUG - 2016-08-22 07:10:38 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:10:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 07:10:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:10:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 07:10:38 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:10:38 --> Final output sent to browser
DEBUG - 2016-08-22 07:10:38 --> Total execution time: 0.2397
INFO - 2016-08-22 07:29:01 --> Config Class Initialized
INFO - 2016-08-22 07:29:01 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:29:01 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:29:01 --> Utf8 Class Initialized
INFO - 2016-08-22 07:29:01 --> URI Class Initialized
DEBUG - 2016-08-22 07:29:01 --> No URI present. Default controller set.
INFO - 2016-08-22 07:29:01 --> Router Class Initialized
INFO - 2016-08-22 07:29:01 --> Output Class Initialized
INFO - 2016-08-22 07:29:01 --> Security Class Initialized
DEBUG - 2016-08-22 07:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:29:01 --> Input Class Initialized
INFO - 2016-08-22 07:29:01 --> Language Class Initialized
INFO - 2016-08-22 07:29:01 --> Loader Class Initialized
INFO - 2016-08-22 07:29:01 --> Helper loaded: url_helper
INFO - 2016-08-22 07:29:01 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:29:01 --> Helper loaded: html_helper
INFO - 2016-08-22 07:29:01 --> Helper loaded: form_helper
INFO - 2016-08-22 07:29:01 --> Helper loaded: file_helper
INFO - 2016-08-22 07:29:01 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:29:01 --> Database Driver Class Initialized
INFO - 2016-08-22 07:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:29:01 --> Form Validation Class Initialized
INFO - 2016-08-22 07:29:01 --> Email Class Initialized
INFO - 2016-08-22 07:29:01 --> Controller Class Initialized
INFO - 2016-08-22 07:29:01 --> Model Class Initialized
INFO - 2016-08-22 07:29:01 --> Model Class Initialized
INFO - 2016-08-22 07:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:29:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:29:02 --> Final output sent to browser
DEBUG - 2016-08-22 07:29:02 --> Total execution time: 0.2478
INFO - 2016-08-22 07:29:02 --> Config Class Initialized
INFO - 2016-08-22 07:29:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:29:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:29:02 --> Utf8 Class Initialized
INFO - 2016-08-22 07:29:02 --> URI Class Initialized
INFO - 2016-08-22 07:29:02 --> Router Class Initialized
INFO - 2016-08-22 07:29:02 --> Output Class Initialized
INFO - 2016-08-22 07:29:02 --> Security Class Initialized
DEBUG - 2016-08-22 07:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:29:02 --> Input Class Initialized
INFO - 2016-08-22 07:29:02 --> Language Class Initialized
ERROR - 2016-08-22 07:29:02 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:29:02 --> Config Class Initialized
INFO - 2016-08-22 07:29:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:29:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:29:02 --> Utf8 Class Initialized
INFO - 2016-08-22 07:29:03 --> URI Class Initialized
INFO - 2016-08-22 07:29:03 --> Router Class Initialized
INFO - 2016-08-22 07:29:03 --> Output Class Initialized
INFO - 2016-08-22 07:29:03 --> Security Class Initialized
DEBUG - 2016-08-22 07:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:29:03 --> Input Class Initialized
INFO - 2016-08-22 07:29:03 --> Language Class Initialized
ERROR - 2016-08-22 07:29:03 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:29:10 --> Config Class Initialized
INFO - 2016-08-22 07:29:10 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:29:10 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:29:10 --> Utf8 Class Initialized
INFO - 2016-08-22 07:29:10 --> URI Class Initialized
DEBUG - 2016-08-22 07:29:10 --> No URI present. Default controller set.
INFO - 2016-08-22 07:29:10 --> Router Class Initialized
INFO - 2016-08-22 07:29:10 --> Output Class Initialized
INFO - 2016-08-22 07:29:10 --> Security Class Initialized
DEBUG - 2016-08-22 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:29:10 --> Input Class Initialized
INFO - 2016-08-22 07:29:10 --> Language Class Initialized
INFO - 2016-08-22 07:29:10 --> Loader Class Initialized
INFO - 2016-08-22 07:29:10 --> Helper loaded: url_helper
INFO - 2016-08-22 07:29:10 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:29:10 --> Helper loaded: html_helper
INFO - 2016-08-22 07:29:10 --> Helper loaded: form_helper
INFO - 2016-08-22 07:29:10 --> Helper loaded: file_helper
INFO - 2016-08-22 07:29:10 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:29:10 --> Database Driver Class Initialized
INFO - 2016-08-22 07:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:29:10 --> Form Validation Class Initialized
INFO - 2016-08-22 07:29:10 --> Email Class Initialized
INFO - 2016-08-22 07:29:10 --> Controller Class Initialized
INFO - 2016-08-22 07:29:10 --> Model Class Initialized
INFO - 2016-08-22 07:29:10 --> Model Class Initialized
INFO - 2016-08-22 07:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:29:10 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:29:10 --> Final output sent to browser
DEBUG - 2016-08-22 07:29:10 --> Total execution time: 0.2548
INFO - 2016-08-22 07:31:23 --> Config Class Initialized
INFO - 2016-08-22 07:31:23 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:31:23 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:31:23 --> Utf8 Class Initialized
INFO - 2016-08-22 07:31:23 --> URI Class Initialized
INFO - 2016-08-22 07:31:23 --> Router Class Initialized
INFO - 2016-08-22 07:31:23 --> Output Class Initialized
INFO - 2016-08-22 07:31:23 --> Security Class Initialized
DEBUG - 2016-08-22 07:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:31:23 --> Input Class Initialized
INFO - 2016-08-22 07:31:23 --> Language Class Initialized
INFO - 2016-08-22 07:31:23 --> Loader Class Initialized
INFO - 2016-08-22 07:31:23 --> Helper loaded: url_helper
INFO - 2016-08-22 07:31:23 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:31:23 --> Helper loaded: html_helper
INFO - 2016-08-22 07:31:23 --> Helper loaded: form_helper
INFO - 2016-08-22 07:31:23 --> Helper loaded: file_helper
INFO - 2016-08-22 07:31:23 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:31:23 --> Database Driver Class Initialized
INFO - 2016-08-22 07:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:31:23 --> Form Validation Class Initialized
INFO - 2016-08-22 07:31:23 --> Email Class Initialized
INFO - 2016-08-22 07:31:23 --> Controller Class Initialized
DEBUG - 2016-08-22 07:31:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:31:23 --> Model Class Initialized
INFO - 2016-08-22 07:31:23 --> Model Class Initialized
INFO - 2016-08-22 07:31:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:31:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:31:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-22 07:31:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:31:23 --> Final output sent to browser
DEBUG - 2016-08-22 07:31:23 --> Total execution time: 0.3553
INFO - 2016-08-22 07:33:50 --> Config Class Initialized
INFO - 2016-08-22 07:33:50 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:33:50 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:33:50 --> Utf8 Class Initialized
INFO - 2016-08-22 07:33:50 --> URI Class Initialized
DEBUG - 2016-08-22 07:33:50 --> No URI present. Default controller set.
INFO - 2016-08-22 07:33:50 --> Router Class Initialized
INFO - 2016-08-22 07:33:50 --> Output Class Initialized
INFO - 2016-08-22 07:33:50 --> Security Class Initialized
DEBUG - 2016-08-22 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:33:50 --> Input Class Initialized
INFO - 2016-08-22 07:33:50 --> Language Class Initialized
INFO - 2016-08-22 07:33:50 --> Loader Class Initialized
INFO - 2016-08-22 07:33:50 --> Helper loaded: url_helper
INFO - 2016-08-22 07:33:50 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:33:50 --> Helper loaded: html_helper
INFO - 2016-08-22 07:33:50 --> Helper loaded: form_helper
INFO - 2016-08-22 07:33:50 --> Helper loaded: file_helper
INFO - 2016-08-22 07:33:50 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:33:50 --> Database Driver Class Initialized
INFO - 2016-08-22 07:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:33:50 --> Form Validation Class Initialized
INFO - 2016-08-22 07:33:50 --> Email Class Initialized
INFO - 2016-08-22 07:33:51 --> Controller Class Initialized
INFO - 2016-08-22 07:33:51 --> Model Class Initialized
INFO - 2016-08-22 07:33:51 --> Model Class Initialized
INFO - 2016-08-22 07:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:33:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:33:51 --> Final output sent to browser
DEBUG - 2016-08-22 07:33:51 --> Total execution time: 0.2675
INFO - 2016-08-22 07:34:04 --> Config Class Initialized
INFO - 2016-08-22 07:34:04 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:34:04 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:34:04 --> Utf8 Class Initialized
INFO - 2016-08-22 07:34:04 --> URI Class Initialized
DEBUG - 2016-08-22 07:34:04 --> No URI present. Default controller set.
INFO - 2016-08-22 07:34:04 --> Router Class Initialized
INFO - 2016-08-22 07:34:04 --> Output Class Initialized
INFO - 2016-08-22 07:34:04 --> Security Class Initialized
DEBUG - 2016-08-22 07:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:34:04 --> Input Class Initialized
INFO - 2016-08-22 07:34:04 --> Language Class Initialized
INFO - 2016-08-22 07:34:04 --> Loader Class Initialized
INFO - 2016-08-22 07:34:04 --> Helper loaded: url_helper
INFO - 2016-08-22 07:34:04 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:34:04 --> Helper loaded: html_helper
INFO - 2016-08-22 07:34:04 --> Helper loaded: form_helper
INFO - 2016-08-22 07:34:04 --> Helper loaded: file_helper
INFO - 2016-08-22 07:34:04 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:34:04 --> Database Driver Class Initialized
INFO - 2016-08-22 07:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:34:04 --> Form Validation Class Initialized
INFO - 2016-08-22 07:34:04 --> Email Class Initialized
INFO - 2016-08-22 07:34:04 --> Controller Class Initialized
INFO - 2016-08-22 07:34:04 --> Model Class Initialized
INFO - 2016-08-22 07:34:04 --> Model Class Initialized
INFO - 2016-08-22 07:34:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:34:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 07:34:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 07:34:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:34:04 --> Final output sent to browser
DEBUG - 2016-08-22 07:34:04 --> Total execution time: 0.2661
INFO - 2016-08-22 07:39:08 --> Config Class Initialized
INFO - 2016-08-22 07:39:08 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:39:08 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:39:08 --> Utf8 Class Initialized
INFO - 2016-08-22 07:39:08 --> URI Class Initialized
INFO - 2016-08-22 07:39:08 --> Router Class Initialized
INFO - 2016-08-22 07:39:08 --> Output Class Initialized
INFO - 2016-08-22 07:39:08 --> Security Class Initialized
DEBUG - 2016-08-22 07:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:39:08 --> Input Class Initialized
INFO - 2016-08-22 07:39:08 --> Language Class Initialized
INFO - 2016-08-22 07:39:08 --> Loader Class Initialized
INFO - 2016-08-22 07:39:08 --> Helper loaded: url_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: html_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: form_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: file_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:39:08 --> Database Driver Class Initialized
INFO - 2016-08-22 07:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:39:08 --> Form Validation Class Initialized
INFO - 2016-08-22 07:39:08 --> Email Class Initialized
INFO - 2016-08-22 07:39:08 --> Controller Class Initialized
INFO - 2016-08-22 07:39:08 --> Model Class Initialized
INFO - 2016-08-22 07:39:08 --> Config Class Initialized
INFO - 2016-08-22 07:39:08 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:39:08 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:39:08 --> Utf8 Class Initialized
INFO - 2016-08-22 07:39:08 --> URI Class Initialized
INFO - 2016-08-22 07:39:08 --> Router Class Initialized
INFO - 2016-08-22 07:39:08 --> Output Class Initialized
INFO - 2016-08-22 07:39:08 --> Security Class Initialized
DEBUG - 2016-08-22 07:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:39:08 --> Input Class Initialized
INFO - 2016-08-22 07:39:08 --> Language Class Initialized
INFO - 2016-08-22 07:39:08 --> Loader Class Initialized
INFO - 2016-08-22 07:39:08 --> Helper loaded: url_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: html_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: form_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: file_helper
INFO - 2016-08-22 07:39:08 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:39:08 --> Database Driver Class Initialized
INFO - 2016-08-22 07:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:39:08 --> Form Validation Class Initialized
INFO - 2016-08-22 07:39:08 --> Email Class Initialized
INFO - 2016-08-22 07:39:08 --> Controller Class Initialized
INFO - 2016-08-22 07:39:08 --> Model Class Initialized
DEBUG - 2016-08-22 07:39:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 07:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:39:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 07:39:09 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:39:09 --> Final output sent to browser
DEBUG - 2016-08-22 07:39:09 --> Total execution time: 0.2856
INFO - 2016-08-22 07:39:15 --> Config Class Initialized
INFO - 2016-08-22 07:39:15 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:39:15 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:39:15 --> Utf8 Class Initialized
INFO - 2016-08-22 07:39:15 --> URI Class Initialized
INFO - 2016-08-22 07:39:15 --> Router Class Initialized
INFO - 2016-08-22 07:39:15 --> Output Class Initialized
INFO - 2016-08-22 07:39:15 --> Security Class Initialized
DEBUG - 2016-08-22 07:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:39:15 --> Input Class Initialized
INFO - 2016-08-22 07:39:15 --> Language Class Initialized
INFO - 2016-08-22 07:39:15 --> Loader Class Initialized
INFO - 2016-08-22 07:39:15 --> Helper loaded: url_helper
INFO - 2016-08-22 07:39:15 --> Helper loaded: utils_helper
INFO - 2016-08-22 07:39:15 --> Helper loaded: html_helper
INFO - 2016-08-22 07:39:15 --> Helper loaded: form_helper
INFO - 2016-08-22 07:39:15 --> Helper loaded: file_helper
INFO - 2016-08-22 07:39:15 --> Helper loaded: myemail_helper
INFO - 2016-08-22 07:39:15 --> Database Driver Class Initialized
INFO - 2016-08-22 07:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 07:39:15 --> Form Validation Class Initialized
INFO - 2016-08-22 07:39:15 --> Email Class Initialized
INFO - 2016-08-22 07:39:15 --> Controller Class Initialized
INFO - 2016-08-22 07:39:15 --> Model Class Initialized
DEBUG - 2016-08-22 07:39:15 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 07:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 07:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 07:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 07:39:15 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 07:39:15 --> Final output sent to browser
DEBUG - 2016-08-22 07:39:15 --> Total execution time: 0.3138
INFO - 2016-08-22 07:39:18 --> Config Class Initialized
INFO - 2016-08-22 07:39:18 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:39:18 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:39:18 --> Utf8 Class Initialized
INFO - 2016-08-22 07:39:18 --> URI Class Initialized
INFO - 2016-08-22 07:39:18 --> Router Class Initialized
INFO - 2016-08-22 07:39:18 --> Output Class Initialized
INFO - 2016-08-22 07:39:18 --> Security Class Initialized
DEBUG - 2016-08-22 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:39:18 --> Input Class Initialized
INFO - 2016-08-22 07:39:18 --> Language Class Initialized
ERROR - 2016-08-22 07:39:18 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 07:39:18 --> Config Class Initialized
INFO - 2016-08-22 07:39:18 --> Hooks Class Initialized
DEBUG - 2016-08-22 07:39:18 --> UTF-8 Support Enabled
INFO - 2016-08-22 07:39:18 --> Utf8 Class Initialized
INFO - 2016-08-22 07:39:18 --> URI Class Initialized
INFO - 2016-08-22 07:39:18 --> Router Class Initialized
INFO - 2016-08-22 07:39:18 --> Output Class Initialized
INFO - 2016-08-22 07:39:18 --> Security Class Initialized
DEBUG - 2016-08-22 07:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 07:39:18 --> Input Class Initialized
INFO - 2016-08-22 07:39:18 --> Language Class Initialized
ERROR - 2016-08-22 07:39:19 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-22 08:13:46 --> Config Class Initialized
INFO - 2016-08-22 08:13:46 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:13:46 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:13:46 --> Utf8 Class Initialized
INFO - 2016-08-22 08:13:46 --> URI Class Initialized
DEBUG - 2016-08-22 08:13:46 --> No URI present. Default controller set.
INFO - 2016-08-22 08:13:46 --> Router Class Initialized
INFO - 2016-08-22 08:13:46 --> Output Class Initialized
INFO - 2016-08-22 08:13:46 --> Security Class Initialized
DEBUG - 2016-08-22 08:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:13:46 --> Input Class Initialized
INFO - 2016-08-22 08:13:46 --> Language Class Initialized
INFO - 2016-08-22 08:13:46 --> Loader Class Initialized
INFO - 2016-08-22 08:13:46 --> Helper loaded: url_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: html_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: form_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: file_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:13:46 --> Database Driver Class Initialized
INFO - 2016-08-22 08:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:13:46 --> Form Validation Class Initialized
INFO - 2016-08-22 08:13:46 --> Email Class Initialized
INFO - 2016-08-22 08:13:46 --> Controller Class Initialized
INFO - 2016-08-22 08:13:46 --> Config Class Initialized
INFO - 2016-08-22 08:13:46 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:13:46 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:13:46 --> Utf8 Class Initialized
INFO - 2016-08-22 08:13:46 --> URI Class Initialized
INFO - 2016-08-22 08:13:46 --> Router Class Initialized
INFO - 2016-08-22 08:13:46 --> Output Class Initialized
INFO - 2016-08-22 08:13:46 --> Security Class Initialized
DEBUG - 2016-08-22 08:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:13:46 --> Input Class Initialized
INFO - 2016-08-22 08:13:46 --> Language Class Initialized
INFO - 2016-08-22 08:13:46 --> Loader Class Initialized
INFO - 2016-08-22 08:13:46 --> Helper loaded: url_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: html_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: form_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: file_helper
INFO - 2016-08-22 08:13:46 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:13:46 --> Database Driver Class Initialized
INFO - 2016-08-22 08:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:13:46 --> Form Validation Class Initialized
INFO - 2016-08-22 08:13:46 --> Email Class Initialized
INFO - 2016-08-22 08:13:46 --> Controller Class Initialized
INFO - 2016-08-22 08:13:46 --> Model Class Initialized
DEBUG - 2016-08-22 08:13:46 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:13:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 08:13:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:13:46 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 08:13:47 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:13:47 --> Final output sent to browser
DEBUG - 2016-08-22 08:13:47 --> Total execution time: 0.3409
INFO - 2016-08-22 08:13:51 --> Config Class Initialized
INFO - 2016-08-22 08:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:13:52 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:13:52 --> Utf8 Class Initialized
INFO - 2016-08-22 08:13:52 --> URI Class Initialized
INFO - 2016-08-22 08:13:52 --> Router Class Initialized
INFO - 2016-08-22 08:13:52 --> Output Class Initialized
INFO - 2016-08-22 08:13:52 --> Security Class Initialized
DEBUG - 2016-08-22 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:13:52 --> Input Class Initialized
INFO - 2016-08-22 08:13:52 --> Language Class Initialized
INFO - 2016-08-22 08:13:52 --> Loader Class Initialized
INFO - 2016-08-22 08:13:52 --> Helper loaded: url_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: html_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: form_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: file_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:13:52 --> Database Driver Class Initialized
INFO - 2016-08-22 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:13:52 --> Form Validation Class Initialized
INFO - 2016-08-22 08:13:52 --> Email Class Initialized
INFO - 2016-08-22 08:13:52 --> Controller Class Initialized
INFO - 2016-08-22 08:13:52 --> Model Class Initialized
DEBUG - 2016-08-22 08:13:52 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:13:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-22 08:13:52 --> Config Class Initialized
INFO - 2016-08-22 08:13:52 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:13:52 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:13:52 --> Utf8 Class Initialized
INFO - 2016-08-22 08:13:52 --> URI Class Initialized
DEBUG - 2016-08-22 08:13:52 --> No URI present. Default controller set.
INFO - 2016-08-22 08:13:52 --> Router Class Initialized
INFO - 2016-08-22 08:13:52 --> Output Class Initialized
INFO - 2016-08-22 08:13:52 --> Security Class Initialized
DEBUG - 2016-08-22 08:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:13:52 --> Input Class Initialized
INFO - 2016-08-22 08:13:52 --> Language Class Initialized
INFO - 2016-08-22 08:13:52 --> Loader Class Initialized
INFO - 2016-08-22 08:13:52 --> Helper loaded: url_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: html_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: form_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: file_helper
INFO - 2016-08-22 08:13:52 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:13:52 --> Database Driver Class Initialized
INFO - 2016-08-22 08:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:13:52 --> Form Validation Class Initialized
INFO - 2016-08-22 08:13:52 --> Email Class Initialized
INFO - 2016-08-22 08:13:52 --> Controller Class Initialized
INFO - 2016-08-22 08:13:52 --> Model Class Initialized
INFO - 2016-08-22 08:13:52 --> Model Class Initialized
INFO - 2016-08-22 08:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\account/index.php
INFO - 2016-08-22 08:13:52 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:13:52 --> Final output sent to browser
DEBUG - 2016-08-22 08:13:52 --> Total execution time: 0.2943
INFO - 2016-08-22 08:13:57 --> Config Class Initialized
INFO - 2016-08-22 08:13:57 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:13:57 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:13:57 --> Utf8 Class Initialized
INFO - 2016-08-22 08:13:57 --> URI Class Initialized
INFO - 2016-08-22 08:13:57 --> Router Class Initialized
INFO - 2016-08-22 08:13:57 --> Output Class Initialized
INFO - 2016-08-22 08:13:57 --> Security Class Initialized
DEBUG - 2016-08-22 08:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:13:57 --> Input Class Initialized
INFO - 2016-08-22 08:13:57 --> Language Class Initialized
INFO - 2016-08-22 08:13:57 --> Loader Class Initialized
INFO - 2016-08-22 08:13:57 --> Helper loaded: url_helper
INFO - 2016-08-22 08:13:57 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:13:57 --> Helper loaded: html_helper
INFO - 2016-08-22 08:13:57 --> Helper loaded: form_helper
INFO - 2016-08-22 08:13:57 --> Helper loaded: file_helper
INFO - 2016-08-22 08:13:57 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:13:57 --> Database Driver Class Initialized
INFO - 2016-08-22 08:13:57 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:13:57 --> Form Validation Class Initialized
INFO - 2016-08-22 08:13:57 --> Email Class Initialized
INFO - 2016-08-22 08:13:57 --> Controller Class Initialized
DEBUG - 2016-08-22 08:13:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 08:13:57 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:13:57 --> Model Class Initialized
INFO - 2016-08-22 08:13:57 --> Model Class Initialized
INFO - 2016-08-22 08:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 08:13:57 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:13:57 --> Final output sent to browser
DEBUG - 2016-08-22 08:13:57 --> Total execution time: 0.4060
INFO - 2016-08-22 08:14:04 --> Config Class Initialized
INFO - 2016-08-22 08:14:04 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:14:04 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:14:04 --> Utf8 Class Initialized
INFO - 2016-08-22 08:14:04 --> URI Class Initialized
INFO - 2016-08-22 08:14:04 --> Router Class Initialized
INFO - 2016-08-22 08:14:04 --> Output Class Initialized
INFO - 2016-08-22 08:14:04 --> Security Class Initialized
DEBUG - 2016-08-22 08:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:14:04 --> Input Class Initialized
INFO - 2016-08-22 08:14:04 --> Language Class Initialized
INFO - 2016-08-22 08:14:04 --> Loader Class Initialized
INFO - 2016-08-22 08:14:04 --> Helper loaded: url_helper
INFO - 2016-08-22 08:14:04 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:14:04 --> Helper loaded: html_helper
INFO - 2016-08-22 08:14:04 --> Helper loaded: form_helper
INFO - 2016-08-22 08:14:04 --> Helper loaded: file_helper
INFO - 2016-08-22 08:14:04 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:14:04 --> Database Driver Class Initialized
INFO - 2016-08-22 08:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:14:04 --> Form Validation Class Initialized
INFO - 2016-08-22 08:14:04 --> Email Class Initialized
INFO - 2016-08-22 08:14:04 --> Controller Class Initialized
DEBUG - 2016-08-22 08:14:04 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:14:04 --> Model Class Initialized
INFO - 2016-08-22 08:14:04 --> Model Class Initialized
INFO - 2016-08-22 08:14:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:14:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:14:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-22 08:14:04 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:14:04 --> Final output sent to browser
DEBUG - 2016-08-22 08:14:04 --> Total execution time: 0.3288
INFO - 2016-08-22 08:14:08 --> Config Class Initialized
INFO - 2016-08-22 08:14:08 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:14:08 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:14:08 --> Utf8 Class Initialized
INFO - 2016-08-22 08:14:08 --> URI Class Initialized
INFO - 2016-08-22 08:14:08 --> Router Class Initialized
INFO - 2016-08-22 08:14:08 --> Output Class Initialized
INFO - 2016-08-22 08:14:08 --> Security Class Initialized
DEBUG - 2016-08-22 08:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:14:08 --> Input Class Initialized
INFO - 2016-08-22 08:14:08 --> Language Class Initialized
INFO - 2016-08-22 08:14:08 --> Loader Class Initialized
INFO - 2016-08-22 08:14:08 --> Helper loaded: url_helper
INFO - 2016-08-22 08:14:08 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:14:08 --> Helper loaded: html_helper
INFO - 2016-08-22 08:14:08 --> Helper loaded: form_helper
INFO - 2016-08-22 08:14:08 --> Helper loaded: file_helper
INFO - 2016-08-22 08:14:08 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:14:08 --> Database Driver Class Initialized
INFO - 2016-08-22 08:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:14:08 --> Form Validation Class Initialized
INFO - 2016-08-22 08:14:08 --> Email Class Initialized
INFO - 2016-08-22 08:14:08 --> Controller Class Initialized
DEBUG - 2016-08-22 08:14:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:14:08 --> Model Class Initialized
INFO - 2016-08-22 08:14:08 --> Model Class Initialized
INFO - 2016-08-22 08:14:08 --> Model Class Initialized
INFO - 2016-08-22 08:14:08 --> Model Class Initialized
INFO - 2016-08-22 08:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-22 08:14:08 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:14:08 --> Final output sent to browser
DEBUG - 2016-08-22 08:14:08 --> Total execution time: 0.3584
INFO - 2016-08-22 08:14:11 --> Config Class Initialized
INFO - 2016-08-22 08:14:11 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:14:11 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:14:11 --> Utf8 Class Initialized
INFO - 2016-08-22 08:14:11 --> URI Class Initialized
INFO - 2016-08-22 08:14:11 --> Router Class Initialized
INFO - 2016-08-22 08:14:11 --> Output Class Initialized
INFO - 2016-08-22 08:14:11 --> Security Class Initialized
DEBUG - 2016-08-22 08:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:14:11 --> Input Class Initialized
INFO - 2016-08-22 08:14:11 --> Language Class Initialized
INFO - 2016-08-22 08:14:11 --> Loader Class Initialized
INFO - 2016-08-22 08:14:11 --> Helper loaded: url_helper
INFO - 2016-08-22 08:14:11 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:14:11 --> Helper loaded: html_helper
INFO - 2016-08-22 08:14:11 --> Helper loaded: form_helper
INFO - 2016-08-22 08:14:11 --> Helper loaded: file_helper
INFO - 2016-08-22 08:14:11 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:14:11 --> Database Driver Class Initialized
INFO - 2016-08-22 08:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:14:11 --> Form Validation Class Initialized
INFO - 2016-08-22 08:14:11 --> Email Class Initialized
INFO - 2016-08-22 08:14:11 --> Controller Class Initialized
DEBUG - 2016-08-22 08:14:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:14:12 --> Model Class Initialized
INFO - 2016-08-22 08:14:12 --> Model Class Initialized
INFO - 2016-08-22 08:14:12 --> Helper loaded: download_helper
INFO - 2016-08-22 08:14:12 --> Config Class Initialized
INFO - 2016-08-22 08:14:12 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:14:12 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:14:12 --> Utf8 Class Initialized
INFO - 2016-08-22 08:14:12 --> URI Class Initialized
INFO - 2016-08-22 08:14:12 --> Router Class Initialized
INFO - 2016-08-22 08:14:12 --> Output Class Initialized
INFO - 2016-08-22 08:14:12 --> Security Class Initialized
DEBUG - 2016-08-22 08:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:14:12 --> Input Class Initialized
INFO - 2016-08-22 08:14:12 --> Language Class Initialized
ERROR - 2016-08-22 08:14:12 --> 404 Page Not Found: Books/Book1.xls
ERROR - 2016-08-22 08:14:12 --> Severity: Warning --> file_get_contents(http://library.pnc.lan/books/Book1.xls): failed to open stream: HTTP request failed! HTTP/1.0 404 Not Found
 D:\wamp\www\library.pnc.lan\application\controllers\Books.php 389
INFO - 2016-08-22 08:14:20 --> Config Class Initialized
INFO - 2016-08-22 08:14:20 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:14:20 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:14:20 --> Utf8 Class Initialized
INFO - 2016-08-22 08:14:20 --> URI Class Initialized
INFO - 2016-08-22 08:14:20 --> Router Class Initialized
INFO - 2016-08-22 08:14:20 --> Output Class Initialized
INFO - 2016-08-22 08:14:20 --> Security Class Initialized
DEBUG - 2016-08-22 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:14:20 --> Input Class Initialized
INFO - 2016-08-22 08:14:20 --> Language Class Initialized
INFO - 2016-08-22 08:14:20 --> Loader Class Initialized
INFO - 2016-08-22 08:14:20 --> Helper loaded: url_helper
INFO - 2016-08-22 08:14:20 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:14:20 --> Helper loaded: html_helper
INFO - 2016-08-22 08:14:20 --> Helper loaded: form_helper
INFO - 2016-08-22 08:14:20 --> Helper loaded: file_helper
INFO - 2016-08-22 08:14:20 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:14:20 --> Database Driver Class Initialized
INFO - 2016-08-22 08:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:14:20 --> Form Validation Class Initialized
INFO - 2016-08-22 08:14:20 --> Email Class Initialized
INFO - 2016-08-22 08:14:20 --> Controller Class Initialized
DEBUG - 2016-08-22 08:14:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:14:20 --> Model Class Initialized
INFO - 2016-08-22 08:14:20 --> Model Class Initialized
INFO - 2016-08-22 08:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-22 08:14:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:14:20 --> Final output sent to browser
DEBUG - 2016-08-22 08:14:20 --> Total execution time: 0.3489
INFO - 2016-08-22 08:15:24 --> Config Class Initialized
INFO - 2016-08-22 08:15:24 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:24 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:24 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:24 --> URI Class Initialized
INFO - 2016-08-22 08:15:24 --> Router Class Initialized
INFO - 2016-08-22 08:15:24 --> Output Class Initialized
INFO - 2016-08-22 08:15:24 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:24 --> Input Class Initialized
INFO - 2016-08-22 08:15:24 --> Language Class Initialized
INFO - 2016-08-22 08:15:24 --> Loader Class Initialized
INFO - 2016-08-22 08:15:24 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:24 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:24 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:24 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:24 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:24 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:24 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:24 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:24 --> Email Class Initialized
INFO - 2016-08-22 08:15:24 --> Controller Class Initialized
INFO - 2016-08-22 08:15:24 --> Model Class Initialized
INFO - 2016-08-22 08:15:24 --> Model Class Initialized
DEBUG - 2016-08-22 08:15:24 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:15:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-22 08:15:24 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:24 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:24 --> Total execution time: 0.3484
INFO - 2016-08-22 08:15:25 --> Config Class Initialized
INFO - 2016-08-22 08:15:25 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:25 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:25 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:25 --> URI Class Initialized
INFO - 2016-08-22 08:15:26 --> Router Class Initialized
INFO - 2016-08-22 08:15:26 --> Output Class Initialized
INFO - 2016-08-22 08:15:26 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:26 --> Input Class Initialized
INFO - 2016-08-22 08:15:26 --> Language Class Initialized
INFO - 2016-08-22 08:15:26 --> Loader Class Initialized
INFO - 2016-08-22 08:15:26 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:26 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:26 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:26 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:26 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:26 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:26 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:26 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:26 --> Email Class Initialized
INFO - 2016-08-22 08:15:26 --> Controller Class Initialized
DEBUG - 2016-08-22 08:15:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 08:15:26 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:15:26 --> Model Class Initialized
INFO - 2016-08-22 08:15:26 --> Model Class Initialized
INFO - 2016-08-22 08:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 08:15:26 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:26 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:26 --> Total execution time: 0.4758
INFO - 2016-08-22 08:15:28 --> Config Class Initialized
INFO - 2016-08-22 08:15:28 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:28 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:28 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:28 --> URI Class Initialized
INFO - 2016-08-22 08:15:28 --> Router Class Initialized
INFO - 2016-08-22 08:15:28 --> Output Class Initialized
INFO - 2016-08-22 08:15:28 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:28 --> Input Class Initialized
INFO - 2016-08-22 08:15:28 --> Language Class Initialized
INFO - 2016-08-22 08:15:28 --> Loader Class Initialized
INFO - 2016-08-22 08:15:28 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:28 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:28 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:28 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:28 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:28 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:28 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:28 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:28 --> Email Class Initialized
INFO - 2016-08-22 08:15:28 --> Controller Class Initialized
INFO - 2016-08-22 08:15:28 --> Model Class Initialized
INFO - 2016-08-22 08:15:28 --> Model Class Initialized
INFO - 2016-08-22 08:15:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_book_request.php
INFO - 2016-08-22 08:15:28 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:29 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:29 --> Total execution time: 0.3938
INFO - 2016-08-22 08:15:34 --> Config Class Initialized
INFO - 2016-08-22 08:15:34 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:34 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:35 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:35 --> URI Class Initialized
INFO - 2016-08-22 08:15:35 --> Router Class Initialized
INFO - 2016-08-22 08:15:35 --> Output Class Initialized
INFO - 2016-08-22 08:15:35 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:35 --> Input Class Initialized
INFO - 2016-08-22 08:15:35 --> Language Class Initialized
INFO - 2016-08-22 08:15:35 --> Loader Class Initialized
INFO - 2016-08-22 08:15:35 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:35 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:35 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:35 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:35 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:35 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:35 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:35 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:35 --> Email Class Initialized
INFO - 2016-08-22 08:15:35 --> Controller Class Initialized
DEBUG - 2016-08-22 08:15:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:15:35 --> Model Class Initialized
INFO - 2016-08-22 08:15:35 --> Model Class Initialized
INFO - 2016-08-22 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/borrow.php
INFO - 2016-08-22 08:15:35 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:35 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:35 --> Total execution time: 0.3337
INFO - 2016-08-22 08:15:39 --> Config Class Initialized
INFO - 2016-08-22 08:15:39 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:39 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:39 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:39 --> URI Class Initialized
INFO - 2016-08-22 08:15:39 --> Router Class Initialized
INFO - 2016-08-22 08:15:39 --> Output Class Initialized
INFO - 2016-08-22 08:15:39 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:39 --> Input Class Initialized
INFO - 2016-08-22 08:15:39 --> Language Class Initialized
INFO - 2016-08-22 08:15:39 --> Loader Class Initialized
INFO - 2016-08-22 08:15:39 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:39 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:39 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:39 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:39 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:39 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:39 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:39 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:39 --> Email Class Initialized
INFO - 2016-08-22 08:15:39 --> Controller Class Initialized
DEBUG - 2016-08-22 08:15:39 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 08:15:39 --> Model Class Initialized
INFO - 2016-08-22 08:15:39 --> Model Class Initialized
INFO - 2016-08-22 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/return_book.php
INFO - 2016-08-22 08:15:39 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:39 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:39 --> Total execution time: 0.3807
INFO - 2016-08-22 08:15:42 --> Config Class Initialized
INFO - 2016-08-22 08:15:42 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:15:42 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:15:42 --> Utf8 Class Initialized
INFO - 2016-08-22 08:15:42 --> URI Class Initialized
INFO - 2016-08-22 08:15:42 --> Router Class Initialized
INFO - 2016-08-22 08:15:42 --> Output Class Initialized
INFO - 2016-08-22 08:15:42 --> Security Class Initialized
DEBUG - 2016-08-22 08:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:15:42 --> Input Class Initialized
INFO - 2016-08-22 08:15:42 --> Language Class Initialized
INFO - 2016-08-22 08:15:42 --> Loader Class Initialized
INFO - 2016-08-22 08:15:42 --> Helper loaded: url_helper
INFO - 2016-08-22 08:15:42 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:15:42 --> Helper loaded: html_helper
INFO - 2016-08-22 08:15:42 --> Helper loaded: form_helper
INFO - 2016-08-22 08:15:42 --> Helper loaded: file_helper
INFO - 2016-08-22 08:15:42 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:15:42 --> Database Driver Class Initialized
INFO - 2016-08-22 08:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:15:42 --> Form Validation Class Initialized
INFO - 2016-08-22 08:15:42 --> Email Class Initialized
INFO - 2016-08-22 08:15:42 --> Controller Class Initialized
INFO - 2016-08-22 08:15:42 --> Model Class Initialized
INFO - 2016-08-22 08:15:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:15:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:15:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-22 08:15:42 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:15:42 --> Final output sent to browser
DEBUG - 2016-08-22 08:15:42 --> Total execution time: 0.3479
INFO - 2016-08-22 08:16:17 --> Config Class Initialized
INFO - 2016-08-22 08:16:17 --> Hooks Class Initialized
DEBUG - 2016-08-22 08:16:17 --> UTF-8 Support Enabled
INFO - 2016-08-22 08:16:17 --> Utf8 Class Initialized
INFO - 2016-08-22 08:16:17 --> URI Class Initialized
INFO - 2016-08-22 08:16:17 --> Router Class Initialized
INFO - 2016-08-22 08:16:17 --> Output Class Initialized
INFO - 2016-08-22 08:16:17 --> Security Class Initialized
DEBUG - 2016-08-22 08:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 08:16:17 --> Input Class Initialized
INFO - 2016-08-22 08:16:17 --> Language Class Initialized
INFO - 2016-08-22 08:16:17 --> Loader Class Initialized
INFO - 2016-08-22 08:16:17 --> Helper loaded: url_helper
INFO - 2016-08-22 08:16:17 --> Helper loaded: utils_helper
INFO - 2016-08-22 08:16:17 --> Helper loaded: html_helper
INFO - 2016-08-22 08:16:17 --> Helper loaded: form_helper
INFO - 2016-08-22 08:16:17 --> Helper loaded: file_helper
INFO - 2016-08-22 08:16:17 --> Helper loaded: myemail_helper
INFO - 2016-08-22 08:16:17 --> Database Driver Class Initialized
INFO - 2016-08-22 08:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 08:16:17 --> Form Validation Class Initialized
INFO - 2016-08-22 08:16:17 --> Email Class Initialized
INFO - 2016-08-22 08:16:17 --> Controller Class Initialized
INFO - 2016-08-22 08:16:17 --> Model Class Initialized
INFO - 2016-08-22 08:16:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 08:16:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 08:16:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/users_state.php
INFO - 2016-08-22 08:16:17 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 08:16:17 --> Final output sent to browser
DEBUG - 2016-08-22 08:16:17 --> Total execution time: 0.3325
INFO - 2016-08-22 10:25:43 --> Config Class Initialized
INFO - 2016-08-22 10:25:43 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:25:43 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:25:43 --> Utf8 Class Initialized
INFO - 2016-08-22 10:25:43 --> URI Class Initialized
INFO - 2016-08-22 10:25:43 --> Router Class Initialized
INFO - 2016-08-22 10:25:43 --> Output Class Initialized
INFO - 2016-08-22 10:25:43 --> Security Class Initialized
DEBUG - 2016-08-22 10:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:25:43 --> Input Class Initialized
INFO - 2016-08-22 10:25:43 --> Language Class Initialized
INFO - 2016-08-22 10:25:43 --> Loader Class Initialized
INFO - 2016-08-22 10:25:43 --> Helper loaded: url_helper
INFO - 2016-08-22 10:25:43 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:25:43 --> Helper loaded: html_helper
INFO - 2016-08-22 10:25:43 --> Helper loaded: form_helper
INFO - 2016-08-22 10:25:43 --> Helper loaded: file_helper
INFO - 2016-08-22 10:25:43 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:25:43 --> Database Driver Class Initialized
INFO - 2016-08-22 10:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:25:43 --> Form Validation Class Initialized
INFO - 2016-08-22 10:25:43 --> Email Class Initialized
INFO - 2016-08-22 10:25:43 --> Controller Class Initialized
INFO - 2016-08-22 10:25:43 --> Model Class Initialized
DEBUG - 2016-08-22 10:25:43 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:25:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-22 10:25:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:25:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-22 10:25:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:25:43 --> Final output sent to browser
DEBUG - 2016-08-22 10:25:43 --> Total execution time: 0.4219
INFO - 2016-08-22 10:25:55 --> Config Class Initialized
INFO - 2016-08-22 10:25:55 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:25:55 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:25:55 --> Utf8 Class Initialized
INFO - 2016-08-22 10:25:55 --> URI Class Initialized
INFO - 2016-08-22 10:25:56 --> Router Class Initialized
INFO - 2016-08-22 10:25:56 --> Output Class Initialized
INFO - 2016-08-22 10:25:56 --> Security Class Initialized
DEBUG - 2016-08-22 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:25:56 --> Input Class Initialized
INFO - 2016-08-22 10:25:56 --> Language Class Initialized
INFO - 2016-08-22 10:25:56 --> Loader Class Initialized
INFO - 2016-08-22 10:25:56 --> Helper loaded: url_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: html_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: form_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: file_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:25:56 --> Database Driver Class Initialized
INFO - 2016-08-22 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:25:56 --> Form Validation Class Initialized
INFO - 2016-08-22 10:25:56 --> Email Class Initialized
INFO - 2016-08-22 10:25:56 --> Controller Class Initialized
INFO - 2016-08-22 10:25:56 --> Model Class Initialized
DEBUG - 2016-08-22 10:25:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:25:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2016-08-22 10:25:56 --> Config Class Initialized
INFO - 2016-08-22 10:25:56 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:25:56 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:25:56 --> Utf8 Class Initialized
INFO - 2016-08-22 10:25:56 --> URI Class Initialized
INFO - 2016-08-22 10:25:56 --> Router Class Initialized
INFO - 2016-08-22 10:25:56 --> Output Class Initialized
INFO - 2016-08-22 10:25:56 --> Security Class Initialized
DEBUG - 2016-08-22 10:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:25:56 --> Input Class Initialized
INFO - 2016-08-22 10:25:56 --> Language Class Initialized
INFO - 2016-08-22 10:25:56 --> Loader Class Initialized
INFO - 2016-08-22 10:25:56 --> Helper loaded: url_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: html_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: form_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: file_helper
INFO - 2016-08-22 10:25:56 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:25:56 --> Database Driver Class Initialized
INFO - 2016-08-22 10:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:25:56 --> Form Validation Class Initialized
INFO - 2016-08-22 10:25:56 --> Email Class Initialized
INFO - 2016-08-22 10:25:56 --> Controller Class Initialized
DEBUG - 2016-08-22 10:25:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2016-08-22 10:25:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:25:56 --> Model Class Initialized
INFO - 2016-08-22 10:25:56 --> Model Class Initialized
INFO - 2016-08-22 10:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\dashboard/dashboard.php
INFO - 2016-08-22 10:25:56 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:25:56 --> Final output sent to browser
DEBUG - 2016-08-22 10:25:56 --> Total execution time: 0.4276
INFO - 2016-08-22 10:26:00 --> Config Class Initialized
INFO - 2016-08-22 10:26:00 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:26:00 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:26:00 --> Utf8 Class Initialized
INFO - 2016-08-22 10:26:00 --> URI Class Initialized
INFO - 2016-08-22 10:26:00 --> Router Class Initialized
INFO - 2016-08-22 10:26:00 --> Output Class Initialized
INFO - 2016-08-22 10:26:00 --> Security Class Initialized
DEBUG - 2016-08-22 10:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:26:01 --> Input Class Initialized
INFO - 2016-08-22 10:26:01 --> Language Class Initialized
INFO - 2016-08-22 10:26:01 --> Loader Class Initialized
INFO - 2016-08-22 10:26:01 --> Helper loaded: url_helper
INFO - 2016-08-22 10:26:01 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:26:01 --> Helper loaded: html_helper
INFO - 2016-08-22 10:26:01 --> Helper loaded: form_helper
INFO - 2016-08-22 10:26:01 --> Helper loaded: file_helper
INFO - 2016-08-22 10:26:01 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:26:01 --> Database Driver Class Initialized
INFO - 2016-08-22 10:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:26:01 --> Form Validation Class Initialized
INFO - 2016-08-22 10:26:01 --> Email Class Initialized
INFO - 2016-08-22 10:26:01 --> Controller Class Initialized
DEBUG - 2016-08-22 10:26:01 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:26:01 --> Model Class Initialized
INFO - 2016-08-22 10:26:01 --> Model Class Initialized
INFO - 2016-08-22 10:26:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:26:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:26:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-22 10:26:01 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:26:01 --> Final output sent to browser
DEBUG - 2016-08-22 10:26:01 --> Total execution time: 0.3779
INFO - 2016-08-22 10:26:02 --> Config Class Initialized
INFO - 2016-08-22 10:26:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:26:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:26:02 --> Utf8 Class Initialized
INFO - 2016-08-22 10:26:02 --> URI Class Initialized
INFO - 2016-08-22 10:26:02 --> Router Class Initialized
INFO - 2016-08-22 10:26:02 --> Output Class Initialized
INFO - 2016-08-22 10:26:02 --> Security Class Initialized
DEBUG - 2016-08-22 10:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:26:02 --> Input Class Initialized
INFO - 2016-08-22 10:26:02 --> Language Class Initialized
INFO - 2016-08-22 10:26:02 --> Loader Class Initialized
INFO - 2016-08-22 10:26:02 --> Helper loaded: url_helper
INFO - 2016-08-22 10:26:02 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:26:02 --> Helper loaded: html_helper
INFO - 2016-08-22 10:26:02 --> Helper loaded: form_helper
INFO - 2016-08-22 10:26:02 --> Helper loaded: file_helper
INFO - 2016-08-22 10:26:02 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:26:02 --> Database Driver Class Initialized
INFO - 2016-08-22 10:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:26:02 --> Form Validation Class Initialized
INFO - 2016-08-22 10:26:02 --> Email Class Initialized
INFO - 2016-08-22 10:26:02 --> Controller Class Initialized
DEBUG - 2016-08-22 10:26:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:26:02 --> Model Class Initialized
INFO - 2016-08-22 10:26:02 --> Model Class Initialized
INFO - 2016-08-22 10:26:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:26:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:26:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-22 10:26:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:26:02 --> Final output sent to browser
DEBUG - 2016-08-22 10:26:02 --> Total execution time: 0.3927
INFO - 2016-08-22 10:26:23 --> Config Class Initialized
INFO - 2016-08-22 10:26:23 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:26:23 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:26:23 --> Utf8 Class Initialized
INFO - 2016-08-22 10:26:23 --> URI Class Initialized
INFO - 2016-08-22 10:26:23 --> Router Class Initialized
INFO - 2016-08-22 10:26:23 --> Output Class Initialized
INFO - 2016-08-22 10:26:23 --> Security Class Initialized
DEBUG - 2016-08-22 10:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:26:23 --> Input Class Initialized
INFO - 2016-08-22 10:26:23 --> Language Class Initialized
INFO - 2016-08-22 10:26:23 --> Loader Class Initialized
INFO - 2016-08-22 10:26:23 --> Helper loaded: url_helper
INFO - 2016-08-22 10:26:23 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:26:23 --> Helper loaded: html_helper
INFO - 2016-08-22 10:26:23 --> Helper loaded: form_helper
INFO - 2016-08-22 10:26:23 --> Helper loaded: file_helper
INFO - 2016-08-22 10:26:23 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:26:23 --> Database Driver Class Initialized
INFO - 2016-08-22 10:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:26:23 --> Form Validation Class Initialized
INFO - 2016-08-22 10:26:23 --> Email Class Initialized
INFO - 2016-08-22 10:26:23 --> Controller Class Initialized
INFO - 2016-08-22 10:26:23 --> Model Class Initialized
INFO - 2016-08-22 10:26:23 --> Model Class Initialized
DEBUG - 2016-08-22 10:26:23 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:26:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:26:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:26:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\bookcategory/index.php
INFO - 2016-08-22 10:26:23 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:26:23 --> Final output sent to browser
DEBUG - 2016-08-22 10:26:23 --> Total execution time: 0.3675
INFO - 2016-08-22 10:29:16 --> Config Class Initialized
INFO - 2016-08-22 10:29:16 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:29:16 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:29:16 --> Utf8 Class Initialized
INFO - 2016-08-22 10:29:16 --> URI Class Initialized
INFO - 2016-08-22 10:29:16 --> Router Class Initialized
INFO - 2016-08-22 10:29:16 --> Output Class Initialized
INFO - 2016-08-22 10:29:16 --> Security Class Initialized
DEBUG - 2016-08-22 10:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:29:16 --> Input Class Initialized
INFO - 2016-08-22 10:29:16 --> Language Class Initialized
INFO - 2016-08-22 10:29:16 --> Loader Class Initialized
INFO - 2016-08-22 10:29:16 --> Helper loaded: url_helper
INFO - 2016-08-22 10:29:16 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:29:16 --> Helper loaded: html_helper
INFO - 2016-08-22 10:29:16 --> Helper loaded: form_helper
INFO - 2016-08-22 10:29:16 --> Helper loaded: file_helper
INFO - 2016-08-22 10:29:16 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:29:16 --> Database Driver Class Initialized
INFO - 2016-08-22 10:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:29:16 --> Form Validation Class Initialized
INFO - 2016-08-22 10:29:16 --> Email Class Initialized
INFO - 2016-08-22 10:29:16 --> Controller Class Initialized
INFO - 2016-08-22 10:29:16 --> Model Class Initialized
INFO - 2016-08-22 10:29:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:29:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:29:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\users/index.php
INFO - 2016-08-22 10:29:16 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:29:16 --> Final output sent to browser
DEBUG - 2016-08-22 10:29:16 --> Total execution time: 0.3421
INFO - 2016-08-22 10:29:19 --> Config Class Initialized
INFO - 2016-08-22 10:29:19 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:29:20 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:29:20 --> Utf8 Class Initialized
INFO - 2016-08-22 10:29:20 --> URI Class Initialized
INFO - 2016-08-22 10:29:20 --> Router Class Initialized
INFO - 2016-08-22 10:29:20 --> Output Class Initialized
INFO - 2016-08-22 10:29:20 --> Security Class Initialized
DEBUG - 2016-08-22 10:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:29:20 --> Input Class Initialized
INFO - 2016-08-22 10:29:20 --> Language Class Initialized
INFO - 2016-08-22 10:29:20 --> Loader Class Initialized
INFO - 2016-08-22 10:29:20 --> Helper loaded: url_helper
INFO - 2016-08-22 10:29:20 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:29:20 --> Helper loaded: html_helper
INFO - 2016-08-22 10:29:20 --> Helper loaded: form_helper
INFO - 2016-08-22 10:29:20 --> Helper loaded: file_helper
INFO - 2016-08-22 10:29:20 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:29:20 --> Database Driver Class Initialized
INFO - 2016-08-22 10:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:29:20 --> Form Validation Class Initialized
INFO - 2016-08-22 10:29:20 --> Email Class Initialized
INFO - 2016-08-22 10:29:20 --> Controller Class Initialized
DEBUG - 2016-08-22 10:29:20 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:29:20 --> Model Class Initialized
INFO - 2016-08-22 10:29:20 --> Model Class Initialized
INFO - 2016-08-22 10:29:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:29:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:29:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-22 10:29:20 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:29:20 --> Final output sent to browser
DEBUG - 2016-08-22 10:29:20 --> Total execution time: 0.3836
INFO - 2016-08-22 10:29:21 --> Config Class Initialized
INFO - 2016-08-22 10:29:21 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:29:21 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:29:21 --> Utf8 Class Initialized
INFO - 2016-08-22 10:29:21 --> URI Class Initialized
INFO - 2016-08-22 10:29:21 --> Router Class Initialized
INFO - 2016-08-22 10:29:21 --> Output Class Initialized
INFO - 2016-08-22 10:29:21 --> Security Class Initialized
DEBUG - 2016-08-22 10:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:29:21 --> Input Class Initialized
INFO - 2016-08-22 10:29:21 --> Language Class Initialized
INFO - 2016-08-22 10:29:21 --> Loader Class Initialized
INFO - 2016-08-22 10:29:21 --> Helper loaded: url_helper
INFO - 2016-08-22 10:29:21 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:29:21 --> Helper loaded: html_helper
INFO - 2016-08-22 10:29:21 --> Helper loaded: form_helper
INFO - 2016-08-22 10:29:21 --> Helper loaded: file_helper
INFO - 2016-08-22 10:29:21 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:29:21 --> Database Driver Class Initialized
INFO - 2016-08-22 10:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:29:21 --> Form Validation Class Initialized
INFO - 2016-08-22 10:29:21 --> Email Class Initialized
INFO - 2016-08-22 10:29:21 --> Controller Class Initialized
INFO - 2016-08-22 10:29:21 --> Model Class Initialized
INFO - 2016-08-22 10:29:21 --> Model Class Initialized
INFO - 2016-08-22 10:29:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:29:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:29:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\search/searchpage.php
INFO - 2016-08-22 10:29:21 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:29:21 --> Final output sent to browser
DEBUG - 2016-08-22 10:29:21 --> Total execution time: 0.3860
INFO - 2016-08-22 10:30:02 --> Config Class Initialized
INFO - 2016-08-22 10:30:02 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:30:02 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:30:02 --> Utf8 Class Initialized
INFO - 2016-08-22 10:30:02 --> URI Class Initialized
INFO - 2016-08-22 10:30:02 --> Router Class Initialized
INFO - 2016-08-22 10:30:02 --> Output Class Initialized
INFO - 2016-08-22 10:30:02 --> Security Class Initialized
DEBUG - 2016-08-22 10:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:30:02 --> Input Class Initialized
INFO - 2016-08-22 10:30:02 --> Language Class Initialized
INFO - 2016-08-22 10:30:02 --> Loader Class Initialized
INFO - 2016-08-22 10:30:02 --> Helper loaded: url_helper
INFO - 2016-08-22 10:30:02 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:30:02 --> Helper loaded: html_helper
INFO - 2016-08-22 10:30:02 --> Helper loaded: form_helper
INFO - 2016-08-22 10:30:02 --> Helper loaded: file_helper
INFO - 2016-08-22 10:30:02 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:30:02 --> Database Driver Class Initialized
INFO - 2016-08-22 10:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:30:02 --> Form Validation Class Initialized
INFO - 2016-08-22 10:30:02 --> Email Class Initialized
INFO - 2016-08-22 10:30:02 --> Controller Class Initialized
DEBUG - 2016-08-22 10:30:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:30:02 --> Model Class Initialized
INFO - 2016-08-22 10:30:02 --> Model Class Initialized
INFO - 2016-08-22 10:30:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:30:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:30:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/list_books.php
INFO - 2016-08-22 10:30:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:30:02 --> Final output sent to browser
DEBUG - 2016-08-22 10:30:02 --> Total execution time: 0.3621
INFO - 2016-08-22 10:31:42 --> Config Class Initialized
INFO - 2016-08-22 10:31:42 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:31:42 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:31:42 --> Utf8 Class Initialized
INFO - 2016-08-22 10:31:42 --> URI Class Initialized
INFO - 2016-08-22 10:31:42 --> Router Class Initialized
INFO - 2016-08-22 10:31:42 --> Output Class Initialized
INFO - 2016-08-22 10:31:42 --> Security Class Initialized
DEBUG - 2016-08-22 10:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:31:42 --> Input Class Initialized
INFO - 2016-08-22 10:31:42 --> Language Class Initialized
INFO - 2016-08-22 10:31:42 --> Loader Class Initialized
INFO - 2016-08-22 10:31:42 --> Helper loaded: url_helper
INFO - 2016-08-22 10:31:42 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:31:42 --> Helper loaded: html_helper
INFO - 2016-08-22 10:31:42 --> Helper loaded: form_helper
INFO - 2016-08-22 10:31:42 --> Helper loaded: file_helper
INFO - 2016-08-22 10:31:42 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:31:42 --> Database Driver Class Initialized
INFO - 2016-08-22 10:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:31:42 --> Form Validation Class Initialized
INFO - 2016-08-22 10:31:42 --> Email Class Initialized
INFO - 2016-08-22 10:31:42 --> Controller Class Initialized
DEBUG - 2016-08-22 10:31:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:31:43 --> Model Class Initialized
INFO - 2016-08-22 10:31:43 --> Model Class Initialized
INFO - 2016-08-22 10:31:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:31:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:31:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/index.php
INFO - 2016-08-22 10:31:43 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:31:43 --> Final output sent to browser
DEBUG - 2016-08-22 10:31:43 --> Total execution time: 0.3749
INFO - 2016-08-22 10:31:44 --> Config Class Initialized
INFO - 2016-08-22 10:31:44 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:31:44 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:31:44 --> Utf8 Class Initialized
INFO - 2016-08-22 10:31:44 --> URI Class Initialized
INFO - 2016-08-22 10:31:44 --> Router Class Initialized
INFO - 2016-08-22 10:31:44 --> Output Class Initialized
INFO - 2016-08-22 10:31:44 --> Security Class Initialized
DEBUG - 2016-08-22 10:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:31:44 --> Input Class Initialized
INFO - 2016-08-22 10:31:44 --> Language Class Initialized
INFO - 2016-08-22 10:31:44 --> Loader Class Initialized
INFO - 2016-08-22 10:31:44 --> Helper loaded: url_helper
INFO - 2016-08-22 10:31:44 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:31:44 --> Helper loaded: html_helper
INFO - 2016-08-22 10:31:44 --> Helper loaded: form_helper
INFO - 2016-08-22 10:31:44 --> Helper loaded: file_helper
INFO - 2016-08-22 10:31:44 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:31:45 --> Database Driver Class Initialized
INFO - 2016-08-22 10:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:31:45 --> Form Validation Class Initialized
INFO - 2016-08-22 10:31:45 --> Email Class Initialized
INFO - 2016-08-22 10:31:45 --> Controller Class Initialized
DEBUG - 2016-08-22 10:31:45 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:31:45 --> Model Class Initialized
INFO - 2016-08-22 10:31:45 --> Model Class Initialized
INFO - 2016-08-22 10:31:45 --> Model Class Initialized
INFO - 2016-08-22 10:31:45 --> Model Class Initialized
INFO - 2016-08-22 10:31:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:31:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:31:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-22 10:31:45 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:31:45 --> Final output sent to browser
DEBUG - 2016-08-22 10:31:45 --> Total execution time: 0.3752
INFO - 2016-08-22 10:31:50 --> Config Class Initialized
INFO - 2016-08-22 10:31:50 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:31:50 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:31:50 --> Utf8 Class Initialized
INFO - 2016-08-22 10:31:50 --> URI Class Initialized
INFO - 2016-08-22 10:31:50 --> Router Class Initialized
INFO - 2016-08-22 10:31:50 --> Output Class Initialized
INFO - 2016-08-22 10:31:50 --> Security Class Initialized
DEBUG - 2016-08-22 10:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:31:50 --> Input Class Initialized
INFO - 2016-08-22 10:31:50 --> Language Class Initialized
INFO - 2016-08-22 10:31:50 --> Loader Class Initialized
INFO - 2016-08-22 10:31:50 --> Helper loaded: url_helper
INFO - 2016-08-22 10:31:50 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:31:50 --> Helper loaded: html_helper
INFO - 2016-08-22 10:31:50 --> Helper loaded: form_helper
INFO - 2016-08-22 10:31:50 --> Helper loaded: file_helper
INFO - 2016-08-22 10:31:50 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:31:50 --> Database Driver Class Initialized
INFO - 2016-08-22 10:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:31:50 --> Form Validation Class Initialized
INFO - 2016-08-22 10:31:50 --> Email Class Initialized
INFO - 2016-08-22 10:31:50 --> Controller Class Initialized
DEBUG - 2016-08-22 10:31:50 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:31:50 --> Model Class Initialized
INFO - 2016-08-22 10:31:50 --> Model Class Initialized
INFO - 2016-08-22 10:31:50 --> Model Class Initialized
INFO - 2016-08-22 10:31:50 --> Model Class Initialized
INFO - 2016-08-22 10:31:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:31:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:31:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/import_book.php
INFO - 2016-08-22 10:31:50 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:31:51 --> Config Class Initialized
INFO - 2016-08-22 10:31:51 --> Hooks Class Initialized
DEBUG - 2016-08-22 10:31:51 --> UTF-8 Support Enabled
INFO - 2016-08-22 10:31:51 --> Utf8 Class Initialized
INFO - 2016-08-22 10:31:51 --> URI Class Initialized
INFO - 2016-08-22 10:31:51 --> Router Class Initialized
INFO - 2016-08-22 10:31:51 --> Output Class Initialized
INFO - 2016-08-22 10:31:51 --> Security Class Initialized
DEBUG - 2016-08-22 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-22 10:31:51 --> Input Class Initialized
INFO - 2016-08-22 10:31:51 --> Language Class Initialized
INFO - 2016-08-22 10:31:51 --> Loader Class Initialized
INFO - 2016-08-22 10:31:51 --> Helper loaded: url_helper
INFO - 2016-08-22 10:31:51 --> Helper loaded: utils_helper
INFO - 2016-08-22 10:31:51 --> Helper loaded: html_helper
INFO - 2016-08-22 10:31:51 --> Helper loaded: form_helper
INFO - 2016-08-22 10:31:51 --> Helper loaded: file_helper
INFO - 2016-08-22 10:31:51 --> Helper loaded: myemail_helper
INFO - 2016-08-22 10:31:51 --> Database Driver Class Initialized
INFO - 2016-08-22 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-22 10:31:51 --> Form Validation Class Initialized
INFO - 2016-08-22 10:31:51 --> Email Class Initialized
INFO - 2016-08-22 10:31:51 --> Controller Class Initialized
DEBUG - 2016-08-22 10:31:51 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-22 10:31:51 --> Model Class Initialized
INFO - 2016-08-22 10:31:51 --> Model Class Initialized
INFO - 2016-08-22 10:31:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-22 10:31:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/menu.php
INFO - 2016-08-22 10:31:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\books/importBookResult.php
INFO - 2016-08-22 10:31:51 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-22 10:31:51 --> Final output sent to browser
DEBUG - 2016-08-22 10:31:51 --> Total execution time: 0.3740
