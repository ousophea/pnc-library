<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2016-08-11 01:47:40 --> Config Class Initialized
INFO - 2016-08-11 01:47:40 --> Hooks Class Initialized
DEBUG - 2016-08-11 01:47:41 --> UTF-8 Support Enabled
INFO - 2016-08-11 01:47:41 --> Utf8 Class Initialized
INFO - 2016-08-11 01:47:42 --> URI Class Initialized
INFO - 2016-08-11 01:47:43 --> Router Class Initialized
INFO - 2016-08-11 01:47:44 --> Output Class Initialized
INFO - 2016-08-11 01:47:45 --> Security Class Initialized
DEBUG - 2016-08-11 01:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 01:47:45 --> Input Class Initialized
INFO - 2016-08-11 01:47:45 --> Language Class Initialized
INFO - 2016-08-11 01:47:46 --> Loader Class Initialized
INFO - 2016-08-11 01:47:47 --> Helper loaded: url_helper
INFO - 2016-08-11 01:47:48 --> Helper loaded: utils_helper
INFO - 2016-08-11 01:47:48 --> Helper loaded: html_helper
INFO - 2016-08-11 01:47:49 --> Helper loaded: form_helper
INFO - 2016-08-11 01:47:49 --> Helper loaded: file_helper
INFO - 2016-08-11 01:47:50 --> Helper loaded: myemail_helper
INFO - 2016-08-11 01:47:53 --> Database Driver Class Initialized
INFO - 2016-08-11 01:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 01:47:57 --> Form Validation Class Initialized
INFO - 2016-08-11 01:47:59 --> Email Class Initialized
INFO - 2016-08-11 01:47:59 --> Controller Class Initialized
INFO - 2016-08-11 01:48:00 --> Config Class Initialized
INFO - 2016-08-11 01:48:00 --> Hooks Class Initialized
DEBUG - 2016-08-11 01:48:00 --> UTF-8 Support Enabled
INFO - 2016-08-11 01:48:00 --> Utf8 Class Initialized
INFO - 2016-08-11 01:48:00 --> URI Class Initialized
INFO - 2016-08-11 01:48:00 --> Router Class Initialized
INFO - 2016-08-11 01:48:00 --> Output Class Initialized
INFO - 2016-08-11 01:48:00 --> Security Class Initialized
DEBUG - 2016-08-11 01:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 01:48:00 --> Input Class Initialized
INFO - 2016-08-11 01:48:00 --> Language Class Initialized
INFO - 2016-08-11 01:48:01 --> Loader Class Initialized
INFO - 2016-08-11 01:48:01 --> Helper loaded: url_helper
INFO - 2016-08-11 01:48:01 --> Helper loaded: utils_helper
INFO - 2016-08-11 01:48:01 --> Helper loaded: html_helper
INFO - 2016-08-11 01:48:01 --> Helper loaded: form_helper
INFO - 2016-08-11 01:48:01 --> Helper loaded: file_helper
INFO - 2016-08-11 01:48:01 --> Helper loaded: myemail_helper
INFO - 2016-08-11 01:48:01 --> Database Driver Class Initialized
INFO - 2016-08-11 01:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2016-08-11 01:48:01 --> Form Validation Class Initialized
INFO - 2016-08-11 01:48:01 --> Email Class Initialized
INFO - 2016-08-11 01:48:01 --> Controller Class Initialized
INFO - 2016-08-11 01:48:01 --> Model Class Initialized
DEBUG - 2016-08-11 01:48:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2016-08-11 01:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/flash-connection.php
INFO - 2016-08-11 01:48:02 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/header.php
INFO - 2016-08-11 01:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\connection/login.php
INFO - 2016-08-11 01:48:03 --> File loaded: D:\wamp\www\library.pnc.lan\application\views\templates/footer.php
INFO - 2016-08-11 01:48:03 --> Final output sent to browser
DEBUG - 2016-08-11 01:48:03 --> Total execution time: 2.8726
INFO - 2016-08-11 01:48:05 --> Config Class Initialized
INFO - 2016-08-11 01:48:05 --> Hooks Class Initialized
DEBUG - 2016-08-11 01:48:05 --> UTF-8 Support Enabled
INFO - 2016-08-11 01:48:05 --> Utf8 Class Initialized
INFO - 2016-08-11 01:48:05 --> URI Class Initialized
INFO - 2016-08-11 01:48:05 --> Router Class Initialized
INFO - 2016-08-11 01:48:05 --> Output Class Initialized
INFO - 2016-08-11 01:48:05 --> Security Class Initialized
DEBUG - 2016-08-11 01:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 01:48:05 --> Input Class Initialized
INFO - 2016-08-11 01:48:05 --> Language Class Initialized
ERROR - 2016-08-11 01:48:05 --> 404 Page Not Found: Faviconico/index
INFO - 2016-08-11 01:48:06 --> Config Class Initialized
INFO - 2016-08-11 01:48:06 --> Hooks Class Initialized
DEBUG - 2016-08-11 01:48:06 --> UTF-8 Support Enabled
INFO - 2016-08-11 01:48:06 --> Utf8 Class Initialized
INFO - 2016-08-11 01:48:06 --> URI Class Initialized
INFO - 2016-08-11 01:48:06 --> Router Class Initialized
INFO - 2016-08-11 01:48:06 --> Output Class Initialized
INFO - 2016-08-11 01:48:06 --> Security Class Initialized
DEBUG - 2016-08-11 01:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2016-08-11 01:48:06 --> Input Class Initialized
INFO - 2016-08-11 01:48:06 --> Language Class Initialized
ERROR - 2016-08-11 01:48:06 --> 404 Page Not Found: Faviconico/index
