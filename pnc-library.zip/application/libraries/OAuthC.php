<?php
class OAuthC
{
    public function __construct()
    {
        require_once APPPATH . 'third_party/OAuthClient/vendor/autoload.php';
    }
}